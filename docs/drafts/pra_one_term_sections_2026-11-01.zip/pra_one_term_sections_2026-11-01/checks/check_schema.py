#!/usr/bin/env python3
"""Reproduce syntax ledgers and bounded examples for PRA from one term.

Uses Python 3 standard library only. This is a finite syntax generator and
checker, not a proof checker for PRA equivalence. Arithmetic evaluations are
bounded examples in the intended natural-number model. The external evaluator
is NOT asserted to be a primitive-recursive object-language universal evaluator.

The current comparison formulas are transcribed from AXIOMS.txt in the three
PRA archives at ProveIt commit d605be20835fc80907e01a105bcb059f07ed8b8c.
Stored descriptors are frozen under active-variable substitution. All costs
are declared AST conventions, not character counts or Kolmogorov complexity.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import random


@dataclass(frozen=True)
class Term:
    tag: str
    args: tuple[Term, ...] = ()
    name: str = ""
    body: Term | None = None


def V(name: str) -> Term:
    return Term("var", name=name)


ZERO = Term("zero")


def S(t: Term) -> Term:
    return Term("succ", (t,))


def fv(t: Term) -> set[str]:
    if t.tag == "var":
        return {t.name}
    return set().union(*(fv(a) for a in t.args))


def D(h: Term, count: Term, seed: Term) -> Term:
    if fv(h) - {"v"}:
        raise ValueError("A stored unary body has external free variables")
    return Term("delay", (count, seed), body=h)


def sub(t: Term, mapping: dict[str, Term]) -> Term:
    """Simultaneous substitution in active arguments only; h stays frozen."""
    if t.tag == "var":
        return mapping.get(t.name, t)
    return Term(t.tag, tuple(sub(a, mapping) for a in t.args), t.name, t.body)


def size(t: Term, stored: bool = False) -> int:
    return (1 + sum(size(a, stored) for a in t.args)
            + (size(t.body, True) if stored and t.body is not None else 0))


def occurrences(t: Term, name: str) -> int:
    return int(t.tag == "var" and t.name == name) + sum(
        occurrences(a, name) for a in t.args)


def rank(t: Term) -> int:
    return max([rank(a) for a in t.args]
               + ([1 + rank(t.body)] if t.body is not None else [0]))


def valid_term(t: Term, stack: frozenset[int] = frozenset()) -> None:
    if id(t) in stack:
        raise ValueError("Cyclic descriptor or term")
    arities = {"zero": 0, "var": 0, "succ": 1, "delay": 2}
    if t.tag not in arities or len(t.args) != arities[t.tag]:
        raise ValueError("Malformed term constructor")
    stack = stack | {id(t)}
    if t.tag == "delay":
        if t.body is None or fv(t.body) - {"v"}:
            raise ValueError("Illegal stored body")
        valid_term(t.body, stack)
    elif t.body is not None:
        raise ValueError("A non-iterator node stores a descriptor")
    for a in t.args:
        valid_term(a, stack)


@dataclass(frozen=True)
class Formula:
    tag: str
    children: tuple[Formula, ...] = ()
    terms: tuple[Term, ...] = ()
    binder: str = ""


BOTTOM = Formula("bottom")


def Eq(s: Term, t: Term) -> Formula:
    return Formula("eq", terms=(s, t))


def Bin(tag: str, f: Formula, g: Formula) -> Formula:
    return Formula(tag, (f, g))


def And(f: Formula, g: Formula) -> Formula:
    return Bin("and", f, g)


def Or(f: Formula, g: Formula) -> Formula:
    return Bin("or", f, g)


def Imp(f: Formula, g: Formula) -> Formula:
    return Bin("imp", f, g)


def All(name: str, f: Formula) -> Formula:
    return Formula("all", (f,), binder=name)


def formula_fv(f: Formula) -> set[str]:
    found = set().union(*(fv(t) for t in f.terms),
                        *(formula_fv(c) for c in f.children))
    return found - {f.binder} if f.tag == "all" else found


def active_names(f: Formula) -> set[str]:
    found = set().union(*(fv(t) for t in f.terms),
                        *(active_names(c) for c in f.children))
    return found | {f.binder} if f.tag == "all" else found


def formula_sub(f: Formula, mapping: dict[str, Term]) -> Formula:
    if f.tag == "all":
        binder = f.binder
        child = f.children[0]
        effective = {k: x for k, x in mapping.items()
                     if k != binder and k in formula_fv(child)}
        replacement_fv = set().union(*(fv(x) for x in effective.values()))
        if binder in replacement_fv:
            forbidden = active_names(child) | replacement_fv | set(effective)
            i = 0
            while f"z{i}" in forbidden:
                i += 1
            fresh = f"z{i}"
            child = formula_sub(child, {binder: V(fresh)})
            binder = fresh
        return All(binder, formula_sub(child, effective))
    return Formula(f.tag,
                   tuple(formula_sub(c, mapping) for c in f.children),
                   tuple(sub(t, mapping) for t in f.terms), f.binder)


def formula_size(f: Formula, stored: bool = False) -> int:
    return (1 + sum(formula_size(c, stored) for c in f.children)
            + sum(size(t, stored) for t in f.terms))


def quantifiers(f: Formula) -> int:
    return int(f.tag == "all") + sum(quantifiers(c) for c in f.children)


def quantifier_depth(f: Formula) -> int:
    return int(f.tag == "all") + max(
        (quantifier_depth(c) for c in f.children), default=0)


def shadowing(f: Formula, bound: frozenset[str] = frozenset()) -> bool:
    if f.tag == "all":
        return f.binder in bound or shadowing(f.children[0], bound | {f.binder})
    return any(shadowing(c, bound) for c in f.children)


def valid_formula(f: Formula) -> None:
    expected = {"bottom": (0, 0), "eq": (0, 2), "and": (2, 0),
                "or": (2, 0), "imp": (2, 0), "all": (1, 0)}
    if f.tag not in expected or (len(f.children), len(f.terms)) != expected[f.tag]:
        raise ValueError("Malformed formula")
    for t in f.terms:
        valid_term(t)
    for child in f.children:
        valid_formula(child)


n, a, b, v = map(V, ("n", "a", "b", "v"))
ONE = S(ZERO)
SIGMA = Imp(Eq(ZERO, ONE), BOTTOM)


def endpoints(u: Term, variant: str = "moving") -> tuple[Term, Term]:
    if fv(u) - {"n", "a", "b"}:
        raise ValueError("Source term has an unpermitted free variable")
    if variant not in {"moving", "fixed"}:
        raise ValueError("Unknown section variant")
    return (sub(u, {"b": ZERO}),
            sub(u, {"b": a if variant == "moving" else ONE}))


def zero_section(u: Term) -> Term:
    if fv(u) - {"n", "a", "b"}:
        raise ValueError("Source term has an unpermitted free variable")
    return sub(u, {"n": v, "a": ZERO, "b": ZERO})


def old_diagonal(s: Term) -> Term:
    if fv(s) - {"n", "a"}:
        raise ValueError("Old source term has an unpermitted free variable")
    return sub(s, {"n": v, "a": v})


def reset(h: Term) -> Formula:
    return Eq(D(h, D(ONE, n, ZERO), a), a)


def tail(h: Term) -> Formula:
    return Eq(D(h, S(S(n)), a), sub(h, {"v": D(h, S(n), a)}))


def sidecar(h: Term) -> Formula:
    return And(SIGMA, And(reset(h), tail(h)))


def rooted(s: Term, t: Term) -> Formula:
    return Or(Eq(n, ZERO), Eq(s, t))


def new_axiom(u: Term, variant: str = "moving") -> Formula:
    s, t = endpoints(u, variant)
    p = rooted(s, t)
    successor_eq = formula_sub(Eq(s, t), {"n": S(n)})
    return All("a", Imp(All("n", Imp(p, successor_eq)),
                        All("n", And(p, sidecar(zero_section(u))))))


def old_one_schema(s: Term, t: Term) -> Formula:
    """Exact one_schema archive A, with original diagonal h_s."""
    p = rooted(s, t)
    return All("a", Imp(All("n", Imp(p, formula_sub(p, {"n": S(n)}))),
                        All("n", And(p, sidecar(old_diagonal(s))))))


def optimized_pair(s: Term, t: Term) -> Formula:
    """Same two-term input interface as old A; shorter successor/zero section."""
    if (fv(s) | fv(t)) - {"n", "a"}:
        raise ValueError("Two-term input has an unpermitted free variable")
    p0 = rooted(s, t)
    h = sub(s, {"n": v, "a": ZERO})
    return All("a", Imp(All("n", Imp(p0, formula_sub(Eq(s, t), {"n": S(n)}))),
                        All("n", And(p0, sidecar(h)))))


def short_dynamic(s: Term, t: Term) -> Formula:
    p = rooted(s, t)
    return All("a", Imp(All("n", Imp(p, formula_sub(Eq(s, t), {"n": S(n)}))),
                        All("n", p)))


def short_computational(h: Term) -> Formula:
    c = sidecar(h)
    return All("a", Imp(All("n", Imp(c, Eq(ZERO, ZERO))), All("n", c)))


def p(x: Term) -> Term:
    return D(S(v), x, ZERO)


def Z(r: Term, x: Term) -> Term:
    return D(ZERO, S(r), x)


def B(s: Term, t: Term, probe: Term = b) -> Term:
    """Pre-selector: slices at 0/Sr are s and p(St), before bootstrap."""
    return D(S(v), Z(Z(probe, ONE), S(t)), Z(probe, s))


def compile_pair(s: Term, t: Term, variant: str = "moving") -> Term:
    if variant == "fixed":
        return B(s, t)
    if variant != "moving":
        raise ValueError("Unknown section variant")
    # The emitted axiom is specialized at a=S(c), so p(a) becomes c.
    return B(sub(s, {"a": p(a)}), sub(t, {"a": p(a)}))


def encode(t: Term) -> list:
    return [t.tag, t.name, [encode(x) for x in t.args],
            encode(t.body) if t.body is not None else None]


def descriptor_id(h: Term) -> str:
    data = json.dumps(encode(h), separators=(",", ":")).encode()
    return hashlib.sha256(data).hexdigest()[:12]


def descriptors(f: Formula) -> set[Term]:
    found: set[Term] = set()
    def term_walk(t: Term) -> None:
        if t.body is not None and t.body not in found:
            found.add(t.body)
            term_walk(t.body)
        for x in t.args:
            term_walk(x)
    def formula_walk(g: Formula) -> None:
        for t in g.terms:
            term_walk(t)
        for child in g.children:
            formula_walk(child)
    formula_walk(f)
    return found


def ledger(*formulas: Formula) -> dict[str, int | bool | list[str]]:
    ds = set().union(*(descriptors(f) for f in formulas))
    return {
        "active_ast": sum(formula_size(f) for f in formulas),
        "descriptor_tree_ast": sum(formula_size(f, True) for f in formulas),
        "distinct_stored_descriptors": len(ds),
        "descriptor_body_nodes_once": sum(size(h) for h in ds),
        "active_plus_descriptor_dictionary_ast": (
            sum(formula_size(f) for f in formulas) + sum(size(h) for h in ds)),
        "quantifier_occurrences": sum(quantifiers(f) for f in formulas),
        "maximum_quantifier_depth": max((quantifier_depth(f) for f in formulas), default=0),
        "active_individual_names": sorted(set().union(*(active_names(f) for f in formulas))),
        "binder_shadowing": any(shadowing(f) for f in formulas),
    }


def term_text(t: Term) -> str:
    if t.tag == "var":
        return t.name
    if t.tag == "zero":
        return "0"
    if t.tag == "succ":
        return f"S({term_text(t.args[0])})"
    assert t.body is not None
    return f"D_{descriptor_id(t.body)}({term_text(t.args[0])},{term_text(t.args[1])})"


def formula_text(f: Formula) -> str:
    if f.tag == "bottom":
        return "false"
    if f.tag == "eq":
        return f"({term_text(f.terms[0])}={term_text(f.terms[1])})"
    if f.tag == "all":
        return f"forall {f.binder}. {formula_text(f.children[0])}"
    op = {"and": "AND", "or": "OR", "imp": "->"}[f.tag]
    return f"({formula_text(f.children[0])} {op} {formula_text(f.children[1])})"


@lru_cache(maxsize=200000)
def evaluate(t: Term, environment: tuple[tuple[str, int], ...]) -> int:
    """External finite evaluation, only used on explicitly small examples."""
    env = dict(environment)
    if t.tag == "zero":
        return 0
    if t.tag == "var":
        return env[t.name]
    if t.tag == "succ":
        return 1 + evaluate(t.args[0], environment)
    count, value = (evaluate(x, environment) for x in t.args)
    if count > 10000:
        raise ValueError("Example exceeds the declared iteration resource bound")
    assert t.body is not None
    for _ in range(max(count - 1, 0)):
        value = evaluate(t.body, (("v", value),))
        if value > 1000000:
            raise ValueError("Example exceeds the declared value resource bound")
    return value


def ev(t: Term, **env: int) -> int:
    return evaluate(t, tuple(sorted(env.items())))


def sample_terms() -> dict[str, Term]:
    pred_body = p(v)
    return {
        "zero": ZERO,
        "counter": n,
        "parameter": a,
        "probe": b,
        "successor_counter": S(n),
        "counter_parameter": D(S(v), n, a),
        "probe_counter": D(S(v), b, n),
        "nested_descriptors": D(pred_body, S(n), D(ONE, a, b)),
        "predecessor_bootstrap": B(n, n),
        "compiled_arithmetic_pair": compile_pair(D(S(v), S(n), a), Z(n, a)),
    }


def generated_terms() -> list[Term]:
    """Deterministic modest finite sample; no completeness claim."""
    rng = random.Random(20261101)
    pool = [ZERO, n, a, b]
    bodies = [ZERO, ONE, v, S(v), p(v), D(ONE, S(v), v)]
    for _ in range(240):
        candidates = [x for x in pool if size(x, True) <= 50]
        if rng.randrange(3) == 0:
            new = S(rng.choice(candidates))
        else:
            new = D(rng.choice(bodies), rng.choice(candidates), rng.choice(candidates))
        pool.append(new)
    return list(dict.fromkeys(pool))


def verify_counts(u: Term) -> None:
    valid_term(u)
    U, W = size(u), size(u, True)
    N, A, BB = (occurrences(u, x) for x in ("n", "a", "b"))
    h = zero_section(u)
    assert size(h) == U and size(h, True) == W
    assert occurrences(h, "v") == N
    assert fv(h) <= {"v"} and rank(h) == rank(u)
    assert rank(D(h, n, a)) == rank(u) + 1
    for variant in ("moving", "fixed"):
        s, t = endpoints(u, variant)
        extra = 3 * BB if variant == "fixed" else 0
        f, old = new_axiom(u, variant), old_one_schema(s, t)
        for form in (f, old, short_dynamic(s, t), short_computational(h)):
            valid_formula(form)
            assert not formula_fv(form)
            assert active_names(form) <= {"n", "a"}
            assert quantifiers(form) == 3
            assert quantifier_depth(form) == 2
            assert not shadowing(form)
        assert formula_size(f) == 38 + 7 * U + 5 * N + extra
        assert formula_size(old) == 43 + 7 * U + 5 * N + 3 * A + extra
        assert formula_size(old) - formula_size(f) == 5 + 3 * A
        assert formula_size(f, True) == 40 + 9 * W + 5 * N + N * W + extra
        assert formula_size(old, True) == 45 + 9 * W + 5 * N + 3 * A + (N + A) * W + extra
        assert formula_size(old, True) - formula_size(f, True) == 5 + A * (3 + W)
        assert formula_size(short_dynamic(s, t)) == 16 + 6 * U + 2 * N + extra
        assert formula_size(short_computational(h)) == 50 + 2 * U + 6 * N
    assert formula_size(new_axiom(u, "fixed")) - formula_size(new_axiom(u)) == 3 * BB


def verify_pair_counts(s: Term, t: Term) -> None:
    Us, Ut, Ws, Wt = size(s), size(t), size(s, True), size(t, True)
    Ns, Nt, As = occurrences(s, "n"), occurrences(t, "n"), occurrences(s, "a")
    old, new = old_one_schema(s, t), optimized_pair(s, t)
    for f in (old, new):
        valid_formula(f)
        assert not formula_fv(f) and active_names(f) <= {"n", "a"}
        assert quantifiers(f) == 3 and quantifier_depth(f) == 2
    assert formula_size(new) == 38 + 4 * Us + 3 * Ut + 4 * Ns + Nt
    assert formula_size(old) - formula_size(new) == 5 + 3 * As
    assert formula_size(new, True) == 40 + 6 * Ws + 3 * Wt + 4 * Ns + Nt + Ns * Ws
    assert formula_size(old, True) - formula_size(new, True) == 5 + As * (3 + Ws)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent,
                        help="Destination for results.json and examples.txt")
    options = parser.parse_args()
    samples = sample_terms()
    generated = generated_terms()
    for u in list(samples.values()) + generated:
        verify_counts(u)
    generated_pairs = [endpoints(u) for u in generated]
    for s, t in generated_pairs:
        verify_pair_counts(s, t)
    comparison_pairs = {
        "n_a": (n, a),
        "a_n": (a, n),
        "zero_zero": (ZERO, ZERO),
        "successor_n_a": (S(n), a),
        "both_arguments": (D(S(v), n, a), D(ONE, a, n)),
        "nested": (D(p(v), S(n), D(ONE, a, n)), D(S(v), a, n)),
    }
    for s, t in comparison_pairs.values():
        verify_pair_counts(s, t)

    # Every chosen legal stored body is recovered literally, not semantically.
    bodies = [ZERO, ONE, v, S(v), p(v), D(p(v), S(v), D(ONE, v, ZERO))]
    for h in bodies:
        u = sub(h, {"v": n})
        assert zero_section(u) == h
        assert endpoints(u)[0] == endpoints(u)[1]
        progress = new_axiom(u).children[0].children[0].children[0]
        target_eq = progress.children[1]
        assert target_eq.tag == "eq" and target_eq.terms[0] == target_eq.terms[1]
        conclusion = new_axiom(u).children[0].children[1].children[0]
        assert conclusion.children[1] == sidecar(h)

    # Stored variables are not active; simultaneous substitution is not sequential.
    stored = D(p(v), n, a)
    changed = sub(stored, {"n": a, "a": n, "v": ZERO})
    assert changed.body == stored.body and changed.args == (a, n)
    assert zero_section(D(S(v), n, a)) == D(S(v), v, ZERO)
    hazard = formula_sub(All("a", Eq(n, a)), {"n": a})
    assert hazard.binder != "a" and formula_fv(hazard) == {"a"}
    assert hazard.children[0] == Eq(a, V(hazard.binder))
    bad = [lambda: D(S(V("external")), n, a),
           lambda: new_axiom(V("external")),
           lambda: valid_term(Term("unknown"))]
    rejected = 0
    for attempt in bad:
        try:
            attempt()
        except ValueError:
            rejected += 1
        else:
            raise AssertionError("Illegal syntax accepted")

    # Bounded model checks do not establish universal identities or induction.
    raw_selector = B(V("x"), V("y"))
    selector_cases = 0
    for x in range(12):
        for y in range(12):
            assert ev(raw_selector, x=x, y=y, b=0) == x
            for probe in range(1, 8):
                assert ev(raw_selector, x=x, y=y, b=probe) == y
            selector_cases += 8
    bootstrap_cases = 0
    for k in range(20):
        assert ev(B(n, n), n=k, b=0) == k
        assert ev(B(n, n), n=k, b=1) == ev(p(S(n)), n=k) == k
        bootstrap_cases += 1
    pairs = [(n, a), (D(S(v), S(n), a), Z(n, a)),
             (D(p(v), S(n), a), D(S(v), a, n))]
    moving_cases = 0
    for s, t in pairs:
        u = compile_pair(s, t)
        s0, sa = endpoints(u)
        for k in range(9):
            for parameter in range(8):
                assert ev(s0, n=k, a=parameter + 1) == ev(s, n=k, a=parameter)
                assert ev(sa, n=k, a=parameter + 1) == ev(t, n=k, a=parameter)
                moving_cases += 1

    rows, text_rows = {}, []
    for name, u in samples.items():
        s, t = endpoints(u)
        f = new_axiom(u)
        h = zero_section(u)
        sh, th = endpoints(u, "fixed")
        reflexive_u = sub(h, {"v": n})
        rows[name] = {
            "u": term_text(u), "zero_section": term_text(h),
            "U_active": size(u), "W_descriptor_tree": size(u, True),
            "occ_n": occurrences(u, "n"), "occ_a": occurrences(u, "a"),
            "occ_b": occurrences(u, "b"), "input_dependency_rank": rank(u),
            "attached_descriptor_rank": rank(u) + 1,
            "preferred_moving": ledger(f),
            "fixed_zero_one_intermediate": ledger(new_axiom(u, "fixed")),
            "old_one_schema_same_moving_endpoints": ledger(old_one_schema(s, t)),
            "old_one_schema_fixed_endpoints": ledger(old_one_schema(sh, th)),
            "short_dynamic_same_endpoints": ledger(short_dynamic(s, t)),
            "short_computational_same_zero_section": ledger(short_computational(h)),
            "short_dynamic_plus_computational": ledger(short_dynamic(s, t), short_computational(h)),
            "new_plus_reflexive_computational_instance": ledger(f, new_axiom(reflexive_u)),
        }
        text_rows.append(f"[{name}]\nu = {term_text(u)}\nh = {term_text(h)}\n{formula_text(f)}")
        for body in sorted(descriptors(f), key=lambda x: (rank(x), descriptor_id(x))):
            text_rows.append(f"  D_{descriptor_id(body)} stores {term_text(body)}; symbol rank {rank(body) + 1}")

    pair_rows = {}
    for name, (s, t) in comparison_pairs.items():
        f = optimized_pair(s, t)
        pair_rows[name] = {
            "s": term_text(s), "t": term_text(t),
            "s_active_nodes": size(s), "s_tree_nodes": size(s, True),
            "s_parameter_occurrences": occurrences(s, "a"),
            "old_one_schema": ledger(old_one_schema(s, t)),
            "optimized_pair": ledger(f),
            "active_saving": formula_size(old_one_schema(s, t)) - formula_size(f),
            "tree_saving": formula_size(old_one_schema(s, t), True) - formula_size(f, True),
        }
        text_rows.append(f"[same-interface optimized pair: {name}]\ns = {term_text(s)}\nt = {term_text(t)}\n{formula_text(f)}")
        for body in sorted(descriptors(f), key=lambda x: (rank(x), descriptor_id(x))):
            text_rows.append(f"  D_{descriptor_id(body)} stores {term_text(body)}; symbol rank {rank(body) + 1}")

    results = {
        "scope": "Finite syntax validation and bounded intended-model examples, not a proof checker.",
        "comparison_commit": "d605be20835fc80907e01a105bcb059f07ed8b8c",
        "preferred_endpoints": "u(n,a,0)=u(n,a,a)",
        "stored_body": "h_u(v)=u(v,0,0)",
        "source_input_variable_slots": ["n", "a", "b"],
        "emitted_axiom_variable_names": ["n", "a"],
        "cost_conventions": {
            "active_ast": "One node per variable, constant, function application, relation, connective, bottom, quantifier; stored descriptor is an opaque symbol label.",
            "descriptor_tree_ast": "The same tree cost, recursively including a stored body at every iterator occurrence, with no sharing.",
            "dictionary_ast": "Active formula nodes plus active nodes of each distinct stored body once; excludes textual names, indices and serialization overhead.",
            "U": "Active AST size of input u.",
            "W": "Input u tree size including all stored bodies recursively.",
            "N_A_B": "Active occurrences in u of n, a, b; stored bodies are excluded.",
        },
        "exact_formulas": {
            "preferred_active": "38+7U+5N",
            "fixed_zero_one_active": "38+7U+5N+3B",
            "old_one_schema_moving_active": "43+7U+5N+3A",
            "preferred_saving_vs_old_same_endpoints_active": "5+3A",
            "preferred_tree": "40+9W+5N+NW",
            "old_one_schema_moving_tree": "45+9W+5N+3A+(N+A)W",
            "preferred_saving_vs_old_same_endpoints_tree": "5+A(3+W)",
            "short_dynamic_moving_active": "16+6U+2N",
            "short_computational_zero_section_active": "50+2U+6N",
            "optimized_pair_active": "38+4Us+3Ut+4Ns+Nt",
            "optimized_pair_saving_same_interface_active": "5+3As",
            "optimized_pair_tree": "40+6Ws+3Wt+4Ns+Nt+NsWs",
            "optimized_pair_saving_same_interface_tree": "5+As(3+Ws)",
        },
        "comparison_caveat": "Matched old/new individual axioms attach different stored bodies and are not asserted logically equivalent as single axioms. The full schemas are equivalent by the written proof. The short dynamic axiom alone lacks computation. The short dynamic plus computational pair is equivalent to the new instance plus its reflexive computational instance, not in general to the new instance alone. There is no claim of uniform size improvement when compiling arbitrary old input pairs through the selector.",
        "sample_count": len(samples),
        "generated_term_count": len(generated),
        "generated_pair_count": len(generated_pairs),
        "same_interface_pair_examples": pair_rows,
        "exact_descriptor_extractions": len(bodies),
        "stored_descriptor_freezing_checked": True,
        "capture_avoidance_checked": True,
        "illegal_inputs_rejected": rejected,
        "bounded_examples": {
            "selector_cases": selector_cases,
            "predecessor_cases": bootstrap_cases,
            "compiled_moving_pair_cases": moving_cases,
            "not_a_consistency_or_induction_strength_proof": True,
        },
        "samples": rows,
    }
    options.out.mkdir(parents=True, exist_ok=True)
    (options.out / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    (options.out / "examples.txt").write_text("\n\n".join(text_rows) + "\n")
    print(json.dumps({"status": "passed", "samples": len(samples),
                      "generated_terms": len(generated),
                      "descriptor_extractions": len(bodies),
                      "bounded_examples": results["bounded_examples"]}, indent=2))


if __name__ == "__main__":
    main()
