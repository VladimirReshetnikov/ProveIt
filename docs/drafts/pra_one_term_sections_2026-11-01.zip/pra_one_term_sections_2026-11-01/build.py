#!/usr/bin/env python3
"""Rebuild this research package using installed tools; no downloads."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


def run(argv: list[str], cwd: Path, log: Path) -> dict:
    result = subprocess.run(argv, cwd=cwd, text=True, capture_output=True)
    log.write_text(result.stdout + result.stderr)
    if result.returncode:
        raise SystemExit(f"Command failed ({result.returncode}); see {log}")
    return {"argv": argv, "exit_code": result.returncode, "log": str(log.relative_to(cwd))}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Optional path or executable name for Lean 4.19.0")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    audit = root / "audit"
    audit.mkdir(exist_ok=True)
    tex = shutil.which("pdflatex")
    if not tex:
        raise SystemExit("pdflatex is required; no installation will be attempted.")
    checks = [run([sys.executable, "checks/check_schema.py", "--out", "checks"],
                  root, audit / "syntax_check.txt")]
    for number in range(1, 4):
        checks.append(run([tex, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
                          root, audit / f"latex_pass_{number}.txt"))
    final_log = (root / "report.log").read_text(errors="replace")
    problems = [line for line in final_log.splitlines()
                if "Overfull" in line or "undefined" in line.lower()
                or "multiply defined" in line.lower()]
    if problems:
        raise SystemExit("Layout or reference warnings require review:\n" + "\n".join(problems))
    if args.lean:
        checks.append(run([args.lean, "--version"], root, audit / "lean_rebuild_version.txt"))
        checks.append(run([args.lean, "formal/SectionsKernel.lean"],
                          root, audit / "lean_rebuild_check.txt"))
    pdf = root / "report.pdf"
    receipt = {
        "status": "passed",
        "commands": checks,
        "pdf_bytes": pdf.stat().st_size,
        "pdf_sha256": hashlib.sha256(pdf.read_bytes()).hexdigest(),
        "visual_review": "Separate; see audit/validation.json for delivered version.",
    }
    (audit / "build_results.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"status": "passed", "pdf_bytes": receipt["pdf_bytes"],
                      "pdf_sha256": receipt["pdf_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
