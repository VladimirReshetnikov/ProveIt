/-
PRA from one term: constructive parameter-probe compression kernel.
Lean 4.19.0, core library only.

This file proves local logical and algebraic implications used in the
manuscript. It does not formalize first-order syntax, the PR compiler,
scalar pairing, or the full bi-interpretability theorem. In particular,
functions supplied to the lemmas represent the denotations of particular
term templates; no claim that arbitrary functions are object-language
terms is made. See SCOPE.txt.
-/
import Init

universe u
namespace SectionsKernel

variable {A : Type u}

/-- The short rooted propagation implication for one predicate. -/
def ShortAt (zero : A) (succ : A → A) (E : A → Prop) : Prop :=
  (∀ n, (n = zero ∨ E n) → E (succ n)) → ∀ n, n = zero ∨ E n

/-- The endpoint equation probes the third argument at 0 and at a. -/
def Probe (zero : A) (t : A → A → A → A) (n a : A) : Prop :=
  t n a zero = t n a a

/-- The propagation part of all numerical instances of one template. -/
def SectionsPropagation (zero : A) (succ : A → A)
    (t : A → A → A → A) : Prop :=
  ∀ a, ShortAt zero succ (fun n => Probe zero t n a)

/-- One emitted axiom, with its descriptor-dependent sidecar abstracted. -/
def Emit (zero : A) (succ : A → A) (t : A → A → A → A)
    (C : A → A → Prop) : Prop :=
  ∀ a, (∀ n, (n = zero ∨ Probe zero t n a) → Probe zero t (succ n) a) →
    ∀ n, (n = zero ∨ Probe zero t n a) ∧ C n a

/-- Projection from an emitted instance to its propagation implication. -/
theorem propagation_of_emit {zero : A} {succ : A → A}
    {t : A → A → A → A} {C : A → A → Prop}
    (h : Emit zero succ t C) : SectionsPropagation zero succ t := by
  intro a step n
  exact (h a step n).1

/-- Independent computation and short propagation prove the whole axiom. -/
theorem emit_of_propagation_and_computation {zero : A} {succ : A → A}
    {t : A → A → A → A} {C : A → A → Prop}
    (sp : SectionsPropagation zero succ t) (comp : ∀ n a, C n a) :
    Emit zero succ t C := by
  intro a step n
  exact ⟨sp a step n, comp n a⟩

/-- The input t(n,a,b)=h(n) makes its premise reflexive and exposes C. -/
theorem computation_of_reflexive_emit {zero : A} {succ : A → A}
    (h : A → A) {C : A → A → Prop}
    (ax : Emit zero succ (fun n _ _ => h n) C) : ∀ n a, C n a := by
  intro n a
  exact (ax a (fun _ _ => Eq.refl _) n).2

/-- Rooted short propagation supplies induction under local base/step assumptions. -/
theorem induction_of_short {zero : A} {succ : A → A} {E : A → Prop}
    (sp : ShortAt zero succ E) (base : E zero)
    (step : ∀ n, E n → E (succ n)) : ∀ n, E n := by
  have rooted : ∀ n, n = zero ∨ E n := sp (by
    intro n hn
    apply step n
    cases hn with
    | inl hz => cases hz; exact base
    | inr he => exact he)
  intro n
  cases rooted n with
  | inl hz => cases hz; exact base
  | inr he => exact he

/-- Pointwise equivalence transfers short propagation without propositional extensionality. -/
theorem transport_short {zero : A} {succ : A → A} {E F : A → Prop}
    (eqv : ∀ n, E n ↔ F n) (sp : ShortAt zero succ E) :
    ShortAt zero succ F := by
  intro step
  have rooted : ∀ n, n = zero ∨ E n := sp (by
    intro n hn
    apply (eqv (succ n)).2
    apply step n
    cases hn with
    | inl hz => exact Or.inl hz
    | inr he => exact Or.inr ((eqv n).1 he))
  intro n
  cases rooted n with
  | inl hz => exact Or.inl hz
  | inr he => exact Or.inr ((eqv n).1 he)

/-- Recover both delayed seeds from Reset and the constant-one Tail instance. -/
theorem two_seeds {zero : A} {succ : A → A} (q d : A → A → A)
    (qtail : q (succ (succ zero)) zero = succ zero)
    (qreset : ∀ n a, q (q n zero) a = a)
    (dreset : ∀ n a, d (q n zero) a = a) :
    ∀ a, d zero a = a ∧ d (succ zero) a = a := by
  have one : ∀ a, d (succ zero) a = a := by
    intro a
    have h := dreset (succ (succ zero)) a
    rw [qtail] at h
    exact h
  have qone : q (succ zero) zero = zero := by
    have h := qreset (succ (succ zero)) zero
    rw [qtail] at h
    exact h
  intro a
  have hz := dreset (succ zero) a
  rw [qone] at hz
  exact ⟨hz, one a⟩

/-- Only the recovered computation instances needed in the new bootstrap. -/
structure Computation (A : Type u) where
  zero : A
  succ : A → A
  ds : A → A → A
  d0 : A → A → A
  ds_zero : ∀ x, ds zero x = x
  ds_one : ∀ x, ds (succ zero) x = x
  ds_tail : ∀ n x, ds (succ (succ n)) x = succ (ds (succ n) x)
  d0_one : ∀ x, d0 (succ zero) x = x
  d0_tail : ∀ n x, d0 (succ (succ n)) x = zero

namespace Computation
variable (K : Computation A)

def one : A := K.succ K.zero
def pred (n : A) : A := K.ds n K.zero
def Z (r x : A) : A := K.d0 (K.succ r) x

/-- The same small term both bootstraps predecessor and later selects branches. -/
def B (b s t : A) : A :=
  K.ds (K.Z (K.Z b K.one) (K.succ t)) (K.Z b s)

theorem z_zero (x : A) : K.Z K.zero x = x := K.d0_one x

theorem z_succ (r x : A) : K.Z (K.succ r) x = K.zero := K.d0_tail r x

/-- This branch needs seeds alone. -/
theorem b_zero (s t : A) : K.B K.zero s t = s := by
  unfold B
  rw [K.z_zero K.one, K.z_zero s]
  change K.ds (K.Z (K.succ K.zero) (K.succ t)) s = s
  rw [K.z_succ, K.ds_zero]

/-- Before predecessor, the successor branch returns p(St), not yet t. -/
theorem b_succ_before_pred (r s t : A) :
    K.B (K.succ r) s t = K.pred (K.succ t) := by
  unfold B
  rw [K.z_succ r K.one, K.z_succ r s, K.z_zero]
  rfl

/-- The single special template needed before arbitrary equation propagation. -/
def predecessorTemplate (n _a b : A) : A := K.B b n n

theorem predecessor_probe (n : A) :
    Probe K.zero K.predecessorTemplate n K.one ↔ n = K.pred (K.succ n) := by
  unfold Probe predecessorTemplate
  rw [K.b_zero]
  change (n = K.B (K.succ K.zero) n n) ↔ n = K.pred (K.succ n)
  rw [K.b_succ_before_pred]

/-- A single template at parameter a=1 recovers p(Sn)=n constructively. -/
theorem predecessor_of_sections
    (sp : SectionsPropagation K.zero K.succ K.predecessorTemplate) :
    ∀ n, K.pred (K.succ n) = n := by
  have base : Probe K.zero K.predecessorTemplate K.zero K.one := by
    apply (K.predecessor_probe K.zero).2
    exact (K.ds_one K.zero).symm
  have step : ∀ n, Probe K.zero K.predecessorTemplate n K.one →
      Probe K.zero K.predecessorTemplate (K.succ n) K.one := by
    intro n hn
    apply (K.predecessor_probe (K.succ n)).2
    have ih := (K.predecessor_probe n).1 hn
    change K.succ n = K.ds (K.succ (K.succ n)) K.zero
    rw [K.ds_tail]
    exact congrArg K.succ ih
  have all := induction_of_short (sp K.one) base step
  intro n
  exact ((K.predecessor_probe n).1 (all n)).symm

/-- Once predecessor is recovered, B is a selector on every successor tag. -/
theorem b_succ (hp : ∀ n, K.pred (K.succ n) = n) (r s t : A) :
    K.B (K.succ r) s t = t :=
  Eq.trans (K.b_succ_before_pred r s t) (hp t)

/-- Encode a pair with parameter c by supplying a=Sc and decoding p(a). -/
def pairTemplate (s t : A → A → A) (n a b : A) : A :=
  K.B b (s n (K.pred a)) (t n (K.pred a))

theorem pair_probe (hp : ∀ n, K.pred (K.succ n) = n)
    (s t : A → A → A) (n c : A) :
    Probe K.zero (K.pairTemplate s t) n (K.succ c) ↔ s n c = t n c := by
  unfold Probe pairTemplate
  rw [K.b_zero, K.b_succ hp, hp c]

/-- The parameter probe recovers arbitrary two-term short propagation. -/
theorem pair_propagation_of_sections
    (hp : ∀ n, K.pred (K.succ n) = n) (s t : A → A → A)
    (sp : SectionsPropagation K.zero K.succ (K.pairTemplate s t)) :
    ∀ c, ShortAt K.zero K.succ (fun n => s n c = t n c) := by
  intro c
  exact transport_short (fun n => K.pair_probe hp s t n c) (sp (K.succ c))

/-- Combined local bootstrap: only the two displayed template instances are used. -/
theorem compression_kernel
    (pre : SectionsPropagation K.zero K.succ K.predecessorTemplate)
    (s t : A → A → A)
    (encoded : SectionsPropagation K.zero K.succ (K.pairTemplate s t)) :
    ∀ c, ShortAt K.zero K.succ (fun n => s n c = t n c) :=
  K.pair_propagation_of_sections (K.predecessor_of_sections pre) s t encoded

end Computation

/- These receipts must list no axiom dependencies. -/
#print axioms propagation_of_emit
#print axioms emit_of_propagation_and_computation
#print axioms computation_of_reflexive_emit
#print axioms induction_of_short
#print axioms transport_short
#print axioms two_seeds
#print axioms Computation.b_zero
#print axioms Computation.b_succ_before_pred
#print axioms Computation.predecessor_of_sections
#print axioms Computation.b_succ
#print axioms Computation.pair_probe
#print axioms Computation.pair_propagation_of_sections
#print axioms Computation.compression_kernel

end SectionsKernel
