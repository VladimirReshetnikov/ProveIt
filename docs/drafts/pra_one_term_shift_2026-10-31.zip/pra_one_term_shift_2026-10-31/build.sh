#!/bin/sh
set -eu
cd "$(dirname "$0")"
pdflatex -interaction=nonstopmode -halt-on-error pra_one_term_shift.tex
pdflatex -interaction=nonstopmode -halt-on-error pra_one_term_shift.tex
pdflatex -interaction=nonstopmode -halt-on-error pra_one_term_shift.tex
