PRA FROM ONE-TERM INDUCTION AND A SUBTRACTION IDENTITY
31 October 2026
====================================================

Main result
-----------
The exclusive draft's one-term schema becomes an exact common
axiomatization of classical and intuitionistic PRA after adding the one
fixed equation M(Sx,Sy)=M(x,y), where M(n,a) denotes a truncated-minus n.
Every recursor may be binary, and the schema needs only one numerical
parameter. No semantic equality-comparison bridge is assumed.

The proof derives moving-target equation induction, zero-test induction,
native equality reflection, full quantifier-free induction, and binary
pairing with a carefully audited parameter budget. A weaker fixed
zero-equivalence law also suffices.

The one-term schema itself and the reconstruction term are credited to the
existing drafts. The result does not settle the schema without the added
equation and does not establish absolute minimality.

Contents
--------
pra_one_term_shift.pdf       Complete report and proofs.
pra_one_term_shift.tex       Self-contained LaTeX source.
axioms.txt                  Exact standalone specification.
build.sh                    Three-pass PDF build.
source_audit.json            Pinned GitHub sources and verified hashes.
VERIFICATION.txt            Verification scope and outcome.
artifacts/check_kernel.py   Binary PR interpreter and finite checks.
artifacts/verification.json Results, bounds, and syntax audit.
SHA256SUMS                  SHA-256 hashes of deliverable members.

Rebuild the report
------------------
Install a TeX Live distribution with pdflatex and the standard packages
listed at the start of pra_one_term_shift.tex, then run:

  sh build.sh

Reproduce the computational checks
---------------------------------
Requires Python 3.10 or later; uses only the standard library:

  python3 artifacts/check_kernel.py

The default writes artifacts/verification.json. Elapsed time can differ;
the fixed test seed, bounds, descriptions, and check counts are recorded.
These are finite numerical checks and a grammar audit. They are not a
machine-checked proof of an infinite schema or equivalence of theories.

Source snapshot
---------------
VladimirReshetnikov/ProveIt
Commit: 487040529a8792ae3239ae75e695424aee3d665c
Five PRA archives in docs/drafts were read; docs/incoming listing and
README were also inspected. Exact provenance is in source_audit.json.
