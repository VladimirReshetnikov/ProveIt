#!/usr/bin/env python3
"""Finite checks for the binary, one-parameter PRA construction.

This is NOT a formal proof of PRA, X1, an induction schema, or equivalence
of theories.  It is a small, independently implemented interpreter for
binary primitive-recursion descriptions, a syntactic dependency audit,
and reproducible finite checks of the terms used in the manuscript.

Only the Python standard library is required.  Run this file directly;
the default report is verification.json beside it.  Every recursor has
base g(a), step h(n,v,a), and two numerical arguments.  In particular,
M(n,a) means max(a-n,0), not max(n-a,0).
"""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import random
import time


@dataclass(frozen=True)
class Term:
    kind: str
    args: tuple[Term, ...] = ()
    name: str = ""


ZERO = Term("zero")


def var(name: str) -> Term:
    return Term("var", name=name)


def succ(term: Term) -> Term:
    return Term("succ", (term,))


def call(name: str, first: Term, second: Term) -> Term:
    return Term("call", (first, second), name)


ONE = succ(ZERO)
N, A, V = var("n"), var("a"), var("v")


def validate(term: Term, known: set[str]) -> set[str]:
    """Validate arities/references and return exactly the free variables."""
    if term.kind == "zero":
        if term.args or term.name:
            raise ValueError("Malformed zero term")
        return set()
    if term.kind == "var":
        if term.args or not term.name:
            raise ValueError("Malformed variable")
        return {term.name}
    if term.kind == "succ":
        if len(term.args) != 1 or term.name:
            raise ValueError("Successor must be unary")
    elif term.kind == "call":
        if len(term.args) != 2:
            raise ValueError("Every declared function must be binary")
        if term.name not in known:
            raise ValueError(f"Unknown, future, or self reference: {term.name}")
    else:
        raise ValueError(f"Unknown term constructor: {term.kind}")
    result: set[str] = set()
    for argument in term.args:
        result.update(validate(argument, known))
    return result


def references(term: Term) -> set[str]:
    answer = {term.name} if term.kind == "call" else set()
    for argument in term.args:
        answer.update(references(argument))
    return answer


def show(term: Term) -> str:
    if term.kind == "zero":
        return "0"
    if term.kind == "var":
        return term.name
    if term.kind == "succ":
        return f"S({show(term.args[0])})"
    return f"{term.name}({show(term.args[0])},{show(term.args[1])})"


@dataclass(frozen=True)
class Definition:
    name: str
    base: Term
    step: Term


class Program:
    """Total interpreter, with no self references in declaration bodies.

    A cached column stores F(0,a), F(1,a), ... for a fixed parameter a.
    Extending it performs precisely the declared recursion.  Evaluation of
    its step can call only previously admitted symbols, so there is no
    dependence on Python's recursion depth for the numerical recursion.
    """

    def __init__(self) -> None:
        self.definitions: dict[str, Definition] = {}
        self.columns: dict[tuple[str, int], list[int]] = {}
        self.computed_cells = 0

    def admit(self, name: str, base: Term, step: Term) -> None:
        if name in self.definitions:
            raise ValueError(f"Duplicate declaration: {name}")
        known = set(self.definitions)
        base_free = validate(base, known)
        step_free = validate(step, known)
        if not base_free <= {"a"}:
            raise ValueError(f"Base has illegal free variables: {base_free}")
        if not step_free <= {"n", "v", "a"}:
            raise ValueError(f"Step has illegal free variables: {step_free}")
        self.definitions[name] = Definition(name, base, step)

    def evaluate(self, term: Term, environment: dict[str, int]) -> int:
        if term.kind == "zero":
            return 0
        if term.kind == "var":
            return environment[term.name]
        if term.kind == "succ":
            return self.evaluate(term.args[0], environment) + 1
        if term.kind != "call":
            raise ValueError(f"Invalid evaluated term: {term.kind}")
        first = self.evaluate(term.args[0], environment)
        second = self.evaluate(term.args[1], environment)
        return self.run(term.name, first, second)

    def run(self, name: str, n: int, a: int) -> int:
        if not isinstance(n, int) or not isinstance(a, int) or n < 0 or a < 0:
            raise ValueError("The interpreter domain is the natural numbers")
        declaration = self.definitions[name]
        key = name, a
        if key not in self.columns:
            self.columns[key] = [self.evaluate(declaration.base, {"a": a})]
            self.computed_cells += 1
        column = self.columns[key]
        while len(column) <= n:
            index = len(column) - 1
            value = self.evaluate(
                declaration.step, {"n": index, "v": column[-1], "a": a}
            )
            column.append(value)
            self.computed_cells += 1
        return column[n]


def pred(x: Term) -> Term:
    return call("p", x, ZERO)


def monus(first: Term, second: Term) -> Term:
    """The displayed order is M(first,second)=second minus first."""
    return call("M", first, second)


def add(x: Term, y: Term) -> Term:
    return call("add", x, y)


def gate(x: Term, value: Term) -> Term:
    return call("gate", x, value)


def select(test: Term, if_zero: Term, if_nonzero: Term) -> Term:
    """A term macro, never a ternary function symbol."""
    return add(gate(test, if_zero), gate(gate(test, ONE), if_nonzero))


def zero_test(x: Term) -> Term:
    return gate(x, ONE)


def delta(x: Term, y: Term) -> Term:
    return select(monus(x, y), monus(y, x), ONE)


def triangular(x: Term) -> Term:
    return call("T", x, ZERO)


def rank(x: Term) -> Term:
    return call("q", x, ZERO)


def pair(x: Term, y: Term) -> Term:
    return add(triangular(add(x, y)), y)


def right(x: Term) -> Term:
    return monus(triangular(rank(x)), x)


def left(x: Term) -> Term:
    return monus(right(x), rank(x))


def make_program() -> Program:
    program = Program()
    program.admit("p", ZERO, N)
    program.admit("M", A, pred(V))
    program.admit("add", A, succ(V))
    program.admit("gate", A, ZERO)
    program.admit("T", ZERO, add(V, succ(N)))
    program.admit(
        "q", ZERO,
        select(delta(succ(N), triangular(succ(V))), succ(V), V),
    )
    return program


# Formula syntax is separate from arithmetic-term syntax.  The compiler
# produces only a term; it does not introduce a predicate/function oracle.
Formula = tuple


def compile_formula(formula: Formula) -> Term:
    operator = formula[0]
    if operator == "eq":
        return delta(formula[1], formula[2])
    if operator == "true":
        return ZERO
    if operator == "false":
        return ONE
    first = compile_formula(formula[1])
    if operator == "not":
        return zero_test(first)
    second = compile_formula(formula[2])
    if operator == "and":
        return select(first, second, ONE)
    if operator == "or":
        return select(first, ZERO, second)
    if operator == "imp":
        return select(first, second, ZERO)
    raise ValueError(f"Unknown formula operator: {operator}")


def formula_value(formula: Formula, program: Program, env: dict[str, int]) -> bool:
    operator = formula[0]
    if operator == "eq":
        return program.evaluate(formula[1], env) == program.evaluate(formula[2], env)
    if operator == "true":
        return True
    if operator == "false":
        return False
    first = formula_value(formula[1], program, env)
    if operator == "not":
        return not first
    second = formula_value(formula[2], program, env)
    if operator == "and":
        return first and second
    if operator == "or":
        return first or second
    if operator == "imp":
        return (not first) or second
    raise ValueError(f"Unknown formula operator: {operator}")


def random_formula(rng: random.Random, depth: int, atoms: list[Formula]) -> Formula:
    if depth == 0 or rng.randrange(5) == 0:
        return rng.choice(atoms)
    operator = rng.choice(("not", "and", "or", "imp"))
    first = random_formula(rng, depth - 1, atoms)
    if operator == "not":
        return operator, first
    return operator, first, random_formula(rng, depth - 1, atoms)


def run_checks() -> dict:
    started = time.perf_counter()
    program = make_program()
    counts: Counter[str] = Counter()

    def check(group: str, condition: bool, detail: object = None) -> None:
        if not condition:
            raise AssertionError(f"{group}: {detail!r}")
        counts[group] += 1

    # Rejection tests establish that the advertised restrictions are checked,
    # rather than merely observed by the examples.
    invalid = [
        ("base_free_variable", var("x"), ZERO),
        ("base_uses_n", N, ZERO),
        ("step_uses_x", ZERO, var("x")),
        ("self_reference", ZERO, call("bad", V, A)),
        ("future_reference", call("future", ZERO, A), ZERO),
        ("unary_function_call", ZERO, Term("call", (V,), "p")),
        ("ternary_function_call", ZERO, Term("call", (N, V, A), "p")),
        ("binary_successor", ZERO, Term("succ", (N, V))),
    ]
    rejected: list[str] = []
    for label, base, step in invalid:
        try:
            program.admit("bad", base, step)
        except ValueError:
            rejected.append(label)
            counts["invalid_descriptions_rejected"] += 1
        else:
            raise AssertionError(f"Invalid description accepted: {label}")

    # All descriptions are evaluated through the same interpreter, including
    # q: no host-language shortcut is used for the compared term values.
    for definition in program.definitions.values():
        for parameter in range(4):
            check("recursion_base", program.run(definition.name, 0, parameter) ==
                  program.evaluate(definition.base, {"a": parameter}))
            for n in range(13):
                prior = program.run(definition.name, n, parameter)
                check("recursion_step", program.run(definition.name, n + 1, parameter) ==
                      program.evaluate(definition.step, {"n": n, "v": prior, "a": parameter}))

    for n in range(25):
        check("predecessor", program.run("p", n, 0) == max(n - 1, 0))
        check("coverage", n == 0 or n == program.run("p", n, 0) + 1)
        for a in range(25):
            check("monus_orientation", program.run("M", n, a) == max(a - n, 0))
            check("addition", program.run("add", n, a) == n + a)
            check("gate", program.run("gate", n, a) == (a if n == 0 else 0))
            check("shift_equation", program.run("M", n + 1, a + 1) == program.run("M", n, a))
            check("zero_shift_equivalence", (program.run("M", n + 1, a + 1) == 0) ==
                  (program.run("M", n, a) == 0))

    test, yes, no = var("test"), var("yes"), var("no")
    selector = select(test, yes, no)
    validate(selector, set(program.definitions))
    for t in range(7):
        for u in range(7):
            for v in range(7):
                value = program.evaluate(selector, {"test": t, "yes": u, "no": v})
                check("selector_macro", value == (u if t == 0 else v), (t, u, v))

    reconstruction = select(monus(A, N), monus(monus(N, A), A), N)
    comparator = delta(N, A)
    for n in range(33):
        check("diagonal", program.run("M", n, n) == 0)
        neighbor = program.run("M", n, n + 1)
        check("neighbor_nonzero", neighbor != 0)
        check("neighbor_zero_test", program.run("gate", neighbor, 1) == 0)
        for a in range(33):
            env = {"n": n, "a": a}
            check("reconstruction", program.evaluate(reconstruction, env) == n, (n, a))
            check("equality_reflection", (program.evaluate(comparator, env) == 0) == (n == a), (n, a))

    # Local transport to h(n)=n.  The exceptional zero index must use the
    # zero-induction base.  This test deliberately records the counterexample
    # to the tempting but invalid unconditional equivalence h(n)=n iff t=0.
    transport = select(test, N, ZERO)
    for n in range(13):
        for t in range(13):
            h = program.evaluate(transport, {"n": n, "test": t})
            if n > 0:
                check("zero_transport_positive_index", (h == n) == (t == 0), (n, t))
            else:
                check("zero_transport_zero_index", h == 0, t)
    for n in range(7):
        for t in range(5):
            for next_t in range(5):
                base_case_allowed = n != 0 or t == 0
                zero_step_allowed = t != 0 or next_t == 0
                h = program.evaluate(transport, {"n": n, "test": t})
                if base_case_allowed and zero_step_allowed and h == n:
                    next_h = program.evaluate(transport, {"n": n + 1, "test": next_t})
                    check("zero_transport_local_step", next_h == n + 1, (n, t, next_t))
    zero_exception = {
        "n": 0, "test_value": 1,
        "h_value": program.evaluate(transport, {"n": 0, "test": 1}),
        "h_equals_n": True, "test_equals_zero": False,
        "conclusion": "The induction base is essential at n=0.",
    }

    terms = [ZERO, ONE, N, A, succ(N), pred(N), monus(N, A), add(N, A)]
    atoms = [("eq", t, u) for t in terms for u in terms]
    atoms += [("true",), ("false",)]
    rng = random.Random(20261031)
    formulas = atoms + [random_formula(rng, 3, atoms) for _ in range(120)]
    for formula in formulas:
        compiled = compile_formula(formula)
        free = validate(compiled, set(program.definitions))
        check("compiler_free_variables", free <= {"n", "a"})
        moving_target = select(compiled, N, ZERO)
        check("transport_free_variables", validate(moving_target, set(program.definitions)) <= {"n", "a"})
        for n in range(5):
            for a in range(5):
                env = {"n": n, "a": a}
                check("formula_compiler", (program.evaluate(compiled, env) == 0) ==
                      formula_value(formula, program, env), (formula[0], n, a))

    # Exhaustive local zero/nonzero truth tables include non-Boolean error
    # values: the compiler is not relying on an unproved 0/1 range invariant.
    for u in range(5):
        for v in range(5):
            env = {"n": u, "a": v}
            encodings = [
                (select(N, A, ONE), u == 0 and v == 0),
                (select(N, ZERO, A), u == 0 or v == 0),
                (select(N, A, ZERO), u != 0 or v == 0),
            ]
            for encoded, expected in encodings:
                check("nonboolean_connective_values", (program.evaluate(encoded, env) == 0) == expected)

    for k in range(25):
        t = program.run("T", k, 0)
        check("triangular_numbers", t == k * (k + 1) // 2)
        check("triangular_boundary", program.run("q", t, 0) == k)
        for i in range(k + 1):
            check("triangular_intervals", program.run("q", t + i, 0) == k, (k, i))
    for n in range(325):
        k = program.run("q", n, 0)
        check("rank_bounds", k * (k + 1) // 2 <= n < (k + 1) * (k + 2) // 2, n)
    paired = pair(N, A)
    paired_left, paired_right = left(paired), right(paired)
    for x in range(12):
        for y in range(12):
            env = {"n": x, "a": y}
            encoded = program.evaluate(paired, env)
            expected = (x + y) * (x + y + 1) // 2 + y
            check("pair_formula", encoded == expected, (x, y))
            check("left_retraction", program.evaluate(paired_left, env) == x, (x, y))
            check("right_retraction", program.evaluate(paired_right, env) == y, (x, y))

    declarations = []
    available: set[str] = set()
    for definition in program.definitions.values():
        declarations.append({
            "name": definition.name,
            "arity": 2,
            "base": show(definition.base),
            "step": show(definition.step),
            "base_free_variables": sorted(validate(definition.base, available)),
            "step_free_variables": sorted(validate(definition.step, available)),
            "earlier_dependencies": sorted(references(definition.base) | references(definition.step)),
        })
        available.add(definition.name)

    return {
        "status": "all checks passed",
        "scope": "Finite numerical checks and a syntactic audit, NOT a formal proof of an infinite schema or theory equivalence.",
        "interpreter": {
            "domain": "standard natural numbers",
            "recursion_order": "F(0,a)=g(a); F(Sn,a)=h(n,F(n,a),a)",
            "monus_orientation": "M(n,a)=max(a-n,0)",
            "all_declared_function_symbols_binary": True,
            "selector_is_a_term_macro": True,
            "computed_recursion_cells": program.computed_cells,
        },
        "declarations": declarations,
        "rejected_invalid_description_kinds": rejected,
        "test_bounds": {
            "recursion_equations": {"n": [0, 12], "a": [0, 3]},
            "basic_functions_and_bridges": {"n": [0, 24], "a": [0, 24]},
            "selector_arguments": [0, 6],
            "reconstruction_and_comparison": [0, 32],
            "zero_transport_n_and_test": [0, 12],
            "formula_count": len(formulas),
            "formula_assignments_n_and_a": [0, 4],
            "random_formula_seed": 20261031,
            "random_formula_maximum_depth": 3,
            "triangular_index_k": [0, 24],
            "rank_argument": [0, 324],
            "pair_arguments": [0, 11],
        },
        "zero_transport_exception": zero_exception,
        "check_counts": dict(sorted(counts.items())),
        "total_checks": sum(counts.values()),
        "elapsed_seconds": round(time.perf_counter() - started, 6),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, default=Path(__file__).with_name("verification.json"))
    args = parser.parse_args()
    report = run_checks()
    report["script_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(f"PASS: {report['total_checks']} finite checks; {report['elapsed_seconds']:.3f} seconds")
    print(f"Report: {args.report.resolve()}")
    print("Scope: numerical checks and syntax audit, not a formal proof of PRA.")


if __name__ == "__main__":
    main()
