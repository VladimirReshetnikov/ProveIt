"""Validate the one-coordinate kernels against independent named-binder oracles.

This driver is outside the trusted acceptance boundary.  It imports only
local frozen reference code and the Python standard library.  Run from any
directory with `python3 validate.py`; results are written beside this file.
"""
from collections import Counter
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import random
import subprocess
import sys
import tempfile
import types

ROOT = Path(__file__).resolve().parent
SUPPORT = ROOT / 'validation'
sys.path.insert(0, str(SUPPORT))
import named_main
import named_scalar
from mutation_support import mutate
from source_measure import metrics


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def packet_digest(packet):
    return hashlib.sha256(json.dumps(packet, sort_keys=True,
                                    separators=(',', ':')).encode()).hexdigest()


def run(module, packet):
    module.k = 0
    stream = deepcopy(packet)
    try:
        module.take = stream.pop
        accepted = bool(module.check(stream.pop(), []))
        error = None
    except Exception as exception:
        accepted, error = False, type(exception).__name__
    return {'accepted': accepted, 'final_k': module.k,
            'remaining': len(stream) if type(stream) is list else None,
            'error': error}


def oracle_run(oracle, packet):
    try:
        return oracle.Oracle().run(deepcopy(packet))
    except (AttributeError, TypeError):
        return {'accepted': False, 'final_k': 0, 'remaining': None}


def encode_formula(value):
    """Q becomes ternary with repeated-body annotations; D becomes unary."""
    if type(value) is not list:
        return deepcopy(value)
    if len(value) == 1:
        body = encode_formula(value[0])
        return [body, deepcopy(body), deepcopy(body)]
    if len(value) == 3:
        return [encode_formula(value[0])]
    return deepcopy(value)


def decode_formula(value):
    """Inverse on canonical syntax; old D annotations become zero equations."""
    if type(value) is not list:
        return deepcopy(value)
    if len(value) == 1:
        return [decode_formula(value[0]), [0, 0], [0, 0]]
    if len(value) == 3:
        return [decode_formula(value[0])]
    return deepcopy(value)


def change_packet(packet, change_formula):
    if type(packet) is not list:
        return deepcopy(packet)
    result = []
    for cell in packet[:-1]:
        if type(cell) is list and len(cell) == 2:
            major, annotation = cell
            if type(major) is list and len(major) == 2:
                annotation = change_formula(annotation)
            result.append([change_formula(major), deepcopy(annotation)])
        else:
            result.append(deepcopy(cell))
    if packet:
        result.append(change_formula(packet[-1]))
    return result


def opening_cases(module, reference, oracle, encode):
    """Exhaustive fixed corpus over sorts, scopes, aliases and zero/one images."""
    atoms = [-3, -2, -1, 0, 1, 2, 3, 4, 5, 6, True, None, {}]
    terms = [*atoms, [], [0], [1], [5], [0, 0], [0, 0, 1], [0, 0, 3],
             [0, 0, 2], [1, 0, [0, 3, 5]], [0, 0, [0, 1, 5]]]
    formulas = [[t, 0] for t in terms]
    formulas += [[[t, 0]] for t in (-2, 0, 1, 2, 3, 4, 5)]
    formulas += [[[t, 0], [1, 2], [3, 4]] for t in (-2, 0, 1, 2, 3, 4, 5, 6)]
    formulas += [[], None, {}, [True], [[0, 0], [5, 5], [0, 0]],
                 [[[5, 1]], [[3, 4]], [[1, 2]]],
                 [[[[0, 0, 9], 5]], [0, 0], [0, 0]]]
    environments = [(), (0,), (-1,), (-3,), (1,), ([0],), ([0, 0, 3],),
                    ([0, 0, 5],), (None,), (True,), ({},)]
    counts = Counter()
    for formula, values in ((True, formulas), (False, terms)):
        for original in values:
            value = encode(original) if formula else original
            for depth in (0, 1, 2):
                for lower in (0, -2):
                    for images in environments:
                        module.k = reference.k = lower
                        d = 2 * depth + (not formula)
                        def invoke(call):
                            try:
                                return True, call()
                            except Exception:
                                return False, None
                        actual = invoke(lambda: module.inst(deepcopy(value),
                                                             *deepcopy(images), d=d))
                        prior = invoke(lambda: reference.inst(deepcopy(value),
                                                              *deepcopy(images), d=d))
                        named = invoke(lambda: oracle.opening(deepcopy(value),
                                                              deepcopy(images),
                                                              formula=formula,
                                                              depth=depth, lower=lower))
                        require(actual == prior == named,
                                ('opening', value, images, d, lower, actual, prior, named))
                        counts['valid' if actual[0] else 'invalid'] += 1
    return dict(counts)


def extra_main_cases():
    body = [[0, 1, 0], 1]
    alias_body = [[0, 2, 0], 2]
    outer_body = [[0, 3, 0], 3]
    rows = [
        ('direct_Q_introduction', [[], [None], [body, body, body]], True),
        ('direct_Q_alias_introduction', [[], [None], [alias_body] * 3], True),
        ('Q_noncanonical_valid_annotations',
         [[], [None], [body, [0, 0], [0, 0]]], True),
        ('D_unused_nonterm_witness', [[], [{}], [body]], True),
        ('D_outer_witness', [[0], [outer_body]], True),
        ('D_outer_alias_witness', [[0], [[[0, 4, 0], 4]]], True),
        ('D_capturing_witness', [[1], [outer_body]], False),
        ('Q_unbound_coordinate_in_annotation',
         [[], [None], [body, [3, 0], body]], False),
        ('Q_future_parameter_in_annotation',
         [[], [None], [body, [-1, 0], body]], False),
        ('Q_numerical_annotation', [[], [None], [body, 0, body]], False),
        ('Q_unchecked_second_annotation', [[], [None], [body, body, None]], False),
        ('equation_cannot_use_introduction', [[0], [0, 0]], False),
        ('successor_equation_cannot_use_introduction', [[0], [[0], [0]]], False),
        ('scalar_successor_computation',
         [[], [[[0], 0, [1]], [[0, 0, [1]]]]], True),
        ('second_exposed_coordinate',
         [[], [], [[[0, 0, 1], 0], [3, 0]], [0, 0]], False),
        ('unbound_root_initializer', [[], [[0, 1, 1], 1]], False),
    ]
    return [dict(name=name, packet=packet, expected=expected)
            for name, packet, expected in rows]


def mutate_program(source, old, new, name):
    require(source.count(old) == 1, ('mutation anchor', name))
    module = types.ModuleType('deliberate_' + name)
    # The executed source is this inspected local checker, never a certificate.
    exec(compile(source.replace(old, new), name, 'exec'), module.__dict__)
    return module


def cli(path, row, folder):
    packet_file = folder / 'certificate.json'
    packet_file.write_text(json.dumps(row['packet']) + '\n')
    for optimized in (False, True):
        result = subprocess.run([sys.executable, *(['-O'] if optimized else []),
                                 str(path), str(packet_file)], capture_output=True,
                                text=True, timeout=15)
        expected = (0, 'ACCEPT', '') if row['expected'] else (1, 'REJECT', '')
        require((result.returncode, result.stdout.strip(), result.stderr) == expected,
                ('CLI', path.name, row['name'], optimized, result.stdout, result.stderr))


def main():
    provenance = json.loads((SUPPORT / 'provenance.json').read_text())
    for row in provenance['copied_support']:
        require(digest(ROOT / row['file']) == row['sha256'], ('changed support', row['file']))
    source_cases = json.loads((SUPPORT / 'scalar_cases.json').read_text())
    transported = [dict(name=r['name'], packet=change_packet(r['packet'], encode_formula),
                        expected=r['expected']) for r in source_cases]
    # This is a genuine inverse on the entire inherited fixed packet cohort.
    for source, target in zip(source_cases, transported):
        require(change_packet(target['packet'], decode_formula) == source['packet'],
                ('canonical codec round trip', source['name']))
    special = extra_main_cases()
    (SUPPORT / 'main_cases.json').write_text(json.dumps(transported + special, indent=2) + '\n')
    summaries = []
    for name, reference_name, oracle, rows, encode in (
            ('checker_compatible.py', 'reference_scalar.py', named_scalar,
             source_cases, lambda x: x),
            ('checker.py', 'reference_combined.py', named_main,
             transported + special, encode_formula)):
        path = ROOT / name
        candidate = load(path, 'candidate_' + path.stem)
        reference = load(SUPPORT / reference_name, 'reference_' + path.stem)
        openings = opening_cases(candidate, reference, oracle, encode)
        fixed = []
        with tempfile.TemporaryDirectory(prefix='one_coordinate_cli_') as temporary:
            for row in rows:
                actual, previous, named = (run(candidate, row['packet']),
                                          run(reference, row['packet']),
                                          oracle_run(oracle, row['packet']))
                for key in ('accepted', 'remaining', 'final_k'):
                    require(actual[key] == previous[key], ('reference', row['name'], key))
                require(actual['accepted'] == named['accepted'] == row['expected'],
                        ('named oracle', row['name'], actual, named))
                if actual['accepted']:
                    for key in ('remaining', 'final_k'):
                        require(actual[key] == named[key], ('named trace', row['name'], key))
                cli(path, row, Path(temporary))
                fixed.append(dict(name=row['name'], expected=row['expected'],
                                  packet_sha256=packet_digest(row['packet']), actual=actual))
        rng = random.Random(20261107)
        mutated = []
        for index in range(1200):
            row = rows[index % len(rows)]
            packet = mutate(row['packet'], rng)
            actual, previous, named = (run(candidate, packet), run(reference, packet),
                                       oracle_run(oracle, packet))
            for key in ('accepted', 'remaining', 'final_k'):
                require(actual[key] == previous[key], ('mutation reference', index, key))
            require(actual['accepted'] == named['accepted'],
                    ('mutation named oracle', index, actual, named))
            mutated.append({'parent': row['name'], 'sha256': packet_digest(packet),
                            'accepted': actual['accepted']})
        by_name = {r['name']: r for r in rows}
        changes = [
            ('capture_image_at_contextual_depth', 'inst(t, d=1)', 'inst(t, d=d)',
             'scalar_contextual_capture', True, 'false conclusion accepted'),
            ('restore_nonexistent_counter_binder', "b'\\0\\0\\2'", "b'\\0\\0\\4'",
             'nonexistent_counter_slot', True, 'malformed scalar update accepted'),
            ('remove_goal_validation', 'if inst(a) in g:', 'if a in g:',
             'false_eigenparameter_escape', True, 'escaping eigenparameter accepted'),
            ('allow_compound_induction', 'h = [b, inst(b, 0)][len(b) % 2:]',
             'h = [b, inst(b, 0)]', 'compound_induction_hypothesis', True,
             'impermissible induction certificate accepted'),
            ('remove_retained_base_for_atoms', 'h = [b, inst(b, 0)][len(b) % 2:]',
             'h = [b] if len(b) == 2 else [inst(b, 0)]', 'retained_base_separation',
             False, 'valid retained-base certificate rejected'),
        ]
        if name == 'checker.py':
            changes += [
                ('erase_one_coordinate_bound', 'and k <= a < d + 2:', 'and k <= a:',
                 'second_exposed_coordinate', True, 'second unbound coordinate silently identified'),
                ('replace_missing_image_by_zero', 'def inst(a, t=None, d=0):',
                 'def inst(a, t=0, d=0):', 'unbound_root_initializer', True,
                 'open root formula admitted as a closed certificate'),
                ('ignore_Q_annotations', "b'\\2\\2\\2'", "b'\\2'",
                 'Q_unchecked_second_annotation', True, 'malformed inert annotation accepted'),
            ]
        controls = []
        source = path.read_text()
        for label, old, new, case, expected, explanation in changes:
            changed = mutate_program(source, old, new, label)
            actual = run(changed, by_name[case]['packet'])['accepted']
            require(actual == expected, ('program mutation', name, label, actual))
            controls.append(dict(mutation=label, case=case,
                                 original_accepts=by_name[case]['expected'],
                                 mutated_accepts=actual, meaning=explanation))
        summaries.append({
            'checker': name, 'metrics': metrics(path), 'reference': reference_name,
            'reference_sha256': digest(SUPPORT / reference_name),
            'oracle_sha256': digest(Path(oracle.__file__)),
            'opening_cases': openings, 'opening_case_count': sum(openings.values()),
            'fixed_packets': len(rows), 'positive_fixed': sum(r['expected'] for r in rows),
            'negative_fixed': sum(not r['expected'] for r in rows),
            'cli_executions': 2 * len(rows), 'packet_mutations': len(mutated),
            'distinct_packet_mutations': len({r['sha256'] for r in mutated}),
            'program_mutation_controls': controls, 'fixed_case_receipts': fixed,
            'packet_mutation_receipts': mutated,
        })
    result = {'status': 'PASS', 'python': platform.python_version(),
              'source_commit': provenance['commit'],
              'canonical_codec_round_trips': len(source_cases),
              'candidates': summaries,
              'limits': 'Finite implementation evidence; mathematical equivalence is a written proof, '
                        'not a Lean or Rocq verification of Python.'}
    (ROOT / 'validation_results.json').write_text(json.dumps(result, indent=2) + '\n')
    concise = dict(result)
    concise['candidates'] = [{k: v for k, v in row.items()
                             if k not in ('fixed_case_receipts', 'packet_mutation_receipts')}
                            for row in summaries]
    (ROOT / 'validation_summary.json').write_text(json.dumps(concise, indent=2) + '\n')
    print(json.dumps(concise, indent=2))


if __name__ == '__main__':
    main()
