"""Frozen generic JSON-tree mutation function; outside the trusted kernel."""
from copy import deepcopy

def mutate(packet, rng):
    result = deepcopy(packet)
    paths = []
    def visit(x, p):
        paths.append(p)
        if type(x) is list:
            for i, y in enumerate(x): visit(y, p + [i])
    visit(result, [])
    path = rng.choice(paths)
    changes = [None, True, False, 0.0, -999, 5, [], [0], [0, 0], [0, 0, 0, 0]]
    replacement = deepcopy(rng.choice(changes))
    if not path:
        return replacement
    target = result
    for i in path[:-1]: target = target[i]
    target[path[-1]] = replacement
    return result

