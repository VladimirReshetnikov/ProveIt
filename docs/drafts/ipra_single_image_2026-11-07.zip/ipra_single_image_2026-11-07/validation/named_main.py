"""Independent named-binder oracle for the one-coordinate main serialization.

No packed sort/depth field, constructor-width table, Python match statement,
or production substitution helper is used. Bound-variable alias spelling is
retained, because the proof calculus compares raw trees literally. This is
untrusted test support, never imported by the acceptance program.

Adaptation for scalar iteration: recursor updates bind only previous; the
unused counter-name field in the named record is inert metadata.

Named-binder technique adapted from the inspected paired-coordinate draft's
validation/reference/named_oracle.py. This variant swaps Q/D serialization and admits the derived direct Q-introduction
rule. It validates every annotation and never calls the production opener.
"""
from copy import deepcopy


class Syntax:
    def __init__(self, lower):
        self.lower = lower
        self.serial = 0

    def fresh(self):
        self.serial += 1
        return self.serial

    def term(self, value, bound=(), holes=0):
        if type(value) is int:
            if value <= 0:
                if value < self.lower:
                    raise ValueError('undeclared numerical parameter')
                return ('constant', value)
            slot = (value + 1) // 2
            if slot <= len(bound):
                return ('variable', bound[slot - 1], 1 - value % 2)
            slot -= len(bound) + 1
            if slot < holes:
                return ('hole', slot)
            raise ValueError('unbound positive coordinate')
        if type(value) is not list:
            raise ValueError('term must be an integer or list')
        if len(value) == 1:
            return ('successor', self.term(value[0], bound, holes))
        if len(value) == 3:
            previous, counter = self.fresh(), self.fresh()
            return ('recursor', self.term(value[0], bound, holes),
                    self.term(value[1], bound, holes), previous, counter,
                    self.term(value[2], (previous,) + bound, holes))
        raise ValueError('invalid term arity')

    def formula(self, value, bound=(), holes=0):
        if type(value) is not list:
            raise ValueError('formula must be a list')
        if len(value) == 2:
            return ('equal', self.term(value[0], bound, holes),
                    self.term(value[1], bound, holes))
        if len(value) == 3:
            variable = self.fresh()
            return ('closure', variable,
                    *(self.formula(v, (variable,) + bound, holes) for v in value))
        if len(value) == 1:
            first, second = self.fresh(), self.fresh()
            return ('exists_closure', first, second,
                    self.formula(value[0], (second, first) + bound, holes))
        raise ValueError('invalid formula arity')

    def term_data(self, tree, bound=()):
        tag = tree[0]
        if tag == 'constant':
            return tree[1]
        if tag == 'variable':
            return 2 * bound.index(tree[1]) + 1 + tree[2]
        if tag == 'successor':
            return [self.term_data(tree[1], bound)]
        if tag == 'recursor':
            _, counter, initial, previous_name, counter_name, step = tree
            return [self.term_data(counter, bound), self.term_data(initial, bound),
                    self.term_data(step, (previous_name,) + bound)]
        raise ValueError('unsubstituted hole')

    def formula_data(self, tree, bound=()):
        tag = tree[0]
        if tag == 'equal':
            return [self.term_data(tree[1], bound), self.term_data(tree[2], bound)]
        if tag == 'closure':
            return [self.formula_data(t, (tree[1],) + bound) for t in tree[2:]]
        if tag == 'exists_closure':
            return [self.formula_data(t, (tree[2], tree[1]) + bound) for t in tree[3:]]
        raise ValueError('invalid formula tree')


def children(tree):
    tag = tree[0]
    if tag in ('constant', 'variable', 'hole'):
        return ()
    if tag == 'successor':
        return (tree[1],)
    if tag == 'recursor':
        return (tree[1], tree[2], tree[5])
    if tag == 'equal':
        return tree[1:]
    if tag == 'exists_closure':
        return tree[3:]
    return tree[2:]


def holes_in(tree):
    if tree[0] == 'hole':
        return {tree[1]}
    return set().union(*(holes_in(t) for t in children(tree)))


def names_in(tree):
    if tree[0] == 'constant' and tree[1] < 0:
        return {tree[1]}
    return set().union(*(names_in(t) for t in children(tree)))


def replace_holes(tree, replacements):
    tag = tree[0]
    if tag == 'hole':
        return replacements[tree[1]]
    if tag in ('constant', 'variable'):
        return tree
    if tag == 'successor':
        return (tag, replace_holes(tree[1], replacements))
    if tag == 'recursor':
        return (tag, replace_holes(tree[1], replacements),
                replace_holes(tree[2], replacements), tree[3], tree[4],
                replace_holes(tree[5], replacements))
    if tag == 'equal':
        return (tag, *(replace_holes(t, replacements) for t in tree[1:]))
    if tag == 'exists_closure':
        return (tag, tree[1], tree[2],
                *(replace_holes(t, replacements) for t in tree[3:]))
    return (tag, tree[1], *(replace_holes(t, replacements) for t in tree[2:]))


def opening(value, images=(), *, formula=True, depth=0, lower=0):
    syntax = Syntax(lower)
    # An explicit independent binder context permits checking protected-depth
    # calls of inst as well as its public depth-zero interface.
    bound = tuple(syntax.fresh() for _ in range(depth))
    parse = syntax.formula if formula else syntax.term
    emit = syntax.formula_data if formula else syntax.term_data
    tree = parse(value, bound, len(images))
    replacements = {i: syntax.term(images[i]) for i in sorted(holes_in(tree))}
    return emit(replace_holes(tree, replacements), bound)


class Oracle:
    def __init__(self):
        self.lower = 0
        self.stack = []
        self.allocations = []
        self.rule_counts = {}

    def open(self, value, images=(), formula=True):
        return opening(value, images, formula=formula, lower=self.lower)

    def rule(self, name):
        self.rule_counts[name] = self.rule_counts.get(name, 0) + 1

    def fresh(self, relevant):
        syntax = Syntax(self.lower)
        names = set().union(*(names_in(syntax.formula(a)) for a in relevant))
        self.lower -= 1
        if self.lower in names or any(self.lower >= n for n in names):
            raise AssertionError('oracle eigenparameter is not fresh')
        self.allocations.append({'eigenparameter': self.lower,
                                 'relevant_names': sorted(names)})
        return self.lower

    def check(self, goal, context):
        self.open(goal)
        if goal in context:
            self.rule('hypothesis')
            return True
        instruction = self.stack.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            if not self.check(major, context):
                return False
            if len(major) == 1:
                self.rule('fused_elimination')
                eigen = self.fresh([goal, *context, major])
                witness_assumption = self.open([major[0]] * 3, [eigen])
                return self.check(goal, [*context, witness_assumption])
            if len(major) == 3:
                self.rule('closure_elimination')
                matrix, left, right = major[0], 0, annotation
            else:
                self.rule('equality_transport')
                matrix, (left, right) = annotation, major
            if self.open(matrix, [right]) != goal:
                return False
            return self.check(self.open(matrix, [left]), context)
        if type(instruction) is list and len(instruction) == 1 and len(goal) in (1, 3):
            self.rule('fused_introduction' if len(goal) == 1 else 'derived_closure_introduction')
            body = opening(goal[0], instruction, depth=1, lower=self.lower)
            assumptions = [self.open(body, [0])]
            if len(body) == 2:
                assumptions.append(body)
            eigen = self.fresh([goal, *context])
            conclusion = self.open(body, [[eigen]])
            instantiated = [self.open(a, [eigen]) for a in assumptions]
            return self.check(conclusion, [*context, *instantiated])
        if (type(instruction) is list and instruction == [] and len(goal) == 2
                and type(goal[0]) is list and len(goal[0]) == 3):
            counter, initial, update = goal[0]
            if counter == 0 and type(counter) is int:
                self.rule('recursion_zero')
                expected = initial
            elif type(counter) is list and len(counter) == 1:
                self.rule('recursion_successor')
                previous = counter[0]
                expected = self.open(update, [[previous, initial, update]], False)
            else:
                return False
            return goal[1] == expected
        return False

    def run(self, packet, lower=0):
        self.lower = lower
        self.allocations = []
        self.rule_counts = {}
        self.stack = deepcopy(packet)
        try:
            accepted = bool(self.check(self.stack.pop(), []))
            error = None
        except Exception as exc:
            if isinstance(exc, AssertionError):
                raise
            accepted, error = False, type(exc).__name__
        return {'accepted': accepted, 'remaining': len(self.stack),
                'final_k': self.lower, 'error': error,
                'allocations': self.allocations, 'rules': self.rule_counts}
