SINGLE-IMAGE SUBSTITUTION: A SMALLER COMPLETE PRESENTATION OF iPRA
Prepared for Vladimir Reshetnikov, 7 November 2026
================================================================

START HERE

report.pdf is the full mathematical article. report.tex and sections/*.tex
are all of its editable sources. The appendix prints both complete checkers.

RESULT

The new observation is that every opening operation in the scalar-iteration
calculus supplies at most one numerical replacement. Even a two-variable
logical binder opens its variables separately, with the other variable
protected. Replacing the variadic environment by one checked optional image
removes environment indexing and forwarding from the trusted code.

Complete source, measured under the unchanged inherited normalization:

                                    Tokens     AST nodes     Bytes
Current six-archive envelope            411           425      1207
checker.py                             400           414      1188
checker_compatible.py                   405           416      1199

Both candidates also beat every coordinate of the core-only envelope.
The compatible checker isolates the one-image change and preserves the
original scalar-depth checker's exact packet acceptance. The primary also
uses already established sort-based introduction and Q/D tag choices.

The original scalar protected-depth program was 414 / 425 / 1212.
The isolated new operation saves 9 tokens, 9 AST nodes and 13 bytes.

The corpus is pinned to ProveIt commit:
  b10a56a8f655c607494a3069b31d6679d968797a
  https://github.com/VladimirReshetnikov/ProveIt/tree/b10a56a8f655c607494a3069b31d6679d968797a/docs/drafts

All ten current root proposals and an expanded inventory of 105 distinct
complete checker-like sources at 273 paths are preserved and measured.
The expanded scan over-includes some helpers; the ten root programs are
identified separately. No expanded program lowers the coordinate minima.

MATHEMATICAL CONTENT

The report states all five native inference patterns, two scalar-iteration
computation schemas, and every scope condition. It includes the inherited
proofs of full intuitionistic logic, predecessor, quantifier-free induction,
general primitive recursion and ordinary whole-domain bi-interpretability.
Both interpretation composite isomorphisms are the identity graph x=y.

The arithmetic basis, paired logic and their bi-interpretability are inherited
from the current draft corpus and credited explicitly. The new result is a
smaller trusted substitution operation with a universal equivalence argument.
This is a finite-corpus improvement, not an absolute shortestness theorem or
a newly discovered arithmetic basis. The metatheory is a written proof,
not a completed Lean/Rocq formalization. Finite tests support implementation
claims; they do not prove the metatheorems by enumeration.

QUICK START

Requires Python 3.10+ for the checkers. Exact measurements use CPython 3.12.14.
All Python dependencies are standard-library or included local validation code.

  python3 checker.py examples/zero_computation.json
  python3 checker.py examples/reflexivity_zero.json

Both should print ACCEPT and exit 0. A negative control:

  python3 checker.py examples/false_equation.json

This should print REJECT and exit 1. Positive integer JSON tokens are bound
coordinates, not arithmetic numerals: numeral 1 is [0]. FORMAT.txt gives the
complete syntax, all instructions, aliases, padding and scope conditions.

REPRODUCING THE RESULT OFFLINE

  python3 package.py --verify
  python3 reproduce.py

The first checks every delivered payload file against SHA256SUMS.txt.
The second verifies frozen comparator identities, recomputes all source
measurements and runs the portable independent validation suite. It rewrites
the generated measurement and validation result files. A compact run receipt
is written to results/reproduction.json.

Useful individual commands:

  python3 measure.py
  python3 validate.py
  python3 build.py

The build command compiles report.pdf in three pdfLaTeX passes. It supports
an offline fallback for TeX Live installations whose local format/database
has not yet been generated. A working TeX distribution with the packages in
report.tex is required. No network is used by any reproduction command.

Rebuilding or changing files can change the delivered hashes. After intended
edits, python3 package.py refreshes SHA256SUMS.txt and recreates the ZIP in
the parent directory. Do not interpret a changed rebuilt PDF hash as evidence
that the mathematical or source-code checks failed.

EXECUTED VALIDATION

For each checker: 4,488 opening cases against both a variadic reference and
an independent named-binder oracle, plus 1,200 deterministic packet mutations.
The compatible checker has 62 fixed cases (45 accept / 17 reject) and 124
actual CLI runs. The primary has 78 fixed cases (52 accept / 26 reject) and
156 actual CLI runs. CLI runs cover normal and optimized (-O) Python.
All 13 deliberate broken-program checks detect their intended faults.
The 62 source-cohort certificates also pass exact canonical codec round trips.

The new primary and compatible formats are not bijective on all arbitrary
padded JSON trees. EQUIVALENCE.txt states the precise canonical codec domain
and the stronger all-packet equivalence for the unchanged-format control.
Malformed primary padding is independently checked by its named oracle.

CONTENTS

report.pdf, report.tex, sections/      Complete article and LaTeX sources
checker.py                            Primary 400-token acceptance program
checker_compatible.py                 Isolated 405-token control
FORMAT.txt, EQUIVALENCE.txt            Exact input contract and equivalence proof
comparison/                           Frozen metric, sources and provenance
measure.py, results/                   Full comparison and generated receipts
validate.py, validation/               Independent oracles, references and cases
validation_summary.json               Compact executed validation receipt
validation_results.json               Full validation details
examples/                             Accepting and rejecting certificates
reproduce.py, build.py, package.py      Offline reproduction/build/packaging
ATTRIBUTION.txt                       New/inherited contribution boundary
UPSTREAM_ATTRIBUTION.txt               Preserved scalar-report provenance
LICENSE_SOURCE.txt                    Preserved MIT-0 source license
SHA256SUMS.txt                        Delivery integrity manifest

Further research questions appear in the article. The successor-seeded
scalar-iterator proposal there is explicitly unresolved and is not used
by either checker or by any equivalence claim.
