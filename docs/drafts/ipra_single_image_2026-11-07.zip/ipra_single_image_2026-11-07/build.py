"""Build report.pdf offline, including a fallback for unconfigured TeX Live."""
from pathlib import Path
import os
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def locate(name, env=None):
    found = subprocess.run(['kpsewhich', name], env=env, text=True,
                           capture_output=True)
    return found.stdout.strip() if found.returncode == 0 else ''


def prepare_environment(logs):
    env = os.environ.copy()
    if locate('pdflatex.fmt', env) and locate('article.cls', env):
        return env
    # Some container distributions have TeX source/fonts but no generated
    # filename database or format. Build a private format without installing
    # anything, changing the system, or accessing the network.
    trees = [p for p in (Path('/usr/share/texlive/texmf-dist'),
                        Path('/usr/share/texmf'), Path('/etc/texmf')) if p.is_dir()]
    if not trees:
        raise RuntimeError('Configure a LaTeX distribution with pdflatex before building.')
    private = ROOT / '.tex-build'
    private.mkdir(exist_ok=True)
    env['TEXMF'] = '{' + ','.join(str(p) for p in trees) + '}'
    env['TEXINPUTS'] = '.:' + ':'.join(str(p / 'tex') + '//' for p in trees) + ':'
    # Prefer stable LaTeX to the optional latex-dev tree.
    stable = trees[0] / 'tex/latex'
    if stable.is_dir():
        env['TEXINPUTS'] = '.:' + str(stable) + '//:' + env['TEXINPUTS'][2:]
    env['TEXFORMATS'] = str(private) + ':'
    if not (private / 'pdflatex.fmt').exists():
        run = subprocess.run(['pdftex', '-ini', '-etex', '-interaction=nonstopmode',
                              '-halt-on-error', '-jobname=pdflatex',
                              '-progname=pdflatex', 'pdflatex.ini'],
                             cwd=private, env=env, text=True,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        logs.append(run.stdout)
        if run.returncode:
            raise RuntimeError(run.stdout)
    if not locate('pdftex.map', env):
        maps = []
        for name in ('cm.map', 'cmextra.map', 'symbols.map', 'euler.map',
                     'latxfont.map', 'lm.map'):
            path = locate(name, env)
            if path:
                maps.append(Path(path).read_text())
        (private / 'pdftex.map').write_text('\n'.join(maps))
        env['TEXFONTMAPS'] = str(private) + '//:'
    return env


def main():
    if not shutil.which('pdflatex') or not shutil.which('kpsewhich'):
        raise SystemExit('Install TeX Live or another LaTeX distribution with pdflatex.')
    logs = []
    try:
        env = prepare_environment(logs)
        for _ in range(3):
            run = subprocess.run(['pdflatex', '-interaction=nonstopmode',
                                  '-halt-on-error', 'report.tex'],
                                 cwd=ROOT, env=env, text=True,
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            logs.append(run.stdout)
            if run.returncode:
                raise RuntimeError(run.stdout)
    finally:
        (ROOT / 'results').mkdir(exist_ok=True)
        (ROOT / 'results/build_log.txt').write_text('\n'.join(logs))
    print('Built report.pdf with three LaTeX passes.')


if __name__ == '__main__':
    main()
