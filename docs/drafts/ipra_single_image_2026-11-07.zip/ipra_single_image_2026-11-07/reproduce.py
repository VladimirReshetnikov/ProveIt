"""Recompute measurements and validation; optionally rebuild the article."""
from pathlib import Path
import json
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    if sys.argv[1:] not in ([], ['--pdf']):
        raise SystemExit('Usage: python3 reproduce.py [--pdf]')
    commands = [['measure.py'], ['validate.py']]
    if sys.argv[1:]:
        commands.append(['build.py'])
    runs = []
    for command in commands:
        result = subprocess.run([sys.executable, *command], cwd=ROOT,
                                text=True, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT)
        log_name = 'reproduce_' + Path(command[0]).stem + '.txt'
        (ROOT / 'results' / log_name).write_text(result.stdout)
        runs.append({'command': command, 'exit_status': result.returncode,
                     'log': 'results/' + log_name})
        if result.returncode:
            raise SystemExit(result.stdout)
    receipt = {'status': 'PASS', 'python': platform.python_version(), 'runs': runs}
    (ROOT / 'results/reproduction.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
