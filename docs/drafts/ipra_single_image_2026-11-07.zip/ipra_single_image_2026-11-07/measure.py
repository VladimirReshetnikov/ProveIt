"""Recompute the pinned comparison with the unchanged upstream metric."""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import platform

ROOT = Path(__file__).resolve().parent
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
METRIC_SHA256 = 'f1404184bf9d39d85c4587f30e191785886c85fed0b3fe01f693191ca6f218dc'


def main():
    metric_path = ROOT / 'comparison/source_measure.py'
    if hashlib.sha256(metric_path.read_bytes()).hexdigest() != METRIC_SHA256:
        raise ValueError('The frozen measurement routine has changed.')
    spec = importlib.util.spec_from_file_location('frozen_measure', metric_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    rows, roots = [], []
    for item in manifest['programs']:
        result = module.metrics(ROOT / 'comparison' / item['local_file'])
        if result['sha256'] != item['sha256']:
            raise ValueError('Comparator identity mismatch: ' + item['local_file'])
        row = {**item, **result}
        rows.append(row)
        for root in item['root_programs']:
            roots.append({**root, **result})
    minimum = {key: min(x[key] for x in rows) for key in FIELDS}
    root_minimum = {key: min(x[key] for x in roots) for key in FIELDS}
    core_minimum = {key: min(x['core'][key] for x in rows) for key in FIELDS}
    candidates = [{'file': name, **module.metrics(ROOT / name)}
                  for name in ('checker.py', 'checker_compatible.py')]
    for candidate in candidates:
        if not all(candidate[key] < minimum[key] for key in FIELDS):
            raise ValueError('Candidate is not below every frontier coordinate.')
    result = {
        'python': platform.python_version(), 'implementation': platform.python_implementation(),
        'commit': manifest['commit'], 'metric_sha256': METRIC_SHA256,
        'archive_count': len(manifest['archives']), 'root_program_count': len(roots),
        'expanded_distinct_sources': len(rows),
        'expanded_occurrences': sum(len(x['occurrences']) for x in rows),
        'coordinatewise_minimum': minimum, 'root_minimum': root_minimum,
        'core_coordinatewise_minimum': core_minimum, 'candidates': candidates,
        'root_programs': roots, 'expanded_programs': rows,
    }
    results = ROOT / 'results'
    results.mkdir(exist_ok=True)
    (results / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    with (results / 'comparison.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, ('archive_directory', 'filename', *FIELDS, 'raw_bytes', 'sha256'), extrasaction='ignore')
        writer.writeheader()
        writer.writerows(roots)
    main, control = candidates
    macros = {'NewTokens': main['normalized_tokens'], 'NewAst': main['ast_nodes'],
              'NewBytes': format(main['normalized_bytes'], ','),
              'ControlTokens': control['normalized_tokens']}
    (results / 'macros.tex').write_text(''.join(
        '\\newcommand{\\' + key + '}{' + str(value) + '}\n'
        for key, value in macros.items()))
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ('root_programs', 'expanded_programs')}, indent=2))


if __name__ == '__main__':
    main()
