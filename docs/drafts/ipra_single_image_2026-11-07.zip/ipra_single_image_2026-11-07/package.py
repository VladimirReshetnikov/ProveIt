"""Create or verify the complete research deliverable."""
from pathlib import Path
import hashlib
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / 'SHA256SUMS.txt'
EXCLUDED_SUFFIXES = {'.pyc', '.aux', '.log', '.out', '.toc', '.synctex.gz'}


def files():
    return sorted(path for path in ROOT.rglob('*')
                  if path.is_file() and path != MANIFEST
                  and not any(part.startswith('.') or part == '__pycache__'
                              for part in path.relative_to(ROOT).parts)
                  and path.suffix not in EXCLUDED_SUFFIXES)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    if sys.argv[1:] == ['--verify']:
        expected = {}
        for line in MANIFEST.read_text().splitlines():
            sha, name = line.split('  ', 1)
            expected[name] = sha
        actual = {str(path.relative_to(ROOT)): digest(path) for path in files()}
        if actual != expected:
            changed = sorted(name for name in actual.keys() | expected.keys()
                             if actual.get(name) != expected.get(name))
            raise SystemExit('Payload differs: ' + ', '.join(changed))
        print('PASS: ' + str(len(actual)) + ' payload identities verified.')
        return
    if sys.argv[1:]:
        raise SystemExit('Usage: python3 package.py [--verify]')
    payload = files()
    MANIFEST.write_text(''.join(digest(path) + '  ' + str(path.relative_to(ROOT)) + '\n'
                                for path in payload))
    target = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in [*payload, MANIFEST]:
            archive.write(path, ROOT.name + '/' + str(path.relative_to(ROOT)))
    with zipfile.ZipFile(target) as archive:
        damaged = archive.testzip()
        if damaged:
            raise ValueError('ZIP integrity error: ' + damaged)
    print(str(target))


if __name__ == '__main__':
    main()
