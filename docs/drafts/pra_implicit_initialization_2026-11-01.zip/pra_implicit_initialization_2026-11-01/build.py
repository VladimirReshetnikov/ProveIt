#!/usr/bin/env python3
"""Rebuild the paper and rerun its executable diagnostics.

Requirements: Python 3.10+, pdflatex with the packages named in report.tex.
Optional: Lean 4.19.0, enabled with --lean /absolute/path/to/lean.
The written arithmetic and interpretation proofs are not machine formalized.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess


ROOT = Path(__file__).resolve().parent


def checked(command, output):
    process = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
    output.write_text(process.stdout + process.stderr)
    if process.returncode:
        raise RuntimeError(f'Command failed: {command}; see {output}')
    return process.stdout


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--lean', help='Path to a Lean 4.19.0 executable')
    parser.add_argument('--skip-pdf', action='store_true')
    args = parser.parse_args()
    audit = ROOT/'audit'
    audit.mkdir(exist_ok=True)
    for program in ('count_axioms.py', 'check_countermodel.py',
                    'check_binary_compiler.py'):
        checked(['python3', str(ROOT/'artifacts'/program)],
                audit/(Path(program).stem+'.log'))
    record = {'diagnostics': 'passed', 'pdf': 'not rebuilt',
              'formal_scope': 'constructive logical reduction only'}
    if args.lean:
        lean_output = checked([args.lean, 'formal/JointSchema.lean'],
                              ROOT/'formal/verification.txt')
        if 'sorryAx' in lean_output or 'depends on axioms: [' in lean_output:
            # An explicitly empty list is acceptable; anything nonempty is not.
            for match in re.finditer(r'depends on axioms:\s*\[([^]]*)\]',
                                     lean_output):
                if match.group(1).strip():
                    raise RuntimeError('A nonempty global axiom dependency was reported')
        record['lean'] = 'passed'
    if not args.skip_pdf:
        binary = shutil.which('pdflatex')
        if binary is None:
            raise RuntimeError('pdflatex is required; alternatively pass --skip-pdf')
        for number in (1, 2):
            checked([binary, '-interaction=nonstopmode', '-halt-on-error',
                     '-file-line-error', 'report.tex'],
                    audit/f'latex-pass-{number}.txt')
        log = (ROOT/'report.log').read_text(errors='replace')
        defects = [line for line in log.splitlines()
                   if ('Overfull \\hbox' in line or 'Overfull \\vbox' in line
                       or 'undefined references' in line
                       or ('LaTeX Warning: Reference' in line and 'undefined' in line)
                       or ('LaTeX Warning: Citation' in line and 'undefined' in line))]
        if defects:
            raise RuntimeError('Layout/reference checks failed:\n'+'\n'.join(defects))
        record['pdf'] = 'compiled; no overfull boxes or undefined references'
        record['pdf_sha256'] = hashlib.sha256((ROOT/'report.pdf').read_bytes()).hexdigest()
        record['tex_sha256'] = hashlib.sha256((ROOT/'report.tex').read_bytes()).hexdigest()
    (audit/'build.json').write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
