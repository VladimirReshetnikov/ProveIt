"""Independent AST ledger for fused induction with shared computation binders.

Reproducible research diagnostic. Every node costs one. A schematic formula
application is counted as a node with its displayed term arguments; all
quantifiers are included. No arbitrary substituted body is charged.
"""
from dataclasses import dataclass


@dataclass(frozen=True)
class Node:
    label: str
    children: tuple = ()

    @property
    def size(self):
        return 1 + sum(child.size for child in self.children)


def node(label, *children):
    return Node(label, children)


def quantify(names, matrix):
    for name in reversed(names):
        matrix = node('forall ' + name, matrix)
    return matrix


z = node('0')
a = node('a')
n = node('n')
sn = node('S', n)
e = node('=', z, node('S', z))


def formula_matrix(argument, parameters):
    return node('A', argument, *parameters)


def computation_matrices():
    base = node('=', node('R_h', z, a), a)
    step = node('=', node('R_h', sn, a),
                node('h', n, node('R_h', n, a)))
    return base, step


def compare(parameter_count):
    """q>0 uses seed a as first formula parameter; q=0 ignores seed."""
    names = ([] if parameter_count == 0 else
             ['a'] + ['c' + str(i) for i in range(1, parameter_count)])
    parameters = [node(name) for name in names]
    a0 = formula_matrix(z, parameters)
    an = formula_matrix(n, parameters)
    asn = formula_matrix(sn, parameters)
    premise = node('and', node('or', a0, e),
                   quantify(['n'], node('implies', an, asn)))
    base, step = computation_matrices()
    ordinary_fusion = quantify(names, node('implies', premise,
                                          quantify(['n'], an)))
    old = (quantify(['a'], base).size
           + quantify(['n', 'a'], step).size + ordinary_fusion.size)
    shared_names = ['a'] if parameter_count == 0 else names
    result = node('and', an, node('and', base, step))
    shared = quantify(shared_names, node('implies', premise,
                                         quantify(['n'], result)))
    return old, shared.size


def compare_coupled_frozen(frozen_count):
    """Original initialized grammar, A parameters are exactly a,b_1,...,b_r."""
    names = ['a'] + ['b' + str(i) for i in range(frozen_count)]
    pars = [node(name) for name in names]
    bs = pars[1:]
    base = node('=', node('R_h', z, a, *bs), a)
    step = node('=', node('R_h', sn, a, *bs),
                node('h', n, *bs, node('R_h', n, a, *bs)))
    an = formula_matrix(n, pars)
    premise = node('and', node('or', formula_matrix(z, pars), e),
                   quantify(['n'], node('implies', an,
                                         formula_matrix(sn, pars))))
    fused = quantify(names, node('implies', premise, quantify(['n'], an)))
    old = (quantify(names, base).size + quantify(['n'] + names, step).size
           + fused.size)
    shared = quantify(names, node('implies', premise,
                      quantify(['n'], node('and', an,
                                             node('and', base, step)))))
    return old, shared.size


def transport(frozen_formula_parameters):
    """One mandatory displayed observer/seed parameter a plus r extras."""
    names = ['a'] + ['c' + str(i) for i in range(frozen_formula_parameters)]
    parameters = [node(name) for name in names]
    transported = [node('R_h', z, a)] + parameters[1:]
    an = formula_matrix(n, parameters)
    asn = formula_matrix(sn, parameters)
    premise = node('and', node('or', formula_matrix(z, transported), e),
                   quantify(['n'], node('implies', an, asn)))
    base, step = computation_matrices()
    result = node('and', an, step)
    packed = quantify(names, node('implies', premise,
                                  quantify(['n'], result)))
    return packed.size


if __name__ == '__main__':
    print('Binary constructor, q actual formula parameters')
    print('q, separate_fusion, shared, saving')
    for q in range(7):
        old, shared = compare(q)
        assert old == 37 + 5*q
        assert shared == (37 if q == 0 else 36 + 5*q)
        print(q, old, shared, old-shared, sep=', ')
    print('Ordinary initialized constructor, r frozen parameters, q=r+1')
    print('r, separate_fusion, shared, saving')
    for r in range(5):
        old, shared = compare_coupled_frozen(r)
        assert old == 42 + 11*r
        assert shared == 41 + 9*r
        print(r, old, shared, old-shared, sep=', ')
    print('Transported base, binary constructor; one observer a plus r extras')
    print('r, separate_fusion, shared, transport, saving_over_separate')
    for r in range(6):
        old, shared = compare(r+1)
        carried = transport(r)
        assert carried == 37 + 5*r
        assert old - carried == 5
        print(r, old, shared, carried, old-carried, sep=', ')
