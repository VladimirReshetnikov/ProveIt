"""Finite countermodel to replacing recursor equations by invariant induction.

This checks the stronger all-predicates property on a two-element carrier,
which includes every quantifier-free instance and every fixed parameter
assignment. It does not refute the separate 37-node base-transport schema.
"""
from itertools import product


DOMAIN = (0, 1)


def successor(n):
    return 1-n


def table_function(values):
    return lambda n, v: values[2*n+v]


checked = 0
nonvacuous = 0
for h_values in product(DOMAIN, repeat=4):
    h = table_function(h_values)
    def rec(n, a):
        return a if n == 0 else h(0, a)
    for predicate_values in product((False, True), repeat=4):
        predicate = table_function(predicate_values)
        closed = all(not predicate(n, v) or predicate(successor(n), h(n, v))
                     for n in DOMAIN for v in DOMAIN)
        for a in DOMAIN:
            checked += 1
            antecedent = predicate(0, a) and closed
            conclusion = all(predicate(n, rec(n, a)) for n in DOMAIN)
            assert not antecedent or conclusion
            nonvacuous += int(antecedent)

# The designated zero and its successor are distinct.
assert 0 != successor(0)
# For update h(n,v)=0, the successor computation equation fails at n=1,a=1.
h = lambda n, v: 0
rec = lambda n, a: a if n == 0 else h(0, a)
left = rec(successor(1), 1)
right = h(1, rec(1, 1))
assert (left, right) == (1, 0)

print({'all_predicate_checks': checked,
       'nonvacuous_antecedents': nonvacuous,
       'separation': True,
       'failed_successor_equation_at_n1_a1': [left, right]})
