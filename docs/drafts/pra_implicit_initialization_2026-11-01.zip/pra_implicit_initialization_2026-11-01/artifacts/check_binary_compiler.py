#!/usr/bin/env python3
"""Finite diagnostics for the binary term compiler in report.tex.

These checks are not a proof about nonstandard models. The evaluator uses
ordinary Python natural numbers. Every defined function symbol below is a
binary initialized recursor; stored updates have only counter/value inputs.
Composed terms, including the ternary selector, are not extra primitives.
"""
from dataclasses import dataclass
from functools import lru_cache
import json
from pathlib import Path


@dataclass(frozen=True)
class Term:
    op: str
    args: tuple = ()
    name: str = ''
    index: int = -1


def var(i):
    return Term('var', index=i)


zero = Term('zero')


def succ(t):
    return Term('succ', (t,))


one = succ(zero)
u, v = var(0), var(1)
descriptions = {}


def call(name, counter, seed):
    return Term('call', (counter, seed), name=name)


def dependencies(t):
    result = {t.name} if t.op == 'call' else set()
    for child in t.args:
        result.update(dependencies(child))
    return result


def variables(t):
    result = {t.index} if t.op == 'var' else set()
    for child in t.args:
        result.update(variables(child))
    return result


def admit(name, body):
    assert name not in descriptions
    assert variables(body) <= {0, 1}, (name, variables(body))
    assert dependencies(body) <= descriptions.keys(), (name, dependencies(body))
    descriptions[name] = body


def substitute(t, values):
    if t.op == 'var':
        return values[t.index]
    return Term(t.op, tuple(substitute(a, values) for a in t.args),
                t.name, t.index)


admit('pred', u)
admit('mask', zero)
admit('add', succ(v))


def pred(x):
    return call('pred', x, zero)


def mask(n, a):
    return call('mask', n, a)


def add(x, y):
    return call('add', y, x)


admit('sub', pred(v))


def sub(x, y):
    return call('sub', y, x)


def case(z, a, b):
    return add(mask(z, a), mask(mask(z, one), b))


admit('tri', add(v, succ(u)))


def tri(x):
    return call('tri', x, zero)


admit('inverse_tri', case(sub(tri(succ(v)), succ(u)), succ(v), v))


def inv(x):
    return call('inverse_tri', x, zero)


def pair(x, y):
    return add(tri(add(x, y)), y)


def right(z):
    return sub(z, tri(inv(z)))


def left(z):
    return sub(inv(z), right(z))


def encode(xs):
    ans = zero
    for x in xs:
        ans = pair(ans, x)
    return ans


def decode(z, length, i):
    for _ in range(length - i - 1):
        z = left(z)
    return right(z)


def compile_recursion(name, base, update, parameter_count):
    """base variables b_0,...; update variables n,b_0,...,b_k-1,value."""
    frozen = left(v)
    values = [u] + [decode(frozen, parameter_count, i)
                    for i in range(parameter_count)] + [right(v)]
    body = pair(frozen, substitute(update, values))
    admit(name, body)
    args = [var(i+1) for i in range(parameter_count)]
    initial = pair(encode(args), substitute(base, args))
    return right(call(name, var(0), initial))


# A parameterized product and a nontrivial affine update. The returned terms
# are built by the same generic compiler, not written by a special shortcut.
product = compile_recursion('compiled_product', zero, add(var(2), var(1)), 1)
affine = compile_recursion('compiled_affine', var(1),
                         add(add(var(3), var(1)), var(0)), 2)


def evaluate(t, env):
    if t.op == 'var':
        return env[t.index]
    if t.op == 'zero':
        return 0
    if t.op == 'succ':
        return evaluate(t.args[0], env) + 1
    if t.op == 'call':
        n, a = (evaluate(arg, env) for arg in t.args)
        return run(t.name, n, a)
    raise ValueError(t.op)


prefix_values = {}


@lru_cache(maxsize=None)
def run(name, counter, seed):
    assert counter >= 0 and seed >= 0
    values = prefix_values.setdefault((name, seed), [seed])
    while len(values) <= counter:
        step = len(values)-1
        values.append(evaluate(descriptions[name], (step, values[-1])))
    return values[counter]


def serialize(t):
    if t.op == 'var':
        return ['var', t.index]
    if t.op == 'zero':
        return ['zero']
    if t.op == 'succ':
        return ['succ', serialize(t.args[0])]
    return ['call', t.name, *(serialize(a) for a in t.args)]


def main():
    counts = {'elementary': 0, 'triangular_intervals': 0, 'pairing': 0,
              'onto_pairing': 0, 'compiled_product': 0, 'compiled_affine': 0}
    for x in range(18):
        assert evaluate(pred(u), (x,)) == max(x-1, 0)
        counts['elementary'] += 1
        for y in range(18):
            assert evaluate(add(u, v), (x, y)) == x+y
            assert evaluate(sub(u, v), (x, y)) == max(x-y, 0)
            counts['elementary'] += 2
    for n in range(180):
        t = evaluate(inv(u), (n,))
        assert t*(t+1)//2 <= n < (t+1)*(t+2)//2
        counts['triangular_intervals'] += 1
        assert evaluate(pair(left(u), right(u)), (n,)) == n
        counts['onto_pairing'] += 1
    for x in range(12):
        for y in range(12):
            z = evaluate(pair(u, v), (x, y))
            assert z == (x+y)*(x+y+1)//2+y
            assert evaluate(left(u), (z,)) == x
            assert evaluate(right(u), (z,)) == y
            counts['pairing'] += 3
    for n in range(7):
        for b in range(5):
            assert evaluate(product, (n, b)) == n*b
            counts['compiled_product'] += 1
    for n in range(5):
        for b in range(3):
            for c in range(3):
                assert evaluate(affine, (n, b, c)) == c+n*b+n*(n-1)//2
                counts['compiled_affine'] += 1
    # Mutation guard: a reversed triangular comparison is detectably wrong.
    wrong = 0
    for n in range(1):
        wrong = wrong+1 if n+1 <= (wrong+1)*(wrong+2)//2 else wrong
    # At the next step the wrong inequality advances too soon: V(2) must be 1.
    wrong = wrong+1 if 2 <= (wrong+1)*(wrong+2)//2 else wrong
    assert wrong == 2 and evaluate(inv(u), (2,)) == 1
    result = {'status': 'passed', 'scope': 'finite standard-natural diagnostics',
              'description_count': len(descriptions), 'checks': counts,
              'total_checks': sum(counts.values()), 'mutation_guard': 'passed',
              'all_update_free_variables': 'subset of {counter,value}',
              'all_description_dependencies': 'strictly earlier'}
    here = Path(__file__).resolve().parent
    (here/'binary_descriptions.json').write_text(json.dumps(
        {k: serialize(t) for k, t in descriptions.items()}, indent=2)+'\n')
    (here/'binary_results.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
