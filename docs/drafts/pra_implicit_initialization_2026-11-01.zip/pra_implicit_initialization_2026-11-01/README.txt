PRA WITH IMPLICIT INITIALIZATION
Research package prepared for Vladimir Reshetnikov, 1 November 2026

Read report.pdf; report.tex is its complete, self-contained LaTeX source.

RESULT
The same effective nonlogical schema gives a classical theory definitionally
equivalent to classical first-order PRA and an intuitionistic theory
definitionally equivalent to intuitionistic first-order PRA. Both use the
full carrier, native equality, and identity round-trip isomorphisms.

Only 0, successor, and binary recursion-description symbols are needed.
There is one axiom schema, with no separately assumed computation or
separation axioms. The initialization equation is recovered by taking the
formula A(x,z,c) to be z=c and specializing c to R_h(0,a).

The matched schematic AST count improves from 42+5r to 37+5r, where r is
the number of extra formula parameters after the shared seed a. This is
a logical-packing and formula-substitution improvement. It is not a global
shortestness theorem and does not count the full axiom enumerator or
arbitrary formula/update bodies. The full generator allows every finite
parameter tuple; r=0 alone is NOT claimed sufficient.

SOURCES
All eight archives in ProveIt/docs/drafts were compared at commit
9feae3a8c33b807fa347f82a9e5127b2e2049823. audit/source_manifest.json records
their immutable URLs and verified hashes. The package does not duplicate
the eight original archives. The paper identifies inherited ingredients
and the new reduction explicitly.

CONTENTS
report.tex / report.pdf             Complete paper and compiled PDF
AXIOMS.txt                         Exact grammar and sole schema
formal/JointSchema.lean             Constructive logical equivalence kernel
formal/SCOPE.txt                    What the Lean file does and does not prove
formal/verification.txt / .json     Checked endpoints and axiom dependencies
artifacts/count_axioms.py           Independent AST counting
artifacts/check_binary_compiler.py  Legal binary descriptions and finite tests
artifacts/check_countermodel.py     Exhaustive two-element countermodel check
audit/                             Source manifest, reviews, validation logs
build.py                           Rebuild and rerun instructions
SHA256SUMS.txt                      Hashes of packaged files

REBUILD
From this directory:
  python3 build.py
For diagnostics without LaTeX:
  python3 build.py --skip-pdf
For the optional Lean replay as well:
  python3 build.py --lean /path/to/lean

Use Lean 4.19.0. The Lean source imports Init only; no Mathlib dependency
is needed. pdflatex requires the packages listed at the top of report.tex.

VALIDATION SCOPE
The Lean kernel verifies the new logical equivalence and initialization
recovery, with an explicit admitted-predicate interface. It does not
formalize first-order syntax, pairing, or the full bi-interpretations.
Finite numerical checks catch coding mistakes; the arbitrary-model
claims are justified by the paper's written internal proofs.

The countermodel section rejects a tempting invariant-only replacement
for the successor computation equation in both logics. Pure unary-update
iteration remains an explicitly unproved further reduction here.
