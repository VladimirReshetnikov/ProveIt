import Init

/-!
# Constructive logical kernel for seed-substitution packing of PRA

`Admitted` is a class of predicate families with a counter input and a seed
input. Their other finite parameters are already fixed. The class is not
identified with all predicates. Induction is restricted to the same explicitly
admitted families throughout.

The kernel checks the logical packing step, including extraction of the missing
initialization equation by an equality probe. The concrete syntax, recursion
description grammar, compiler, and bi-interpretations are outside its scope.
-/

universe u

namespace PRAJoint

variable {Carrier : Type u}

/-- Both computation equations for one binary recursor and its update. -/
def Computation
    (zero : Carrier) (succ : Carrier → Carrier)
    (recursor update : Carrier → Carrier → Carrier) : Prop :=
  (∀ seed, recursor zero seed = seed) ∧
    ∀ index seed,
      recursor (succ index) seed = update index (recursor index seed)

/-- Counter induction for an admitted family with its seed fixed. -/
def AdmittedInduction
    (Admitted : (Carrier → Carrier → Prop) → Prop)
    (zero : Carrier) (succ : Carrier → Carrier) : Prop :=
  ∀ seed predicate, Admitted predicate → predicate zero seed →
    (∀ index, predicate index seed → predicate (succ index) seed) →
      ∀ index, predicate index seed

/-- The modified seed occurs only in the induction base. -/
def JointSchema
    (Admitted : (Carrier → Carrier → Prop) → Prop)
    (zero : Carrier) (succ : Carrier → Carrier)
    (recursor update : Carrier → Carrier → Carrier) : Prop :=
  ∀ seed predicate, Admitted predicate →
    ((predicate zero (recursor zero seed) ∨ zero = succ zero) ∧
      (∀ index, predicate index seed → predicate (succ index) seed)) →
        ∀ index,
          predicate index seed ∧
            recursor (succ index) seed = update index (recursor index seed)

/-- The separate computation, separation, and admitted-induction principles. -/
def SeparateBasis
    (Admitted : (Carrier → Carrier → Prop) → Prop)
    (zero : Carrier) (succ : Carrier → Carrier)
    (recursor update : Carrier → Carrier → Carrier) : Prop :=
  Computation zero succ recursor update ∧
    (zero ≠ succ zero) ∧ AdmittedInduction Admitted zero succ

theorem joint_implies_initialization
    {Admitted : (Carrier → Carrier → Prop) → Prop}
    {zero : Carrier} {succ : Carrier → Carrier}
    {recursor update : Carrier → Carrier → Carrier}
    (probes_admitted : ∀ probe, Admitted (fun _ seed => seed = probe))
    (joint : JointSchema Admitted zero succ recursor update) :
    ∀ seed, recursor zero seed = seed := by
  intro seed
  have premise :
      ((recursor zero seed = recursor zero seed ∨ zero = succ zero) ∧
        (∀ _ : Carrier,
          seed = recursor zero seed → seed = recursor zero seed)) :=
    ⟨Or.inl rfl, fun _ proof => proof⟩
  have reversed : seed = recursor zero seed :=
    (joint seed (fun _ value => value = recursor zero seed)
      (probes_admitted (recursor zero seed)) premise zero).1
  exact reversed.symm

theorem joint_implies_successor_computation
    {Admitted : (Carrier → Carrier → Prop) → Prop}
    {zero : Carrier} {succ : Carrier → Carrier}
    {recursor update : Carrier → Carrier → Carrier}
    (true_admitted : Admitted (fun _ _ => True))
    (joint : JointSchema Admitted zero succ recursor update) :
    ∀ index seed,
      recursor (succ index) seed = update index (recursor index seed) := by
  intro index seed
  have premise :
      ((True ∨ zero = succ zero) ∧ (∀ _ : Carrier, True → True)) :=
    ⟨Or.inl True.intro, fun _ proof => proof⟩
  exact (joint seed (fun _ _ => True) true_admitted premise index).2

theorem joint_implies_computation
    {Admitted : (Carrier → Carrier → Prop) → Prop}
    {zero : Carrier} {succ : Carrier → Carrier}
    {recursor update : Carrier → Carrier → Carrier}
    (true_admitted : Admitted (fun _ _ => True))
    (probes_admitted : ∀ probe, Admitted (fun _ seed => seed = probe))
    (joint : JointSchema Admitted zero succ recursor update) :
    Computation zero succ recursor update := by
  exact ⟨joint_implies_initialization probes_admitted joint,
    joint_implies_successor_computation true_admitted joint⟩

theorem joint_implies_separation
    {Admitted : (Carrier → Carrier → Prop) → Prop}
    {zero : Carrier} {succ : Carrier → Carrier}
    {recursor update : Carrier → Carrier → Carrier}
    (false_admitted : Admitted (fun _ _ => False))
    (joint : JointSchema Admitted zero succ recursor update) :
    zero ≠ succ zero := by
  intro collision
  have premise :
      ((False ∨ zero = succ zero) ∧ (∀ _ : Carrier, False → False)) :=
    ⟨Or.inr collision, fun _ proof => proof⟩
  exact (joint zero (fun _ _ => False) false_admitted premise zero).1

theorem joint_implies_induction
    {Admitted : (Carrier → Carrier → Prop) → Prop}
    {zero : Carrier} {succ : Carrier → Carrier}
    {recursor update : Carrier → Carrier → Carrier}
    (probes_admitted : ∀ probe, Admitted (fun _ seed => seed = probe))
    (joint : JointSchema Admitted zero succ recursor update) :
    AdmittedInduction Admitted zero succ := by
  intro seed predicate admitted base step index
  have initialization := joint_implies_initialization probes_admitted joint seed
  have shifted_base : predicate zero (recursor zero seed) := by
    rw [initialization]
    exact base
  exact (joint seed predicate admitted ⟨Or.inl shifted_base, step⟩ index).1

theorem separate_implies_joint
    {Admitted : (Carrier → Carrier → Prop) → Prop}
    {zero : Carrier} {succ : Carrier → Carrier}
    {recursor update : Carrier → Carrier → Carrier}
    (basis : SeparateBasis Admitted zero succ recursor update) :
    JointSchema Admitted zero succ recursor update := by
  intro seed predicate admitted premise index
  have base : predicate zero seed := by
    cases premise.1 with
    | inl shifted_base =>
      rw [basis.1.1 seed] at shifted_base
      exact shifted_base
    | inr collision => exact False.elim (basis.2.1 collision)
  exact ⟨basis.2.2 seed predicate admitted base premise.2 index,
    basis.1.2 index seed⟩

theorem joint_iff_separate
    {Admitted : (Carrier → Carrier → Prop) → Prop}
    {zero : Carrier} {succ : Carrier → Carrier}
    {recursor update : Carrier → Carrier → Carrier}
    (true_admitted : Admitted (fun _ _ => True))
    (false_admitted : Admitted (fun _ _ => False))
    (probes_admitted : ∀ probe, Admitted (fun _ seed => seed = probe)) :
    JointSchema Admitted zero succ recursor update ↔
      SeparateBasis Admitted zero succ recursor update := by
  constructor
  · intro joint
    exact ⟨joint_implies_computation true_admitted probes_admitted joint,
      joint_implies_separation false_admitted joint,
      joint_implies_induction probes_admitted joint⟩
  · exact separate_implies_joint

/-- Family extraction uses one explicitly selected legal dummy description. -/
theorem family_joint_iff_separate
    {Description : Type}
    (selected : Description)
    {Admitted : (Carrier → Carrier → Prop) → Prop}
    {zero : Carrier} {succ : Carrier → Carrier}
    {recursors updates : Description → Carrier → Carrier → Carrier}
    (true_admitted : Admitted (fun _ _ => True))
    (false_admitted : Admitted (fun _ _ => False))
    (probes_admitted : ∀ probe, Admitted (fun _ seed => seed = probe)) :
    (∀ description,
      JointSchema Admitted zero succ
        (recursors description) (updates description)) ↔
    ((∀ description,
      Computation zero succ (recursors description) (updates description)) ∧
      (zero ≠ succ zero) ∧ AdmittedInduction Admitted zero succ) := by
  constructor
  · intro joint
    exact ⟨fun description =>
      joint_implies_computation true_admitted probes_admitted (joint description),
      joint_implies_separation false_admitted (joint selected),
      joint_implies_induction probes_admitted (joint selected)⟩
  · intro basis description
    exact separate_implies_joint ⟨basis.1 description, basis.2.1, basis.2.2⟩

#print axioms joint_implies_initialization
#print axioms joint_implies_successor_computation
#print axioms joint_implies_computation
#print axioms joint_implies_separation
#print axioms joint_implies_induction
#print axioms separate_implies_joint
#print axioms joint_iff_separate
#print axioms family_joint_iff_separate

end PRAJoint
