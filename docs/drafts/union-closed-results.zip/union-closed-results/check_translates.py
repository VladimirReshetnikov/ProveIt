#!/usr/bin/env python3
"""Exhaust all shapes, up to translation, on the finite abelian groups listed.

Frequency and arithmetic inequalities use integer arithmetic only.
Run with Python 3.9+; no external dependencies.
"""
from fractions import Fraction
from itertools import product
from math import prod


def make_group(factors):
    points = list(product(*(range(m) for m in factors)))
    position = {point: i for i, point in enumerate(points)}
    return [
        [position[tuple((a + b) % m for a, b, m in zip(x, y, factors))]
         for y in points]
        for x in points
    ]


def translate(mask, permutation):
    return sum(1 << to for i, to in enumerate(permutation) if mask & (1 << i))


def unions(generators):
    family = {0}
    for generator in generators:
        family.update([member | generator for member in family])
    return family


def check_group(factors):
    addition = make_group(factors)
    n = len(addition)
    seen = {0}
    tested = 0
    tightest = None
    for shape in range(1, 1 << n):
        if shape in seen:
            continue
        translates = {translate(shape, row) for row in addition}
        seen.update(translates)
        family = unions(translates)
        count = len(family)
        cover = sum(bool(member & 1) for member in family)
        assert all(sum(bool(member & (1 << i)) for member in family) == cover
                   for i in range(n))
        periods = n // len(translates)
        d = shape.bit_count() // periods
        assert shape.bit_count() == d * periods
        # Check the AEL identity using any translate through the origin.
        tile = next(generator for generator in translates if generator & 1)
        assert sum(member & tile == tile for member in family) == count-cover
        if d == 1:
            assert 2 * cover == count
        else:
            p = Fraction(cover, count)
            assert p > Fraction(1, 2)
            assert p >= Fraction(d+2, 2*d+3)
            overlaps = [size for gen in translates
                        if (size := (tile & gen).bit_count()) and gen != tile]
            m = min(overlaps) // periods
            assert m * periods == min(overlaps)
            assert p >= Fraction(1, 2) + Fraction(m, 4*d+6*m)
            tightest = p if tightest is None else min(tightest, p)
        tested += 1
    assert len(seen) == 2**n
    return tested, tightest


if __name__ == '__main__':
    groups = [(n,) for n in range(1, 14)]
    groups += [(2, 2), (2, 2, 2), (2, 4), (3, 3), (2, 6)]
    total = shapes = 0
    for factors in groups:
        tested, lowest = check_group(factors)
        shapes += (1 << prod(factors)) - 1
        total += tested
        print(f'{str(factors):16s}  orbits {tested:4d}  '
              f'least noncoset frequency {lowest if lowest else "none"}')
    print(f'PASS: {shapes} nonempty shapes in {total} translation orbits '
          f'on {len(groups)} groups.')
