"""Construct and check the four smallest examples on their smallest ground sets."""
from itertools import combinations
import argparse


def subsets(mask):
    return {i for i in range(mask + 1) if (i & mask) == i}


def example(a, include_empty):
    first, second, universe = 7, 11, 15
    bottom = {first, second, universe}
    if include_empty:
        bottom.add(0)
    mandated = {0, first, second, universe}
    fibers = [subsets(first) | mandated, subsets(second) | mandated,
              subsets(first ^ second) | mandated]
    counts = [a, a, 5 * a + 1]
    outside_width = sum(count.bit_length() for count in counts)
    outside = ((1 << outside_width) - 1) << 4
    family = bottom | {outside | s for s in subsets(universe)}
    offset = 4
    for count, fiber in zip(counts, fibers):
        for omission in range(1, count + 1):
            label = outside ^ (omission << offset)
            family.update(label | s for s in fiber)
        offset += count.bit_length()
    return family


def list_sets(family):
    for s in sorted(family, key=lambda x: (x.bit_count(), x)):
        members = (str(i + 1) for i in range(s.bit_length()) if s >> i & 1)
        yield "{" + ", ".join(members) + "}"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write-example", metavar="PATH")
    args = parser.parse_args()
    for a, empty, n, v in [(2, True, 137, 12), (3, False, 191, 13),
                            (3, True, 192, 13), (4, False, 246, 15)]:
        family = example(a, empty)
        degrees = [sum((s >> i) & 1 for s in family) for i in range(v)]
        assert len(family) == n and max(family) == (1 << v) - 1
        assert all((s | t) in family for s, t in combinations(family, 2))
        assert (0 in family) == empty
        assert set(s for s in family if s.bit_count() == 3) == {7, 11}
        assert all(d == (n - 1) // 2 for d in degrees[:4])
        assert min(degrees[4:]) * 2 >= n
        print(f"{n} members on {v} points. Degrees: {degrees}.")
        if n == 137 and args.write_example:
            with open(args.write_example, "w", encoding="utf-8") as stream:
                stream.write("\n".join(list_sets(family)) + "\n")


if __name__ == "__main__":
    main()
