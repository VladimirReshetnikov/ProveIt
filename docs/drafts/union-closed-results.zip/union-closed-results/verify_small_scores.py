#!/usr/bin/env python3
"""Check the additional local table for the global abundance corollary."""
from collections import Counter
from verify_minima import FIRST, SECOND, score, union_closed


def main():
    observations = Counter()
    for code in range(1, 1 << 16):
        family = {s for s in range(16) if code >> s & 1}
        if not all((s | t) in family for s in family for t in (FIRST, SECOND)):
            continue
        if not union_closed(family) or score(family) > 14:
            continue
        assert 0 in family and (4 in family or 8 in family)
        imbalances = [sum(1 if s & (1 << i) else -1 for s in family)
                      for i in range(4)]
        row = (score(family), sum(imbalances[:2]), tuple(sorted(imbalances[2:])))
        observations[row] += 1
    expected = {(0, 4, (-6, 0)): 2, (0, -2, (1, 1)): 1,
                (4, -2, (1, 1)): 2, (8, 0, (0, 0)): 1,
                (12, 0, (0, 0)): 2, (14, 2, (-3, 1)): 4}
    assert observations == expected
    for row, count in sorted(observations.items()):
        print(f'{row}: {count}')


if __name__ == '__main__':
    main()
