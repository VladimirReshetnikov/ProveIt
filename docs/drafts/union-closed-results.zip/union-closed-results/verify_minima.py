#!/usr/bin/env python3
"""Independent exhaustive four-point checks and four sharp extremizers.

No imports beyond Python 3.10+'s standard library. Each possible nonempty
local family is visited directly; no bound from a linear solver is used.
"""
from itertools import combinations


CORE = 3
PETALS = 12
FIRST = 7
SECOND = 11
FULL = 15
BOTTOM = frozenset({0, FIRST, SECOND, FULL})


def union_closed(family):
    return all((s | t) in family for s, t in combinations(family, 2))


def score(family):
    return sum(31 * (s & CORE).bit_count() + 24 * (s & PETALS).bit_count() - 54
               for s in family)


def check_fibers():
    admitted = 0
    minima = {'all': None, 'no_empty': None, 'miss_core': None, 'miss_petal': None}

    def record(key, value):
        old = minima[key]
        minima[key] = value if old is None else min(old, value)

    for encoding in range(1, 1 << 16):
        family = {s for s in range(16) if encoding >> s & 1}
        if not all((s | t) in family for s in family for t in (FIRST, SECOND)):
            continue
        if not union_closed(family):
            continue
        admitted += 1
        record('all', score(family))
        if 0 not in family:
            record('no_empty', score(family))
            continue
        if 1 not in family or 2 not in family:
            record('miss_core', sum(2 * s.bit_count() - 4 for s in family))
        if 4 not in family or 8 not in family:
            record('miss_petal', sum(2 * (s & CORE).bit_count() - 2 for s in family))
    assert admitted == 2216
    assert minima == {'all': 0, 'no_empty': 50, 'miss_core': 0, 'miss_petal': 0}
    print(f'Admissible nonempty four-point fibers = {admitted}')
    print(f'Minima of the four certificate functions = {minima}')


def submasks(mask):
    return {s for s in range(mask + 1) if s | mask == mask}


def example(q, include_empty):
    high = [submasks(triple) | BOTTOM for triple in (FIRST, SECOND)]
    low = submasks(PETALS) | BOTTOM
    layers = (high + [low] * 5) * q + [low]
    outside = ((1 << len(layers)) - 1) << 4
    family = set(BOTTOM) | {outside | s for s in range(16)}
    for i, layer in enumerate(layers):
        trace = outside ^ (1 << (i + 4))
        family.update(trace | s for s in layer)
    if not include_empty:
        family.remove(0)
    return family


def check_examples():
    for q, include_empty, expected in [(2, True, 137), (3, True, 192),
                                       (3, False, 191), (4, False, 246)]:
        family = example(q, include_empty)
        assert len(family) == expected and union_closed(family)
        assert (0 in family) == include_empty
        assert {s for s in family if s.bit_count() == 3} == {FIRST, SECOND}
        degrees = tuple(sum(bool(s & (1 << i)) for s in family) for i in range(4))
        assert degrees == (27*q + 14,) * 4
        assert all(2*d < len(family) for d in degrees)
        print(f'empty = {include_empty!s:5}, size = {len(family)}, degrees = {degrees}')


if __name__ == '__main__':
    check_fibers()
    check_examples()
