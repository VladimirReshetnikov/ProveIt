#!/usr/bin/env python3
"""Exact certificates for two intersecting triples. Uses only Python 3.10+."""
from collections import Counter
from fractions import Fraction


def submasks(mask):
    return frozenset(x for x in range(mask + 1) if x | mask == mask)


def close_after_adding(hull, point, seed_closure):
    """Add one local set to an already union-closed, seed-stable hull."""
    return (hull | {point | seed for seed in seed_closure}
            | {point | other for other in hull})


def fiber_score(fiber, scores):
    return sum(scores[point] for point in fiber)


def tight_orbits(overlap, first, second):
    """Explicit list of all positive-size equality families."""
    universe = first | second
    core = first & second
    petals = first ^ second
    if overlap == 2:
        high = [submasks(block) | {first, second, universe}
                for block in [first, second]]
        low = submasks(petals) | {first, second, universe}
    else:
        high = []
        for block, other in [(first, second), (second, first)]:
            pair = block ^ core
            for part in submasks(pair):
                base = {0, core, pair, first, second, universe}
                for leaf in [1 << i for i in range(5) if part >> i & 1]:
                    base.update({leaf, leaf | core, leaf | other})
                high.append(frozenset(base))
        low = submasks(petals) | {core | p for p in submasks(petals)
                                  if (((first & petals) | p) == p or ((second & petals) | p) == p)}
    return high, low


def closed(fiber, seeds):
    return all((s | t) in fiber for s in fiber for t in fiber | seeds)


def check(overlap):
    if overlap == 2:
        first, second, core_weight, petal_weight, target = 7, 11, 31, 24, 54
        expected_min = Fraction(27, 55)
    else:
        first, second, core_weight, petal_weight, target = 7, 25, 41, 25, 69
        expected_min = Fraction(23, 47)
    core, petals, universe = first & second, first ^ second, first | second
    seeds = {0, first, second, universe}
    scores = {mask: (core_weight * (mask & core).bit_count() +
                     petal_weight * (mask & petals).bit_count() - target)
              for mask in submasks(universe)}
    assert 0 not in scores.values()
    negatives = sorted(mask for mask, score in scores.items() if score < 0)
    hulls = {frozenset()}
    for mask in negatives:
        hulls |= {close_after_adding(hull, mask, seeds) for hull in hulls}
    hulls.remove(frozenset())
    histogram = Counter(fiber_score(hull, scores) for hull in hulls)
    assert min(histogram) == 0
    tight = {hull for hull in hulls if fiber_score(hull, scores) == 0}
    high, low = tight_orbits(overlap, first, second)
    assert tight == set(high) | {low}
    assert all(closed(h, seeds) for h in tight)
    assert all(0 in h for h in tight)
    assert all(not (h <= low or low <= h) for h in high)
    high_freq = Fraction(3, 5) if overlap == 2 else Fraction(2, 3)
    low_freq = Fraction(3, 7) if overlap == 2 else Fraction(7, 23)
    for h in tight:
        core_frequency = Fraction(sum((s & core).bit_count() for s in h),
                                  len(h) * core.bit_count())
        assert core_frequency == (low_freq if h == low else high_freq)
    assert low_freq < expected_min < high_freq
    if overlap == 2:
        batch = high + [low] * 5
    else:
        batch = [h for h in high if len(h) == 6] * 2 + [low]
    degree = [sum(sum(bool(s & (1 << i)) for s in h) for h in batch)
              for i in range(universe.bit_length())]
    size = sum(map(len, batch))
    assert all(Fraction(d, size) == expected_min for d in degree)

    print(f'{overlap} shared point(s)')
    print(f'  negative masks = {len(negatives)}; selections = {2 ** len(negatives)}')
    print(f'  distinct nonempty hulls = {len(hulls)}; minimizers = {len(tight)}')
    print(f'  minimum slack = {min(histogram)}')
    print(f'  next positive hull slack = {min(k for k in histogram if k > 0)}')
    print(f'  counts by extremal size = {dict(sorted(Counter(map(len,tight)).items()))}')
    print(f'  batch size = {size}; local degrees = {degree}')
    print(f'  sharp infimum = {expected_min}')


if __name__ == '__main__':
    check(2)
    check(1)
