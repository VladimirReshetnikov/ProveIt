Sharp frequency bounds in union-closed families
25 November 2026

Read union-closed.pdf for the statements, proofs, literature comparisons, and
further questions. The TeX source is a single self-contained file.

Main result
-----------
For a union-closed family containing {1,2,3} and {1,2,4}, the smallest
possible family in which all four points are strictly rare has 137 sets.
It can be realized on 12 points. The other parity and empty-set minima are
191, 192, and 246. The paper proves these thresholds and gives a further
range in which Frankl's conjecture holds via a point outside the two triples.

Verify
------
In this directory run

    python3 verify_all.py

Use Python 3.10 or later. Only the standard library is required. The scripts
use assertions, so leave optimization disabled. The recorded output is in
verification.txt. The scripts do not require internet access.

example-137.txt is the full 12-point example, with one set per line. The
four distinguished points are 1, 2, 3, and 4. Recreate that file with

    python3 check_ground.py --write-example regenerated.txt

verify_minima.py and verify_small_scores.py check all admissible four-point
fibers for the minimum-size theorem and the outside-element corollary.
verify_overlap.py checks the sharp frequency bounds for both overlaps.
check_ground.py checks the compact extremizers and their degrees.
check_translates.py and check_circles.py cross-check the group and circle
theorems in finite instances. Their all-orders proofs are in the paper.
check_four.py checks the fiber identities and sharpness constructions for
a single four-element member.

Build
-----
Run pdflatex union-closed.tex twice in a standard TeX Live installation.
