"""Run every certificate and compare the archived 137-set list with its construction."""
from pathlib import Path
import os
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
SCRIPTS = ["verify_minima.py", "check_ground.py", "verify_small_scores.py", "verify_overlap.py",
           "check_translates.py", "check_circles.py", "check_four.py"]

def main():
    if not __debug__:
        raise SystemExit("Run without -O so the verifier assertions are enabled.")
    env = os.environ.copy()
    env.pop("PYTHONOPTIMIZE", None)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    with tempfile.TemporaryDirectory() as tmp:
        example = Path(tmp) / "example.txt"
        for script in SCRIPTS:
            print(f"\n{script}", flush=True)
            extra = ["--write-example", str(example)] if script == "check_ground.py" else []
            subprocess.run([sys.executable, str(ROOT / script), *extra], check=True,
                           cwd=ROOT, env=env)
        assert example.read_bytes() == (ROOT / "example-137.txt").read_bytes()
    print("\nPASS. The archived list matches the independently checked construction.")

if __name__ == "__main__":
    main()
