"""Check the circle formulas in the paper. Python 3.8+, standard library."""
from fractions import Fraction
from math import comb


def union_family(n, k):
    """Choose each translated interval in turn, retaining only distinct unions."""
    family = {0}
    for start in range(n):
        interval = sum(1 << ((start + j) % n) for j in range(k))
        family |= {member | interval for member in family}
    return family


def by_runs(n, k):
    """Return the number of members and the number containing a given point."""
    total = 2
    total_ones = n
    for r in range(1, n // (k + 1) + 1):
        free = n - (k + 1) * r
        ordered_lists = comb(free + 2 * r - 1, 2 * r - 1)
        count, remainder = divmod(n * ordered_lists, r)
        assert remainder == 0
        total += count
        doubled_ones = count * (n + (k - 1) * r)
        assert doubled_ones % 2 == 0
        total_ones += doubled_ones // 2
    assert total_ones % n == 0
    return total, total_ones // n


def sharp(k):
    return Fraction(3*k*k + 9*k + 4, 4*k*k + 14*k + 14)


def main():
    small_cases = 0
    for n in range(3, 17):
        for k in range(2, n):
            family = union_family(n, k)
            total, containing = by_runs(n, k)
            assert total == len(family)
            assert containing == sum(mask & 1 for mask in family)
            small_cases += 1
    print(f"Direct union generation equals run counts in {small_cases} cases (n <= 16).")

    large_cases = 0
    for k in range(2, 41):
        for n in range(k + 1, 251):
            total, containing = by_runs(n, k)
            frequency = Fraction(containing, total)
            assert frequency >= sharp(k)
            assert (frequency == sharp(k)) == (n == 2*k + 2)
            large_cases += 1
    print(f"Sharp bound and equality condition hold in {large_cases} exact checks.")
    print("Minimum for k=2:", sharp(2), "on the 6-cycle.")


if __name__ == "__main__":
    main()
