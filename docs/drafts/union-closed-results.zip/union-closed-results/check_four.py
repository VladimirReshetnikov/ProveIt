"""Exact checks for the finite sharp bound on four marked points.

Use Python 3.10+ and run python check_four.py.  All operations use integers.
"""
from itertools import combinations

TOP = 15
STARTS = [
    ((1, 1, 1, 1), 0, 30, 14), ((1, 0, 0, 0), 0, 21, 11),
    ((0, 0, 2, 1), 1, 32, 15), ((0, 0, 0, 0), 1, 23, 12),
    ((1, 1, 0, 0), 0, 24, 12), ((0, 0, 2, 2), 1, 35, 16),
    ((0, 0, 1, 0), 1, 26, 13), ((1, 1, 1, 0), 0, 27, 13),
    ((0, 0, 0, 0), 0, 18, 9), ((0, 0, 2, 0), 1, 29, 14),
]


def edge(i, j):
    return frozenset([0, 1 << i, 1 << j, (1 << i) | (1 << j), TOP])


def is_union_closed(family):
    return all(a | b in family for a, b in combinations(family, 2))


def check_fibers():
    zero_cases = set()
    cases = 0
    for h in range(1 << TOP, 1 << (TOP + 1)):
        family = frozenset(a for a in range(TOP + 1) if h >> a & 1)
        if not is_union_closed(family):
            continue
        cases += 1
        n = len(family)
        weight = sum(a.bit_count() for a in family)
        score = 5 * weight - 8 * n
        assert score >= 0
        if not score:
            zero_cases.add(family)
        for z in range(4):
            if 0 not in family or 1 << z not in family:
                dz = sum(a >> z & 1 for a in family)
                g = 2 * weight - dz - 3 * n
                assert g >= 0
                if not any(a.bit_count() in (1, 2) for a in family):
                    assert g >= 1
    assert zero_cases == {edge(i, j) for i, j in combinations(range(4), 2)}
    print(f"All {cases} admissible four-point fibers verified, including {len(zero_cases)} zero cases.")


def target(m):
    return (2 * m + 13) // 5 + (m % 10 == 3)


def construct(m):
    mult, edge_count, base_size, base_frequency = STARTS[m % 10]
    t, rem = divmod(m - base_size, 10)
    assert rem == 0 and t >= 0
    fibers = []
    for i, count in enumerate(mult):
        fibers.extend([frozenset([0, 1 << i, TOP])] * count)
    fibers.extend([edge(0, 1)] * (edge_count + t))
    fibers.extend([edge(2, 3)] * t)
    assert len(fibers) >= 2
    outside = ((1 << len(fibers)) - 1) << 4
    family = {0, TOP}
    family.update(outside | a for a in range(TOP + 1))
    for j, fiber in enumerate(fibers):
        label = outside ^ (1 << (4 + j))
        family.update(label | a for a in fiber)
    frequencies = [sum(a >> i & 1 for a in family) for i in range(4)]
    assert len(family) == m
    assert max(frequencies) == base_frequency + 4 * t == target(m)
    assert {a for a in family if 0 < a.bit_count() <= 4} == {TOP}
    assert is_union_closed(family)
    return frequencies


def check_chains(r):
    """The sharp outside-degree witness consists of two nested branches."""
    outside = ((1 << (2 * r)) - 1) << 4
    family = {0, TOP}
    family.update(outside | a for a in range(TOP + 1))
    for block, fiber in enumerate((edge(0, 1), edge(2, 3))):
        for k in range(1, r + 1):
            prefix = ((1 << k) - 1) << (4 + block * r)
            label = outside ^ prefix
            family.update(label | a for a in fiber)
    m = 18 + 10 * r
    assert len(family) == m
    assert is_union_closed(family)
    degrees = [sum(a >> j & 1 for a in family) for j in range(4 + 2 * r)]
    assert degrees[:4] == [9 + 4 * r] * 4
    assert min(degrees[4:]) == degrees[4] == degrees[4 + r] == m // 2 + 7


if __name__ == "__main__":
    check_fibers()
    for m in list(range(54, 84)) + list(range(244, 264)):
        construct(m)
    print("Explicit families, closure, uniqueness of smallest nonempty set, and degrees verified for M=54,...,83 and M=244,...,263.")
    for r in (1, 2, 4, 5, 23, 24, 25):
        check_chains(r)
    print("Two-branch sharpness examples checked at seven sizes, including M=248, 258, 268.")
