#!/usr/bin/env python3
"""Compile locally; construct a private format if the TeX package omits it."""
from pathlib import Path
import os
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def command(arguments, environment, directory):
    result = subprocess.run(arguments, env=environment, cwd=directory,
                            text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, check=False)
    if result.returncode:
        print(result.stdout[-14000:])
        raise SystemExit(result.returncode)
    return result.stdout


if __name__ == "__main__":
    if not shutil.which("pdflatex"):
        raise SystemExit("Install a standard TeX Live or MiKTeX distribution.")
    environment = dict(os.environ)
    probe = subprocess.run(["kpsewhich", "pdflatex.fmt"],
                           capture_output=True, check=False)
    if not probe.stdout.strip():
        trees = [p for p in ("/usr/share/texlive/texmf-dist", "/usr/share/texmf")
                 if Path(p).is_dir()]
        if trees:
            environment["TEXMF"] = "{" + ",".join(trees) + "}"
        cache = ROOT / "build" / "texformat"
        cache.mkdir(parents=True, exist_ok=True)
        if not (cache / "pdflatex.fmt").is_file():
            command(["pdftex", "-ini", "-etex", "-jobname=pdflatex",
                     "-interaction=nonstopmode", "-halt-on-error", "pdflatex.ini"],
                    environment, cache)
        maps = [Path("/usr/share/texmf/fonts/map/dvips/lm/lm.map")]
        maps += [Path("/usr/share/texlive/texmf-dist/fonts/map/dvips/amsfonts") / name
                 for name in ("cm.map", "cmextra.map", "symbols.map")]
        if all(p.is_file() for p in maps):
            (cache / "pdftex.map").write_text("\n".join(p.read_text() for p in maps))
            environment["TEXFONTMAPS"] = str(cache) + os.pathsep
        environment["TEXFORMATS"] = str(cache) + os.pathsep
    logs = []
    for _ in range(3):
        logs.append(command(["pdflatex", "-interaction=nonstopmode",
                             "-halt-on-error", "report.tex"], environment, ROOT))
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results" / "latex-build.txt").write_text(logs[-1])
    print("Compiled report.pdf")
