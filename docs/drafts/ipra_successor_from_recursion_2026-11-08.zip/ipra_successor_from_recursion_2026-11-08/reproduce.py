#!/usr/bin/env python3
"""Replay symbolic proofs, source measurements, and separate CLI controls."""
from pathlib import Path
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(relative):
    path = ROOT / relative
    completed = subprocess.run(
        [sys.executable, str(path)], cwd=path.parent,
        text=True, capture_output=True, check=False)
    print(completed.stdout, end="")
    if completed.stderr:
        print(completed.stderr, file=sys.stderr, end="")
    if completed.returncode:
        raise SystemExit(completed.returncode)
    return {"script": relative, "exit_code": completed.returncode}


if __name__ == "__main__":
    outcomes = [run("verification/run_checks.py"),
                run("benchmark/run_measurements.py"),
                run("exploration/run_experiments.py")]
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results" / "reproduction.json").write_text(
        json.dumps({"python": sys.version.split()[0], "runs": outcomes,
                    "scope": "Symbolic equation certificates, retained source measurements, and equivalent-implementation CLI controls; not full-theory formalization."},
                   indent=2) + "\n")
    print("All delivered verification steps passed.")
