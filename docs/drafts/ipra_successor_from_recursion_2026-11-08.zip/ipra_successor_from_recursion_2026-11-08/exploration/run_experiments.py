#!/usr/bin/env python3
"""Measure four complete source variants and replay 13 UTF-8 CLI cases.

The inherited normalizer parses source as data.  The separate CLI regression
does execute the pinned compact checker and compact_unpack_open.py.  There
is no external oracle.  All generated files stay in this exploration folder.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
FIELDS = ("normalized_tokens", "ast_nodes", "normalized_bytes")
RECORDED = {
    "structural_open": (316, 347, 901),
    "compact_open": (317, 351, 878),
    "compact_unpack": (314, 348, 929),
    "compact_unpack_open": (313, 347, 922),
}
sys.dont_write_bytecode = True


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def checked_read(path, expected_hash):
    raw = path.read_bytes()
    if sha256(raw) != expected_hash:
        raise ValueError("Pinned source hash changed: " + path.name)
    return raw


def open_stdin(source):
    return source.replace("import json, sys", "import json").replace(
        "json.load(sys.stdin)", "json.load(open(0))")


def unpack_major(source):
    old = "            t, s, u = (t, *m) if m[1:] else (*m, 0, t)"
    new = ("            try:\n"
           "                s, u = m\n"
           "            except:\n"
           "                s, u, t = 0, t, *m")
    if source.count(old) != 1:
        raise ValueError("The pinned dispatch no longer matches the stated transformation")
    return source.replace(old, new)


def cli(path, input_text, environment):
    completed = subprocess.run(
        [sys.executable, "-X", "utf8", str(path)],
        input=input_text.encode("utf-8"), capture_output=True,
        env=environment, timeout=15,
    )
    return {"exit_code": completed.returncode,
            "stdout": completed.stdout.decode("utf-8"),
            "stderr": completed.stderr.decode("utf-8")}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--benchmark-dir", type=Path,
                        default=ROOT.parent / "benchmark")
    args = parser.parse_args()
    benchmark = args.benchmark_dir.resolve()
    manifest = json.loads((benchmark / "source_manifest.json").read_text())
    normalizer_info = manifest["normalizer"]
    normalizer_path = benchmark / normalizer_info["local_file"]
    checked_read(normalizer_path, normalizer_info["sha256"])
    spec = importlib.util.spec_from_file_location("exploration_normalizer", normalizer_path)
    normalizer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(normalizer)

    by_file = {Path(item["local_file"]).name: item for item in manifest["programs"]}
    sources = {}
    baseline_receipts = {}
    for short in ("structural", "compact"):
        filename = "initializer_" + short + ".py"
        entry = by_file[filename]
        raw = checked_read(benchmark / entry["local_file"], entry["sha256"])
        sources[short] = raw.decode("utf-8")
        baseline_receipts[short] = {
            "file": entry["local_file"], "sha256": entry["sha256"],
            **normalizer.metrics(raw),
        }
    transformed = {
        "structural_open": open_stdin(sources["structural"]),
        "compact_open": open_stdin(sources["compact"]),
        "compact_unpack": unpack_major(sources["compact"]),
        "compact_unpack_open": open_stdin(unpack_major(sources["compact"])),
    }
    minima = {key: min(row["reported_metrics"][key] for row in manifest["programs"])
              for key in FIELDS}
    variants = []
    for name, expected_source in transformed.items():
        path = ROOT / (name + ".py")
        raw = path.read_bytes()
        if raw.decode("utf-8") != expected_source:
            raise ValueError("Variant differs from its stated source transformation: " + path.name)
        measured = normalizer.metrics(raw)
        measured_values = tuple(measured[key] for key in FIELDS)
        variants.append({"name": name, "file": path.name, **measured,
                         "matches_recorded_metrics": measured_values == RECORDED[name],
                         "strictly_below_all_coordinates": all(
                             measured[key] < minima[key] for key in FIELDS)})

    environment = dict(os.environ)
    environment["PYTHONUTF8"] = "1"
    environment["PYTHONIOENCODING"] = "utf-8:strict"
    probe = ("import json,sys; f=open(0); "
             "print(json.dumps({'stdin_encoding':sys.stdin.encoding,"
             "'stdin_errors':sys.stdin.errors,'open0_encoding':f.encoding,"
             "'open0_errors':f.errors,'utf8_mode':sys.flags.utf8_mode}))")
    observed = subprocess.run([sys.executable, "-X", "utf8", "-c", probe],
                              input=b"", capture_output=True, env=environment,
                              check=True, timeout=15)
    encoding = json.loads(observed.stdout)
    if (encoding["stdin_encoding"].lower() != "utf-8"
            or encoding["open0_encoding"].lower() != "utf-8"
            or encoding["stdin_errors"] != "strict"
            or encoding["open0_errors"] != "strict"):
        raise ValueError("The controlled CLI encoding assumption was not established")

    cases_raw = (ROOT / "cli_cases.json").read_bytes()
    cases = json.loads(cases_raw)["cases"]
    if len(cases) != 13:
        raise ValueError("Unexpected regression case count")
    original = benchmark / by_file["initializer_compact.py"]["local_file"]
    candidate = ROOT / "compact_unpack_open.py"
    comparisons = []
    for case in cases:
        if "source_sha256" in case and sha256(case["input_text"].encode("utf-8")) != case["source_sha256"]:
            raise ValueError("A copied public example changed: " + case["name"])
        first = cli(original, case["input_text"], environment)
        second = cli(candidate, case["input_text"], environment)
        expected = case["expected_accept"]
        if first != second:
            raise ValueError("CLI results disagree on " + case["name"])
        wanted_code = 0 if expected else 1
        wanted_text = "ACCEPT\n" if expected else "REJECT\n"
        if second["exit_code"] != wanted_code or second["stdout"] != wanted_text or second["stderr"]:
            raise ValueError("Unexpected CLI verdict on " + case["name"])
        comparisons.append({"name": case["name"], "expected_accept": expected,
                            "same_result": True, "result": second})

    result = {
        "python": platform.python_version(), "implementation": platform.python_implementation(),
        "normalizer_sha256": normalizer_info["sha256"],
        "reference_coordinate_envelope": minima,
        "baseline_sources": baseline_receipts, "variants": variants,
        "encoding_configuration": {"python_options": ["-X", "utf8"],
                                   "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8:strict",
                                   "observed": encoding},
        "regression": {"case_file": "cli_cases.json", "case_file_sha256": sha256(cases_raw),
                       "case_count": len(cases), "process_runs": 2 * len(cases),
                       "reference": "../benchmark/checkers/initializer_compact.py",
                       "candidate": candidate.name, "all_passed": True,
                       "cases": comparisons},
        "scope": ("Four complete source variants, not the new K theory. "
                  "No candidate is strictly below all three reference coordinates. "
                  "The 13 CLI cases are finite regression evidence. "
                  "Input-wrapper equivalence assumes identical UTF-8 text decoding; "
                  "arbitrary byte/environment behavior is not claimed identical."),
    }
    (ROOT / "results.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"variants": {row["name"]: {key: row[key] for key in FIELDS}
                                     for row in variants},
                      "regression_cases": len(cases), "all_passed": True}, indent=2))


if __name__ == "__main__":
    main()
