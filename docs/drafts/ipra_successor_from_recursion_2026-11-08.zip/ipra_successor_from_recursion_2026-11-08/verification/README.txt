SYMBOLIC CERTIFICATES FOR SHIFTED RECURSION
=========================================

Purpose
-------
These files check the short equational part of the new construction.  They
are not a complete iPRA proof checker, a proof of the full interpretation
theorem, or a contender in the minimum-checker comparison.  Acceptance is
based on explicit equations and proof rules, not numerical sampling.

Reproduce
---------
  python3 make_certificates.py
  python3 check_equations.py < equations.json
  python3 run_checks.py

make_certificates.py is an untrusted producer.  It does not import the
checker.  check_equations.py is the independent checker and its entire
equational trust boundary.  run_checks.py calls the public checker process,
both normally and with Python's -O flag, on the valid certificate and 21
deterministic rejection controls.  verification.json records the results.

Mathematical basis
------------------
For each fixed closed binary update h(r,u), the symbol K_h is binary and has
the two computation axioms

  K_h(0,a)       = sigma(a),
  K_h(sigma(n),a)= h(n,K_h(n,a)).

Only zero and the staged K constructors are primitive numerical syntax.
Let pi(r,u)=r.  The common row/column construction is

  sigma(a) = K_pi(0,a),       Q(n) = K_pi(n,0).

Thus Q(sigma(n))=n is a definition followed by one successor computation.
Q(0)=sigma(0); Q is a left inverse, not the usual predecessor at zero.

For a fixed binary h, define

  lift_h(r,u) = sigma(h(r,Q(u))),
  R_h(n,a)    = Q(K_lift_h(n,a)).

The certificate proves

  R_h(0,a)=a,
  R_h(sigma(n),a)=h(n,R_h(n,a)).

The proof is the cancellation Q(sigma(x))=x applied to both defining rows
of K.  No induction is used.  The displayed h is an opaque fixed binary
operation in the certificate.  It is a metatheoretic placeholder for each
fixed admissible closed binary term, not a quantified program code or a
universal evaluator.  Consequently this certificate verifies exactly the
closed-update instance of the conjugation lemma.  Parameterized variants
are addressed by the mathematical report, not silently identified here.

For pi(r,u)=r, put

  P(n) = R_pi(n,0).

The certificate also proves P(0)=0 and P(sigma(n))=n.  An explicit contextual
proof derives m=n from the hypothesis sigma(m)=sigma(n).

For the constant-zero update put Z(n)=K_zero(n,0).  Its two equations are

  Z(0)=sigma(0),             Z(sigma(n))=0.

They yield 0=sigma(0) from the hypothesis sigma(n)=0.  With the separate
falsity bridge 0=sigma(0) -> false, this gives successor separation.  The
falsity bridge and intuitionistic logic are not implemented by this
equational checker; the conditional equation itself is checked.

Dependency order
----------------
  K_pi -> sigma, Q
  sigma, Q, fixed h -> K_lift_h -> R_h
  sigma -> K_lift_pi -> R_pi -> P
  constant zero -> K_zero -> Z

Every K update has exactly the two permitted formal slots (counter, state)
and may call only earlier function symbols.  Every abbreviation has its
stated finite arity, may call only earlier symbols, and has no free proof
variables.  The declaration checker enforces these properties.

Proof language and scope
------------------------
Terms are JSON trees:
  ["zero"]           zero;
  ["v", "n"]         a free variable in the theorem's explicit variable list;
  ["b", 0], ["b", 1] counter/state slots, in a declaration body only;
  ["f", t1, ...]     a declared function applied at its exact arity.

The proof rules are K0, KS, definition unfolding, reflexivity, symmetry,
transitivity, congruence, explicit hypothesis, and use of a previously
checked lemma with a simultaneous variable substitution.  All references
must point backwards.  A lemma's context must be supplied by explicit
premises: conditional successor injectivity cannot be used as an
unconditional equality.  Unknown rules, symbols, variables and excess
fields are rejected.

There are no binders inside proof terms: binding is confined to staged
function declarations.  Substitution inserts each image once and never
substitutes inside the newly inserted image.  Closed bodies reject free
variables and out-of-range slots, preventing capture by construction.
Negative controls test those restrictions, escaping bound slots in goals,
forward symbols and proof nodes, undischarged hypotheses, wrong arities,
forged equations, altered successor definitions, and malformed input.

What is trusted
---------------
The checker implements the two displayed K axioms and standard equational
logic.  Its soundness follows by induction on the declaration list and
proof-node list: definitions are staged term abbreviations, every axiom
instance is constructed from its schema, and every other node is one of
the stated equality rules.  A lemma carries its hypotheses explicitly.
Python and the standard JSON parser are the execution platform.  No
assert statement controls acceptance and no input is executed as code.

The certificate contains 12 theorems with 61 proof nodes.  Their variables
are arbitrary elements of any model of the displayed computation axioms;
these are symbolic proofs, including nonstandard inputs where applicable.
The checker does not verify equation induction, Boolean range, arithmetic
function completeness, logical reconstruction, or bi-interpretability.
Those claims, and the choice of the intended iPRA theory, remain written
mathematical obligations in the main report.
