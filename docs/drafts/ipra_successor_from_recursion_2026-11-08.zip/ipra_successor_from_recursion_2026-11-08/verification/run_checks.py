#!/usr/bin/env python3
"""Replay the proof packet and rejection controls through the public CLI."""
import copy
import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
CHECKER = ROOT / "check_equations.py"


def run(value, optimized=False, raw=False):
    command = [sys.executable, *(["-O"] if optimized else []), str(CHECKER)]
    completed = subprocess.run(command, input=value if raw else json.dumps(value),
                               text=True, capture_output=True, timeout=15)
    try:
        result = json.loads(completed.stdout)
    except ValueError:
        raise RuntimeError("checker did not return a JSON result: " + completed.stderr)
    if completed.returncode not in (0, 1):
        raise RuntimeError("checker terminated unexpectedly: " + completed.stderr)
    if result.get("accepted") != (completed.returncode == 0):
        raise RuntimeError("checker result and exit status disagree")
    return result


def main():
    packet = json.loads((ROOT / "equations.json").read_text(encoding="utf-8"))
    mutations = []

    def add(name, mutate):
        value = copy.deepcopy(packet)
        mutate(value)
        mutations.append((name, value, False))

    add("incorrect_final_equation", lambda p: p["theorems"][0]["goal"].__setitem__(1, ["sigma", ["v", "n"]]))
    add("forward_proof_reference", lambda p: p["theorems"][0]["proof"][2].__setitem__("left", 3))
    add("missing_hypothesis", lambda p: p["theorems"][2].__setitem__("context", []))
    add("lost_separation_hypothesis", lambda p: p["theorems"][-1].__setitem__("context", []))
    add("closed_update_free_variable", lambda p: p["declarations"][4].__setitem__("body", ["v", "n"]))
    add("closed_update_third_slot", lambda p: p["declarations"][4].__setitem__("body", ["b", 2]))
    add("boolean_slot_coordinate", lambda p: p["declarations"][4].__setitem__("body", ["b", True]))
    add("future_declaration_reference", lambda p: p["declarations"][4].__setitem__("body", ["R_h", ["b", 0], ["b", 1]]))
    add("recursive_declaration", lambda p: p["declarations"][4].__setitem__("body", ["K_lift_h", ["b", 0], ["b", 1]]))
    add("wrong_update_arity", lambda p: p["declarations"][4].__setitem__("body", ["h", ["b", 0]]))
    add("altered_successor_definition", lambda p: p["declarations"][1].__setitem__("body", ["K_counter", ["b", 0], ["zero"]]))
    add("schema_applied_to_opaque_symbol", lambda p: p["theorems"][0]["proof"][1].__setitem__("symbol", "h"))
    add("unavailable_free_variable", lambda p: p["theorems"][0]["proof"][1].__setitem__("counter", ["v", "z"]))
    add("bound_slot_escape", lambda p: p["theorems"][0]["proof"][1].__setitem__("counter", ["b", 0]))
    add("unsupported_rule", lambda p: p["theorems"][0]["proof"][0].__setitem__("rule", "oracle"))
    add("nonintegral_proof_reference", lambda p: p["theorems"][0]["proof"][2].__setitem__("right", 1.0))
    add("invalid_term_tree", lambda p: p["theorems"][0]["proof"][1].__setitem__("counter", "n"))
    add("empty_proof", lambda p: p["theorems"][0].__setitem__("proof", []))

    forged = {
        "name": "forged_injectivity_without_assumption", "variables": ["m", "n"],
        "context": [], "goal": [["v", "m"], ["v", "n"]],
        "proof": [{"rule": "lemma", "name": "successor_injective",
                   "substitution": {"m": ["v", "m"], "n": ["v", "n"]},
                   "premises": []}], "result": 0,
    }
    add("undischarged_lemma_context", lambda p: p["theorems"].append(forged))
    add("future_theorem_reference", lambda p: p["theorems"][3]["proof"][3].__setitem__("name", "P_succ"))
    mutations.append(("invalid_json", "[", True))

    results = {"positive": {}, "negative": [], "scope":
               "Symbolic equation certificates and CLI rejection controls; no finite-value testing."}
    for optimized in (False, True):
        mode = "python_O" if optimized else "python"
        positive = run(packet, optimized)
        if positive["accepted"] is not True:
            raise RuntimeError("the unmodified certificate was rejected")
        results["positive"][mode] = positive
        for name, value, raw in mutations:
            result = run(value, optimized, raw)
            if result["accepted"] is not False:
                raise RuntimeError("negative control accepted: " + name + " / " + mode)
            results["negative"].append({"name": name, "mode": mode, **result})
    results["summary"] = {"positive_runs": 2, "negative_cases": len(mutations),
                          "negative_runs": len(results["negative"]), "all_passed": True}
    (ROOT / "verification.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(results["summary"], indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
