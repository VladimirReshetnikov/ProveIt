#!/usr/bin/env python3
"""Untrusted producer of explicit shifted-recursion proof certificates.

This script deliberately does not import the checker.  Every produced proof
is independently reconstructed and checked by check_equations.py.
"""
import json
from pathlib import Path


Z = ["zero"]
def V(name): return ["v", name]
def B(slot): return ["b", slot]
def C(name, *arguments): return [name, *arguments]
def S(value): return C("sigma", value)
def Q(value): return C("Q", value)


class Proof:
    def __init__(self, name, variables, goal, context=()):
        self.data = {"name": name, "variables": variables,
                     "context": list(context), "goal": goal, "proof": []}

    def add(self, rule, **data):
        result = len(self.data["proof"])
        self.data["proof"].append({"rule": rule, **data})
        return result

    def definition(self, symbol, *arguments):
        return self.add("def", symbol=symbol, arguments=list(arguments))

    def cong(self, symbol, *premises):
        return self.add("cong", symbol=symbol, premises=list(premises))

    def chain(self, *premises):
        result = premises[0]
        for following in premises[1:]:
            result = self.add("trans", left=result, right=following)
        return result

    def lemma(self, name, **substitution):
        return self.add("lemma", name=name, substitution=substitution, premises=[])

    def finish(self, result):
        self.data["result"] = result
        return self.data


def produce():
    declarations = [
        {"kind": "iterator", "name": "K_counter", "body": B(0)},
        {"kind": "definition", "name": "sigma", "arity": 1,
         "body": C("K_counter", Z, B(0))},
        {"kind": "definition", "name": "Q", "arity": 1,
         "body": C("K_counter", B(0), Z)},
        {"kind": "opaque", "name": "h", "arity": 2},
        {"kind": "iterator", "name": "K_lift_h",
         "body": S(C("h", B(0), Q(B(1))))},
        {"kind": "definition", "name": "R_h", "arity": 2,
         "body": Q(C("K_lift_h", B(0), B(1)))},
        {"kind": "iterator", "name": "K_lift_counter", "body": S(B(0))},
        {"kind": "definition", "name": "R_counter", "arity": 2,
         "body": Q(C("K_lift_counter", B(0), B(1)))},
        {"kind": "definition", "name": "P", "arity": 1,
         "body": C("R_counter", B(0), Z)},
        {"kind": "iterator", "name": "K_zero", "body": Z},
        {"kind": "definition", "name": "Z", "arity": 1,
         "body": C("K_zero", B(0), Z)},
    ]
    theorems = []
    n, a, m = V("n"), V("a"), V("m")

    p = Proof("Q_succ", ["n"], [Q(S(n)), n])
    q = p.definition("Q", S(n))
    k = p.add("ks", symbol="K_counter", counter=n, initial=Z)
    theorems.append(p.finish(p.chain(q, k)))

    p = Proof("Q_zero", [], [Q(Z), S(Z)])
    q = p.definition("Q", Z)
    k = p.add("k0", symbol="K_counter", initial=Z)
    theorems.append(p.finish(p.chain(q, k)))

    p = Proof("successor_injective", ["m", "n"], [m, n], [[S(m), S(n)]])
    h = p.add("hyp", index=0)
    qh = p.cong("Q", h)
    qm = p.lemma("Q_succ", n=m)
    mq = p.add("sym", premise=qm)
    qn = p.lemma("Q_succ", n=n)
    theorems.append(p.finish(p.chain(mq, qh, qn)))

    p = Proof("R_zero", ["a"], [C("R_h", Z, a), a])
    r = p.definition("R_h", Z, a)
    k = p.add("k0", symbol="K_lift_h", initial=a)
    qk = p.cong("Q", k)
    qs = p.lemma("Q_succ", n=a)
    theorems.append(p.finish(p.chain(r, qk, qs)))

    p = Proof("R_succ", ["n", "a"],
              [C("R_h", S(n), a), C("h", n, C("R_h", n, a))])
    r = p.definition("R_h", S(n), a)
    k = p.add("ks", symbol="K_lift_h", counter=n, initial=a)
    qk = p.cong("Q", k)
    qs = p.lemma("Q_succ", n=C("h", n, Q(C("K_lift_h", n, a))))
    rn = p.definition("R_h", n, a)
    nr = p.add("sym", premise=rn)
    nn = p.add("refl", term=n)
    hr = p.cong("h", nn, nr)
    theorems.append(p.finish(p.chain(r, qk, qs, hr)))

    p = Proof("R_counter_zero", ["a"], [C("R_counter", Z, a), a])
    r = p.definition("R_counter", Z, a)
    k = p.add("k0", symbol="K_lift_counter", initial=a)
    qk = p.cong("Q", k)
    qs = p.lemma("Q_succ", n=a)
    theorems.append(p.finish(p.chain(r, qk, qs)))

    p = Proof("R_counter_succ", ["n", "a"], [C("R_counter", S(n), a), n])
    r = p.definition("R_counter", S(n), a)
    k = p.add("ks", symbol="K_lift_counter", counter=n, initial=a)
    qk = p.cong("Q", k)
    qs = p.lemma("Q_succ", n=n)
    theorems.append(p.finish(p.chain(r, qk, qs)))

    p = Proof("P_zero", [], [C("P", Z), Z])
    d = p.definition("P", Z)
    r = p.lemma("R_counter_zero", a=Z)
    theorems.append(p.finish(p.chain(d, r)))

    p = Proof("P_succ", ["n"], [C("P", S(n)), n])
    d = p.definition("P", S(n))
    r = p.lemma("R_counter_succ", n=n, a=Z)
    theorems.append(p.finish(p.chain(d, r)))

    p = Proof("Z_zero", [], [C("Z", Z), S(Z)])
    d = p.definition("Z", Z)
    k = p.add("k0", symbol="K_zero", initial=Z)
    theorems.append(p.finish(p.chain(d, k)))

    p = Proof("Z_succ", ["n"], [C("Z", S(n)), Z])
    d = p.definition("Z", S(n))
    k = p.add("ks", symbol="K_zero", counter=n, initial=Z)
    theorems.append(p.finish(p.chain(d, k)))

    p = Proof("successor_separation", ["n"], [Z, S(Z)], [[S(n), Z]])
    h = p.add("hyp", index=0)
    zh = p.cong("Z", h)
    zs = p.lemma("Z_succ", n=n)
    sz = p.add("sym", premise=zs)
    zz = p.lemma("Z_zero")
    theorems.append(p.finish(p.chain(sz, zh, zz)))

    return {"format": "shifted-recursion-equations-v1",
            "declarations": declarations, "theorems": theorems}


if __name__ == "__main__":
    destination = Path(__file__).with_name("equations.json")
    destination.write_text(json.dumps(produce(), indent=2) + "\n", encoding="utf-8")
    print(destination.name)
