#!/usr/bin/env python3
"""A small, explicit equational proof kernel for shifted recursion.

This is a proof artifact, not a proposed minimum iPRA checker.  It checks
finite proof trees using the two shifted-recursion computation schemas,
staged definitions, and ordinary equational inference.  No evaluations or
finite numerical tests are used to accept an equation.
"""
import json
import sys


ZERO = ["zero"]
PRELUDE = [
    {"kind": "iterator", "name": "K_counter", "body": ["b", 0]},
    {"kind": "definition", "name": "sigma", "arity": 1,
     "body": ["K_counter", ZERO, ["b", 0]]},
    {"kind": "definition", "name": "Q", "arity": 1,
     "body": ["K_counter", ["b", 0], ZERO]},
]


class Invalid(Exception):
    pass


def need(condition, message):
    if not condition:
        raise Invalid(message)


def fields(value, expected):
    need(type(value) is dict and set(value) == set(expected),
         "incorrect object fields")


def index(value, length):
    need(type(value) is int and 0 <= value < length,
         "out-of-scope, forward, or nonintegral reference")
    return value


def valid_name(value):
    return (type(value) is str and value.isascii()
            and value.isidentifier() and value not in {"zero", "v", "b"})


def check_term(term, signature, variables=(), bound=0):
    need(type(term) is list and len(term) > 0,
         "a term must be a nonempty JSON array")
    head = term[0]
    need(type(head) is str, "term head must be a symbol name")
    if head == "zero":
        need(term == ZERO, "zero has no arguments")
    elif head == "v":
        need(len(term) == 2 and type(term[1]) is str
             and term[1] in variables, "free-variable escape")
    elif head == "b":
        need(len(term) == 2, "a bound slot has one coordinate")
        index(term[1], bound)
    else:
        need(head in signature, "unknown or future function symbol")
        need(len(term) == signature[head]["arity"] + 1,
             "incorrect function arity")
        for child in term[1:]:
            check_term(child, signature, variables, bound)


def substitute_slots(term, arguments):
    # Arguments contain no bound slots.  Insert once, without traversing
    # the image: this is simultaneous substitution, not textual rewriting.
    if term[0] == "b":
        return arguments[term[1]]
    return [term[0], *[substitute_slots(x, arguments) for x in term[1:]]]


def substitute_variables(term, mapping):
    if term[0] == "v":
        return mapping[term[1]]
    return [term[0], *[substitute_variables(x, mapping) for x in term[1:]]]


def equation(value, signature, variables):
    need(type(value) is list and len(value) == 2,
         "an equation has two terms")
    for term in value:
        check_term(term, signature, variables)
    return value


def build_signature(declarations):
    need(type(declarations) is list and declarations[:len(PRELUDE)] == PRELUDE,
         "the explicit shifted-recursion prelude was altered")
    signature = {}
    for declaration in declarations:
        need(type(declaration) is dict, "invalid declaration")
        kind = declaration.get("kind")
        name = declaration.get("name")
        need(valid_name(name) and name not in signature,
             "invalid or redeclared symbol")
        if kind == "iterator":
            fields(declaration, ("kind", "name", "body"))
            arity = 2
            check_term(declaration["body"], signature, bound=2)
        elif kind in {"definition", "opaque"}:
            required = ("kind", "name", "arity")
            fields(declaration, required + (("body",) if kind == "definition" else ()))
            arity = declaration["arity"]
            need(type(arity) is int and arity >= 0, "invalid arity")
            if kind == "definition":
                check_term(declaration["body"], signature, bound=arity)
        else:
            raise Invalid("unknown declaration kind")
        signature[name] = {**declaration, "arity": arity}
    return signature


def verify_theorem(theorem, signature, previous):
    fields(theorem, ("name", "variables", "context", "goal", "proof", "result"))
    need(valid_name(theorem["name"]) and theorem["name"] not in previous,
         "invalid or repeated theorem name")
    variables = theorem["variables"]
    need(type(variables) is list and all(valid_name(v) for v in variables)
         and len(set(variables)) == len(variables), "invalid theorem variables")
    context = theorem["context"]
    need(type(context) is list, "invalid hypothesis list")
    for hypothesis in context:
        equation(hypothesis, signature, variables)
    goal = equation(theorem["goal"], signature, variables)
    proof = theorem["proof"]
    need(type(proof) is list and len(proof) > 0, "empty or invalid proof")
    done = []

    def term(value):
        check_term(value, signature, variables)
        return value

    def ref(value):
        return done[index(value, len(done))]

    def symbol(name, kind=None):
        need(type(name) is str and name in signature, "unknown symbol")
        declaration = signature[name]
        if kind is not None:
            need(declaration["kind"] == kind, "wrong declaration kind")
        return declaration

    for step in proof:
        need(type(step) is dict, "invalid proof node")
        rule = step.get("rule")
        if rule == "refl":
            fields(step, ("rule", "term"))
            value = term(step["term"])
            result = [value, value]
        elif rule == "hyp":
            fields(step, ("rule", "index"))
            result = context[index(step["index"], len(context))]
        elif rule == "def":
            fields(step, ("rule", "symbol", "arguments"))
            declaration = symbol(step["symbol"], "definition")
            arguments = step["arguments"]
            need(type(arguments) is list and len(arguments) == declaration["arity"],
                 "wrong definition argument count")
            for value in arguments:
                term(value)
            result = [[step["symbol"], *arguments],
                      substitute_slots(declaration["body"], arguments)]
        elif rule == "k0":
            fields(step, ("rule", "symbol", "initial"))
            symbol(step["symbol"], "iterator")
            initial = term(step["initial"])
            result = [[step["symbol"], ZERO, initial], ["sigma", initial]]
        elif rule == "ks":
            fields(step, ("rule", "symbol", "counter", "initial"))
            declaration = symbol(step["symbol"], "iterator")
            counter, initial = term(step["counter"]), term(step["initial"])
            recursive = [step["symbol"], counter, initial]
            result = [[step["symbol"], ["sigma", counter], initial],
                      substitute_slots(declaration["body"], [counter, recursive])]
        elif rule == "sym":
            fields(step, ("rule", "premise"))
            left, right = ref(step["premise"])
            result = [right, left]
        elif rule == "trans":
            fields(step, ("rule", "left", "right"))
            left, middle = ref(step["left"])
            other, right = ref(step["right"])
            need(middle == other, "transitivity middle terms differ")
            result = [left, right]
        elif rule == "cong":
            fields(step, ("rule", "symbol", "premises"))
            declaration = symbol(step["symbol"])
            premises = step["premises"]
            need(type(premises) is list and len(premises) == declaration["arity"],
                 "wrong congruence arity")
            equations = [ref(p) for p in premises]
            result = [[step["symbol"], *[p[0] for p in equations]],
                      [step["symbol"], *[p[1] for p in equations]]]
        elif rule == "lemma":
            fields(step, ("rule", "name", "substitution", "premises"))
            name = step["name"]
            need(type(name) is str and name in previous, "unknown or future theorem")
            lemma = previous[name]
            mapping = step["substitution"]
            fields(mapping, lemma["variables"])
            for value in mapping.values():
                term(value)
            required = [[substitute_variables(t, mapping) for t in p]
                        for p in lemma["context"]]
            premises = step["premises"]
            need(type(premises) is list and len(premises) == len(required),
                 "a lemma hypothesis was not discharged")
            need([ref(p) for p in premises] == required, "wrong lemma hypotheses")
            result = [substitute_variables(t, mapping) for t in lemma["goal"]]
        else:
            raise Invalid("unsupported proof rule")
        equation(result, signature, variables)
        done.append(result)
    need(ref(theorem["result"]) == goal, "final equation differs from stated goal")
    return len(done)


def verify(packet):
    fields(packet, ("format", "declarations", "theorems"))
    need(packet["format"] == "shifted-recursion-equations-v1", "unknown format")
    signature = build_signature(packet["declarations"])
    need(type(packet["theorems"]) is list and packet["theorems"], "no theorems")
    previous, counts = {}, {}
    for theorem in packet["theorems"]:
        count = verify_theorem(theorem, signature, previous)
        previous[theorem["name"]] = theorem
        counts[theorem["name"]] = count
    return {"accepted": True, "theorems": counts,
            "proof_nodes": sum(counts.values()), "declarations": len(signature)}


def main():
    try:
        result = verify(json.load(sys.stdin))
    except (Invalid, ValueError, TypeError, KeyError, IndexError, RecursionError) as error:
        print(json.dumps({"accepted": False, "reason": str(error)}))
        return 1
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
