#!/usr/bin/env python3
"""Package the current deliverable and write its payload integrity manifest."""
from pathlib import Path
import hashlib
import zipfile


ROOT = Path(__file__).resolve().parent
EXCLUDED_DIRS = {"build", "__pycache__"}
EXCLUDED_NAMES = {
    "SHA256SUMS", "report.aux", "report.log", "report.out", "report.toc",
    "report.fls", "report.fdb_latexmk", "report.synctex.gz",
}


def payload():
    return sorted(
        path for path in ROOT.rglob("*")
        if path.is_file()
        and not EXCLUDED_DIRS.intersection(path.relative_to(ROOT).parts)
        and path.name not in EXCLUDED_NAMES
        and path.suffix != ".pyc"
    )


def main():
    files = payload()
    hashes = {
        path.relative_to(ROOT).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in files
    }
    manifest = ROOT / "SHA256SUMS"
    manifest.write_text("".join(f"{digest}  {name}\n" for name, digest in hashes.items()),
                        encoding="utf-8")
    target = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(files + [manifest]):
            archive.write(path, (Path(ROOT.name) / path.relative_to(ROOT)).as_posix())
    with zipfile.ZipFile(target) as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP CRC validation failed")
        for name, digest in hashes.items():
            member = (Path(ROOT.name) / name).as_posix()
            if hashlib.sha256(archive.read(member)).hexdigest() != digest:
                raise ValueError("ZIP payload hash differs: " + name)
    print(f"Created {target.name}: {len(files) + 1} files; CRC and payload hashes verified.")


if __name__ == "__main__":
    main()
