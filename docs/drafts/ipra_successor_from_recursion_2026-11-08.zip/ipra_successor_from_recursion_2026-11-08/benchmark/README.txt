REPRODUCIBLE COMPARISON OF THE RETAINED COMPLETE CHECKERS
=======================================================

Current repository boundary:
  VladimirReshetnikov/ProveIt
  docs/drafts at 9773e5e0376fdaf953567d0e1e6f19570d566bc6
  Six active ZIP archives, all downloaded and matched to their Git blob hashes.

Original boundary of the retained complete programs:
  docs/drafts at 06e097f723c659030816e0194e5eb7e8c607ba9b
  Twelve root checker programs retained as exact nested source copies in the
  current Boolean-gluing report. The current six archives introduce no new
  claimed competitive complete checker. Their larger exploratory prototypes
  are not represented as new record-size validated programs.

CONTENTS
--------
checkers/
  Twelve exact complete Python source files, renamed locally for readability.
  File bytes are unchanged; individual SHA-256 values are in source_manifest.json.
inherited_measure_current.py
  Unchanged measurement implementation from the current Boolean-gluing report.
  Its own SHA-256 is checked before importing its metrics function.
run_measurements.py
  New small orchestration script: validates sources and reproduces measurements.
source_manifest.json
  Both pinned commits, all six current ZIP names and repository paths, their
  byte sizes, Git blob SHA-1 and SHA-256 values, original/retained source members,
  the normalizer identity, and the original published source metrics.
results/measurements.json
  Complete current reproduction receipt, including imports and exact source hashes.
results/comparison_table.tex
  Portable TeX table for inclusion in the report (requires booktabs).
provenance/
  Inherited MIT No Attribution license, unchanged historical attribution notices,
  and the earlier twelve-archive manifest. Historical notices describe their
  original packages, not new work in this investigation.

REPRODUCE
---------
From this directory, with Python 3.12 for exact agreement with the pinned AST
and ast.unparse behavior:

  python3 run_measurements.py

No network is used. The script parses every checker as source data and does
not import or execute any checker. Its reported minima are full-program
measurements including imports, parser, validation, and ACCEPT/REJECT driver.
Genuine docstrings and comments are omitted; ast.unparse normalizes formatting.
The shared Python runtime and standard library are outside this inherited
source-size convention. No imported project-specific proof module is hidden.

If the six original ZIPs have separately been downloaded, optionally recheck
their exact payloads against the receipt:

  python3 run_measurements.py --archives-dir /absolute/path/to/zip/files

The ZIP payloads are deliberately not bundled a second time. Their manifest
identities are retrieval evidence; the default offline run cannot rehash bytes
that are not included. The optional argument provides that stronger check.

The expected coordinate minima are 317 normalized tokens, 348 AST nodes, and
885 normalized bytes. The first two are attained by initializer_structural.py
(317/348/908); the byte minimum is attained by initializer_compact.py
(318/352/885). No individual retained program attains all three coordinates.
These are observed corpus minima, not mathematical lower bounds.

This comparison does not prove those programs sound or complete. It does not
serve as a proof checker for the new paper, and it makes no new size-record
claim. The inherited programs retain the mathematical and validation status
described by their original reports.

ATTRIBUTION
-----------
The twelve programs and inherited measurement implementation are from the
ProveIt drafts identified above, under the preserved MIT No Attribution license.
Only the portable manifest, comparison orchestration, and this explanation
are new here. No baseline source code has been altered to lower its count.
