#!/usr/bin/env python3
"""Verify pinned source hashes and measure retained complete iPRA checkers.

This program parses source as data. It never executes a proof checker.
The inherited normalizer is imported only after its SHA-256 is verified.
All paths are relative to this portable comparison directory.
"""

import argparse
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import sys


ROOT = Path(__file__).resolve().parent
FIELDS = ("normalized_tokens", "ast_nodes", "normalized_bytes")
sys.dont_write_bytecode = True


def checked_bytes(path, expected_hash):
    raw = path.read_bytes()
    actual = hashlib.sha256(raw).hexdigest()
    if actual != expected_hash:
        raise ValueError(f"SHA-256 mismatch: {path.name}")
    return raw


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--archives-dir", type=Path,
        help="Optionally recheck the six downloaded current ZIPs; not required offline.",
    )
    args = parser.parse_args()
    manifest = json.loads((ROOT / "source_manifest.json").read_text())
    normalizer = manifest["normalizer"]
    metric_path = ROOT / normalizer["local_file"]
    checked_bytes(metric_path, normalizer["sha256"])
    spec = importlib.util.spec_from_file_location("inherited_measure_current", metric_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    programs = []
    for source in manifest["programs"]:
        path = ROOT / source["local_file"]
        raw = checked_bytes(path, source["sha256"])
        parsed = ast.parse(raw.decode("utf-8"))
        imports = [ast.unparse(node) for node in ast.walk(parsed)
                   if isinstance(node, (ast.Import, ast.ImportFrom))]
        for node in ast.walk(parsed):
            if isinstance(node, ast.ImportFrom):
                raise ValueError(f"Unexpected from-import in {path.name}")
            if isinstance(node, ast.Import):
                if any(alias.name not in {"json", "sys"} for alias in node.names):
                    raise ValueError(f"Unexpected import in {path.name}")
        measured = module.metrics(raw)
        programs.append({**source, **measured, "imports": imports,
                         "matches_pinned_metrics": all(
                             measured[k] == source["reported_metrics"][k] for k in FIELDS
                         )})

    if len(programs) != manifest["retained_program_count"] or len(programs) != 12:
        raise ValueError("Unexpected retained source inventory")
    observed_files = {str(p.relative_to(ROOT)) for p in (ROOT / "checkers").glob("*.py")}
    if observed_files != {p["local_file"] for p in programs}:
        raise ValueError("A source was added or omitted from the manifest")

    archive_checks = []
    if args.archives_dir is not None:
        for entry in manifest["current_archives"]:
            path = args.archives_dir / entry["file_name"]
            if not path.is_file():
                path = args.archives_dir / entry["file_name"].replace("(1)", "_variant1")
            raw = checked_bytes(path, entry["sha256"])
            blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
            if blob != entry["git_blob_sha1"] or len(raw) != entry["size_bytes"]:
                raise ValueError(f"Git blob or size mismatch: {entry['file_name']}")
            archive_checks.append({"file_name": entry["file_name"], "verified": True})

    minima = {key: min(row[key] for row in programs) for key in FIELDS}
    pareto = [row["label"] for row in programs if not any(
        all(other[key] <= row[key] for key in FIELDS)
        and any(other[key] < row[key] for key in FIELDS)
        for other in programs
    )]
    result = {
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "current_commit": manifest["current_commit"],
        "original_checker_commit": manifest["original_checker_commit"],
        "current_archive_count": len(manifest["current_archives"]),
        "retained_program_count": len(programs),
        "coordinate_minima": minima,
        "minimum_attainers": {
            key: [row["label"] for row in programs if row[key] == minima[key]]
            for key in FIELDS
        },
        "pareto_programs": pareto,
        "all_source_hashes_verified": True,
        "normalizer_sha256_verified": normalizer["sha256"],
        "all_pinned_metrics_reproduced": all(r["matches_pinned_metrics"] for r in programs),
        "checker_programs_executed": False,
        "optional_current_archive_checks": archive_checks,
        "archive_verification_note": (
            "Six outer ZIP blob hashes and SHA-256 values were checked at retrieval. "
            "ZIPs are not bundled. The optional --archives-dir switch rechecks them."
        ),
        "scope": manifest["scope"],
        "programs": programs,
    }
    output = ROOT / "results"
    output.mkdir(exist_ok=True)
    (output / "measurements.json").write_text(json.dumps(result, indent=2) + "\n")
    lines = [
        "% Generated by benchmark/run_measurements.py; complete programs only.",
        r"\begin{tabular}{lrrr}", r"\toprule",
        r"Retained program & Tokens & AST nodes & Bytes \\", r"\midrule",
    ]
    for row in programs:
        lines.append(f"{row['label']} & {row['normalized_tokens']} & "
                     f"{row['ast_nodes']} & {row['normalized_bytes']} " + r"\\")
    lines.extend([
        r"\midrule",
        f"Coordinate minima & {minima['normalized_tokens']} & {minima['ast_nodes']} & "
        f"{minima['normalized_bytes']} " + r"\\",
        r"\bottomrule", r"\end{tabular}", "",
    ])
    (output / "comparison_table.tex").write_text("\n".join(lines))
    print(json.dumps({key: result[key] for key in (
        "python", "current_commit", "original_checker_commit", "current_archive_count",
        "retained_program_count", "coordinate_minima", "pareto_programs",
        "all_source_hashes_verified", "all_pinned_metrics_reproduced",
        "checker_programs_executed", "optional_current_archive_checks",
    )}, indent=2))


if __name__ == "__main__":
    main()
