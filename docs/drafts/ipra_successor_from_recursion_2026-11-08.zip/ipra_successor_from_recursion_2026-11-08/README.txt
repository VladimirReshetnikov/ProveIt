SUCCESSOR FROM RECURSION
=======================
A one-constructor presentation of intuitionistic primitive recursive arithmetic
Prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific date)

START HERE
----------
report.pdf is the complete mathematical report. Its editable source is
report.tex together with sections/*.tex and the benchmark table.

RESULT AND HONEST LIMIT
----------------------
This report proves a whole-domain bi-interpretation with full intuitionistic
first-order PRA using zero and one shifted recursion constructor. Successor
is a derived term, and every update is a fixed closed binary description
reading only its counter and state. Both interpretation composites are
internally the identity.

For the counter projection pi(r,u)=r, put

  sigma(a)=K_pi(0,a),     Q(n)=K_pi(n,0).

The two computation schemas are

  K_h(0,a)=sigma(a),
  K_h(sigma(n),a)=h(n,K_h(n,a)).

They immediately give Q(sigma(n))=n. For each fixed closed binary h, put

  lift_h(r,u)=sigma(h(r,Q(u))),
  R_h(n,a)=Q(K_lift_h(n,a)).

Then R_h(0,a)=a and R_h(sigma(n),a)=h(n,R_h(n,a)), using no induction or
Boolean case analysis. Ordinary predecessor is R_pi(n,0). The full report
lists every logical and nonlogical axiom and rule, derives quantifier-free
induction and pairing, and supplies the parameter-packing compiler.

A second theorem proves global equational conservativity of the Boolean
completion: Boolean range and the falsity bridge can be eliminated from
arbitrary proofs of equational sequents, including proofs with quantified
and implicational intermediate formulas. The local quotient-gluing step is
inherited from the current drafts; the added normalization argument extends
it to arbitrary equational proofs. This does not remove those principles
from the full first-order theory.

The requested strict complete-checker improvement is NOT established.
The retained benchmark is 317 normalized tokens / 348 AST nodes / 885 bytes,
with different programs attaining the coordinate minima. Removing primitive
successor from the arithmetic signature does not automatically shrink a
checker whose syntax already shares successor with a logical closure. The
new counter/state update also requires distinct substitutions. No globally
simplest axiomatization or historical priority claim is made.

PROOF AND VERIFICATION SCOPE
----------------------------
The mathematical equivalence and conservativity results are written proofs.
They have not been formalized in Lean or Rocq.

verification/check_equations.py independently replays the supplied symbolic
equational certificate: 12 theorems, 61 proof nodes. Both normal and -O Python
accept it. Twenty-one rejection controls are run in both modes (42 negative
runs). The checker uses no finite numerical sampling, induction, imported
theorem prover, or execution of input as code. Its exact trust boundary and
limitations are in verification/README.txt. It is NOT a full iPRA checker
and is NOT entered in the source-size comparison.

benchmark/ contains twelve exact retained complete-checker sources, the
unchanged inherited normalizer, complete provenance, and reproduced metrics.
The source-measurement script never executes the proof checkers. Measuring
their source is not an independent correctness proof of those programs.

exploration/ records a separate implementation experiment on the inherited
complete checker. Equivalent input/dispatch changes reach 313 normalized
tokens and 347 AST nodes, but require 922 normalized bytes. This lowers two
coordinates and misses the 885-byte benchmark. These variants retain the old
calculus; they are not direct checkers for the new shifted-recursion syntax.
Their source equivalence argument, exact measurements, and CLI regression
controls are supplied separately. Identifier shortening is not credited.

REPRODUCE
---------
With Python 3.12 (3.12.14 was used for the recorded exact measurements):

  python3 reproduce.py

This needs only the standard library and no network. To regenerate the
symbolic certificate before replaying it:

  python3 verification/make_certificates.py
  python3 reproduce.py

To rebuild the PDF with pdflatex and standard TeX Live packages:

  make pdf

To verify the original delivered payload before regeneration:

  sha256sum -c SHA256SUMS

To package the current files after intentional changes:

  python3 package.py

This refreshes SHA256SUMS and creates a ZIP beside this directory. It does
not reprove the mathematics or rebuild the PDF.

CONTENTS
--------
report.pdf, report.tex, sections/  Complete mathematical report and source
verification/                    Symbolic certificate, producer, checker,
                                 rejection controls, and exact scope notes
benchmark/                       Pinned complete source comparison
exploration/                     Equivalent checker implementation tradeoffs
results/                         Reproduction and PDF validation receipts
provenance/                      Contribution boundary and source snapshot
reproduce.py, Makefile,
build_pdf.py, package.py         Reproduction, PDF build, and ZIP packaging
SHA256SUMS                       Integrity manifest for other payload files

REFERENCE SNAPSHOT
------------------
Repository: VladimirReshetnikov/ProveIt
Current commit: 9773e5e0376fdaf953567d0e1e6f19570d566bc6
Current directory: docs/drafts (six active archives)
Retained complete checkers originally from:
  06e097f723c659030816e0194e5eb7e8c607ba9b (twelve archives)

All six current ZIP payloads were checked against their Git blob IDs and
SHA-256 digests. Their exact identities and source member paths are retained
in benchmark/source_manifest.json. No repository files were changed.
