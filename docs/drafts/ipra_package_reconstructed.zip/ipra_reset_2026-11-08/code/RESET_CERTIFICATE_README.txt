SYMBOLIC CERTIFICATES FOR THE RESET-PREMISE EQUIVALENCE
====================================================

This is a limited independent symbolic proof artifact. It is NOT a complete
iPRA checker, NOT a formal verification of the complete report, and NOT an
entry in the complete-checker source-size comparison.

What is proved
--------------
For an arbitrary binary numerical function symbol f, with parameter p,
write R(z,p)=D(f(z,p),Sz,0). The three exact closed exported theorems are:

1. For every p,
   [forall z, f(R(z,p),p)=0] implies
   [f(0,p)=0 and forall z, (f(z,p)=0 implies f(Sz,p)=0)].

2. For every p, the converse implication.

3. For every p, the conjunction of those two implications.

These are symbolic first-order derivations, not evaluations at finitely many
natural numbers. They use 20, 22, and 42 proof-tree nodes respectively. The
third claim repeats the first two directions under one parameter binder, so
the aggregate node count 84 includes that repetition.

Every claim is checked from an empty local hypothesis context and closes p.
Consequently it remains usable with arbitrary retained assumptions Gamma by
weakening and implication elimination. The proof of equivalence of the RESET
inference rule with contextual zero-equation induction is in the report; this
artifact certifies the logical equivalence of its universal premise with the
ordinary base-and-progress premises. It does not implement either induction
rule as a trusted certificate rule.

Exact trust boundary
--------------------
This certificate uses zero, unary S, binary f, and ternary D. The shared
logical engine additionally recognizes C, sg, and w for the separately
configured anchored-reflection artifact; no extra arithmetic axiom or
inference is thereby enabled in this certificate profile.
Equality is actual equality. The only nonlogical axiom schemas accepted by
the replayer, with arbitrary numerical terms substituted, are:

  zero_dec:   v=0 or (v=0 -> bottom)
  D_zero:     v=0 -> D(v,a,b)=a
  D_nonzero:  (v=0 -> bottom) -> D(v,a,b)=b

These schemas are explicit assumptions of this small artifact. The report
derives them from the PR equations, Boolean range, anchored reset, and Sep,
using its exact numerical equality test. Abs itself is derived there.
That derivation and the full PR
description grammar are NOT part of this replayer.

The logical rules are hypothesis, implication introduction/elimination,
conjunction introduction/elimination, disjunction elimination, universal
introduction/elimination, equality reflexivity/symmetry, and substitution in a
fixed formula motive. There is no explosion rule in the replayer and no
induction, stationarity, RESET rule, arithmetic evaluator, or theorem oracle.
Universal introduction checks the retained-context eigenvariable condition;
substitution avoids capture by fresh renaming. Branch hypotheses are local
and cannot escape. The exact expected exported formulas are fixed in the
replayer independently of the certificate's declarations.

Separation of producer and checker
---------------------------------
make_reset_certificate.py produces proof JSON without importing or invoking
the replayer. replay_reset_certificate.py derives every proof-node conclusion
from its premises. It never imports the producer and does not execute input
as code. verify_reset_certificates.py invokes the public checker CLI in normal
and optimized Python and builds focused damaged-certificate controls.

The finite executable checks do not prove that the Python replayer itself is
correct. Its small trusted rules and their implementation remain available
for inspection. No Lean or Rocq formalization is claimed.

Reproduce
---------
From the package root, using Python 3.10 or newer and the standard library:

  python3 code/make_reset_certificate.py
  python3 code/replay_reset_certificate.py
  python3 code/verify_reset_certificates.py

The last command writes evidence/reset_certificate_results.json. The receipt
contains exact source/certificate hashes, rule counts, normal and optimized
CLI results, and twelve rejection controls: unbound hypotheses, wrong selector
branch, unauthorized axiom, branch escape, captured eigenvariable, reversed
transport, changed motive, wrong universal instance, malformed term arity,
forged export, duplicate export, and a declared extra induction schema.

The expected outcome is two accepted positive CLI runs and 24 rejected
negative CLI runs. No certificate input is executed as Python code.
