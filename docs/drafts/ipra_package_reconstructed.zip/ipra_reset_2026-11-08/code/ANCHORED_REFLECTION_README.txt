EQUALITY REFLECTION FROM ONE ANCHORED RESET APPLICATION
=====================================================

Main result certified
---------------------
The producer and independent replayer verify the exact universally closed
equations and implications:

  d(a,a)=0;
  d(a,b)=0 -> a=b;
  a=b -> d(a,b)=0.

Here e(a,b)=sg(w(a,b)) and d(a,b)=C(e(a,a),e(a,b),0). The symbol w is an
opaque binary numerical function for this proof. In the report it is the
fixed PR term K(Sa dotminus b); no equation for w is needed in the reflection
derivation itself. The certificate uses ordinary symbolic terms and actual
equality, never numeric sampling or a finite approximation of the rule.

The proof has 13, 83, and 20 proof-tree nodes in its three claims, 116 in
total. The middle claim uses EXACTLY ONE instance of the anchored RESET
rule. The diagonal and reverse implication use none.

Trusted arithmetic rule
-----------------------
For one fixed finite numerical term template F(x), put

  rho_F(z)=C(d(F(z),F(1)),Sz,0),       1=S0.

The sole permitted arithmetic inference in this certificate profile is

  Gamma |- F(rho_F(z))=F(1)
  -------------------------- anchored_reset
  Gamma |- F(t)=F(1).

The checker reconstructs the entire premise from the SAME template F. It
checks that z is absent from Gamma, the target t, and every passive template
parameter. The numerical anchor F(1) is reconstructed and cannot be supplied
as a different function or an arbitrary certificate field.

This rule is an explicit TRUSTED inference of this partial checker. The
artifact certifies the deduction of reflection FROM the proposed rule;
it does not formally prove that rule admissible in iPRA. The report supplies
that separate ordinary equation-induction proof for the exact raw test.

Trusted fixed axioms
--------------------
Only the following schemas are accepted in this profile:

  BR:             sg(t)=0 or sg(t)=1;
  sg_zero:        sg(0)=0;
  sg_successor:   sg(St)=1;
  C_zero:         C(0,a,b)=a;
  C_successor:    C(St,a,b)=b.

They are the indicated inherited BR sentence and PR defining-equation
instances. There is NO Abs axiom, equality-reflection axiom, decidability
of actual numerical equality, separation axiom, numerical coverage, or
induction schema in this certificate profile. In particular, neither
reflection nor diagonal correctness is smuggled into the rule premises.

The logical engine
------------------
replay_anchored_reflection.py imports the ordinary symbolic natural-deduction
engine from replay_reset_certificate.py. It supplies its own fixed axiom
provider and the anchored arithmetic inference explicitly as trusted Python
functions. A certificate cannot choose or execute those functions. Shared
logical rules are equality reflexivity/symmetry/transport and the ordinary
first-order rules needed by the proof. All retained-context and branch-scope
checks remain active. No producer code is imported by either checker.

The shared engine recognizes additional function symbols needed by the two
certificate profiles, but the axiom inventories are kept separate. The old
zero-selector profile does not get an anchored RESET rule automatically.

Reproduce
---------
From the package root:

  python3 code/make_anchored_reflection.py
  python3 code/replay_anchored_reflection.py
  python3 code/verify_anchored_reflection.py

The last command writes evidence/anchored_reflection_results.json, including
source/certificate hashes, exact proof counts, and focused tamper controls.
Expected results: two accepted normal/optimized CLI runs and 24 rejected
negative runs (12 damaged certificates in both modes). Controls target
eigenvariable escape, changed F templates, forged premises, unauthorized
Abs/induction, equality motives, and exported theorem identity.

Scope limitation
----------------
This is NOT a full iPRA checker or a complete proof-checker size competitor.
It does not validate arbitrary PR descriptions, the target-iPRA proof of
the raw equality test, the whole quantifier-free characteristic compiler,
or the complete bi-interpretability theorem. The Python replayer itself is
not formally verified in Lean or Rocq. The written report and the limited
symbolic certificate establish different, explicitly separated claims.
