"""Independent symbolic replayer for the RESET-premise equivalence.

NOT a full iPRA proof checker and NOT a source-size competitor. Its default
certificate uses 0, S, a binary numerical f, and a ternary selector D. The
default nonlogical schemas are decidable actual zero and the two faithful
selector branches, printed in TRUSTED_AXIOMS below. Its shared logical engine
can be called with an explicit trusted profile by the separate anchored
reflection replayer. The default CLI has no induction or arithmetic rule,
numeric evaluator, imported theorem prover, exec, or eval operation.
"""
import json
import re
import sys
from collections import Counter
from pathlib import Path


TRUSTED_AXIOMS = {
    "zero_dec": "v=0 or (v=0 -> bottom)",
    "D_zero": "v=0 -> D(v,a,b)=a",
    "D_nonzero": "(v=0 -> bottom) -> D(v,a,b)=b",
}
TERM_ARITIES = {"zero": 0, "S": 1, "f": 2, "D": 3,
                "C": 3, "sg": 1, "w": 2}
CONNECTIVES = {"imp", "and", "or"}


class InvalidCertificate(ValueError):
    pass


def require(test, message):
    if not test:
        raise InvalidCertificate(message)


def identifier(value):
    return type(value) is str and re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", value) is not None


def term(value):
    require(type(value) is list and value and type(value[0]) is str, "Term must be a tagged array")
    tag = value[0]
    if tag == "var":
        require(len(value) == 2 and identifier(value[1]), "Malformed numerical variable")
    else:
        require(tag in TERM_ARITIES and len(value) == TERM_ARITIES[tag] + 1, "Numerical arity mismatch")
        for child in value[1:]:
            term(child)
    return value


def formula(value):
    require(type(value) is list and value and type(value[0]) is str, "Formula must be a tagged array")
    tag = value[0]
    if tag == "bottom":
        require(len(value) == 1, "Malformed bottom")
    elif tag == "eq":
        require(len(value) == 3, "Equation arity mismatch")
        term(value[1]); term(value[2])
    elif tag in CONNECTIVES:
        require(len(value) == 3, "Connective arity mismatch")
        formula(value[1]); formula(value[2])
    elif tag == "all":
        require(len(value) == 3 and identifier(value[1]), "Malformed universal binder")
        formula(value[2])
    else:
        raise InvalidCertificate("Unknown formula constructor")
    return value


def term_variables(value):
    if value[0] == "var":
        return {value[1]}
    result = set()
    for child in value[1:]:
        result |= term_variables(child)
    return result


def free_variables(value):
    tag = value[0]
    if tag == "bottom":
        return set()
    if tag == "eq":
        return term_variables(value[1]) | term_variables(value[2])
    if tag == "all":
        return free_variables(value[2]) - {value[1]}
    return free_variables(value[1]) | free_variables(value[2])


def all_names(value):
    result = free_variables(value)
    if value[0] == "all":
        return result | {value[1]} | all_names(value[2])
    if value[0] in CONNECTIVES:
        return result | all_names(value[1]) | all_names(value[2])
    return result


def substitute_term(value, variable, image):
    if value[0] == "var":
        return image if value[1] == variable else value
    return [value[0], *(substitute_term(x, variable, image) for x in value[1:])]


def substitute(value, variable, image):
    tag = value[0]
    if tag == "bottom":
        return value
    if tag == "eq":
        return [tag, substitute_term(value[1], variable, image),
                substitute_term(value[2], variable, image)]
    if tag in CONNECTIVES:
        return [tag, substitute(value[1], variable, image), substitute(value[2], variable, image)]
    bound, body = value[1], value[2]
    if bound == variable:
        return value
    if bound in term_variables(image) and variable in free_variables(body):
        used = all_names(body) | term_variables(image) | {variable, bound}
        new = bound + "_fresh"
        while new in used:
            new += "_fresh"
        body = substitute(body, bound, ["var", new])
        bound = new
    return ["all", bound, substitute(body, variable, image)]


def axiom(name, arguments):
    require(type(arguments) is list, "Axiom arguments must be an array")
    for argument in arguments:
        term(argument)
    zero = ["zero"]
    if name == "zero_dec":
        require(len(arguments) == 1, "zero_dec has one term argument")
        atom = ["eq", arguments[0], zero]
        return ["or", atom, ["imp", atom, ["bottom"]]]
    require(name in {"D_zero", "D_nonzero"}, "Unlicensed axiom schema")
    require(len(arguments) == 3, "Selector schema has three term arguments")
    v, a, b = arguments
    atom = ["eq", v, zero]
    if name == "D_zero":
        return ["imp", atom, ["eq", ["D", v, a, b], a]]
    return ["imp", ["imp", atom, ["bottom"]], ["eq", ["D", v, a, b], b]]


def extend(context, name, assumption):
    require(identifier(name) and name not in context, "Hypothesis name is invalid or already active")
    return {**context, name: assumption}


def replay(node, context, counts, axiom_provider=axiom, extension=None):
    require(type(node) is dict and type(node.get("rule")) is str, "Malformed proof node")
    rule = node["rule"]
    counts[rule] += 1
    def derive(proof, retained=None):
        return replay(proof, context if retained is None else retained, counts,
                      axiom_provider, extension)
    if rule == "hyp":
        require(node.get("name") in context, "Unbound hypothesis")
        return context[node["name"]]
    if rule == "axiom":
        return axiom_provider(node.get("name"), node.get("terms"))
    if rule == "imp_i":
        assumption = formula(node["assumption"])
        result = derive(node["proof"], extend(context, node["name"], assumption))
        return ["imp", assumption, result]
    if rule == "imp_e":
        major = derive(node["major"])
        minor = derive(node["minor"])
        require(major[0] == "imp" and major[1] == minor, "Implication antecedent mismatch")
        return major[2]
    if rule == "and_i":
        return ["and", derive(node["left"]), derive(node["right"])]
    if rule == "and_e":
        result = derive(node["proof"])
        side = node.get("side")
        require(type(side) is int and side in (0, 1) and result[0] == "and", "Invalid conjunction projection")
        return result[side + 1]
    if rule == "or_e":
        major = derive(node["major"])
        require(major[0] == "or", "Disjunction elimination major is not a disjunction")
        require(node["left_name"] != node["right_name"], "Branch names must be distinct")
        left = derive(node["left"], extend(context, node["left_name"], major[1]))
        right = derive(node["right"], extend(context, node["right_name"], major[2]))
        require(left == right, "Disjunction branches have different conclusions")
        return left
    if rule == "all_i":
        variable = node.get("variable")
        require(identifier(variable), "Invalid eigenvariable")
        require(all(variable not in free_variables(a) for a in context.values()),
                "Universal introduction eigenvariable occurs in retained context")
        result = derive(node["proof"])
        return ["all", variable, result]
    if rule == "all_e":
        result = derive(node["proof"])
        require(result[0] == "all", "Universal elimination major is not universal")
        image = term(node["term"])
        return substitute(result[2], result[1], image)
    if rule == "eq_sym":
        result = derive(node["proof"])
        require(result[0] == "eq", "Symmetry premise is not an equation")
        return ["eq", result[2], result[1]]
    if rule == "eq_e":
        equality = derive(node["equality"])
        result = derive(node["body"])
        require(equality[0] == "eq", "Equality transport premise is not an equation")
        variable = node.get("variable")
        require(identifier(variable), "Invalid equality motive variable")
        template = formula(node["template"])
        require(result == substitute(template, variable, equality[1]), "Equality transport source mismatch")
        return substitute(template, variable, equality[2])
    if rule == "eq_refl":
        value = term(node["term"])
        return ["eq", value, value]
    if extension is not None:
        return extension(node, context, derive)
    raise InvalidCertificate("Unlicensed inference rule: " + rule)


def expected_claims():
    z = ["var", "z"]
    p = ["var", "p"]
    zero = ["zero"]
    fz = ["f", z, p]
    fs = ["f", ["S", z], p]
    base = ["eq", ["f", zero, p], zero]
    step = ["all", "z", ["imp", ["eq", fz, zero], ["eq", fs, zero]]]
    ordinary = ["and", base, step]
    reset = ["all", "z", ["eq", ["f", ["D", fz, ["S", z], zero], p], zero]]
    forward = ["imp", reset, ordinary]
    backward = ["imp", ordinary, reset]
    return {
        "reset_implies_base_and_progress": ["all", "p", forward],
        "base_and_progress_imply_reset": ["all", "p", backward],
        "reset_premise_equivalence": ["all", "p", ["and", forward, backward]],
    }


def verify(certificate):
    require(type(certificate) is dict and certificate.get("format") == "reset-symbolic-nd-v1",
            "Unknown certificate format")
    require(certificate.get("trusted_axiom_schemas") == list(TRUSTED_AXIOMS),
            "Trusted axiom declaration mismatch")
    claims = certificate.get("claims")
    targets = expected_claims()
    require(type(claims) is list and len(claims) == len(targets), "Wrong number of exported claims")
    seen = set()
    rows = []
    for claim in claims:
        require(type(claim) is dict, "Malformed claim")
        name = claim.get("name")
        require(name in targets and name not in seen, "Unknown or duplicate exported claim")
        seen.add(name)
        declared = formula(claim["conclusion"])
        require(declared == targets[name], "Exported target changed")
        require(not free_variables(declared), "Exported theorem has a free variable")
        counts = Counter()
        derived = replay(claim["proof"], {}, counts)
        require(derived == declared, "Derived conclusion does not match exact exported target")
        rows.append({"name": name, "proof_nodes": sum(counts.values()), "rules": dict(sorted(counts.items()))})
    return {"accepted": True, "claims": rows, "proof_nodes": sum(r["proof_nodes"] for r in rows),
            "trusted_axioms": TRUSTED_AXIOMS,
            "scope": "Symbolic RESET-premise equivalence only; no iPRA induction or arithmetic evaluation."}


def main():
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name("reset_certificate.json")
    try:
        result = verify(json.loads(path.read_text(encoding="utf-8")))
    except (InvalidCertificate, KeyError, TypeError, IndexError, RecursionError, ValueError) as error:
        print(json.dumps({"accepted": False, "error": str(error)}))
        return 1
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
