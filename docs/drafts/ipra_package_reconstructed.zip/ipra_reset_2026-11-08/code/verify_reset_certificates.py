"""Replay the RESET certificate and focused rejection controls.

The producer is deliberately not imported. This harness invokes the public
replayer CLI in ordinary and optimized Python, so disabled assertions cannot
make an invalid certificate pass. No numerical sampling is used.
"""
import copy
import hashlib
import json
import platform
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT.parent


def nodes(value):
    if isinstance(value, dict):
        if "rule" in value:
            yield value
        for child in value.values():
            yield from nodes(child)
    elif isinstance(value, list):
        for child in value:
            yield from nodes(child)


def first(certificate, predicate):
    return next(node for node in nodes(certificate) if predicate(node))


def changed(original, mutation):
    result = copy.deepcopy(original)
    mutation(result)
    return result


def unbound_hypothesis(certificate):
    first(certificate, lambda n: n["rule"] == "hyp")["name"] = "never_assumed"


def wrong_selector_branch(certificate):
    first(certificate, lambda n: n.get("name") == "D_nonzero")["name"] = "D_zero"


def unauthorized_axiom(certificate):
    first(certificate, lambda n: n["rule"] == "axiom")["name"] = "arbitrary_equation"


def escaping_branch_assumption(certificate):
    node = first(certificate, lambda n: n["rule"] == "or_e")
    node["right"] = {"rule": "hyp", "name": node["left_name"]}


def captured_eigenvariable(certificate):
    node = first(certificate, lambda n: n["rule"] == "all_i" and n["variable"] == "z")
    node["variable"] = "p"


def reversed_transport(certificate):
    node = first(certificate, lambda n: n["rule"] == "eq_e")
    node["equality"] = {"rule": "eq_sym", "proof": node["equality"]}


def changed_motive(certificate):
    node = first(certificate, lambda n: n["rule"] == "eq_e")
    node["template"] = ["eq", ["var", "hole"], ["zero"]]


def wrong_universal_instance(certificate):
    node = first(certificate, lambda n: n["rule"] == "all_e")
    node["term"] = ["S", node["term"]]


def malformed_term(certificate):
    node = first(certificate, lambda n: n["rule"] == "axiom")
    node["terms"][0] = ["f", ["zero"]]


def wrong_export(certificate):
    certificate["claims"][0]["conclusion"] = ["eq", ["zero"], ["S", ["zero"]]]


def duplicate_claim(certificate):
    certificate["claims"][1] = copy.deepcopy(certificate["claims"][0])


def declared_induction(certificate):
    certificate["trusted_axiom_schemas"].append("induction")


MUTATIONS = [
    ("unbound_hypothesis", unbound_hypothesis),
    ("wrong_selector_branch", wrong_selector_branch),
    ("unauthorized_axiom", unauthorized_axiom),
    ("branch_assumption_escape", escaping_branch_assumption),
    ("captured_eigenvariable", captured_eigenvariable),
    ("reversed_equality_transport", reversed_transport),
    ("changed_equality_motive", changed_motive),
    ("wrong_universal_instance", wrong_universal_instance),
    ("malformed_function_arity", malformed_term),
    ("forged_exported_target", wrong_export),
    ("duplicate_exported_claim", duplicate_claim),
    ("unlicensed_induction_declaration", declared_induction),
]


def cli(path, optimized):
    command = [sys.executable]
    if optimized:
        command.append("-O")
    command += [str(ROOT / "replay_reset_certificate.py"), str(path)]
    result = subprocess.run(command, text=True, capture_output=True, check=False)
    payload = json.loads(result.stdout)
    return result.returncode, payload


def main():
    original_path = ROOT / "reset_certificate.json"
    original = json.loads(original_path.read_text(encoding="utf-8"))
    positives = []
    for optimized in (False, True):
        code, result = cli(original_path, optimized)
        if code != 0 or result.get("accepted") is not True:
            raise RuntimeError("Valid symbolic certificate rejected")
        positives.append({"optimized": optimized, "exit_code": code, "result": result})
    negatives = []
    with tempfile.TemporaryDirectory(prefix="reset-certificate-controls-") as directory:
        for name, mutation in MUTATIONS:
            path = Path(directory) / (name + ".json")
            path.write_text(json.dumps(changed(original, mutation)), encoding="utf-8")
            runs = []
            for optimized in (False, True):
                code, result = cli(path, optimized)
                if code != 1 or result.get("accepted") is not False:
                    raise RuntimeError("Damaged symbolic certificate accepted: " + name)
                runs.append({"optimized": optimized, "exit_code": code, "error": result.get("error")})
            negatives.append({"name": name, "rejected": True, "runs": runs})
    files = ["make_reset_certificate.py", "replay_reset_certificate.py",
             "reset_certificate.json", "verify_reset_certificates.py", "RESET_CERTIFICATE_README.txt"]
    receipt = {
        "format": "reset-symbolic-nd-receipt-v1",
        "python": platform.python_version(),
        "positive_cli_runs": len(positives),
        "negative_controls": len(negatives),
        "negative_cli_runs": sum(len(n["runs"]) for n in negatives),
        "total_cli_runs": len(positives) + sum(len(n["runs"]) for n in negatives),
        "all_checks_passed": True,
        "numeric_sampling_used": False,
        "induction_rule_in_replayer": False,
        "full_ipra_checker": False,
        "complete_checker_size_record": False,
        "scope": "Three exact closed symbolic theorems about the RESET premise, relative to decidable actual zero and faithful selector schemas.",
        "positive_runs": positives,
        "rejection_controls": negatives,
        "sha256": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in files},
    }
    destination = PACKAGE / "evidence" / "reset_certificate_results.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"receipt": str(destination), "positive_cli_runs": len(positives),
                      "negative_controls": len(negatives), "negative_cli_runs": 24,
                      "proof_nodes": positives[0]["result"]["proof_nodes"],
                      "all_checks_passed": True}, indent=2))


if __name__ == "__main__":
    main()
