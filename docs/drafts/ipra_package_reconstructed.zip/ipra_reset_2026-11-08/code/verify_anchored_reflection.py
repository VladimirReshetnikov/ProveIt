"""Run public anchored-reflection replays and focused negative controls."""
import copy
import hashlib
import json
import platform
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def nodes(value):
    if isinstance(value, dict):
        if "rule" in value:
            yield value
        for child in value.values():
            yield from nodes(child)
    elif isinstance(value, list):
        for child in value:
            yield from nodes(child)


def first(certificate, predicate):
    return next(node for node in nodes(certificate) if predicate(node))


def ar(certificate):
    return first(certificate, lambda node: node["rule"] == "anchored_reset")


def retained_parameter_as_eigenvariable(c): ar(c)["eigenvariable"] = "a"
def target_escapes(c): ar(c)["target"] = ["var", "z"]
def passive_parameter_escapes(c): ar(c)["template"] = ["C", ["sg", ["var", "x"]], ["var", "z"], ["var", "b"]]
def different_template(c): ar(c)["template"] = ["S", ar(c)["template"]]
def forged_premise(c): ar(c)["proof"] = {"rule": "eq_refl", "term": ["zero"]}
def wrong_arithmetic_rule(c): ar(c)["rule"] = "unrestricted_induction"


def assumed_abs(c):
    first(c, lambda node: node["rule"] == "axiom")["name"] = "Abs"


def declared_abs(c): c["trusted_axiom_schemas"].append("Abs")


def branch_escape(c):
    node = first(c, lambda node: node["rule"] == "or_e")
    node["right"] = {"rule": "hyp", "name": node["left_name"]}


def wrong_motive(c):
    node = first(c, lambda node: node["rule"] == "eq_e")
    node["template"] = ["eq", ["var", "hole"], ["S", ["zero"]]]


def false_export(c): c["claims"][1]["conclusion"] = ["eq", ["zero"], ["S", ["zero"]]]
def duplicate_claim(c): c["claims"][2] = copy.deepcopy(c["claims"][1])


CONTROLS = [
    ("retained_parameter_as_eigenvariable", retained_parameter_as_eigenvariable),
    ("eigenvariable_in_target", target_escapes),
    ("eigenvariable_as_passive_parameter", passive_parameter_escapes),
    ("changed_numerical_template", different_template),
    ("forged_reset_premise", forged_premise),
    ("unlicensed_arithmetic_rule", wrong_arithmetic_rule),
    ("Abs_used_as_axiom", assumed_abs),
    ("Abs_added_to_inventory", declared_abs),
    ("branch_hypothesis_escape", branch_escape),
    ("wrong_equality_motive", wrong_motive),
    ("false_exported_equation", false_export),
    ("duplicate_exported_claim", duplicate_claim),
]


def cli(path, optimized):
    command = [sys.executable] + (["-O"] if optimized else [])
    command += [str(ROOT / "replay_anchored_reflection.py"), str(path)]
    result = subprocess.run(command, capture_output=True, text=True, check=False)
    return result.returncode, json.loads(result.stdout)


def main():
    certificate_path = ROOT / "anchored_reflection_certificate.json"
    original = json.loads(certificate_path.read_text(encoding="utf-8"))
    positives, negatives = [], []
    for optimized in (False, True):
        code, result = cli(certificate_path, optimized)
        if code != 0 or result.get("accepted") is not True or result.get("anchored_reset_uses") != 1:
            raise RuntimeError("Correct reflection certificate failed")
        positives.append({"optimized": optimized, "exit_code": code, "result": result})
    with tempfile.TemporaryDirectory(prefix="anchored-reflection-controls-") as directory:
        for name, mutation in CONTROLS:
            changed = copy.deepcopy(original)
            mutation(changed)
            path = Path(directory) / (name + ".json")
            path.write_text(json.dumps(changed), encoding="utf-8")
            runs = []
            for optimized in (False, True):
                code, result = cli(path, optimized)
                if code != 1 or result.get("accepted") is not False:
                    raise RuntimeError("Damaged reflection certificate accepted: " + name)
                runs.append({"optimized": optimized, "exit_code": code, "error": result.get("error")})
            negatives.append({"name": name, "rejected": True, "runs": runs})
    names = ["replay_reset_certificate.py", "make_anchored_reflection.py",
             "replay_anchored_reflection.py", "anchored_reflection_certificate.json",
             "verify_anchored_reflection.py", "ANCHORED_REFLECTION_README.txt"]
    receipt = {
        "format": "anchored-reflection-receipt-v1", "python": platform.python_version(),
        "all_checks_passed": True, "positive_cli_runs": len(positives),
        "negative_controls": len(negatives), "negative_cli_runs": 2 * len(negatives),
        "proof_nodes": positives[0]["result"]["proof_nodes"], "anchored_reset_uses": 1,
        "abs_or_reflection_axiom_used": False, "numeric_sampling_used": False,
        "full_ipra_checker": False, "complete_checker_size_record": False,
        "positive_runs": positives, "rejection_controls": negatives,
        "sha256": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in names},
    }
    destination = ROOT.parent / "evidence" / "anchored_reflection_results.json"
    destination.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"receipt": str(destination), "all_checks_passed": True,
                      "positive_cli_runs": 2, "negative_cli_runs": 24,
                      "proof_nodes": receipt["proof_nodes"], "anchored_reset_uses": 1}, indent=2))


if __name__ == "__main__":
    main()
