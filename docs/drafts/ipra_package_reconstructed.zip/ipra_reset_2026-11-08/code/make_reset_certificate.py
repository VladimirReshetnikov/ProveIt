"""Produce symbolic natural-deduction certificates for the RESET equivalence.

This producer does not import, execute, or inspect the independent replayer.
Its output is proof data, never Python code. The trusted replayer checks every
logical and equality step relative to three disclosed selector schemas.
"""
import json
from pathlib import Path


def var(name):
    return ["var", name]


def zero():
    return ["zero"]


def succ(t):
    return ["S", t]


def fun(t):
    return ["f", t, var("p")]


def reset(t):
    return ["D", fun(t), succ(t), zero()]


def eq(a, b):
    return ["eq", a, b]


def imp(a, b):
    return ["imp", a, b]


def all_(name, a):
    return ["all", name, a]


def hyp(name):
    return {"rule": "hyp", "name": name}


def inst(proof, term):
    return {"rule": "all_e", "proof": proof, "term": term}


def mp(major, minor):
    return {"rule": "imp_e", "major": major, "minor": minor}


def selector(name, t):
    return {"rule": "axiom", "name": name,
            "terms": [fun(t), succ(t), zero()]}


def rewrite(equality, body):
    return {"rule": "eq_e", "equality": equality, "body": body,
            "variable": "hole", "template": eq(fun(var("hole")), zero())}


def case_zero(t, left_name, left, right_name, right):
    return {"rule": "or_e",
            "major": {"rule": "axiom", "name": "zero_dec", "terms": [fun(t)]},
            "left_name": left_name, "left": left,
            "right_name": right_name, "right": right}


def implication(name, assumption, proof):
    return {"rule": "imp_i", "name": name,
            "assumption": assumption, "proof": proof}


def generalize(name, proof):
    return {"rule": "all_i", "variable": name, "proof": proof}


z = var("z")
premise = all_("z", eq(fun(reset(z)), zero()))
base = eq(fun(zero()), zero())
progress = all_("z", imp(eq(fun(z), zero()), eq(fun(succ(z)), zero())))
ordinary = ["and", base, progress]

# Forward direction: derive the base by a zero/nonzero split at f(0,p).
negative_base = rewrite(
    mp(selector("D_nonzero", zero()), hyp("n0")),
    inst(hyp("H"), zero()))
base_proof = case_zero(zero(), "h0", hyp("h0"), "n0", negative_base)

# The local progress assumption makes the reset argument exactly Sz.
step_proof = rewrite(
    mp(selector("D_zero", z), hyp("hz")), inst(hyp("H"), z))
progress_proof = generalize("z", implication("hz", eq(fun(z), zero()), step_proof))
forward = implication("H", premise,
                      {"rule": "and_i", "left": base_proof, "right": progress_proof})

# Reverse direction: the reset image is Sz in the zero branch, 0 otherwise.
left_result = mp(inst({"rule": "and_e", "side": 1, "proof": hyp("K")}, z),
                 hyp("hz"))
left = rewrite({"rule": "eq_sym", "proof": mp(selector("D_zero", z), hyp("hz"))},
               left_result)
right = rewrite(
    {"rule": "eq_sym", "proof": mp(selector("D_nonzero", z), hyp("nz"))},
    {"rule": "and_e", "side": 0, "proof": hyp("K")})
backward = implication("K", ordinary,
                       generalize("z", case_zero(z, "hz", left, "nz", right)))

claims = [
    {"name": "reset_implies_base_and_progress",
     "conclusion": all_("p", imp(premise, ordinary)),
     "proof": generalize("p", forward)},
    {"name": "base_and_progress_imply_reset",
     "conclusion": all_("p", imp(ordinary, premise)),
     "proof": generalize("p", backward)},
    {"name": "reset_premise_equivalence",
     "conclusion": all_("p", ["and", imp(premise, ordinary), imp(ordinary, premise)]),
     "proof": generalize("p", {"rule": "and_i", "left": forward, "right": backward})},
]
certificate = {
    "format": "reset-symbolic-nd-v1",
    "scope": "Symbolic first-order RESET-premise equivalence; not a full iPRA checker.",
    "trusted_axiom_schemas": ["zero_dec", "D_zero", "D_nonzero"],
    "claims": claims,
}
destination = Path(__file__).with_name("reset_certificate.json")
destination.write_text(json.dumps(certificate, indent=2) + "\n", encoding="utf-8")
print(destination)
