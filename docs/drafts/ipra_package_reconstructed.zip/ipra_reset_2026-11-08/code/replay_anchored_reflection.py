"""Independent anchored-RESET reflection replayer using the shared ND engine.

The shared engine checks only ordinary first-order and equality rules. This
module supplies exactly BR, the C/sg defining endpoints, and one explicit
anchored RESET inference. Abs, reflection, induction, and actual numerical
equality decisions are NOT trusted axioms here. No numerical sampling is used.
"""
import json
import sys
from collections import Counter
from pathlib import Path

import replay_reset_certificate as logic


AXIOMS = ["BR", "sg_zero", "sg_successor", "C_zero", "C_successor"]
ZERO = ["zero"]
ONE = ["S", ZERO]


def raw(a, b):
    return ["sg", ["w", a, b]]


def normalized(a, b):
    return ["C", raw(a, a), raw(a, b), ZERO]


def axiom(name, arguments):
    logic.require(type(arguments) is list, "Axiom arguments must be an array")
    for argument in arguments:
        logic.term(argument)
    if name == "BR":
        logic.require(len(arguments) == 1, "BR takes one term")
        sign = ["sg", arguments[0]]
        return ["or", ["eq", sign, ZERO], ["eq", sign, ONE]]
    if name == "sg_zero":
        logic.require(not arguments, "sg_zero takes no arguments")
        return ["eq", ["sg", ZERO], ZERO]
    if name == "sg_successor":
        logic.require(len(arguments) == 1, "sg_successor takes one term")
        return ["eq", ["sg", ["S", arguments[0]]], ONE]
    if name == "C_zero":
        logic.require(len(arguments) == 2, "C_zero takes two terms")
        a, b = arguments
        return ["eq", ["C", ZERO, a, b], a]
    if name == "C_successor":
        logic.require(len(arguments) == 3, "C_successor takes three terms")
        n, a, b = arguments
        return ["eq", ["C", ["S", n], a, b], b]
    raise logic.InvalidCertificate("Unlicensed anchored-profile axiom: " + str(name))


def anchored_rule(node, context, derive):
    logic.require(node["rule"] == "anchored_reset", "Unlicensed arithmetic inference")
    variable = node.get("matrix_variable")
    eigenvariable = node.get("eigenvariable")
    logic.require(logic.identifier(variable) and logic.identifier(eigenvariable), "Invalid RESET variables")
    logic.require(variable != eigenvariable, "Template and eigenvariable must be distinct")
    template = logic.term(node["template"])
    target = logic.term(node["target"])
    passive = logic.term_variables(template) - {variable}
    logic.require(eigenvariable not in passive, "RESET eigenvariable is a passive parameter")
    logic.require(eigenvariable not in logic.term_variables(target), "RESET eigenvariable occurs in target")
    logic.require(all(eigenvariable not in logic.free_variables(a) for a in context.values()),
                  "RESET eigenvariable occurs in retained context")
    f_at_one = logic.substitute_term(template, variable, ONE)
    f_at_z = logic.substitute_term(template, variable, ["var", eigenvariable])
    image = ["C", normalized(f_at_z, f_at_one), ["S", ["var", eigenvariable]], ZERO]
    expected = ["eq", logic.substitute_term(template, variable, image), f_at_one]
    actual = derive(node["proof"])
    logic.require(actual == expected, "Anchored RESET premise does not match its exact template")
    return ["eq", logic.substitute_term(template, variable, target), f_at_one]


def expected_claims():
    a, b = ["var", "a"], ["var", "b"]
    test_zero = ["eq", normalized(a, b), ZERO]
    equal = ["eq", a, b]
    return {
        "normalized_diagonal": ["all", "a", ["eq", normalized(a, a), ZERO]],
        "zero_test_reflects_actual_equality": ["all", "a", ["all", "b", ["imp", test_zero, equal]]],
        "actual_equality_implies_zero_test": ["all", "a", ["all", "b", ["imp", equal, test_zero]]],
    }


def verify(certificate):
    logic.require(type(certificate) is dict and certificate.get("format") == "anchored-reflection-nd-v1",
                  "Unknown anchored certificate format")
    logic.require(certificate.get("trusted_axiom_schemas") == AXIOMS, "Anchored axiom inventory changed")
    logic.require(certificate.get("trusted_arithmetic_rule") == "anchored_reset", "Arithmetic rule declaration changed")
    targets = expected_claims()
    claims = certificate.get("claims")
    logic.require(type(claims) is list and len(claims) == len(targets), "Wrong exported claim count")
    seen, rows = set(), []
    for claim in claims:
        logic.require(type(claim) is dict, "Malformed claim")
        name = claim.get("name")
        logic.require(name in targets and name not in seen, "Unknown or duplicate claim")
        seen.add(name)
        declared = logic.formula(claim["conclusion"])
        logic.require(declared == targets[name] and not logic.free_variables(declared), "Exact closed target changed")
        counts = Counter()
        derived = logic.replay(claim["proof"], {}, counts, axiom_provider=axiom, extension=anchored_rule)
        logic.require(derived == declared, "Derived anchored conclusion differs from exact target")
        rows.append({"name": name, "proof_nodes": sum(counts.values()),
                     "anchored_reset_uses": counts["anchored_reset"], "rules": dict(sorted(counts.items()))})
    return {"accepted": True, "claims": rows, "proof_nodes": sum(r["proof_nodes"] for r in rows),
            "anchored_reset_uses": sum(r["anchored_reset_uses"] for r in rows),
            "trusted_axioms": AXIOMS, "trusted_arithmetic_rule": "anchored_reset",
            "abs_or_reflection_axiom_used": False, "numeric_sampling_used": False,
            "scope": "Symbolic reflection from the explicitly trusted anchored RESET rule; not full iPRA verification."}


def main():
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name("anchored_reflection_certificate.json")
    try:
        result = verify(json.loads(path.read_text(encoding="utf-8")))
    except (logic.InvalidCertificate, KeyError, TypeError, IndexError, RecursionError, ValueError) as error:
        print(json.dumps({"accepted": False, "error": str(error)}))
        return 1
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
