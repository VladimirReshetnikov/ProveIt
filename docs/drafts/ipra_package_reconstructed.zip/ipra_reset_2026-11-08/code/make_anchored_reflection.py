"""Produce symbolic equality-reflection proofs using one anchored RESET.

The producer never imports the replayer. It writes ordinary proof data.
No numerical evaluation or finite sampling is used.
"""
import json
from pathlib import Path


Z = ["zero"]
ONE = ["S", Z]


def V(x): return ["var", x]
def S(x): return ["S", x]
def C(v, a, b): return ["C", v, a, b]
def sg(x): return ["sg", x]
def raw(a, b): return sg(["w", a, b])
def test(a, b): return C(raw(a, a), raw(a, b), Z)
def eq(a, b): return ["eq", a, b]


def replace(term, image):
    if term == V("hole"):
        return image
    if term[0] == "var":
        return term
    return [term[0], *(replace(child, image) for child in term[1:])]


class Equation:
    def __init__(self, left, right, proof):
        self.left, self.right, self.proof = left, right, proof

    def then(self, other):
        if self.right != other.left:
            raise ValueError("Producer transitivity mismatch")
        return Equation(self.left, other.right,
                        {"rule": "eq_e", "equality": other.proof, "body": self.proof,
                         "variable": "hole", "template": eq(self.left, V("hole"))})

    def sym(self):
        return Equation(self.right, self.left, {"rule": "eq_sym", "proof": self.proof})

    def through(self, template):
        left, right = replace(template, self.left), replace(template, self.right)
        return Equation(left, right,
                        {"rule": "eq_e", "equality": self.proof,
                         "body": {"rule": "eq_refl", "term": left},
                         "variable": "hole", "template": eq(left, template)})


def hypothesis(name, left, right):
    return Equation(left, right, {"rule": "hyp", "name": name})


def axiom(name, args, left, right):
    return Equation(left, right, {"rule": "axiom", "name": name, "terms": args})


def c0(a, b): return axiom("C_zero", [a, b], C(Z, a, b), a)
def cs(n, a, b): return axiom("C_successor", [n, a, b], C(S(n), a, b), b)
def sign0(): return axiom("sg_zero", [], sg(Z), Z)
def signs(n): return axiom("sg_successor", [n], sg(S(n)), ONE)


def split_sign(t, name0, proof0, name1, proof1):
    if proof0.left != proof1.left or proof0.right != proof1.right:
        raise ValueError("Producer branch mismatch")
    return Equation(proof0.left, proof0.right,
                    {"rule": "or_e",
                     "major": {"rule": "axiom", "name": "BR", "terms": [t]},
                     "left_name": name0, "left": proof0.proof,
                     "right_name": name1, "right": proof1.proof})


def diagonal(a):
    c = raw(a, a)
    template = C(V("hole"), V("hole"), Z)
    branch0 = hypothesis("diag_zero", c, Z).through(template).then(c0(Z, Z))
    branch1 = hypothesis("diag_one", c, ONE).through(template).then(cs(Z, ONE, Z))
    return split_sign(["w", a, a], "diag_zero", branch0, "diag_one", branch1)


def generalize(names, proof):
    result = proof
    for name in reversed(names):
        result = {"rule": "all_i", "variable": name, "proof": result}
    return result


a, b, z, x = V("a"), V("b"), V("z"), V("x")


def ramp(t): return C(sg(t), a, b)


at0 = sign0().through(C(V("hole"), a, b)).then(c0(a, b))
at1 = signs(Z).through(C(V("hole"), a, b)).then(cs(Z, a, b))
ats = signs(z).through(C(V("hole"), a, b)).then(cs(Z, a, b))

# In the ramp's zero branch, the guard becomes the retained equation d(a,b)=0.
ramp0 = hypothesis("ramp_zero", sg(z), Z).through(C(V("hole"), a, b)).then(c0(a, b))
guard0 = (ramp0.through(test(V("hole"), ramp(ONE)))
          .then(at1.through(test(a, V("hole"))))
          .then(hypothesis("test_equal", test(a, b), Z)))

# In its one branch the normalized diagonal lemma supplies d(b,b)=0.
ramp1 = hypothesis("ramp_one", sg(z), ONE).through(C(V("hole"), a, b)).then(cs(Z, a, b))
guard1 = (ramp1.through(test(V("hole"), ramp(ONE)))
          .then(at1.through(test(b, V("hole"))))
          .then(diagonal(b)))
guard = split_sign(z, "ramp_zero", guard0, "ramp_one", guard1)

# The reset image is Sz. Its ramp value equals the anchor F(1)=b.
rho = C(test(ramp(z), ramp(ONE)), S(z), Z)
rho_is_successor = guard.through(C(V("hole"), S(z), Z)).then(c0(S(z), Z))
premise = rho_is_successor.through(ramp(V("hole"))).then(ats).then(at1.sym())
anchored = Equation(ramp(Z), ramp(ONE), {
    "rule": "anchored_reset", "matrix_variable": "x", "template": ramp(x),
    "eigenvariable": "z", "target": Z, "proof": premise.proof,
})
reflected = at0.sym().then(anchored).then(at1)
forward = {"rule": "imp_i", "name": "test_equal",
           "assumption": eq(test(a, b), Z), "proof": reflected.proof}

# Actual equality gives the zero test by substitution into the diagonal.
back = hypothesis("actual_equal", a, b).sym().through(test(a, V("hole"))).then(diagonal(a))
backward = {"rule": "imp_i", "name": "actual_equal", "assumption": eq(a, b), "proof": back.proof}

claims = [
    {"name": "normalized_diagonal", "conclusion": ["all", "a", eq(test(a, a), Z)],
     "proof": generalize(["a"], diagonal(a).proof)},
    {"name": "zero_test_reflects_actual_equality",
     "conclusion": ["all", "a", ["all", "b", ["imp", eq(test(a, b), Z), eq(a, b)]]],
     "proof": generalize(["a", "b"], forward)},
    {"name": "actual_equality_implies_zero_test",
     "conclusion": ["all", "a", ["all", "b", ["imp", eq(a, b), eq(test(a, b), Z)]]],
     "proof": generalize(["a", "b"], backward)},
]
payload = {"format": "anchored-reflection-nd-v1",
           "scope": "Equality reflection from Boolean normalization and one anchored RESET; no Abs axiom.",
           "trusted_axiom_schemas": ["BR", "sg_zero", "sg_successor", "C_zero", "C_successor"],
           "trusted_arithmetic_rule": "anchored_reset", "claims": claims}
destination = Path(__file__).with_name("anchored_reflection_certificate.json")
destination.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
print(destination)
