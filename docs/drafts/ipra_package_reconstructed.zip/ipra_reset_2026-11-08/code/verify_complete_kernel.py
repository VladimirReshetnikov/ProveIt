#!/usr/bin/env python3
"""Verify the separate complete native kernel and reproduce its source record.

Finite tests support the all-input program argument in COMPLETE_KERNEL_README.txt;
they are not a formal proof of the inherited calculus or of anchored RESET.
This verifier is outside the measured/trusted checker and imports no producers.
"""
import ast
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import random
import runpy
import subprocess
import sys
import tokenize
from concurrent.futures import ThreadPoolExecutor

ROOT = Path(__file__).resolve().parent.parent
CANDIDATE = ROOT / 'code/complete_kernel.py'
BASELINE = ROOT / 'reference/checkers/array_only.py'
NORMALIZER = ROOT / 'reference/source_measure.py'
POSITIVE = ROOT / 'code/complete_kernel_fixtures.json'
PUBLIC = ROOT / 'code/complete_kernel_cli_cases.json'
HASHES = {
    'code/complete_kernel.py': '6726df4aa9cb5560ac82889c5ff1fcab8838e8752b29eeee2c509ad78e85982e',
    'reference/checkers/array_only.py': '9cc227c1481d321449b8f9b5ca5d447555bec42f28e07419ad1bab1c7d097e28',
    'reference/source_measure.py': 'f1404184bf9d39d85c4587f30e191785886c85fed0b3fe01f693191ca6f218dc',
    'reference/checker_manifest.json': 'e12e0dd0281b01ba7f64c187d2e9880ede506c123afd35646313852bbd9091f0',
    'code/complete_kernel_fixtures.json': '9374ce943039bb948326a76f3130dc89c09beba6e2efcb8fe117f35e28be619a',
    'code/complete_kernel_cli_cases.json': '2330f0222b77046bfc3e227c04c7cd3838b1ecfde66975bb7628a722ee38ce09',
}
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
RENAMING = {'inst': 'i', 'check': 'c', 'take': 'q'}
COORDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def check_hash(data, expected_hash, label):
    require(digest(data) == expected_hash, 'Integrity failure: ' + label)


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


class Rename(ast.NodeTransformer):
    def visit_Name(self, node):
        node.id = RENAMING.get(node.id, node.id)
        return node

    def visit_FunctionDef(self, node):
        self.generic_visit(node)
        node.name = RENAMING.get(node.name, node.name)
        return node


def tree(source):
    return ast.fix_missing_locations(StripDocstrings().visit(ast.parse(source)))


def names(node):
    return ({n.id for n in ast.walk(node) if isinstance(n, ast.Name)}
            | {n.arg for n in ast.walk(node) if isinstance(n, ast.arg)}
            | {n.name for n in ast.walk(node) if isinstance(n, ast.FunctionDef)})


def renamed(node):
    require(not names(node).intersection(RENAMING.values()), 'Rename target collision')
    return ast.fix_missing_locations(Rename().visit(copy.deepcopy(node)))


def tree_metrics(node):
    normalized = ast.unparse(node) + '\n'
    return {
        'normalized_tokens': sum(t.type not in IGNORED for t in
                                 tokenize.generate_tokens(io.StringIO(normalized).readline)),
        'ast_nodes': sum(1 for _ in ast.walk(node)),
        'normalized_bytes': len(normalized.encode('utf-8')),
    }


def verify_transformation(old_source, new_source):
    """Mechanically recognize all changes; semantics are justified in the README."""
    expected = renamed(tree(old_source))
    old_block = ast.parse('try:\n s,u=m\nexcept:\n s,u,t=0,t,*m\n').body[0]
    new_block = ast.parse('u=t\ntry:\n t,=m\nexcept:\n s,u=m\n').body

    class LocalRewrite(ast.NodeTransformer):
        transport_changes = 0
        default_changes = 0
        byte_changes = 0

        def visit_Try(self, node):
            if ast.dump(node) == ast.dump(old_block):
                self.transport_changes += 1
                return copy.deepcopy(new_block)
            return self.generic_visit(node)

        def visit_FunctionDef(self, node):
            self.generic_visit(node)
            if node.name == 'c':
                require([a.arg for a in node.args.args] == ['a', 'g']
                        and not node.args.defaults, 'Unexpected old function signature')
                node.args.args.append(ast.arg(arg='s'))
                node.args.defaults.append(ast.Constant(value=0))
                self.default_changes += 1
            return node

        def visit_Constant(self, node):
            if node.value == bytes([0, 2, 1, 4]):
                self.byte_changes += 1
                node.value = bytes([32, 2, 1, 4])
            return node

    rewrite = LocalRewrite()
    expected = ast.fix_missing_locations(rewrite.visit(expected))
    actual = tree(new_source)
    require((rewrite.transport_changes, rewrite.default_changes, rewrite.byte_changes)
            == (1, 1, 1), 'Source rewrite was not unique')
    require(ast.dump(expected) == ast.dump(actual), 'Unreviewed source change')
    calls = [n for n in ast.walk(actual) if isinstance(n, ast.Call)
             and isinstance(n.func, ast.Name) and n.func.id == 'c']
    require(len(calls) == 4 and all(len(n.args) == 2 and not n.keywords for n in calls),
            'Checker default can be overridden by an internal call')
    require(not any(isinstance(n, ast.Assert) for n in ast.walk(actual)),
            'Assertion is an acceptance gate')
    imports = [n for n in ast.walk(actual) if isinstance(n, (ast.Import, ast.ImportFrom))]
    require(len(imports) == 1 and ast.dump(imports[0]) == ast.dump(ast.parse('import json').body[0]),
            'Unreviewed runtime dependency')
    return {'exact_ast_rewrite': True, 'two_argument_checker_call_sites': len(calls),
            'alpha_renaming_collision_free': True, 'assert_acceptance_gates': 0,
            'runtime_imports': ['json'], 'transport_rewrites': 1,
            'immutable_zero_defaults_added': 1, 'unread_table_cells_changed': 1}


def must_fail(operation, label):
    try:
        operation()
    except ValueError:
        return label
    raise ValueError('Negative control did not fail: ' + label)


def expected(accept):
    return {'exit_code': 0 if accept else 1,
            'stdout': 'ACCEPT\n' if accept else 'REJECT\n', 'stderr': ''}


def cli(path, data, optimized):
    command = [sys.executable, '-X', 'utf8'] + (['-O'] if optimized else []) + [str(path)]
    process = subprocess.run(command, input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             timeout=20, env=dict(os.environ, PYTHONUTF8='1',
                                                 PYTHONIOENCODING='utf-8:strict'))
    return {'exit_code': process.returncode, 'stdout': process.stdout.decode(),
            'stderr': process.stderr.decode()}


def definitions(path):
    parsed = ast.parse(path.read_text())
    parsed.body = [n for n in parsed.body if not isinstance(n, ast.Try)]
    namespace = {}
    exec(compile(parsed, str(path), 'exec'), namespace)
    return namespace


def run(namespace, packet, new=False):
    stack = copy.deepcopy(packet)
    namespace['k'] = 0
    take_name, check_name = ('q', 'c') if new else ('take', 'check')
    try:
        namespace[take_name] = stack.pop
        accept = bool(namespace[check_name](namespace[take_name](), []))
    except BaseException:
        accept = False
    # JSON serialization also compares NaN/Infinity spellings consistently.
    return accept, namespace['k'], json.dumps(stack, sort_keys=True, separators=(',', ':'))


def branch_coverage(fixtures):
    """Observe positive branch witnesses without modifying the measured source."""
    source = CANDIDATE.read_text()
    lines = {line.strip(): number for number, line in enumerate(source.splitlines(), 1)}
    direct_labels = {
        lines['return 1']: 'context_membership',
        lines['a = i(a[2], t, 2)']: 'introduction',
        lines['k -= 1']: 'fresh_context_extension',
    }
    witnesses = {}
    current = None
    current_canonical = False

    def trace(frame, event, arg):
        if frame.f_code.co_filename != str(CANDIDATE):
            return None
        if event == 'line' and frame.f_code.co_name == 'c':
            line = frame.f_lineno
            labels = []
            if line in direct_labels:
                labels.append(direct_labels[line])
            if line == lines['u = t']:
                labels.append('singleton_elimination' if len(frame.f_locals['m']) == 1
                              else 'equation_transport')
            if line == lines['if [] in (h := [0, m[2:]]):']:
                major = frame.f_locals['m']
                if isinstance(major, list) and len(major) == 3:
                    labels.append('paired_major_elimination')
            if line == lines['if n:']:
                labels.append('successor_computation' if frame.f_locals['n']
                              else 'zero_computation')
            if (line in (lines['a = i(a[2], t, 2)'], lines['(n, t, r), b = a'])
                    and frame.f_locals['m']):
                labels.append('failed_major_fallback')
            for label in labels:
                if label not in witnesses or (current_canonical and not witnesses[label]['canonical']):
                    witnesses[label] = {'id': current['id'], 'name': current['name'],
                                        'canonical': current_canonical}
        return trace

    def canonical(value):
        return type(value) is int or (isinstance(value, list) and all(map(canonical, value)))

    namespace = definitions(CANDIDATE)
    for current in fixtures:
        current_canonical = canonical(current['packet'])
        sys.settrace(trace)
        try:
            require(run(namespace, current['packet'], True)[0], 'Positive trace rejected')
        finally:
            sys.settrace(None)
    required = {'context_membership', 'singleton_elimination', 'equation_transport',
                'paired_major_elimination', 'introduction', 'zero_computation',
                'successor_computation', 'fresh_context_extension', 'failed_major_fallback'}
    require(required <= witnesses.keys(), 'Missing positive branch coverage: '
            + repr(required - witnesses.keys()) + '; seen=' + repr(witnesses))
    require(all(witnesses[x]['canonical'] for x in required), 'Noncanonical branch witness')
    return witnesses


def main():
    for relative, expected_hash in HASHES.items():
        check_hash((ROOT / relative).read_bytes(), expected_hash, relative)
    manifest = json.loads((ROOT / 'reference/checker_manifest.json').read_text())
    for entry in manifest['programs']:
        check_hash((ROOT / entry['file']).read_bytes(), entry['sha256'], entry['file'])
    old_source, new_source = BASELINE.read_text(), CANDIDATE.read_text()
    transformation = verify_transformation(old_source, new_source)
    negative_controls = []
    for relative in ('code/complete_kernel.py', 'reference/checkers/array_only.py',
                     'code/complete_kernel_fixtures.json', 'code/complete_kernel_cli_cases.json'):
        data = (ROOT / relative).read_bytes()
        negative_controls.append(must_fail(
            lambda d=data, h=HASHES[relative], p=relative: check_hash(d + b' ', h, p),
            'changed_bytes_rejected:' + relative))
    for label, corrupted in (
        ('changed_default_zero', new_source.replace('def c(a, g, s=0):', 'def c(a, g, s=1):')),
        ('changed_reachable_arity_offset', new_source.replace("b' \\2\\1\\4'", "b' \\3\\1\\4'")),
        ('missing_transport_validation', new_source.replace('i(t, u) == a and ', '')),
    ):
        negative_controls.append(must_fail(lambda s=corrupted: verify_transformation(old_source, s), label))

    metrics = runpy.run_path(str(NORMALIZER))['metrics']
    candidate_metrics = metrics(CANDIDATE)
    baseline_metrics = metrics(BASELINE)
    require(tuple(candidate_metrics[k] for k in COORDS) == (309, 344, 864),
            'Expected metrics differ; use the recorded Python 3.12 normalizer environment')
    require(tree_metrics(tree(new_source)) == {k: candidate_metrics[k] for k in COORDS},
            'Independent metric implementation disagrees')
    comparator_rows = [{'file': entry['file'], **metrics(ROOT / entry['file'])}
                       for entry in manifest['programs']]
    minima = {k: min(row[k] for row in comparator_rows) for k in COORDS}
    require(tuple(minima[k] for k in COORDS) == (312, 347, 878), 'Frozen frontier changed')
    require(all(candidate_metrics[k] < minima[k] for k in COORDS), 'Not a strict triple improvement')
    control_rows = []
    for name in ('array_only', 'compact_unpack_open', 'structural_open', 'compact_open'):
        path = ROOT / 'reference/checkers' / (name + '.py')
        original = metrics(path)
        control_rows.append({'file': str(path.relative_to(ROOT)),
                             'literal_metrics': {k: original[k] for k in COORDS},
                             'uniform_short_names': tree_metrics(renamed(tree(path.read_text())))})
    metric_receipt = {
        'python': platform.python_version(), 'implementation': platform.python_implementation(),
        'source_normalizer_sha256': HASHES['reference/source_measure.py'],
        'complete_source_boundary': 'Whole module, imports and CLI included; only actual docstrings removed.',
        'candidate': candidate_metrics, 'baseline': baseline_metrics,
        'frozen_coordinate_minima': minima, 'frozen_programs': comparator_rows,
        'uniform_name_control': {'renaming': RENAMING, 'collision_free': True,
                                 'programs': control_rows,
                                 'candidate_unchanged': {k: candidate_metrics[k] for k in COORDS},
                                 'candidate_beats_control_byte_minimum': False},
        'strict_literal_source_improvement_in_all_three_coordinates': True,
        'name_independent_byte_dominance_claimed': False,
    }

    fixtures = json.loads(POSITIVE.read_text())['records']
    public = json.loads(PUBLIC.read_text())['cases']
    supplemental = [
        {'id': 'extra-0', 'name': 'failed_major_then_zero_computation',
         'packet': [[0, 0], [[[0, 0, 0], [0]], 0], [[0, 0, 0], 0]]},
        {'id': 'extra-1', 'name': 'failed_major_then_introduction',
         'packet': [[0, 0], [[[0, 0, 0], [0]], [0]], [0, 0, [0, 0]]]},
    ]
    alias_cases = [
        ('ordinary_zero', [[0, 0], [[0, 0, 0], 0]], True),
        ('used_empty_object', [[0, 0], [[0, {}, 0], {}]], False),
        ('unread_object_prefix', [{}, [0, 0], [[0, 0, 0], 0]], True),
        ('used_empty_string', [[0, 0], [[0, '', 0], '']], False),
        ('used_one_character_string', [[0, 0], [[0, 'x', 0], 'x']], False),
        ('used_nonempty_object', [[0, 0], [[0, {'x': 0}, 0], {'x': 0}]], False),
        ('boolean_alias', [[0, 0], [[False, False, False], False]], True),
        ('fractional_zero_alias', [[0, 0], [[0, .5, 0], .5]], True),
        ('empty_array_zero', [[0, 0], [[[], [], []], []]], True),
        ('empty_array_false_goal', [[0, 0], [[[], [], []], [[]]]], False),
        ('wrong_zero_result', [[0, 0], [[0, 0, 0], [0]]], False),
        ('truncated_instruction', [[0], [[0, 0, 0], 0]], False),
        ('overlong_instruction', [[0, 0, 0], [[0, 0, 0], 0]], False),
        ('missing_proof', [[[0, 0, 0], 0]], False),
        ('overlong_goal', [[0, 0], [0, 0, 0, 0]], False),
    ]
    jobs = []
    for fixture in fixtures + supplemental:
        data = json.dumps(fixture['packet'], separators=(',', ':')).encode()
        for program in (BASELINE, CANDIDATE):
            for optimized in (False, True):
                jobs.append((program, data, optimized, True, fixture['name']))
    for case in public:
        for program in (BASELINE, CANDIDATE):
            for optimized in (False, True):
                jobs.append((program, case['input_text'].encode(), optimized,
                             case['expected_accept'], case['name']))
    for name, packet, accept in alias_cases:
        for program in (BASELINE, CANDIDATE):
            for optimized in (False, True):
                jobs.append((program, json.dumps(packet).encode(), optimized, accept, name))
    for name, data in [('trailing_content', b'[] []'), ('invalid_utf8', b'\xff'),
                       ('empty_input', b''), ('top_level_string', b'"x"'),
                       ('top_level_object', b'{"x":0}')]:
        for program in (BASELINE, CANDIDATE):
            for optimized in (False, True):
                jobs.append((program, data, optimized, False, name))

    def job(item):
        program, data, optimized, accept, name = item
        got = cli(program, data, optimized)
        return None if got == expected(accept) else {
            'program': str(program.relative_to(ROOT)), 'case': name, 'optimized': optimized,
            'got': got, 'expected': expected(accept)}

    with ThreadPoolExecutor(max_workers=8) as pool:
        failures = [result for result in pool.map(job, jobs) if result is not None]
    require(not failures, 'CLI regression failed: ' + json.dumps(failures[:5]))
    witnesses = branch_coverage(fixtures + supplemental)

    baseline, candidate = definitions(BASELINE), definitions(CANDIDATE)
    atoms = [None, False, True, -2, -1, 0, 1, 2, .5, 1.5, '', 'x', {}, {'x': 0}, [],
             float('nan'), float('inf'), -float('inf')]
    small = atoms + [[copy.deepcopy(a)] * n for a in atoms for n in range(1, 5)]
    packets = []
    for value in small:
        packets.extend([value, [value], [[0, 0], value], [value, [[0, 0, 0], 0]],
                        [[value, 0], [[0, 0, 0], 0]], [[value, value], [value, value]]])
    systematic_accepted = 0
    for packet in packets:
        a, b = run(baseline, packet), run(candidate, packet, True)
        require(a == b, 'Systematic parsed-JSON trace divergence: ' + repr(packet))
        systematic_accepted += a[0]

    rng = random.Random(20261109)
    mutation_count = 256
    mutation_accepted = 0
    replacements = [None, False, True, -1, 0, 1, .5, '', 'x', {}, {'x': 0}, [],
                    [0], [0, 0], [0, 0, 0], [0, 0, 0, 0]]
    for _ in range(mutation_count):
        packet = copy.deepcopy(rng.choice(fixtures)['packet'])
        paths = []

        def walk(value, path=()):
            paths.append(path)
            if isinstance(value, list):
                for index, member in enumerate(value):
                    walk(member, path + (index,))

        walk(packet)
        path = rng.choice(paths)
        replacement = copy.deepcopy(rng.choice(replacements))
        if path:
            target = packet
            for index in path[:-1]:
                target = target[index]
            target[path[-1]] = replacement
        else:
            packet = replacement
        a, b = run(baseline, packet), run(candidate, packet, True)
        require(a == b, 'Mutated parsed-JSON trace divergence')
        mutation_accepted += a[0]

    result = {
        'python': platform.python_version(), 'implementation': platform.python_implementation(),
        'verified_sha256': HASHES, 'all_frozen_comparator_hashes_verified': len(comparator_rows),
        'source_transformation': transformation, 'negative_integrity_controls': negative_controls,
        'candidate_metrics': candidate_metrics, 'baseline_metrics': baseline_metrics,
        'coordinate_minima': minima, 'strict_literal_triple_improvement': True,
        'positive_fixture_count': len(fixtures), 'public_cli_case_count': len(public),
        'additional_canonical_branch_fixtures': supplemental,
        'additional_alias_and_corruption_cases': len(alias_cases),
        'additional_parser_cases': 5, 'cli_runs': len(jobs),
        'cli_modes': ['normal', '-O'], 'stdout_stderr_exitcode_all_matched': True,
        'canonical_positive_branch_witnesses': witnesses,
        'systematic_parsed_json_cases': len(packets), 'systematic_accepted_by_both': systematic_accepted,
        'fixed_seed_mutations': mutation_count, 'mutations_accepted_by_both': mutation_accepted,
        'comparison_observations': ['acceptance', 'fresh-coordinate floor', 'remaining proof stack'],
        'trace_divergences': 0,
        'fixture_provenance': {
            'original_snapshot': '06e097f723c659030816e0194e5eb7e8c607ba9b',
            'source_archive': 'docs/drafts/ipra_kernels_and_initializer_obstruction_2026-11-08.zip',
            'positive_member': 'ipra_kernel_2026-11-08/validation/boxed_positive_certificates.json',
            'copied_from': 'ipra_successor_clock_2026-11-09/code/checker/',
        },
        'scope': ('Full public CLI certificate-language equivalence to frozen array_only.py under ordinary '
                  'deterministic execution with sufficient resources; mathematical soundness/completeness '
                  'of that inherited calculus is transferred, not reproved by these finite tests. '
                  'This is not an implementation of the new anchored-reset presentation. '
                  'The strict byte record is under the inherited literal-source metric, not uniform renaming.'),
    }
    (ROOT / 'evidence/complete_kernel_metrics.json').write_text(json.dumps(metric_receipt, indent=2) + '\n')
    (ROOT / 'evidence/complete_kernel_results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('python', 'candidate_metrics', 'strict_literal_triple_improvement',
                                           'cli_runs', 'stdout_stderr_exitcode_all_matched',
                                           'systematic_parsed_json_cases', 'fixed_seed_mutations',
                                           'trace_divergences')}, indent=2))


if __name__ == '__main__':
    main()
