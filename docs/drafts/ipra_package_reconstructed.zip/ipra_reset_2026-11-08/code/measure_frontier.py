"""Reproduce the frozen COMPLETE-program frontier; no partial replayer competes."""
import importlib.util
import json
import platform
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("frozen_measure", ROOT / "reference/source_measure.py")
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)


def main():
    manifest = json.loads((ROOT / "reference/checker_manifest.json").read_text())
    rows = []
    for entry in manifest["programs"]:
        result = measure.metrics(ROOT / entry["file"])
        if result["sha256"] != entry["sha256"]:
            raise ValueError("Changed comparator: " + entry["file"])
        rows.append({**entry, **result})
    fields = ("normalized_tokens", "ast_nodes", "normalized_bytes")
    minima = {field: min(row[field] for row in rows) for field in fields}
    result = {
        "commit": manifest["commit"],
        "python": platform.python_version(),
        "complete_programs": len(rows),
        "boundary": "Whole executable source after actual docstring removal and ast.unparse; no producer/replayer entered.",
        "coordinate_minima": minima,
        "attainers": {field: [row["file"] for row in rows if row[field] == minima[field]] for field in fields},
        "programs": rows,
    }
    (ROOT / "evidence/frontier.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "programs"}, indent=2))


if __name__ == "__main__":
    main()
