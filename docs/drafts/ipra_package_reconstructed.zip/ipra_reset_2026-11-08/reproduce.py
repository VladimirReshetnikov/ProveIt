"""Replay the two scoped symbolic certificates and complete-source measurements."""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SCRIPTS = [
    "code/verify_reset_certificates.py",
    "code/verify_anchored_reflection.py",
    "code/measure_frontier.py",
    "code/verify_complete_kernel.py",
]
for script in SCRIPTS:
    subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)
print("All scoped symbolic checks, complete-kernel validation, and source measurements passed.")
