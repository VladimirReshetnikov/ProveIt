EQUALITY-REFLECTING RESET INDUCTION FOR iPRA
==========================================
Research report prepared for Vladimir Reshetnikov
8 November 2026 (Pacific date)

Read report.pdf. Its LaTeX entry point is report.tex; all included .tex files
are supplied. This package contains a proved mathematical axiom elimination,
two explicitly scoped symbolic certificate suites, and a separate complete
native checker below the inspected source-size envelope. The complete checker
retains the old native calculus; it does not directly implement the new AR
presentation. No smallest-possible axiomatization is claimed.

THE MAIN RESULT
---------------
In the ordinary full PR-description language, retain intuitionistic first-order
logic with equality and genuine falsity, all PR defining equations, and only:

  BR:  forall x (sg(x)=0 or sg(x)=1)
  Sep: 0=1 -> bottom.

Write 1=S0. Let C(0,a,b)=a, C(Sn,a,b)=b; sg(0)=0, sg(Sn)=1;
p(0)=0, p(Sn)=n; a dotminus 0=a, a dotminus Sn=p(a dotminus n).
Fix K(r)=C(r,1,p(r)), e(a,b)=sg(K(Sa dotminus b)), and
d(a,b)=C(e(a,a),e(a,b),0).

For ONE fixed finite template f(x,parameters), set

  c=f(1,parameters),
  rho(z)=C(d(f(z,parameters),c),Sz,0).

The only induction-type rule is

  Gamma proves f(rho(z),parameters)=c
  ----------------------------------
  Gamma proves f(t,parameters)=c,

where z is fresh for Gamma, t, and all passive parameters. Every f occurrence
is the same template; there is no independently supplied anchor.

One instance, using F(x)=C(sg(x),a,b), derives d(a,b)=0 -> a=b.
The converse follows from the normalized diagonal. Thus the previous Abs
equation is a theorem. The rule subsequently recovers every contextual
quantifier-free induction instance. Conversely, ordinary iPRA validates the
exact raw test and the rule. The two ordinary theories have exactly the same
sequents, with literal identity interpretations and composite graph x=y.

FINITE NUMERICAL GRAMMAR
-----------------------
An alternative uses only variables, 0, and a staged shifted counter/state
recursor T(n,a;u,v.h), with fixed captured numerical parameters permitted.
Two computation schemas, BR, Sep, and anchored reset suffice. All other
arithmetic terms are finite abbreviations. A proved optional shortcut reuses
L(x)=T(x,0;u,v.u) inside the raw detector. This construction has a finite term
grammar, NOT a finite ordinary first-order signature. It is fully
bi-interpretable with iPRA; its cross-language composites are provably
equal/equivalent, not literally identical strings. The recursion bootstrap is
inherited from the current successor_from_recursion draft and is credited.

LOGICAL REPRESENTATION
----------------------
Over the completed arithmetic theory, the progression binder

  P_{x,y} B := exists x forall y (B(x,y) -> B(x,Sy))

together with equations represents all intuitionistic first-order connectives
and quantifiers by explicit periodic-reset formulas. This is a representation
theorem, not permission to delete numerical cases from a native proof kernel.

THE SEPARATE COMPLETE-CHECKER RESULT
------------------------------------
The inspected drafts' complete-checker coordinate minima are:

  normalized tokens: 312   (array_only.py)
  AST nodes:         347   (compact_unpack_open.py and structural_open.py)
  normalized bytes:  878   (compact_open.py)

The supplied code/complete_kernel.py measures 309 normalized tokens, 344 AST
nodes, and 864 normalized bytes, below all three of those previous minima.
It preserves the complete accepted certificate language of array_only.py by
an explicit whole-input source-equivalence proof. Public CLI validation runs
in normal and optimized Python; see code/COMPLETE_KERNEL_README.txt and the
machine-readable evidence/complete_kernel_results.json receipt.

This is an implementation reduction of the inherited native calculus, not a
checker for the new anchored-reset axiomatization. Shorter interface names
contribute 62 bytes. Applying the same renaming to old comparators removes
byte dominance; token and AST advantages persist. The record is specifically
under the inherited literal-source metric, not a name-independent or universal
complexity lower-bound theorem. Neither symbolic fragment replayer is counted
as a complete proof checker. Novelty claims concern the inspected repository
snapshot, not historical priority throughout mathematics.

CONTENTS
--------
report.pdf, report.tex, *.tex
    Complete statement, logical inventory, proofs, finite-constructor variant,
    periodic progression representation, independence arguments, and comparison.

code/make_anchored_reflection.py
code/replay_anchored_reflection.py
code/anchored_reflection_certificate.json
code/verify_anchored_reflection.py
code/ANCHORED_REFLECTION_README.txt
    Producer, independent replayer, certificate, rejection controls, and exact
    trusted interface for the equality-calibration proof. Exactly one AR use;
    no primitive Abs, reflection, numerical coverage, or ordinary induction.

code/make_reset_certificate.py
code/replay_reset_certificate.py
code/reset_certificate.json
code/verify_reset_certificates.py
code/RESET_CERTIFICATE_README.txt
    Separate generic reset-premise equivalence, relative to a faithful zero
    selector and decidable zero tests. The arithmetic rules of the first profile
    are not automatically trusted by this second profile.

reference/checkers/*.py, reference/source_measure.py
    Seventeen frozen complete comparator programs and their inherited normalizer.
    Provenance and hashes appear in reference/checker_manifest.json.

code/complete_kernel.py
code/verify_complete_kernel.py
code/COMPLETE_KERNEL_README.txt
    The separate complete native checker, executable comparison, full-input
    equivalence argument, and the explicit naming control.

code/measure_frontier.py, reproduce.py
    Reproduce certificate checks, complete-kernel validation, and exact
    complete-source measurements.

evidence/
    Source snapshot identities, independent mathematical reviews, exact test
    receipts, frontier measurements, build log, and PDF inspection receipt.

build.py, package.py, MANIFEST.json
    Rebuild the PDF, create a deterministic ZIP, and verify payload checksums.

REPRODUCE
---------
Run from the extracted package directory:

  python3 reproduce.py
  python3 build.py
  python3 package.py

For a minimal direct complete-checker example (a native zero-counter
initialization computation), run:

  python3 code/complete_kernel.py < code/example_certificate.json

It prints ACCEPT. The independent mathematical AR certificate is replayed by
code/replay_anchored_reflection.py; it uses a different, explicitly scoped
certificate language.

The verification code requires Python 3.10 or newer and its standard library.
The exact published AST/unparse metrics were measured with CPython 3.12.14;
other interpreter versions can change those source metrics. Building the PDF
requires pdfLaTeX and the packages listed in report.tex (ordinary TeX Live).
build.py also supports an unpacked installed TeX tree with missing format/map
indexes by constructing temporary local files. It downloads nothing and changes
no system TeX configuration. Shell escape is disabled.

The certificate producers are not imported by the replay checkers. Their
outputs are symbolic derivations, not finite numerical samples. Successful
replay does not formally verify the Python replayers or the entire metatheory.
The exact limitations are stated in the report and the two certificate READMEs.

SOURCE SNAPSHOT
---------------
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit:     4890fd00a5cacfc9881ae282120978f95c3ba392
Directory:  docs/drafts

All sixteen current ZIP archives were retrieved and checked against their Git
blob identities. evidence/source_snapshot.json records them. The exact borrowed
programs are included with the inherited license; see ATTRIBUTION.txt.
