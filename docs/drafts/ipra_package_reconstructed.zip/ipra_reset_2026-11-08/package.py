"""Create a deterministic ZIP of the reviewed release payload."""
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXCLUDED = {".aux", ".log", ".out", ".toc", ".pyc"}
payload = sorted(p for p in ROOT.rglob("*") if p.is_file()
                 and "__pycache__" not in p.parts and p.suffix not in EXCLUDED
                 and p.name != "MANIFEST.json")
manifest = {str(p.relative_to(ROOT)): {"bytes": p.stat().st_size,
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in payload}
(ROOT / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
payload.append(ROOT / "MANIFEST.json")
destination = ROOT.parent / (ROOT.name + ".zip")
with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for p in sorted(payload):
        info = zipfile.ZipInfo(ROOT.name + "/" + str(p.relative_to(ROOT)), (2026, 11, 8, 12, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, p.read_bytes())
print(destination)
print("Payload files:", len(payload), "ZIP bytes:", destination.stat().st_size)
