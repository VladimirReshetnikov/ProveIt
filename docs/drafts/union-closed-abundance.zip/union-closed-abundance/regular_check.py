"""Exact truth-table checks for the fixed-rank linear hypergraph theorem."""
from fractions import Fraction
from itertools import combinations


def bit_columns(n):
    """Column v records which of the 2**n vertex subsets include vertex v."""
    length = 1 << n
    columns = []
    for v in range(n):
        block = 1 << v
        column = ((1 << block) - 1) << block
        width = 2 * block
        while width < length:
            column |= column << width
            width *= 2
        columns.append(column)
    return columns


def intersection(masks, full):
    result = full
    for mask in masks:
        result &= mask
    return result


def mask_union(masks):
    result = 0
    for mask in masks:
        result |= mask
    return result


def verify(n, edges):
    r = len(edges[0])
    assert all(len(e) == r for e in edges)
    assert all(len(e & g) <= 1 for e, g in combinations(edges, 2))
    incidence = [[e for e in edges if v in e] for v in range(n)]
    d = len(incidence[0])
    assert d and all(len(star) == d for star in incidence)
    columns = bit_columns(n)
    total = 1 << n
    full = (1 << total) - 1
    edge_selected = {edge: intersection((columns[v] for v in edge), full) for edge in edges}
    bad = [columns[v] & ~mask_union(edge_selected[e] for e in incidence[v]) for v in range(n)]
    good = full & ~mask_union(bad)
    k = r - 1
    a = 1 - Fraction(1, 2**k)
    b = Fraction(2 ** (k - 1) - 1, 2**k - 1)
    one_bad = a**d / 2
    exponent = 1 + k * (k - 1)
    pair_bound_power = a ** (d * exponent) * (1 - b**k) ** (d - 1)
    for bv, bw in combinations(bad, 2):
        joint = Fraction((bv & bw).bit_count(), total)
        assert joint**exponent <= pair_bound_power

    frequencies = []
    for x in range(n):
        near = set().union(*incidence[x])
        assert len(near) == 1 + k * d
        far_good = full & ~mask_union(bad[v] for v in range(n) if v not in near)
        assert (far_good & columns[x]).bit_count() * 2 == far_good.bit_count()
        for v in near:
            assert Fraction(bad[v].bit_count(), total) == one_bad
            given_x = Fraction((bad[v] & columns[x]).bit_count(), total // 2)
            expected = 2 * one_bad if v == x else one_bad * (1 - Fraction(2, 2**k)) / a
            assert given_x == expected
        q0 = Fraction((far_good & ~good).bit_count(), far_good.bit_count())
        q1 = Fraction((far_good & columns[x] & ~good).bit_count(), (far_good & columns[x]).bit_count())
        frequency = Fraction((good & columns[x]).bit_count(), good.bit_count())
        assert frequency == (1 - q1) / (2 * (1 - q0))
        frequencies.append(frequency)
    predicted = Fraction(1, 2) + a**d * (Fraction(k*d, 2**k - 1) - 1) / 4
    print(f"n={n}, r={r}, d={d}, unions={good.bit_count()}, "
          f"frequency range [{min(frequencies)}, {max(frequencies)}], "
          f"asymptotic main terms {float(predicted):.6f}")


def cyclic_edges(n, patterns):
    return sorted({frozenset((t+x) % n for x in edge)
                   for edge in patterns for t in range(n)}, key=sorted)


if __name__ == "__main__":
    verify(7, cyclic_edges(7, [(0, 1, 3)]))
    verify(13, cyclic_edges(13, [(0, 1, 3, 9)]))
    verify(19, cyclic_edges(19, [(0, 1, 5), (0, 2, 8), (0, 3, 10)]))
    verify(21, cyclic_edges(21, [(0, 1, 4, 14, 16)]))
