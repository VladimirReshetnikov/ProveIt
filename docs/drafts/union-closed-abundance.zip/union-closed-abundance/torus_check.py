"""Exact finite checks for the nine-cell count and the cyclic blocker formula."""
from itertools import combinations


def distinct_unions(generators):
    result = {0}
    for mask in generators:
        result.update([value | mask for value in result])
    return result


def check_patch():
    rows = [sum(1 << (3 * i + j) for j in range(3)) for i in range(3)]
    columns = [sum(1 << (3 * i + j) for i in range(3)) for j in range(3)]
    family = distinct_unions(rows + columns)
    counts = [sum(bool(value & (1 << j)) for value in family) for j in range(9)]
    assert (len(family), counts) == (50, [34] * 9)
    return len(family), counts


def check_cyclic_blockers(max_order=32):
    cases = 0
    largest_one_orientation = 0
    for n in range(3, max_order + 1):
        for a, b in combinations(range(1, n), 2):
            shape = {0, a, b}
            blockers = {(a + b - 2 * x) % n for x in shape} - shape
            translates = {frozenset((x + t) % n for x in shape) for t in range(n)}
            for tile in translates:
                if tile != shape and tile & shape:
                    assert tile & blockers
            hitting_shape = sum(bool(tile & shape) for tile in translates)
            hitting_blockers = sum(bool(tile & blockers) for tile in translates)
            one_orientation = 3 * hitting_blockers + len(blockers) * hitting_shape
            assert one_orientation <= 48
            largest_one_orientation = max(largest_one_orientation, one_orientation)
            cases += 1
    return cases, largest_one_orientation


if __name__ == "__main__":
    size, counts = check_patch()
    print(f"Local family size {size}, cell counts {counts}")
    cases, largest = check_cyclic_blockers()
    print(f"Verified {cases} triples containing zero in cyclic groups of orders 3 to 32.")
    print(f"Maximum number of horizontal tiles meeting the blockers (equal shapes): {largest}")
