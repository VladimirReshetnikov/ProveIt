# Abundance in finite union-closed families

Read **abundance.pdf** for the complete manuscript. The regular-generator theorem and its irregular extension are in Section 1. The unrestricted multiplicity bound is in Section 2.

## Rebuild

The master source is **abundance.tex**. Keep the component TeX files in the same directory. With a standard TeX Live installation, run:

    pdflatex abundance.tex
    pdflatex abundance.tex

## Reproduce the finite computations

With Python 3.10 or later, run:

    python3 verify.py

The checkers use only the standard library. Their recorded output is in **verification.txt**. They enumerate finite configurations and verify local probability identities, sharpness constructions and example counts. The arguments for arbitrary size are in the manuscript.

## Earlier work

The bibliography and introductory comparison identify the published inputs and the ProveIt drafts used. The repository snapshot is b608a105d79fb6b108f4ad423872ab6b997cf4d5. This is a research manuscript for independent review. The general union-closed sets conjecture remains open.
