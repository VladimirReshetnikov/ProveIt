"""Exhaust the possible fibers over a marked four-element set."""
from collections import Counter
from itertools import combinations


def check():
    nclosed = 0
    zeros = set()
    histogram = Counter()
    for encoding in range(1 << 15):
        fiber = [i for i in range(15) if (encoding >> i) & 1] + [15]
        traces = set(fiber)
        if any((a | b) not in traces for a, b in combinations(fiber, 2)):
            continue
        nclosed += 1
        score = 5 * sum(a.bit_count() for a in fiber) - 8 * len(fiber)
        assert score >= 0
        histogram[score] += 1
        if not score:
            zeros.add(frozenset(fiber))
    expected = {
        frozenset([15] + [i for i in range(16) if i | edge == edge])
        for edge in range(16) if edge.bit_count() == 2
    }
    assert zeros == expected
    for left, right in combinations(zeros, 2):
        forced = {a | b for a in left for b in right}
        assert all(not forced <= z for z in zeros)
    print(f"Four-set: {nclosed} admissible fibers; {len(zeros)} have zero score.")
    print(f"Least positive score: {min(s for s in histogram if s)}.")


if __name__ == "__main__":
    check()
