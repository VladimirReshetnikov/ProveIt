"""Numerical checks for the frequency-count bounds and their examples."""

from itertools import combinations
from math import expm1, log, log1p, log2, sqrt


def entropy(x):
    return -x * log2(x) - (1 - x) * log1p(-x) / log(2)


def coefficients(u):
    psi = (3 - sqrt(5)) / 2
    a = u
    stages = 0
    while a < psi:
        a *= 2 - a
        stages += 1
    v = u * (2 - u)
    j = 0
    while -expm1(-log(2) / 2 ** (j + 1)) >= u:
        j += 1
    w = -expm1(-log(2) / 2**j)
    assert u <= w <= v
    theta = (w - u) / (v - u)
    chord = (1 - theta) * entropy(u) + theta * entropy(v)
    return stages, 1 - entropy(u) / entropy(v), 1 - entropy(u) / entropy(a), 1 - entropy(u) * entropy(w) / chord


def check_code_example():
    # A length-32 simplex code with pairwise distance 16.
    r = 32
    m = r // 6
    edges = [
        sum(1 << (2 * position + ((word & position).bit_count() % 2))
            for position in range(r))
        for word in range(m)
    ]
    assert min((x | y).bit_count() for x, y in combinations(edges, 2)) * 3 >= 4 * r
    total = 0
    counts = [0] * m
    for subset in range(2**m):
        required = 0
        chosen = [i for i in range(m) if subset & (1 << i)]
        for i in chosen:
            required |= edges[i]
        count = 2 ** (2 * r - required.bit_count())
        total += count
        for i in chosen:
            counts[i] += count
    u_denominator = 2 ** (r - 1)
    assert all(count * u_denominator < total for count in counts)
    assert total >= 2 ** (2 * r) + m * 2**r
    print(f"code construction: {total} sets, {m} auxiliary counts {counts}")


if __name__ == "__main__":
    for threshold in (0.001, 0.01, 0.05, 0.1, 0.2):
        stages, one, repeated, mixed = coefficients(threshold)
        print(f"u={threshold:g}  iterations={stages}  one={one:.8f}  "
              f"iterated={repeated:.8f}  mixed={mixed:.8f}")
    assert coefficients(0.01)[2] > 0.9190
    check_code_example()
