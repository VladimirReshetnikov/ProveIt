"""Enumerate internal triples for a seven-point, three-petal sunflower."""
from fractions import Fraction
from itertools import combinations, product

petals = [(1, 2), (3, 4), (5, 6)]
basic_edges = [1 | (1 << a) | (1 << b) for a, b in petals]
transversals = [sum(1 << x for x in choice) for choice in product(*petals)]
rows = set()
number = 0
for size in range(9):
    for extra in combinations(transversals, size):
        if any((a & b).bit_count() > 1 for a, b in combinations(extra, 2)):
            continue
        number += 1
        family = {0}
        for edge in basic_edges + list(extra):
            family.update([word | edge for word in family])
        center = Fraction(sum(word & 1 for word in family), len(family))
        leaves = Fraction(sum((word >> 1).bit_count() for word in family), 6 * len(family))
        assert center >= leaves and (center + 7 * leaves) / 8 >= Fraction(35, 64)
        rows.add((size, len(family), center, leaves))
assert len(rows) == 6
print(f"{number} admissible collections")
for size, count, center, leaves in sorted(rows):
    print(f"{size} extra triples, {count} unions, center {center}, mean leaves {leaves}")


# Build all graph models through five generator indices. A vertex of degree
# below three must have enough private points to complete its triple.
for n in range(2, 6):
    all_pairs = list(combinations(range(n), 2))
    graph_count = 0
    for choice in range(1, 1 << len(all_pairs)):
        pairs = [pair for i, pair in enumerate(all_pairs) if choice & (1 << i)]
        triples = [0] * n
        for i, (v, w) in enumerate(pairs):
            triples[v] |= 1 << i
            triples[w] |= 1 << i
        if any(triple.bit_count() > 3 for triple in triples):
            continue
        next_point = len(pairs)
        for v, triple in enumerate(triples):
            for _ in range(3 - triple.bit_count()):
                triples[v] |= 1 << next_point
                next_point += 1
        family = {0}
        for triple in triples:
            family.update([member | triple for member in family])
        for i in range(len(pairs)):
            missing = sum(not member & (1 << i) for member in family)
            assert Fraction(missing, len(family)) <= Fraction(12, 11)**6 / 4
        graph_count += 1
    print(f"{n} generator triples: checked {graph_count} nonempty shared-point graphs.")
