"""Reproduce finite checks of the vertex-star results using standard Python 3."""

from collections import Counter
from fractions import Fraction
from itertools import combinations
from math import isqrt


def adjacency(vertex_count, edges):
    neighbors = [0] * vertex_count
    for u, v in edges:
        neighbors[u] |= 1 << v
        neighbors[v] |= 1 << u
    return neighbors


def star_counts(vertex_count, edges):
    """Count frequencies directly among all distinct unions of the stars."""
    stars = [0] * vertex_count
    for i, (u, v) in enumerate(edges):
        stars[u] |= 1 << i
        stars[v] |= 1 << i
    unions = {0}
    for star in stars:
        unions.update([union | star for union in unions])
    present = [sum((union >> i) & 1 for union in unions) for i in range(len(edges))]
    return len(unions), present


def conditioned_counts(neighbors, edges):
    """Examine each vertex subset once, recording its isolated vertices."""
    far_valid = [0] * len(edges)
    outside = [
        ((1 << len(neighbors)) - 1) ^ (neighbors[u] | neighbors[v])
        for u, v in edges
    ]
    valid = 0
    for subset in range(1 << len(neighbors)):
        bad = sum(
            1 << v
            for v, hood in enumerate(neighbors)
            if subset & (1 << v) and not (subset & hood)
        )
        if not bad:
            valid += 1
        for i, far in enumerate(outside):
            if not (bad & far):
                far_valid[i] += 1
    return valid, far_valid


def parameter_lower_bound(d):
    """A rational lower enclosure of the smaller root of x*(1-d*x)=p."""
    lower = Fraction(0)
    upper = Fraction(1, 2 * d)
    event_prob = Fraction(1, 2 ** (d + 1))
    for _ in range(50):
        midpoint = (lower + upper) / 2
        if midpoint * (1 - d * midpoint) <= event_prob:
            lower = midpoint
        else:
            upper = midpoint
    return lower


def test_graph(vertex_count, edges):
    neighbors = adjacency(vertex_count, edges)
    d = neighbors[0].bit_count()
    assert d and all(nhood.bit_count() == d for nhood in neighbors)
    count, frequencies = star_counts(vertex_count, edges)
    valid, far_valid = conditioned_counts(neighbors, edges)
    assert valid == count
    x_lower = parameter_lower_bound(d)
    for i, (u, v) in enumerate(edges):
        assert 4 * (count - frequencies[i]) == far_valid[i]
        assert 4 * frequencies[i] <= 3 * count
        size = (neighbors[u] | neighbors[v]).bit_count()
        # The lower endpoint for x gives a stronger bound to test.
        assert 4 * (count - frequencies[i]) * (1 - x_lower) ** size <= count
    return count, frequencies


def labelled_examples():
    totals = Counter()
    for n in range(2, 7):
        pairs = list(combinations(range(n), 2))
        for d in range(1, n):
            if n * d % 2:
                continue
            for edges in combinations(pairs, n * d // 2):
                if any(mask.bit_count() != d for mask in adjacency(n, edges)):
                    continue
                test_graph(n, edges)
                totals[n] += 1
    print("Labelled regular graphs checked by vertex count:", dict(totals))


def prism_examples():
    for d in range(1, 8):
        edges = [(i, d + i) for i in range(d)]
        for k in [0, d]:
            edges += list(combinations(range(k, k + d), 2))
        n_unions, present = test_graph(2 * d, edges)
        assert n_unions == 4**d - d * 2**d + d * (d - 1)
        assert all(n_unions - count == 4 ** (d - 1) for count in present[:d])
        print(f"Prism degree {d}: {n_unions} unions, matching edge {present[0]}/{n_unions}")


def incidence_examples():
    for d in range(2, 20):
        q = next(i for i in range(d, 2 * d) if all(i % j for j in range(2, isqrt(i) + 1)))
        n = 2 * d * q
        edges = [
            (s * q + (m * s + t) % q, d * q + m * q + t)
            for s in range(d) for m in range(d) for t in range(q)
        ]
        neighbors = adjacency(n, edges)
        assert all(mask.bit_count() == d for mask in neighbors)
        assert all((neighbors[u] | neighbors[v]).bit_count() == 2 * d for u, v in edges)
        assert all((a & b).bit_count() <= 1 for a, b in combinations(neighbors, 2))
        if d <= 3:
            n_unions, present = test_graph(n, edges)
            p = Fraction(1, 2 ** (d + 1))
            maximum = Fraction(3, 4) - d * p / 2 + d * (n - 1) * p * p
            assert Fraction(max(present), n_unions) <= maximum
            print(f"Incidence degree {d}: {n_unions} unions, max {max(present)}/{n_unions}")
    print("Incidence degree, neighborhood sizes and codegrees checked for 2 <= d <= 19.")


if __name__ == "__main__":
    labelled_examples()
    prism_examples()
    incidence_examples()
