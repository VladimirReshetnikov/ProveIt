"""Check the marked low-degree point by enumerating all generated unions."""
from fractions import Fraction


def verify(q, m, expected_unions, expected_degree):
    # gf(q) with layers 0,1,2 and slopes 0,...,2m-1.
    edges = [
        sum(1 << (s*q + (s*slope + intercept) % q) for s in range(3))
        for slope in range(2*m)
        for intercept in range(q)
        if intercept != 0 or slope >= m
    ]
    family = {0}
    for edge in edges:
        family |= {member | edge for member in family}
    size = len(family)
    marked_degree = sum(member & 1 for member in family)
    assert (size, marked_degree) == (expected_unions, expected_degree)
    assert 2 * marked_degree < size
    print(f"q={q}, m={m}: {marked_degree}/{size} = {float(Fraction(marked_degree,size)):.8f}")


if __name__ == "__main__":
    verify(5, 2, 4621, 2260)
    verify(7, 3, 532530, 257088)
