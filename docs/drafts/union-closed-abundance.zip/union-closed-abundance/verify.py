"""Run each finite verification with assertions enabled."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
for script in sorted(root.glob("*_check.py")):
    print(f"\n{script.name}", flush=True)
    subprocess.run([sys.executable, "-E", str(script)], check=True, cwd=root)
