"""Check the three-block examples and the exact private-coordinate count."""

from itertools import product


def build_block(d, k, with_rare_bit):
    width = d + int(with_rare_bit)
    choices = list(range(2**d))
    if with_rare_bit:
        choices.append(2**width - 1)
    members = {
        sum(choice << (width * j) for j, choice in enumerate(components))
        for components in product(choices, repeat=k)
    }
    return width * k, members


def build_family(width, members, trim=0):
    block_top = 2**width - 1
    outside_top = 2 ** (3 * width) - 1
    types = []
    family = {0, 7} | {(outside_top << 3) | trace for trace in range(8)}
    for i in range(3):
        common = outside_top ^ (block_top << (width * i))
        proper = sorted(members - {block_top})
        if i == 2:
            proper = proper[trim:]
        projections = {common | (member << (width * i)) for member in proper}
        types.append(projections)
        family.update(
            (projection << 3) | trace
            for projection in projections
            for trace in (0, 1 << i, 7)
        )
    return family, types


def check_example(d, k, with_rare_bit, trim=0):
    width, block = build_block(d, k, with_rare_bit)
    family, types = build_family(width, block, trim)
    m = len(block)
    n = len(family)
    assert n == 9 * m + 1 - 3 * trim
    assert all(a | b in family for a in family for b in family)
    degrees = [
        sum((member >> x) & 1 for member in family) for x in range(3 + 3 * width)
    ]
    excess = 9 * max(degrees[:3]) - 4 * n
    assert excess == 5 + 3 * trim
    all_projections = {member >> 3 for member in family}
    exceptional = all_projections.difference(*types)
    assert len(exceptional) == 2
    for i, group in enumerate(types):
        other_groups = [other for j, other in enumerate(types) if j != i]
        others = set.union(*other_groups)
        assert all(a | b in exceptional for a in group for b in others)
        private = [
            x for x in range(3 * width)
            if all((b >> x) & 1 for b in others)
            and any(not ((a >> x) & 1) for a in group)
        ]
        assert len(group) <= 2 ** (len(exceptional) + len(private))
        assert all(degrees[3 + x] >= 3 * sum(map(len, other_groups)) for x in private)
    if with_rare_bit and trim == 0:
        rare_positions = [
            3 + i * width + j * (d + 1) + d for i in range(3) for j in range(k)
        ]
        expected_degree = 6 * m + 3 * (m // (2**d + 1)) - 1
        assert all(degrees[x] == expected_degree for x in rare_positions)
    print(f"d={d}, k={k}, rare={with_rare_bit}, trim={trim}, N={n}, E={excess}: OK")


if __name__ == "__main__":
    for dimension in (1, 2, 3, 4, 5):
        check_example(dimension, 1, False)
    for dimension, copies in ((1, 1), (1, 2), (1, 3), (2, 2), (3, 2)):
        check_example(dimension, copies, True)
    for deletions in (1, 3, 7):
        check_example(2, 2, True, deletions)
