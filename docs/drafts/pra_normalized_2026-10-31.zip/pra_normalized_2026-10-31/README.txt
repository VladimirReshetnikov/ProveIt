SMALL PRESENTATIONS OF PRA
Research report prepared for Vladimir Reshetnikov
Repository snapshot: 1933ee3d1630a43f96bfe16aeb88a8371b52082e

START HERE

Read pra_normalized.pdf for the complete mathematical report and proofs.
The editable source is pra_normalized.tex. Exact specifications in plain
text are in axioms.txt. No additional TeX source or bibliography file is
needed to build the PDF.

RESULT

Use the same arithmetic axioms with either classical first-order logic
with equality or intuitionistic first-order logic with equality. The
report proves a conservative definitional equivalence with ordinary PRA
separately in each logic. It does not identify their full quantified
theorem sets.

All options use the restricted initial-value recursion grammar

    I_h(0,a) = a,
    I_h(Sn,a) = h(n,I_h(n,a)),

where h is an earlier term with only the counter and state variables.
The update has no separate access to the original initial value.

The existing two-term guarded basis (G plus 0 != S0) remains the
shortest displayed arithmetic basis among the compared established
options, at 42 formula-tree nodes under the report's convention.

Putting separation into G's conclusion gives H, a three-template,
43-node basis. It is strictly shorter than the current 54-node seeded
guard under this count, with the same recursion grammar, two varying
terms, one parameter, and three templates. H is equivalent to Sep+G
by elementary logical packaging, not a new arithmetic elimination.

For one varying term, the existing guarded identity schema G_id plus
separation and Shift has 47 nodes and five templates. Combining its
separation clause into the schema gives the recommended four-template
one-term form T plus Shift, at 48 nodes. This is elementary packaging
and a synthesis with the restricted grammar, not a new elimination of
separation. The report also proves the direct constructive normalization
X <-> N of the exclusive schema: 55 nodes decrease to 49 with Shift.

These counts cover displayed arithmetic formulas. They exclude the
computation equations, the term bodies substituted into a schema, and
the full cost of the language grammar or axiom recognizer. The template
counts, unlike the formula counts, include both computation families.
There is no absolute minimality claim.

CONTENTS

pra_normalized.tex             Complete source of the mathematical report
pra_normalized.pdf             Compiled, visually reviewed report
axioms.txt                     Standalone exact axiom specifications
formal/NormalizedOneTerm.lean  Finite-term constructive normalization proof
formal/lean_check.txt          Actual Lean compiler/axiom-audit output
artifacts/schema_sizes.py      Reproducible arithmetic formula-tree counter
artifacts/schema_sizes.json    Recorded output of the counter
source_audit.json              Pinned source paths, hashes, and review scope
VERIFICATION.txt              What was checked and what remains informal
rebuild.sh                     Build commands; optional Lean check
SHA256SUMS                     SHA-256 hashes of all other delivered files

VERIFICATION SCOPE

The full equivalence proof is written mathematics. The Lean certificate
formalizes only the normalization and stated selected consequences over
finite terms in an arbitrary carrier. It does not formalize the entire
recursive description language, pairing, equality reflection, or the
first-order conservative-extension theorem. It compiles without imports
under Lean 4.19.0. Its eighteen audited declarations use no axioms.
The arithmetic assumptions appear explicitly as hypotheses; the audit
does not make them automatic in arbitrary structures.

SOURCE SCOPE

All six PRA archives in docs/drafts at the pinned commit were downloaded
and their main specifications and relevant proofs reviewed. Their Git
blob hashes were verified. The docs/incoming listing and README were
also inspected. Unrelated incoming archives were not searched internally.
The audit records exactly these limits; no repository changes were made.

OPEN QUESTIONS

The paper does not derive Shift from the one-term schema, prove Shift
independent, or internally justify removing the counter from the update.
The final research section distinguishes these open reductions from
standard-model function-generation results and suggests formalization
targets.

BUILD

From this directory:

    bash rebuild.sh

Required for the PDF: Python 3, latexmk, and a TeX installation with the
packages listed at the top of pra_normalized.tex. If lean is available
on PATH, the script also checks the certificate. To select Lean explicitly:

    LEAN=/path/to/lean bash rebuild.sh

Use `sha256sum -c SHA256SUMS` before rebuilding to check delivered bytes.
Rebuilt PDFs can differ in timestamps and other metadata.
