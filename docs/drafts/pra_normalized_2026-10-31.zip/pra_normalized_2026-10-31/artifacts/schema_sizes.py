#!/usr/bin/env python3
"""Reproduce formula-tree counts. Pure syntax; not a theorem prover.

Every variable/constant occurrence, function application, equality,
connective, and individual quantifier binder costs one. Negation and XOR
are expanded. A schema placeholder application counts like an application,
including its displayed arguments; its substituted body is not counted.
"""
from collections import Counter
import json

def node(tag, *children): return (tag, children)
def var(name): return node('var:' + name)
def app(name, *xs): return node('app:' + name, *xs)
def eq(x, y): return node('eq', x, y)
def And(x, y): return node('and', x, y)
def Or(x, y): return node('or', x, y)
def Imp(x, y): return node('imp', x, y)
def All(x, f): return node('all:' + x, f)
def Not(x): return Imp(x, node('bottom'))
def Xor(x, y): return And(Or(x, y), Not(And(x, y)))
def S(x): return app('S', x)

n, a, x, y = map(var, ('n', 'a', 'x', 'y'))
zero = node('zero')
one = S(zero)
sep = Not(eq(zero, one))
def t(v): return app('t', v, a)
def f(v): return app('f', v, a)
def g(v): return app('g', v, a)
def e(v): return eq(f(v), g(v))
def b(v): return Or(eq(v, zero), eq(v, S(t(v))))
premise = All('n', Imp(b(n), eq(n, t(S(n)))))
old_x = All('a', Imp(premise, All('n', Xor(eq(n, zero), eq(n, S(t(n)))))))
new_n = All('a', Imp(premise, And(sep, All('n', b(n)))))
def bid(v): return Or(eq(v, zero), eq(v, t(v)))
premise_id = All('n', Imp(bid(n), eq(S(n), t(S(n)))))
guard_id = All('a', Imp(premise_id, All('n', bid(n))))
packed_id = All('a', Imp(premise_id, And(sep, All('n', bid(n)))))
shift = All('x', All('y', eq(app('M', S(x), S(y)), app('M', x, y))))
guard_g = All('a', Imp(All('n', Imp(Or(eq(n, zero), e(n)), e(S(n)))),
                       All('n', Or(eq(n, zero), e(n)))))
packed_g = All('a', Imp(All('n', Imp(Or(eq(n, zero), e(n)), e(S(n)))),
                        And(sep, All('n', Or(eq(n, zero), e(n))))))
def es(v): return eq(f(v), S(g(v)))
seed_a = All('a', Imp(And(eq(f(zero), zero),
    All('n', Imp(Or(eq(n, zero), es(n)), es(S(n))))),
    And(Not(eq(zero, S(g(zero)))), All('n', Or(eq(n, zero), es(n))))))

def counts(tree):
    tag, children = tree
    out = Counter(nodes=1)
    if tag == 'eq': out['equations'] += 1
    if tag.startswith('all:'): out['quantifiers'] += 1
    if tag in ('and', 'or', 'imp'): out[tag] += 1
    for c in children: out.update(counts(c))
    return out

def aggregate(*trees):
    out = Counter()
    for tree in trees: out.update(counts(tree))
    return dict(sorted(out.items()))

def report():
    result = {
        'G_plus_Sep': aggregate(guard_g, sep),
        'packed_H': aggregate(packed_g),
        'current_seeded_A': aggregate(seed_a),
        'current_X_plus_Shift': aggregate(old_x, shift),
        'normalized_N_plus_Shift': aggregate(new_n, shift),
        'current_Gid_plus_Sep_plus_Shift': aggregate(guard_id, sep, shift),
        'packed_T_plus_Shift': aggregate(packed_id, shift),
        'components': {'G': aggregate(guard_g), 'H': aggregate(packed_g), 'Sep': aggregate(sep),
                       'A': aggregate(seed_a), 'X': aggregate(old_x),
                       'N': aggregate(new_n), 'Shift': aggregate(shift),
                       'Gid': aggregate(guard_id), 'T': aggregate(packed_id)},
        'convention': 'Arithmetic formulas only; negation/XOR expanded; one parameter; 1=S0; M opaque.'
    }
    assert [result[k]['nodes'] for k in ('G_plus_Sep','current_seeded_A','current_X_plus_Shift','normalized_N_plus_Shift')] == [42,54,55,49]
    assert [result[k]['equations'] for k in ('G_plus_Sep','current_seeded_A','current_X_plus_Shift','normalized_N_plus_Shift')] == [6,7,8,7]
    assert result['current_Gid_plus_Sep_plus_Shift']['nodes'] == 47
    assert result['packed_T_plus_Shift']['nodes'] == 48
    assert result['packed_H']['nodes'] == 43
    return result

if __name__ == '__main__':
    print(json.dumps(report(), indent=2))
