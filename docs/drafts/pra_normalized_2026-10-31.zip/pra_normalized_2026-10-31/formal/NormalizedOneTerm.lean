/-
Constructive normalization certificate for the one-term PRA schema.

This is a standalone Lean 4 file with no imports. Schema instances range over
finite terms with exactly two available variables, not arbitrary semantic
functions. Variable 0 is the induction variable and variable 1 is the fixed
numerical parameter. Additional function symbols have explicitly given arities.

Certified: the original exclusive schema X is equivalent to the normalized
schema N; either schema derives separation and positive constructor coverage;
successor injectivity, successor nonzeroness, and zero decidability follow.

Scope: predecessor is supplied through its two defining equations. Its
realization in the initial-value recursion language is proved in the paper.
This file does not formalize the recursion-description grammar, the Shift
equation, equality reflection, pairing, or the full first-order PRA translation.
It uses Lean equality in an arbitrary carrier; it is a structural certificate,
not a complete formalization of object-language derivability.
-/

namespace NormalizedOneTerm

universe u v

structure Core (M : Type v) where
  zero : M
  succ : M → M
  pred : M → M
  pred_zero : pred zero = zero
  pred_succ : ∀ x, pred (succ x) = x

inductive Term (Sigma : Type u) (arity : Sigma → Nat) (n : Nat) : Type u where
  | var : Fin n → Term Sigma arity n
  | zero : Term Sigma arity n
  | succ : Term Sigma arity n → Term Sigma arity n
  | pred : Term Sigma arity n → Term Sigma arity n
  | extra : (f : Sigma) → (Fin (arity f) → Term Sigma arity n) →
      Term Sigma arity n

abbrev Extra (M : Type v) (Sigma : Type u) (arity : Sigma → Nat) :=
  (f : Sigma) → (Fin (arity f) → M) → M

variable {M : Type v} {Sigma : Type u} {arity : Sigma → Nat}

def Term.eval (C : Core M) (E : Extra M Sigma arity) {n : Nat}
    (t : Term Sigma arity n) (rho : Fin n → M) : M :=
  match t with
  | .var i => rho i
  | .zero => C.zero
  | .succ s => C.succ (s.eval C E rho)
  | .pred s => C.pred (s.eval C E rho)
  | .extra f args => E f (fun i => (args i).eval C E rho)

def env2 (x a : M) : Fin 2 → M :=
  fun i => if i.val = 0 then x else a

def Exclusive (P Q : Prop) : Prop := (P ∨ Q) ∧ ¬ (P ∧ Q)

def Separation (C : Core M) : Prop := C.zero ≠ C.succ C.zero

def Coverage (C : Core M) : Prop :=
  ∀ x, x = C.zero ∨ x = C.succ (C.pred x)

def Guard (C : Core M) (E : Extra M Sigma arity)
    (t : Term Sigma arity 2) (a x : M) : Prop :=
  x = C.zero ∨ x = C.succ (t.eval C E (env2 x a))

def Premise (C : Core M) (E : Extra M Sigma arity)
    (t : Term Sigma arity 2) (a : M) : Prop :=
  ∀ x, Guard C E t a x → x = t.eval C E (env2 (C.succ x) a)

/-- The original one-term schema, with exclusive disjunction. -/
def XSchema (C : Core M) (E : Extra M Sigma arity) : Prop :=
  ∀ (t : Term Sigma arity 2) (a : M), Premise C E t a →
    ∀ x, Exclusive (x = C.zero)
      (x = C.succ (t.eval C E (env2 x a)))

/-- The normalized schema has a fixed ground separation conjunct. -/
def NSchema (C : Core M) (E : Extra M Sigma arity) : Prop :=
  ∀ (t : Term Sigma arity 2) (a : M), Premise C E t a →
    Separation C ∧ ∀ x, Guard C E t a x

def predecessorTerm : Term Sigma arity 2 := .pred (.var ⟨0, Nat.zero_lt_succ 1⟩)

theorem predecessor_premise (C : Core M) (E : Extra M Sigma arity) (a : M) :
    Premise C E predecessorTerm a := by
  intro x _
  change x = C.pred (C.succ x)
  exact (C.pred_succ x).symm

theorem successor_injective (C : Core M) {x y : M}
    (h : C.succ x = C.succ y) : x = y := by
  have hp := congrArg C.pred h
  simpa only [C.pred_succ] using hp

theorem successor_nonzero_of_separation (C : Core M)
    (sep : Separation C) (x : M) : C.succ x ≠ C.zero := by
  intro hx
  have hp := congrArg C.pred hx
  have hx0 : x = C.zero := by
    simpa only [C.pred_succ, C.pred_zero] using hp
  have h10 : C.succ C.zero = C.zero := by
    simpa only [hx0] using hx
  exact sep h10.symm

theorem x_separation (C : Core M) (E : Extra M Sigma arity)
    (X : XSchema C E) : Separation C := by
  intro bad
  have h := X predecessorTerm C.zero
    (predecessor_premise C E C.zero) C.zero
  apply h.2
  constructor
  · rfl
  · change C.zero = C.succ (C.pred C.zero)
    simpa only [C.pred_zero] using bad

theorem x_coverage (C : Core M) (E : Extra M Sigma arity)
    (X : XSchema C E) : Coverage C := by
  intro x
  have h := X predecessorTerm C.zero
    (predecessor_premise C E C.zero) x
  exact h.1

theorem n_separation (C : Core M) (E : Extra M Sigma arity)
    (N : NSchema C E) : Separation C := by
  exact (N predecessorTerm C.zero (predecessor_premise C E C.zero)).1

theorem n_coverage (C : Core M) (E : Extra M Sigma arity)
    (N : NSchema C E) : Coverage C := by
  exact (N predecessorTerm C.zero (predecessor_premise C E C.zero)).2

theorem x_implies_n (C : Core M) (E : Extra M Sigma arity)
    (X : XSchema C E) : NSchema C E := by
  intro t a hp
  constructor
  · exact x_separation C E X
  · intro x
    exact (X t a hp x).1

theorem n_implies_x (C : Core M) (E : Extra M Sigma arity)
    (N : NSchema C E) : XSchema C E := by
  intro t a hp x
  have h := N t a hp
  constructor
  · exact h.2 x
  · intro overlap
    have h0 := overlap.1
    have hs := overlap.2
    have bad : C.succ (t.eval C E (env2 x a)) = C.zero :=
      hs.symm.trans h0
    exact successor_nonzero_of_separation C h.1 _ bad

theorem x_iff_n (C : Core M) (E : Extra M Sigma arity) :
    XSchema C E ↔ NSchema C E :=
  ⟨x_implies_n C E, n_implies_x C E⟩

theorem n_successor_nonzero (C : Core M) (E : Extra M Sigma arity)
    (N : NSchema C E) (x : M) : C.succ x ≠ C.zero :=
  successor_nonzero_of_separation C (n_separation C E N) x

theorem n_zero_decision (C : Core M) (E : Extra M Sigma arity)
    (N : NSchema C E) (x : M) : x = C.zero ∨ x ≠ C.zero := by
  rcases n_coverage C E N x with h0 | hs
  · exact Or.inl h0
  · apply Or.inr
    intro bad
    exact n_successor_nonzero C E N (C.pred x) (hs.symm.trans bad)

#print axioms predecessor_premise
#print axioms predecessorTerm
#print axioms env2
#print axioms x_separation
#print axioms x_coverage
#print axioms n_separation
#print axioms n_coverage
#print axioms successor_injective
#print axioms successor_nonzero_of_separation
#print axioms x_iff_n
#print axioms n_zero_decision

end NormalizedOneTerm

/-
The shorter guarded-identity presentation already present in the reviewed
one_term_shift draft, together with its normalized four-template packaging.
The following independent namespace certifies that packaging and the direct
identity-induction bootstrap. No Shift equation is used here.
-/

namespace GuardedIdentityNormalization

open NormalizedOneTerm

universe u v

variable {M : Type v} {Sigma : Type u} {arity : Sigma → Nat}

def IdGuard (C : Core M) (E : Extra M Sigma arity)
    (f : Term Sigma arity 2) (a x : M) : Prop :=
  x = C.zero ∨ x = f.eval C E (env2 x a)

def IdPremise (C : Core M) (E : Extra M Sigma arity)
    (f : Term Sigma arity 2) (a : M) : Prop :=
  ∀ x, IdGuard C E f a x →
    C.succ x = f.eval C E (env2 (C.succ x) a)

/-- The source draft's guarded-identity schema, without separation. -/
def GidSchema (C : Core M) (E : Extra M Sigma arity) : Prop :=
  ∀ (f : Term Sigma arity 2) (a : M), IdPremise C E f a →
    ∀ x, IdGuard C E f a x

/-- Packing separation into the schema's conclusion changes no strength. -/
def NidSchema (C : Core M) (E : Extra M Sigma arity) : Prop :=
  ∀ (f : Term Sigma arity 2) (a : M), IdPremise C E f a →
    Separation C ∧ ∀ x, IdGuard C E f a x

/-- This actual finite term is S(p(n)); it ignores the numerical parameter. -/
def constructorTerm : Term Sigma arity 2 :=
  .succ (.pred (.var ⟨0, Nat.zero_lt_succ 1⟩))

theorem constructor_premise (C : Core M) (E : Extra M Sigma arity) (a : M) :
    IdPremise C E constructorTerm a := by
  intro x _
  change C.succ x = C.succ (C.pred (C.succ x))
  exact congrArg C.succ (C.pred_succ x).symm

theorem gid_coverage (C : Core M) (E : Extra M Sigma arity)
    (G : GidSchema C E) : Coverage C := by
  exact G constructorTerm C.zero (constructor_premise C E C.zero)

theorem nid_separation (C : Core M) (E : Extra M Sigma arity)
    (N : NidSchema C E) : Separation C := by
  exact (N constructorTerm C.zero (constructor_premise C E C.zero)).1

theorem nid_coverage (C : Core M) (E : Extra M Sigma arity)
    (N : NidSchema C E) : Coverage C := by
  exact (N constructorTerm C.zero (constructor_premise C E C.zero)).2

theorem sep_gid_implies_nid (C : Core M) (E : Extra M Sigma arity)
    (H : Separation C ∧ GidSchema C E) : NidSchema C E := by
  intro f a hp
  exact ⟨H.1, H.2 f a hp⟩

theorem nid_implies_sep_gid (C : Core M) (E : Extra M Sigma arity)
    (N : NidSchema C E) : Separation C ∧ GidSchema C E := by
  constructor
  · exact nid_separation C E N
  · intro f a hp
    exact (N f a hp).2

theorem sep_gid_iff_nid (C : Core M) (E : Extra M Sigma arity) :
    (Separation C ∧ GidSchema C E) ↔ NidSchema C E :=
  ⟨sep_gid_implies_nid C E, nid_implies_sep_gid C E⟩

/-- Direct identity-target induction; its zero branch uses the given base. -/
theorem nid_identity_induction (C : Core M) (E : Extra M Sigma arity)
    (N : NidSchema C E) (f : Term Sigma arity 2) (a : M)
    (base : f.eval C E (env2 C.zero a) = C.zero)
    (step : ∀ x, f.eval C E (env2 x a) = x →
      f.eval C E (env2 (C.succ x) a) = C.succ x) :
    ∀ x, f.eval C E (env2 x a) = x := by
  have hp : IdPremise C E f a := by
    intro x hx
    have hfx : f.eval C E (env2 x a) = x := by
      rcases hx with h0 | hf
      · subst x
        exact base
      · exact hf.symm
    exact (step x hfx).symm
  have hc := (N f a hp).2
  intro x
  rcases hc x with h0 | hf
  · subst x
    exact base
  · exact hf.symm

#print axioms constructorTerm
#print axioms constructor_premise
#print axioms gid_coverage
#print axioms nid_separation
#print axioms nid_coverage
#print axioms sep_gid_iff_nid
#print axioms nid_identity_induction

end GuardedIdentityNormalization
