#!/usr/bin/env bash
set -eu
cd -- "$(dirname -- "$0")"

python3 artifacts/schema_sizes.py > artifacts/schema_sizes.json
latexmk -pdf -interaction=nonstopmode -halt-on-error pra_normalized.tex

if [ -n "${LEAN:-}" ]; then
    "$LEAN" formal/NormalizedOneTerm.lean > formal/lean_check.txt
elif command -v lean >/dev/null 2>&1; then
    lean formal/NormalizedOneTerm.lean > formal/lean_check.txt
else
    printf '%s\n' 'PDF and counts rebuilt. Lean was not found; certificate check skipped.'
fi
