TWO EQUALITY ALTERNATIVES SUFFICE FOR PRIMITIVE RECURSIVE ARITHMETIC
Classical and intuitionistic axiomatizations
Prepared for Vladimir Reshetnikov, 31 October 2026

MAIN RESULT

In the effective primitive-recursive description language, use:

  1. The two defining equations for every primitive recursion.
  2. The single separation axiom 0 != S(0).
  3. Induction only for matrices t(n,a)=0 OR t(n,a)=u(n,a),
     with arbitrary primitive-recursive terms t,u and all fixed parameters a.

In classical first-order logic this has exactly the consequences of standard
classical PRA. In ordinary intuitionistic first-order logic with equality,
the same arithmetic axioms have exactly the consequences of standard
intuitionistic PRA with quantifier-free induction. Equality is not assumed
decidable as part of the logic; its decidability is derived.

The reduction is constructive. Successor laws follow from defining equations
and separation. The restricted schema provides equation induction and positive
zero-or-successor coverage. A countdown-and-overflow invariant proves a faithful
numerical equality test. Every quantifier-free formula is then compiled to a
zero equation, recovering its induction instance.

PRECISE OPTIMALITY

Fix the background to the recursion equations plus 0 != 1. Among induction
restrictions allowing disjunctions of positive equations, width one fails
(the coordinatewise product N x N is a countermodel) and the displayed special
width-two pattern suffices. This is NOT a claim of globally shortest syntax,
minimum proof-checker size, or minimum Turing-machine state count.

A separate three-node Kripke model shows why the negative comparison bridges
in the reviewed classical drafts cannot simply be interpreted intuitionistically.
The paper also gives the compact classical comparison-plus-constancy alternative.

CONTENTS

  pra_two_equation.pdf           Complete article and mathematical proofs.
  pra_two_equation.tex           Self-contained LaTeX source.
  axioms.txt                    Standalone exact axiom specification.
  Makefile                      PDF build and companion-check commands.
  lean-toolchain                Lean 4.19.0 version pin for elan users.
  sources.json                  Pinned draft URLs and verified checksums.
  draft_audit.txt                Assessment of all six supplied drafts.
  VALIDATION.txt                Executed checks, scope, and tool versions.
  SHA256SUMS                    Checksums of all other deliverable files.

  artifacts/pra_syntax.py        Staged recursion syntax and formula compiler.
  artifacts/check_companion.py   Reproducible finite implementation checks.
  artifacts/program_descriptions.json
                                Six helper descriptions and eight formula examples.
  artifacts/check_report.json    Results and countermodel witness tables.

  formal/CompactPRA.lean         Constructive algebraic/logical Lean certificate.
  formal/Audit.lean              Dependency audit for principal theorems.
  formal/verification.txt        Actual Lean version and dependency-audit output.

REPRODUCING THE FILES

PDF: a normal TeX Live installation with latexmk and pdfLaTeX is sufficient.

  make pdf

The source uses standard packages including amsmath/amsthm, lmodern, microtype,
geometry, booktabs/tabularx, TikZ, xurl, and hyperref. No external figure or
bibliography file is required. Without latexmk, run pdflatex twice.

Python: Python 3.10 or later, standard library only.

  make check

or:

  python3 artifacts/check_companion.py --output-dir artifacts

Lean: Lean 4.19.0 with its bundled Std library; Mathlib is not required.

  make formal

or:

  cd formal
  lean -o CompactPRA.olean CompactPRA.lean
  LEAN_PATH=. lean Audit.lean

An explicit checker can be selected with make LEAN=/absolute/path/to/lean formal.

VERIFICATION BOUNDARIES

The paper contains the complete mathematical first-order equivalence proof,
the exact term grammar, and the infinite-model countermodel proofs.

The Lean certificate verifies the algebraic comparison proof, constructive
formula compilation/decidability, and the final induction reduction. Its
abstract induction hypothesis ranges over all ambient Lean functions and its
formula atoms are supplied as semantic functions. This hypothesis is stronger
than the syntactic first-order PRA schema. The certificate does not formalize
PR-term admissibility, first-order derivability, proof translation, or the
infinite countermodels. Those parts are mathematical proofs in the article.
Dependency checks report only propositional extensionality, with no classical
choice and no admitted proofs.

The Python script is an executable specification, not a proof checker.
Seventeen named checks (347 reported finite cases) passed. Finite samples
do not prove universal identities, schema equivalence, or all-schema model
validity. Its general external evaluator is not claimed to be primitive
recursive uniformly in the input program description.

Classical and intuitionistic PRA agree on quantifier-free consequences and
their universal closures, as proved in the article. The two exact-equivalence
claims are made separately in their respective ambient logics; they do not
identify unrestricted first-order sentence theories.

PROVENANCE

Reviewed source: VladimirReshetnikov/ProveIt, docs/drafts.
Pinned commit: ffbbfd31452e7188a9e3ba62c81a3bdb64072b82.
The six original archives are identified in sources.json and draft_audit.txt.
They are not duplicated in this package. The new two-term positive induction
pattern and the joint analysis are established here without a claim of
historical priority. Equation coding and recursion uniqueness have classical
antecedents cited in the article.
