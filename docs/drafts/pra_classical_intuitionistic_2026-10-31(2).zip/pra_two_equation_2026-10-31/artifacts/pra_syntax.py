"""Finite syntax and standard-model evaluation for the accompanying PRA note.

This module is an executable specification, not a proof checker.  In particular,
its evaluator neither proves identities nor decides equality of PR programs.
The uniform evaluator is not claimed to be primitive recursive in program code.

The initial term constructors are variables, zero, and successor.  A declaration
adds a fresh primitive-recursion symbol, with a base term and a step term using
only previously declared symbols.  Variables supply projections; substitution
and term nesting supply composition.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class Succ:
    term: Term


@dataclass(frozen=True)
class App:
    name: str
    arguments: tuple[Term, ...]


Term = Zero | Var | Succ | App
ZERO = Zero()
ONE = Succ(ZERO)


def app(name: str, *arguments: Term) -> App:
    return App(name, arguments)


def substitute(term: Term, replacements: Mapping[str, Term]) -> Term:
    """Simultaneous variable substitution; ordinary terms contain no binders."""
    match term:
        case Zero():
            return term
        case Var(name):
            return replacements.get(name, term)
        case Succ(inner):
            return Succ(substitute(inner, replacements))
        case App(name, arguments):
            return App(name, tuple(substitute(t, replacements) for t in arguments))
    raise TypeError(f"Not a term: {term!r}")


def term_json(term: Term) -> dict:
    match term:
        case Zero():
            return {"zero": True}
        case Var(name):
            return {"var": name}
        case Succ(inner):
            return {"successor": term_json(inner)}
        case App(name, arguments):
            return {"apply": name, "arguments": [term_json(t) for t in arguments]}
    raise TypeError(f"Not a term: {term!r}")


def term_text(term: Term) -> str:
    match term:
        case Zero():
            return "0"
        case Var(name):
            return name
        case Succ(inner):
            return f"S({term_text(inner)})"
        case App(name, arguments):
            return name + "(" + ", ".join(map(term_text, arguments)) + ")"
    raise TypeError(f"Not a term: {term!r}")


@dataclass(frozen=True)
class RecursionDeclaration:
    name: str
    parameters: tuple[str, ...]
    base: Term
    step: Term
    index_variable: str = "n"
    accumulator_variable: str = "r"

    @property
    def arity(self) -> int:
        return 1 + len(self.parameters)


class Registry:
    """Ordered, acyclic primitive-recursion declarations with explicit arities."""

    def __init__(self) -> None:
        self.declarations: dict[str, RecursionDeclaration] = {}
        self._cache: dict[tuple[str, tuple[int, ...]], int] = {}

    def check_term(self, term: Term, allowed_variables: set[str]) -> None:
        match term:
            case Zero():
                return
            case Var(name):
                if name not in allowed_variables:
                    raise ValueError(f"Undeclared variable: {name}")
            case Succ(inner):
                self.check_term(inner, allowed_variables)
            case App(name, arguments):
                if name not in self.declarations:
                    raise ValueError(f"Unknown or forward function reference: {name}")
                arity = self.declarations[name].arity
                if len(arguments) != arity:
                    raise ValueError(f"{name} expects {arity} arguments")
                for argument in arguments:
                    self.check_term(argument, allowed_variables)
            case _:
                raise TypeError(f"Not a term: {term!r}")

    def declare(self, declaration: RecursionDeclaration) -> None:
        name = declaration.name
        if not name.isidentifier() or name in {"S", "zero"}:
            raise ValueError(f"Invalid declaration name: {name}")
        if name in self.declarations:
            raise ValueError(f"Function name is already declared: {name}")
        local_names = (
            declaration.index_variable,
            declaration.accumulator_variable,
            *declaration.parameters,
        )
        if len(set(local_names)) != len(local_names):
            raise ValueError("Recursion variables and parameters must be distinct")
        if not all(name.isidentifier() for name in local_names):
            raise ValueError("Variable names must be identifiers")
        # Validation precedes insertion: self-reference is rejected as well.
        self.check_term(declaration.base, set(declaration.parameters))
        self.check_term(declaration.step, set(local_names))
        self.declarations[name] = declaration

    @staticmethod
    def _natural(value: int) -> None:
        if type(value) is not int or value < 0:
            raise ValueError("Numerical arguments must be nonnegative integers")

    def evaluate(self, term: Term, environment: Mapping[str, int]) -> int:
        self.check_term(term, set(environment))
        for value in environment.values():
            self._natural(value)
        return self._evaluate(term, environment)

    def _evaluate(self, term: Term, environment: Mapping[str, int]) -> int:
        match term:
            case Zero():
                return 0
            case Var(name):
                return environment[name]
            case Succ(inner):
                return 1 + self._evaluate(inner, environment)
            case App(name, arguments):
                values = tuple(self._evaluate(t, environment) for t in arguments)
                return self.call(name, *values)
        raise TypeError(f"Not a term: {term!r}")

    def call(self, name: str, *values: int) -> int:
        if name not in self.declarations:
            raise ValueError(f"Unknown function: {name}")
        declaration = self.declarations[name]
        if len(values) != declaration.arity:
            raise ValueError(f"{name} expects {declaration.arity} arguments")
        for value in values:
            self._natural(value)
        key = (name, values)
        if key in self._cache:
            return self._cache[key]
        environment = dict(zip(declaration.parameters, values[1:]))
        result = self._evaluate(declaration.base, environment)
        for index in range(values[0]):
            environment[declaration.index_variable] = index
            environment[declaration.accumulator_variable] = result
            result = self._evaluate(declaration.step, environment)
        self._cache[key] = result
        return result

    def to_json(self) -> dict:
        return {
            "status": "Syntactic program descriptions, not proof certificates",
            "initial_constructors": ["variable", "zero", "successor"],
            "recursion_argument": "first argument",
            "declarations": [
                {
                    "stage": stage,
                    "name": declaration.name,
                    "arity": declaration.arity,
                    "parameters": list(declaration.parameters),
                    "index_variable": declaration.index_variable,
                    "accumulator_variable": declaration.accumulator_variable,
                    "base": term_json(declaration.base),
                    "step": term_json(declaration.step),
                    "base_text": term_text(declaration.base),
                    "step_text": term_text(declaration.step),
                }
                for stage, declaration in enumerate(self.declarations.values(), 1)
            ],
        }


def arithmetic_registry() -> Registry:
    """The six helpers used in the constructive equality-test proof."""
    registry = Registry()
    n, r, a, b, y = map(Var, ("n", "r", "a", "b", "y"))
    definitions = [
        RecursionDeclaration("p", (), ZERO, n),
        RecursionDeclaration("z", (), ONE, ZERO),
        RecursionDeclaration("c", ("a", "b"), a, b),
        RecursionDeclaration("add", ("y",), y, Succ(r)),
        RecursionDeclaration("alpha", ("y",), y, app("p", r)),
        RecursionDeclaration(
            "beta", ("y",), ZERO,
            app("c", app("alpha", n, y), Succ(r), r),
        ),
    ]
    for definition in definitions:
        registry.declare(definition)
    return registry


def distance(left: Term, right: Term) -> Term:
    return app("add", app("alpha", left, right), app("beta", left, right))


@dataclass(frozen=True)
class Truth:
    value: bool


@dataclass(frozen=True)
class Eq:
    left: Term
    right: Term


@dataclass(frozen=True)
class Not:
    formula: Formula


@dataclass(frozen=True)
class And:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Or:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Implies:
    left: Formula
    right: Formula


Formula = Truth | Eq | Not | And | Or | Implies


def compile_error(formula: Formula) -> Term:
    """Syntactically compile a QF formula to its zero-for-truth error term."""
    match formula:
        case Truth(value):
            return ZERO if value else ONE
        case Eq(left, right):
            return distance(left, right)
        case Not(inner):
            return app("z", compile_error(inner))
        case And(left, right):
            return app("add", compile_error(left), compile_error(right))
        case Or(left, right):
            return app("c", compile_error(left), ZERO, compile_error(right))
        case Implies(left, right):
            return app("c", compile_error(left), compile_error(right), ZERO)
    raise TypeError(f"Not a formula: {formula!r}")


def evaluate_formula(
    formula: Formula, registry: Registry, environment: Mapping[str, int]
) -> bool:
    """Ordinary Boolean semantics in N, used only for finite sanity checks."""
    match formula:
        case Truth(value):
            return value
        case Eq(left, right):
            return registry.evaluate(left, environment) == registry.evaluate(right, environment)
        case Not(inner):
            return not evaluate_formula(inner, registry, environment)
        case And(left, right):
            return (evaluate_formula(left, registry, environment)
                    and evaluate_formula(right, registry, environment))
        case Or(left, right):
            return (evaluate_formula(left, registry, environment)
                    or evaluate_formula(right, registry, environment))
        case Implies(left, right):
            return (not evaluate_formula(left, registry, environment)
                    or evaluate_formula(right, registry, environment))
    raise TypeError(f"Not a formula: {formula!r}")


def formula_text(formula: Formula) -> str:
    match formula:
        case Truth(value):
            return "true" if value else "false"
        case Eq(left, right):
            return f"({term_text(left)} = {term_text(right)})"
        case Not(inner):
            return f"not {formula_text(inner)}"
        case And(left, right):
            return f"({formula_text(left)} and {formula_text(right)})"
        case Or(left, right):
            return f"({formula_text(left)} or {formula_text(right)})"
        case Implies(left, right):
            return f"({formula_text(left)} implies {formula_text(right)})"
    raise TypeError(f"Not a formula: {formula!r}")


def evaluate_pair(
    term: Term, registry: Registry, environment: Mapping[str, tuple[int, int]]
) -> tuple[int, int]:
    return tuple(
        registry.evaluate(term, {name: value[i] for name, value in environment.items()})
        for i in (0, 1)
    )


ACCESSIBLE = {
    "product": ("product",),
    "root": ("root", "left", "right"),
    "left": ("left",),
    "right": ("right",),
}


def force_qf(
    formula: Formula,
    world: str,
    registry: Registry,
    environment: Mapping[str, tuple[int, int]],
) -> bool:
    """Ground QF forcing for the product and three-node countermodel witnesses.

    All nodes have pair domain. Root/product equality is pair equality; leaf
    equality compares the corresponding coordinate. This persistent congruence
    semantics is equivalent to quotienting each leaf to N. Quantifiers and
    induction schemas are deliberately not implemented or finitely verified.
    """
    if world not in ACCESSIBLE:
        raise ValueError(f"Unknown world: {world}")
    match formula:
        case Truth(value):
            return value
        case Eq(left, right):
            first = evaluate_pair(left, registry, environment)
            second = evaluate_pair(right, registry, environment)
            if world in {"product", "root"}:
                return first == second
            coordinate = 0 if world == "left" else 1
            return first[coordinate] == second[coordinate]
        case Not(inner):
            return all(
                not force_qf(inner, later, registry, environment)
                for later in ACCESSIBLE[world]
            )
        case And(left, right):
            return (force_qf(left, world, registry, environment)
                    and force_qf(right, world, registry, environment))
        case Or(left, right):
            return (force_qf(left, world, registry, environment)
                    or force_qf(right, world, registry, environment))
        case Implies(left, right):
            return all(
                not force_qf(left, later, registry, environment)
                or force_qf(right, later, registry, environment)
                for later in ACCESSIBLE[world]
            )
    raise TypeError(f"Not a formula: {formula!r}")
