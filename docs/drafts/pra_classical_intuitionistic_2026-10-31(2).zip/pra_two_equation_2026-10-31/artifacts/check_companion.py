#!/usr/bin/env python3
"""Run named finite checks; write reproducible descriptions and witness tables.

Run: python3 check_companion.py --output-dir .
Requires Python 3.10 or newer and only the standard library.
No numerical check here is a proof of a general arithmetic theorem.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from pra_syntax import (
    ZERO, ONE, And, Eq, Implies, Not, Or, RecursionDeclaration, Registry,
    Succ, Truth, Var, app, arithmetic_registry, compile_error, distance,
    evaluate_formula, evaluate_pair, force_qf, formula_text, substitute,
    term_json, term_text,
)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).parent)
    destination = parser.parse_args().output_dir
    destination.mkdir(parents=True, exist_ok=True)
    registry = arithmetic_registry()
    checks: list[dict] = []

    def record(name: str, count: int, condition: bool, detail: str) -> None:
        if not condition:
            raise RuntimeError(f"Failed check: {name}")
        checks.append({"name": name, "cases": count, "passed": True, "detail": detail})

    def reject(name: str, action) -> None:
        try:
            action()
        except (ValueError, TypeError):
            record(name, 1, True, "Malformed syntax or numerical input rejected.")
        else:
            raise RuntimeError(f"Expected rejection: {name}")

    x, y, n = Var("x"), Var("y"), Var("n")
    record("six_staged_helpers", 6, list(registry.declarations) ==
           ["p", "z", "c", "add", "alpha", "beta"],
           "All six declarations pass syntactic variable, dependency, and arity checks.")
    reject("forward_reference", lambda: Registry().declare(
        RecursionDeclaration("bad", (), ZERO, app("later", n))))
    reject("self_reference", lambda: Registry().declare(
        RecursionDeclaration("bad", (), ZERO, app("bad", n))))
    reject("base_uses_recursion_index", lambda: Registry().declare(
        RecursionDeclaration("bad", (), n, ZERO)))
    reject("repeated_parameter", lambda: Registry().declare(
        RecursionDeclaration("bad", ("n",), ZERO, ZERO)))
    reject("incorrect_application_arity", lambda: registry.check_term(
        app("c", ZERO, ONE), set()))
    reject("negative_numerical_input", lambda: registry.call("p", -1))

    original = app("add", x, y)
    replaced = substitute(original, {"x": y, "y": ZERO})
    record("simultaneous_substitution", 1, replaced == app("add", y, ZERO),
           "A replacement term is not recursively rewritten by the same substitution.")

    pairs = [(a, b) for a in range(5) for b in range(5)]
    record("helper_standard_values", len(pairs), all(
        registry.call("add", a, b) == a + b
        and registry.call("alpha", a, b) == max(b - a, 0)
        and registry.call("beta", a, b) == max(a - b, 0)
        for a, b in pairs), "Inputs independently range from 0 through 4.")
    record("countdown_and_overflow_shifts", len(pairs), all(
        registry.call("alpha", a + 1, b + 1) == registry.call("alpha", a, b)
        and registry.call("beta", a + 1, b + 1) == registry.call("beta", a, b)
        for a, b in pairs), "Finite samples of the two shift identities in the proof.")
    record("balance_invariant", len(pairs), all(
        a + registry.call("alpha", a, b) == b + registry.call("beta", a, b)
        for a, b in pairs), "Finite samples; the general invariant is proved in the paper.")
    record("distance_zero_set", len(pairs), all(
        (registry.evaluate(distance(x, y), {"x": a, "y": b}) == 0) == (a == b)
        for a, b in pairs), "Check the exact helper used by the formula compiler.")

    samples = [
        Truth(True), Truth(False), Eq(x, y), Not(Eq(x, ZERO)),
        And(Eq(app("alpha", x, y), ZERO), Not(Eq(y, ZERO))),
        Or(Eq(x, ZERO), Eq(x, app("p", y))),
        Implies(Or(Eq(x, ZERO), Eq(x, y)), Eq(x, y)),
        Implies(Not(Eq(x, y)), Or(Not(Eq(x, ZERO)), Not(Eq(y, ZERO)))),
    ]
    compiled = [compile_error(formula) for formula in samples]
    for term in compiled:
        registry.check_term(term, {"x", "y"})
    record("quantifier_free_error_compiler", len(samples) * len(pairs), all(
        (registry.evaluate(term, {"x": a, "y": b}) == 0)
        == evaluate_formula(formula, registry, {"x": a, "y": b})
        for formula, term in zip(samples, compiled) for a, b in pairs),
        "Eight formulas cover truth, falsehood, equality, negation, and/or/implication.")

    shifted = Or(Eq(Succ(x), ZERO), Eq(Succ(x), Succ(y)))
    record("equation_induction_matrix_embedding", len(pairs), all(
        evaluate_formula(shifted, registry, {"x": a, "y": b}) == (a == b)
        for a, b in pairs), "The two-term disjunction embeds equality by successor.")
    coverage = Or(Eq(x, ZERO), Eq(x, Succ(app("p", x))))
    record("constructor_coverage_standard_samples", 5, all(
        evaluate_formula(coverage, registry, {"x": a}) for a in range(5)),
        "The second required induction instance has t=x and u=S(p(x)).")

    epsilon = app("z", distance(x, ZERO))
    equality = Eq(x, ZERO)
    disequality = Not(equality)
    epsilon_zero = Eq(epsilon, ZERO)
    exact_predecessor = Eq(Succ(app("p", x)), x)
    comparison_bridge = And(Implies(epsilon_zero, disequality),
                            Implies(disequality, epsilon_zero))
    predecessor_bridge = And(Implies(exact_predecessor, disequality),
                             Implies(disequality, exact_predecessor))
    equality_decision = Or(equality, disequality)
    witness_environment = {"x": (0, 1)}
    formulas = {
        "x_equals_zero": equality,
        "not_x_equals_zero": disequality,
        "epsilon_x_zero_equals_zero": epsilon_zero,
        "successor_predecessor_equals_x": exact_predecessor,
        "coverage": coverage,
        "equality_decision": equality_decision,
        "comparison_bridge_instance": comparison_bridge,
        "exact_predecessor_bridge_instance": predecessor_bridge,
    }
    table = [
        {"world": world, **{
            label: force_qf(formula, world, registry, witness_environment)
            for label, formula in formulas.items()
        }}
        for world in ("product", "root", "left", "right")
    ]
    rows = {row["world"]: row for row in table}
    record("classical_product_witness", 1,
           not rows["product"]["coverage"]
           and rows["product"]["not_x_equals_zero"]
           and not rows["product"]["comparison_bridge_instance"],
           "One ground witness in N x N; all-schema validity is a mathematical proof.")
    record("intuitionistic_three_node_witness", 3,
           not rows["root"]["coverage"]
           and not rows["root"]["equality_decision"]
           and all(rows[world]["comparison_bridge_instance"]
                   and rows[world]["exact_predecessor_bridge_instance"]
                   for world in ("root", "left", "right"))
           and rows["left"]["coverage"] and rows["right"]["coverage"],
           "Ground forcing computations; no quantifier or induction checker is implemented.")

    descriptions = registry.to_json()
    descriptions["compiled_samples"] = [
        {"formula": formula_text(formula), "error_term": term_json(term),
         "error_term_text": term_text(term)}
        for formula, term in zip(samples, compiled)
    ]
    (destination / "program_descriptions.json").write_text(
        json.dumps(descriptions, indent=2) + "\n", encoding="utf-8")
    report = {
        "status": "PASS: finite implementation checks only",
        "verification_boundary": [
            "This program is not a proof checker or proof-assistant formalization.",
            "Finite samples do not establish identities for all natural numbers.",
            "The equivalence theorems and all-schema countermodels are proved in the paper.",
            "The external evaluator is not claimed to be uniformly primitive recursive.",
        ],
        "named_checks": len(checks),
        "reported_cases": sum(item["cases"] for item in checks),
        "checks": checks,
        "countermodel_witness": {
            "x": [0, 1], "zero": [0, 0], "one": [1, 1],
            "p_x": list(evaluate_pair(app("p", x), registry, witness_environment)),
            "epsilon_x_zero": list(evaluate_pair(epsilon, registry, witness_environment)),
            "table": table,
            "semantics": {
                "product": "Single classical node; literal pair equality.",
                "root": "Successors: root, left, right; literal pair equality.",
                "left": "Terminal; equality of first coordinates.",
                "right": "Terminal; equality of second coordinates.",
            },
        },
    }
    (destination / "check_report.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "named_checks": len(checks),
                      "reported_cases": report["reported_cases"],
                      "outputs": ["check_report.json", "program_descriptions.json"]},
                     indent=2))


if __name__ == "__main__":
    main()
