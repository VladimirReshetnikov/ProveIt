import Std

/-!
# Constructive algebraic certificate for the compact PRA kernel

This file checks the algebraic reduction used in the accompanying paper.
The induction oracle below ranges over *all ambient Lean functions*.  It is
therefore a stronger, higher-order assumption than the syntactic PRA schema.
This is not a formalization of PRA syntax, derivability, or conservativity.

The proofs use that oracle only for the explicitly displayed functions in
`equation_induction`, `cover`, and the arithmetic lemmas.  In the paper those
functions are primitive-recursive terms, so each corresponding application is
an instance of the specified first-order schema.  No classical principles,
`sorry`, or additional arithmetic axioms are used in this certificate.

Checked with Lean 4.19.0, using only its bundled Std library.
-/

universe u

namespace CompactPRA

structure Kernel (A : Type u) where
  zero : A
  succ : A → A
  pred : A → A
  zeroTest : A → A
  choose : A → A → A → A
  add : A → A → A
  alpha : A → A → A
  beta : A → A → A
  zero_ne_one : zero ≠ succ zero
  pred_zero : pred zero = zero
  pred_succ : ∀ x, pred (succ x) = x
  zeroTest_zero : zeroTest zero = succ zero
  zeroTest_succ : ∀ x, zeroTest (succ x) = zero
  choose_zero : ∀ x y, choose zero x y = x
  choose_succ : ∀ n x y, choose (succ n) x y = y
  add_zero : ∀ y, add zero y = y
  add_succ : ∀ x y, add (succ x) y = succ (add x y)
  alpha_zero : ∀ y, alpha zero y = y
  alpha_succ : ∀ n y, alpha (succ n) y = pred (alpha n y)
  beta_zero : ∀ y, beta zero y = zero
  beta_succ : ∀ n y,
    beta (succ n) y = choose (alpha n y) (succ (beta n y)) (beta n y)
  split_induction : ∀ (t r : A → A),
    (t zero = zero ∨ t zero = r zero) →
    (∀ n, (t n = zero ∨ t n = r n) →
      (t (succ n) = zero ∨ t (succ n) = r (succ n))) →
    ∀ n, t n = zero ∨ t n = r n

namespace Kernel

variable {A : Type u} (K : Kernel A)

theorem succ_ne_zero (x : A) : K.succ x ≠ K.zero := by
  intro hx
  have hz := congrArg K.zeroTest hx
  have h01 : K.zero = K.succ K.zero := by
    simpa only [K.zeroTest_succ, K.zeroTest_zero] using hz
  exact K.zero_ne_one h01

theorem succ_injective {x y : A} (h : K.succ x = K.succ y) : x = y := by
  have hp := congrArg K.pred h
  simpa only [K.pred_succ] using hp

/-- The schema for `t = 0 ∨ t = r` contains ordinary equation induction. -/
theorem equation_induction (f g : A → A)
    (h0 : f K.zero = g K.zero)
    (hs : ∀ n, f n = g n → f (K.succ n) = g (K.succ n)) :
    ∀ n, f n = g n := by
  have h := K.split_induction (fun n => K.succ (f n))
    (fun n => K.succ (g n))
    (Or.inr (congrArg K.succ h0)) (by
      intro n hn
      cases hn with
      | inl hn => exact False.elim (K.succ_ne_zero (f n) hn)
      | inr hn =>
        exact Or.inr (congrArg K.succ (hs n (K.succ_injective hn))))
  intro n
  cases h n with
  | inl hn => exact False.elim (K.succ_ne_zero (f n) hn)
  | inr hn => exact K.succ_injective hn

/-- Constructor coverage is one direct instance of the restricted schema. -/
theorem cover (x : A) : x = K.zero ∨ x = K.succ (K.pred x) := by
  apply K.split_induction (fun n => n) (fun n => K.succ (K.pred n))
  · exact Or.inl rfl
  · intro n _
    exact Or.inr (congrArg K.succ (K.pred_succ n).symm)

theorem zero_decidable (x : A) : x = K.zero ∨ x ≠ K.zero := by
  cases K.cover x with
  | inl hx => exact Or.inl hx
  | inr hx =>
    exact Or.inr (fun h0 => K.succ_ne_zero (K.pred x) (hx.symm.trans h0))

theorem zeroTest_eq_zero_iff (x : A) : K.zeroTest x = K.zero ↔ x ≠ K.zero := by
  constructor
  · intro hz hx
    have h1 : K.zeroTest x = K.succ K.zero := by
      rw [hx, K.zeroTest_zero]
    exact K.zero_ne_one (hz.symm.trans h1)
  · intro hx
    cases K.cover x with
    | inl h0 => exact False.elim (hx h0)
    | inr hs => rw [hs, K.zeroTest_succ]

theorem choose_of_nonzero (a x y : A) (ha : a ≠ K.zero) :
    K.choose a x y = y := by
  cases K.cover a with
  | inl h0 => exact False.elim (ha h0)
  | inr hs => rw [hs, K.choose_succ]

theorem add_right_zero : ∀ x, K.add x K.zero = x := by
  apply K.equation_induction (fun x => K.add x K.zero) (fun x => x)
  · exact K.add_zero K.zero
  · intro x hx
    calc
      K.add (K.succ x) K.zero = K.succ (K.add x K.zero) := K.add_succ x K.zero
      _ = K.succ x := congrArg K.succ hx

theorem add_right_succ (x y : A) : K.add x (K.succ y) = K.succ (K.add x y) := by
  apply K.equation_induction (fun n => K.add n (K.succ y))
    (fun n => K.succ (K.add n y))
  · simp only [K.add_zero]
  · intro n hn
    calc
      K.add (K.succ n) (K.succ y) = K.succ (K.add n (K.succ y)) :=
        K.add_succ n (K.succ y)
      _ = K.succ (K.succ (K.add n y)) := congrArg K.succ hn
      _ = K.succ (K.add (K.succ n) y) := congrArg K.succ (K.add_succ n y).symm

theorem add_eq_zero_iff (x y : A) :
    K.add x y = K.zero ↔ x = K.zero ∧ y = K.zero := by
  constructor
  · intro h
    cases K.cover x with
    | inl hx =>
      exact ⟨hx, by simpa only [hx, K.add_zero] using h⟩
    | inr hx =>
      have hr : K.add (K.succ (K.pred x)) y = K.zero :=
        (congrArg (fun a => K.add a y) hx).symm.trans h
      have hs : K.succ (K.add (K.pred x) y) = K.zero := by
        simpa only [K.add_succ] using hr
      exact False.elim (K.succ_ne_zero _ hs)
  · intro h
    rw [h.1, h.2, K.add_zero]

theorem alpha_shift (n y : A) : K.alpha (K.succ n) (K.succ y) = K.alpha n y := by
  apply K.equation_induction (fun k => K.alpha (K.succ k) (K.succ y))
    (fun k => K.alpha k y)
  · simp only [K.alpha_succ, K.alpha_zero, K.pred_succ]
  · intro k hk
    calc
      K.alpha (K.succ (K.succ k)) (K.succ y) =
          K.pred (K.alpha (K.succ k) (K.succ y)) := K.alpha_succ _ _
      _ = K.pred (K.alpha k y) := congrArg K.pred hk
      _ = K.alpha (K.succ k) y := (K.alpha_succ k y).symm

theorem beta_shift (n y : A) : K.beta (K.succ n) (K.succ y) = K.beta n y := by
  apply K.equation_induction (fun k => K.beta (K.succ k) (K.succ y))
    (fun k => K.beta k y)
  · simp only [K.beta_succ, K.alpha_zero, K.beta_zero, K.choose_succ]
  · intro k hk
    calc
      K.beta (K.succ (K.succ k)) (K.succ y) =
          K.choose (K.alpha (K.succ k) (K.succ y))
            (K.succ (K.beta (K.succ k) (K.succ y)))
            (K.beta (K.succ k) (K.succ y)) := K.beta_succ _ _
      _ = K.choose (K.alpha k y) (K.succ (K.beta k y)) (K.beta k y) := by
        rw [K.alpha_shift, hk]
      _ = K.beta (K.succ k) y := (K.beta_succ k y).symm

theorem alpha_diagonal : ∀ n, K.alpha n n = K.zero := by
  apply K.equation_induction (fun n => K.alpha n n) (fun _ => K.zero)
  · exact K.alpha_zero K.zero
  · intro n hn
    exact (K.alpha_shift n n).trans hn

theorem beta_diagonal : ∀ n, K.beta n n = K.zero := by
  apply K.equation_induction (fun n => K.beta n n) (fun _ => K.zero)
  · exact K.beta_zero K.zero
  · intro n hn
    exact (K.beta_shift n n).trans hn

theorem balance (n y : A) :
    K.add n (K.alpha n y) = K.add y (K.beta n y) := by
  apply K.equation_induction (fun k => K.add k (K.alpha k y))
    (fun k => K.add y (K.beta k y))
  · simp only [K.alpha_zero, K.beta_zero, K.add_zero, K.add_right_zero]
  · intro k hk
    cases K.cover (K.alpha k y) with
    | inl ha =>
      have ha' : K.alpha (K.succ k) y = K.zero := by
        rw [K.alpha_succ, ha, K.pred_zero]
      have hb' : K.beta (K.succ k) y = K.succ (K.beta k y) := by
        rw [K.beta_succ, ha, K.choose_zero]
      have hk' : k = K.add y (K.beta k y) := by
        simpa only [ha, K.add_right_zero] using hk
      calc
        K.add (K.succ k) (K.alpha (K.succ k) y) = K.succ k := by
          rw [ha', K.add_right_zero]
        _ = K.succ (K.add y (K.beta k y)) := congrArg K.succ hk'
        _ = K.add y (K.succ (K.beta k y)) := (K.add_right_succ y _).symm
        _ = K.add y (K.beta (K.succ k) y) := congrArg (K.add y) hb'.symm
    | inr ha =>
      have hb' : K.beta (K.succ k) y = K.beta k y := by
        rw [K.beta_succ, ha, K.choose_succ]
      calc
        K.add (K.succ k) (K.alpha (K.succ k) y) =
            K.add (K.succ k) (K.pred (K.alpha k y)) :=
          congrArg (K.add (K.succ k)) (K.alpha_succ k y)
        _ = K.succ (K.add k (K.pred (K.alpha k y))) := K.add_succ _ _
        _ = K.add k (K.succ (K.pred (K.alpha k y))) :=
          (K.add_right_succ _ _).symm
        _ = K.add k (K.alpha k y) := congrArg (K.add k) ha.symm
        _ = K.add y (K.beta k y) := hk
        _ = K.add y (K.beta (K.succ k) y) := congrArg (K.add y) hb'.symm

def distance (x y : A) : A := K.add (K.alpha x y) (K.beta x y)

theorem distance_eq_zero_iff (x y : A) : K.distance x y = K.zero ↔ x = y := by
  constructor
  · intro hd
    have hab := (K.add_eq_zero_iff (K.alpha x y) (K.beta x y)).mp hd
    have hb := K.balance x y
    simpa only [hab.1, hab.2, K.add_right_zero] using hb
  · intro hxy
    cases hxy
    simp only [distance, K.alpha_diagonal, K.beta_diagonal, K.add_zero]

include K in
/-- Decidability as an intuitionistic disjunction, not a Lean typeclass instance. -/
theorem equality_decidable (x y : A) : x = y ∨ x ≠ y := by
  cases K.zero_decidable (K.distance x y) with
  | inl h0 => exact Or.inl ((K.distance_eq_zero_iff x y).mp h0)
  | inr h0 =>
    exact Or.inr (fun hxy => h0 ((K.distance_eq_zero_iff x y).mpr hxy))

end Kernel

/-!
The following syntax records only the propositional formula tree.  Atomic
"terms" are supplied as semantic functions `X → A`; no claim is made here
that this file decides or formalizes their primitive-recursive admissibility.
The paper supplies that syntactic side of the argument.
-/

universe v

inductive Formula (A : Type u) (X : Type v) where
  | truth
  | falsum
  | equation (f g : X → A)
  | negation (p : Formula A X)
  | conjunction (p q : Formula A X)
  | disjunction (p q : Formula A X)
  | implication (p q : Formula A X)

namespace Formula

variable {A : Type u} {X : Type v}

def holds : Formula A X → X → Prop
  | .truth, _ => True
  | .falsum, _ => False
  | .equation f g, x => f x = g x
  | .negation p, x => ¬p.holds x
  | .conjunction p q, x => p.holds x ∧ q.holds x
  | .disjunction p q, x => p.holds x ∨ q.holds x
  | .implication p q, x => p.holds x → q.holds x

/-- A code is zero exactly when the formula holds.  Nonzero values need not be one. -/
def errorCode (K : Kernel A) : Formula A X → X → A
  | .truth, _ => K.zero
  | .falsum, _ => K.succ K.zero
  | .equation f g, x => K.distance (f x) (g x)
  | .negation p, x => K.zeroTest (p.errorCode K x)
  | .conjunction p q, x => K.add (p.errorCode K x) (q.errorCode K x)
  | .disjunction p q, x => K.choose (p.errorCode K x) K.zero (q.errorCode K x)
  | .implication p q, x => K.choose (p.errorCode K x) (q.errorCode K x) K.zero

theorem errorCode_correct (K : Kernel A) (p : Formula A X) :
    ∀ x, p.errorCode K x = K.zero ↔ p.holds x := by
  induction p with
  | truth =>
    intro x
    exact ⟨fun _ => True.intro, fun _ => rfl⟩
  | falsum =>
    intro x
    exact ⟨K.succ_ne_zero K.zero, False.elim⟩
  | equation f g =>
    intro x
    exact K.distance_eq_zero_iff (f x) (g x)
  | negation p ih =>
    intro x
    exact (K.zeroTest_eq_zero_iff (p.errorCode K x)).trans (not_congr (ih x))
  | conjunction p q ihp ihq =>
    intro x
    exact (K.add_eq_zero_iff (p.errorCode K x) (q.errorCode K x)).trans
      (and_congr (ihp x) (ihq x))
  | disjunction p q ihp ihq =>
    intro x
    change K.choose (p.errorCode K x) K.zero (q.errorCode K x) = K.zero ↔
      p.holds x ∨ q.holds x
    cases K.zero_decidable (p.errorCode K x) with
    | inl hp =>
      rw [hp, K.choose_zero]
      exact ⟨fun _ => Or.inl ((ihp x).mp hp), fun _ => rfl⟩
    | inr hp =>
      rw [K.choose_of_nonzero _ _ _ hp]
      constructor
      · intro hq
        exact Or.inr ((ihq x).mp hq)
      · intro h
        cases h with
        | inl h => exact False.elim (hp ((ihp x).mpr h))
        | inr h => exact (ihq x).mpr h
  | implication p q ihp ihq =>
    intro x
    change K.choose (p.errorCode K x) (q.errorCode K x) K.zero = K.zero ↔
      (p.holds x → q.holds x)
    cases K.zero_decidable (p.errorCode K x) with
    | inl hp =>
      rw [hp, K.choose_zero]
      exact ⟨fun hq _ => (ihq x).mp hq,
        fun h => (ihq x).mpr (h ((ihp x).mp hp))⟩
    | inr hp =>
      rw [K.choose_of_nonzero _ _ _ hp]
      exact ⟨fun _ h => False.elim (hp ((ihp x).mpr h)), fun _ => rfl⟩

theorem formula_decidable (K : Kernel A) (p : Formula A X) (x : X) :
    p.holds x ∨ ¬p.holds x := by
  cases K.zero_decidable (p.errorCode K x) with
  | inl h => exact Or.inl ((p.errorCode_correct K x).mp h)
  | inr h => exact Or.inr (fun hp => h ((p.errorCode_correct K x).mpr hp))

/-- Semantic verification of the final induction reduction; see the scope warning above. -/
theorem formula_induction (K : Kernel A) (p : Formula A A)
    (h0 : p.holds K.zero)
    (hs : ∀ n, p.holds n → p.holds (K.succ n)) : ∀ n, p.holds n := by
  have he : ∀ n, p.errorCode K n = K.zero :=
    K.equation_induction (p.errorCode K) (fun _ => K.zero)
      ((p.errorCode_correct K K.zero).mpr h0)
      (fun n hn => (p.errorCode_correct K (K.succ n)).mpr
        (hs n ((p.errorCode_correct K n).mp hn)))
  intro n
  exact (p.errorCode_correct K n).mp (he n)

end Formula

end CompactPRA
