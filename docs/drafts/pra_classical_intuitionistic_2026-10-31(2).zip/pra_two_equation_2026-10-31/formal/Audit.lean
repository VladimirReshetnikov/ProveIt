import CompactPRA

-- These commands report dependencies of completed theorems, not new assumptions.
#print axioms CompactPRA.Kernel.distance_eq_zero_iff
#print axioms CompactPRA.Formula.errorCode_correct
#print axioms CompactPRA.Formula.formula_decidable
#print axioms CompactPRA.Formula.formula_induction
