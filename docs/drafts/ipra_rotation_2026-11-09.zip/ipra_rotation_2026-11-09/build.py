"""Compile the complete LaTeX paper locally, with shell escape disabled."""
import json
import os
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    executable = shutil.which('pdflatex')
    if executable is None:
        raise SystemExit('pdflatex is required; install ordinary TeX Live and rerun.')
    environment = dict(os.environ)
    environment['SOURCE_DATE_EPOCH'] = '1794257650'
    outputs = []
    command = [executable, '-no-shell-escape', '-interaction=nonstopmode',
               '-halt-on-error', '-file-line-error', 'report.tex']
    for _ in range(3):
        result = subprocess.run(command, cwd=ROOT, env=environment, text=True, capture_output=True)
        outputs.append(result.stdout + result.stderr)
        if result.returncode:
            (ROOT / 'evidence/build.log').write_text('\n'.join(outputs))
            raise SystemExit(result.stdout[-8000:] + result.stderr)
    log = (ROOT / 'report.log').read_text()
    (ROOT / 'evidence/build.log').write_text('\n'.join(outputs))
    receipt = {'status': 'compiled', 'passes': 3, 'shell_escape': False,
               'undefined_references': 'There were undefined references' in log,
               'overfull_box_count': log.count('Overfull \\hbox') + log.count('Overfull \\vbox'),
               'pdf_bytes': (ROOT / 'report.pdf').stat().st_size}
    (ROOT / 'evidence/build.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
