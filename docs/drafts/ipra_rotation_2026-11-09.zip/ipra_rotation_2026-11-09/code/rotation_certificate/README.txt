Scoped symbolic certificate for the successor/rotation argument
===============================================================

STATUS AND TRUST BOUNDARY

This is a symbolic equality-fragment replayer, NOT a complete proof
checker for iPRA, NOT a checker for every axiom of the new theory, and
NOT a Lean/Rocq formalization. It verifies the critical clock equations
and both equality-reflection directions from the exact named imports
below. The paper supplies the mathematical proofs of those imports from
its stated basis; this replayer does not independently prove them.

All variables a, b, n are arbitrary symbolic parameters. No standard-model
evaluation, numerical sample, arithmetic oracle, or numerical cutoff is
used in checking these equations. The producer is untrusted. The replayer
never imports it and checks each certificate node before accepting a goal.

FILES

  replay.py        Trusted scoped equality rules and exact import schemas.
  produce.py       Untrusted constructor for the finite certificate.
  certificate.json Frozen generated certificate, five symbolic theorems.
  verify.py        Replay plus 18 targeted rejection controls.
  results.json     Receipt, theorem/node counts, controls and SHA-256 hashes.

Only Python's standard library is required.

REPRODUCTION

From this directory:

  python3 replay.py certificate.json
  python3 verify.py

To regenerate the certificate first:

  python3 produce.py

The verifier also checks that the frozen certificate equals fresh producer
output. Altering the producer is not a way to bypass replay: the replayer
must still accept every proof node and the final equation.

THE FIVE VERIFIED THEOREMS

1. J(n,0) = D(n).
2. J(n,N(n)) = 0.
3. J(b,J(a,N(b))) = D(a).
4. Under retained hypothesis a=b: sg(J(a,N(b))) = 0.
5. Under retained hypothesis sg(J(a,N(b)))=0: a=b.

There are 45 nodes in the frozen certificate. The two conditional theorem
blocks keep their equations as actual retained assumptions. The replayer
does not silently promote them to unconditional lemmas. Within the ordinary
intuitionistic logic of the paper, discharging the last two assumptions
gives the two implications comprising equality reflection.

EXACT TRUSTED IMPORTS

Fixed computation instances:
  J_zero(a):              J(0,a)=a.
  J_successor(n,a):       J(Sn,a)=B(J(n,a)).
  N_zero:                 N(0)=0.
  sign_zero:              sg(0)=0.

The fixed additional axiom:
  rotation(n,a):          J(n,B(a))=B(J(n,a)).

The final paper defines the negative clock by N(n)=P(D(n)), where P is
predecessor. P is not a primitive term of this small replayer: the two
needed consequences N_zero and signed_backward are the explicit imports.
The earlier piecewise description of N is not required by this certificate.

Previously established paper lemmas:
  signed_backward(n):     B(N(Sn))=N(n).
  half_double(n):         H(D(n))=n.
  sign_reflection_rule:   from sg(u)=0 infer u=0.

Previously established paper rule lemmas, used with retained contexts:
  zero_stationarity_rule:
    from f(0)=0 and f(Sz)=f(z), infer f(t)=0.
  zero_signed_uniqueness_rule:
    from f(0)=0 and f(Sz)=B(f(z)), infer f(t)=D(t).

The replayer verifies the displayed premise forms exactly. In both rule
lemmas the active variable is a declared eigenvariable, cannot occur in
the target or retained assumptions, and cannot be a passive parameter.
The term template may contain only that variable and declared passive
parameters. The manuscript proves these rules from Cov and normalized
successor uniqueness; neither is an additional primitive axiom of the
new mathematical theory.

There is NO import of the negative diagonal, anchored translation,
J(n,0)=D(n), equality reflection, general iterate commutation, arbitrary
equation induction, or an arbitrary-equation/oracle inference. The first
three are derived and then reused only after their certificate blocks
have succeeded.

ORDINARY EQUALITY RULES

The replayer supports reflexivity, symmetry, transitivity, congruence by
a fixed numerical term template, retained hypotheses, and simultaneous
capture-free substitution. These numerical terms have no binders; the
special rule lemmas check their eigenvariable conditions explicitly.
Substitution is rejected if it changes any retained hypothesis. Reuse of
an earlier theorem checks the exact parameter substitution and is allowed
only for an earlier theorem with no retained hypotheses.

No formula evaluator or general logical parser is present. The explicit
first-order logic and the characteristic compilation of arbitrary
quantifier-free formulas remain written proofs in the paper.

REJECTION CONTROLS

The verification script corrupts the oracle name, rotation counter,
backward-clock instance, zero base, signed step, forward references,
eigenvariable target/body/context, passive-parameter condition, sign
reflection premise, conditional-lemma reuse, hypothesis index, retained
context substitution, term signature/arity, proof identifier, and final
goal. All 18 controls must reject. A separate small positive control
exercises reflexivity and ordinary simultaneous substitution.

SCOPE OF THE EVIDENCE

These tests check implemented side conditions and detect specified
transcription errors; finite testing alone is not a soundness proof.
The mathematical justification for the fragment is induction on its finite
proof nodes: every node is a valid equality inference or an exact instance
of a listed imported lemma, and every reused theorem was previously proved
without assumptions. The import list remains an explicit trust boundary.
The files are not candidates in the complete-checker size comparison.
