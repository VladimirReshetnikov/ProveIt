"""Replay the scoped certificate and require rejection of targeted corruptions."""
import copy
import hashlib
import json
from pathlib import Path

from produce import build, V, Z, S, J, B, SG
from replay import check_certificate, InvalidCertificate


HERE = Path(__file__).resolve().parent


def node(packet, theorem, identifier):
    return next(n for t in packet["theorems"] if t["name"] == theorem
                for n in t["nodes"] if n["id"] == identifier)


def run():
    certificate = json.loads((HERE / "certificate.json").read_text())
    if certificate != build():
        raise RuntimeError("producer and frozen certificate differ")
    receipt = check_certificate(certificate)
    controls = []

    def reject(label, change):
        altered = copy.deepcopy(certificate)
        change(altered)
        try:
            check_certificate(altered)
        except (InvalidCertificate, TypeError, KeyError, IndexError) as error:
            controls.append({"name": label, "result": "rejected", "reason": str(error)})
        else:
            raise RuntimeError("corrupted certificate was accepted: " + label)

    reject("unknown imported oracle", lambda p: node(p, "negative_diagonal", "rotation")
           .update(name="arbitrary_equation"))
    reject("rotation at wrong counter", lambda p: node(p, "negative_diagonal", "rotation")
           .update(arguments={"n": Z, "a": ["N", S(V("z"))]}))
    reject("wrong backward instance", lambda p: node(p, "negative_diagonal", "back")
           .update(mapping={"n": S(V("z"))}))
    reject("bad zero base", lambda p: node(p, "negative_diagonal", "result")
           .update(base="negative_zero"))
    reject("unproved step", lambda p: node(p, "anchored_translation", "result")
           .update(step="missing"))
    reject("signed step replaced by computation alone",
           lambda p: node(p, "anchored_translation", "result").update(step="step_compute"))
    reject("eigenvariable captured by target", lambda p: node(p, "negative_diagonal", "result")
           .update(target=V("z")))
    reject("unrelated eigenvariable captured by body",
           lambda p: node(p, "negative_diagonal", "result").update(body=J(V("w"), Z)))
    reject("parameter used as fresh induction variable",
           lambda p: node(p, "anchored_translation", "result").update(variable="b"))

    def context_capture(p):
        theorem = p["theorems"][1]
        theorem["hypotheses"] = [[V("z"), Z]]
    reject("eigenvariable in retained context", context_capture)

    def incorrect_sign_premise(p):
        p["theorems"][4]["hypotheses"] = [[J(V("a"), ["N", V("b")]), Z]]
    reject("incorrect sign reflection premise", incorrect_sign_premise)
    reject("conditional theorem imported without hypotheses",
           lambda p: node(p, "zero_test_implies_equality", "forward")
           .update(theorem="equality_implies_zero_test", mapping={"a": V("a"), "b": V("b")}))
    reject("invalid hypothesis reference",
           lambda p: node(p, "zero_test_implies_equality", "assumption").update(index=1))

    def hypothesis_substitution(p):
        theorem = p["theorems"][4]
        theorem["nodes"].insert(1, {"id": "bad_substitution", "rule": "subst",
                                  "proof": "assumption", "mapping": {"a": Z}})
    reject("substitution changes retained hypothesis", hypothesis_substitution)
    reject("unknown function symbol", lambda p: node(p, "negative_diagonal", "rotation")
           .update(arguments={"n": V("z"), "a": ["mystery"]}))
    reject("wrong function arity", lambda p: node(p, "negative_diagonal", "rotation")
           .update(arguments={"n": ["S"], "a": Z}))
    reject("duplicate proof identifier", lambda p: p["theorems"][0]["nodes"].append(
        copy.deepcopy(p["theorems"][0]["nodes"][0])))
    reject("goal changed after verification", lambda p: p["theorems"][-1].update(
        goal=[V("a"), S(V("b"))]))

    positive = {"schema_version": 1, "theorems": [{
        "name": "ordinary_equality_rules", "parameters": ["a"], "eigenvariables": [],
        "hypotheses": [], "goal": [S(V("a")), S(V("a"))],
        "nodes": [{"id": "r", "rule": "refl", "term": V("a")},
                  {"id": "s", "rule": "subst", "proof": "r", "mapping": {"a": S(V("a"))}}],
        "result": "s"}]}
    check_certificate(positive)
    receipt["positive_rule_control"] = "verified"
    receipt["negative_controls"] = controls
    receipt["negative_controls_rejected"] = len(controls)
    receipt["sha256"] = {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest()
                         for name in ("replay.py", "produce.py", "certificate.json")}
    (HERE / "results.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    run()
