"""Scoped symbolic equality replayer; this is NOT a complete iPRA checker.

The trusted imports are exactly IMPORTS and the three named imported rules
below. They are the mathematical lemmas established in the accompanying
paper. All certificate conclusions use arbitrary symbolic parameters.
"""
import json
import sys
from pathlib import Path


ARITIES = {"0": 0, "S": 1, "N": 1, "D": 1, "H": 1,
           "B": 1, "sg": 1, "J": 2}
ZERO = ["0"]


class InvalidCertificate(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise InvalidCertificate(message)


def exact_keys(obj, keys, where):
    require(type(obj) is dict and set(obj) == set(keys),
            "wrong fields in " + where)


def variable(name):
    return ["var", name]


def term_free(term):
    require(type(term) is list and bool(term), "term must be a nonempty array")
    if term[0] == "var":
        require(len(term) == 2 and type(term[1]) is str and bool(term[1]),
                "malformed variable")
        return {term[1]}
    require(type(term[0]) is str and term[0] in ARITIES,
            "unknown term constructor")
    require(len(term) == ARITIES[term[0]] + 1, "incorrect term arity")
    result = set()
    for child in term[1:]:
        result |= term_free(child)
    return result


def substitute(term, mapping):
    if term[0] == "var":
        return mapping.get(term[1], term)
    return [term[0], *(substitute(x, mapping) for x in term[1:])]


def equation(left, right):
    return [left, right]


def equation_free(eq):
    require(type(eq) is list and len(eq) == 2, "malformed equation")
    return term_free(eq[0]) | term_free(eq[1])


def equation_substitute(eq, mapping):
    return [substitute(side, mapping) for side in eq]


IMPORTS = {
    "J_zero": ("a",),
    "J_successor": ("n", "a"),
    "N_zero": (),
    "signed_backward": ("n",),
    "half_double": ("n",),
    "rotation": ("n", "a"),
    "sign_zero": (),
}


def imported_equation(name, arguments):
    require(name in IMPORTS, "unknown imported lemma")
    exact_keys(arguments, IMPORTS[name], "import arguments")
    if name == "J_zero":
        a = arguments["a"]
        return equation(["J", ZERO, a], a)
    if name == "J_successor":
        n, a = arguments["n"], arguments["a"]
        return equation(["J", ["S", n], a], ["B", ["J", n, a]])
    if name == "N_zero":
        return equation(["N", ZERO], ZERO)
    if name == "signed_backward":
        n = arguments["n"]
        return equation(["B", ["N", ["S", n]]], ["N", n])
    if name == "half_double":
        n = arguments["n"]
        return equation(["H", ["D", n]], n)
    if name == "rotation":
        n, a = arguments["n"], arguments["a"]
        return equation(["J", n, ["B", a]], ["B", ["J", n, a]])
    return equation(["sg", ZERO], ZERO)


RULE_FIELDS = {
    "import": {"name", "arguments"},
    "refl": {"term"},
    "hyp": {"index"},
    "sym": {"proof"},
    "trans": {"first", "second"},
    "cong": {"proof", "hole", "template"},
    "subst": {"proof", "mapping"},
    "use": {"theorem", "mapping"},
    "sign_reflection": {"proof"},
    "zero_stationarity": {"variable", "body", "target", "base", "step"},
    "zero_signed_uniqueness": {"variable", "body", "target", "base", "step"},
}


def check_certificate(packet):
    exact_keys(packet, {"schema_version", "theorems"}, "certificate")
    require(packet["schema_version"] == 1, "unknown certificate version")
    require(type(packet["theorems"]) is list and packet["theorems"],
            "no theorems")
    established = {}
    receipt = []
    imports_used = set()
    rules_used = set()
    total_nodes = 0
    for theorem in packet["theorems"]:
        exact_keys(theorem, {"name", "parameters", "eigenvariables", "hypotheses",
                             "goal", "nodes", "result"}, "theorem")
        name = theorem["name"]
        require(type(name) is str and name and name not in established,
                "invalid or duplicate theorem name")
        parameters, eigenvariables = theorem["parameters"], theorem["eigenvariables"]
        for names in (parameters, eigenvariables):
            require(type(names) is list and all(type(x) is str and x for x in names),
                    "invalid variable declaration")
            require(len(names) == len(set(names)), "duplicate variable declaration")
        require(not set(parameters) & set(eigenvariables), "parameter/eigenvariable collision")
        permitted = set(parameters) | set(eigenvariables)
        hypotheses = theorem["hypotheses"]
        require(type(hypotheses) is list, "hypotheses must be a list")
        for hyp in hypotheses:
            require(equation_free(hyp) <= set(parameters),
                    "eigenvariable occurs in retained hypotheses")
        require(equation_free(theorem["goal"]) <= set(parameters),
                "undeclared variable in theorem goal")
        require(type(theorem["nodes"]) is list, "nodes must be a list")
        proven = {}

        def previous(identifier):
            require(type(identifier) is str and identifier in proven,
                    "unknown or forward proof reference")
            return proven[identifier]

        def mapping_ok(mapping, extra=()):
            require(type(mapping) is dict and all(type(k) is str and k for k in mapping),
                    "malformed substitution")
            for value in mapping.values():
                require(term_free(value) <= permitted | set(extra),
                        "undeclared variable in substitution image")

        for node in theorem["nodes"]:
            require(type(node) is dict and node.get("rule") in RULE_FIELDS,
                    "unknown proof rule")
            rule = node["rule"]
            exact_keys(node, {"id", "rule"} | RULE_FIELDS[rule], "proof node")
            identifier = node["id"]
            require(type(identifier) is str and identifier and identifier not in proven,
                    "invalid or duplicate proof identifier")
            rules_used.add(rule)
            if rule == "import":
                mapping_ok(node["arguments"])
                result = imported_equation(node["name"], node["arguments"])
                imports_used.add(node["name"])
            elif rule == "refl":
                result = equation(node["term"], node["term"])
            elif rule == "hyp":
                index = node["index"]
                require(type(index) is int and 0 <= index < len(hypotheses),
                        "invalid hypothesis reference")
                result = hypotheses[index]
            elif rule == "sym":
                result = list(reversed(previous(node["proof"])))
            elif rule == "trans":
                first, second = previous(node["first"]), previous(node["second"])
                require(first[1] == second[0], "transitivity middle terms differ")
                result = equation(first[0], second[1])
            elif rule == "cong":
                source = previous(node["proof"])
                hole = node["hole"]
                require(type(hole) is str and hole and hole not in permitted,
                        "congruence hole must be fresh")
                require(term_free(node["template"]) <= permitted | {hole},
                        "undeclared variable in congruence template")
                result = [substitute(node["template"], {hole: side}) for side in source]
            elif rule == "subst":
                mapping_ok(node["mapping"])
                require(all(equation_substitute(hyp, node["mapping"]) == hyp
                            for hyp in hypotheses),
                        "substitution changes a retained hypothesis")
                result = equation_substitute(previous(node["proof"]), node["mapping"])
            elif rule == "use":
                require(node["theorem"] in established, "unknown earlier theorem")
                lemma = established[node["theorem"]]
                require(not lemma["hypotheses"], "cannot import a conditional theorem as closed")
                exact_keys(node["mapping"], lemma["parameters"], "theorem instantiation")
                mapping_ok(node["mapping"])
                result = equation_substitute(lemma["goal"], node["mapping"])
            elif rule == "sign_reflection":
                source = previous(node["proof"])
                require(source[1] == ZERO and source[0][0] == "sg",
                        "sign reflection requires sg(u)=0")
                result = equation(source[0][1], ZERO)
                imports_used.add("sign_reflection_rule")
            else:
                active, body, target = node["variable"], node["body"], node["target"]
                require(active in eigenvariables, "active variable is not a fresh eigenvariable")
                require(term_free(body) <= set(parameters) | {active},
                        "body captures an unrelated eigenvariable")
                require(term_free(target) <= set(parameters),
                        "target captures an eigenvariable")
                require(all(active not in equation_free(hyp) for hyp in hypotheses),
                        "active variable occurs in retained context")
                at_zero = substitute(body, {active: ZERO})
                at_successor = substitute(body, {active: ["S", variable(active)]})
                require(previous(node["base"]) == equation(at_zero, ZERO),
                        "zero-rule base has the wrong equation")
                right = body if rule == "zero_stationarity" else ["B", body]
                require(previous(node["step"]) == equation(at_successor, right),
                        "zero-rule step has the wrong equation")
                end = ZERO if rule == "zero_stationarity" else ["D", target]
                result = equation(substitute(body, {active: target}), end)
                imports_used.add(rule + "_rule")
            require(equation_free(result) <= permitted, "undeclared variable in proved equation")
            proven[identifier] = result
            total_nodes += 1
        require(previous(theorem["result"]) == theorem["goal"], "final equation differs from goal")
        established[name] = theorem
        receipt.append({"name": name, "parameters": parameters,
                        "retained_hypotheses": len(hypotheses),
                        "proof_nodes": len(proven), "status": "verified"})
    return {"status": "verified", "scope": "imported-lemma symbolic equality fragment",
            "theorems": receipt, "proof_nodes": total_nodes,
            "imports_used": sorted(imports_used), "rules_used": sorted(rules_used)}


def main():
    try:
        raw = Path(sys.argv[1]).read_text() if len(sys.argv) == 2 else sys.stdin.read()
        result = check_certificate(json.loads(raw))
    except (ValueError, TypeError, KeyError, IndexError, OSError) as error:
        print(json.dumps({"status": "rejected", "reason": str(error)}, indent=2))
        raise SystemExit(1)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
