"""Produce the untrusted symbolic certificate consumed by replay.py."""
import json
from pathlib import Path


def V(name):
    return ["var", name]


Z = ["0"]
S = lambda t: ["S", t]
N = lambda t: ["N", t]
D = lambda t: ["D", t]
H = lambda t: ["H", t]
B = lambda t: ["B", t]
SG = lambda t: ["sg", t]
J = lambda n, a: ["J", n, a]
EQ = lambda a, b: [a, b]


class Builder:
    def __init__(self, name, parameters, eigenvariables, hypotheses, goal):
        self.theorem = dict(name=name, parameters=parameters,
                            eigenvariables=eigenvariables, hypotheses=hypotheses,
                            goal=goal, nodes=[], result="")

    def add(self, identifier, rule, **fields):
        self.theorem["nodes"].append(dict(id=identifier, rule=rule, **fields))
        self.theorem["result"] = identifier
        return identifier

    def imp(self, identifier, name, **arguments):
        return self.add(identifier, "import", name=name, arguments=arguments)

    def use(self, identifier, theorem, **mapping):
        return self.add(identifier, "use", theorem=theorem, mapping=mapping)

    def sym(self, identifier, proof):
        return self.add(identifier, "sym", proof=proof)

    def trans(self, identifier, first, second):
        return self.add(identifier, "trans", first=first, second=second)

    def cong(self, identifier, proof, template):
        return self.add(identifier, "cong", proof=proof, hole="_hole", template=template)


def build():
    a, b, n, z, hole = (V(x) for x in ("a", "b", "n", "z", "_hole"))
    out = []

    p = Builder("forward_clock", ["n"], ["z"], [], EQ(J(n, Z), D(n)))
    p.imp("base", "J_zero", a=Z)
    p.imp("step", "J_successor", n=z, a=Z)
    p.add("result", "zero_signed_uniqueness", variable="z", body=J(z, Z),
          target=n, base="base", step="step")
    out.append(p.theorem)

    p = Builder("negative_diagonal", ["n"], ["z"], [], EQ(J(n, N(n)), Z))
    p.imp("base_compute", "J_zero", a=N(Z))
    p.imp("negative_zero", "N_zero")
    p.trans("base", "base_compute", "negative_zero")
    p.imp("step_compute", "J_successor", n=z, a=N(S(z)))
    p.imp("rotation", "rotation", n=z, a=N(S(z)))
    p.sym("rotation_reverse", "rotation")
    p.trans("rotated_step", "step_compute", "rotation_reverse")
    p.imp("back_at_parameter", "signed_backward", n=n)
    p.add("back", "subst", proof="back_at_parameter", mapping={"n": z})
    p.cong("inside_clock", "back", J(z, hole))
    p.trans("step", "rotated_step", "inside_clock")
    p.add("result", "zero_stationarity", variable="z", body=J(z, N(z)),
          target=n, base="base", step="step")
    out.append(p.theorem)

    p = Builder("anchored_translation", ["a", "b"], ["z"], [],
                EQ(J(b, J(a, N(b))), D(a)))
    p.imp("inner_zero", "J_zero", a=N(b))
    p.cong("base_compute", "inner_zero", J(b, hole))
    p.use("negative_base", "negative_diagonal", n=b)
    p.trans("base", "base_compute", "negative_base")
    p.imp("inner_step", "J_successor", n=z, a=N(b))
    p.cong("step_compute", "inner_step", J(b, hole))
    p.imp("rotate_outer", "rotation", n=b, a=J(z, N(b)))
    p.trans("step", "step_compute", "rotate_outer")
    p.add("result", "zero_signed_uniqueness", variable="z",
          body=J(b, J(z, N(b))), target=a, base="base", step="step")
    out.append(p.theorem)

    p = Builder("equality_implies_zero_test", ["a", "b"], [], [EQ(a, b)],
                EQ(SG(J(a, N(b))), Z))
    p.add("assumption", "hyp", index=0)
    p.cong("replace_first_argument", "assumption", J(hole, N(b)))
    p.use("negative", "negative_diagonal", n=b)
    p.trans("clock_zero", "replace_first_argument", "negative")
    p.cong("take_sign", "clock_zero", SG(hole))
    p.imp("sign_at_zero", "sign_zero")
    p.trans("result", "take_sign", "sign_at_zero")
    out.append(p.theorem)

    p = Builder("zero_test_implies_equality", ["a", "b"], [],
                [EQ(SG(J(a, N(b))), Z)], EQ(a, b))
    p.add("assumption", "hyp", index=0)
    p.add("clock_zero", "sign_reflection", proof="assumption")
    p.cong("apply_opposite_clock", "clock_zero", J(b, hole))
    p.use("anchored", "anchored_translation", a=a, b=b)
    p.sym("anchored_reverse", "anchored")
    p.trans("double_to_forward", "anchored_reverse", "apply_opposite_clock")
    p.use("forward", "forward_clock", n=b)
    p.trans("doubles_equal", "double_to_forward", "forward")
    p.cong("halves_equal", "doubles_equal", H(hole))
    p.imp("half_a", "half_double", n=a)
    p.sym("half_a_reverse", "half_a")
    p.trans("a_to_half_b", "half_a_reverse", "halves_equal")
    p.imp("half_b", "half_double", n=b)
    p.trans("result", "a_to_half_b", "half_b")
    out.append(p.theorem)

    return {"schema_version": 1, "theorems": out}


if __name__ == "__main__":
    destination = Path(__file__).with_name("certificate.json")
    destination.write_text(json.dumps(build(), indent=2) + "\n")
    print(destination.name)
