EXACT PROGRESSION-SELECTOR COUNTEREXAMPLE
======================================

Run with Python 3.10 or later and its standard library:

  python3 zero_pattern_certificate.py

The program writes zero_pattern_receipt.json and prints a short PASS line.
No network, theorem library, external proof assistant, or hidden arithmetic
oracle is used. The receipt includes the exact script SHA-256 and runtime
version. Assertions are not used as acceptance gates; the same checks run
under python3 -O.

Model and formulas
------------------
The numerical model is N x N with all operations interpreted coordinatewise.
Let 0=(0,0), 1=(1,1), a=(0,1), b=(1,0), and t=(0,1). The selector is

  C(0,r,s)=r,       C(n+1,r,s)=s.

For a fixed parameter c, put

  E_c(v) := [ C(v,c,1)=0 ].
  A := P_(u,v) E_a(v).
  B := P_(u,v) E_b(v).

Here P_(u,v) F means exists u, forall v, [F(v) implies F(Sv)]. The witness
variable u is unused in every displayed formula. Since the domain is
nonempty, its existential quantifier has no effect; u=(0,0) is a witness
whenever the universal progression condition holds.

The structural selector of A and B has equation matrix

  F_t(v) := [ C(t, C(v,a,1), C(v,b,1)) = 0 ].

E_a(v) is always false because its second coordinate is always 1=0.
E_b(v) is always false because its first coordinate is always 1=0.
Thus A and B are both true. But F_t(0,0) is true and F_t(1,1) is false.
Consequently P_(u,v) F_t(v) is false. The gluing inference

  A, B  ==>  M_t(A,B)

is therefore not valid under this progression interpretation.

Why the four-row calculation is EXACT
------------------------------------
This is not testing all numbers below an arbitrary numerical bound. Define

  pi(v1,v2) = ( [v1 != 0], [v2 != 0] ).

Its range consists of the four bit patterns 00,01,10,11. Each pattern has
a representative in N x N, and pi(Sv)=11 for EVERY v in N x N.

Every occurrence of v in E_a, E_b and F_t is a CONTROL argument of C.
The selected data are the fixed vectors a,b,0,1. Therefore each displayed
equation has exactly the same truth value at v and w whenever pi(v)=pi(w).
This follows directly from the two defining selector equations in each
coordinate. No magnitude beyond zero versus positive is inspected.
Each successor matrix likewise has the fixed truth value of class 11.

It follows that

  forall v in N x N [F(v) implies F(Sv)]

is equivalent to the conjunction of precisely the FOUR transitions in the
receipt. This proves exhaustiveness of the table for these particular
matrices. A bit 1 in a pattern means every positive number, not only the
numeral 1. No claim of such a reduction is made for arbitrary PR terms or
arbitrary progression formulas.

Controls
--------
The program also checks:

* Uniform zero selector 00: the selected matrix equals E_a on all four
  classes, so its progression is exactly A.
* Uniform positive selector 11: the selected matrix equals E_b on all four
  classes, so its progression is exactly B.
* Opposite mixed selector 10: with a,b unchanged, the selected antecedent
  stays false and the progression holds.
* Swapped a,b with selector 01: the progression holds.
* Swapped a,b with selector 10: the counterexample reappears.

Thus the failure is caused by mixed coordinate selection, and the program
does not incorrectly reject the ordinary zero/successor endpoint cases.

Relation to the paper
--------------------
The general validity of contextual equation induction in arbitrary powers
N^I, the parameter-fixing coordinate-transposition argument for uncountable
I, and automorphism faithfulness for definable interpretation round trips
are mathematical proofs in the manuscript. They are NOT established by
this script or by a finite table. Likewise this script is not an iPRA proof
checker or a verification of every native progression inference rule.
