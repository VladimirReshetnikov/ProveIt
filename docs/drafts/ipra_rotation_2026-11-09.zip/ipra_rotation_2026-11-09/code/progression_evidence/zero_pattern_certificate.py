"""Exact zero-pattern certificate for the progression-selector counterexample.

This is a four-class quotient calculation, not bounded numerical sampling.
It is not a proof checker for iPRA or for the progression calculus.
See README.txt for the factorization argument justifying the quotient.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import platform
from pathlib import Path


ZERO = (0, 0)
ONE = (1, 1)
PATTERNS = tuple(itertools.product((0, 1), repeat=2))


def select(control, at_zero, at_positive):
    """Coordinatewise selector; controls are exact zero/nonzero classes."""
    return tuple(
        at_zero[i] if control[i] == 0 else at_positive[i]
        for i in range(2)
    )


def equation(parameter, counter_pattern):
    """E_parameter(v) is the equation C(v, parameter, 1) = 0."""
    return select(counter_pattern, parameter, ONE) == ZERO


def selected_equation(selector_pattern, a, b, counter_pattern):
    """The literal equation in the structural selector of P E_a and P E_b."""
    left = select(counter_pattern, a, ONE)
    right = select(counter_pattern, b, ONE)
    return select(selector_pattern, left, right) == ZERO


def progression(matrix):
    """Evaluate forall v (matrix(v) -> matrix(Sv)) on its exact quotient."""
    rows = []
    for pattern in PATTERNS:
        antecedent = matrix(pattern)
        # Every coordinate of the successor of any natural number is positive.
        consequent = matrix(ONE)
        rows.append({
            "counter_zero_pattern": list(pattern),
            "successor_zero_pattern": list(ONE),
            "antecedent": antecedent,
            "consequent": consequent,
            "transition_holds": (not antecedent) or consequent,
        })
    return {"holds": all(row["transition_holds"] for row in rows), "rows": rows}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def verify_case(name, a, b, selector, expected_mux):
    a_result = progression(lambda v: equation(a, v))
    b_result = progression(lambda v: equation(b, v))
    mux_result = progression(lambda v: selected_equation(selector, a, b, v))
    require(a_result["holds"], name + ": A should hold")
    require(b_result["holds"], name + ": B should hold")
    require(mux_result["holds"] is expected_mux, name + ": wrong selector result")

    if selector == ZERO:
        require(
            all(selected_equation(selector, a, b, v) == equation(a, v)
                for v in PATTERNS),
            name + ": zero endpoint failed",
        )
    if selector == ONE:
        require(
            all(selected_equation(selector, a, b, v) == equation(b, v)
                for v in PATTERNS),
            name + ": positive endpoint failed",
        )

    return {
        "name": name,
        "a": list(a),
        "b": list(b),
        "selector_zero_pattern": list(selector),
        "A": a_result,
        "B": b_result,
        "selected_formula": mux_result,
        "expected_selected_formula": expected_mux,
    }


def build_receipt():
    a, b = (0, 1), (1, 0)
    specifications = (
        ("mixed_counterexample", a, b, (0, 1), False),
        ("uniform_zero_endpoint", a, b, ZERO, True),
        ("uniform_positive_endpoint", a, b, ONE, True),
        ("opposite_mixed_control", a, b, (1, 0), True),
        ("swapped_parameters_control", b, a, (0, 1), True),
        ("swapped_parameters_counterexample", b, a, (1, 0), False),
    )
    cases = [verify_case(*specification) for specification in specifications]
    bad = cases[0]["selected_formula"]["rows"][0]
    require(bad["antecedent"] and not bad["consequent"],
            "The explicit (0,0) -> (1,1) countertransition was not reproduced")
    require(all(not row["antecedent"] for row in cases[0]["A"]["rows"]),
            "A was expected to hold by an everywhere-false antecedent")
    require(all(not row["antecedent"] for row in cases[0]["B"]["rows"]),
            "B was expected to hold by an everywhere-false antecedent")
    return {
        "status": "PASS",
        "method": "exact quotient by the two coordinate zero/nonzero patterns",
        "pattern_meanings": {"0": "zero", "1": "positive (not a numerical bound)"},
        "number_of_patterns": len(PATTERNS),
        "number_of_cases": len(cases),
        "model": "N x N, primitive-recursive operations interpreted pointwise",
        "unused_existential_witness": [0, 0],
        "scope": (
            "Exact truth values of the displayed selector equations and their "
            "progression formulas. Does not verify the infinite-product theorem, "
            "all native inference rules, or a bi-interpretability theorem."
        ),
        "python_version": platform.python_version(),
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "cases": cases,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path,
        default=Path(__file__).with_name("zero_pattern_receipt.json"),
    )
    args = parser.parse_args()
    receipt = build_receipt()
    args.output.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print("PASS: 6 cases, each evaluated on all 4 exact zero-pattern classes")


if __name__ == "__main__":
    main()
