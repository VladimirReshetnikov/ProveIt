"""Finite transcription checks only; no metatheorem is inferred from them.

Each named function below follows the fixed PR description in the paper.
In particular J iterates B; it is not replaced by a signed-integer formula.
"""
import json
from functools import cache
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def P(n):
    return 0 if n == 0 else n - 1


def C(n, a, b):
    return a if n == 0 else b


def sg(n):
    return C(n, 0, 1)


@cache
def E(n):
    state = 0
    for _ in range(n):
        state = C(state, 1, 0)
    return state


@cache
def H(n):
    state = 0
    for counter in range(n):
        state = C(E(counter), state, state + 1)
    return state


@cache
def D(n):
    state = 0
    for _ in range(n):
        state += 2
    return state


def B(n):
    return C(E(n), n + 2, P(P(n)))


@cache
def J(n, a):
    state = a
    for _ in range(n):
        state = B(state)
    return state


def N(n):
    return P(D(n))


def main():
    bound = 96
    counts = {name: 0 for name in (
        'parity_range', 'parity_two_step', 'half_two_step',
        'double_parity', 'half_retraction', 'negative_backward',
        'forward_clock', 'negative_diagonal', 'rotation',
        'anchored_translation', 'equality_reflection', 'interleaving')}

    def check(name, condition):
        require(condition, 'failed numerical check: ' + name)
        counts[name] += 1

    for n in range(bound + 1):
        check('parity_range', E(n) in (0, 1))
        check('parity_two_step', E(n + 2) == E(n))
        check('half_two_step', H(n + 2) == H(n) + 1)
        check('double_parity', E(D(n)) == 0)
        check('half_retraction', H(D(n)) == n)
        check('negative_backward', B(N(n + 1)) == N(n))
        check('forward_clock', J(n, 0) == D(n))
        check('negative_diagonal', J(n, N(n)) == 0)
        interleaved = C(E(n), D(H(n)), D(H(n)) + 1)
        check('interleaving', interleaved == n)
        for a in range(bound + 1):
            check('rotation', J(n, B(a)) == B(J(n, a)))
            check('anchored_translation', J(a, J(n, N(a))) == D(n))
            check('equality_reflection', (sg(J(n, N(a))) == 0) == (n == a))

    negative_controls = {
        'negative_clock_cannot_be_doubling': J(1, D(1)) != 0,
        'signed_step_is_not_always_plus_two': B(1) != 3,
        'half_doubling_cannot_be_reversed': D(H(1)) != 1,
        'unanchored_composition_not_doubling': J(0, J(0, 1)) != D(0),
        'negative_clock_zero_must_be_patched': 2 * 0 - 1 != N(0),
    }
    require(all(negative_controls.values()), 'a negative control failed')
    receipt = {
        'status': 'passed',
        'scope': 'finite standard-number transcription checks, not a universal proof',
        'evaluation': 'fixed PR defining recurrences; memoization only',
        'inclusive_bound': bound,
        'counts': counts,
        'total_positive_checks': sum(counts.values()),
        'negative_controls_detected': negative_controls,
    }
    output = Path(__file__).resolve().parents[1] / 'evidence' / 'numerical_checks.json'
    output.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
