"""Remeasure unchanged complete comparator programs, with no execution of them."""
import ast
import hashlib
import importlib.util
import json
import platform
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('source_measure', ROOT / 'reference/source_measure.py')
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def renamed_metrics(path):
    tree = ast.parse(path.read_text())
    replacements = {'inst': 'i', 'check': 'c', 'take': 'q'}
    names = {n.id for n in ast.walk(tree) if isinstance(n, ast.Name)}
    names |= {n.name for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    names |= {n.arg for n in ast.walk(tree) if isinstance(n, ast.arg)}
    if replacements.keys() & names:
        if set(replacements.values()) & names:
            return {'status': 'not_applied', 'reason': 'existing names would collide'}

        class Rename(ast.NodeTransformer):
            def visit_Name(self, node):
                node.id = replacements.get(node.id, node.id)
                return node

            def visit_FunctionDef(self, node):
                self.generic_visit(node)
                node.name = replacements.get(node.name, node.name)
                return node

        tree = Rename().visit(tree)
    tree = ast.fix_missing_locations(measure.StripDocstrings().visit(tree))
    normalized = ast.unparse(tree) + '\n'
    return {'normalized_tokens': measure.significant(normalized),
            'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'normalized_bytes': len(normalized.encode())}


def main():
    manifest = json.loads((ROOT / 'reference/current_checker_manifest.json').read_text())
    rows = []
    for item in manifest['programs']:
        path = ROOT / item['local_file']
        result = measure.metrics(path)
        require(result['sha256'] == item['sha256'], 'changed frozen source: ' + path.name)
        rows.append({**item, **{key: result[key] for key in FIELDS},
                     'uniform_name_control': renamed_metrics(path)})
    normalizer_hash = hashlib.sha256((ROOT / 'reference/source_measure.py').read_bytes()).hexdigest()
    require(normalizer_hash == manifest['normalizer_sha256'], 'changed normalizer')
    minimum = {key: min(row[key] for row in rows) for key in FIELDS}
    require(minimum == {'normalized_tokens': 309, 'ast_nodes': 344, 'normalized_bytes': 864},
            'source frontier differs; inspect Python version or source identities')
    receipt = {
        'status': 'passed', 'python': platform.python_version(),
        'implementation': platform.python_implementation(), 'snapshot': manifest['snapshot'],
        'complete_source_count': len(rows), 'whole_source_minimum': minimum,
        'attainers': {key: [r['name'] for r in rows if r[key] == minimum[key]] for key in FIELDS},
        'normalizer_sha256': normalizer_hash, 'programs': rows,
    }
    (ROOT / 'evidence/baseline_metrics.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({k: v for k, v in receipt.items() if k != 'programs'}, indent=2))


if __name__ == '__main__':
    main()
