FROZEN REFERENCE MATERIAL
=========================

checkers/ contains eighteen distinct complete native proof-checker sources
from the ProveIt snapshot identified in evidence/source_snapshot.json.
current_checker_manifest.json records original archive member paths and
SHA-256 identities. inherited_checker_manifest.json preserves the source
manifest supplied with the reconstructed draft.

source_measure.py is the unchanged inherited normalizer. The measurement
driver uses its whole-source profile. Actual leading docstrings and comments
are removed before ast.unparse; imports, JSON input, checking logic, and the
verdict driver remain charged. Its exact CPython version affects normalized
source and is therefore recorded in the measurement receipt.

The inherited license is LICENSE-inherited.txt.

These are comparators for the earlier native calculus, not implementations
of the rotation theory in this report. No source-level change to these
checkers is presented as a contribution of this package.
