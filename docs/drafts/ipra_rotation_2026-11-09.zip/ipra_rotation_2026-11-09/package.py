"""Create a reproducible ZIP and checksum manifest for the research package."""
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {'.aux', '.out', '.toc', '.synctex.gz', '.pyc'}


def payload():
    for path in sorted(ROOT.rglob('*')):
        relative = path.relative_to(ROOT)
        if not path.is_file() or '__pycache__' in relative.parts:
            continue
        if path.name == 'MANIFEST.json' or relative.as_posix() == 'report.log':
            continue
        if path.suffix in EXCLUDED_SUFFIXES:
            continue
        yield path


def main():
    paths = list(payload())
    entries = [{'path': p.relative_to(ROOT).as_posix(), 'bytes': p.stat().st_size,
                'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]
    manifest = ROOT / 'MANIFEST.json'
    manifest.write_text(json.dumps({'format': 1, 'files': entries}, indent=2) + '\n')
    paths.append(manifest)
    output = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(paths):
            name = ROOT.name + '/' + path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(name, (2026, 11, 9, 20, 54, 10))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, path.read_bytes())
    with zipfile.ZipFile(output) as archive:
        if archive.testzip() is not None:
            raise ValueError('ZIP CRC verification failed')
        for entry in entries:
            data = archive.read(ROOT.name + '/' + entry['path'])
            if hashlib.sha256(data).hexdigest() != entry['sha256']:
                raise ValueError('ZIP content identity failed: ' + entry['path'])
    print(json.dumps({'file': str(output), 'payload_files': len(paths),
                      'bytes': output.stat().st_size,
                      'sha256': hashlib.sha256(output.read_bytes()).hexdigest()}, indent=2))


if __name__ == '__main__':
    main()
