"""Offline reproduction of the explicitly scoped evidence."""
import json
import platform
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run(script, *arguments, optimized=False):
    path = ROOT / script
    command = [sys.executable] + (['-O'] if optimized else []) + [path.name, *arguments]
    result = subprocess.run(command, cwd=path.parent, text=True, capture_output=True)
    if result.returncode:
        raise RuntimeError(script + '\n' + result.stdout + result.stderr)
    return result.stdout


def main():
    tasks = [
        ('code/measure_baselines.py', ()),
        ('code/numerical_checks.py', ()),
        ('code/rotation_certificate/verify.py', ()),
        ('code/progression_evidence/zero_pattern_certificate.py', ()),
    ]
    completed = []
    for script, arguments in tasks:
        run(script, *arguments)
        completed.append({'script': script, 'status': 'passed'})
        print('PASS ' + script)
    ordinary = run('code/rotation_certificate/replay.py', 'certificate.json')
    optimized = run('code/rotation_certificate/replay.py', 'certificate.json', optimized=True)
    if ordinary != optimized:
        raise RuntimeError('optimized symbolic replay changed output')
    ordinary = run('code/progression_evidence/zero_pattern_certificate.py')
    optimized = run('code/progression_evidence/zero_pattern_certificate.py', optimized=True)
    if ordinary != optimized:
        raise RuntimeError('optimized zero-pattern evidence changed output')
    receipt = {'status': 'passed', 'python': platform.python_version(), 'tasks': completed,
               'normal_and_optimized_replays_match': True,
               'scope': 'finite symbolic and exact-pattern evidence; not a mechanized full equivalence proof'}
    (ROOT / 'evidence/reproduction.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('PASS normal/optimized replay agreement')


if __name__ == '__main__':
    main()
