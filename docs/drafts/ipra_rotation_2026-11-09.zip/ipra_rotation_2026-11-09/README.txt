SUCCESSOR UNIQUENESS AND ONE ROTATION LAW
Research package prepared for Vladimir Reshetnikov, November 9, 2026

START HERE
==========
Open report.pdf. The complete editable paper is report.tex with sections/*.tex.

RESULT
======
Over the full finite-description primitive-recursive language and ordinary
intuitionistic first-order logic, take the defining equations, numerical
coverage x=0 or x=S(P(x)), separation (0=1)->bottom, zero-initialized
successor uniqueness, and the single fixed rotation equation

    J(n,B(a)) = B(J(n,a)).

B is the specified signed-counter update and J its primitive-recursive
iterator. This theory and full first-order iPRA derive exactly the same
sequents. Identity interpretations give both composites and equiconsistency.
Relative to the retained base, the one rotation equation is equivalent to
the entire contextual uniqueness schema for the fixed signed update B.
The paper supplies all definitions, logical rules, freshness conditions,
and the constructive equality-reflection argument.

STATUS OF THE REQUESTED MINIMUM
===============================
The strict complete-checker reduction requested by the user is NOT achieved.
The current literal-source frontier in the eleven inspected ProveIt archives
is 309 normalized tokens / 344 AST nodes / 864 normalized bytes. Those three
values belong to one inherited complete source. This package reproduces its
measurements; it does not pass off a fragment verifier as a smaller checker.
These are finite-corpus minima, not a universal mathematical lower bound.
The byte frontier also depends on identifier spelling; the naming control is
included. Historical priority or absolute simplestness is not claimed.

The new positive contribution relative to the inspected two-update theory
is the fixed-rotation schema trade and its anchored, zero-based proof.

REPRODUCTION
============
From the extracted package directory:

    python3 reproduce.py
    python3 build.py
    python3 package.py

The first command runs the numerical checks, exact progression evidence,
symbolic certificate replay, negative controls, and whole-source comparator
measurements. Use CPython 3.12 to reproduce the recorded AST/unparse metrics;
the actual run used CPython 3.12.14. No third-party Python modules or network
access are required for these checks.

The second command requires pdflatex and ordinary TeX Live packages. It
compiles three passes with shell escape disabled and records the build log.
The delivered PDF has also been rasterized and visually inspected.

The third command regenerates MANIFEST.json and a ZIP beside this directory,
with fixed archive timestamps, CRC checks, and payload SHA-256 verification.
The manifest includes all payload files except itself. Generated TeX working
files and Python bytecode caches are omitted from the archive.

WHAT IS AND IS NOT MACHINE-CHECKED
================================
1. The main mathematical equivalence has a complete written proof and
   independent assistant reviews. It is not a Lean/Rocq mechanization or
   external peer review.
2. code/rotation_certificate checks 45 symbolic nodes for five key results,
   with explicit imported arithmetic lemmas and 18 rejected corrupted
   certificates. Its README lists the entire trust boundary. The imported
   lemmas are proved in the paper, not derived by that fragment replayer.
3. code/progression_evidence gives an exact four-pattern reduction for six
   selector examples. It is exact for those formulas, not a machine proof
   of the infinite-product or automorphism theorem in the appendix.
4. code/numerical_checks.py makes 29,100 finite positive checks and five
   negative controls using the actual recursive definitions. Such checks
   detect transcription errors; they do not prove universal identities.
5. Eighteen unchanged inherited complete checkers are measured as whole
   programs. They implement the earlier native calculus, not the new
   rotation presentation. Their source hashes and original archive members
   are recorded in reference/current_checker_manifest.json.

CONTENTS
========
report.pdf, report.tex, sections/  Complete paper and its source
code/                            Evidence programs and scoped certificates
reference/                       Frozen comparator sources and normalizer
evidence/                        Source snapshot and execution/build receipts
reviews/                         Independent assistant audits
reproduce.py, build.py            Offline evidence and paper build drivers
package.py, MANIFEST.json         Archive construction and integrity metadata
ATTRIBUTION.txt                   Provenance and contribution boundaries

SOURCE SNAPSHOT
===============
https://github.com/VladimirReshetnikov/ProveIt/tree/89fd4b4c5cd158259b1f2846f63e3d98f053553c/docs/drafts

All eleven ZIPs were pinned and verified by length, Git blob identity, and
SHA-256. evidence/source_snapshot.json records their identities. The GitHub
repository was only read. Nothing was submitted, published, or modified there.

OPEN QUESTIONS
==============
Can rotation itself be removed from this base? Can the argument be transferred
to a genuinely smaller numerical grammar? Can its exact rule trade yield a
complete checker below the inherited frontier? The paper does not resolve
these questions or claim an impossibility theorem for other approaches.
