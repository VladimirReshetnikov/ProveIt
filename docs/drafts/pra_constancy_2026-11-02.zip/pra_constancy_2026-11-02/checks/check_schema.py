#!/usr/bin/env python3
"""Independently count expanded finite axiom syntax trees.

This is a syntax/count/substitution audit, NOT a mathematical proof checker.
Each formula is first constructed from its expanded terms and connectives;
recursive tree traversal is then compared with the report's closed formulas.
The random input terms use a fixed seed.  No third-party packages are needed.

Counting convention: one node per variable, constant, ordinary function
application, equality, connective, falsity, or quantifier.  An atomic-equality
conditional ``if s=t then b else c`` contributes TWO nodes (the conditional
constructor and its equality condition), in addition to its four term trees.
Stored recursor descriptors are frozen under active substitution.  We report
both active counts (descriptor labels excluded) and fully expanded counts
(each descriptor body charged recursively at every occurrence).

The templates can be counted on any term tree.  Counting the delayed G
template on a counter-recursion input is a comparison of syntactic profiles,
not a claim that the original delayed language contains that input.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import random
from typing import Union


@dataclass(frozen=True)
class Term:
    tag: str
    args: tuple["Term", ...] = ()
    name: str = ""
    descriptor: "Term | None" = None


@dataclass(frozen=True)
class Formula:
    tag: str
    args: tuple[Union[Term, "Formula"], ...] = ()
    variable: str = ""


def V(name: str) -> Term:
    return Term("var", name=name)


ZERO = Term("zero")


def S(t: Term) -> Term:
    return Term("succ", (t,))


ONE = S(ZERO)
N, A = V("n"), V("a")


def Call(family: str, descriptor: Term, x: Term, y: Term) -> Term:
    assert family in {"R", "D"}
    return Term("call", (x, y), family, descriptor)


def Ite(s: Term, t: Term, yes: Term, no: Term) -> Term:
    return Term("ite", (s, t, yes, no))


def Eq(s: Term, t: Term) -> Formula:
    return Formula("eq", (s, t))


BOT = Formula("bottom")


def And(p: Formula, q: Formula) -> Formula:
    return Formula("and", (p, q))


def Or(p: Formula, q: Formula) -> Formula:
    return Formula("or", (p, q))


def Imp(p: Formula, q: Formula) -> Formula:
    return Formula("implies", (p, q))


def All(variable: str, p: Formula) -> Formula:
    return Formula("forall", (p,), variable)


SIGMA = Imp(Eq(ZERO, ONE), BOT)


def subst(t: Term, mapping: dict[str, Term]) -> Term:
    """Simultaneous ACTIVE substitution; never recurse into a descriptor."""
    if t.tag == "var":
        return mapping.get(t.name, t)
    return Term(t.tag, tuple(subst(a, mapping) for a in t.args),
                t.name, t.descriptor)


def free_variables(tree: Union[Term, Formula]) -> set[str]:
    if isinstance(tree, Term):
        if tree.tag == "var":
            return {tree.name}
        return set().union(*(free_variables(x) for x in tree.args))
    result = set().union(*(free_variables(x) for x in tree.args))
    if tree.tag == "forall":
        result.discard(tree.variable)
    return result


def active_names(tree: Union[Term, Formula]) -> set[str]:
    names: set[str] = set()
    if isinstance(tree, Term) and tree.tag == "var":
        names.add(tree.name)
    if isinstance(tree, Formula) and tree.tag == "forall":
        names.add(tree.variable)
    for child in tree.args:
        names |= active_names(child)
    return names


def count(tree: Union[Term, Formula], charge_descriptors: bool = False) -> int:
    own = 2 if isinstance(tree, Term) and tree.tag == "ite" else 1
    total = own + sum(count(x, charge_descriptors) for x in tree.args)
    if isinstance(tree, Term) and tree.descriptor is not None and charge_descriptors:
        total += count(tree.descriptor, True)
    return total


def occurrences(t: Term, variable: str) -> int:
    return int(t.tag == "var" and t.name == variable) + sum(
        occurrences(x, variable) for x in t.args)


def quantifier_profile(tree: Union[Term, Formula]) -> tuple[int, int]:
    if isinstance(tree, Term):
        return 0, 0
    children = [quantifier_profile(x) for x in tree.args]
    quantifiers = sum(n for n, _ in children)
    depth = max((d for _, d in children), default=0)
    if tree.tag == "forall":
        return quantifiers + 1, depth + 1
    return quantifiers, depth


def validate_finite(tree: Union[Term, Formula], ancestors: frozenset[int] = frozenset()) -> None:
    assert id(tree) not in ancestors, "cyclic syntax or self-referential descriptor"
    trail = ancestors | {id(tree)}
    if isinstance(tree, Term):
        expected = {"var": 0, "zero": 0, "succ": 1, "call": 2, "ite": 4}
        assert tree.tag in expected and len(tree.args) == expected[tree.tag]
        if tree.tag == "call":
            assert tree.descriptor is not None
            allowed = {"v", "w"} if tree.name == "R" else {"v"}
            assert free_variables(tree.descriptor) <= allowed
            validate_finite(tree.descriptor, trail)
        else:
            assert tree.descriptor is None
    else:
        expected = {"eq": 2, "bottom": 0, "and": 2, "or": 2,
                    "implies": 2, "forall": 1}
        assert tree.tag in expected and len(tree.args) == expected[tree.tag]
    for child in tree.args:
        validate_finite(child, trail)


def computation(u: Term) -> Formula:
    h = subst(u, {"n": V("v"), "a": V("w")})
    base = Eq(Call("R", h, ZERO, A), A)
    previous = Call("R", h, N, A)
    step = Eq(Call("R", h, S(N), A), subst(u, {"n": previous, "a": N}))
    return And(SIGMA, And(base, step))


def envelope(c: Formula, premise: Formula, conclusion: Formula, depth_two: bool) -> Formula:
    if depth_two:
        return All("a", And(All("n", c), Imp(premise, All("n", conclusion))))
    # Inner n deliberately shadows outer n only inside the premise.
    return All("a", All("n", And(c, Imp(premise, conclusion))))


def counter_cr(u: Term, depth_two: bool = False) -> Formula:
    def e(t: Term) -> Formula:
        return Eq(subst(u, {"n": t}), subst(u, {"n": t, "a": S(A)}))
    p = Or(Eq(N, ZERO), e(N))
    premise = All("n", Imp(p, e(S(N))))
    return envelope(computation(u), premise, p, depth_two)


def constancy(u: Term, depth_two: bool = False) -> Formula:
    premise = All("n", Eq(subst(u, {"n": S(N)}), u))
    conclusion = Eq(u, subst(u, {"n": ZERO}))
    return envelope(computation(u), premise, conclusion, depth_two)


def zero_induction(u: Term, depth_two: bool = False) -> Formula:
    base = Eq(subst(u, {"n": ZERO}), ZERO)
    at_n = Eq(u, ZERO)
    step = All("n", Imp(at_n, Eq(subst(u, {"n": S(N)}), ZERO)))
    return envelope(computation(u), And(base, step), at_n, depth_two)


def shared_g(u: Term) -> Formula:
    h = subst(u, {"n": V("v"), "a": ZERO})
    e = Eq(u, subst(u, {"a": S(A)}))
    successor_e = Eq(subst(u, {"n": S(N)}),
                     subst(u, {"n": S(N), "a": S(A)}))
    premise = All("n", Imp(Or(Eq(N, ZERO), e), successor_e))
    q = Call("D", ONE, N, ZERO)
    reset = Eq(Call("D", h, q, A), A)
    previous = Call("D", h, N, A)
    step = Eq(Call("D", h, S(N), A), subst(u, {"n": previous, "a": ZERO}))
    conclusion = And(SIGMA, And(reset, Or(Eq(N, ZERO), And(e, step))))
    return All("a", Imp(premise, All("n", conclusion)))


BUILDERS = {
    "CONST": lambda u: constancy(u),
    "CONST_depth2": lambda u: constancy(u, True),
    "CR": lambda u: counter_cr(u),
    "CR_depth2": lambda u: counter_cr(u, True),
    "G": shared_g,
    "ZERO": lambda u: zero_induction(u),
    "ZERO_depth2": lambda u: zero_induction(u, True),
}


def predicted(name: str, m: int, i: int, j: int, expanded: bool = False) -> int:
    # These are the independently supplied published closed-form claims.
    bases = {
        "CONST": 25 + 5*m + 3*i,
        "CONST_depth2": 26 + 5*m + 3*i,
        "CR": 35 + 7*m + 4*i + 3*j,
        "CR_depth2": 36 + 7*m + 4*i + 3*j,
        "G": 37 + 7*m + 4*i + 3*j,
        "ZERO": 33 + 5*m + 3*i,
        "ZERO_depth2": 34 + 5*m + 3*i,
    }
    result = bases[name]
    if expanded:
        # The freshly named body occurs in two direct calls plus i calls
        # introduced by substitution into the recurrence's right side.
        result += (2 + i) * m
        if name == "G":
            result += 2  # The additional stored descriptor of q = D_(S0).
    return result


def render(t: Term) -> str:
    if t.tag == "var":
        return t.name
    if t.tag == "zero":
        return "0"
    if t.tag == "succ":
        return "S(" + render(t.args[0]) + ")"
    if t.tag == "ite":
        s, q, yes, no = map(render, t.args)
        return f"if {s}={q} then {yes} else {no}"
    assert t.descriptor is not None
    return f"{t.name}_{{{render(t.descriptor)}}}({render(t.args[0])},{render(t.args[1])})"


def audit_input(u: Term) -> dict:
    assert free_variables(u) <= {"n", "a"}
    validate_finite(u)
    m, full_m = count(u), count(u, True)
    i, j = occurrences(u, "n"), occurrences(u, "a")
    results: dict[str, dict] = {}
    for name, builder in BUILDERS.items():
        formula = builder(u)
        validate_finite(formula)
        assert free_variables(formula) == set(), (name, render(u))
        assert active_names(formula) <= {"n", "a"}
        actual, expanded = count(formula), count(formula, True)
        assert actual == predicted(name, m, i, j), (name, actual, predicted(name, m, i, j))
        assert expanded == predicted(name, full_m, i, j, True), (name, expanded)
        profile = quantifier_profile(formula)
        expected_profile = (4, 2) if name.endswith("depth2") else ((3, 2) if name == "G" else (3, 3))
        assert profile == expected_profile, (name, profile, expected_profile)
        results[name] = {"active_nodes": actual, "expanded_nodes": expanded,
                         "quantifiers": profile[0], "quantifier_depth": profile[1]}
    assert results["CR"]["active_nodes"] - results["CONST"]["active_nodes"] == 10 + 2*m + i + 3*j
    assert results["CR"]["expanded_nodes"] - results["CONST"]["expanded_nodes"] == 10 + 2*full_m + i + 3*j
    assert results["ZERO"]["active_nodes"] - results["CONST"]["active_nodes"] == 8
    return {"term": render(u), "m": m, "expanded_m": full_m, "i": i, "j": j,
            "schemas": results}


def random_term(rng: random.Random, depth: int) -> Term:
    if depth == 0:
        return rng.choice((ZERO, N, A))
    kind = rng.randrange(6)
    if kind == 0:
        return rng.choice((ZERO, N, A))
    if kind == 1:
        return S(random_term(rng, depth - 1))
    if kind == 2:
        return Ite(*(random_term(rng, depth - 1) for _ in range(4)))
    if kind in (3, 4):
        bodies = (V("v"), V("w"), ZERO, S(V("v")),
                  Ite(V("v"), V("w"), V("v"), ZERO),
                  Call("R", S(V("v")), V("w"), V("v")))
        return Call("R", rng.choice(bodies), random_term(rng, depth - 1), random_term(rng, depth - 1))
    bodies = (V("v"), ZERO, ONE, S(V("v")),
              Ite(V("v"), ZERO, ONE, V("v")))
    return Call("D", rng.choice(bodies), random_term(rng, depth - 1), random_term(rng, depth - 1))


def test_frozen_simultaneous_substitution() -> None:
    inner = Ite(V("v"), V("w"), S(V("v")), V("w"))
    t = Call("R", inner, V("v"), V("w"))
    changed = subst(t, {"v": ONE, "w": ZERO})
    assert changed.descriptor is inner
    assert changed.args == (ONE, ZERO)
    assert subst(N, {"n": A, "a": ZERO}) == A  # Simultaneous, not sequential.
    conditional = Ite(N, A, S(N), A)
    translated = subst(conditional, {"n": S(A), "a": ZERO})
    assert translated == Ite(S(A), ZERO, S(S(A)), ZERO)
    assert count(conditional) == 7  # 2 logical nodes + 1+1+2+1 term nodes.
    assert occurrences(conditional, "n") == 2
    assert occurrences(conditional, "a") == 2


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parent.parent / "verification" / "schema_results.json")
    parser.add_argument("--random-cases", type=int, default=400)
    parser.add_argument("--seed", type=int, default=20261102)
    args = parser.parse_args()
    assert args.random_cases >= 0
    test_frozen_simultaneous_substitution()
    samples = [ZERO, N, A, S(N), S(A), Call("R", V("v"), N, A),
               Call("D", V("v"), N, N),
               Ite(N, A, ZERO, ONE),
               Ite(Call("R", Ite(V("v"), V("w"), V("v"), ZERO), N, A),
                   S(A), S(N), ZERO)]
    sample_results = [audit_input(u) for u in samples]
    rng = random.Random(args.seed)
    random_inputs = [random_term(rng, rng.randrange(1, 5)) for _ in range(args.random_cases)]
    random_results = [audit_input(u) for u in random_inputs]
    digest = hashlib.sha256("\n".join(render(t) for t in random_inputs).encode()).hexdigest()
    output = {
        "status": "PASS",
        "scope": "Finite syntax, substitution, and exact node-count audit; not a proof checker or semantic validation.",
        "seed": args.seed,
        "random_cases": len(random_results),
        "explicit_cases": len(sample_results),
        "schemas_per_case": len(BUILDERS),
        "formula_trees_checked": (len(sample_results) + len(random_results)) * len(BUILDERS),
        "random_input_sha256": digest,
        "maximum_random_active_input_nodes": max((r["m"] for r in random_results), default=0),
        "atomic_conditional_cost": "1 conditional node + 1 equality node + four argument trees",
        "active_counts": {"CONST": "25+5m+3i", "CONST_depth2": "26+5m+3i",
                          "CR": "35+7m+4i+3j", "CR_depth2": "36+7m+4i+3j",
                          "G": "37+7m+4i+3j", "ZERO": "33+5m+3i",
                          "ZERO_depth2": "34+5m+3i"},
        "expanded_count_rule": "Use recursively expanded input size M instead of m; add (2+i)M; add a further 2 for G's fixed q descriptor.",
        "constancy_saving_vs_cr_active": "10+2m+i+3j",
        "constancy_saving_vs_cr_expanded": "10+2M+i+3j",
        "tests": ["finite acyclic syntax", "descriptor free-variable budgets",
                  "simultaneous active substitution", "frozen descriptor identity",
                  "atomic conditional nodes and occurrences", "closed emitted formulas",
                  "only two active variable names", "quantifier occurrence counts",
                  "quantifier depth", "active node formulas", "fully expanded descriptor node formulas"],
        "samples": sample_results,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({k: output[k] for k in ("status", "explicit_cases", "random_cases", "formula_trees_checked",
                                           "maximum_random_active_input_nodes", "random_input_sha256")}, indent=2))
    print("Results:", args.output)


if __name__ == "__main__":
    main()
