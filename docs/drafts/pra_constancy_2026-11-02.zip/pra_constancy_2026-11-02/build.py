#!/usr/bin/env python3
"""Build the self-contained report with a local TeX installation."""
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
if shutil.which("latexmk"):
    subprocess.run(["latexmk", "-pdf", "-interaction=nonstopmode", "-halt-on-error",
                    "report.tex"], cwd=root, check=True)
elif shutil.which("pdflatex"):
    for _ in range(3):
        subprocess.run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                        "report.tex"], cwd=root, check=True)
else:
    raise SystemExit("Install latexmk or pdflatex, then rerun this script.")
print(root / "report.pdf")
