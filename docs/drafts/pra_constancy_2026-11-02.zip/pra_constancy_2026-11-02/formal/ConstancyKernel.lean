import Std

/-
  Local proof kernel for the constancy presentation of PRA.

  This checks one fixed predicate P and its corresponding latch recursion R.
  The constancy assumption is ONLY the displayed test family below. It is
  not an assumption of induction, or of constancy for arbitrary predicates.
  The carrier is arbitrary and need not be the standard natural numbers.
  This file does not formalize the generated syntax, pairing, all arithmetic
  translations, or the complete bi-interpretability theorem.
-/

namespace PRAConstancy

universe u

variable {A : Type u}

/-- Preserve the marked state while its encoded parameter passes the test. -/
def latch (zero : A) (pred : A → A) (P : A → A → Prop)
    [∀ n a, Decidable (P n a)] (v n : A) : A :=
  if P n (pred v) then v else zero

/-- Test the state AFTER the current step. Zero denotes success. -/
def probe [DecidableEq A] (zero one : A) (succ : A → A)
    (R : A → A → A) (n a : A) : A :=
  if R (succ n) (succ a) = succ a then zero else one

theorem latch_eq_mark
    {zero : A} {succ pred : A → A} {P : A → A → Prop}
    [∀ n a, Decidable (P n a)]
    (succ_ne_zero : ∀ a, succ a ≠ zero)
    (pred_succ : ∀ a, pred (succ a) = a)
    (a v n : A) :
    latch zero pred P v n = succ a ↔ v = succ a ∧ P n a := by
  unfold latch
  by_cases hp : P n (pred v)
  · simp only [if_pos hp]
    constructor
    · intro hv
      refine ⟨hv, ?_⟩
      have hpred : pred v = a := by rw [hv, pred_succ]
      simpa only [hpred] using hp
    · intro h
      exact h.1
  · simp only [if_neg hp]
    constructor
    · intro hz
      exact False.elim (succ_ne_zero a hz.symm)
    · intro h
      have hpred : pred v = a := by rw [h.1, pred_succ]
      have hp' : P n (pred v) := by simpa only [hpred] using h.2
      exact False.elim (hp hp')

theorem recursion_eq_mark
    {zero : A} {succ pred : A → A} {P : A → A → Prop}
    [∀ n a, Decidable (P n a)] {R : A → A → A}
    (succ_ne_zero : ∀ a, succ a ≠ zero)
    (pred_succ : ∀ a, pred (succ a) = a)
    (step : ∀ n a, R (succ n) a = latch zero pred P (R n a) n)
    (n a : A) :
    R (succ n) (succ a) = succ a ↔
      R n (succ a) = succ a ∧ P n a := by
  rw [step n (succ a)]
  exact latch_eq_mark succ_ne_zero pred_succ a (R n (succ a)) n

theorem marked_successors_iff
    {zero : A} {succ pred : A → A} {P : A → A → Prop}
    [∀ n a, Decidable (P n a)] {R : A → A → A}
    (succ_ne_zero : ∀ a, succ a ≠ zero)
    (pred_succ : ∀ a, pred (succ a) = a)
    (step : ∀ n a, R (succ n) a = latch zero pred P (R n a) n)
    (a : A) (progress : ∀ n, P n a → P (succ n) a) (n : A) :
    R (succ (succ n)) (succ a) = succ a ↔
      R (succ n) (succ a) = succ a := by
  constructor
  · intro h
    exact ((recursion_eq_mark succ_ne_zero pred_succ step (succ n) a).mp h).1
  · intro h
    have hp : P n a :=
      ((recursion_eq_mark succ_ne_zero pred_succ step n a).mp h).2
    exact (recursion_eq_mark succ_ne_zero pred_succ step (succ n) a).mpr
      ⟨h, progress n hp⟩

theorem probe_stationary [DecidableEq A]
    {zero one : A} {succ pred : A → A} {P : A → A → Prop}
    [∀ n a, Decidable (P n a)] {R : A → A → A}
    (succ_ne_zero : ∀ a, succ a ≠ zero)
    (pred_succ : ∀ a, pred (succ a) = a)
    (step : ∀ n a, R (succ n) a = latch zero pred P (R n a) n)
    (a : A) (progress : ∀ n, P n a → P (succ n) a) (n : A) :
    probe zero one succ R (succ n) a = probe zero one succ R n a := by
  have hm := marked_successors_iff succ_ne_zero pred_succ step a progress n
  by_cases h : R (succ n) (succ a) = succ a
  · have hs : R (succ (succ n)) (succ a) = succ a := hm.mpr h
    simp only [probe, if_pos h, if_pos hs]
  · have hs : R (succ (succ n)) (succ a) ≠ succ a := fun h' => h (hm.mp h')
    simp only [probe, if_neg h, if_neg hs]

/--
  One application of constancy, for the explicitly displayed probe family,
  yields induction for the fixed predicate P under local base/step hypotheses.
-/
theorem induction_from_probe_constancy [DecidableEq A]
    {zero one : A} {succ pred : A → A} {P : A → A → Prop}
    [∀ n a, Decidable (P n a)] {R : A → A → A}
    (separation : zero ≠ one)
    (succ_ne_zero : ∀ a, succ a ≠ zero)
    (pred_succ : ∀ a, pred (succ a) = a)
    (base : ∀ a, R zero a = a)
    (step : ∀ n a, R (succ n) a = latch zero pred P (R n a) n)
    (constancy : ∀ a,
      (∀ n, probe zero one succ R (succ n) a = probe zero one succ R n a) →
      ∀ n, probe zero one succ R n a = probe zero one succ R zero a)
    (a : A) (initial : P zero a)
    (progress : ∀ n, P n a → P (succ n) a) (n : A) : P n a := by
  have hfirst : R (succ zero) (succ a) = succ a :=
    (recursion_eq_mark succ_ne_zero pred_succ step zero a).mpr
      ⟨base (succ a), initial⟩
  have hprobe0 : probe zero one succ R zero a = zero := by
    simp only [probe, if_pos hfirst]
  have hstationary : ∀ k,
      probe zero one succ R (succ k) a = probe zero one succ R k a :=
    probe_stationary succ_ne_zero pred_succ step a progress
  have hprobe : probe zero one succ R n a = zero :=
    (constancy a hstationary n).trans hprobe0
  by_cases hmarked : R (succ n) (succ a) = succ a
  · exact ((recursion_eq_mark succ_ne_zero pred_succ step n a).mp hmarked).2
  · have honezero : one = zero := by
      simpa only [probe, if_neg hmarked] using hprobe
    exact False.elim (separation honezero.symm)

#print axioms latch_eq_mark
#print axioms recursion_eq_mark
#print axioms marked_successors_iff
#print axioms probe_stationary
#print axioms induction_from_probe_constancy

end PRAConstancy
