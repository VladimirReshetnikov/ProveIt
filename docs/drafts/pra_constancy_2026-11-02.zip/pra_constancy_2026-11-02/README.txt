CONSTANCY WITH EQUALITY CONDITIONALS
A shorter one-schema presentation of primitive recursive arithmetic
Prepared for Vladimir Reshetnikov, 2026-11-02.

Read report.pdf for the complete specification, proofs, comparison and limits.
The self-contained LaTeX source is report.tex.

The main result uses classical first-order logic extended with an atomic-
equality conditional term constructor. Its one axiom schema has
25 + 5|u| + 3 nu_n(u) active syntax-tree nodes, compared with
35 + 7|u| + 4 nu_n(u) + 3 nu_a(u) in the shortest current draft.
The conditional constructor is an explicit cost of the new presentation.
This is not a shortestness theorem in the old conditional-free language.

Repository comparison is pinned to ProveIt commit
5ffc596c844086fc26509685c7833b548ebf25c3.
source_manifest.json records all six archive names and verified hashes.

Build and checks:
  python3 build.py
  python3 checks/check_schema.py
  lean formal/ConstancyKernel.lean

The Lean file checks the central abstract latch argument. The full pairing,
compiler and bi-interpretation theorem are proved in the report; they are not
claimed to be fully formalized in Lean. The Python check audits syntax counts.

No third-party draft archives or toolchain binaries are redistributed here.
