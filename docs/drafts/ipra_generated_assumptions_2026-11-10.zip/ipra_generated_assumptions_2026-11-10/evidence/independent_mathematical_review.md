# Independent review of computation insertion and zero-witness insertion

Package note: the experimental paths below are historical.
`review_binding.json` maps those reviewed executable ASTs to the normalized
files under `code/`. The numerical falsification script is packaged as
`tests/check_zero_instances.py`. See `final_review.txt` for the final review
of the report after the closed-completeness and known-instance corrections.

Reviewer: the logic-reduction subagent. This is a written mathematical and
source review, not a Lean/Rocq formal verification or a proof inferred from
finite testing.

## Scope and verdict

Reviewed complete programs:

* `experiments/audit_hybrid/insert_source.py`, SHA-256
  `8b84cd3ab2a89eb991f05fc52e5ce2fa234d8533319df23e4f9ba10e344cbe83`.
* Its exception-opening variant `insert_source_exc.py`, SHA-256
  `ab3d8ceff3372957099a8efa9b2be1863105d3f120a421bae87f36beae3c4067`.
* `insert_source_witness.py`, SHA-256
  `87d031d070d415c027a8dd85c3f27b5cd7b0fecd235dad21d14abb3d35fbb038`.
* `insert_source_exc_witness.py`, with the same witness change and the same
  exception-based opener as the preceding strict variant.

The strict insertion program is sound and canonically complete relative to
the inherited scalar Choice-DI calculus. The witness program is also sound
and canonically complete. Its arithmetic branch requires a different
argument: the added equation need only have a provable zero instance, not
be a theorem for every value of the newly allocated parameter. The eager
predecessor-recursion opening must remain. Removing that eager check is
unsound.

## 1. The inherited decoder and opening invariant

At numerical sort, an empty array denotes zero, a singleton denotes
successor with one extra dummy zero slot, a binary array denotes zero with
checked but semantically ignored annotations, and a triple denotes the
initialized scalar iterator. The counter and seed have two dummy zero
slots; the update has two aliases of the same state. At formula sort, a
binary array is an equation, a singleton is Q, and a triple is D. Formula
scalars and padding carry no nontrivial numerical information.

The constructor depth increments 2,1,4 preserve this sorted interpretation.
Numerical root depth is 1 and formula root depth is 0. Numerical images are
rechecked at numerical root. The existing common-motive and capture-free
opening lemmas therefore continue to apply. A successful root opening with
no supplied image proves that no meaningful numerical coordinate refers
to a not-yet-allocated parameter.

For the extra JSON numeric aliases, every retained finite real coordinate
has the same meaning as its floor. This follows because all scope bounds
are integers. In particular [0,1) consists of zero aliases, and a negative
coordinate in [j,j+1) denotes parameter j. Boolean equality with integers
preserves that decoding. Nonfinite numbers cannot survive as a meaningful
retained numerical coordinate; when a supplied image replaces them, the
image has the normal checked meaning. Values in ignored annotations are
irrelevant. Strings, dictionaries, and null do not become numerical terms
through the guarded opener. Invalid iterable packets cannot bypass these
syntax checks.

Every reachable context entry in a successful trace is a list. DE supplies
a list slice; Eq/Q administrative continuation supplies []; computation
insertion supplies an equation list. DI must pass the matrix length test
before adding its assumption, so a scalar matrix cannot be added. Thus a
successful major is a nonempty array of arity 1,2,or3. A scalar requested
goal cannot close by hypothesis, and every available continuation either
rejects or retains a scalar goal while consuming a packet. It therefore
has no finite successful trace. This observation is used only to classify
successful majors, not to justify an unchecked false-goal sentinel.

## 2. Invalid endpoint packets are harmless continuations

The endpoint condition is

    m in ([s,u], not s and [t]) and i(t,u) == a.

When it succeeds, a binary major is exactly equality transport and a
unary major is exactly closure specialization from zero. The assignment
`a=i(t,s)` is the corresponding checked minor premise. If it fails for
either arity, the requested goal is unchanged and `h=m[2:]=[]`.

The shared continuation then adds only native truth and an unused fresh
parameter. From a derivation under this context, cut the truth assumption
against its theorem and replace the unused parameter by zero. This proves
the original sequent. The initial root check of a ensures that allocating
the new parameter does not change its decoded meaning. When the endpoint
condition succeeds, the new minor has itself been root-checked before the
new parameter is allocated, so the same statement holds for that minor.

A three-field major cannot satisfy either endpoint candidate, by list
length alone. Its slice is [B], and its continuation is precisely the old
DE rule. Consequently the permissive endpoint branch does not turn a D
proof into an equality or closure proof.

## 3. Strict computation insertion

The arithmetic branch reads a triple s=[n,a,u]. If n is false, it generates
the candidate equation I(n,a;u)=a. Successful root validation identifies n
with zero and checks the exposed seed, so its decoded equation is I0.

If n is true, the eager call

    p = i([*n,a,u], d=1)

has two separate roles. First, it forces n to have exactly one element.
The constructed list has length len(n)+2; length at least four rejects in
the constructor table, and a non-list iterable eventually fails scalar
syntax checking. A successful true n is therefore [v]. Second, it checks
the predecessor iterator, including its seed and update, at numerical root
before the fresh parameter is allocated, even if the update ignores its
state argument. The right side i(u,p,1) is then the standard substitution
of that predecessor iterator for both aliases of the state. The resulting
equation is IS, with the familiar dummy-zero padding removed by decoding.

The outer i on the whole generated equation completes root validation
before freshness allocation. Adding this theorem as a local assumption
and continuing with the unchanged goal is ordinary axiom cut. It is sound
even when the eventual goal is unrelated to the generated equation.

## 4. The zero-witness strengthening

The witness program omits only the outer i on the generated equation. It
retains the eager p check in the true-counter branch. Let w be the new
parameter allocated by the common tail, and let H(w) be the decoded
equation actually added by that tail. Some raw newly legal negative names
may also denote w, regardless of whether the tail image is w or zero.
The correct invariant is uniformly H(0), not that H has no occurrence of w.

### Zero-extension lemma

Take a finite raw numerical expression. Compare decoding it with finitely
many extra outer slots all assigned zero against opening those exposed
outer coordinates to a single fresh parameter and then assigning that
parameter zero. Every successfully decoded meaningful numerical value is
the same. The statement includes aliases of an out-of-scope negative
coordinate, since opening replaces these by the same image.

Proof is structural on the raw expression. A scalar belonging to an older
parameter is retained on both sides. A scalar belonging to an added outer
zero slot, a new parameter alias, or an exposed coordinate becomes zero on
both sides. Successor extends both environments by its dummy zero. A
binary numerical node is zero independently of its annotations. An
iterator extends both counter/seed environments by two zeros and both
update environments by the same two state aliases; the induction
hypothesis identifies its counter, seed and fixed update at every state.
Thus both occurrences denote the same finite scalar term/function. This
is a structural substitution argument, not induction over all PR program
codes and not an appeal to standard numerals alone.

### Base insertion

The equation before final opening is [s,a], with false counter n. The seed
in the left iterator sees two extra zero slots; the right seed has no such
slots and may expose coordinates to w. At w=0 the zero-extension lemma
identifies these seeds. The counter is zero, and the update can be arbitrary
because I0 does not use it. Therefore H(0) is an I0 instance, possibly after
discarding syntactically inert annotations. The seed and update need not
have been checked before allocating w. This is exactly the new freedom.

### Successor insertion

The eager check of p still proves that the counter is syntactically unary
and that the predecessor counter, seed and update have no meaningful
not-yet-allocated numerical parameter. In particular an exposed update
coordinate beyond its two state aliases cannot be accepted and later
mistaken for the previous state. The right-side opening is a checked
capture-free substitution. Hence H(0) is the same IS instance described in
the strict proof. In fact no new meaningful parameter is needed in this
case; proving only H(0) suffices.

### Discharging the local equation

The retained context and requested goal have already been root-checked,
so w is absent from their decoded meanings. Suppose the recursive
continuation proves Gamma,H(w) |- A. Apply the inherited admissibility of
capture-free numerical substitution, replacing w by zero and renaming
later local eigenparameters if necessary. This yields Gamma,H(0) |- A.
Cut against the I0/IS proof of H(0), obtaining Gamma |- A. Equivalently,
the rule is elimination of the proved existential statement exists w H(w)
with witness zero. No primitive existential rule or solver is added to the
checker. This argument also handles a fresh name explicitly supplied in
the raw arithmetic packet and recognized only after allocation.

## 5. Full soundness and canonical completeness

Induct on a finite successful checking trace. Hyp is immediate. The major
subcall must return successfully before its result is used. The major and
introduction branches use the inherited rules or the administrative
continuation established above. The arithmetic branch uses axiom cut in
the strict variant and zero-witness cut in the witness variant. All further
recursive calls consume at least one packet. The strictly decreasing
global name floor makes every subsequently allocated label new for all
previously validated meaningful data. Thus every successful closed result
is a theorem of the original scalar Choice-DI theory.

For the reverse direction, translate a finite canonical Choice-DI proof.
Replace each computation leaf by one insertion instruction for exactly
that computation equation followed by Hyp. Canonical seeds and updates
already have the required scopes, so the extra zero-witness freedom is not
needed. Translate other rules as before, choosing correct endpoint data.
At Eq/Q eliminations, insert the harmless truth continuation and allocate
its additional unused name. Serialize using the new actual allocation
order and contexts. The arithmetical insertion likewise consumes one fresh
name, and a compiler must account for it. Reusing old packets verbatim is
not the completeness proof. This yields a finite accepted certificate for
every canonical theorem, under unbounded resources.

The exception-opening variant has the same success values and failures
on JSON syntax. If a list traversal raises, its fallback comparison of an
integer with that list also raises; it cannot turn the traversal failure
into success. Every non-list JSON type fails a+[] and then executes exactly
the scalar branch of the guarded opener. Thus the preceding proof applies
to both implementations.

## 6. Necessary negative test and finite falsification attempts

Deleting the eager predecessor check is unsound. Take n=[0,0], seed 0 and
constant update [0] (one). Then n denotes annotated zero. A lazy update
substitution ignores its malformed four-field predecessor iterator and
would insert the false closed equation I(0,0;v.1)=1. Both reviewed strict
programs reject this packet. The eager check must therefore be treated as
a semantic part of the rule, not optional redundant validation.

The strict programs also reject ternary non-unary counters, nonzero float
counters, future-label seeds, exposed seed coordinates, an unrelated false
goal, and the canonical false goal with no instructions. They accept the
base and successor computation examples. Results are recorded in
`experiments/insertion_review_cases.json`.

An independent numerical decoder in
`experiments/review_witness_semantics.py` tried 36,000 generated raw
arithmetic packets at three name floors, including finite fractional
coordinates, Boolean aliases, nonfinite numbers, exposed coordinates and
future negative names. Of these, 23,247 reached a successful witness
opening; every decoded zero instance was an equality. No evaluation was
skipped for resource limits. This is supporting falsification evidence;
the universal justification is the structural zero-extension lemma above.

The implementation has ordinary finite Python resource limits. Logical
completeness is the unbounded-resource statement, as in the source corpus.
Nothing in this review proves absolute kernel minimality or literature-
wide novelty. The mathematical point established here is preservation of
the exact native theorem theory by the new continuation/insertion rules.
