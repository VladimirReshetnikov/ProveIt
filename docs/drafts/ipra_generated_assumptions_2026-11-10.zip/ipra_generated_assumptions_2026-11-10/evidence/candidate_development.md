# Forward computation insertion with a common continuation

**Historical development record.** Statements below about a review still
being pending describe the investigation at that earlier point. The review
has since been completed; see `independent_mathematical_review.md`,
`final_review.txt`, and `review_binding.json` for the final verdict and the
binding to the normalized programs delivered in this package.

## Frozen complete implementations and measurements

The principal candidate is `/workspace/scratch/774eb78d4cde/experiments/audit_hybrid/insert_source.py`.
The exception-based opening variant is `insert_source_exc.py` in the same directory. Neither changes the missing-image sentinel or verdict handling from the inherited controls; there is no dynamic execution of certificate text.

| Complete program | Normalized tokens | AST nodes | Normalized bytes | Raw source SHA-256 |
|---|---:|---:|---:|---|
| Principal candidate | **284** | **321** | **688** | `8b84cd3ab2a89eb991f05fc52e5ce2fa234d8533319df23e4f9ba10e344cbe83` |
| Exception-opening variant | **286** | **318** | **713** | `ab3d8ceff3372957099a8efa9b2be1863105d3f120a421bae87f36beae3c4067` |
| Existing endpoint token control | 287 | 328 | 749 | `1de97b4eaf1a7e64408762478524a1b55b3c85921d72f8f90c5a9b841462d372` |
| Existing endpoint AST control | 293 | 323 | 893 | `6aa9fda3030385de9bdad1609f66df9bd60578415acdae0218b7395ade868b05` |
| Existing successor-recursion byte control | 305 | 351 | 738 | `f1e11d165890303162ddfcb8da4ce8430ad935303c78d3063212939c517a5fb4` |

Thus each new source is individually strictly below the current coordinate envelope **287/323/738**. The principal source saves 3 normalized tokens, 2 AST nodes, and 50 bytes against those independent minima (approximately 1.05%, 0.62%, and 6.78%). This is an empirical source comparison, not an absolute-minimality theorem.

The three original controls were copied byte-for-byte to `experiments/audit_hybrid/reference/{tokens,ast,bytes}.py`; the unchanged inherited normalizer is `reference/source_measure.py`. `experiments/audit_hybrid/frozen_metrics.json` records original paths, copied paths, complete metrics, and hashes. All originals belong to the ten archives at repository commit `7bded17cc0122767f86e494fcf256b47fe85c9b8`.

## Mathematical change

The candidate retains initialized **scalar** iteration, with the two inherited equations

    I(0,a;v.h) = a
    I(Sn,a;v.h) = h[I(n,a;v.h)/v].

It also retains the inherited Choice-DI language, logical interpretation, case/progress rules, and numerical domain. It does **not** use the distinct-counter/state R recursor. Its new proof-checking organization is this:

1. Computation is a **forward context insertion**, not a leaf that compares a claimed goal with a computed right side.
2. After checking a computation description, generate its defining equation H and continue proving the original requested goal under the additional hypothesis H.
3. Every non-hypothesis instruction now uses the same continuation: introduce one fresh numerical parameter, add one checked formula to the context, and continue at one requested formula.
4. In Eq/Q elimination, when the redundant endpoint fields fail to describe an actual elimination of the requested goal, retain that original goal and add only the truth alias `[]`. This is an admissible administrative step, not a failed comparison disguised as a theorem.

The arithmetic insertion rule is

    Γ,H ⊢ A
    --------    H is a checked I0 or IS equation, with currently available parameters
      Γ ⊢ A.

Soundness follows by cutting the computation axiom Γ ⊢ H against the premise. Conversely, a computation leaf Γ ⊢ H is simulated by one insertion of H followed by Hyp. Since the remaining rules are unchanged or have harmless administrative continuations, this yields an effective theorem-preserving translation in both directions. Both interpretations with iPRA are the inherited ones; formulas and numerical operations are not being replaced by a weaker equiconsistent surrogate.

This forward insertion idea is a change in certificate calculus/verification architecture. The scalar iterator, native logical basis, endpoint certificates, and common-continuation idea are inherited. It should not be sold as a wholly new arithmetic axiomatization or a literature-wide priority claim.

## Exact new computation packet

Packets remain four-field arrays `[m,s,u,t]`, consumed in reverse order from a finite JSON array. The final array item is the closed requested goal. An unused prefix remains inert, as in the old interface.

When `m` and the original packet field `t` are false, `s` is an explicit three-field iterator description `[n,a,r]`. The other field `u` is unused in this branch. The entire computation branch is:

```python
n, t, u = s
h = i([s, i(u, i([*n, t, u], d=1), 1) if n else t])
```

Here the local names have become `n` = counter, `t` = initializer, and `u` = update body. The original `s` is retained as the equation's left side, avoiding a reconstructed copy.

For a zero counter, the generated equation is `[s,t]`. For a unary counter `[p]`, the generated right side is the update instantiated at the predecessor iterator `[p,t,u]`. Both `h` and the replacement iterator are checked before the global freshness floor is decreased.

The inner `i([*n,t,u],d=1)` is **essential**, even when the update does not inspect its state. It eagerly validates the predecessor iterator and, through its array arity, forces a nonzero counter to be unary. Omitting it accepts an invalid computation: `n=[0,0]` is an annotated numerical zero in the inherited decoder, yet the unchecked nonzero branch with constant update 1 would insert `I(0,0;1)=1`.

## Scope and insertion soundness

Use the inherited sorted decoder and opening lemma; all numerical parameters available in a running proof are rigid negative labels. The depth table and array arities are unchanged. The relevant invariants are:

1. A successful initial `i(a)` checks the requested formula before any new eigenparameter for that invocation is allocated.
2. In the computation branch, a successful destructuring plus the eager replacement check and final `i(h)` force the inserted formula to decode as an actual I0 or IS instance with available parameters.
3. The inserted `h` is root-scoped before `k -= 1`. Consequently the later `i(h, selected_image)` does not introduce the fresh label or change the decoded equation, regardless of which harmless image the common tail selects.
4. The goal is unchanged in this branch, and its opening with the fresh successor therefore preserves its decoded meaning. That newly allocated parameter is absent from the outer goal and retained assumptions. If a continuation uses it in intermediate reasoning, ordinary fresh renaming and substitution remove it when the insertion cut is discharged.

For point 2, consider all accepted counter forms. False numerical counters are the inherited aliases of zero. A truthy scalar is not iterable and fails the star expansion; inappropriate JSON strings or mappings fail the numeric opening. If a truthy counter is a list, the eager predecessor iterator has arity `len(n)+2`. The unchanged opening table rejects arity above three; therefore successful nonzero insertion has `len(n)=1`. The step equation then follows by the inherited capture-free numerical opening lemma. Final `i(h)` checks the full left side, right side, and passive parameters as a formula.

The sorted raw encoding contains checked dummy slots and aliases. Some noncanonical encodings of a valid computation can be rejected because extracting a seed or predecessor changes which dummy slots are available. This is harmless for soundness and canonical completeness: the producer can write zero in unused dummy positions and put every passive numerical parameter in a rigid label. The statement should be **soundness for accepted packets and completeness via canonical packets**, not acceptance equivalence for every arbitrary old JSON packet.

## Eq/Q no-op fusion

After proving a nonempty major `m`, the candidate performs:

```python
if m in ([s,u], not s and [t]) and i(t,u) == a:
    a = i(t,s)
h = m[2:]
```

- A successful equality or closure endpoint match performs precisely the inherited transport or QE step. Its `h` is empty and so the common continuation also adds the theorem `0=0` and an unused fresh parameter.
- A failed endpoint match for a one- or two-field major leaves `a` unchanged. Again `h=[]`, so its continuation merely proves the same conclusion under an extra truth assumption and a fresh parameter. Cut and fresh substitution remove both.
- A three-field D major cannot equal either endpoint candidate, whose lengths are one or two. Thus its goal remains unchanged and `h=m[2:]` is the same unary closure added by ordinary D elimination.

No False/0 rejection-state invariant is needed. The extra administrative cases do not assert the invalid endpoint equation. They may accept more raw certificate packets than the old endpoint checker, but the decoded closed theorem set is unchanged.

## Soundness and canonical completeness proof outline

Induct on a finite successful checking trace. Hyp is immediate. Paired introduction and paired elimination have their inherited eigenparameter checks. Matched Eq/Q steps use inherited substitution and specialization soundness. Unmatched Eq/Q steps are the truth-context lemma above. Computation insertion supplies a genuine checked axiom H and eliminates it by ordinary assumption cut. Every continuation uses fresh parameters absent from its outer conclusion, and all scoped openings use the inherited numerical substitution lemma.

For completeness, begin with a canonical native derivation. Serialize its major subtrees and continuations in depth-first order. Replace each computation leaf by an insertion of that same equation followed by Hyp. Reallocate negative labels at **every** common continuation, including arithmetic insertions and administrative Eq/Q continuations. Track the resulting contexts so Hyp leaves consume no packet. This constructs an accepted finite certificate for every old canonical theorem. A copied old packet need not remain accepted: allocation counts and automatic hypothesis pruning have changed.

The two directions preserve the numerical equality language and every native end sequent. Therefore the inherited full-domain interpretation composites remain provable. Runtime limits may reject a sufficiently large canonical certificate, as for the original recursive Python controls; no formal verification of Python or proof-assistant certification is claimed by this argument.

## Subsequent witness-completion variant (independent review pending)

The parent suggested removing only the outer normalization in the computation branch:

```python
n, t, u = s
h = [s, i(u, i([*n,t,u],d=1),1) if n else t]
```

The eager predecessor-iterator normalization remains mandatory. The files are separate; the two frozen candidates above have not been changed.

| Variant | Tokens | AST | Bytes | SHA-256 |
|---|---:|---:|---:|---|
| `insert_source_witness.py` | 281 | 318 | 685 | `87d031d070d415c027a8dd85c3f27b5cd7b0fecd235dad21d14abb3d35fbb038` |
| `insert_source_exc_witness.py` | 283 | 315 | 710 | `21f783aa4146f0c140391293648152740c99e0114069676085084fc6e0cbd64e` |

The proposed soundness reason is stronger than the earlier axiom-cut invariant. In the zero branch, the new assumption need not hold for every value of the freshly allocated parameter w. For example, raw source `[0,1,0]` can produce an assumption decoding as `I(0,0;0)=w`. But it holds at w=0. The correct rule is witnessed context introduction:

    Γ,H(w) ⊢ A       Γ ⊢ H(0)
    -------------------------    w fresh for Γ,A
              Γ ⊢ A.

It is justified by substituting 0 for w in the continuation, then cutting the proof of H(0). This explanation does not require postulating an extra existential rule; it can alternatively be presented using ordinary derived existential elimination.

The required zero-completion lemma is: for a raw numerical seed p and fixed previously allocated negative parameters, interpret every exposed positive slot and newly admitted/unallocated negative label as 0. Then placing p beneath the two dummy zero slots of an iterator initializer has the same numerical meaning as placing p at numerical root. Internal binders retain their own nearest slots in both occurrences; all extra outer slots carry 0. Structural induction on p proves the lemma. Ignored annotation fields at binary numerical nodes remain semantically irrelevant, though the checker still traverses them.

In the zero branch, the common opening either replaces all exposed slots by w or by 0. It also admits at most the newly allocated negative label w. Setting w=0 therefore makes the left initializer and copied right initializer agree, so H(0) is I0. Any escaped slots in the unused update are harmless because the counter is zero.

In the successor branch, the eager `i([*n,t,u],d=1)` already validates the initializer, update, and predecessor before w is allocated, and enforces a unary counter. In particular, an update coordinate outside its state aliases cannot be smuggled through substitution. The instantiated right side is root-scoped. The ordinary scalar opening lemma therefore identifies H with an IS instance; the zero-completion argument is available as a common statement for both branches.

The parameter freshness condition holds because the requested goal is checked before the computation packet is read, and the global freshness floor decreases only after h is prepared. All prior context formulas are scoped under the old floor. Thus the continuation cannot publish the new witness in the outer end sequent.

This variant has passed the same 11 targeted public-CLI cases as the frozen candidates (44 executions across four programs). These include rejection of the binary-counter/constant-update exploit, invalid root parameters, wrong claimed equalities, malformed source arity, and acceptance of state-dependent successor computations and administrative no-ops. Records: `experiments/audit_hybrid/check_local.py` and `local_checks.json`. The finite checks do not establish the general zero-completion lemma; the lemma needs independent theoretical review before the variant is described as proved.
