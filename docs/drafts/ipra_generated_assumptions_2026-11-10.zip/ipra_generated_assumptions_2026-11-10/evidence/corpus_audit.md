# Current-draft audit

Pinned repository commit: `7bded17cc0122767f86e494fcf256b47fe85c9b8`.
Root: `/workspace/scratch/774eb78d4cde/drafts`.

## Credible concrete comparison target

All ten direct ZIPs were extracted by the parent. I independently parsed all 154 Python source occurrences (109 distinct SHA-256 byte identities). I stripped module/function/class docstrings throughout the AST, used `ast.unparse(tree) + '\n'`, and counted significant Python tokens, AST nodes, and UTF-8 bytes. Full results are in `/workspace/scratch/774eb78d4cde/audit_source_metrics.json`.

The current complete-checker coordinate envelope is **287 tokens / 323 AST nodes / 738 normalized bytes**. Different complete programs attain these minima; this is an observed upper-bound envelope, not a mathematical lower bound.

| Current complete program (path relative to root) | Tokens | AST | Bytes |
|---|---:|---:|---:|
| `ipra_endpoint_certificates_2026-11-09/ipra_endpoint_certificates_2026-11-09/code/compact.py` | 287 | 328 | 749 |
| `ipra_named_specialization_2026-11-10/ipra_named_specialization/code/kernel_tokens.py` | 287 | 331 | 811 |
| `ipra_endpoint_certificates_2026-11-09/ipra_endpoint_certificates_2026-11-09/reference/matched_legacy_structure.py` | 293 | 323 | 893 |
| `ipra_successor_recursion_2026-11-09/ipra_successor_recursion_2026-11-09/code/kernel.py` | 305 | 351 | 738 |

Other useful current profiles: endpoint `code/explicit_failure.py` = 289/330/739; named `code/kernel_structure.py` = 289/326/840; named `code/kernel_bytes.py` = 292/341/753; elimination-assumptions byte profile = 300/351/745.

Every other distinct source at or below one of 287/323/738 is a build, reproduce, verify, or metric script, not a standalone theorem checker. The `reference/matched_legacy_structure.py` file is a complete standalone checker despite being labeled a control: it imports only standard JSON, has its own opening routine and proof dispatcher, and prints ACCEPT/REJECT with the current verdict convention. It must be counted. Endpoint report lines 99-123 explicitly include it and report their own resulting 287/323/739 envelope. The successor construction improves the latter byte coordinate by one.

The named-specialization README's 287/326/753 envelope is stale relative to the combined present ten-archive corpus. Likewise all-starts' 295/334/801 comparison is historical. Do not use these advertised historical envelopes as the current target.

## Mechanisms already present; do not recast them as novel

- Initialized scalar iteration `I(0,a;u.h)=a`, `I(Sn,a;u.h)=h[I(n,a;u.h)/u]`; equality plus unary closure Q and paired D binders; case/progress Choice-DI; ordinary logic derived via numerical formula selectors, gates, and padding. These are common inherited core.
- `ipra_three_schema_2026-11-09` and `(1)` are variants of the same zero-seeded 0/G/J basis: `Sx=G(0,x)`, `G(Sa,b)=a`, J0, JS. They recover arbitrary initialization via an equation invariant. Their matching implementation comparison is much larger than the compact core.
- K iteration specializes the reset operation to K application, yielding `(K a)b=a`, J(K)=K, and J(Kn)=h[J(n)]; also three equations, also larger than compact frontier.
- Successor recursion absorbs S into a counter-aware recursor's seed. Numerical grammar is only 0 and R, with `Sa:=R(0,a;u,v.0)`, `R(0,a;u,v.h)=Sa`, `R(Sn,a;u,v.h)=h[n/u,R(n,a;u,v.h)/v]`. It has direct `W(n)=R(n,0;u,v.u)`, `W(0)=1`, `W(Sn)=n`, and direct general PR compiler. This is already the smallest byte implementation and a mathematically useful arithmetic simplification. See its `theory/successor_recursion.tex` lines 6-40, 101-166, and 256-272.
- All-starts changes *atomic* Q semantics to progression and combines zero-start induction and one-step progression in arbitrary-start specialization. It normalizes all raw formulas into a safe gated sublanguage, repairing a prior round-trip hole. Its complete checker costs 323/374/974. See `theory/all_starts.tex` lines 453-544 for full raw-formula normalization. Safe-language-only equivalence is expressly insufficient.
- Named specialization restricts QE targets to an in-scope variable or 1; arbitrary targets are recovered by existential equality naming. It preserves every raw native sequent with 9 extra primitive nodes per replaced QE. It separately proves that dropping either variable targets or target 1 fails to preserve the same contextual consequence relation. Its implementing restricted checker is larger, 337/395/947.
- Named specialization's smaller profiles use a **uniform continuation** for all noncomputation instructions. Eq/Q steps get an extra truth assumption and unused fresh name. A wrong target becomes scalar False/0; no successful finite trace can escape because all contexts consist of lists. See `theory/kernel.tex` lines 80-202.
- Endpoint certificates expose redundant `[major,source,target,template]` fields, all checked. Eq and Q elimination then share endpoint substitution code. Compact failures are forced by an unbound local; explicit-failure variant avoids this and is smaller in bytes. See endpoint `report.tex` lines 465-566 and its code files.
- Elimination-assumptions removes direct hypothesis closure and recovers every Eq/D assumption through structural identity expansion (4+3d nodes). Thus deleting unrestricted Hyp has already been investigated.
- Scalar feedback uses an equality-test symbol e with no computation equations, calibrated by a self-comparison rule and three scalar successor-isolated supports. It is a separate arithmetic theory, not the 762-byte checker also bundled there.
- Countdown gives a conditional self-observation/equality-reflection bridge; do not treat finite countdown behavior alone as a completed unconditional whole-domain iPRA proof. The endpoint research appendix expressly says it does not close the countdown equality-reflection gap.

## Soundness and interpretation audit

I found **no concrete counterexample to the leading complete checkers** in the inspected code. This is an audit judgment, not machine-checked soundness. Current manuscripts make a deliberate distinction between canonical completeness, aliases, malformed input rejection, and actual mathematical soundness.

Particular soundness obligations relevant to new work:

1. A failed Boolean major must never be ignored. Some compact versions use normal completion versus exceptions; others return booleans and explicitly divide by the major's result. Combining their code paths carelessly can accept invalid majors.
2. Endpoint fallback after invalid Eq/Q endpoints is safe only because an attempted `m[2]` rejects for length 1/2; the computation fallback's h is genuinely unbound within that local invocation. Preserve this invariant or use explicit rejection.
3. Uniform-continuation wrong-match False/0 is an *operational rejection state*, not native falsity. It remains safe only while every context entry is a list. Adding scalar hypotheses breaks the given argument.
4. Successor recursion requires two independent update slots, old counter and old state. Reusing scalar iteration's two aliases of the same state invalidates W(Sn)=n and the direct compiler.
5. Whole-domain equality reflection must precede claiming quantifier-free induction from equation induction. Scalar ordinary-standard computations do not establish reflection in nonstandard models.
6. Bi-interpretability requires normalization/round trips for **every raw native formula**, not only equations or a restricted safe sublanguage. The all-starts paper explicitly repairs this issue.
7. Restricting QE to variables is not silently closed under arbitrary numerical substitution. The named-specialization proof avoids assuming the needed substitution admissibility, using explicit weakening/renaming and equality naming instead.
8. Standard Python runtime, JSON parser, object equality, and the AST normalizer are ambient assumptions common to the source comparison. This is a concrete source-size measure, not implementation-language-independent minimality.

The current inherited equality-reflection argument appears structurally coherent on inspection: it derives coverage/constructor laws, forms a literal-equation residual invariant, reflects `d(Sa,b)=1` to actual `a=b`, then builds quantifier-free characteristics. It does not invoke induction on quantified formulas. The direct R compiler is particularly useful because it avoids scalar predecessor/pairing bootstrap dependencies.

## Overall verdict

None of the present reports proves an absolute simplest axiomatization. Several explicitly state that they have not attained the requested significant breakthrough. Any new result should be compared against the combined current 287/323/738 envelope and distinguish a new mathematical presentation from a local rearrangement of existing checker code. A single complete program strictly below all coordinates would be a legitimate empirical improvement; claiming fundamental minimality or substantial mathematical novelty would require additional evidence.
