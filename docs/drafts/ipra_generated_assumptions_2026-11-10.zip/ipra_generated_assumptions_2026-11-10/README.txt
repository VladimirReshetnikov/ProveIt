NUMERICAL AXIOMS AS LOCAL ASSUMPTIONS
===================================
Research prepared for Vladimir Reshetnikov, 10 November 2026.

RESULT
------
One complete standalone checker is below all three independent current
draft minima:

                                     Tokens   AST nodes   Normalized bytes
  Current coordinate envelope           287         323                738
  code/checker.py                       281         318                685
  code/checker_ast.py                   283         315                710
  code/checker_strict.py                284         321                688

The old minima belong to different programs. All three new files are
complete programs, not separate components that must be combined. The
principal normalized source is also exactly 685 actual bytes in this package.
Measurements include JSON input, validation, checking, and verdict output.

The new mathematical mechanism generates a local equation H(w) with a
known zero witness. The requested goal and old context exclude the fresh w.
If the continuation proves Gamma,H(w) |- A and H(0) is a computation
theorem, substitution of zero and cut prove Gamma |- A. Computation can
therefore share the same continuation as every other non-hypothesis rule.
Invalid Eq/Q endpoint requests may also continue at the unchanged goal
under an extra truth assumption, after successfully checking their major.

The scalar arithmetic and native Choice-DI logical basis are inherited.
The report proves identity-language equivalence and preserves the existing
whole-domain bi-interpretation with full intuitionistic PRA. The complete
inherited bridge is included and attributed. Absolute minimality and a
substantially new arithmetic basis are not claimed.

OPEN FIRST
----------
ipra_generated_assumptions.pdf       Complete compiled research report.
ipra_generated_assumptions.tex       Standalone source, including code listing
                                     and the inherited proof appendices.
code/checker.py                     Principal complete 685-byte checker.
code/checker_ast.py                 Complete alternative with fewer AST nodes.
code/checker_strict.py              Stricter control that validates the whole
                                     generated equation before freshness.
code/FORMAT.txt                     Exact certificate protocol and decoding.
verify.py                          Measurements and complete-program tests.
tests/producer.py                  Untrusted named example producer.
tests/fixtures/                    Executable JSON proof and rejection cases.
evidence/                          Metrics, receipts, archive identities,
                                     reviews, and source hashes.
reference/                         Frozen competitors, unchanged measurer,
                                     inherited proofs, and license.
sources/                           The ten original draft ZIPs, unchanged.
audit_corpus.py                     Offline archive and source-metric audit.

REPRODUCE
---------
From the extracted package directory, with Python 3:

  python3 verify.py
  python3 code/checker.py < tests/fixtures/I0_arbitrary_seed.json

The checker prints ACCEPT with exit status 0, or REJECT with nonzero status.
Rejected inputs may also print a traceback on stderr. No submitted strings
are executed as code. The exact metric baseline uses CPython 3.12.14;
other versions can change AST/unparser measurements.

To rebuild the report with an installed PDFLaTeX distribution:

  python3 build.py

The standalone .tex also compiles directly with PDFLaTeX, without other
package files, network access, shell escape, or a bibliography processor.
The modular editing sources are report.tex and theory/.

For the independent finite zero-instance check:

  python3 tests/check_zero_instances.py

This numerical experiment is separate from proof checking and is not
imported by any trusted kernel. It supplements the structural proof.

To check the frozen ten-archive corpus and reproduce all source metrics:

  python3 audit_corpus.py

The script checks archive identities and exhaustive source measurements.
The mathematical classification of complete checkers versus auxiliary
scripts is documented separately in evidence/corpus_audit.md.

VERIFICATION AND LIMITS
-----------------------
All 182 complete-program certificate and malformed-input runs passed under
ordinary and optimized Python. Three targeted guard-removal mutants accept
their invalid proof examples, while the original checker rejects them.
There are 26 generic proof fixtures and two additional safe alias fixtures
for the zero-witness profiles. One induction example consumes 40 commands
and depends on both a retained base assumption and its induction hypothesis.

An independent decoder examined 36,000 raw arithmetic packets; 23,247
successfully opened equations had true zero instances, with no budget skips.
This finite test is not the universal soundness proof. The mathematical
claims have written proofs and independent assistant-agent reviews; no
Lean/Rocq formalization, external human peer review, or verified Python
runtime is claimed. Physical stack and memory limits can reject enormous
valid certificates. Canonical completeness is the unbounded-resource claim.

The source repository was read at commit:
  7bded17cc0122767f86e494fcf256b47fe85c9b8
All ten current ZIPs were checked. Their complete inventory is retained.
No repository change is part of this deliverable.

ATTRIBUTION
-----------
Endpoint certificates, the scalar numerical basis, Choice-DI, and the earlier
common continuation are inherited from the supplied ProveIt drafts. Exact
source-member identities are recorded in evidence/inherited_provenance.json.
The original MIT No Attribution license is reference/LICENSE.txt.
The new computation generator, zero-witness proof, neutral continuation,
independent serializer, targeted tests, and report are identified separately.

Run package.py to refresh MANIFEST.sha256 and rebuild the ZIP archive after
verification and PDF rebuilding. Local build caches are excluded.
