SUCCESSOR TRANSPORT AND SMALL AXIOMATIZATIONS OF iPRA
3 November 2026
=================================================

Start with report.pdf. All mathematical content and qualifications are
also available in report.tex and sections/*.tex. AXIOMS.txt is the compact
exact specification. No external repository checkout is needed to read
the elementary construction or its proofs.

RESULT
All four current drafts survive comparison with the three archived ones.
The main core matches the witnessed draft's one six-node separation axiom
plus initialized recursion and witnessed-boundary schemas. The new result
is a proved successor-transport merge, applicable while preserving each
complete source presentation and all of its previous optimizations.

The source-wise homomorphic image preserves genuine falsity and full
first-order intuitionistic formulas, has internally identity round trips,
and never enlarges a finite source axiom packet. It gives unbounded strict
savings on an explicit family missed by all four current rule lists.

For j=1 the old variable call costs4m+8 and the retained call costs8.
The old ordinary module costs16m+35; its exact image costs4m+35;
the separately certified canonical ordinary module costs35.
These latter two reductions are deliberately distinguished.

Two sharp local lower bounds are proved: addition body size5, and the
complete triangular iterator size8 in the raw staged0,S grammar with
fully charged descriptions. All8256 terms of sizes1 through7 are also
enumerated. The claim is not an encoding-independent global minimum
for an axiomatization of iPRA. The full source-envelope qualification,
constructor support costs, and positive-falsity caveat are in the report.

CONTENTS
report.pdf                  Compiled mathematical report
report.tex, sections/*.tex   Complete LaTeX source
AXIOMS.txt                  Exact concise specification
build.py                    Re-run checks and compile the PDF
artifacts/verify_transport.py
artifacts/verify_boundary.py
artifacts/verify_commuting.py
artifacts/*results.json     Executed validation records
artifacts/source_verification.json
provenance/source_manifest.json
provenance/comparison.csv
provenance/github_snapshot.json
SHA256SUMS.txt               Delivery file hashes

REBUILD
From this directory:
  python3 build.py

Requires Python3.10 or later and a standard pdfLaTeX installation. The three verifier
scripts use only Python's standard library and can be run individually.
The build script checks diagnostics and unresolved references after
three LaTeX passes. Source-archive hashes record the independently
verified retrieved snapshot; the original source ZIPs are not duplicated.

VERIFICATION STATUS
Written proofs establish the infinite mathematical results. The scripts
provide finite syntax checks, exhaustive small-term enumerations, bounded
recursion and boundary checks, and negative controls. There is no claim
of a complete Lean/Rocq formalization or universal proof-length reduction.

AUDITED SNAPSHOT
https://github.com/VladimirReshetnikov/ProveIt
f26a867c0f5c94ec91e2aa26030720ed5046bca8
