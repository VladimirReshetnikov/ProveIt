#!/usr/bin/env python3
"""Reproducible finite checks for the successor-transport presentation.

Python 3 standard library only. Run from any directory:

    python3 artifacts/verify_transport.py

The script checks finite symbolic proof templates, scope conventions,
fully charged syntax counts, a complete small-term lower-bound enumeration,
and bounded numerical examples. It is not a Lean/Rocq formalization of
the metatheorems, nor does finite numerical testing establish them.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from functools import lru_cache
from itertools import product
from pathlib import Path
import json


@dataclass(frozen=True)
class Recursor:
    name: str
    body: "Node"
    parameters: int = 0


@dataclass(frozen=True)
class Node:
    kind: str
    children: tuple["Node", ...] = ()
    label: str = ""
    recursor: Recursor | None = None


def variable(name: str) -> Node:
    return Node("variable", label=name)


ZERO = Node("zero")
V, W, N, A0, B0 = map(variable, ("v", "w", "n", "a", "b"))


def successor(term: Node) -> Node:
    return Node("successor", (term,))


def repeat(operation, times: int, term: Node) -> Node:
    for _ in range(times):
        term = operation(term)
    return term


def call(rec: Recursor, *arguments: Node) -> Node:
    assert len(arguments) == rec.parameters + 2
    return Node("recursor", tuple(arguments), recursor=rec)


@lru_cache(maxsize=None)
def size(term: Node) -> int:
    """Every frozen descriptor is charged again at every active occurrence."""
    return (
        1 + sum(size(child) for child in term.children)
        + (size(term.recursor.body) if term.recursor is not None else 0)
    )


def active_substitute(term: Node, replacements: dict[str, Node]) -> Node:
    if term.kind == "variable":
        return replacements.get(term.label, term)
    # A recursor's frozen descriptor is deliberately not traversed.
    return Node(
        term.kind,
        tuple(active_substitute(c, replacements) for c in term.children),
        term.label,
        term.recursor,
    )


def replace_active(term: Node, old: Node, new: Node) -> Node:
    if term == old:
        return new
    return Node(
        term.kind,
        tuple(replace_active(c, old, new) for c in term.children),
        term.label,
        term.recursor,
    )


def instantiated_update(rec: Recursor, state: Node, counter: Node,
                        parameters: tuple[Node, ...] = ()) -> Node:
    assert len(parameters) == rec.parameters
    replacements = {"v": state, "w": counter}
    replacements.update({f"c{i}": t for i, t in enumerate(parameters)})
    return active_substitute(rec.body, replacements)


def ordinary_module(rec: Recursor) -> Node:
    """Grouped module, one node per individual quantifier; binder names free."""
    parameters = tuple(variable(f"c{i}") for i in range(rec.parameters))
    base = Node("equality", (call(rec, ZERO, A0, *parameters), A0))
    residual = call(rec, N, A0, *parameters)
    update = instantiated_update(rec, residual, N, parameters)
    step = Node("equality", (call(rec, successor(N), A0, *parameters), update))
    module = Node("and", (base, Node("forall", (step,), "n")))
    for name in reversed(("a",) + tuple(f"c{i}" for i in range(rec.parameters))):
        module = Node("forall", (module,), name)
    return module


def exact_image(term: Node, old: Recursor, new: Recursor) -> Node:
    """Homomorphic active-symbol map, with all retained labels frozen."""
    return Node(
        term.kind,
        tuple(exact_image(c, old, new) for c in term.children),
        term.label,
        new if term.recursor == old else term.recursor,
    )


def active_occurrences(term: Node, rec: Recursor) -> int:
    return int(term.recursor == rec) + sum(
        active_occurrences(child, rec) for child in term.children
    )


def evaluate(term: Node, environment: dict[str, int]) -> int:
    if term.kind == "zero":
        return 0
    if term.kind == "variable":
        return environment[term.label]
    if term.kind == "successor":
        return 1 + evaluate(term.children[0], environment)
    assert term.kind == "recursor" and term.recursor is not None
    arguments = [evaluate(child, environment) for child in term.children]
    counter, state, *parameters = arguments
    for index in range(counter):
        local = {"v": state, "w": index}
        local.update({f"c{i}": p for i, p in enumerate(parameters)})
        state = evaluate(term.recursor.body, local)
    return state


Q = Recursor("Q", W)
ADDITION = Recursor("A", successor(V))


def predecessor(term: Node) -> Node:
    return call(Q, term, ZERO)


def normalize_certificate(term: Node, flags: frozenset[Recursor]) -> Node:
    """Small proof-template normalizer, used only on the displayed examples.

    It uses ordinary recursion computation and previously certified
    successor-equivariance. The 10,000-call cap is an explicit safeguard,
    not an assumption that arbitrary symbolic computation is terminating.
    No frozen descriptor is actively rewritten. A failed finite test does
    not imply the corresponding mathematical identity is false.
    """
    budget = [10000]

    def visit(t: Node) -> Node:
        budget[0] -= 1
        if budget[0] < 0:
            raise RuntimeError("finite certificate budget exhausted")
        t = Node(t.kind, tuple(visit(c) for c in t.children), t.label, t.recursor)
        if t.kind != "recursor":
            return t
        rec = t.recursor
        assert rec is not None
        counter, initializer, *parameters = t.children
        parameters = tuple(parameters)
        if counter == ZERO:
            return initializer
        if counter.kind == "successor":
            previous_counter = counter.children[0]
            residual = call(rec, previous_counter, initializer, *parameters)
            return visit(instantiated_update(rec, residual, previous_counter, parameters))
        if rec in flags and initializer.kind == "successor":
            return visit(successor(call(rec, counter, initializer.children[0], *parameters)))
        return t

    return visit(term)


def certify_equivariance(rec: Recursor, earlier_flags: frozenset[Recursor]) -> bool:
    assert rec not in earlier_flags  # No self-flag may establish its own premise.
    left = active_substitute(rec.body, {"v": successor(V)})
    right = successor(rec.body)
    return normalize_certificate(left, earlier_flags) == normalize_certificate(
        right, earlier_flags
    )


def check_induction_template(rec: Recursor, earlier_flags: frozenset[Recursor]) -> dict:
    """Check the base and the induction-step proof skeleton as AST identities."""
    assert certify_equivariance(rec, earlier_flags)
    parameters = tuple(variable(f"c{i}") for i in range(rec.parameters))
    lhs_base = call(rec, ZERO, successor(A0), *parameters)
    rhs_base = successor(call(rec, ZERO, A0, *parameters))
    assert normalize_certificate(lhs_base, earlier_flags) == normalize_certificate(
        rhs_base, earlier_flags
    )
    inner_left = call(rec, N, successor(A0), *parameters)
    inner_right = successor(call(rec, N, A0, *parameters))
    step_after_computation = instantiated_update(rec, inner_left, N, parameters)
    step_after_hypothesis = replace_active(step_after_computation, inner_left, inner_right)
    assert step_after_hypothesis == instantiated_update(rec, inner_right, N, parameters)
    expected = successor(instantiated_update(rec, call(rec, N, A0, *parameters), N, parameters))
    assert normalize_certificate(step_after_hypothesis, earlier_flags) == normalize_certificate(
        expected, earlier_flags
    )
    # The expected term is exactly the computation expansion of S R_h(Sn,a,c).
    final = successor(call(rec, successor(N), A0, *parameters))
    assert normalize_certificate(final, earlier_flags) == normalize_certificate(
        expected, earlier_flags
    )
    return {"recursor": rec.name, "base": "pass", "induction_step": "pass"}


def check_families() -> dict:
    rows = []
    for j in range(1, 9):
        g = Recursor(f"G{j}", repeat(successor, j, V))
        k = call(g, W, V)
        merged = Recursor(f"B{j}", k)
        for m in range(1, 9):
            h = repeat(predecessor, m, call(g, W, repeat(successor, m, V)))
            old = Recursor(f"H{m}_{j}", h)
            old_module = ordinary_module(old)
            image_module = exact_image(old_module, old, merged)
            fresh_module = ordinary_module(merged)
            assert size(k) == j + 4
            assert size(h) == 4 * m + j + 4
            assert active_occurrences(old_module, old) == 3
            assert size(old_module) == 16 * m + 4 * j + 31
            assert size(image_module) == 4 * m + 4 * j + 31
            assert size(fresh_module) == 4 * j + 31
            # Verify the pointwise saving also for compound actual arguments.
            actual_counter = successor(successor(N))
            actual_initializer = call(Q, call(ADDITION, N, successor(A0)), B0)
            old_call = call(old, actual_counter, actual_initializer)
            new_call = call(merged, actual_counter, actual_initializer)
            assert size(old_call) - size(new_call) == 4 * m
            rows.append({
                "j": j, "m": m, "old_body": size(h), "new_body": size(k),
                "old_variable_call": size(call(old, N, A0)),
                "new_variable_call": size(call(merged, N, A0)),
                "old_ordinary_module": size(old_module),
                "literal_image_module": size(image_module),
                "fresh_ordinary_module": size(fresh_module),
                "literal_image_saving": 12 * m,
                "fresh_module_saving": 16 * m,
            })
    return {"status": "pass", "cases": len(rows), "rows": rows}


def check_local_lower_bound() -> dict:
    """All raw terms of fully charged size <5, free variables among v,w.

    Completeness is justified structurally: the first recursor needs4
    nodes, so it must occupy the entire term, have a one-node descriptor,
    two leaf actuals, and no extra declared parameter. Otherwise the term
    is a unary successor chain. See the accompanying mathematical proof.
    """
    leaves = (ZERO, V, W)
    rows = []
    points = ({"v": 0, "w": 0}, {"v": 2, "w": 2})
    for atom_name, atom in zip(("0", "v", "w"), leaves):
        for k in range(4):
            term = repeat(successor, k, atom)
            rows.append({"term": f"S^{k}({atom_name})", "size": size(term),
                         "values": [evaluate(term, p) for p in points]})
    for body_name, body in zip(("0", "v", "w"), leaves):
        rec = Recursor(f"R_{body_name}", body)
        for counter_name, counter in zip(("0", "v", "w"), leaves):
            for init_name, init in zip(("0", "v", "w"), leaves):
                term = call(rec, counter, init)
                rows.append({"term": f"R_[{body_name}]({counter_name},{init_name})",
                             "size": size(term),
                             "values": [evaluate(term, p) for p in points]})
    assert len(rows) == 39
    assert all(row["size"] <= 4 and row["values"] != [0, 4] for row in rows)
    assert size(call(ADDITION, W, V)) == 5
    return {"status": "pass", "terms_checked": len(rows),
            "points": [[0, 0], [2, 2]], "addition_values": [0, 4],
            "minimum_addition_body_size": 5, "rows": rows}


@lru_cache(maxsize=None)
def positive_compositions(total: int, parts: int) -> tuple[tuple[int, ...], ...]:
    if parts == 1:
        return ((total,),) if total >= 1 else ()
    return tuple(
        (first,) + rest
        for first in range(1, total - parts + 2)
        for rest in positive_compositions(total - first, parts - 1)
    )


@lru_cache(maxsize=None)
def raw_terms(charged_size: int, active_slots: int) -> tuple[Node, ...]:
    """Every raw term at this size, modulo fixed canonical slot names.

    Recursor local slots are v,w,c0,... independently of surrounding
    active slots. Unused declared parameters are allowed and charged.
    Every recursive subproblem has smaller charged size, so the finite
    generation does not assume a decision procedure for PR equivalence.
    """
    slots = (V, W) + tuple(variable(f"c{i}") for i in range(active_slots - 2))
    if charged_size == 1:
        return (ZERO,) + slots
    terms = [successor(t) for t in raw_terms(charged_size - 1, active_slots)]
    for parameters in range(charged_size - 3):
        for descriptor_size in range(1, charged_size - parameters - 2):
            actual_size = charged_size - 1 - descriptor_size
            for parts in positive_compositions(actual_size, parameters + 2):
                argument_lists = tuple(raw_terms(p, active_slots) for p in parts)
                for body in raw_terms(descriptor_size, parameters + 2):
                    rec = Recursor(f"Raw{parameters}", body, parameters)
                    for arguments in product(*argument_lists):
                        terms.append(call(rec, *arguments))
    assert all(size(t) == charged_size for t in terms)
    return tuple(terms)


def check_full_call_lower_bound() -> dict:
    """Exhaust all 8256 raw terms of size <=7 at the distinguishing input."""
    expected_counts = [3, 3, 3, 30, 219, 1218, 6780]
    expected_maxima = [10, 11, 12, 13, 20, 30, 40]
    rows = []
    for charged_size in range(1, 8):
        terms = raw_terms(charged_size, 2)
        values = [evaluate(t, {"v": 10, "w": 0}) for t in terms]
        assert len(terms) == expected_counts[charged_size - 1]
        assert max(values) == expected_maxima[charged_size - 1]
        assert all(value <= 40 for value in values)
        rows.append({"size": charged_size, "terms": len(terms), "maximum": max(values)})
    triangular = Recursor("Triangular", call(ADDITION, W, V))
    target = call(triangular, V, W)
    assert size(target) == 8
    assert evaluate(target, {"v": 10, "w": 0}) == 45
    return {
        "status": "pass", "terms_checked": sum(expected_counts),
        "scope": "Raw native-0,S fully charged staged grammar; all finite parameter lists allowed.",
        "input_counter_initializer": [10, 0], "target_value": 45,
        "all_smaller_terms_at_most": 40, "minimum_triangular_call_size": 8,
        "counts_and_maxima_by_size": rows,
    }


def check_symbolic_and_numerical() -> dict:
    flags: frozenset[Recursor] = frozenset()
    symbolic = []
    symbolic.append(check_induction_template(ADDITION, flags))
    flags = flags | {ADDITION}
    g2 = Recursor("G2", repeat(successor, 2, V))
    g3 = Recursor("G3", repeat(successor, 3, V))
    symbolic.append(check_induction_template(g2, flags))
    symbolic.append(check_induction_template(g3, flags))
    # Counter-dependent update v+w: demonstrates that autonomy is unnecessary.
    counter_dependent = Recursor("K", call(ADDITION, W, V))
    symbolic.append(check_induction_template(counter_dependent, flags))
    # A true parameterized example: update v+c0, using earlier certified A.
    parameterized = Recursor("P", call(ADDITION, variable("c0"), V), 1)
    symbolic.append(check_induction_template(parameterized, flags))

    invalid = Recursor("DoubleState", call(ADDITION, V, V))
    assert not certify_equivariance(invalid, flags)
    invalid_left = evaluate(active_substitute(invalid.body, {"v": successor(V)}),
                            {"v": 0, "w": 0})
    invalid_right = evaluate(successor(invalid.body), {"v": 0, "w": 0})
    assert (invalid_left, invalid_right) == (2, 1)

    # Frozen descriptor variables must not be captured by active substitution.
    sample = call(g3, V, W)
    substituted = active_substitute(sample, {"v": ZERO, "w": successor(W)})
    assert substituted.recursor is g3
    assert substituted.recursor.body == repeat(successor, 3, V)
    assert substituted.children == (ZERO, successor(W))

    cases = 0
    for rec in (ADDITION, g2, g3, counter_dependent, parameterized):
        for n in range(9):
            for a in range(9):
                param_values = range(4) if rec.parameters else (None,)
                for parameter in param_values:
                    env = {"n": n, "a": a}
                    args = () if parameter is None else (variable("c0"),)
                    if parameter is not None:
                        env["c0"] = parameter
                    base = call(rec, N, A0, *args)
                    transported = call(rec, N, successor(A0), *args)
                    assert evaluate(transported, env) == evaluate(base, env) + 1
                    for b in range(5):
                        env["b"] = b
                        contracted = call(Q, transported, B0)
                        assert evaluate(contracted, env) == evaluate(base, env)
                        assert size(contracted) - size(base) == 3 + size(B0)
                        cases += 1

    family_cases = 0
    for j in range(1, 5):
        g = Recursor(f"NumericalG{j}", repeat(successor, j, V))
        k = call(g, W, V)
        for m in range(1, 5):
            h = repeat(predecessor, m, call(g, W, repeat(successor, m, V)))
            for v in range(6):
                for w in range(6):
                    env = {"v": v, "w": w}
                    assert evaluate(h, env) == evaluate(k, env) == v + j * w
                    family_cases += 1
    return {
        "status": "pass", "symbolic_templates": symbolic,
        "invalid_flag_rejected": {"update": "A(v,v)=2v", "at_v_0": [2, 1]},
        "frozen_descriptor_scope": "pass",
        "transport_and_cancellation_numerical_cases": cases,
        "family_update_numerical_cases": family_cases,
        "counter_dependent_update": "A(w,v)=v+w",
        "parameterized_update": "A(c0,v)=v+c0",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    results = {
        "status": "pass",
        "scope": "Finite diagnostics and checked symbolic templates; not a full formalization.",
        "family_counts": check_families(),
        "local_lower_bound": check_local_lower_bound(),
        "full_call_lower_bound": check_full_call_lower_bound(),
        "symbolic_and_numerical": check_symbolic_and_numerical(),
    }
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "verification_results.json").write_text(
        json.dumps(results, indent=2) + "\n", encoding="utf-8"
    )
    numerical = results["symbolic_and_numerical"]
    summary = (
        "SUCCESSOR-TRANSPORT VALIDATION: PASS\n"
        "====================================\n"
        "Python 3 standard library; no external dependencies.\n\n"
        "64 family pairs (1 <= j,m <= 8): full frozen-descriptor counts agree.\n"
        "Old ordinary module:        16m + 4j + 31.\n"
        "Literal homomorphic image:   4m + 4j + 31 (saves 12m).\n"
        "Fresh ordinary module:            4j + 31 (saves 16m).\n"
        "Every source module has exactly three active occurrences of its recursor.\n"
        "Arbitrary compound-argument calls save exactly 4m.\n\n"
        "Complete small-term enumeration: 39 terms of charged size <=4.\n"
        "None represents addition, distinguished at (0,0) and (2,2).\n"
        "A(w,v) has charged size5; this is the sharp local raw-language minimum.\n\n"
        "Complete larger enumeration: 8256 raw terms of charged size <=7.\n"
        "At (counter,initializer)=(10,0), every such term is at most40.\n"
        "R_[A(w,v)](n,a) has size8 and value45 at that input.\n"
        "Thus the full reduced triangular call also attains its local minimum.\n\n"
        "Five symbolic induction templates pass: A, S^2 iteration, S^3 iteration,\n"
        "counter-dependent update v+w, and parameterized update v+c0.\n"
        "The invalid update 2v is rejected (at v=0, the proposed sides are 2 and1).\n"
        "Active substitution preserves all frozen descriptor scopes.\n"
        f"Bounded transport/cancellation checks: {numerical['transport_and_cancellation_numerical_cases']}.\n"
        f"Bounded family-update checks: {numerical['family_update_numerical_cases']}.\n\n"
        "LIMITATION\n"
        "These checks do not prove the infinite theory's bi-interpretability,\n"
        "equiconsistency, or general induction metatheorem. The report supplies\n"
        "written proofs. No Lean/Rocq kernel certification is claimed.\n"
    )
    (args.output_dir / "verification_summary.txt").write_text(summary, encoding="utf-8")
    print(summary, end="")


if __name__ == "__main__":
    main()
