#!/usr/bin/env python3
"""Finite independent checks of witnessed boundaries and exact syntax costs.

These checks are diagnostics. They do not formalize induction, interpretation
theorems, or nonstandard models. Only Python's standard library is required.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path


@dataclass(frozen=True)
class Tree:
    tag: str
    children: tuple["Tree", ...] = ()
    frozen: "Tree | None" = None

    def size(self) -> int:
        return 1 + sum(c.size() for c in self.children) + (
            0 if self.frozen is None else self.frozen.size()
        )


def var(name: str) -> Tree:
    return Tree("variable:" + name)


def node(tag: str, *children: Tree) -> Tree:
    return Tree(tag, tuple(children))


ZERO = Tree("zero")
BOTTOM = Tree("bottom")


def successor(term: Tree) -> Tree:
    return node("successor", term)


def addition(n: Tree, a: Tree) -> Tree:
    # A = R_[S(v)]; the frozen update is paid at each occurrence.
    return Tree("recursor:A", (n, a), successor(var("local-v")))


def replace_active(tree: Tree, variable: str, replacement: Tree) -> Tree:
    if tree.tag == "variable:" + variable:
        return replacement
    # Frozen descriptors have their own local slots, so remain unchanged.
    return Tree(
        tree.tag,
        tuple(replace_active(c, variable, replacement) for c in tree.children),
        tree.frozen,
    )


def close_parameters(matrix: Tree, count: int) -> Tree:
    result = matrix
    for i in reversed(range(count)):
        result = node("forall:c" + str(i + 1), result)
    return node("forall:t", result)


def witnessed_boundary(equation: Tree, parameters: int) -> Tree:
    b, x, t = var("b"), var("x"), var("t")
    accessible = node(
        "or",
        node("equal", b, ZERO),
        node(
            "exists:x",
            node("and", node("equal", successor(x), b), equation),
        ),
    )
    endpoint = node(
        "implies", replace_active(equation, "x", b), node("equal", b, t)
    )
    return close_parameters(
        node("exists:b", node("and", accessible, endpoint)), parameters
    )


def scoped_boundary(equation: Tree, parameters: int) -> Tree:
    b, x, t = var("b"), var("x"), var("t")
    predecessor = node(
        "forall:x", node("implies", node("equal", successor(x), b), equation)
    )
    endpoint = node(
        "implies", replace_active(equation, "x", b), node("equal", b, t)
    )
    return close_parameters(
        node("exists:b", node("and", predecessor, endpoint)), parameters
    )


def j_boundary(equation: Tree, parameters: int) -> Tree:
    b, x, t = var("b"), var("x"), var("t")
    # x is a binding annotation, not an additional variable-tree occurrence.
    matrix = node(
        "J_x",
        node("equal", b, ZERO),
        node("equal", successor(x), b),
        equation,
        b,
        node("equal", b, t),
    )
    return close_parameters(node("exists:b", matrix), parameters)


def check_costs() -> dict:
    x, t, b, v = map(var, ("x", "t", "b", "v"))
    sep = node("implies", node("equal", ZERO, successor(ZERO)), BOTTOM)
    coverage = node(
        "forall:z",
        node(
            "exists:y",
            node(
                "or",
                node("equal", var("z"), ZERO),
                node("equal", var("z"), successor(var("y"))),
            ),
        ),
    )
    assert sep.size() == 6
    assert coverage.size() == 10

    A, B, P, C, D = map(var, ("A", "B", "P", "C", "D"))
    k4_left = node("K4", A, B, C, D)
    k4_right = node(
        "and", node("implies", A, B), node("implies", B, node("implies", C, D))
    )
    k3_left = node("K3", A, B, D)
    k3_right = node("and", node("implies", A, B), node("implies", B, D))
    bx, px, pv = node("template:B", x), node("template:P", x), node("template:P", v)
    j_left = node("J_x", A, bx, px, v, C)
    j_right = node(
        "and",
        node("or", A, node("exists:x", node("and", bx, px))),
        node("implies", pv, C),
    )
    costs = {
        "separation": sep.size(),
        "coverage": coverage.size(),
        "K4_definition": 1 + k4_left.size() + k4_right.size(),
        "K3_definition": 1 + k3_left.size() + k3_right.size(),
        "J_definition": 1 + j_left.size() + j_right.size(),
    }
    assert costs == {
        "separation": 6,
        "coverage": 10,
        "K4_definition": 15,
        "K3_definition": 12,
        "J_definition": 22,
    }

    checked = 0
    for parameters in range(9):
        left = x
        for i in range(parameters):
            left = addition(left, var("c" + str(i + 1)))
        for depth in range(13):
            equation = node("equal", left, t)
            F = equation.size()
            assert witnessed_boundary(equation, parameters).size() == 2 * F + parameters + 17
            assert scoped_boundary(equation, parameters).size() == 2 * F + parameters + 13
            assert j_boundary(equation, parameters).size() == F + parameters + 14
            # Replacing a one-node active probe leaves frozen labels untouched.
            assert replace_active(equation, "x", b).size() == F
            checked += 1
            left = successor(left)
    return {"fixed_costs": costs, "equation_instances": checked, "formula_checks": 3 * checked}


def scan(predicate: tuple[bool, ...], target: int) -> list[int]:
    values = [0]
    for n in range(target):
        state = values[-1]
        values.append(n + 1 if predicate[state] else state)
    return values


def is_witness(predicate: tuple[bool, ...], b: int, target: int) -> bool:
    # For standard natural successor, these are the exact WB conditions.
    accessible = b == 0 or predicate[b - 1]
    endpoint = not predicate[b] or b == target
    return accessible and endpoint


def check_scan(maximum_target: int) -> dict:
    tables = invariant_checks = probe_checks = candidate_checks = 0
    selected_witnesses: set[tuple[int, int]] = set()
    for target in range(maximum_target + 1):
        for mask in range(1 << (target + 1)):
            predicate = tuple(bool(mask & (1 << i)) for i in range(target + 1))
            values = scan(predicate, target)
            tables += 1
            for n, b in enumerate(values):
                assert 0 <= b <= n
                assert is_witness(predicate, b, n)
                invariant_checks += 1
                # Extra probes outside the truth table cannot be predecessors
                # of b<=n<=target; no predicate value outside the table is read.
                for x in range(target + 3):
                    if x + 1 == b:
                        assert predicate[x]
                    probe_checks += 1
            b = values[-1]
            oracle = next((i for i, truth in enumerate(predicate) if not truth), target)
            assert b == oracle
            all_witnesses = []
            for candidate in range(target + 1):
                candidate_checks += 1
                if is_witness(predicate, candidate, target):
                    all_witnesses.append(candidate)
            assert b in all_witnesses
            assert all_witnesses
            selected_witnesses.add((target, b))
    # Every potential first-failure position is exercised, including b=target.
    assert selected_witnesses == {
        (target, b)
        for target in range(maximum_target + 1)
        for b in range(target + 1)
    }
    return {
        "maximum_target": maximum_target,
        "all_truth_tables": tables,
        "scan_invariant_instances": invariant_checks,
        "explicit_predecessor_probe_instances": probe_checks,
        "candidate_witness_instances": candidate_checks,
        "independent_least_failure_oracle_checks": tables,
        "all_target_witness_pairs_exercised": len(selected_witnesses),
        "scope": "All Boolean predicates on {0,...,t}, separately for every t in the stated range.",
    }


def check_negative_controls() -> dict:
    negative = {}
    mutations = {
        "always_zero": lambda predicate, target: 0,
        "always_target": lambda predicate, target: target,
    }
    for name, choose in mutations.items():
        witness = None
        for target in range(1, 5):
            for mask in range(1 << (target + 1)):
                predicate = tuple(bool(mask & (1 << i)) for i in range(target + 1))
                b = choose(predicate, target)
                if not is_witness(predicate, b, target):
                    witness = {"target": target, "predicate": predicate, "chosen_b": b}
                    break
            if witness is not None:
                break
        assert witness is not None
        negative[name] = witness

    # A Boolean model of the formulas, not a model of full recursor arithmetic.
    # S is deliberately noninjective. This disproves the proposed logical
    # quantifier interchange without claiming an arithmetic countermodel.
    domain = (0, 1)
    successor_values = (1, 1)
    predicate = (True, False)
    target = 1

    def matrix(x: int, b: int) -> bool:
        predecessor_edge = successor_values[x] != b or predicate[x]
        endpoint_edge = not predicate[x] or x != b or b == target
        return predecessor_edge and endpoint_edge

    table = [[matrix(x, b) for b in domain] for x in domain]
    pointwise_witnesses = all(any(matrix(x, b) for b in domain) for x in domain)
    common_witness = any(all(matrix(x, b) for x in domain) for b in domain)
    assert table == [[False, True], [True, False]]
    assert pointwise_witnesses and not common_witness
    negative["quantifier_order"] = {
        "domain": domain,
        "successor_table": successor_values,
        "predicate": predicate,
        "target": target,
        "matrix_rows_x_columns_b": table,
        "forall_x_exists_b": pointwise_witnesses,
        "exists_b_forall_x": common_witness,
        "scope": "Formula-level counterexample only; not a model of the recursion axioms.",
    }
    return negative


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--max-target", type=int, default=10)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("boundary_results.json"))
    args = parser.parse_args()
    if not 0 <= args.max_target <= 16:
        parser.error("--max-target must be between 0 and 16")
    result = {
        "status": "passed",
        "scope": "Finite diagnostic checks, not a formal proof of the metatheorem.",
        "syntax_costs": check_costs(),
        "witness_scan": check_scan(args.max_target),
        "negative_controls": check_negative_controls(),
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
