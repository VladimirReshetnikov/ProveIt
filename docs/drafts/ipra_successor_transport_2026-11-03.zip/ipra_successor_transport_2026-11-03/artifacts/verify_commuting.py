#!/usr/bin/env python3
"""Finite checks of commuting-iterator fusion and its distinct size ledgers.

Exhaustive finite transformation checks are diagnostic evidence for the
written induction argument; they are not a formal arithmetic metatheorem.
"""

from __future__ import annotations

import argparse
from itertools import product
import json
from pathlib import Path

from verify_boundary import (
    Tree,
    ZERO,
    addition,
    node,
    replace_active,
    successor,
    var,
)


def iterate(table: tuple[int, ...], count: int, state: int) -> int:
    for _ in range(count):
        state = table[state]
    return state


def check_finite_transformations() -> dict:
    functions = tuple(product(range(3), repeat=3))
    commuting_pairs = noncommuting_pairs = fusion_checks = 0
    first_failure_without_commutation = None
    for h, k in product(functions, repeat=2):
        commute = all(h[k[a]] == k[h[a]] for a in range(3))
        if commute:
            commuting_pairs += 1
            for n, m, p, a in product(range(5), range(5), range(5), range(3)):
                left = iterate(h, n, iterate(k, m, iterate(h, p, a)))
                right = iterate(k, m, iterate(h, n + p, a))
                assert left == right
                fusion_checks += 1
        else:
            noncommuting_pairs += 1
            a = next(a for a in range(3) if h[k[a]] != k[h[a]])
            # Exponents n=m=1,p=0 reduce the proposed fusion to commutation.
            left = iterate(h, 1, iterate(k, 1, iterate(h, 0, a)))
            right = iterate(k, 1, iterate(h, 1, a))
            assert left != right
            if first_failure_without_commutation is None:
                first_failure_without_commutation = {
                    "h": h,
                    "k": k,
                    "n": 1,
                    "m": 1,
                    "p": 0,
                    "a": a,
                    "left": left,
                    "right": right,
                }
    assert commuting_pairs + noncommuting_pairs == 27 * 27
    return {
        "state_set": [0, 1, 2],
        "all_transformations": len(functions),
        "all_ordered_pairs": len(functions) ** 2,
        "commuting_pairs": commuting_pairs,
        "noncommuting_pairs": noncommuting_pairs,
        "maximum_exponent": 4,
        "fusion_instances": fusion_checks,
        "each_noncommuting_pair_has_a_counterexample": True,
        "first_failure_without_commutation": first_failure_without_commutation,
    }


def check_other_guards() -> dict:
    def clocked_iterate(n: int, a: int) -> int:
        # The update h(v,w)=v+w commutes with k(v)=v+1 at each fixed w,
        # but its counter resets in each separately initialized iteration.
        for w in range(n):
            a += w
        return a

    n = m = p = 1
    a = 0
    left = clocked_iterate(n, clocked_iterate(p, a) + m)
    right = clocked_iterate(n + p, a) + m
    assert (left, right) == (1, 2)

    # Omitting literal equality of the repeated h-parameter tuples is false.
    c_outer, c_inner = 1, 2
    mismatch_left = n * c_outer + p * c_inner + a
    mismatch_right = (n + p) * c_outer + a
    assert (mismatch_left, mismatch_right) == (3, 2)
    return {
        "counter_dependence": {
            "h(v,w)": "v+w",
            "k(v)": "v+1",
            "n": n,
            "m": m,
            "p": p,
            "a": a,
            "left": left,
            "right": right,
        },
        "mismatched_parameter_tuples": {
            "h_c(v)": "v+c",
            "k(v)": "v",
            "outer_parameter": c_outer,
            "inner_parameter": c_inner,
            "n": n,
            "p": p,
            "a": a,
            "left": mismatch_left,
            "right": mismatch_right,
        },
    }


def numeral_successors(term: Tree, count: int) -> Tree:
    for _ in range(count):
        term = successor(term)
    return term


def recursor(label: str, body: Tree, counter: Tree, initializer: Tree) -> Tree:
    return Tree("recursor:" + label, (counter, initializer), body)


def ordinary_module(label: str, body: Tree) -> Tree:
    a, n = var("a"), var("n")
    base = node("equal", recursor(label, body, ZERO, a), a)
    previous = recursor(label, body, n, a)
    rhs = replace_active(replace_active(body, "v", previous), "w", n)
    step = node("equal", recursor(label, body, successor(n), a), rhs)
    return node("forall:a", node("and", base, node("forall:n", step)))


def merge_active(tree: Tree, old_label: str, new_label: str, new_body: Tree) -> Tree:
    children = tuple(merge_active(c, old_label, new_label, new_body) for c in tree.children)
    if tree.tag == "recursor:" + old_label:
        return Tree("recursor:" + new_label, children, new_body)
    return Tree(tree.tag, children, tree.frozen)


def active_occurrences(tree: Tree, variable: str) -> int:
    return int(tree.tag == "variable:" + variable) + sum(
        active_occurrences(c, variable) for c in tree.children
    )


def check_family_costs() -> dict:
    v, w, n, a = map(var, ("v", "w", "n", "a"))
    families = argument_checks = 0
    samples = []
    for j in range(2, 17):
        for ell in range(2, 17):
            if j == ell:
                continue
            hj = numeral_successors(v, j)
            hk = numeral_successors(v, ell)

            def gj(counter: Tree, initializer: Tree) -> Tree:
                return recursor("G" + str(j), hj, counter, initializer)

            def gk(counter: Tree, initializer: Tree) -> Tree:
                return recursor("G" + str(ell), hk, counter, initializer)

            old_body = gj(w, gk(w, gj(w, v)))
            new_body = gk(w, gj(addition(w, w), v))
            d = j - 1
            assert old_body.size() == 2 * j + ell + 10
            assert new_body.size() == j + ell + 11
            assert active_occurrences(old_body, "v") == 1
            assert active_occurrences(new_body, "v") == 1
            old_call = recursor("old", old_body, n, a)
            new_call = recursor("new", new_body, n, a)
            assert old_call.size() == 2 * j + ell + 13
            assert new_call.size() == j + ell + 14
            assert old_call.size() - new_call.size() == d

            original = ordinary_module("old", old_body)
            image = merge_active(original, "old", "new", new_body)
            canonical = ordinary_module("new", new_body)
            assert original.size() == 8 * j + 4 * ell + 55
            assert image.size() == 5 * j + 4 * ell + 58
            assert canonical.size() == 4 * j + 4 * ell + 59
            assert original.size() - image.size() == 3 * d
            assert original.size() - canonical.size() == 4 * d
            assert image.size() - canonical.size() == d

            for counter_depth in range(7):
                for initializer_depth in range(5):
                    counter = numeral_successors(var("u"), counter_depth)
                    initializer = addition(
                        numeral_successors(var("z"), initializer_depth), var("y")
                    )
                    before = recursor("old", old_body, counter, initializer)
                    after = recursor("new", new_body, counter, initializer)
                    assert before.size() - after.size() == d
                    argument_checks += 1
            if (j, ell) in ((2, 3), (3, 2), (8, 3), (16, 2)):
                samples.append({
                    "j": j,
                    "ell": ell,
                    "old_body": old_body.size(),
                    "new_body": new_body.size(),
                    "old_call": old_call.size(),
                    "new_call": new_call.size(),
                    "ordinary_source_module": original.size(),
                    "exact_homomorphic_image_module": image.size(),
                    "fresh_canonical_module": canonical.size(),
                })
            families += 1
    return {
        "j_and_ell_range": [2, 16],
        "distinct_parameter_pairs": families,
        "arbitrary_argument_size_checks": argument_checks,
        "source_image_and_canonical_ledgers_distinguished": True,
        "samples": samples,
    }


def check_module_growth_warning() -> dict:
    v = var("v")
    duplicated = addition(addition(v, v), addition(v, v))
    folded = recursor("D", duplicated, successor(ZERO), v)
    assert (duplicated.size(), active_occurrences(duplicated, "v")) == (13, 4)
    assert (folded.size(), active_occurrences(folded, "v")) == (17, 1)
    source_cost = ordinary_module("folded", folded).size()
    canonical_cost = ordinary_module("duplicated", duplicated).size()
    assert (source_cost, canonical_cost) == (83, 112)
    return {
        "folded_body_size": folded.size(),
        "unfolded_body_size": duplicated.size(),
        "folded_active_state_occurrences": active_occurrences(folded, "v"),
        "unfolded_active_state_occurrences": active_occurrences(duplicated, "v"),
        "source_ordinary_module": source_cost,
        "fresh_canonical_ordinary_module": canonical_cost,
        "growth": canonical_cost - source_cost,
        "conclusion": "Smaller descriptors do not imply smaller freshly regenerated ordinary modules.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("commuting_results.json"))
    args = parser.parse_args()
    result = {
        "status": "passed",
        "scope": "Finite algebraic and syntax diagnostics, not a proof-assistant formalization.",
        "finite_transformations": check_finite_transformations(),
        "additional_guard_counterexamples": check_other_guards(),
        "family_costs": check_family_costs(),
        "fresh_module_growth_counterexample": check_module_growth_warning(),
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
