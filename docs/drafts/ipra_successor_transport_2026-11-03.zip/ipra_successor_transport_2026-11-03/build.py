#!/usr/bin/env python3
"""Run finite checks and build the mathematical report with pdfLaTeX."""
from __future__ import annotations

import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
ARTIFACTS = ROOT / "artifacts"
LOGS = ARTIFACTS / "build_logs"


def main() -> None:
    LOGS.mkdir(exist_ok=True)
    for name in ("verify_transport.py", "verify_boundary.py", "verify_commuting.py"):
        result = subprocess.run(
            [sys.executable, str(ARTIFACTS / name)], cwd=ROOT,
            text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        )
        (LOGS / (Path(name).stem + ".txt")).write_text(result.stdout)
        if result.returncode:
            raise RuntimeError(f"{name} failed; inspect its build log")
        print(f"PASS {name}")
    latex = shutil.which("pdflatex")
    if latex is None:
        raise RuntimeError("pdfLaTeX is required; the finite verifiers already passed")
    for number in range(1, 4):
        result = subprocess.run(
            [latex, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
            cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        )
        (LOGS / f"latex_pass_{number}.txt").write_text(result.stdout)
        if result.returncode:
            raise RuntimeError(f"LaTeX pass {number} failed; inspect its build log")
    log = (ROOT / "report.log").read_text(errors="replace")
    overfull = re.findall(r"Overfull \\[hv]box[^\n]*", log)
    unresolved = [line for line in log.splitlines()
                  if "undefined" in line.lower() or "Rerun to get" in line]
    pages = re.search(r"Output written on report\.pdf \((\d+) pages", log)
    summary = {
        "finite_verifiers": "passed",
        "latex_passes": 3,
        "pdf_exists": (ROOT / "report.pdf").is_file(),
        "pages": int(pages.group(1)) if pages else None,
        "overfull_boxes": overfull,
        "unresolved_references": unresolved,
        "status": "passed" if not overfull and not unresolved else "layout_review_required",
    }
    (ARTIFACTS / "build_results.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
