#!/usr/bin/env python3
"""Recount complete checkers from exact packaged bytes; execute none of them.

Python 3.12.14 was used for the recorded AST/unparse measurements.
The candidate is checker.py unless --candidate explicitly selects another file.
"""

import argparse
import ast
from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize


ROOT = Path(__file__).resolve().parent
METRICS = ("source_tokens", "normalized_tokens", "ast_nodes",
           "normalized_bytes", "raw_bytes", "effective_lines")
IGNORED_TOKENS = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.NEWLINE,
                  tokenize.NL, tokenize.INDENT, tokenize.DEDENT,
                  tokenize.COMMENT}
MACRO_SUFFIX = {
    "source_tokens": "Tokens",
    "normalized_tokens": "NormalizedTokens",
    "ast_nodes": "AST",
    "normalized_bytes": "NormalizedBytes",
    "raw_bytes": "RawBytes",
    "effective_lines": "EffectiveLines",
}


def standalone_string(node):
    return (isinstance(node, ast.Expr)
            and isinstance(node.value, ast.Constant)
            and isinstance(node.value.value, str))


class RemoveStandaloneStrings(ast.NodeTransformer):
    def visit_Expr(self, node):
        return None if standalone_string(node) else self.generic_visit(node)


def significant_tokens(source, excluded_spans=()):
    return [token for token in tokenize.generate_tokens(io.StringIO(source).readline)
            if token.type not in IGNORED_TOKENS
            and not any(start <= token.start and token.end <= end
                        for start, end in excluded_spans)]


def measure(path):
    raw = path.read_bytes()
    source = raw.decode("utf-8")
    tree = ast.parse(source)
    lines = source.splitlines(keepends=True)

    # AST columns count UTF-8 bytes; tokenize columns count Unicode characters.
    def position(row, byte_column):
        prefix = lines[row - 1].encode("utf-8")[:byte_column]
        return row, len(prefix.decode("utf-8"))

    spans = [(position(node.lineno, node.col_offset),
              position(node.end_lineno, node.end_col_offset))
             for node in ast.walk(tree) if standalone_string(node)]
    tokens = significant_tokens(source, spans)
    effective = set()
    for token in tokens:
        last = token.end[0] - (token.end[1] == 0 and token.end[0] > token.start[0])
        effective.update(range(token.start[0], last + 1))
    clean = ast.fix_missing_locations(RemoveStandaloneStrings().visit(tree))
    normalized = ast.unparse(clean) + "\n"
    return {
        "sha256": hashlib.sha256(raw).hexdigest(),
        "source_tokens": len(tokens),
        "normalized_tokens": len(significant_tokens(normalized)),
        "ast_nodes": sum(1 for _ in ast.walk(clean)),
        "normalized_bytes": len(normalized.encode("utf-8")),
        "raw_bytes": len(raw),
        "effective_lines": len(effective),
        "physical_lines": len(source.splitlines()),
    }


def latex_table(primary, minimum, candidate):
    keys = ("source_tokens", "normalized_tokens", "ast_nodes",
            "normalized_bytes", "raw_bytes")
    out = [r"\begin{center}", r"\small", r"\setlength{\tabcolsep}{4pt}",
           r"\begin{tabular}{lrrrrr}", r"\toprule",
           r"Complete program & \shortstack{Source\\tokens} & "
           r"\shortstack{Normalized\\tokens} & \shortstack{AST\\nodes} & "
           r"\shortstack{Normalized\\bytes} & \shortstack{Raw\\bytes} \\",
           r"\midrule"]
    for row in primary:
        out.append(row["label"] + " & " + " & ".join(str(row[k]) for k in keys) + r" \\")
    out += [r"\midrule", "Current coordinate minima & "
            + " & ".join(str(minimum[k]) for k in keys) + r" \\"]
    out.append(r"\textbf{Shared unary checker} & "
               + " & ".join(r"\textbf{" + str(candidate[k]) + "}" for k in keys)
               + r" \\")
    out += [r"\bottomrule", r"\end{tabular}", r"\end{center}"]
    return "\n".join(out) + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, default=ROOT / "checker.py")
    args = parser.parse_args()
    inventory = json.loads((ROOT / "comparison/inventory.json").read_text())
    sources = []
    by_hash = {}
    for entry in inventory["sources"]:
        result = measure(ROOT / entry["snapshot"])
        if result["sha256"] != entry["sha256"] or result["raw_bytes"] != entry["raw_bytes"]:
            raise ValueError("Changed comparison source: " + entry["snapshot"])
        row = dict(entry, **result)
        sources.append(row)
        by_hash[row["sha256"]] = row
    occurrences = inventory["occurrences"]
    actual_occurrences = Counter(row["sha256"] for row in occurrences)
    if set(actual_occurrences) != set(by_hash):
        raise ValueError("Inventory and packaged source sets differ")
    if any(actual_occurrences[row["sha256"]] != row["occurrences"] for row in sources):
        raise ValueError("Incorrect occurrence count")
    if len(sources) != inventory["distinct_sources"] or len(occurrences) != inventory["standalone_occurrences"]:
        raise ValueError("Incorrect inventory totals")
    for row in occurrences:
        if row["snapshot"] != by_hash[row["sha256"]]["snapshot"]:
            raise ValueError("Incorrect occurrence snapshot")
    primary = [dict(entry, **measure(ROOT / entry["snapshot"]))
               for entry in inventory["primary"]]
    minimum = {key: min(row[key] for row in sources) for key in METRICS}
    primary_minimum = {key: min(row[key] for row in primary) for key in METRICS}
    candidate = measure(args.candidate.resolve())
    try:
        candidate_path = str(args.candidate.resolve().relative_to(ROOT))
    except ValueError:
        candidate_path = str(args.candidate.resolve())
    candidate["source_path"] = candidate_path
    controls = [dict(source_path=str(path.relative_to(ROOT)), **measure(path))
                for path in sorted((ROOT / "controls").glob("*.py"))]
    result = {
        "schema_version": 1,
        "python_version": platform.python_version(),
        "repository": inventory["repository"],
        "commit": inventory["commit"],
        "metric_definitions": {
            "source_tokens": "Original tokenize tokens, excluding whitespace/layout, comments, and standalone constant-string expressions.",
            "normalized_tokens": "The same token count after removing standalone strings and applying ast.unparse plus one final newline.",
            "ast_nodes": "All ast.walk nodes after removing standalone constant-string expressions; includes context and operator nodes.",
            "normalized_bytes": "UTF-8 byte length of ast.unparse of that AST plus one final newline.",
            "raw_bytes": "All original file bytes, including comments and documentation.",
            "effective_lines": "Physical lines occupied by significant original-source tokens.",
            "physical_lines": "Original source splitlines count, including blank and comment lines.",
        },
        "trust_boundary": "Entire individual acceptance program including imports, formation, substitution, schemas, inference, and JSON CLI; fixed Python runtime and standard-library implementation. No test or translation program is imported by the six current checkers or the candidate.",
        "selection": inventory["selection"],
        "python_members_in_archives": inventory["python_members"],
        "standalone_occurrences": len(occurrences),
        "distinct_sources": len(sources),
        "primary": primary,
        "coordinate_minima": minimum,
        "primary_coordinate_minima": primary_minimum,
        "candidate": candidate,
        "candidate_strictly_below_minima": {key: candidate[key] < minimum[key] for key in METRICS},
        "candidate_at_most_minima": {key: candidate[key] <= minimum[key] for key in METRICS},
        "reduction_percent": {key: 100 * (minimum[key] - candidate[key]) / minimum[key] for key in METRICS},
        "distinct_baseline_sources": sources,
        "matched_controls": controls,
        "limitations": [
            "These are finite source-size comparisons, not universal shortest-program lower bounds.",
            "The six public programs differ in syntax/interface details, including explicit versus canonical falsity; the main paper explains the retained mathematical boundary.",
            "This script verifies packaged source hashes and recounts exact bytes. It does not execute a checker or establish mathematical soundness.",
            "The original ZIP identities were verified when the exact source snapshots were obtained; reproducing archive retrieval requires the pinned repository resources.",
            "AST normalization is Python-version sensitive; reproduce recorded numbers with Python 3.12.14.",
        ],
    }
    results = ROOT / "results"
    results.mkdir(exist_ok=True)
    (results / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    macros = []
    for prefix, values in (("Candidate", candidate), ("Minimum", minimum)):
        for key, suffix in MACRO_SUFFIX.items():
            macros.append("\\newcommand{\\" + prefix + suffix + "}{" + str(values[key]) + "}")
    for name, value in (("ComparisonOccurrences", len(occurrences)),
                        ("ComparisonDistinct", len(sources)),
                        ("ComparisonPrimary", len(primary))):
        macros.append("\\newcommand{\\" + name + "}{" + str(value) + "}")
    (results / "metrics_macros.tex").write_text("\n".join(macros) + "\n")
    (ROOT / "comparison/current_table.tex").write_text(latex_table(primary, minimum, candidate))
    print(json.dumps({"candidate": candidate,
                      "coordinate_minima": minimum,
                      "standalone_occurrences": len(occurrences),
                      "distinct_sources": len(sources),
                      "strictly_below": result["candidate_strictly_below_minima"]}, indent=2))


if __name__ == "__main__":
    main()
