A SMALLER COMPLETE AXIOMATIZATION OF INTUITIONISTIC PRA
Prepared for Vladimir Reshetnikov, 6 November 2026
=====================================================

START HERE
  report.pdf        Self-contained research paper, with all rules and proofs
  report.tex        Main LaTeX source; supporting sources are in sections/
  checker.py        Entire trusted acceptance program
  FORMAT.txt        Exact mathematical and JSON certificate conventions

RESULT
The complete checker has:
  853 significant original-source tokens
  853 normalized tokens
  884 executable AST nodes
  2,688 normalized executable bytes
  2,937 raw source bytes
  72 effective code lines

These are strictly below the corresponding current minima:
  863 / 864 / 915 / 2,730 / 3,088 / 76.

The comparison is pinned to ProveIt commit
  9e338a5c51a26ac6ae90f2d8f563a44c3879ba68
and includes all six primary current acceptance programs, plus 89 distinct
standalone sources appearing 251 times in their archives. Exact original
source snapshots, lengths, hashes, and member provenance are included.
The older 957-token frontier quoted inside the drafts is not used.

The mathematical basis is inherited from the unary-existential proposal.
This iteration combines that language with a single typed finite-prefix
substitution traversal shared by validation, lifting, instantiation, and
public falsity conversion. It also rejects malformed Boolean hypothesis
lookup keys. These are implementation improvements, with full attribution;
no new invention of the inherited arithmetic or logical basis is claimed.

THE THEORY
Native terms use variables, zero, successor, and finite initialized
recursion. Native formulas use equality, Pi_x(A;B)=forall x(A -> B),
and E_x A=exists x A. Public falsity has the explicit conversion
bottom <-> (0 = S0). The report lists every primitive logical rule,
both recursion computation schemas, and the numerical schema.

The numerical schema gives induction for literal equations and
zero/successor cases for all other formulas. Formula amalgamation
recovers full conjunction and disjunction. A numerical equality detector
and quantifier-free reflection recover every reference induction instance.

The ordinary first-order realization is bi-interpretable and equiconsistent
with full first-order iPRA, using the entire number domain. Internal
recursion uniqueness proves the interpretation round trips at every
counter, including nonstandard values.

This is a strict finite implementation comparison, not a theorem of a
globally shortest checker. General proofs are written mathematics;
no Lean/Rocq formalization of the metatheory or Python semantics is claimed.

RUN
Python 3.10+ and its standard library suffice. Python 3.12.14 reproduces
the recorded AST normalization.

  python3 checker.py validation/certificates/induction_zero_plus_n.json
  python3 reproduce.py --no-pdf

The first checks 0+n=n without assumptions and prints ACCEPT.
The second remeasures every comparison source and reruns finite checks.

  python3 reproduce.py

This also compiles the PDF and rebuilds the ZIP. It requires pdfLaTeX
and the standard packages declared in report.tex. To compile/package
already validated files without rerunning tests:

  python3 build.py

A certificate is [assumptions, goal, proof]. A nonempty assumptions list
certifies a sequent under those assumptions; it is not an unconditional
theorem. Zero is -1 in the wire format, while nonnegative integers are
variable indices. Very large finite proofs can exceed host resources.

VALIDATION
  116 positive certificates accepted.
   61 negative certificates rejected.
  Every positive replayed in the unchanged original unary checker and,
  after an untrusted expansion, in an unchanged binary checker.
  362 normal/optimized Python CLI invocations.
  1,500 callable-environment substitution comparisons.
  5,000 unique-named-variable substitution comparisons.
  Explicit rejection of quantified induction, escaped eigenvariables,
  capture, malformed terms, and invalid unused witnesses.

One old Boolean-alias lookup is preserved as a negative; its integer-key
counterpart is positive. The other 175 original fixtures are reproduced
byte-for-byte. All records and provenance are in validation/.

CONTENTS
  checker.py                 Entire trusted acceptance boundary
  report.pdf, report.tex     Paper and main LaTeX source
  sections/                  Remaining self-contained paper source
  FORMAT.txt                 Exact certificate specification
  validation/                Fixtures, reference kernels, oracle, results
  comparison/                89 unchanged comparison sources and census
  provenance/                Pinned repository and archive identities
  results/                   Size measurements, compilation and visual review
  measure.py                 Static reproducible source measurement
  reproduce.py               Measurement, validation, and PDF entry point
  build.py                   PDF/ZIP generation and integrity verification
  SHA256SUMS.txt              Hashes of every other packaged deliverable

Only checker.py participates in certificate acceptance. The mathematical
paper, proof builders, translators, references, tests, and measurement
scripts are not imported by it.
