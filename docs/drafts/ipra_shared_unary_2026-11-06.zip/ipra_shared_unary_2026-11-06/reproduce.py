"""Reproduce complete-checker measurements, finite verification, and the paper."""

import argparse
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--no-pdf", action="store_true",
                        help="run all Python checks without requiring a TeX installation")
    args = parser.parse_args()
    scripts = ["measure.py", "validation/validate.py", "validation/independent_binding.py"]
    if not args.no_pdf:
        scripts.append("build.py")
    for script in scripts:
        print("Running " + script, flush=True)
        subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
