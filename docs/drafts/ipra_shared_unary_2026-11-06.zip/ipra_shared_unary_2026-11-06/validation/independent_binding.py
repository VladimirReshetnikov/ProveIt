"""Check finite-prefix substitution against fresh named-variable semantics.

This oracle does not implement shifting or substitution by a depth walker.
It decodes bound indices to unique symbol objects, substitutes free symbols,
then re-encodes. The main checker is imported only as the system under test.
"""

import importlib.util
import json
import random
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("kernel", ROOT / "checker.py")
kernel = importlib.util.module_from_spec(spec)
spec.loader.exec_module(kernel)


def bind_count(tag, child):
    if tag == "r" and child == 2:
        return 2
    return 1 if tag in ("pi", "ex") else 0


def decode(tree, bound=()):
    if type(tree) is int:
        if tree == -1:
            return ("zero",)
        return ("var", bound[tree] if tree < len(bound) else tree - len(bound))
    tag, *children = tree
    slots = tuple(object() for _ in range(2 if tag == "r" else
                                        1 if tag in ("pi", "ex") else 0))
    return (tag, slots, tuple(
        decode(child, slots[:bind_count(tag, i)] + bound)
        for i, child in enumerate(children)))


def encode(tree, bound=()):
    if tree[0] == "zero":
        return -1
    if tree[0] == "var":
        symbol = tree[1]
        return symbol + len(bound) if type(symbol) is int else bound.index(symbol)
    tag, slots, children = tree
    return [tag, *(encode(child, slots[:bind_count(tag, i)] + bound)
                   for i, child in enumerate(children))]


def replace_free(tree, prefix, offset):
    if tree[0] == "zero":
        return tree
    if tree[0] == "var":
        symbol = tree[1]
        if type(symbol) is not int:
            return tree
        return decode(prefix[symbol]) if symbol < len(prefix) else ("var", symbol + offset)
    tag, slots, children = tree
    return (tag, slots, tuple(replace_free(c, prefix, offset) for c in children))


def term(rng, depth, scope=0):
    if depth == 0 or rng.randrange(4) == 0:
        return rng.randrange(-1, scope + 6)
    if rng.randrange(2):
        return ["s", term(rng, depth - 1, scope)]
    return ["r", term(rng, depth - 1, scope), term(rng, depth - 1, scope),
            term(rng, depth - 1, scope + 2)]


def formula(rng, depth, scope=0):
    if depth == 0 or rng.randrange(3) == 0:
        return ["=", term(rng, 2, scope), term(rng, 2, scope)]
    if rng.randrange(2):
        return ["ex", formula(rng, depth - 1, scope + 1)]
    return ["pi", formula(rng, depth - 1, scope + 1),
            formula(rng, depth - 1, scope + 1)]


def main():
    rng = random.Random(20261106)
    tested = 0
    kinds = {"shift": 0, "instantiate": 0, "recursion": 0,
             "successor": 0, "general": 0}
    for i in range(1000):
        a = formula(rng, 4) if i % 2 else term(rng, 4)
        assert encode(decode(a)) == a
        envs = [
            ("shift", [rng.randrange(5)]),
            ("instantiate", [term(rng, 3), -1]),
            ("recursion", [term(rng, 3), term(rng, 3), -2]),
            ("successor", [["s", 0], 0]),
            ("general", [term(rng, 3) for _ in range(3)] + [rng.randrange(-3, 4)]),
        ]
        for name, env in envs:
            expected = encode(replace_free(decode(a), env[:-1], env[-1]))
            actual = kernel.subst(a, env)
            if actual != expected:
                raise AssertionError((name, a, env, actual, expected))
            kinds[name] += 1
            tested += 1
    result = dict(seed=20261106, trees=1000, substitutions=tested,
                  cases=kinds, mismatches=0,
                  oracle="Unique named bound symbols, free-symbol replacement, re-encoding")
    (ROOT / "validation/binding_results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
