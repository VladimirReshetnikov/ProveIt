"""Generate and verify substantive proofs and rejection cases.

The planned sequent is encoded independently of kernel inference. Every
positive proof is replayed by the unchanged original unary checker and then
expanded into the unchanged, separately implemented compact binary checker.
Run with Python 3.10+ from any directory. No third-party packages are needed.
"""

from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import platform
import random
import subprocess
import sys

from builder import *
import translate


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "certificates"
OUT.mkdir(exist_ok=True)
records = []


def save(name, data, accept, category, expanded_bytes=0):
    encoded = json.dumps(data, separators=(",", ":"), ensure_ascii=True) + "\n"
    path = OUT / (name + ".json")
    path.write_text(encoded)
    records.append({"name": name, "category": category, "accepted": accept,
                    "file": str(path.relative_to(ROOT)), "bytes": len(encoded.encode()),
                    "sha256": hashlib.sha256(encoded.encode()).hexdigest(),
                    "independent_expansion_bytes": expanded_bytes})


def positive(name, context, proof, goal, parameters, category):
    # This expected goal is supplied by the mathematical test, not inferred.
    assert same(proof.goal, goal)
    data = certificate(context, proof, parameters)
    expected = [[encode(a, parameters) for a in context], encode(goal, parameters)]
    assert data[:2] == expected
    expanded = translate.certificate(data)
    assert expanded["goal"] == translate.syntax(expected[1])
    size = len(json.dumps(expanded, separators=(",", ":")))
    save(name, data, True, category, size)
    return data


def negative(name, data, category="rejection"):
    try:
        kernel.check(data)
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        save(name, data, False, category)
        return
    raise AssertionError("Invalid certificate accepted: " + name)


def add(a, n):
    u, v = fresh("previous"), fresh("counter")
    return R(n, a, u, v, S(u))


def tests():
    p, q = fresh("parameter_p"), fresh("parameter_q")
    u, v = fresh("bound_u"), fresh("bound_v")
    params = [p, q]
    forms = [
        Eq(p, q),
        Pi(u, Eq(u, p), Eq(S(u), S(p))),
        Ex(u, Eq(u, p)),
        Pi(u, Ex(v, Eq(v, u)), Ex(v, Eq(S(v), S(p)))),
        Ex(u, Pi(v, Eq(v, u), Eq(p, q))),
        Pi(u, Pi(v, Eq(v, u), Eq(u, p)), Ex(v, Eq(v, q))),
    ]
    pairs = [(0, 0), (0, 1), (1, 0), (0, 2), (2, 0), (1, 2),
             (2, 1), (3, 4), (4, 3), (5, 4)]
    for number, (i, j) in enumerate(pairs):
        a, b = forms[i], forms[j]
        z = fresh("tag")
        plan = amalgamate(z, a, b)
        extra = Eq(S(p), S(q))
        for side in (0, 1):
            selected = a if side == 0 else b
            mixed = sub(plan.formula, {z: Z if side == 0 else S(q)})
            for direction in (True, False):
                source, target = (mixed, selected) if direction else (selected, mixed)
                proof = endpoint(plan, side, hyp(source), direction, q)
                name = f"endpoint_{number:02d}_{side}_{'out' if direction else 'in'}"
                positive(name, [extra, source], proof, target, params, "amalgamation_endpoint")

        conjunction_formula, conjunction_plan = conjunction(a, b)
        positive(f"and_{number:02d}_intro", [extra, a, b],
                 conjunction_intro(conjunction_plan, hyp(a), hyp(b)),
                 conjunction_formula, params, "derived_conjunction")
        for side in (0, 1):
            positive(f"and_{number:02d}_elim_{side}", [extra, conjunction_formula],
                     conjunction_elim(conjunction_plan, hyp(conjunction_formula), side),
                     a if side == 0 else b, params, "derived_conjunction")

        disjunction_formula, disjunction_plan = disjunction(a, b)
        for side in (0, 1):
            selected = a if side == 0 else b
            positive(f"or_{number:02d}_intro_{side}", [extra, selected],
                     disjunction_intro(disjunction_plan, hyp(selected), side),
                     disjunction_formula, params, "derived_disjunction")
        goal = Ex(u, Eq(u, p))
        ia, ib = Imp(a, goal), Imp(b, goal)
        proof = disjunction_elim(disjunction_plan, hyp(disjunction_formula), goal,
                                lambda r: imp_elim(hyp(ia), r),
                                lambda r: imp_elim(hyp(ib), r))
        positive(f"or_{number:02d}_elim", [extra, disjunction_formula, ia, ib],
                 proof, goal, params, "derived_disjunction")

    # Dependent local assumptions: the conjunction code runs inside a Pi
    # binder, and the two input formulas genuinely depend on its eigenvariable.
    x = fresh("local_number")
    a, b = Ex(u, Eq(u, x)), Pi(v, Eq(v, x), Eq(S(v), S(x)))
    result, plan = conjunction(a, b)
    body = imp_intro(b, lambda hb: conjunction_intro(plan, hyp(a), hb))
    local = pi_intro(x, a, body)
    positive("nested_local_conjunction", [], local, Pi(x, a, Imp(b, result)), [],
             "dependent_local_context")

    # Nontrivial equation induction: addition defined by finite recursion.
    n = fresh("induction_number")
    matrix = Eq(add(Z, n), n)
    base = compute(add(Z, Z))

    def step(y, ih):
        x = fresh("transport")
        return trans(compute(add(Z, S(y))), congr(ih, x, S(x)))

    proof = numerical(n, matrix, p, base, step)
    induction_data = positive("induction_zero_plus_n", [], proof, Eq(add(Z, p), p),
                              params, "equation_induction")

    # Parameter-dependent invariant and a real use of its induction hypothesis.
    h1, h2 = fresh("previous"), fresh("counter")
    const_rec = lambda t: R(t, q, h1, h2, h1)
    matrix = Eq(const_rec(n), q)
    proof = numerical(n, matrix, p, compute(const_rec(Z)),
                      lambda y, ih: trans(compute(const_rec(S(y))), ih))
    positive("induction_with_parameter", [], proof, Eq(const_rec(p), q), params,
             "equation_induction")

    # Cases, with an arbitrary quantified matrix. No induction hypothesis is
    # accepted for this matrix; the successor branch ignores its base guard.
    matrix = Ex(u, Eq(u, n))
    base = exists_intro(sub(matrix, {n: Z}), Z, refl(Z))
    proof = numerical(n, matrix, p, base,
                      lambda y, unused: exists_intro(sub(matrix, {n: S(y)}), S(y), refl(S(y))))
    case_data = positive("cases_quantified_matrix", [], proof, sub(matrix, {n: p}), params,
                         "numerical_cases")

    # A dependent witness containing two nested recursion binders.
    u0, v0, u1, v1 = [fresh(label) for label in ("u0", "v0", "u1", "v1")]
    nested = R(S(p), q, u0, v0, R(v0, u0, u1, v1, S(u1)))
    witness_goal = Ex(u, Eq(u, nested))
    witness_data = positive("existential_nested_recursion_witness", [],
                            exists_intro(witness_goal, nested, refl(nested)),
                            witness_goal, params, "dependent_witness")
    positive("recursion_nested_successor", [], compute(nested), compute(nested).goal,
             params, "recursion_computation")
    positive("recursion_base_with_parameter", [], compute(R(Z, p, u0, v0, q)),
             Eq(R(Z, p, u0, v0, q), p), params, "recursion_computation")

    # Transport beneath Pi, Ex, and both recursion scopes in one formula.
    z = fresh("replacement")
    x, y = fresh("quantified_x"), fresh("quantified_y")
    template = Pi(x, Eq(R(x, z, u0, v0, R(v0, u0, u1, v1, S(z))), p),
                  Ex(y, Eq(R(z, y, u0, v0, S(u0)), S(z))))
    equality = Eq(p, q)
    source, target = sub(template, {z: p}), sub(template, {z: q})
    transport_data = positive("transport_nested_pi_ex_rec", [equality, source],
                              rewrite(hyp(equality), z, template, hyp(source)), target,
                              params, "capture_avoidance")

    # Direct Pi/Ex operations with genuinely dependent matrices.
    inner = Ex(y, Eq(y, x))
    proof = pi_intro(x, Eq(x, p), exists_intro(inner, x, refl(x)))
    positive("dependent_pi_introduction", [], proof, Pi(x, Eq(x, p), inner), params,
             "primitive_logical_rules")
    principal = Ex(x, Eq(x, p))
    goal = Ex(y, Eq(y, p))
    body = exists_intro(goal, x, hyp(Eq(x, p)))
    proof = exists_elim(hyp(principal), x, body, goal)
    positive("dependent_ex_elimination", [principal], proof, goal, params,
             "primitive_logical_rules")

    positive("derived_reflexivity", [], refl(p), Eq(p, p), params, "equality")
    positive("derived_symmetry", [Eq(p, q)], sym(hyp(Eq(p, q))), Eq(q, p), params, "equality")
    positive("derived_successor_separation", [Eq(Z, S(p))], separation(hyp(Eq(Z, S(p)))),
             D, params, "arithmetic_falsity")
    exploding_goal = Pi(x, Eq(x, p), Ex(y, Eq(R(x, q, u0, v0, S(u0)), y)))
    explosion = positive("derived_explosion_quantified", [D], explode(hyp(D), exploding_goal),
                         exploding_goal, params, "arithmetic_falsity")
    public = copy.deepcopy(explosion)
    public[0] = [["false"]]
    kernel.check(public)
    expanded = translate.certificate(public)
    save("public_falsity_conversion", public, True, "public_interface",
         len(json.dumps(expanded, separators=(",", ":"))))

    # The new shared traversal validates hypothesis keys. Preserve a canonical
    # positive lookup and test the original Boolean alias as a rejection.
    canonical = [[["=", 0, -1]], ["=", 0, -1], ["hyp", ["=", 0, -1]]]
    kernel.check(canonical)
    expanded = translate.certificate(canonical)
    save("stored_hypothesis_canonical", canonical, True, "public_interface",
         len(json.dumps(expanded, separators=(",", ":"))))
    alias = copy.deepcopy(canonical)
    alias[2][1][1] = False
    assert translate.unary.check(alias)
    negative("reject_hypothesis_boolean_alias", alias, "syntax_rejection")

    # Scope and induction restrictions, each targeted at a specific guard.
    true = ["=", -1, -1]
    false = ["=", -1, ["s", -1]]
    ex_zero = ["ex", ["=", 0, -1]]
    negative("reject_ex_witness_escape", [[ex_zero], ["=", 0, -1],
             ["use", ["hyp", ex_zero], ["=", 0, -1], ["hyp", ["=", 0, -1]]]],
             "eigenvariable_rejection")
    negative("reject_pi_eigenvariable_capture", [[["=", 0, -1]],
             ["pi", true, ["=", 0, -1]], ["pi", true, ["hyp", ["=", 0, -1]]]],
             "eigenvariable_rejection")
    negative("reject_witness_equation_missing_lift", [[], ["ex", ["=", 0, 1]],
             ["pack", 0, ["hyp", ["=", 0, 0]]]], "eigenvariable_rejection")

    # An internally valid step proof with a quantified IH is rejected when
    # supplied to the numerical axiom, which demands the fixed base guard.
    mat = Ex(u, Eq(u, n))
    bp = exists_intro(sub(mat, {n: Z}), Z, refl(Z))
    partial = pi_elim(nat_axiom(n, mat), p, bp)
    step_var = fresh("illegal_IH_number")
    illegal_guard = sub(mat, {n: step_var})
    wrong_step = pi_intro(step_var, illegal_guard,
                         exists_intro(sub(mat, {n: S(step_var)}), S(step_var), refl(S(step_var))))
    raw = [[], encode(sub(mat, {n: p}), params),
           ["use", encode_proof(partial, params), -1, encode_proof(wrong_step, params)]]
    negative("reject_quantified_induction_hypothesis", raw, "induction_rejection")
    bad = copy.deepcopy(induction_data)
    bad[1] = ["=", -1, ["s", -1]]
    negative("reject_wrong_induction_conclusion", bad, "induction_rejection")

    # Alter a free-variable substitution below the nested binders.
    bad = copy.deepcopy(transport_data)
    bad[1] = copy.deepcopy(bad[0][1])
    negative("reject_transport_keeps_old_parameter", bad, "capture_rejection")
    bad = copy.deepcopy(transport_data)
    bad[2][2][2][1][2] = 0
    negative("reject_transport_captured_parameter", bad, "capture_rejection")

    # Invalid witnesses must be rejected even when the matrix ignores them.
    const_pi = ["pi", true, true]
    pi_proof = ["pi", true, ["hyp", true]]
    invalid_terms = [True, False, 0.0, -2, "parameter", ["=", -1, -1],
                     ["ex", true], {"var": 0}, ["s"], ["r", -1, -1],
                     ["r", -1, -1, true]]
    for number, term in enumerate(invalid_terms):
        negative(f"reject_pi_ignored_witness_{number:02d}",
                 [[true], true, ["use", pi_proof, term, ["hyp", true]]], "witness_rejection")
        negative(f"reject_ex_ignored_witness_{number:02d}",
                 [[true], ["ex", true], ["pack", term, ["hyp", true]]], "witness_rejection")

    malformed_formulas = [True, 0, -1, 0.0, "formula", [], ["ex"],
                          ["ex", true, true], ["pi", true], ["=", -1],
                          ["=", True, -1], ["=", -1, -2], ["unknown", true]]
    for number, formula in enumerate(malformed_formulas):
        negative(f"reject_goal_syntax_{number:02d}", [[true], formula, ["hyp", true]], "syntax_rejection")
    for number, annotation in enumerate([True, 0.0, "formula", ["s", -1], ["ex"], ["=", -1]]):
        negative(f"reject_equality_template_{number:02d}",
                 [[true], true, ["use", ["hyp", true], annotation, ["hyp", true]]],
                 "syntax_rejection")

    for number, document in enumerate([
        {}, {"assumptions": [], "goal": true, "proof": ["hyp", true]},
        None, True, [[], true], [[], true, ["hyp", true], 0],
        [True, true, ["hyp", true]], [[True], true, ["hyp", true]],
        [[true], true, []], [[true], true, ["unknown"]],
        [[true], true, ["hyp", false]], [[true], true, ["pi", true]],
    ]):
        negative(f"reject_envelope_or_proof_{number:02d}", document, "interface_rejection")


def substitution_audit(samples=1500):
    rng = random.Random(20261106)

    def term(depth):
        if depth == 0 or rng.random() < .5:
            return rng.choice([-1, 0, 1, 2, 7, 31])
        if rng.random() < .5:
            return ["s", term(depth - 1)]
        return ["r", term(depth - 1), term(depth - 1), term(depth - 1)]

    def formula(depth):
        if depth == 0 or rng.random() < .5:
            return ["=", term(2), term(2)]
        if rng.random() < .5:
            return ["ex", formula(depth - 1)]
        return ["pi", formula(depth - 1), formula(depth - 1)]

    for _ in range(samples):
        a = formula(3)
        size = rng.randint(0, 3)
        values = [term(3) for _ in range(size)]
        delta = rng.randint(-size, 5)
        actual = translate.syntax(kernel.subst(a, [*values, delta]))
        old_values = [translate.syntax(t) for t in values]
        expected = translate.old.subst(translate.syntax(a),
                                       lambda i: old_values[i] if i < size else i + delta)
        assert actual == expected
    return {"samples": samples, "seed": 20261106,
            "comparison": "finite substitution versus independent callable substitution after Ex-to-Sigma translation"}


def cli_audit():
    checker = Path(kernel.__file__)
    invocations = 0
    for record in records:
        path = ROOT / record["file"]
        for flags in ([], ["-O"]):
            result = subprocess.run([sys.executable, *flags, str(checker), str(path)],
                                    text=True, capture_output=True, timeout=20)
            expected = (0, "ACCEPT") if record["accepted"] else (1, "REJECT")
            assert (result.returncode, result.stdout.strip()) == expected, (record["name"], flags, result)
            invocations += 1
    malformed = ["{", "[", "", "[[],[\"=\",-1,-1],]"]
    for i, text in enumerate(malformed):
        path = OUT / f"malformed_json_{i}.txt"
        path.write_text(text)
        for flags in ([], ["-O"]):
            result = subprocess.run([sys.executable, *flags, str(checker), str(path)],
                                    text=True, capture_output=True, timeout=20)
            assert (result.returncode, result.stdout.strip()) == (1, "REJECT")
            invocations += 1
    return {"certificate_invocations": 2 * len(records),
            "malformed_json_invocations": 2 * len(malformed), "total_invocations": invocations,
            "normal_and_optimized_python": True}


def upstream_fixture_audit():
    """Verify unchanged fixture bytes, with the two documented alias changes."""
    source = json.loads((ROOT / "upstream_fixture_manifest.json").read_text())
    unchanged = 0
    for record in source["certificates"]:
        if record["name"] == "stored_hypothesis_boolean_alias":
            path = OUT / "reject_hypothesis_boolean_alias.json"
        else:
            path = ROOT / record["file"]
            unchanged += 1
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        assert actual == record["sha256"], record["name"]
    return {"byte_identical_original_fixtures": unchanged,
            "original_boolean_alias_retained_byte_identically_as_negative": True,
            "canonical_integer_key_positive_added": True}


def schema_audit():
    """Distinguish literal-equation induction from Pi/Ex cases with equation matrices."""
    x, y, parameter = fresh("schema_number"), fresh("local"), fresh("parameter")
    matrices = [("equation", Eq(x, parameter)),
                ("pi", Pi(y, Eq(y, x), Eq(x, parameter))),
                ("ex", Ex(y, Eq(y, x)))]
    accepted, rejected = [], []
    for name, matrix in matrices:
        proof = nat_axiom(x, matrix)
        document = certificate([], proof, [parameter])
        translate.certificate(document)
        accepted.append(name)
        if name != "equation":
            base = sub(matrix, {x: Z})
            step_number = fresh("illegal_induction_slot")
            wrong_step = Pi(step_number, sub(matrix, {x: step_number}),
                            sub(matrix, {x: S(step_number)}))
            wrong_goal = Pi(x, base, Imp(wrong_step, matrix))
            forged = [[], encode(wrong_goal, [parameter]),
                      encode_proof(proof, [parameter])]
            try:
                kernel.check(forged)
            except (ValueError, TypeError, IndexError, KeyError, RecursionError):
                rejected.append(name)
            else:
                raise AssertionError("Quantified induction schema accepted: " + name)
    return {"correct_schema_roots_accepted_and_reference_replayed": accepted,
            "quantified_induction_schemas_rejected": rejected,
            "note": "Pi and Ex matrices contain equations but their outer constructor still permits cases only."}


def provenance_audit():
    source = json.loads((ROOT / "source_provenance.json").read_text())
    checked = []
    for record in source["copied_sources"]:
        if record["changes"] != "unchanged":
            continue
        path = ROOT.parent / record["packaged_path"]
        assert hashlib.sha256(path.read_bytes()).hexdigest() == record["source_sha256"], str(path)
        checked.append(record["packaged_path"])
    return {"byte_identical_files": checked}


def main():
    provenance = provenance_audit()
    tests()
    schemas = schema_audit()
    substitutions = substitution_audit()
    cli = cli_audit()
    positive_records = [r for r in records if r["accepted"]]
    negative_records = [r for r in records if not r["accepted"]]
    checker = Path(kernel.__file__)
    baseline = Path(translate.old.__file__)
    result = {
        "status": "passed", "python_version": platform.python_version(),
        "checker_sha256": hashlib.sha256(checker.read_bytes()).hexdigest(),
        "independent_checker_sha256": hashlib.sha256(baseline.read_bytes()).hexdigest(),
        "original_unary_checker_sha256": hashlib.sha256(Path(translate.unary.__file__).read_bytes()).hexdigest(),
        "positive_certificates": len(positive_records),
        "negative_certificates": len(negative_records),
        "positive_original_unary_replays_accepted": len(positive_records),
        "positive_independent_expansions_accepted": len(positive_records),
        "upstream_fixture_comparison": upstream_fixture_audit(),
        "hypothesis_key_validation": "Canonical integer-key lookup is positive; the original malformed Boolean-key alias is retained as a negative fixture.",
        "planned_sequents_checked_independently_of_inference": True,
        "max_certificate_bytes": max(r["bytes"] for r in records),
        "total_certificate_bytes": sum(r["bytes"] for r in records),
        "max_independent_expansion_bytes": max(r["independent_expansion_bytes"] for r in records),
        "substitution_audit": substitutions, "schema_audit": schemas,
        "source_provenance_audit": provenance, "cli_audit": cli,
        "categories": {c: sum(r["category"] == c for r in records)
                       for c in sorted({r["category"] for r in records})},
        "qualification": "Finite executable evidence; the general theorems are mathematical proofs, not Lean/Rocq formalizations.",
        "certificates": records,
    }
    (ROOT / "certificate_results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "certificates"}, indent=2))


if __name__ == "__main__":
    main()
