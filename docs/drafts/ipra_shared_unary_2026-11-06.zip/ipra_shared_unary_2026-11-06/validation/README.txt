FINITE VALIDATION AND SOURCE CREDITS

Run from any directory:

  python3 /absolute/path/to/package/validation/validate.py
  python3 /absolute/path/to/package/validation/independent_binding.py

All validation code is outside the trusted boundary. checker.py never
imports these files. Both test scripts require only the Python standard
library. Their assert statements are test assertions; the trusted checker
uses explicit require() checks, which are tested under python -O.

WHAT IS TESTED

validate.py regenerates 116 positive and 61 negative finite JSON fixtures.
For constructed positive proofs, named proof formulas determine the target
sequent before candidate inference. The corpus includes formula-amalgamation
endpoints for unlike logical roots, derived conjunction and disjunction,
local dependent contexts, parameterized equation induction, cases on a
quantified formula, nested recursion witnesses, and equality transport
beneath Pi, Ex, and recursion binders. Negative examples target witness
escape, capture, invalid quantifier witnesses even when unused, ill-formed
terms/formulas, malformed proof records/envelopes, and quantified induction.

Every positive passes:

  1. The candidate checker.
  2. reference/unary_checker.py, copied byte-for-byte from the current
     unary-existential archive.
  3. reference/binary_checker.py, copied byte-for-byte from the compact
     checker preserved within that same archive, after independent expansion
     Ex_x A -> Sigma_x(0=0,A).

translate.py uses the original unary checker for its own inference and
canonicalization; it does not import the candidate. The candidate and the
references share a calculus lineage, so agreement is finite differential
evidence, not an independent general soundness proof. The binary reference
has distinct syntax, a distinct proof interface, separate formation and
substitution routines, and an explicit falsity bridge.

The original corpus's Boolean-alias hypothesis key is the one deliberate
interface change. The malformed original is retained byte-for-byte as a
negative. A positive copy uses the actual integer index. All other 175
original fixture files are byte-identical to the supplied draft's output;
the regeneration checks their original SHA-256 hashes.

All 177 fixtures are also run through the candidate command-line interface
under both normal Python and python -O. Four malformed JSON documents are
tried in both modes. There are 362 CLI invocations in total. Separate schema
checks accept equation induction and Pi/Ex cases, and reject induction on
Pi/Ex formulas even when their matrices are equational.

independent_binding.py checks 5000 finite-prefix substitutions on 1000
seeded trees against unique named-variable decoding, free-symbol replacement,
and re-encoding. It implements no de Bruijn substitution walker as an oracle.
validate.py adds 1500 comparisons with the binary reference's callable
substitution routine after syntax translation. Fixed seeds make both
runs reproducible.

PROVENANCE

source_provenance.json records the pinned repository commit, archive identity
and SHA-256, precise archive member paths, original source hashes, and changes.
The two reference checkers and builder.py are verified byte-identical on each
run. upstream_fixture_manifest.json preserves the original per-fixture
hashes and expected acceptance classifications.

The initialized-recursion proof construction, amalgamation certificates,
arithmetic examples, and targeted rejection fixtures are adapted from the
supplied ipra_unary_existential_2026-11-06.zip. Its original comparison
inventory attributes the binary checker to ipra_compact_2026-11-06.zip,
commit 36fb791c722edc2549719744c38feef74fa422fb. The enclosing current archive
was retrieved at commit 9e338a5c51a26ac6ae90f2d8f563a44c3879ba68. The
named-variable substitution oracle is likewise adapted from the unary
archive, with increased tree depth and sample count. The new checker and
this package's reports clearly distinguish inherited mathematics from the
shared-traversal implementation reduction.

RESULTS

certificate_results.json records counts, reference hashes, test categories,
fixture hashes, schema checks, provenance checks, and CLI outcomes.
binding_results.json records the named-variable oracle comparisons.
certificates/ contains all replayable proof/rejection inputs.

These files document finite executable checks. They do not claim a Lean or
Rocq formalization, universal differential equivalence, or a mechanized
metatheorem. The report supplies the mathematical arguments.
