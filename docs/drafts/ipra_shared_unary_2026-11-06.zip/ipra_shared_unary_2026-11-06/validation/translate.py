"""Untrusted unary-to-binary proof expansion with two frozen reference checkers.

The original unary checker first validates the input and canonically erases
public falsity. Ex_x A is expanded to Sigma_x(0=0,A); the expanded proof is
then checked by the unchanged compact binary checker. This module does not
import the candidate checker and is never imported by it.

Adapted from validation/translate.py in the supplied unary-existential draft.
Exact reference-file provenance is in source_provenance.json.
"""

import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


unary = load("reference_unary", ROOT / "reference/unary_checker.py")
old = load("reference_binary", ROOT / "reference/binary_checker.py")
TRUE = ["=", -1, -1]


def syntax(a):
    if type(a) is int:
        return a
    if a[0] == "ex":
        return ["sig", TRUE, syntax(a[1])]
    return [a[0], *(syntax(b) for b in a[1:])]


def reflexivity(t):
    computation = ["rec", ["r", -1, t, -1]]
    return ["use", computation, ["=", 0, old.shift(t)], computation]


def proof(p, g):
    match p:
        case ["hyp", key]:
            return ["hyp", syntax(g[g.index(key)])]
        case ["pi", a, q]:
            return ["pi", syntax(a), proof(q, [*map(unary.subst, g), a])]
        case ["pack", t, q]:
            local = [*map(unary.subst, g), ["=", 0, unary.subst(t)]]
            return ["pair", syntax(t), reflexivity(-1), proof(q, local)]
        case ["use", p, a, q]:
            e = unary.infer(p, g)
            local = [*map(unary.subst, g), *e[1:]] if e[0] == "ex" else g
            return ["use", proof(p, g), syntax(a), proof(q, local)]
        case [("rec" | "nat") as tag, a]:
            return [tag, syntax(a)]
        case _:
            raise ValueError("Unknown proof node in untrusted translation")


def certificate(data):
    unary.check(data)
    g, a, p = unary.erase(data)
    result = {"assumptions": [syntax(b) for b in g],
              "goal": syntax(a), "proof": proof(p, g)}
    old.check(result)
    return result


if __name__ == "__main__":
    import json
    import sys
    if len(sys.argv) not in (2, 3):
        raise SystemExit("usage: translate.py INPUT.json [OUTPUT.json]")
    result = certificate(json.loads(Path(sys.argv[1]).read_text()))
    text = json.dumps(result, separators=(",", ":")) + "\n"
    if len(sys.argv) == 3:
        Path(sys.argv[2]).write_text(text)
    else:
        print(text, end="")
