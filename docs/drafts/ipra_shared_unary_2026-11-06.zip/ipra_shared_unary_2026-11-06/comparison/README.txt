CURRENT-CORPUS SOURCE COMPARISON
==============================

Repository: VladimirReshetnikov/ProveIt
Commit: 9e338a5c51a26ac6ae90f2d8f563a44c3879ba68
Directory: docs/drafts

SCOPE

The current directory contains six ZIP proposals, all dated 2026-11-06.
Their own comparisons refer to an older repository snapshot and quote a
957-token minimum. That old number is not the frontier used here.

This comparison reads all 336 Python members of the six current ZIPs.
It selects the 251 members containing def infer(, def check(, and
__main__, and additionally confirms that each defines infer and check
at top level, imports only json and/or sys, and has no calls to exec,
eval, compile, or __import__. The selected members contain 89 distinct
byte sequences. All 89 are preserved, without editing, in sources/.
Repeated historical copies and repeated controls are not counted as
independent current proposals. They are included as additional concrete
comparison sources so an embedded smaller implementation is not missed.

The six main checker paths are explicit in inventory.json. The single
traversal proposal's complete checker is code/checker.py; its top-level
checker.py is only a wrapper and is not measured in isolation. Sources
that are support modules, tests, generators, translators, or nonstandalone
libraries are outside this particular standalone-program census. The
census is not a claim that every possible grouping of historical library
files has been independently optimized or proved complete.

ORIGINAL BYTES AND PROVENANCE

Before these snapshots were obtained, all six original ZIP byte lengths,
SHA-256 digests, and Git blob SHA-1 identities were checked against
provenance/repository.json. A Git blob digest is SHA-1 of the byte string

  b"blob " + decimal_byte_length + b"\0" + original_file_bytes.

The originals were then read directly from the ZIP archives. Snapshots
retain all original comments, documentation strings, and source spelling.
Their filenames are their SHA-256 digests. inventory.json records each
archive/member occurrence, source digest, snapshot path, and main-checker
status, together with archive summaries and the exact selection rule.

The full original ZIP archives are not duplicated in this package. Their
verified retrieval identities and pinned GitHub URLs are preserved in
provenance/repository.json. Offline measurement needs only the exact
source snapshots included here.

REPRODUCTION

From the package root, using Python 3.12.14 for identical AST output:

  python3 measure.py

The script executes no candidate or baseline checker. It verifies every
snapshot's SHA-256 and byte length, verifies occurrence counts, measures
the six current main programs and all 89 distinct source snapshots, and
measures the current package checker.py. It writes:

  results/metrics.json          Full numerical records and definitions
  results/metrics_macros.tex    Values used by the article
  comparison/current_table.tex Current six-program comparison table

An explicit --candidate PATH can be used to measure another complete
acceptance program during development. The delivered recorded candidate
must be checker.py; rerun without that option after any checker edit.
Optional *.py files in the package controls/ directory are measured in
a separate matched_controls field and never lower the baseline minima.

MEASUREMENTS AND TRUST BOUNDARY

Significant original-source tokens omit Python layout/whitespace tokens,
comments, and standalone constant-string expressions. Effective code
lines are physical source lines occupied by these significant tokens.
Normalized source is produced by deleting standalone constant-string
expressions from the AST, applying ast.unparse, and appending one newline.
Normalized tokens use the same token exclusions. AST nodes count every
ast.walk node in the cleaned tree, including operators and contexts.
Raw bytes count the entire original file, including its documentation.

The entire acceptance file is charged: imports, constructor tables,
validation, arithmetic schema generation, substitution and binding,
proof inference, JSON input, and the CLI. Python and its standard-library
implementation are fixed across the comparison. No local proof generator,
translator, fixture, metric script, or mathematical report is imported by
these acceptance programs.

Current coordinate minima over all selected standalone snapshots are:

  significant original-source tokens     863
  normalized significant tokens          864
  executable AST nodes                   915
  normalized executable UTF-8 bytes     2730
  raw UTF-8 source bytes                3088
  effective source lines                  76

The current six main programs already attain every one of these minima.
The new candidate uses unary existence and accepts explicit public
falsity, as does its direct unary predecessor. Other baselines have
different internal syntax; in particular the reduced-kernel main checker
accepts canonical arithmetic falsity only. The comparison includes that
smaller interface as well. The article gives the mathematical meaning
and adequacy of the candidate's interface, rather than treating an
uncounted translator as trusted code.

These numbers describe a finite implementation frontier in a fixed
language and runtime. They are not absolute shortest-program bounds,
nor do source measurements establish the mathematical correctness of a
baseline or candidate. Written soundness and interpretation arguments
and executable validation are reported separately in the article.

ATTRIBUTION

The 89 files are exact comparison copies of source supplied in the six
ProveIt draft archives. Their original attribution and commentary remain
intact. They are not new kernel implementations in this package.
