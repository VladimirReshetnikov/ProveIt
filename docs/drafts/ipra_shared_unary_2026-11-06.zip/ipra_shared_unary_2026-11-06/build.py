"""Compile the paper and package the already validated source tree."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent


def members():
    return sorted(p for p in ROOT.rglob("*")
                  if p.is_file() and "__pycache__" not in p.parts
                  and p.name != "SHA256SUMS.txt"
                  and p.suffix not in {".pyc", ".aux", ".log", ".out", ".toc"})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package-only", action="store_true")
    args = parser.parse_args()
    if not args.package_only:
        with tempfile.TemporaryDirectory(prefix="ipra-paper-") as temporary:
            directory = Path(temporary)
            for iteration in range(3):
                run = subprocess.run(
                    ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                     "-file-line-error", "-output-directory", str(directory),
                     "report.tex"],
                    cwd=ROOT, text=True, stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT)
                if run.returncode:
                    raise RuntimeError(run.stdout[-12000:])
            log = (directory / "report.log").read_text(errors="replace")
            defects = [line for line in log.splitlines()
                       if "Overfull" in line or "undefined references" in line
                       or ("LaTeX Warning: Citation" in line and "undefined" in line)]
            if defects:
                raise RuntimeError("PDF layout/reference diagnostics:\n" + "\n".join(defects))
            shutil.copy2(directory / "report.pdf", ROOT / "report.pdf")
            summary = {
                "status": "compiled",
                "passes": 3,
                "overfull_boxes": 0,
                "unresolved_references": 0,
                "checker_sha256": hashlib.sha256((ROOT / "checker.py").read_bytes()).hexdigest(),
                "pdf_sha256": hashlib.sha256((ROOT / "report.pdf").read_bytes()).hexdigest(),
                "note": "Visual inspection is recorded separately; this is the compiler check."
            }
            (ROOT / "results" / "build.json").write_text(json.dumps(summary, indent=2) + "\n")
    if not (ROOT / "report.pdf").is_file():
        raise RuntimeError("Compile report.pdf before packaging.")
    files = members()
    hashes = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in files}
    manifest = ROOT / "SHA256SUMS.txt"
    manifest.write_text("".join(value + "  " + name + "\n"
                                for name, value in sorted(hashes.items())))
    archive = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as result:
        for path in files + [manifest]:
            relative = ROOT.name + "/" + path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(relative, (2026, 11, 6, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            result.writestr(info, path.read_bytes())
    with zipfile.ZipFile(archive) as result:
        for name, digest in hashes.items():
            if hashlib.sha256(result.read(ROOT.name + "/" + name)).hexdigest() != digest:
                raise RuntimeError("Archive mismatch: " + name)
        if result.testzip() is not None:
            raise RuntimeError("ZIP integrity failure")
    print(json.dumps({"archive": str(archive), "files": len(files) + 1,
                      "bytes": archive.stat().st_size,
                      "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}, indent=2))


if __name__ == "__main__":
    main()
