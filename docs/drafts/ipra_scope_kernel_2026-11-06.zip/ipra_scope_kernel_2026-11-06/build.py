"""Compile the complete article with pdfLaTeX and check its final log."""
import pathlib
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent


def main():
    build = ROOT / '.build'
    build.mkdir(exist_ok=True)
    command = ['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
               '-output-directory=.build', 'report.tex']
    for _ in range(3):
        run = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
        if run.returncode:
            raise RuntimeError(run.stdout[-12000:] + run.stderr[-2000:])
    log = (build / 'report.log').read_text(errors='replace')
    bad = [line for line in log.splitlines()
           if 'Overfull' in line or 'undefined' in line or 'Rerun to get' in line
           or 'multiply defined' in line]
    if bad:
        raise RuntimeError('\n'.join(bad))
    (ROOT / 'report.pdf').write_bytes((build / 'report.pdf').read_bytes())
    print('PASS: report.pdf compiled with no overflow or unresolved references')


if __name__ == '__main__':
    main()
