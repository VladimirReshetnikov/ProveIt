A SMALLER COMPLETE PRESENTATION OF iPRA
Prepared for Vladimir Reshetnikov -- 6 November 2026 (Pacific time)

RESULT

The supplied complete checkers are strictly below the coordinatewise size
envelope of all 13 current root checkers in the six ProveIt/docs/drafts
archives at commit 5aeafa5bf49f94af475b3a17433d958dc50b0bbf.

                                 Source  Normalized    AST   Normalized   Raw
                                 tokens     tokens   nodes      bytes   bytes
Current complete-program minima     541        543     562       1688    1777
checker.py (strict)                  536        542     557       1678    1750
checker_demand.py (byte scopes)      523        529     542       1658    1734
checker_text_scopes.py (demand)      526        532     545       1633    1709

Both demand variants also beat every current core minimum after imports and
CLI code are removed identically. Their core AST/token/byte counts are
471/466/1364 and 474/469/1339, versus minima 483/474/1376. The strict
companion's core does not beat that envelope; its full-program improvement
also uses the smaller wrapper. Exact normalization uses CPython 3.12.14.

The mathematical basis is inherited from the supplied drafts and credited.
The new contribution is a smaller combination of scope-driven validation,
positive indexing, theorem boundaries, shared premise reconstruction, and
optional erasure of irrelevant universal witnesses, plus the current-corpus
comparison and validation. This is an incremental finite-corpus improvement,
not an absolute minimality theorem or a new foundational arithmetic basis.

MATHEMATICAL CLAIM

The target iPRA convention is full intuitionistic first-order logic with
equality and falsity; fixed primitive-recursive descriptions and their
defining equations; successor injectivity and separation; and induction for
all quantifier-free formulas with parameters, including implication/negation.

The native calculus has only zero/successor/initialized recursion as numerical
constructors and equality/guarded universal/existential as formula constructors.
The article gives every primitive logical rule and arithmetic schema. It
derives full intuitionistic logic, equation induction, numerical coverage,
and all quantifier-free induction instances.

The native calculus faithfully presents an ordinary first-order theory
T_cov. T_cov and the stated iPRA are bi-interpretable on their entire number
domains. Internal uniqueness for each fixed recursion proves that equality
x=y defines both composite isomorphisms. Contradiction is preserved in both
directions, giving equiconsistency. A bare atomic-induction-only presentation
without coverage is not silently identified with this target.

START HERE

  report.pdf                 Complete mathematical and implementation article.
  report.tex, sections/      All LaTeX sources.
  checker.py                 Strict standalone theorem checker.
  checker_demand.py          Smallest AST/token checker.
  checker_text_scopes.py     Smallest normalized/raw-byte checker.
  FORMAT.txt                 Exact grammar, certificate order, and API contract.
  examples/                  Nineteen ready-to-run theorem certificates.
  canonicalize.py            Demand-to-strict proof reconstruction, checked output.
  comparison/               All 13 unchanged comparators and pinned provenance.
  validation/               Independent named-binder oracle and frozen proof corpus.
  results/                  Executed measurements and verification records.
  measure.py                Full-program and core-only measurement.
  reproduce.py              Reproduce all audits, measurements, and examples.
  build.py                  Rebuild the PDF with pdfLaTeX.
  package.py                Recreate checksums and the ZIP.
  MANIFEST.sha256            Hashes of all other delivered files.
  LICENSE_SOURCE.txt         License for inherited material.

RUN

  python3 reproduce.py
  python3 checker.py examples/reflexivity.json
  python3 checker_demand.py examples/residual.json
  python3 checker_text_scopes.py examples/closed_automatic_collision.json

Public input is exactly [goal,proof]. The initial context is empty. Free
number parameters are permitted. Success prints ACCEPT and exits zero;
failure or an exception prints REJECT and exits nonzero. See FORMAT.txt.

The strict program checks every witness used by an active inference, including
vacuous universal witnesses. The demand programs may ignore a malformed
annotation only when neither universal matrix uses its distinguished number.
Replacing an irrelevant annotation with zero gives a strict certificate.

  python3 canonicalize.py examples/reflexivity.json strict_proof.json

The independent oracle and conversion tools are not imported by any acceptance
program. They may be deleted without changing the checked theory.

EXECUTED EVIDENCE

For each of three candidates: 130 curated cases; 11 malformed-context boundary
cases; 150 inherited records (125 theorem records, 30 distinct translated
theorem certificates); 96 formation cases; 384 substitutions compared with
named binders; 160 seeded mutations; and 222 real CLI runs including -O and
encoding/argument failures. Zero failures. Accepted cases were reconstructed
into an unchanged strict predecessor: 229 strict cases and 241 for each demand
variant. The 12 extra demand accepts are intended unused-witness cases.
The nineteen delivered examples also pass every checker.

These finite groups overlap. They complement the written proofs and are not
a Lean/Rocq formalization, exhaustive proof enumeration, or internal proof of
the theory's own consistency.

REBUILD

Python 3.10+ and the standard library suffice for code artifacts; CPython
3.12.14 reproduces the exact recorded AST-normalization numbers. Rebuilding
the PDF requires pdfLaTeX and the packages listed in report.tex.

  python3 build.py
  python3 package.py

No network is required. The PDF was rendered and visually checked. Source
comparators and archive identities are pinned; live repository changes do
not alter this comparison. No repository publication is part of this package.
