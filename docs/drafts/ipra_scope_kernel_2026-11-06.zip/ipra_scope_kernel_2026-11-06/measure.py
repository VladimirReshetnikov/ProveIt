"""Reproduce the complete-program and core-only comparison, offline."""
import ast
import csv
import hashlib
import io
import json
import platform
import tokenize
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FIELDS = ('source_tokens', 'normalized_tokens', 'ast_nodes', 'normalized_bytes', 'raw_bytes')
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
CANDIDATES = ('checker.py', 'checker_demand.py', 'checker_text_scopes.py')


def count_tokens(source, spans=()):
    return sum(t.type not in IGNORED and not any(a <= t.start and t.end <= b for a, b in spans)
               for t in tokenize.generate_tokens(io.StringIO(source).readline))


def measure(path):
    raw = path.read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if (isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef))
                and node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            doc = node.body.pop(0)
            spans.append(((doc.lineno, doc.col_offset), (doc.end_lineno, doc.end_col_offset)))
    normalized = ast.unparse(tree) + '\n'
    result = dict(source=str(path.relative_to(ROOT)), sha256=hashlib.sha256(raw).hexdigest(),
                  source_tokens=count_tokens(source, spans),
                  normalized_tokens=count_tokens(normalized),
                  ast_nodes=sum(1 for _ in ast.walk(tree)),
                  normalized_bytes=len(normalized.encode()), raw_bytes=len(raw))
    # Every source uses imports followed by declarations and a single CLI guard.
    # Removing all top-level Import/ImportFrom/If nodes is identical for all files.
    tree.body = [n for n in tree.body if not isinstance(n, (ast.Import, ast.ImportFrom, ast.If))]
    core = ast.unparse(tree) + '\n'
    result['core'] = dict(normalized_tokens=count_tokens(core),
                          ast_nodes=sum(1 for _ in ast.walk(tree)),
                          normalized_bytes=len(core.encode()))
    return result


def label(path):
    family, filename = Path(path).parts[-2:]
    names = {'ipra_arity_calculus_2026-11-06': 'Arity calculus',
             'ipra_automatic_goal_kernel_2026-11-06': 'Automatic goal',
             'ipra_goal_only_2026-11-06': 'Goal only',
             'ipra_implicit_certificates_2026-11-06': 'Implicit certificates',
             'ipra_shared_introduction_2026-11-06': 'Shared introduction',
             'ipra_structural_kernel_2026-11-06': 'Structural kernel'}
    variant = {'checker.py': 'strict', 'checker_demand.py': 'demand',
               'checker_open.py': 'open strict', 'checker_open_demand.py': 'open demand'}[filename]
    return names[family] + ': ' + variant


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    baselines = []
    for item in manifest['baselines']:
        row = measure(ROOT / item['frozen_source'])
        if row['sha256'] != item['source_sha256']:
            raise ValueError('Frozen baseline changed: ' + item['frozen_source'])
        row['label'] = label(row['source'])
        baselines.append(row)
    candidates = [measure(ROOT / name) for name in CANDIDATES]
    envelope = {k: min(r[k] for r in baselines) for k in FIELDS}
    core_envelope = {k: min(r['core'][k] for r in baselines) for k in candidates[0]['core']}
    result = dict(python=platform.python_version(), repository=manifest['repository'],
                  commit=manifest['commit'], archive_count=len(manifest['archives']),
                  baseline_count=len(baselines), baselines=baselines, candidates=candidates,
                  coordinatewise_minimum=envelope, core_coordinatewise_minimum=core_envelope,
                  complete_boundary='All theory-specific source, syntax, scopes, substitution, rules, JSON reader, CLI, and failure handling. Only the common Python runtime and json/sys implementations are external.',
                  normalization='Remove actual docstrings; count significant tokens; ast.unparse plus a final newline; count every remaining AST node.',
                  core_boundary='Remove imports and the top-level CLI conditional identically from every parsed source.',
                  strictly_below={r['source']: {k: r[k] < envelope[k] for k in FIELDS} for r in candidates},
                  core_strictly_below={r['source']: {k: r['core'][k] < core_envelope[k] for k in core_envelope} for r in candidates})
    results = ROOT / 'results'
    results.mkdir(exist_ok=True)
    (results / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    with (results / 'metrics.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, ['source', 'sha256', *FIELDS], extrasaction='ignore')
        writer.writeheader()
        writer.writerows([*baselines, *candidates])
    table = [r'\begin{tabular}{lrrrrr}', r'\toprule',
             r'Current complete program & Source & Norm. & AST & Norm. & Raw\\',
             r'& tokens & tokens & nodes & bytes & bytes\\', r'\midrule']
    for row in baselines:
        table.append(row['label'] + ' & ' + ' & '.join(str(row[k]) for k in FIELDS) + r' \\')
    table += [r'\bottomrule', r'\end{tabular}']
    (results / 'baseline_table.tex').write_text('\n'.join(table) + '\n')
    macros = []
    for prefix, data in [('Old', envelope), ('Strict', candidates[0]),
                         ('Demand', candidates[1]), ('Text', candidates[2])]:
        for field, suffix in [('source_tokens', 'Source'), ('normalized_tokens', 'Tokens'),
                              ('ast_nodes', 'AST'), ('normalized_bytes', 'Bytes'), ('raw_bytes', 'Raw')]:
            macros.append('\\newcommand{\\' + prefix + suffix + '}{' + str(data[field]) + '}')
    (results / 'metrics.tex').write_text('\n'.join(macros) + '\n')
    if not all(all(flags.values()) for flags in result['strictly_below'].values()):
        raise ValueError('A delivered checker no longer beats the complete-program envelope')
    print(json.dumps({'status': 'PASS', 'python': result['python'], 'envelope': envelope,
                      'candidates': candidates, 'core_envelope': core_envelope,
                      'core_strictly_below': result['core_strictly_below']}, indent=2))
    return result


if __name__ == '__main__':
    main()
