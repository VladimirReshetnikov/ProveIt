"""Reproduce measurements, independent checks, and delivered examples offline."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(arguments):
    proc = subprocess.run([sys.executable, *arguments], cwd=ROOT, text=True,
                          capture_output=True)
    if proc.returncode:
        raise RuntimeError(proc.stdout + proc.stderr)
    return proc.stdout


def main():
    (ROOT / 'results').mkdir(exist_ok=True)
    run(['measure.py'])
    audits = {}
    for name, policy in [('checker.py', 'strict'), ('checker_demand.py', 'demand'),
                         ('checker_text_scopes.py', 'demand')]:
        output = 'results/' + Path(name).stem + '_validation.json'
        summary = json.loads(run(['validation/verify.py', name, '--policy', policy,
                                  '--binary-json', '--output', output]))
        audits[name] = summary
        print(name + ': independent audit ' + summary['status'], flush=True)
    examples = json.loads((ROOT / 'examples/provenance.json').read_text())
    for row in examples:
        path = ROOT / 'examples' / row['file']
        if hashlib.sha256(path.read_bytes()).hexdigest() != row['sha256']:
            raise ValueError('Changed example: ' + row['file'])
        for name in audits:
            if run([name, str(path)]).strip() != 'ACCEPT':
                raise ValueError('Example failed: ' + row['file'])
    result = {'status': 'PASS', 'audits': audits, 'example_count': len(examples),
              'example_cli_checks': len(examples) * len(audits),
              'qualification': 'Finite audits support the written metatheory; no formalized metatheorem is claimed.'}
    (ROOT / 'results/reproduction.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
