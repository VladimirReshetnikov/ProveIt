"""Create a deterministic archive and a manifest of all delivered members."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent


def files():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and not any(x.startswith('.') or x == '__pycache__'
                              for x in p.relative_to(ROOT).parts)
                  and p.suffix != '.pyc' and p.name != 'MANIFEST.sha256')


def main():
    manifest = ROOT / 'MANIFEST.sha256'
    manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  '
                                + p.relative_to(ROOT).as_posix() + '\n' for p in files()))
    archive = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted([*files(), manifest]):
            info = zipfile.ZipInfo(ROOT.name + '/' + p.relative_to(ROOT).as_posix(),
                                   date_time=(2026, 11, 6, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            z.writestr(info, p.read_bytes())
    print(archive)
    print(hashlib.sha256(archive.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
