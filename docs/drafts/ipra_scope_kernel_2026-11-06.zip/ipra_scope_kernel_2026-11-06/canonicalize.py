"""Untrusted conversion of a demand certificate into a strict certificate.

Every output is checked by the standalone strict kernel before being written.
The input and output theorem formulas are identical.
"""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'validation'))
sys.path.insert(0, str(ROOT / 'validation/support'))
import checker
import checker_demand
from demand_oracle import reconstruct, shift_codes


def main():
    _, source, destination = sys.argv
    with open(source, 'rb') as stream:
        payload = json.load(stream)
    if type(payload) is not list or len(payload) != 2:
        raise ValueError('Expected [goal, proof]')
    a, p = payload
    if not checker_demand.check(a, p, []):
        raise ValueError('Demand checker rejected input')
    okay, proof = reconstruct(shift_codes(a, -1), shift_codes(p, -1), [])
    if not okay:
        raise ValueError('Reconstruction failed')
    proof = shift_codes(proof, 1)
    if not checker.check(a, proof, []):
        raise ValueError('Strict checker rejected reconstruction')
    Path(destination).write_text(json.dumps([a, proof], indent=2) + '\n')
    print('ACCEPT: strict certificate written')


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('REJECT: ' + str(error))
        sys.exit(1)
