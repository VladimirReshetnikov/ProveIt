"""Measure all 13 current programs and candidates, with and without I/O.

Core comparison removes only top-level imports and the __main__ CLI block,
identically for every program. All application-specific formation data,
substitution, context handling, and inference checking remain. Leading
docstrings, comments, and formatting tokens are omitted in both comparisons.
This is a finite source comparison, not an absolute minimality theorem.
"""
import argparse
import ast
import copy
import hashlib
import io
import json
from pathlib import Path
import sys
import tokenize

ROOT = Path(__file__).resolve().parent
FIELDS = ("source_tokens", "normalized_tokens", "ast_nodes", "normalized_bytes")
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}


def is_main(node):
    if not isinstance(node, ast.If):
        return False
    test = node.test
    return (isinstance(test, ast.Compare) and isinstance(test.left, ast.Name)
            and test.left.id == "__name__" and len(test.ops) == 1
            and isinstance(test.ops[0], ast.Eq) and len(test.comparators) == 1
            and isinstance(test.comparators[0], ast.Constant)
            and test.comparators[0].value == "__main__")


def measure(path, core=False):
    raw = path.read_bytes()
    source = raw.decode("utf-8")
    tree = ast.parse(source)
    omitted = []

    def omit(node):
        omitted.append(((node.lineno, node.col_offset), (node.end_lineno, node.end_col_offset)))

    for node in ast.walk(tree):
        if (isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
                and node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            omit(node.body.pop(0))
    if core:
        main_blocks = sum(is_main(node) for node in tree.body)
        if main_blocks != 1:
            raise ValueError("Expected exactly one CLI block: " + str(path))
        kept = []
        for node in tree.body:
            if isinstance(node, (ast.Import, ast.ImportFrom)) or is_main(node):
                omit(node)
            else:
                kept.append(node)
        tree.body = kept
    normal = ast.unparse(tree) + "\n"

    def count(text, spans=()):
        return sum(tok.type not in IGNORED
                   and not any(start <= tok.start and tok.end <= end for start, end in spans)
                   for tok in tokenize.generate_tokens(io.StringIO(text).readline))

    return {"source_tokens": count(source, omitted),
            "normalized_tokens": count(normal),
            "ast_nodes": sum(1 for _ in ast.walk(tree)),
            "normalized_bytes": len(normal.encode("utf-8"))}


def main(candidates):
    baselines = []
    for row in json.loads((ROOT / "baseline_programs.json").read_text()):
        path = ROOT / row["frozen"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != row["sha256"]:
            raise ValueError("Changed frozen baseline: " + row["frozen"])
        baselines.append({**row, "full": measure(path), "core": measure(path, True)})
    envelopes = {scope: {key: min(row[scope][key] for row in baselines) for key in FIELDS}
                 for scope in ("full", "core")}
    compared = []
    for path in candidates:
        item = {"source": path.name, "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                "full": measure(path), "core": measure(path, True)}
        item["strictly_below"] = {
            scope: {key: item[scope][key] < envelopes[scope][key] for key in FIELDS}
            for scope in ("full", "core")}
        compared.append(item)
    result = {"repository_sha": "5aeafa5bf49f94af475b3a17433d958dc50b0bbf",
              "python": sys.version, "baseline_programs": len(baselines),
              "core_boundary": "Remove only top-level imports and __main__ CLI, identically for every source.",
              "baselines": baselines, "envelopes": envelopes, "candidates": compared}
    (ROOT / "results/core_metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"envelopes": envelopes, "candidates": compared}, indent=2))
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("candidates", nargs="+", type=Path)
    main(parser.parse_args().candidates)
