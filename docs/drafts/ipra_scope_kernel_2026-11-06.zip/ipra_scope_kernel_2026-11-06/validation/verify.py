"""Independent finite verification of a positive-index theorem checker.

Run: python3 validation/verify.py checker_demand.py --binary-json

The oracle resolves indices to named binders; it never calls the candidate's
formation/substitution/proof routines. Accepted demand proofs are reconstructed
and rechecked by an unchanged strict predecessor. The public command-line
boundary, including Python -O, is tested in isolated processes. This is finite
evidence accompanying a paper proof, not a formalized metatheorem.
"""
import argparse
from collections import Counter
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / "support"))
from named_oracle import valid, oracle, term, formula
from rule_oracle import accepted as strict_oracle
from cases import direct_cases, node_paths, replace_at, reflexivity, TRUTH, FALSE
from demand_oracle import accepted, reconstruct, reencode, shift_codes


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def run(candidate, policy="demand", binary_json=False, output=None):
    candidate = candidate.resolve()
    original_bytes = candidate.read_bytes()
    target = load(candidate, "candidate_under_audit")
    baseline_path = ROOT / "sources/ipra_structural_kernel_2026-11-06__checker.py"
    strict = load(baseline_path, "unchanged_strict_predecessor")
    failures, results = [], {}
    rules = Counter()
    reconstruction_count = 0

    provenance = json.loads((ROOT / "provenance.json").read_text())
    for row in provenance["files"]:
        if hashlib.sha256((ROOT / row["frozen"]).read_bytes()).hexdigest() != row["sha256"]:
            raise ValueError("Modified frozen source: " + row["frozen"])
    results["frozen_sources_verified"] = len(provenance["files"])

    def target_core(a, p, g=()):
        # Internal check has a well-formed-context precondition. The only
        # public context is empty; arbitrary user contexts are tested at CLI.
        try:
            return bool(target.check(shift_codes(a, 1), shift_codes(p, 1),
                                     shift_codes(list(g), 1)))
        except Exception:
            return False

    def compare(label, a, p, g=(), stipulated=None):
        nonlocal reconstruction_count
        if not all(valid(h, True) for h in g):
            raise ValueError("Core test violates the documented context precondition")
        expected = (strict_oracle(a, p, g, rules) if policy == "strict"
                    else accepted(a, p, g, rules))
        observed = target_core(a, p, g)
        if expected != observed or (stipulated is not None and expected != stipulated):
            failures.append({"group": "independent_rule_comparison", "label": label,
                             "expected": expected, "target": observed,
                             "stipulated": stipulated, "input": [a, p, list(g)]})
        if expected and observed:
            good, canonical = reconstruct(a, p, g)
            assert good
            sanitized = shift_codes(canonical, 1)
            try:
                passed = (strict_oracle(a, canonical, g)
                          and strict.check(shift_codes(a, 1), sanitized,
                                           shift_codes(list(g), 1)))
            except Exception:
                passed = False
            reconstruction_count += 1
            if not passed:
                failures.append({"group": "strict_reconstruction", "label": label})
        return expected, observed

    # Independently stipulated direct rules, binder conditions, and invalid
    # grammar. Invalid external contexts are a public-interface test instead.
    curated, invalid_contexts = [], []
    for label, a, p, g, expected in direct_cases(ROOT / "support"):
        if not all(valid(h, True) for h in g):
            invalid_contexts.append((label, a, p, g))
            continue
        if policy == "demand" and label.startswith("unused_universal_witness_"):
            expected = True
        actual, observed = compare(label, a, p, g, expected)
        curated.append({"label": label, "expected": actual, "target": observed})
    results["curated"] = curated

    # Every supplied root example, plus the two explicit source/example
    # collections, is checked at its frozen origin, independently translated,
    # and accepted in the target. The theorem subset also supplies CLI tests.
    inherited = json.loads(gzip.decompress((ROOT / "inherited_corpus.json.gz").read_bytes()))
    sources = {}
    inherited_rows, theorem_documents = [], {}
    for i, row in enumerate(inherited):
        source = sources.setdefault(row["checker"], load(ROOT / row["checker"], "source_" + str(i)))
        a, p, g = row["goal"], row["proof"], row["context"]
        try:
            for h in g:
                source.subst(h)
            origin = bool(source.check(a, p, *g) if row["varargs_context"]
                          else source.check(a, p, g))
        except Exception:
            origin = False
        if not origin:
            failures.append({"group": "source_example", "source": row["source"]})
            continue
        if not row["negative_coordinates"]:
            a, p, g = shift_codes([a, p, g], -1)
        new_proof = reencode(a, p, g, row["marker"], row["tagged"])
        expected, observed = compare("inherited_" + str(i), a, new_proof, g, True)
        data = shift_codes([a, new_proof], 1)
        if not g:
            theorem_documents[digest(data)] = data
        inherited_rows.append({"source": row["source"], "open_assumptions": len(g),
                               "origin": origin, "oracle": expected, "target": observed,
                               "translated_sha256": digest([a, new_proof, g])})
    results["inherited"] = inherited_rows

    # Formation covers malformed constructor types, non-integers, wrong arity,
    # and malformed dormant updates as well as nested valid expressions.
    bad_atoms = [True, False, None, -2, -1.0, 0.0, {}, [], "", "s", "r", ["s"],
                 ["s", -1, -1], ["r", -1, -1], ["pi", TRUTH], ["ex", TRUTH, TRUTH]]
    formation_samples = [(x, False) for x in bad_atoms]
    formation_samples += [(["=", x, -1], True) for x in bad_atoms]
    formation_samples += [(["r", -1, -1, x], False) for x in bad_atoms]
    formation_samples += [(x, True) for x in bad_atoms]
    rng = random.Random(0xD3A4D)
    formation_samples += [(formula(rng, 3), True) for _ in range(16)]
    formation_samples += [(term(rng, 4), False) for _ in range(16)]
    formation_rows = []
    for a, is_formula in formation_samples:
        expected = valid(a, is_formula)
        try:
            out = target.subst(shift_codes(a, 1), formula=is_formula)
            observed = True
            if not valid(shift_codes(out, -1), is_formula):
                failures.append({"group": "invalid_substitution_result", "input": a})
        except Exception:
            observed = False
        if observed != expected:
            failures.append({"group": "formation", "input": a, "formula": is_formula,
                             "expected": expected, "target": observed})
        formation_rows.append({"sha256": digest([a, is_formula]), "expected": expected,
                               "target": observed})
    results["formation"] = formation_rows

    # Capture-sensitive comparison via named binders, including two-variable
    # recursor updates nested in formulas and protected ambient depths.
    envs = [(1,), (0,), [-1, 0], [["s", 0], 0], [2, -1],
            [["r", ["s", 1], 0, 2], -1],
            [0, ["s", 1], -2], [["r", 0, 1, ["s", 2]], 3, -2]]
    fixed = [
        (["r", 2, 0, ["r", ["s", 1], 4, ["s", 5]]], False),
        (["pi", ["=", 0, 1], ["ex", ["=", ["r", 1, 2, ["r", 0, 4, 6]], 3]]], True),
        (["=", ["r", 0, 1, ["r", 2, 3, ["s", 4]]], 2], True),
        (["r", ["s", 2], ["r", 1, 0, 3], ["r", 1, 2, ["r", 4, 5, 6]]], False),
    ]
    samples = fixed + [(formula(rng, 4), True) if i % 2 == 0 else (term(rng, 5), False)
                       for i in range(44)]
    substitution_count = 0
    for i, (a, is_formula) in enumerate(samples):
        depth = i % 5
        for env in envs:
            positive_env = [*[shift_codes(x, 1) for x in env[:-1]], env[-1]]
            expected = shift_codes(oracle(a, env, depth, is_formula), 1)
            observed = target.subst(shift_codes(a, 1), positive_env, depth, is_formula)
            substitution_count += 1
            if observed != expected:
                failures.append({"group": "named_substitution", "sample": i,
                                 "depth": depth, "env": env, "input": a,
                                 "expected": expected, "target": observed})
    results["named_substitution_comparisons"] = substitution_count

    # A bounded mutation set detects altered dispatch/arity/binder-sensitive
    # leaves. The independent oracle chooses each result; there is no claim
    # that this samples all certificates or proves a universal theorem.
    seeds = [(a, p, g) for _, a, p, g, expected in direct_cases(ROOT / "support")
             if expected and all(valid(h, True) for h in g)
             and len(json.dumps([a, p, g])) < 2500]
    replacements = [None, True, False, -2, -1.0, -1, 0, 1, [], {}, "r", ["s", -1],
                    ["ex", ["=", 0, -1]], ["pi", TRUTH, TRUTH]]
    mutation_rows = []
    seen = set()
    while len(mutation_rows) < 160:
        a, p, g = rng.choice(seeds)
        altered = replace_at([a, p], rng.choice(list(node_paths([a, p]))), rng.choice(replacements))
        if type(altered) is not list or len(altered) != 2:
            continue
        key = digest([altered, g])
        if key in seen:
            continue
        seen.add(key)
        expected, observed = compare("mutation_" + str(len(mutation_rows)), *altered, g)
        mutation_rows.append({"sha256": key, "oracle": expected, "target": observed})
    results["mutations"] = mutation_rows

    # Explicit theorem forms exercise witness demand at the actual public
    # boundary, including witnesses used only by a guard or only by a body.
    vacuous = ["pi", TRUTH, TRUTH]
    pi_uses_guard = ["pi", ["=", 0, 0], TRUTH]
    pi_uses_body = ["pi", TRUTH, ["=", 0, 0]]
    bad_witnesses = [True, -1.0, None, {}, -2, ["s", -1, -1]]
    semantic_cli = []
    for i, witness in enumerate(bad_witnesses):
        tests = [
            ("unused_witness_%d" % i, TRUTH,
             [vacuous, [None], witness, reflexivity(-1)], policy == "demand"),
            ("guard_used_witness_%d" % i, TRUTH,
             [pi_uses_guard, [reflexivity(-1)], witness, reflexivity(-1)], False),
            ("body_used_witness_%d" % i, TRUTH,
             [pi_uses_body, [reflexivity(["s", 0])], witness, reflexivity(-1)], False),
            ("existential_witness_%d" % i, ["ex", TRUTH],
             [witness, reflexivity(-1)], False),
        ]
        for label, a, p, expectation in tests:
            compare(label, a, p, (), expectation)
            semantic_cli.append((label, shift_codes([a, p], 1), expectation))
    semantic_cli += [
        ("ignored_hypothesis_payload", shift_codes([vacuous, [{"unused": True}]], 1), True),
        ("unproved_contradiction", shift_codes([FALSE, None], 1), False),
        ("malformed_equality_motive", shift_codes([TRUTH,
            [TRUTH, reflexivity(-1), ["=", True, -1], reflexivity(-1)]], 1), False),
    ]

    good = shift_codes([TRUTH, reflexivity(-1)], 1)
    raw_cases = [("valid_truth", json.dumps(good), True)]
    top_values = [None, True, False, 0, 1, -1, 0.0, {}, {"goal": good[0]}, "", "xx", [],
                  [good[0]], [*good, []], [*good, [["=", 0, ["s", 0]]]],
                  [*good, None], [*good, [], None]]
    raw_cases += [("public_shape_%02d" % i, json.dumps(x), False) for i, x in enumerate(top_values)]
    for i, bad in enumerate([True, False, None, -1, 0.0, -0.0, {}, "s", ["s"],
                              ["s", 0, 0], ["r", 0, 0], ["r", 0, 0, {}]]):
        raw_cases.append(("public_bad_term_%02d" % i, json.dumps([["=", bad, 0], "r"]), False))
    raw_cases += [("raw_%02d" % i, raw, False) for i, raw in enumerate(
        ["", "[", "[1,]", "[0,0] trailing", "{\"x\":0,\"x\":1}",
         "[[\"=\",NaN,0],null]", "[[\"=\",Infinity,0],null]"])]
    raw_cases.append(("invalid_encoding", b"\xff\x80\xfe", False))
    for encoding in ("utf-16", "utf-32"):
        raw_cases.append(("json_" + encoding, json.dumps(good).encode(encoding), binary_json))
    raw_cases += [(label, json.dumps(doc), expected) for label, doc, expected in semantic_cli]
    for label, a, p, g in invalid_contexts:
        raw_cases.append((label, json.dumps(shift_codes([a, p, g], 1)), False))
    for i, data in enumerate(theorem_documents.values()):
        raw_cases.append(("inherited_distinct_theorem_%03d" % i, json.dumps(data), True))

    cli_rows = []
    with tempfile.TemporaryDirectory(prefix="ipra-public-") as temporary:
        path = Path(temporary) / "input.json"
        for label, raw, expectation in raw_cases:
            if isinstance(raw, bytes):
                path.write_bytes(raw)
            else:
                path.write_text(raw)
            for optimized in (False, True):
                args = [sys.executable, *( ["-O"] if optimized else []), str(candidate), str(path)]
                proc = subprocess.run(args, capture_output=True, text=True, timeout=20)
                accepted_cli = proc.returncode == 0 and proc.stdout.strip() == "ACCEPT"
                rejected_cli = proc.returncode != 0 and proc.stdout.strip() == "REJECT"
                passed = accepted_cli if expectation else rejected_cli
                cli_rows.append({"label": label, "optimized": optimized,
                                 "expected": expectation, "returncode": proc.returncode,
                                 "stdout": proc.stdout.strip(), "passed": passed})
                if not passed:
                    failures.append({"group": "public_cli", "label": label,
                                     "optimized": optimized, "expected": expectation,
                                     "returncode": proc.returncode, "stdout": proc.stdout,
                                     "stderr": proc.stderr})
        for label, extras in (("missing_argument", []), ("extra_argument", [str(path), str(path)]),
                              ("missing_file", [str(Path(temporary) / "absent.json")])):
            for optimized in (False, True):
                proc = subprocess.run([sys.executable, *(["-O"] if optimized else []),
                                       str(candidate), *extras], capture_output=True, text=True, timeout=10)
                passed = proc.returncode != 0 and proc.stdout.strip() == "REJECT"
                cli_rows.append({"label": label, "optimized": optimized,
                                 "expected": False, "returncode": proc.returncode,
                                 "stdout": proc.stdout.strip(), "passed": passed})
                if not passed:
                    failures.append({"group": "public_cli_arguments", "label": label})
    results["cli"] = cli_rows
    results["strict_reconstructions"] = reconstruction_count
    results["rule_activity"] = dict(rules)
    results["summary"] = {
        "curated_cases": len(curated),
        "malformed_context_boundary_cases": len(invalid_contexts),
        "inherited_records": len(inherited_rows),
        "inherited_theorem_records": sum(row["open_assumptions"] == 0 for row in inherited_rows),
        "distinct_inherited_theorem_certificates": len(theorem_documents),
        "formation_cases": len(formation_rows),
        "named_substitution_comparisons": substitution_count,
        "mutations": len(mutation_rows),
        "cli_runs": len(cli_rows),
        "strict_reconstructions": reconstruction_count,
        "failures": len(failures),
    }
    results.update({"status": "passed" if not failures else "failed",
                    "candidate": str(candidate.relative_to(ROOT.parent)) if candidate.is_relative_to(ROOT.parent) else str(candidate), "candidate_sha256": hashlib.sha256(original_bytes).hexdigest(),
                    "witness_policy": policy, "binary_json_reader": binary_json,
                    "python": sys.version, "failures": failures,
                    "qualification": "Finite independent checks; paper metatheory is not machine formalized."})
    if candidate.read_bytes() != original_bytes:
        raise ValueError("Candidate changed during audit")
    output = output or ROOT / "results" / (candidate.stem + ".json")
    output.write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps({"status": results["status"], **results["summary"],
                      "candidate_sha256": results["candidate_sha256"]}, indent=2))
    if failures:
        raise SystemExit(1)
    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("candidate", nargs="?", type=Path, default=ROOT.parent / "checker_demand.py")
    parser.add_argument("--policy", choices=("strict", "demand"), default="demand")
    parser.add_argument("--binary-json", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    run(args.candidate, args.policy, args.binary_json, args.output)
