INDEPENDENT CHECKER VERIFICATION
===============================

This directory is untrusted verification support. No candidate acceptance
program imports it. It may be relocated intact alongside the chosen checker.
All verification uses only Python's standard library and needs no network.

Run a demand-policy theorem checker with binary JSON input:

    python3 validation/verify.py checker_demand.py --binary-json

Run a strict-witness theorem checker:

    python3 validation/verify.py checker.py --policy strict --binary-json

Omit --binary-json for the earlier UTF-8 text-reader prototype. The flag sets
the expected outcome of UTF-16/UTF-32 JSON boundary tests; it does not change
the checker or its proof syntax. The target uses positive de Bruijn indices
and zero=0; the independent oracle uses distinct named binders internally.
Its input convention is zero=-1, so the harness performs the explicit
integer-code change while preserving Booleans and floating-point payloads.

By default, reports go to results/<candidate-stem>.json. --output PATH can
select another report destination. A failed comparison exits nonzero.

WHAT IS CHECKED

- 130 curated rule/formation/binding cases from the independent draft audit;
- 11 malformed external-context cases at the theorem-only public boundary;
- all 150 supplied example records across the six current archives and their
  two explicitly supplied source-example collections (125 theorem records);
- 30 distinct translated inherited theorem certificates through the CLI;
- 96 positive and negative grammar samples;
- 384 substitutions compared with a named-binder oracle, including nested
  recursors whose updates bind two distinct variables;
- 160 seeded mutations of small rule certificates;
- 222 isolated CLI executions per new binary-reader variant, equally split
  between normal and optimized (-O) Python;
- reconstruction of each accepted rule/corpus/mutation case into an unchanged
  strict predecessor, with every ignored universal witness replaced by zero.

The original text-reader prototype's earlier report has 216 CLI runs; the
current harness adds invalid-encoding and UTF-16/UTF-32 cases. The groups
overlap and must not be added as counts of distinct mathematical theorems.

The strict candidate reconstructed 229 accepted cases. Each demand candidate
reconstructed 241, the extra 12 being the deliberately malformed but unused
universal-witness cases. Those extra acceptances preserve the proved sequent:
the independent named-binder oracle verifies that the witness occurs in
neither guard nor consequent, and replaces it with the well-formed zero term.

INDEPENDENCE AND PUBLIC CONTRACT

support/named_oracle.py validates syntax with a separate grammar, assigns
distinct identities to all binders, substitutes only named free variables,
then reconstructs indices. It does not call candidate functions. The rule
oracle reads the inference rules using that substitution implementation.
demand_oracle.py adds demand policy and reconstructs strict proofs. Every
accepted reconstructed proof is checked by both the strict independent
oracle and the unchanged structural predecessor in sources/.

The candidate check(a,p,g) core assumes g already contains well-formed
formulas. The public theorem CLI admits exactly [goal,proof] and supplies an
empty context. Internal context additions are separately checked by rule and
binding cases. Invalid external contexts are tested by passing a forbidden
third field to the CLI, rather than pretending the core has a public context
validation contract. Every public formula, active existential witness, used
universal witness, and equality motive is tested for formation.

The source-example corpus preserves original proofs and their provenance.
Each source proof is accepted by its unchanged frozen checker before its
marker/index conversion is independently recomputed. Historical source
examples contribute tests only; they are not counted as current comparator
programs in the size measurements.

MEASUREMENT

    python3 validation/core_metrics.py checker.py checker_demand.py checker_text_scopes.py

baseline_programs.json fixes all 13 root acceptance programs from the six
archives at repository commit 5aeafa5bf49f94af475b3a17433d958dc50b0bbf.
core_metrics.py measures entire programs and also removes imports and each
__main__ block identically. Formation data, substitution, context handling,
and all inference checking remain in the core comparison. Source hashes
are verified before measurement. Results go to results/core_metrics.json.

In the executed comparison, both demand variants beat every current
coordinate minimum even after I/O removal. The strict string-table variant
beats the full-program envelope, but its core does not beat the envelope
that includes all existing demand-policy programs. Do not omit this
distinction when presenting the measurements.

CORPUS PROVENANCE

The compact corpus retains original inputs and source-checker identities.
All required source checkers and independent support are frozen locally,
with origins and hashes in provenance.json. Verification requires no
external reference directory or network. Inherited material retains
LICENSE_SOURCE.txt.

LIMITATION

All these are finite implementation checks. They support the written
soundness, completeness, and bi-interpretation proofs; they are not a Lean,
Rocq, or other machine-checked proof of those universal metatheorems, an
internal consistency proof, or an absolute checker-minimality theorem.
