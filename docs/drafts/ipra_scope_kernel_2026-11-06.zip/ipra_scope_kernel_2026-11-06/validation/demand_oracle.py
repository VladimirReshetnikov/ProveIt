"""Independent demand-rule oracle and strict proof reconstruction.

This module never imports a candidate checker. Syntax validation and every
substitution use the separately written named-binder oracle frozen in support/.
Coordinates are zero=-1, first free variable=0, as in that oracle. Accepted
proofs are normalized to the structural draft's 'r' computation marker.
"""
from collections import Counter
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent / "support"))
from named_oracle import valid, oracle
from rule_oracle import expression, context, require, local_goal


def normalized(a, p, g=(), counts=None):
    """Return a strict canonical proof, or None/False with explicit status.

    The returned pair is (accepted, proof). Failed proof search can fall back
    to a hypothesis; malformed formation or selected arity raises. No target
    substitution or target proof function participates in the reconstruction.
    """
    expression(a)
    counts = Counter() if counts is None else counts
    array = type(p) is list
    if a[0] == "pi" and array and len(p) == 1:
        b, h, kind = local_goal(a)
        counts[kind] += 1
        good, child = normalized(b, p[0], [*[oracle(x) for x in g], h], counts)
        return good, [child]
    if a[0] == "ex" and array and len(p) == 2:
        witness, child = p
        expression(witness, False)
        h = ["=", 0, oracle(witness, formula=False)]
        counts["existential_introduction"] += 1
        good, child = normalized(a[1], child, [*[oracle(x) for x in g], h], counts)
        return good, [witness, child]
    if array and len(p) >= 2 and type(p[0]) is list and p[0]:
        major = p[0]
        good, head = normalized(major, p[1], g, counts)
        if good:
            args = p[2:]
            if major[0] == "ex":
                require(len(args) == 1)
                counts["existential_elimination"] += 1
                good, child = normalized(oracle(a), args[0],
                                         [*[oracle(x) for x in g], major[1]], counts)
                return good, [major, head, child]
            require(len(args) == 2)
            annotation, child = args
            if major[0] == "pi":
                # Deleting the binder is permitted exactly when its named
                # identity occurs in neither matrix. This uses None as a
                # deletion sentinel in the independent substitution oracle.
                try:
                    premise = oracle(major[1], [None, -1])
                    conclusion = oracle(major[2], [None, -1])
                    if not valid(annotation, False):
                        counts["malformed_unused_witness_sanitized"] += 1
                    annotation = -1
                    counts["unused_witness_replaced_by_zero"] += 1
                except ValueError:
                    expression(annotation, False)
                    premise = oracle(major[1], [annotation, -1])
                    conclusion = oracle(major[2], [annotation, -1])
                counts["guarded_elimination"] += 1
            else:
                require(major[0] == "=")
                expression(annotation)
                premise = oracle(annotation, [major[1], -1])
                conclusion = oracle(annotation, [major[2], -1])
                counts["equality_transport"] += 1
            if conclusion != a:
                return False, None
            good, child = normalized(premise, child, g, counts)
            return good, [major, head, annotation, child]
        counts["failed_major_hypothesis_fallback"] += 1
    if p == "r" and a[0] == "=" and type(a[1]) is list and a[1][0] == "r":
        n, initial, update = a[1][1:]
        if n == -1:
            rhs = initial
            counts["computation_zero"] += 1
        else:
            require(type(n) is list and len(n) == 2 and n[0] == "s")
            predecessor = n[1]
            rhs = oracle(update, [["r", predecessor, initial, update], predecessor, -2],
                         formula=False)
            counts["computation_successor"] += 1
        return rhs == a[2], "r"
    counts["hypothesis_membership"] += 1
    return a in g, None


def reconstruct(a, p, g=(), counts=None):
    return normalized(a, p, context(g), counts)


def accepted(a, p, g=(), counts=None):
    try:
        return reconstruct(a, p, g, counts)[0]
    except Exception:
        return False


def shift_codes(a, offset):
    """Renumber actual integers, preserving Booleans and invalid float types."""
    if type(a) is int:
        return a + offset
    if type(a) is list:
        return [shift_codes(x, offset) for x in a]
    if type(a) is dict:
        return {k: shift_codes(v, offset) for k, v in a.items()}
    return a


def reencode(a, p, g=(), marker="r", tagged=False):
    """Translate a source proof's markers using the independent rule grammar.

    The caller checks the original with its frozen source checker first.
    Positive numeric codes must already have been changed to negative codes.
    """
    array = type(p) is list
    if a[0] == "pi" and array and ((tagged and p and p[0] == "lam")
                                  or (not tagged and len(p) == 1)):
        b, h, _ = local_goal(a)
        q = p[1] if tagged else p[0]
        return [reencode(b, q, [*[oracle(x) for x in g], h], marker, tagged)]
    if a[0] == "ex" and array and ((tagged and p and p[0] == "pack")
                                  or (not tagged and len(p) == 2)):
        witness, q = p[1:] if tagged else p
        h = ["=", 0, oracle(witness, formula=False)]
        return [witness, reencode(a[1], q, [*[oracle(x) for x in g], h], marker, tagged)]
    if array and len(p) >= 2 and type(p[0]) is list and p[0]:
        major, original_head, *args = p
        head = reencode(major, original_head, g, marker, tagged)
        if accepted(major, head, g):
            if major[0] == "ex":
                q, = args
                return [major, head, reencode(oracle(a), q,
                    [*[oracle(x) for x in g], major[1]], marker, tagged)]
            annotation, q = args
            premise = (oracle(major[1], [annotation, -1]) if major[0] == "pi"
                       else oracle(annotation, [major[1], -1]))
            return [major, head, annotation, reencode(premise, q, g, marker, tagged)]
    if p == marker and a[0] == "=" and type(a[1]) is list and a[1][0] == "r":
        return "r"
    return None
