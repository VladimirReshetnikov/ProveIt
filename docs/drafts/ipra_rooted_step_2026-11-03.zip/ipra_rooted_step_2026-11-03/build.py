#!/usr/bin/env python3
"""Reproduce the finite diagnostics and compile the complete LaTeX report."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
BUILD = ROOT / ".build"
ARTIFACTS = ROOT / "artifacts"


def run(command: list[str], log: Path | None = None) -> None:
    environment = dict(os.environ)
    # Fixed publication day makes TeX's date handling reproducible.
    environment["SOURCE_DATE_EPOCH"] = "1793664000"
    environment["FORCE_SOURCE_DATE"] = "1"
    if log is None:
        subprocess.run(command, cwd=ROOT, env=environment, check=True)
    else:
        with log.open("w", encoding="utf-8") as stream:
            subprocess.run(command, cwd=ROOT, env=environment, check=True,
                           stdout=stream, stderr=subprocess.STDOUT)


def main() -> None:
    if shutil.which("pdflatex") is None:
        raise SystemExit("pdflatex is required to compile report.tex")
    BUILD.mkdir(exist_ok=True)
    ARTIFACTS.mkdir(exist_ok=True)
    for script, result in [
        ("check_syntax.py", "syntax_results.json"),
        ("check_zero_tests.py", "zero_test_results.json"),
    ]:
        run([sys.executable, str(ARTIFACTS / script), "--output",
             str(ARTIFACTS / result)], BUILD / f"{Path(script).stem}.txt")

    for number in range(1, 4):
        run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
             f"-output-directory={BUILD}", "report.tex"],
            BUILD / f"latex_pass_{number}.txt")
    shutil.copy2(BUILD / "report.pdf", ROOT / "report.pdf")
    log_text = (BUILD / "report.log").read_text(errors="replace")
    warnings = [line for line in log_text.splitlines()
                if "Warning:" in line or "warning (" in line or "Overfull" in line]
    summary = {
        "latex_passes": 3,
        "diagnostics": ["syntax_results.json", "zero_test_results.json"],
        "pdf_bytes": (ROOT / "report.pdf").stat().st_size,
        "latex_warnings": warnings,
        "status": "PASS",
        "scope": "Successful compilation and finite diagnostics; visual QA is separate.",
    }
    (ARTIFACTS / "build_results.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    files = sorted(path for path in ROOT.rglob("*")
                   if path.is_file() and ".build" not in path.parts
                   and "__pycache__" not in path.parts
                   and path.name != "SHA256SUMS.txt")
    checksums = [f"{hashlib.sha256(path.read_bytes()).hexdigest()}  "
                 f"{path.relative_to(ROOT).as_posix()}" for path in files]
    (ROOT / "SHA256SUMS.txt").write_text("\n".join(checksums) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
