A small complete axiomatization of intuitionistic PRA
3 November 2026
====================================================

Start with report.pdf. AXIOMS.txt is the complete standalone specification.
report.tex includes all sections/*.tex; keep that directory when rebuilding.

Main result
-----------
Full intuitionistic equality logic + one separation sentence + initialized
recursion + one rooted equation-step schema. The report proves whole-carrier
bi-interpretability with iPRA, with internally identity round trips and genuine
falsity preserved.

Proved improvements
-------------------
* Five fewer nodes per expanded closure instance than the current equation-
  closure draft, with no additional arithmetic helper.
* Five fewer nodes per atomic equality test in the quantifier-free compiler.
* A systematic nonincreasing pruning of each current optimized source in its
  own ledger, retaining all substantive successor clauses and anchor modules.
* Optional fully paid notation with a smaller recurring instance cost; its
  fixed-cost tradeoff is disclosed.

The raw readable core is not claimed to dominate every optimized signature.
The source-preserving companions carry the precise lower-envelope theorem.
There is no encoding-independent absolute shortestness claim.

Rebuild
-------
Requires Python 3.10+ and pdflatex with ordinary LaTeX packages.
Run from this directory:
  python3 build.py

To rerun only the diagnostics:
  python3 artifacts/check_syntax.py --output artifacts/syntax_results.json
  python3 artifacts/check_zero_tests.py --output artifacts/zero_test_results.json

The Python programs require no third-party packages. Their finite checks are
not proof-assistant verification. Full theorems are proved in the report.

Files
-----
report.tex, sections/*.tex      Complete article source
report.pdf                     Compiled article
AXIOMS.txt                     Complete logical and arithmetic specification
build.py                       Diagnostics and three-pass LaTeX build
artifacts/check_syntax.py       Charged AST counts and anchored initialization
artifacts/check_zero_tests.py   Numerical and formula-compiler diagnostics
artifacts/*_results.json        Reproducible diagnostic/build output
artifacts/pdf_review.json       Visual layout review record
provenance/source_manifest.json Pinned current input paths and verified hashes
provenance/comparison.csv       Exact principal comparisons
SHA256SUMS.txt                  Checksums of delivered package files

Current sources are four archives at ProveIt commit
5753b3f955eb6681b6f89f5d778fda2b7ec8f87a. The report does not substitute the
older source snapshots discussed inside those archives for the actual inputs.
