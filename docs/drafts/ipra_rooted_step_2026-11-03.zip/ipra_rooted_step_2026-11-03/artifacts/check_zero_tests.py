#!/usr/bin/env python3
"""Finite diagnostics for unnormalized primitive-recursive zero tests.

The report supplies the infinite, intuitionistic proofs.  This program checks
the numerical definitions, the residual invariant, the propositional compiler,
and the stated finite-tree costs on explicitly reported finite domains.  It is
not a proof assistant and does not establish a theorem about nonstandard
models, arbitrary formulas, or the complete arithmetic theory.

Only the Python standard library is required.  Run directly, or use
``python3 check_zero_tests.py --output zero_test_results.json``.
"""

from __future__ import annotations

import argparse
import itertools
import json
from collections import Counter
from functools import lru_cache
from pathlib import Path
from typing import Any


NUMERIC_BOUND = 48  # Every integer from zero through this bound, inclusive.
ASSIGNMENT_BOUND = 3
MAX_CONNECTIVES = 2
VARIABLES = ("x", "y", "z")
CONNECTIVES = ("and", "or", "imp")

# Immutable trees: arithmetic terms, formulas, and compiled numerical terms.
Tree = tuple
Assignment = tuple[int, int, int]


def successor(n: int) -> int:
    return n + 1


def predecessor(n: int) -> int:
    return 0 if n == 0 else n - 1


def q(counter: int, initializer: int) -> int:
    """Q(0,a)=a and Q(Sn,a)=n, the generated predecessor recursor."""
    return initializer if counter == 0 else counter - 1


def addition(counter: int, initializer: int) -> int:
    """A(n,a)=a+n, evaluated from its initialized recursion."""
    state = initializer
    for _ in range(counter):
        state = successor(state)
    return state


def difference(initializer: int, counter: int) -> int:
    """d(y,n)=p iterated n times on y; argument order follows the report."""
    state = initializer
    for _ in range(counter):
        state = predecessor(state)
    return state


def selector(counter: int, at_zero: int, at_successor: int) -> int:
    """C(0,a,b)=a and C(Sn,a,b)=b."""
    return at_zero if counter == 0 else at_successor


def epsilon(left: int, right: int) -> int:
    """The unnormalized test Q(d(S left,right),1)."""
    return q(difference(successor(left), right), 1)


@lru_cache(maxsize=None)
def arithmetic_value(term: Tree, values: Assignment) -> int:
    tag = term[0]
    if tag == "var":
        return values[VARIABLES.index(term[1])]
    if tag == "const":
        return term[1]
    if tag == "succ":
        return successor(arithmetic_value(term[1], values))
    if tag == "pred":
        return predecessor(arithmetic_value(term[1], values))
    if tag == "add":
        return addition(
            arithmetic_value(term[1], values),
            arithmetic_value(term[2], values),
        )
    if tag == "sub":
        return difference(
            arithmetic_value(term[1], values),
            arithmetic_value(term[2], values),
        )
    raise ValueError(f"Unknown arithmetic constructor: {tag}")


def formula_value(formula: Tree, values: Assignment) -> bool:
    """Independent Boolean semantics in the standard numerical model."""
    tag = formula[0]
    if tag == "eq":
        return arithmetic_value(formula[1], values) == arithmetic_value(
            formula[2], values
        )
    if tag == "bottom":
        return False
    left = formula_value(formula[1], values)
    right = formula_value(formula[2], values)
    if tag == "and":
        return left and right
    if tag == "or":
        return left or right
    if tag == "imp":
        return (not left) or right
    raise ValueError(f"Unknown formula constructor: {tag}")


def compile_zero_test(formula: Tree) -> Tree:
    """Use epsilon at atoms; deliberately do not normalize it to a bit."""
    tag = formula[0]
    if tag == "eq":
        return ("epsilon", formula[1], formula[2])
    if tag == "bottom":
        return ("constant", 1)
    left = compile_zero_test(formula[1])
    right = compile_zero_test(formula[2])
    if tag == "and":
        return ("select", left, right, ("constant", 1))
    if tag == "or":
        return ("select", left, ("constant", 0), right)
    if tag == "imp":
        return ("select", left, right, ("constant", 0))
    raise ValueError(f"Unknown formula constructor: {tag}")


def compiled_value(term: Tree, values: Assignment) -> int:
    tag = term[0]
    if tag == "constant":
        return term[1]
    if tag == "epsilon":
        return epsilon(
            arithmetic_value(term[1], values),
            arithmetic_value(term[2], values),
        )
    if tag == "select":
        return selector(
            compiled_value(term[1], values),
            compiled_value(term[2], values),
            compiled_value(term[3], values),
        )
    raise ValueError(f"Unknown compiled constructor: {tag}")


def formula_levels(atoms: tuple[Tree, ...]) -> list[list[Tree]]:
    """All ordered binary formula trees with at most two connectives."""
    levels: list[list[Tree]] = [[("bottom",), *atoms]]
    for count in range(1, MAX_CONNECTIVES + 1):
        level = []
        for left_count in range(count):
            right_count = count - 1 - left_count
            for tag in CONNECTIVES:
                for left in levels[left_count]:
                    for right in levels[right_count]:
                        level.append((tag, left, right))
        levels.append(level)
    return levels


def check_numerical_identities() -> dict[str, Any]:
    atomic_checks = 0
    residual_checks = 0
    nonbinary_count = 0
    nonbinary_examples = []
    outputs = set()
    for left, right in itertools.product(range(NUMERIC_BOUND + 1), repeat=2):
        value = epsilon(left, right)
        assert (value == 0) == (left == right), (left, right, value)
        atomic_checks += 1
        outputs.add(value)
        if value > 1:
            nonbinary_count += 1
            if len(nonbinary_examples) < 8:
                nonbinary_examples.append(
                    {"left": left, "right": right, "epsilon": value}
                )

        # This is the independently stated residual identity, not a check
        # against another implementation of the same formula compiler.
        y, n = left, right
        residual = difference(y, n)
        result = selector(residual, y, addition(residual, n))
        assert result == y, (y, n, residual, result)
        residual_checks += 1

    # A deliberate regression check: the useful zero test is not Boolean.
    assert epsilon(5, 1) == 4
    assert nonbinary_count > 0
    return {
        "domain": {
            "variables": ["left", "right"],
            "minimum": 0,
            "maximum_inclusive": NUMERIC_BOUND,
        },
        "atomic_reflection_checks": atomic_checks,
        "residual_identity_checks": residual_checks,
        "residual_identity": "C(d(y,n),y,n+d(y,n)) = y; n+d(y,n)=A(d(y,n),n)",
        "epsilon_output_minimum": min(outputs),
        "epsilon_output_maximum": max(outputs),
        "nonbinary_atomic_outputs": nonbinary_count,
        "nonbinary_examples": nonbinary_examples,
    }


def check_formula_compiler() -> dict[str, Any]:
    x, y, z = (("var", variable) for variable in VARIABLES)
    atoms = (
        ("eq", x, y),
        ("eq", ("succ", x), y),
        ("eq", ("sub", x, y), z),
        ("eq", ("add", x, y), z),
        ("eq", ("pred", x), z),
        ("eq", x, ("const", 0)),
    )
    levels = formula_levels(atoms)
    assignments = tuple(
        itertools.product(range(ASSIGNMENT_BOUND + 1), repeat=len(VARIABLES))
    )
    checks = 0
    output_counts: Counter[int] = Counter()
    atom_occurrences: Counter[int] = Counter()

    def count_atoms(formula: Tree) -> int:
        if formula[0] == "eq":
            return 1
        if formula[0] == "bottom":
            return 0
        return count_atoms(formula[1]) + count_atoms(formula[2])

    for level in levels:
        for formula in level:
            compiled = compile_zero_test(formula)
            atom_occurrences[count_atoms(formula)] += 1
            for values in assignments:
                expected = formula_value(formula, values)
                actual = compiled_value(compiled, values)
                assert (actual == 0) == expected, (formula, values, actual, expected)
                checks += 1
                output_counts[actual] += 1

    formula_count = sum(map(len, levels))
    assert [len(level) for level in levels] == [7, 147, 6174]
    assert formula_count == 6328
    assert checks == formula_count * len(assignments)
    assert sum(count for value, count in output_counts.items() if value > 1) > 0
    return {
        "atoms": atoms,
        "falsity_is_an_additional_leaf": True,
        "connectives": list(CONNECTIVES),
        "generation": (
            "Every ordered binary formula tree with zero, one, or two "
            "connectives over the six listed atoms and falsity."
        ),
        "counts_by_connective_count": {
            str(count): len(level) for count, level in enumerate(levels)
        },
        "formula_count": formula_count,
        "assignment_domain": {
            "variables": list(VARIABLES),
            "minimum": 0,
            "maximum_inclusive": ASSIGNMENT_BOUND,
            "assignment_count": len(assignments),
        },
        "formula_assignment_checks": checks,
        "normalization_to_boolean_bits": False,
        "compiled_output_histogram": {
            str(value): count for value, count in sorted(output_counts.items())
        },
        "formulas_by_atomic_equality_occurrences": {
            str(count): formulas for count, formulas in sorted(atom_occurrences.items())
        },
    }


def check_atomic_costs() -> dict[str, Any]:
    """Count the displayed recursor trees, including frozen descriptors."""
    # Q has descriptor w (one node). Its application pays another node.
    def q_size(counter_size: int, initializer_size: int) -> int:
        return 1 + 1 + counter_size + initializer_size

    predecessor_descriptor_size = q_size(1, 1)  # Q(v,0).
    assert predecessor_descriptor_size == 4
    cost_checks = 0
    samples = []
    for left_size, right_size in itertools.product(range(1, 13), repeat=2):
        # d(Ss,t) = R_[Q(v,0)](t,Ss).
        residual_size = 1 + predecessor_descriptor_size + right_size + 1 + left_size
        unnormalized_size = q_size(residual_size, 2)  # The numeral S0 costs 2.
        # C has descriptor c1 (one node); actual arguments are epsilon,0,S0.
        normalized_size = 1 + 1 + unnormalized_size + 1 + 2
        assert unnormalized_size == left_size + right_size + 10
        assert normalized_size == left_size + right_size + 15
        assert normalized_size - unnormalized_size == 5
        cost_checks += 1
        if (left_size, right_size) in ((1, 1), (3, 7), (12, 12)):
            samples.append(
                {
                    "left_term_size": left_size,
                    "right_term_size": right_size,
                    "epsilon_size": unnormalized_size,
                    "normalized_beta_size": normalized_size,
                    "saving": normalized_size - unnormalized_size,
                }
            )
    return {
        "convention": (
            "One node per variable, constant, and application, plus the "
            "entire frozen descriptor per recursor occurrence; 1 means S0."
        ),
        "epsilon_size": "|s| + |t| + 10",
        "normalized_beta_size": "|s| + |t| + 15",
        "saving_per_atomic_equality_occurrence": 5,
        "finite_cost_checks": cost_checks,
        "samples": samples,
        "scope": (
            "These are term-tree counts, not complete theory, generator, "
            "logical-calculus, or proof-length costs."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Optional JSON result path.")
    args = parser.parse_args()
    result = {
        "artifact": "check_zero_tests.py",
        "status": "passed",
        "scope": (
            "Finite diagnostics in the standard natural numbers. These checks "
            "do not prove the infinite induction or interpretation theorems, "
            "and are not a Lean, Rocq, or other proof-assistant verification."
        ),
        "numerical_identities": check_numerical_identities(),
        "quantifier_free_compiler": check_formula_compiler(),
        "atomic_syntax_costs": check_atomic_costs(),
    }
    rendered = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")


if __name__ == "__main__":
    main()
