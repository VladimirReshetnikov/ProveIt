#!/usr/bin/env python3
"""Finite syntax checks for rooted-step iPRA and initialization pruning.

This is a dependency-free diagnostic, not a proof assistant for iPRA.
It checks actual finite syntax trees, capture-avoiding substitution, the
published occurrence ledger, and elementary initialization reductions.
Every recursor occurrence pays for its entire frozen description.

Run:
    python3 check_syntax.py
    python3 check_syntax.py --output syntax_results.json
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, replace
import json
from pathlib import Path


@dataclass(frozen=True)
class Expr:
    kind: str
    children: tuple[Expr, ...] = ()
    name: str = ""
    descriptor: Expr | None = None
    parameters: tuple[str, ...] = ()


def variable(name: str) -> Expr:
    return Expr("variable", name=name)


ZERO = Expr("zero")
BOTTOM = Expr("bottom")
STATE = variable("v")
CLOCK = variable("w")


def successor(term: Expr) -> Expr:
    return Expr("successor", (term,))


def equality(left: Expr, right: Expr) -> Expr:
    return Expr("equality", (left, right))


def conjunction(left: Expr, right: Expr) -> Expr:
    return Expr("and", (left, right))


def disjunction(left: Expr, right: Expr) -> Expr:
    return Expr("or", (left, right))


def implication(left: Expr, right: Expr) -> Expr:
    return Expr("implies", (left, right))


def universal(name: str, formula: Expr) -> Expr:
    return Expr("forall", (formula,), name=name)


def close(formula: Expr, names: tuple[str, ...]) -> Expr:
    for name in reversed(names):
        formula = universal(name, formula)
    return formula


@dataclass(frozen=True)
class Recursor:
    name: str
    descriptor: Expr
    parameters: tuple[str, ...] = ()

    def __call__(self, *arguments: Expr) -> Expr:
        if len(arguments) != 2 + len(self.parameters):
            raise ValueError(f"Wrong arity for {self.name}")
        return Expr("recursor", arguments, self.name, self.descriptor, self.parameters)


def symbol_of(expression: Expr) -> Recursor:
    if expression.kind != "recursor" or expression.descriptor is None:
        raise ValueError("Expected a recursor application")
    return Recursor(expression.name, expression.descriptor, expression.parameters)


def size(expression: Expr) -> int:
    descriptor_cost = 0 if expression.descriptor is None else size(expression.descriptor)
    return 1 + descriptor_cost + sum(size(child) for child in expression.children)


def free_variables(expression: Expr) -> set[str]:
    """Free active variables; frozen descriptions have their own local slots."""
    if expression.kind == "variable":
        return {expression.name}
    result = set().union(*(free_variables(child) for child in expression.children))
    if expression.kind in {"forall", "exists"}:
        result.discard(expression.name)
    return result


def active_names(expression: Expr) -> set[str]:
    result = set().union(*(active_names(child) for child in expression.children))
    if expression.kind in {"variable", "forall", "exists"}:
        result.add(expression.name)
    return result


def active_occurrences(expression: Expr, name: str) -> int:
    if expression.kind == "variable":
        return int(expression.name == name)
    if expression.kind in {"forall", "exists"} and expression.name == name:
        return 0
    return sum(active_occurrences(child, name) for child in expression.children)


def substitute(expression: Expr, substitutions: dict[str, Expr]) -> Expr:
    """Simultaneous capture-avoiding substitution; never traverse descriptors."""
    if expression.kind == "variable":
        return substitutions.get(expression.name, expression)
    local = dict(substitutions)
    children = expression.children
    binder = expression.name
    if expression.kind in {"forall", "exists"}:
        local.pop(binder, None)
        relevant = free_variables(expression)
        inserted = set().union(*(
            free_variables(term) for name, term in local.items() if name in relevant
        ))
        if binder in inserted:
            avoid = active_names(expression) | inserted | set(local)
            suffix = 0
            fresh = f"{binder}_{suffix}"
            while fresh in avoid:
                suffix += 1
                fresh = f"{binder}_{suffix}"
            children = tuple(substitute(child, {binder: variable(fresh)})
                             for child in children)
            binder = fresh
    return replace(expression, name=binder,
                   children=tuple(substitute(child, local) for child in children))


def repeat(operation, count: int, term: Expr) -> Expr:
    for _ in range(count):
        term = operation(term)
    return term


Q = Recursor("Q", CLOCK)
A = Recursor("A", successor(STATE))


def predecessor(term: Expr) -> Expr:
    return Q(term, ZERO)


P = Recursor("P", predecessor(STATE))


def ordinary_module(symbol: Recursor) -> Expr:
    """The complete grouped initialization-and-successor module."""
    initial = variable("a")
    counter = variable("n")
    parameters = tuple(variable(name) for name in symbol.parameters)
    base = equality(symbol(ZERO, initial, *parameters), initial)
    recursive_call = symbol(counter, initial, *parameters)
    update = substitute(symbol.descriptor, {"v": recursive_call, "w": counter})
    step = equality(symbol(successor(counter), initial, *parameters), update)
    return close(conjunction(base, universal("n", step)), ("a", *symbol.parameters))


def rooted_closure(equation: Expr, parameters: tuple[str, ...], stripped: bool) -> Expr:
    probe = variable("x")
    guard = disjunction(equality(probe, ZERO), equation)
    step_target = substitute(equation if stripped else guard, {"x": successor(probe)})
    step = universal("x", implication(guard, step_target))
    return close(implication(step, universal("x", guard)), parameters)


@dataclass(frozen=True)
class SymbolImage:
    slots: tuple[str, ...]
    term: Expr


def translate(expression: Expr, images: dict[Recursor, SymbolImage]) -> Expr:
    """A fixed homomorphic symbol map, including only active arguments."""
    children = tuple(translate(child, images) for child in expression.children)
    translated = replace(expression, children=children)
    if translated.kind == "recursor" and symbol_of(translated) in images:
        image = images[symbol_of(translated)]
        if len(image.slots) != len(children):
            raise ValueError("Image has the wrong number of argument slots")
        return substitute(image.term, dict(zip(image.slots, children)))
    return translated


ERASE_INITIALIZER = SymbolImage(("n", "a"), variable("a"))


def peel_universals(formula: Expr) -> tuple[tuple[str, ...], Expr]:
    names = []
    while formula.kind == "forall":
        names.append(formula.name)
        formula = formula.children[0]
    return tuple(names), formula


def initialization_anchor(module: Expr) -> Recursor:
    """Validate a retained ordinary module before using its base equation."""
    names, matrix = peel_universals(module)
    if not names or matrix.kind != "and" or matrix.children[0].kind != "equality":
        raise ValueError("Anchor is not a complete grouped ordinary module")
    base, quantified_step = matrix.children
    left, right = base.children
    if quantified_step.kind != "forall" or left.kind != "recursor":
        raise ValueError("Anchor is missing its successor clause")
    symbol = symbol_of(left)
    expected = (ZERO, variable(names[0]), *(variable(name) for name in names[1:]))
    if left.children != expected or right != variable(names[0]):
        raise ValueError("Anchor initialization does not have the required form")
    if len(names) != 1 + len(symbol.parameters):
        raise ValueError("Anchor has the wrong parameter closure")
    return symbol


def reduce_initializations(term: Expr, anchors: set[Recursor]) -> tuple[Expr, int]:
    """Only g(0,z,parameters) -> z for selected, retained anchors."""
    reduced_children = []
    steps = 0
    for child in term.children:
        reduced, used = reduce_initializations(child, anchors)
        reduced_children.append(reduced)
        steps += used
    reduced = replace(term, children=tuple(reduced_children))
    if (reduced.kind == "recursor" and symbol_of(reduced) in anchors
            and reduced.children[0] == ZERO):
        result = reduced.children[1]
        assert size(result) < size(reduced)
        return result, steps + 1
    return reduced, steps


def prune_base(module: Expr, retained_modules: tuple[Expr, ...]) -> tuple[Expr, int]:
    """Prune a certified base, protecting every selected anchor module."""
    if module in retained_modules:
        return module, 0
    names, matrix = peel_universals(module)
    if not names or matrix.kind != "and" or matrix.children[0].kind != "equality":
        return module, 0
    base, step = matrix.children
    if step.kind != "forall":
        return module, 0
    anchors = {initialization_anchor(anchor) for anchor in retained_modules}
    left, left_steps = reduce_initializations(base.children[0], anchors)
    right, right_steps = reduce_initializations(base.children[1], anchors)
    if left != right or right != variable(names[0]):
        return module, left_steps + right_steps
    pruned = close(step, names)
    assert size(module) - size(pruned) == size(base) + 1
    return pruned, left_steps + right_steps


def check_scope() -> dict:
    frozen = Recursor("Frozen_parameter", successor(variable("x")), ("x",))
    inactive = frozen(variable("n"), variable("a"), variable("c"))
    active = frozen(variable("x"), variable("a"), variable("c"))
    inactive_result = substitute(inactive, {"x": successor(variable("x"))})
    active_result = substitute(active, {"x": successor(variable("x"))})
    assert inactive_result == inactive
    assert active_occurrences(inactive, "x") == 0
    assert active_occurrences(active, "x") == 1
    assert size(active_result) == size(active) + 1
    assert active_result.descriptor is active.descriptor
    captured = universal("y", equality(variable("x"), variable("y")))
    renamed = substitute(captured, {"x": variable("y")})
    assert renamed.name != "y"
    assert free_variables(renamed) == {"y"}
    assert renamed.children[0] == equality(variable("y"), variable(renamed.name))
    return {
        "frozen_descriptor_preserved": True,
        "metadata_x_occurrences_excluded": True,
        "active_substitution_size_increment": 1,
        "capture_avoiding_renaming": True,
    }


def check_closure_counts() -> list[dict]:
    x = variable("x")
    frozen = Recursor("Descriptor_x", successor(variable("x")), ("x",))
    examples = [
        (equality(x, x), ()),
        (equality(x, ZERO), ()),
        (equality(successor(x), variable("c")), ("c",)),
        (equality(Q(x, ZERO), x), ()),
        (equality(frozen(x, variable("a"), variable("c")), x), ("a", "c")),
        (equality(variable("a"), variable("b")), ("a", "b", "unused")),
    ]
    rows = []
    for equation, parameters in examples:
        assert free_variables(equation) - {"x"} <= set(parameters)
        formula_size = size(equation)
        occurrences = active_occurrences(equation, "x")
        old = size(rooted_closure(equation, parameters, stripped=False))
        new = size(rooted_closure(equation, parameters, stripped=True))
        assert old == 3 * formula_size + occurrences + len(parameters) + 17
        assert new == 3 * formula_size + occurrences + len(parameters) + 12
        assert old - new == 5
        rows.append({
            "equation_size": formula_size,
            "active_x": occurrences,
            "parameters": len(parameters),
            "Z": old,
            "Z_minus": new,
            "saving": old - new,
        })
    return rows


def check_module_counts() -> list[dict]:
    examples = [
        Q,
        A,
        P,
        Recursor("Identity", STATE),
        Recursor("Reset", ZERO),
        Recursor("Case", variable("c1"), ("c1",)),
        Recursor("Double", A(STATE, STATE)),
        Recursor("Clock_iteration", A(CLOCK, STATE)),
        Recursor("Two_parameters", A(STATE, variable("c1")), ("c1", "c2")),
    ]
    rows = []
    for symbol in examples:
        body_size = size(symbol.descriptor)
        parameters = len(symbol.parameters)
        state_occurrences = active_occurrences(symbol.descriptor, "v")
        expected = (3 * body_size + 3 * parameters + 13
                    + state_occurrences * (body_size + parameters + 2))
        observed = size(ordinary_module(symbol))
        assert observed == expected
        rows.append({
            "symbol": symbol.name,
            "H": body_size,
            "m": parameters,
            "state_occurrences": state_occurrences,
            "module_size": observed,
        })
    return rows


def erasure_row(symbol: Recursor, expected_old: int, expected_new: int) -> dict:
    residual = translate(ordinary_module(symbol), {symbol: ERASE_INITIALIZER})
    pruned, steps = prune_base(residual, ())
    assert size(residual) == expected_old
    assert size(pruned) == expected_new
    assert steps == 0
    assert expected_old - expected_new == 4
    return {"before": size(residual), "after": size(pruned), "saving": 4}


def check_residual_families() -> dict:
    equation_rows = []
    block_update = Recursor("Block_6", repeat(successor, 6, STATE))
    for index in (2, 3, 8):
        body = repeat(predecessor, 6 * index,
                      block_update(repeat(successor, index, ZERO), STATE))
        symbol = Recursor(f"Block_identity_{index}", body)
        assert size(body) == 19 * index + 10
        assert size(ordinary_module(symbol)) == 76 * index + 55
        row = erasure_row(symbol, 19 * index + 18, 19 * index + 14)
        equation_rows.append({"k": index, **row})

    inverse_rows = []
    for index in (1, 2, 8):
        body = STATE
        for _ in range(index):
            body = P(CLOCK, A(CLOCK, body))
        symbol = Recursor(f"Eta_{index}", body)
        assert size(body) == 10 * index + 1
        assert size(ordinary_module(symbol)) == 40 * index + 19
        row = erasure_row(symbol, 10 * index + 9, 10 * index + 5)
        inverse_rows.append({"j": index, **row})

    retraction_rows = []
    for index in (1, 2, 8):
        inverse = Recursor(f"Retraction_down_{index}", repeat(predecessor, index, STATE))
        forward = Recursor(f"Retraction_up_{index}", repeat(successor, index, STATE))
        body = inverse(CLOCK, forward(CLOCK, STATE))
        symbol = Recursor(f"Retraction_identity_{index}", body)
        assert size(body) == 4 * index + 7
        assert size(ordinary_module(symbol)) == 16 * index + 43
        row = erasure_row(symbol, 4 * index + 15, 4 * index + 11)
        retraction_rows.append({"j": index, **row})

    transport_rows = []
    for repetitions, stride in ((1, 1), (2, 1), (1, 3), (4, 8)):
        increment = Recursor(f"Transport_stride_{stride}",
                            repeat(successor, stride, STATE))
        representative = Recursor(f"Transport_B_{stride}", increment(CLOCK, STATE))
        body = repeat(predecessor, repetitions,
                      increment(CLOCK, repeat(successor, repetitions, STATE)))
        source = Recursor(f"Transport_H_{repetitions}_{stride}", body)
        image = SymbolImage(("n", "a"), representative(variable("n"), variable("a")))
        residual = translate(ordinary_module(source), {source: image})
        anchor = ordinary_module(representative)
        pruned, steps = prune_base(residual, (anchor,))
        unsupported, _ = prune_base(residual, ())
        protected, _ = prune_base(anchor, (anchor,))
        assert unsupported == residual
        assert protected == anchor
        assert size(anchor) == 4 * stride + 31
        assert size(residual) == 4 * repetitions + 4 * stride + 31
        assert size(pruned) == 4 * repetitions + 3 * stride + 21
        assert size(residual) - size(pruned) == stride + 10
        assert steps == 1
        transport_rows.append({
            "m": repetitions,
            "j": stride,
            "before": size(residual),
            "after": size(pruned),
            "saving": stride + 10,
            "anchor_size": size(anchor),
            "supported_packet_before": size(residual) + size(anchor),
            "supported_packet_after": size(pruned) + size(anchor),
        })
    return {
        "equation_closure": equation_rows,
        "inverse_iteration": inverse_rows,
        "retraction": retraction_rows,
        "successor_transport": transport_rows,
    }


def check_nested_anchor_image() -> dict:
    """The existing folded-power image has two retained base dependencies."""
    double = Recursor("Power_M", A(STATE, STATE))
    stride = Recursor("Power_Sigma_3", repeat(successor, 3, STATE))
    body = STATE
    for _ in range(3):
        body = A(body, body)
    source = Recursor("Power_g_3", body)
    image = SymbolImage(("n", "a"), double(stride(variable("n"), ZERO), variable("a")))
    residual = translate(ordinary_module(source), {source: image})
    anchors = (ordinary_module(double), ordinary_module(stride))
    pruned, steps = prune_base(residual, anchors)
    missing_double, _ = prune_base(residual, anchors[1:])
    missing_stride, _ = prune_base(residual, anchors[:1])
    assert missing_double == residual
    assert missing_stride == residual
    assert steps == 2
    assert size(residual) - size(pruned) == 17
    nongrouped = universal("a", equality(variable("a"), variable("a")))
    assert prune_base(nongrouped, ())[0] == nongrouped
    return {
        "retained_anchor_count": 2,
        "initialization_reductions": steps,
        "base_and_conjunction_saving": size(residual) - size(pruned),
        "missing_either_anchor_prevents_pruning": True,
        "non_grouped_module_left_unchanged": True,
    }


def run_checks() -> dict:
    return {
        "status": "PASS",
        "scope": (
            "Finite actual-AST ledgers and syntactic initialization certificates; "
            "not a proof-assistant verification of iPRA, induction, or bi-interpretability."
        ),
        "scope_and_substitution": check_scope(),
        "rooted_schema_counts": check_closure_counts(),
        "complete_module_counts": check_module_counts(),
        "pruned_current_source_modules": check_residual_families(),
        "anchored_reduction_checks": check_nested_anchor_image(),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Write JSON here instead of stdout")
    arguments = parser.parse_args()
    rendered = json.dumps(run_checks(), indent=2, ensure_ascii=True) + "\n"
    if arguments.output is None:
        print(rendered, end="")
    else:
        arguments.output.parent.mkdir(parents=True, exist_ok=True)
        arguments.output.write_text(rendered, encoding="utf-8")


if __name__ == "__main__":
    main()
