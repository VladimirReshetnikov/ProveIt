#!/usr/bin/env python3
"""Write SHA256SUMS and an ordered ZIP of the final deliverable."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED = {".aux", ".log", ".out", ".toc", ".fls", ".fdb_latexmk", ".synctex.gz", ".pyc"}
def selected(p):
    return p.is_file() and p.suffix not in EXCLUDED and "__pycache__" not in p.parts and p.name != "SHA256SUMS"
files = sorted(p for p in ROOT.rglob("*") if selected(p))
(ROOT / "SHA256SUMS").write_text("".join(
    hashlib.sha256(p.read_bytes()).hexdigest() + "  "
    + p.relative_to(ROOT).as_posix() + "\n" for p in files
))
archive = ROOT.parent / (ROOT.name + ".zip")
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in files + [ROOT / "SHA256SUMS"]:
        z.write(p, arcname=(Path(ROOT.name) / p.relative_to(ROOT)).as_posix())
print(archive)

