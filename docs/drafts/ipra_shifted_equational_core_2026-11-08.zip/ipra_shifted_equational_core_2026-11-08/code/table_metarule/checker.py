#!/usr/bin/env python3
"""Replay only the disclosed generic equational finite-table derivations.

This is not a complete iPRA checker and does not check the clock theorem.
The only imported arithmetic equations are B(0)=0 and B(Sx)=S0.
All table lifting uses explicit literal-equation induction proof nodes.
"""
import json
import sys


class Invalid(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise Invalid(message)


def variable(name):
    return ["v", name]


def application(name, *arguments):
    return ["f", name, *arguments]


ZERO = application("0")
ONE = application("S", ZERO)


def term(value, signature):
    require(type(value) is list and len(value) >= 2, "not a term")
    require(type(value[0]) is str and type(value[1]) is str, "bad term tag")
    if value[0] == "v":
        require(len(value) == 2 and value[1] != "", "bad variable")
    else:
        require(value[0] == "f" and value[1] in signature, "unknown function")
        require(len(value) - 2 == signature[value[1]], "wrong function arity")
        for argument in value[2:]:
            term(argument, signature)
    return value


def equation(value, signature):
    require(type(value) is list and len(value) == 3 and value[0] == "=",
            "induction and judgments require a literal equation")
    term(value[1], signature)
    term(value[2], signature)
    return value


def free_variables(value):
    if value[0] == "v":
        return {value[1]}
    start = 1 if value[0] == "=" else 2
    result = set()
    for child in value[start:]:
        result.update(free_variables(child))
    return result


def substitute(value, mapping):
    if value[0] == "v":
        return mapping.get(value[1], value)
    start = 1 if value[0] == "=" else 2
    return value[:start] + [substitute(child, mapping) for child in value[start:]]


def replay(node, context, signature, statistics):
    require(type(node) is dict and type(node.get("rule")) is str, "bad proof node")
    rule = node["rule"]
    statistics["nodes"] += 1
    statistics["rules"][rule] = statistics["rules"].get(rule, 0) + 1
    if rule == "hyp":
        index = node.get("index")
        require(type(index) is int and 0 <= index < len(context), "bad hypothesis")
        result = context[index]
    elif rule == "refl":
        value = term(node.get("term"), signature)
        result = ["=", value, value]
    elif rule == "sym":
        proof = replay(node.get("proof"), context, signature, statistics)
        result = ["=", proof[2], proof[1]]
    elif rule == "trans":
        left = replay(node.get("left"), context, signature, statistics)
        right = replay(node.get("right"), context, signature, statistics)
        require(left[2] == right[1], "transitivity middle terms differ")
        result = ["=", left[1], right[2]]
    elif rule == "cong":
        name, arguments = node.get("symbol"), node.get("proofs")
        require(type(name) is str and name in signature, "bad congruence symbol")
        require(type(arguments) is list and len(arguments) == signature[name],
                "bad congruence arity")
        proofs = [replay(proof, context, signature, statistics) for proof in arguments]
        result = ["=", application(name, *(p[1] for p in proofs)),
                  application(name, *(p[2] for p in proofs))]
    elif rule == "B0":
        result = ["=", application("B", ZERO), ZERO]
    elif rule == "BS":
        value = term(node.get("term"), signature)
        result = ["=", application("B", application("S", value)), ONE]
    elif rule == "subst":
        source_context, mapping = node.get("source_context"), node.get("mapping")
        require(type(source_context) is list and type(mapping) is dict, "bad substitution")
        for hypothesis in source_context:
            equation(hypothesis, signature)
        for name, value in mapping.items():
            require(type(name) is str and name != "", "bad substitution variable")
            term(value, signature)
        for hypothesis in source_context:
            require(substitute(hypothesis, mapping) in context,
                    "substitution does not preserve the retained context")
        proof = replay(node.get("proof"), source_context, signature, statistics)
        result = substitute(proof, mapping)
    elif rule == "EI":
        name = node.get("variable")
        require(type(name) is str and name != "", "bad induction variable")
        matrix = equation(node.get("matrix"), signature)
        target = term(node.get("at"), signature)
        require(name not in free_variables(target), "eigenvariable occurs in target")
        require(all(name not in free_variables(h) for h in context),
                "eigenvariable occurs in retained context")
        base_expected = substitute(matrix, {name: ZERO})
        step_expected = substitute(matrix, {name: application("S", variable(name))})
        base = replay(node.get("base"), context, signature, statistics)
        require(base == base_expected, "wrong induction base")
        step = replay(node.get("step"), context + [matrix], signature, statistics)
        require(step == step_expected, "wrong induction step or matrix")
        result = substitute(matrix, {name: target})
    else:
        raise Invalid("unsupported inference rule: " + rule)
    return equation(result, signature)


def check(certificate):
    require(type(certificate) is dict, "certificate must be an object")
    signature = certificate.get("signature")
    require(type(signature) is dict, "missing signature")
    require(all(type(name) is str and type(arity) is int and arity >= 0
                for name, arity in signature.items()), "bad signature")
    require(all(signature.get(name) == arity for name, arity in
                {"0": 0, "S": 1, "B": 1}.items()), "fixed endpoint signature changed")
    context = certificate.get("context")
    require(type(context) is list, "missing retained context")
    for hypothesis in context:
        equation(hypothesis, signature)
    goal = equation(certificate.get("goal"), signature)
    statistics = {"nodes": 0, "rules": {}}
    conclusion = replay(certificate.get("proof"), context, signature, statistics)
    require(conclusion == goal, "wrong exported conclusion")
    return statistics


def main():
    try:
        result = check(json.load(sys.stdin))
    except (ValueError, TypeError, KeyError, IndexError, RecursionError) as error:
        print(json.dumps({"accepted": False, "error": str(error)}))
        return 1
    print(json.dumps({"accepted": True, **result}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
