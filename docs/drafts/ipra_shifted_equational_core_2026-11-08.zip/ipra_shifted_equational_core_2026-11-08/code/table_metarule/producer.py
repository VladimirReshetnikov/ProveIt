#!/usr/bin/env python3
"""Independent producer; deliberately does not import the replay checker."""
import itertools
import json
from pathlib import Path


def v(name):
    return ["v", name]


def f(name, *args):
    return ["f", name, *args]


ZERO = f("0")
ONE = f("S", ZERO)


def eq(left, right):
    return ["=", left, right]


def refl(value):
    return {"rule": "refl", "term": value}


def sym(proof):
    return {"rule": "sym", "proof": proof}


def trans(left, right):
    return {"rule": "trans", "left": left, "right": right}


def congruence(name, proofs):
    return {"rule": "cong", "symbol": name, "proofs": proofs}


def endpoint_lift(symbol, arguments, index, endpoint):
    proofs = [refl(argument) for argument in arguments]
    proofs[index] = endpoint
    return congruence(symbol, proofs)


def make_certificate(controls):
    rows = list(itertools.product([0, 1], repeat=controls))
    constants = [ZERO, ONE]
    parameter = v("p")
    targets = [v("b" + str(i)) for i in range(controls)]
    context = [eq(f("F", *(constants[b] for b in row), parameter),
                  f("G", *(constants[b] for b in row), parameter)) for row in rows]
    context += [eq(f("B", target), target) for target in targets]

    def derive(prefix):
        index = len(prefix)
        if index == controls:
            return {"rule": "hyp", "index": rows.index(tuple(prefix))}
        name = "u" + str(index)
        current = v(name)
        arguments = [constants[bit] for bit in prefix] + [f("B", current)]
        arguments += [f("B", target) for target in targets[index + 1:]] + [parameter]
        matrix = eq(f("F", *arguments), f("G", *arguments))

        def branch(bit):
            point = ZERO if bit == 0 else f("S", current)
            before = arguments.copy()
            before[index] = f("B", point)
            endpoint = {"rule": "B0"} if bit == 0 else {"rule": "BS", "term": current}
            left = endpoint_lift("F", before, index, endpoint)
            right = endpoint_lift("G", before, index, endpoint)
            inner = derive(prefix + [bit])
            return trans(left, trans(inner, sym(right)))

        return {"rule": "EI", "variable": name, "matrix": matrix,
                "at": targets[index], "base": branch(0), "step": branch(1)}

    lifted = derive([])
    replacements = [{"rule": "hyp", "index": len(rows) + i} for i in range(controls)]
    replacements += [refl(parameter)]
    left = congruence("F", replacements)
    right = congruence("G", replacements)
    proof = trans(sym(left), trans(lifted, right))
    return {"description": str(controls) + "-control generic Boolean-table lifting",
            "signature": {"0": 0, "S": 1, "B": 1, "F": controls + 1, "G": controls + 1},
            "context": context, "goal": eq(f("F", *targets, parameter),
                                             f("G", *targets, parameter)), "proof": proof}


def replace(value, mapping):
    if value[0] == "v":
        return mapping.get(value[1], value)
    start = 1 if value[0] == "=" else 2
    return value[:start] + [replace(child, mapping) for child in value[start:]]


def main():
    destination = Path(__file__).resolve().parent / "certificates"
    destination.mkdir(exist_ok=True)
    for number in (1, 2):
        certificate = make_certificate(number)
        (destination / ("table_" + str(number) + ".json")).write_text(
            json.dumps(certificate, indent=2) + "\n")
    original = make_certificate(2)
    mapping = {"b0": f("S", v("a")), "b1": f("B", v("a")), "p": v("a")}
    substituted = {"description": "Finished two-control theorem specialized to dependent actual controls",
                   "signature": original["signature"],
                   "context": [replace(hypothesis, mapping) for hypothesis in original["context"]],
                   "goal": replace(original["goal"], mapping),
                   "proof": {"rule": "subst", "mapping": mapping,
                             "source_context": original["context"], "proof": original["proof"]}}
    (destination / "table_2_specialized.json").write_text(json.dumps(substituted, indent=2) + "\n")
    print(json.dumps({"certificates_written": 3, "directory": str(destination)}))


if __name__ == "__main__":
    main()
