#!/usr/bin/env python3
"""Execute focused positive and adversarial replay controls, in normal/-O modes."""
import copy
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
ZERO = ["f", "0"]


def first_induction(node):
    if isinstance(node, dict):
        if node.get("rule") == "EI":
            return node
        for child in node.values():
            found = first_induction(child)
            if found is not None:
                return found
    elif isinstance(node, list):
        for child in node:
            found = first_induction(child)
            if found is not None:
                return found
    return None


def run(certificate, optimized):
    command = [sys.executable] + (["-O"] if optimized else []) + [str(ROOT / "checker.py")]
    process = subprocess.run(command, input=json.dumps(certificate), text=True,
                             capture_output=True, timeout=15)
    try:
        result = json.loads(process.stdout)
    except json.JSONDecodeError as error:
        raise RuntimeError("checker did not return a receipt") from error
    return process.returncode, result


def main():
    subprocess.run([sys.executable, str(ROOT / "producer.py")], check=True,
                   capture_output=True, text=True)
    examples = [(path.name, json.loads(path.read_text()))
                for path in sorted((ROOT / "certificates").glob("*.json"))]
    positive = []
    for name, certificate in examples:
        for optimized in (False, True):
            code, receipt = run(certificate, optimized)
            if code != 0 or receipt.get("accepted") is not True:
                raise RuntimeError("valid certificate rejected: " + name + ": " + str(receipt))
            positive.append({"file": name, "optimized": optimized, **receipt})

    template = dict(examples)["table_2.json"]
    controls = []

    def altered(name, change):
        value = copy.deepcopy(template)
        change(value)
        controls.append((name, value))

    def bad_freshness(value):
        name = first_induction(value["proof"])["variable"]
        variable = ["v", name]
        value["context"].append(["=", ["f", "B", variable], variable])
    altered("retained_Bool_of_induction_variable", bad_freshness)

    def composite_freshness(value):
        name = first_induction(value["proof"])["variable"]
        successor = ["f", "S", ["v", name]]
        value["context"].append(["=", ["f", "B", successor], successor])
    altered("eigenvariable_inside_retained_composite_term", composite_freshness)
    altered("wrong_induction_step", lambda value: first_induction(value["proof"]).__setitem__(
        "step", {"rule": "refl", "term": ZERO}))

    def wrong_matrix(value):
        node = first_induction(value["proof"])
        node["matrix"][2] = copy.deepcopy(node["matrix"][1])
    altered("changed_induction_matrix", wrong_matrix)
    altered("compound_formula_induction_matrix", lambda value: first_induction(value["proof"]).__setitem__(
        "matrix", ["forall", "x", ["=", ZERO, ZERO]]))

    def target_freshness(value):
        node = first_induction(value["proof"])
        node["at"] = ["v", node["variable"]]
    altered("eigenvariable_in_induction_target", target_freshness)
    altered("changed_exported_conclusion", lambda value: value["goal"].__setitem__(2, ZERO))
    altered("untrusted_table_rule", lambda value: value.__setitem__("proof", {"rule": "table"}))
    altered("changed_fixed_endpoint_signature", lambda value: value["signature"].__setitem__("B", 2))
    changed = copy.deepcopy(dict(examples)["table_2_specialized.json"])
    changed["proof"]["source_context"].append(["=", ZERO, ["f", "S", ZERO]])
    controls.append(("substitution_loses_a_retained_assumption", changed))

    negative = []
    for name, certificate in controls:
        for optimized in (False, True):
            code, receipt = run(certificate, optimized)
            if code == 0 or receipt.get("accepted") is not False:
                raise RuntimeError("invalid certificate accepted: " + name)
            negative.append({"case": name, "optimized": optimized, **receipt})
    output = {"scope": "Generic equational table-lifting and eigenvariable discipline only",
              "not_a_complete_ipra_checker": True,
              "imported_arithmetic_schemas": ["B(0)=0", "B(Sx)=S0"],
              "positive_cli_runs": len(positive), "negative_cli_runs": len(negative),
              "positive": positive, "negative": negative}
    (ROOT / "results.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({key: value for key, value in output.items()
                      if key not in ("positive", "negative")}, indent=2))


if __name__ == "__main__":
    main()
