SCOPED CERTIFICATES FOR THE FINITE BOOLEAN TABLE METARULE
=======================================================

This directory checks one proof-theoretic mechanism used by the paper:
lifting finitely many endpoint equations to algebraic Boolean arguments
without performing an induction under a control-dependent context.

It is NOT a complete iPRA proof checker, NOT a checker-size competitor,
NOT a formal verification of the entire predecessor theorem, and NOT a
replacement for the paper's mathematical proofs. The supplied checker is
itself ordinary unverified Python. Its small diagnostic scope is explicit.

EXACT IMPORTED BASIS
-------------------
Terms use variables and a declared first-order function signature. The
symbols 0, S, and B have fixed arities. The only imported arithmetic
equations are

    B(0)=0,                 B(Sx)=S0.

These endpoint equations are proved in the paper's bare arithmetic theory.
They are trusted schemas here; their proofs are not part of this artifact.
F and G are arbitrary uninterpreted operation symbols. The endpoint
equations F(epsilon,p)=G(epsilon,p) are retained premises, not equations
asserted true without justification. The algebraic Boolean equations
B(b_i)=b_i are also retained premises.

The replay rules are hypothesis, reflexivity, symmetry, transitivity,
function congruence, numerical substitution with explicit context
preservation, the two imported endpoint schemas, and contextual
literal-equation induction. There is NO Boolean-table rule, case-split
rule, general formula induction, numerical evaluation oracle, or truth
test for arbitrary equations.

Every EI node supplies its equation matrix, induction variable, target,
base derivation, and step derivation. The checker verifies that the
induction variable is absent from the entire retained context and the
target. It checks the exact substituted base and successor equations.
The step proof receives exactly one additional equation hypothesis.
Formula-shaped matrices reject. Checks use explicit exceptions rather
than Python assert, so Python -O does not disable them.

WHAT THE CERTIFICATES PROVE
--------------------------
For k=1 and k=2, from all 2^k endpoint equations and B(b_i)=b_i, the
certificates derive F(b_1,...,b_k,p)=G(b_1,...,b_k,p).

Their actual proof trees first derive the equation with B(b_i) as inputs,
using explicit nested endpoint EIs on fresh u_i. Both endpoint branches
rewrite B(0) or B(Su_i) to its numeral. Their induction hypotheses are
unused. Congruence then replaces B(b_i) by b_i. The k=2 proof has three
EI nodes: one outer induction and two inner endpoint inductions.

A third certificate numerically substitutes b_1=S(a), b_2=B(a), and p=a
into the FINISHED k=2 theorem. Its actual controls now depend on a common
parameter; the substitution preserves every retained assumption. This
illustrates the paper's permissible order of operations.

This is a generic operation-symbol instance. Arbitrary fixed numerical
term templates can replace F and G in the mathematical derivation by
uniform term replacement; this artifact does not implement that further
schema expansion. Nor does it check the rho normalization, affine clock,
commutation, predecessor, primitive-recursive compiler, or bi-interpretations.

FILES AND REPRODUCTION
----------------------
checker.py       Independent replay checker; accepts one JSON certificate
                 on stdin and returns a JSON receipt plus exit status.
producer.py      Separate producer. It does not import checker.py.
validate.py      Regenerates certificates and executes focused controls.
certificates/    One-control, two-control, and specialized derivations.
results.json     Actual replay receipts, including all rejection reasons.

Run with Python 3.10+ and its standard library:

    python3 validate.py
    python3 checker.py < certificates/table_2.json

VALIDATION BOUNDARY
------------------
Three positive certificates are run in normal and optimized modes.
Ten altered certificates are likewise run in both modes. Negative cases
include a retained Bool(u) assumption during induction on u; u hidden
inside a retained composite term; a changed step or matrix; a quantified
matrix; u in the target; a changed exported equation; an unsupported
table rule; an altered endpoint-symbol signature; and a substitution
which discards an assumption.

These are focused regression controls for the trust boundary. Finite
accept/reject results do not prove the replay checker correct for every
possible input or mechanically verify the paper's universal metatheorems.
