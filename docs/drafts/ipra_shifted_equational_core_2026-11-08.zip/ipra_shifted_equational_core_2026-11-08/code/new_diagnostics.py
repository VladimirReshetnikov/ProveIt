#!/usr/bin/env python3
"""Reproduce finite transcription diagnostics for the new equational proof.

The numerical source and evaluator in sibling clock/ are unchanged copies of
the successor_clock archive. Their accelerated mode discloses its elementary
helper identities. These checks do not certify equational derivability,
nonstandard-model validity, or the full predecessor proof.

Usage:
    python3 code/new_diagnostics.py
    python3 code/new_diagnostics.py --output evidence/new_diagnostics.json
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys


def run():
    source_dir = Path(__file__).resolve().parent / "clock"
    sys.path.insert(0, str(source_dir))
    from evaluate import Evaluator
    from clock_terms import signature

    evaluator = Evaluator(signature(), accelerated=True, step_limit=10_000_000)
    F, K = evaluator.apply, evaluator.K
    Z = lambda x: F("Z", x)
    parity_control = lambda x: F("N", x + 7)
    # This proof abbreviation is distinct from clock_terms.py's helper e4.
    ell = lambda x: Z(F("cycle4", F("cycle4", x)))
    rho = lambda b, c: K("zero", (1 - b) * c, K("zero", b, 0))
    counts = {}

    def check(label, observed, expected):
        if observed != expected:
            raise AssertionError(
                f"{label}: observed {observed}, expected {expected}"
            )
        counts[label] = counts.get(label, 0) + 1

    for u in range(80):
        b, c = F("N", u), Z(u)
        check(
            "j3_rho",
            F("cycle3", F("cycle3", F("cycle3", u))),
            rho(b, c),
        )
        residue = F("M", u)
        check("M_normal", residue, rho(F("N", residue), Z(residue)))
        check("bT_f", F("b", F("T", u)), F("f", u))

    for d in (0, 1):
        for u in range(30):
            check(
                "GA",
                K("zero", d, K("G", Z(d), u)),
                K("zero", d, F("G", u + 1)),
            )
            check(
                "GB",
                K("zero", d, K("s", d, u)),
                K("zero", d, u + 1),
            )
            check(
                "GC",
                1 + K("zero", d, 18 + F("A3", u)),
                K("H", Z(d), K("zero", d, u)),
            )
            check(
                "GD",
                K("zero", d, 1 + K("H", d, u)),
                K("zero", d, u + 2),
            )
            check(
                "AFF_step_table",
                3 + K("s", d, K("s", d, 17 + F("A3", u))),
                K("s", Z(d), 17 + F("A3", K("s", d, u))),
            )
            check(
                "N_gate",
                F("N", K("zero", d, u)),
                (1 - d) * (1 - F("N", u)),
            )
            check("Z_gate", Z(K("zero", d, u)), d)

    for residue in (0, 1, 2):
        check(
            "ramp_semiconjugacy_table",
            K("cycle4", ell(residue), residue),
            F("cycle3", residue),
        )
        for value in range(20):
            check(
                "ramp_three_table",
                K(
                    "s",
                    ell(F("cycle3", F("cycle3", residue))),
                    K(
                        "s",
                        ell(F("cycle3", residue)),
                        K("s", ell(residue), value),
                    ),
                ),
                value + 4,
            )

    def commutation_table(beta, pi, seed):
        factor, exit_bit = beta * (1 - pi), beta * pi
        left = 1 + K(
            "zero",
            exit_bit,
            K("G", factor, K("H", beta, seed)),
        )
        right = K(
            "H",
            factor,
            K("zero", exit_bit, K("G", factor, seed + 1)),
        )
        return left, right

    for seed in range(50):
        actual_pi = parity_control(seed + 1)
        for beta in (0, 1):
            check(
                "COMM_generic_beta_actual_pi",
                *commutation_table(beta, actual_pi, seed),
            )

    W = lambda counter, seed: K("T", counter, seed)
    for ramp_parameter in range(8):
        for seed_parameter in range(7):
            seed = F("a", seed_parameter)
            observed_state = W(11 + ramp_parameter, seed)
            # The generic observation table retains exactly this hypothesis.
            if F("f", observed_state):
                continue

            def X(control):
                return F(
                    "Psi",
                    W(K("s", control, 9 + ramp_parameter), seed),
                )

            for control in (0, 1):
                check("OBS_BOOL", F("f", X(control)), 0)
            for residue in (0, 1, 2):
                check(
                    "OBS_TABLE",
                    K("s", F("cycle3", residue), F("V", X(ell(residue)))),
                    1 + K("s", residue, F("V", observed_state)),
                )

    # The proof varies beta independently while retaining pi=N(S^2 a).
    # Treating both controls as independent would assert a false equation.
    invalid_left, invalid_right = commutation_table(1, 0, 1)
    if invalid_left == invalid_right:
        raise AssertionError("Expected the overgeneralized control equation to fail")

    sources = {}
    for name in ("clock_terms.py", "evaluate.py"):
        sources[name] = hashlib.sha256((source_dir / name).read_bytes()).hexdigest()
    return {
        "status": "PASS",
        "counts": counts,
        "total_cases": sum(counts.values()),
        "scope": (
            "Finite standard-model transcription diagnostics only; "
            "not a proof certificate for the full equational theorem."
        ),
        "evaluation": (
            "Unchanged staged source evaluator, accelerated only by its "
            "disclosed inherited elementary helper identities."
        ),
        "negative_control": {
            "claim": "The COMM table cannot vary both beta and pi independently.",
            "beta": 1,
            "pi": 0,
            "seed": 1,
            "actual_pi": parity_control(2),
            "left": invalid_left,
            "right": invalid_right,
            "expected": "inequality",
            "status": "PASS",
        },
        "source_sha256": sources,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = run()
    rendered = json.dumps(result, indent=2) + "\n"
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered)
    print(rendered, end="")


if __name__ == "__main__":
    main()

