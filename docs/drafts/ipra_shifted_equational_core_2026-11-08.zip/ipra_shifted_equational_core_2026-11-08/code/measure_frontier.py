#!/usr/bin/env python3
"""Reproduce the inherited whole-program comparison without running comparators."""
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import platform

ROOT = Path(__file__).resolve().parents[1]
REFERENCE = ROOT / "reference"
FIELDS = ("normalized_tokens", "ast_nodes", "normalized_bytes")


def run():
    manifest = json.loads((REFERENCE / "comparator_manifest.json").read_text())
    source = REFERENCE / "source_measure.py"
    if hashlib.sha256(source.read_bytes()).hexdigest() != manifest["normalizer_sha256"]:
        raise ValueError("The inherited normalizer has changed")
    spec = importlib.util.spec_from_file_location("inherited_source_measure", source)
    normalizer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(normalizer)
    rows = []
    for entry in manifest["programs"]:
        path = REFERENCE / "checkers" / entry["file"]
        measured = normalizer.metrics(path)
        if measured["sha256"] != entry["sha256"]:
            raise ValueError("Changed comparator: " + entry["file"])
        rows.append({"file": entry["file"], **measured})
    envelope = {key: min(row[key] for row in rows) for key in FIELDS}
    if envelope != dict(zip(FIELDS, (312, 347, 878))):
        raise ValueError("Different comparison profile: " + repr(envelope))
    result = {
        "status": "PASS",
        "scope": "Complete retained source programs, normalized and measured; not executed.",
        "commit": json.loads((ROOT / "evidence/source_snapshot.json").read_text())["commit"],
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "program_count": len(rows),
        "normalizer_sha256": manifest["normalizer_sha256"],
        "coordinatewise_minimum": envelope,
        "minimum_attainers": {
            key: [row["file"] for row in rows if row[key] == envelope[key]]
            for key in FIELDS
        },
        "new_complete_checker_supplied": False,
        "programs": rows,
    }
    evidence = ROOT / "evidence"
    evidence.mkdir(exist_ok=True)
    (evidence / "comparator_measurements.json").write_text(json.dumps(result, indent=2) + "\n")
    with (evidence / "comparator_measurements.csv").open("w", newline="") as stream:
        fields = ("file", "source_tokens", *FIELDS, "raw_bytes", "sha256")
        writer = csv.DictWriter(stream, fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({key: value for key, value in result.items() if key != "programs"}, indent=2))


if __name__ == "__main__":
    run()
