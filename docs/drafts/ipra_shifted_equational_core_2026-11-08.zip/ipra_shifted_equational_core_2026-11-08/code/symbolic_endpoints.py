#!/usr/bin/env python3
"""Check selected finite-table endpoints as symbolic equations.

Free parameters remain formal variables, not sampled integers. The normalizer
uses only the explicit recurrence/definition list reported in the output and
a Boolean unit law guarded by a known Boolean-valued expression. G is opaque.

This is a relative endpoint checker. It does not check the complete induction
ledger, prove the imported recurrences, or certify the full retraction theorem.
"""
import argparse
import json
from pathlib import Path


def S(x, count=1):
    for _ in range(count):
        x = ("S", x)
    return x


def F(name, x):
    return ("F", name, x)


def K(name, n, a):
    return ("K", name, n, a)


def And(x, y):
    return ("And", x, y)


def Z(x):
    return F("Z", x)


def ell(x):
    return Z(F("h4", F("h4", x)))


def known_boolean(t):
    if type(t) is int:
        return t in (0, 1)
    if type(t) is not tuple:
        return False
    if len(t) == 3 and t[0] == "F":
        return t[1] in ("Z", "N")
    if len(t) == 3 and t[0] == "And":
        return known_boolean(t[1]) and known_boolean(t[2])
    return False


UPDATES = {"id", "zero", "s", "G", "H", "j", "h4"}
FUNCTIONS = UPDATES | {"A3", "D", "Z", "N", "M"}


def normal(t):
    if type(t) is int:
        if t < 0:
            raise ValueError("negative numeral")
        return t
    if type(t) is str:
        if t not in ("x", "a", "v"):
            raise ValueError("unknown formal parameter")
        return t
    if type(t) is not tuple or not t:
        raise ValueError("malformed term")
    if t[0] == "S" and len(t) == 2:
        x = normal(t[1])
        return x + 1 if type(x) is int else ("S", x)
    if t[0] == "K" and len(t) == 4:
        name = t[1]
        if name not in UPDATES:
            raise ValueError("unknown update")
        n, a = normal(t[2]), normal(t[3])
        if type(n) is int:
            if n == 0:
                return normal(S(a))
            return normal(F(name, K(name, n - 1, a)))
        if type(n) is tuple and n[0] == "S":
            return normal(F(name, K(name, n[1], a)))
        return ("K", name, n, a)
    if t[0] == "F" and len(t) == 3:
        name, x = t[1], normal(t[2])
        if name not in FUNCTIONS:
            raise ValueError("unknown function")
        if name == "id":
            return x
        if name == "zero":
            return 0
        if name == "s":
            return normal(S(x))
        if name == "H":
            return normal(S(F("A3", x), 14))
        if name == "Z":
            if type(x) is int:
                return int(x == 0)
            if type(x) is tuple and x[0] == "S":
                return 0
        if name in ("D", "A3", "N", "M"):
            if type(x) is int and x == 0:
                return 0
            previous = None
            if type(x) is int and x > 0:
                previous = x - 1
            elif type(x) is tuple and x[0] == "S":
                previous = x[1]
            if previous is not None:
                old = F(name, previous)
                if name == "D":
                    return normal(S(old, 2))
                if name == "A3":
                    return normal(S(old, 3))
                if name == "N":
                    return normal(Z(old))
                if name == "M":
                    return normal(F("j", old))
        if name == "j" and type(x) is int and x in (0, 1, 2):
            return (1, 2, 0)[x]
        if name == "h4" and type(x) is int and x in (0, 1, 2, 3):
            return (1, 2, 3, 0)[x]
        # G is intentionally opaque, even at numeral arguments.
        return ("F", name, x)
    if t[0] == "And" and len(t) == 3:
        x, y = normal(t[1]), normal(t[2])
        if x == 0 or y == 0:
            return 0
        if x == 1 and known_boolean(y):
            return y
        if y == 1 and known_boolean(x):
            return x
        return ("And", x, y)
    raise ValueError("malformed constructor or arity")


def parameters(t):
    if type(t) is str:
        return {t}
    if type(t) is int:
        return set()
    if t[0] == "S":
        children = t[1:]
    elif t[0] in ("K", "F"):
        children = t[2:]
    else:
        children = t[1:]
    found = set()
    for child in children:
        found |= parameters(child)
    return found


def equations():
    cases = []
    for d in (0, 1):
        cases.extend([
            ("GA", {"d": d},
             K("zero", d, K("G", Z(d), "x")),
             K("zero", d, F("G", S("x")))),
            ("GB", {"d": d},
             K("zero", d, K("s", d, "x")),
             K("zero", d, S("x"))),
            ("GC", {"d": d},
             S(K("zero", d, S(F("A3", "v"), 18))),
             K("H", Z(d), K("zero", d, "v"))),
            ("GD", {"d": d},
             K("zero", d, S(K("H", d, "a"))),
             K("zero", d, S("a", 2))),
            ("AFF_step", {"b": d},
             S(K("s", d, K("s", d, S(F("A3", "v"), 17))), 3),
             K("s", Z(d), S(F("A3", K("s", d, "v")), 17))),
            ("G_two", {"b": d},
             K("s", Z(d), K("s", d, "v")),
             S("v", 3)),
            ("N_gate", {"d": d},
             F("N", K("zero", d, "x")),
             And(Z(d), Z(F("N", "x")))),
            ("Z_gate", {"d": d},
             Z(K("zero", d, "x")),
             d),
            ("j_on_Boolean", {"b": d}, F("j", d), S(d)),
            ("Kj_diagonal", {"b": d}, K("j", d, d), Z(d)),
        ])
    for b in (0, 1):
        for c in (0, 1):
            alpha = And(Z(b), Z(c))
            beta = And(Z(b), c)
            cases.append((
                "rho_normalization",
                {"b": b, "c": c},
                K("zero", beta, K("zero", b, K("zero", alpha, "x"))),
                K("zero", beta, K("zero", b, 0)),
            ))
    for q in (0, 1, 2):
        cases.extend([
            ("ramp_semiconjugacy", {"q": q},
             K("h4", ell(q), q), F("j", q)),
            ("ramp_three", {"q": q},
             K("s", ell(F("j", F("j", q))),
               K("s", ell(F("j", q)), K("s", ell(q), "v"))),
             S("v", 4)),
            ("doubling_residue", {"q": q},
             F("j", F("j", F("M", F("D", q)))),
             F("M", F("D", F("j", q)))),
        ])
    return cases


def run():
    records = []
    for name, endpoint, left, right in equations():
        left_normal, right_normal = normal(left), normal(right)
        if left_normal != right_normal:
            raise AssertionError((name, endpoint, left_normal, right_normal))
        records.append({
            "identity": name,
            "endpoint": endpoint,
            "formal_parameters": sorted(parameters(left) | parameters(right)),
            "left": left,
            "right": right,
            "common_normal_form": left_normal,
            "status": "ACCEPT",
        })

    mutations = [
        ("GA_omitted_successor",
         K("zero", 0, K("G", 1, "x")),
         K("zero", 0, F("G", "x"))),
        ("GB_omitted_successor",
         K("zero", 0, K("s", 0, "x")),
         K("zero", 0, "x")),
        ("GC_offset_18_changed_to_17",
         S(K("zero", 0, S(F("A3", "v"), 17))),
         K("H", 1, K("zero", 0, "v"))),
        ("GD_offset_2_changed_to_1",
         K("zero", 0, S(K("H", 0, "a"))),
         K("zero", 0, S("a"))),
        ("AFF_one_offset_changed",
         S(K("s", 0, K("s", 0, S(F("A3", "v"), 16))), 3),
         K("s", 1, S(F("A3", K("s", 0, "v")), 17))),
        ("rho_wrong_outer_gate",
         K("zero", 1, K("zero", 0, K("zero", 1, "x"))),
         K("zero", 0, K("zero", 0, 0))),
        ("ramp_wrong_total_increment",
         K("s", 1, K("s", 0, K("s", 0, "v"))),
         S("v", 3)),
        ("Boolean_unit_without_Boolean_hypothesis",
         And(1, "x"), "x"),
    ]
    rejected_mutations = []
    for name, left, right in mutations:
        if normal(left) == normal(right):
            raise AssertionError(f"changed identity unexpectedly accepted: {name}")
        rejected_mutations.append(name)

    malformed = [
        ("boolean_as_numeral", True),
        ("nested_boolean_as_numeral", ("K", "zero", True, "x")),
        ("negative_numeral", -1),
        ("wrong_successor_arity", ("S", "x", "v")),
        ("undeclared_update", ("K", "unknown", 0, "x")),
        ("mutable_term_container", ["S", "x"]),
    ]
    rejected_malformed = []
    for name, term in malformed:
        try:
            normal(term)
        except (ValueError, TypeError):
            rejected_malformed.append(name)
        else:
            raise AssertionError(f"malformed term unexpectedly accepted: {name}")

    return {
        "status": "PASS",
        "scope": (
            "Relative symbolic verification of selected finite endpoints. "
            "Formal parameters remain variables; no finite numeric sampling "
            "of them is used. This does not mechanize the full E_K proof."
        ),
        "imported_equations": [
            "K_h(0,a)=S(a); K_h(Sn,a)=h(K_h(n,a))",
            "id(x)=x; zero(x)=0; s(x)=S(x)",
            "Z(0)=1; Z(Sx)=0",
            "N(0)=0; N(Sx)=Z(N(x))",
            "M(0)=0; M(Sx)=j(M(x))",
            "D(0)=0; D(Sx)=S^2(D(x))",
            "A3(0)=0; A3(Sx)=S^3(A3(x))",
            "H(x)=S^14(A3(x))",
            "j(0)=1; j(1)=2; j(2)=0",
            "h4(0)=1; h4(1)=2; h4(2)=3; h4(3)=0",
            "And(0,x)=And(x,0)=0",
            "And(1,b)=And(b,1)=b for known algebraic Booleans b",
            "Every value Z(x), N(x), and And of known Booleans is algebraically Boolean",
        ],
        "opaque_symbols": ["G"],
        "symbolic_endpoint_cases": len(records),
        "changed_identities_rejected": len(rejected_mutations),
        "malformed_terms_rejected": len(rejected_malformed),
        "records": records,
        "negative_controls": {
            "changed_identities": rejected_mutations,
            "malformed_terms": rejected_malformed,
        },
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = run()
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({
        key: report[key] for key in (
            "status", "symbolic_endpoint_cases",
            "changed_identities_rejected", "malformed_terms_rejected", "scope"
        )
    }, indent=2))


if __name__ == "__main__":
    main()

