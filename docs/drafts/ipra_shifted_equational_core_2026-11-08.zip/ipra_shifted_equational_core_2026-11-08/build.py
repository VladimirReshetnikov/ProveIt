#!/usr/bin/env python3
"""Build the report with shell escape disabled."""
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
for _ in range(3):
    subprocess.run(["pdflatex", "-no-shell-escape", "-interaction=nonstopmode", "-halt-on-error", "report.tex"], cwd=ROOT, check=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
print(ROOT / "report.pdf")

