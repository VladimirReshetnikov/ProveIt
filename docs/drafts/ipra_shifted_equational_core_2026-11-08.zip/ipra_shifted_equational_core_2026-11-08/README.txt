SHIFTED ITERATION WITHOUT BOOLEAN BRANCHING
=========================================
A bare equational predecessor theorem and a smaller native signature for iPRA
Research report prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific)

READ FIRST
----------
report.pdf is the complete mathematical report. report.tex and sections/
are its editable LaTeX source. Section 3 proves the new bare equational
predecessor theorem; Section 4 states the complete native theory and its
bi-interpretation with full iPRA; Section 5 states the exact boundary.

The new result removes Boolean range and falsity from the successor-clock
predecessor proof. It makes a native numerical signature with only 0 and
closed unary shifted iteration available before ordinary logical macros
are reconstructed. The predecessor term and clock are inherited; the
stronger equational proof and its native integration are new relative to
the pinned corpus. No literature-wide priority or global minimum is claimed.

The strict requested implementation-size reduction remains OPEN. There is
no new complete proof checker smaller than the reproduced coordinatewise
envelope of 312 normalized tokens / 347 AST nodes / 878 normalized bytes.
Different retained programs attain these minima. The evidence checkers in
this archive have narrower scopes and are not size competitors for iPRA.

SOURCE SNAPSHOT AND ATTRIBUTION
-------------------------------
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 4890fd00a5cacfc9881ae282120978f95c3ba392
Directory: docs/drafts

All sixteen active source archives were downloaded and their Git blob
identities verified during the investigation. evidence/source_snapshot.json
records their paths, sizes, SHA-256 hashes, Git blob hashes, and pinned URLs.
Four unchanged source archives are bundled in reference/ because the new
report uses their clock, internal primitive-recursive reconstruction,
direct logical compiler, and equational conservation theorem. All seventeen
compact comparison programs and the original normalizer are also retained.
ATTRIBUTION.txt and the inherited license files state the contribution boundary.

REPRODUCTION
------------
Requires Python 3.10+ with its standard library. The recorded normalized
source metrics were reproduced under Python 3.12. AST normalization can
change between Python versions; a different envelope fails explicitly.
From this directory run:

    python3 reproduce.py

This verifies the four bundled source archives against the pinned Git
identities; compares inherited source files byte for byte with the original
clock archive; remeasures the seventeen complete comparison programs without
executing them; replays the finite-table certificates in ordinary and
optimized Python; reruns symbolic endpoint checks; and reruns inherited
and new finite arithmetic diagnostics. Receipts are written to evidence/.

With a standard TeX Live installation:

    python3 build.py

This runs pdflatex three times with shell escape disabled. The document
uses standard packages, including amsmath, amsthm, mathtools, microtype,
booktabs, longtable, enumitem, fancyhdr, needspace, and hyperref.

To update file hashes and create the ZIP in the parent directory:

    python3 package.py

SHA256SUMS lists all delivered payload files except itself. TeX build
intermediates and Python caches are excluded. No network is needed for
any of these commands. Rebuilding a PDF can change metadata and file bytes.

WHAT THE CHECKS ESTABLISH
------------------------
1. code/table_metarule/ has a separate certificate producer and replay
   checker. It checks actual equation-induction proof trees, not an oracle
   for finite tables. It imports exactly B(0)=0 and B(Sx)=S0, whose proofs
   appear in the report. It verifies the one- and two-control generic
   lifting mechanism and legal specialization to dependent controls.
   Results: 6 positive command-line runs and 20 rejected negative runs.

2. code/symbolic_endpoints.py checks 33 finite endpoint equations while
   arbitrary numerical parameters remain formal variables. Its imported
   recurrences are listed in evidence/symbolic_endpoints.json. Eight
   changed identities and six malformed terms reject. It does not check
   the surrounding induction proofs or the entire predecessor argument.

3. code/new_diagnostics.py performs 1,103 finite numerical transcription
   checks. A negative control exposes a false strengthening that varies
   the clock's parity control independently of its numerical seed.

4. code/clock/ is an unchanged inherited finite-description validator and
   evaluator. It provides direct source evaluation, exact cycle skipping,
   and an explicitly disclosed accelerated mode. Its source README states
   every acceleration. The final predecessor is not replaced by an oracle.
   These finite checks do not establish universal derivability.

5. The written mathematical argument received independent adversarial
   review; those audit notes are retained under evidence/. This is not
   an externally verified Lean/Rocq development or a correctness proof of
   the Python evidence tools for all possible inputs.

ARTIFACT MAP
------------
report.pdf, report.tex, sections/  Complete report and LaTeX source
code/                            Scoped reproducible evidence
evidence/                        Executed receipts, source manifest, audits
reference/                       Unchanged dependencies and comparator sources
reproduce.py                     One-command evidence reproduction
build.py                         PDF compilation
package.py                       Integrity manifest and ZIP creation
SHA256SUMS                       Final payload hashes
