#!/usr/bin/env python3
"""Reproduce the explicitly scoped evidence. Python standard library only."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "evidence"


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def source_integrity():
    snapshot = json.loads((EVIDENCE / "source_snapshot.json").read_text())
    names = {item["name"]: item for item in snapshot["archives"]}
    receipts = []
    for path in sorted((ROOT / "reference").glob("*.zip")):
        expected = names[path.name]
        data = path.read_bytes()
        git_blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        if (len(data) != expected["bytes"] or sha256(data) != expected["sha256"]
                or git_blob != expected["git_blob_sha"]):
            raise ValueError("Source archive differs from pinned Git blob: " + path.name)
        with zipfile.ZipFile(path) as archive:
            damaged = archive.testzip()
            if damaged is not None:
                raise ValueError("Damaged source ZIP member: " + damaged)
        receipts.append({"file": path.name, "bytes": len(data), "sha256": sha256(data),
                         "git_blob_sha": git_blob, "status": "PASS"})
    clock_archive = ROOT / "reference/ipra_successor_clock_2026-11-09.zip"
    copied = []
    with zipfile.ZipFile(clock_archive) as archive:
        for relative, member in json.loads((ROOT / "reference/copied_source_manifest.json").read_text()).items():
            if (ROOT / relative).read_bytes() != archive.read(member):
                raise ValueError("Copied source changed: " + relative)
            copied.append(relative)
    result = {"status": "PASS", "commit": snapshot["commit"],
              "source_archives_verified": receipts, "unchanged_copied_sources": copied,
              "scope": "Four bundled source archives and copied clock/comparison files; the manifest records all sixteen inspected archives."}
    (EVIDENCE / "source_integrity.json").write_text(json.dumps(result, indent=2) + "\n")
    print("Pinned source identities: PASS", flush=True)
    return result


def main():
    EVIDENCE.mkdir(exist_ok=True)
    source_integrity()
    commands = [
        ["code/measure_frontier.py"],
        ["code/table_metarule/validate.py"],
        ["code/symbolic_endpoints.py", "--output", "evidence/symbolic_endpoints.json"],
        ["code/clock/evaluate.py", "--output", "evidence/inherited_clock_diagnostics.json"],
        ["code/new_diagnostics.py", "--output", "evidence/new_diagnostics.json"],
    ]
    executions = []
    for command in commands:
        print("Running " + " ".join(command), flush=True)
        completed = subprocess.run([sys.executable, *command], cwd=ROOT, check=True,
                                   text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        print(completed.stdout, end="", flush=True)
        executions.append({"command": ["python3", *command], "exit_code": completed.returncode})
    receipt = {
        "status": "PASS", "python": sys.version, "executions": executions,
        "scope": "Reproducible source identity, measurement, scoped certificates, and diagnostics; not a mechanization of the complete mathematical proof.",
        "complete_checker_size_record_claimed": False,
    }
    (EVIDENCE / "reproduction.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print("All scoped reproduction checks: PASS")


if __name__ == "__main__":
    main()
