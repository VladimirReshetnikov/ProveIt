#!/usr/bin/env python3
"""A finite-description compiler for the initial-value presentation of PRA.

The SOURCE language permits ordinary primitive recursion with an arbitrary
base term and arbitrarily many frozen numerical parameters. The TARGET has
only zero, successor, variables, and binary initial-value recursors

    I_h(0, a) = a,     I_h(n + 1, a) = h(n, I_h(n, a)).

Every target transition has free variables contained in {n, v}, and may call
only previously declared target symbols. In particular, the initial value a
is NOT available as a separate transition variable.

All target arithmetic, pairing, unpairing, and compiled programs are evaluated
from these recursion equations. Native Python pairing, subtraction, addition,
or multiplication is not substituted for any target program. The interpreter
uses Python addition only to implement the primitive successor and to manage
its finite loop/cache bookkeeping.

This is an executable finite check of the syntactic translation and selected
standard-natural-number evaluations. It is NOT a proof assistant or a proof
of the universal equivalence theorem. See the accompanying paper for that
proof and test_initial_value_compiler.py for the bounded verification suite.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from functools import cache
from typing import Mapping, Sequence


@dataclass(frozen=True)
class Term:
    kind: str
    name: str = ""
    args: tuple["Term", ...] = ()


ZERO = Term("zero")


def var(name: str) -> Term:
    return Term("var", name)


def succ(term: Term) -> Term:
    return Term("succ", args=(term,))


ONE = succ(ZERO)


def call(name: str, *args: Term) -> Term:
    return Term("call", name, tuple(args))


@cache
def free_vars(term: Term) -> frozenset[str]:
    if term.kind == "var":
        return frozenset((term.name,))
    return frozenset().union(*(free_vars(arg) for arg in term.args))


@cache
def references(term: Term) -> frozenset[str]:
    here = frozenset((term.name,)) if term.kind == "call" else frozenset()
    return here.union(*(references(arg) for arg in term.args))


def substitute(term: Term, replacements: Mapping[str, Term]) -> Term:
    if term.kind == "var":
        return replacements.get(term.name, term)
    if not term.args:
        return term
    return Term(term.kind, term.name,
                tuple(substitute(arg, replacements) for arg in term.args))


def validate_term(term: Term, variables: frozenset[str],
                  arities: Mapping[str, int]) -> None:
    if not isinstance(term, Term):
        raise ValueError("A term must be an immutable Term object")
    if term.kind == "zero":
        if term.args or term.name:
            raise ValueError("Zero has no arguments or name")
    elif term.kind == "var":
        if term.args or term.name not in variables:
            raise ValueError(f"Variable outside the permitted context: {term.name}")
    elif term.kind == "succ":
        if term.name or len(term.args) != 1:
            raise ValueError("Successor has exactly one argument and no name")
    elif term.kind == "call":
        if term.name not in arities:
            raise ValueError(f"Unknown, forward, or recursive reference: {term.name}")
        if len(term.args) != arities[term.name]:
            raise ValueError(f"Wrong arity for {term.name}")
    else:
        raise ValueError(f"Unknown term constructor: {term.kind}")
    for arg in term.args:
        validate_term(arg, variables, arities)


def _natural(value: int) -> None:
    if type(value) is not int or value < 0:
        raise ValueError("Arguments must be nonnegative integers")


@dataclass(frozen=True)
class InitialValueDescription:
    name: str
    update: Term


class TargetProgram:
    """A well-founded list of strictly binary initial-value descriptions."""

    def __init__(self, step_limit: int = 8_000_000) -> None:
        self.descriptions: dict[str, InitialValueDescription] = {}
        self.prefixes: dict[tuple[str, int], list[int]] = {}
        self.steps = Counter()
        self.step_limit = step_limit
        self.total_steps = 0

    @property
    def arities(self) -> dict[str, int]:
        return {name: 2 for name in self.descriptions}

    def declare(self, name: str, update: Term) -> None:
        if name in self.descriptions:
            raise ValueError(f"Duplicate target description: {name}")
        # Validation precedes insertion, so self and forward references fail.
        validate_term(update, frozenset(("n", "v")), self.arities)
        self.descriptions[name] = InitialValueDescription(name, update)

    def validate_all(self) -> None:
        earlier: dict[str, int] = {}
        for name, description in self.descriptions.items():
            validate_term(description.update, frozenset(("n", "v")), earlier)
            earlier[name] = 2

    def evaluate(self, term: Term, environment: Mapping[str, int] | None = None) -> int:
        env = {} if environment is None else dict(environment)
        validate_term(term, frozenset(env), self.arities)
        for value in env.values():
            _natural(value)
        return self._term(term, tuple(sorted(env.items())))

    def _term(self, term: Term, environment: tuple[tuple[str, int], ...]) -> int:
        if term.kind == "zero":
            return 0
        if term.kind == "var":
            return dict(environment)[term.name]
        # Project away unused variables before memoization. In particular,
        # evaluating p(v) must not retain a separate entry for each unused n.
        # This changes only caching, not the equations used for evaluation.
        needed = free_vars(term)
        reduced = tuple((name, value) for name, value in environment if name in needed)
        return self._cached_term(term, reduced)

    @cache
    def _cached_term(self, term: Term, environment: tuple[tuple[str, int], ...]) -> int:
        if term.kind == "succ":
            return self._term(term.args[0], environment) + 1
        args = tuple(self._term(arg, environment) for arg in term.args)
        return self.evaluate_call(term.name, *args)

    def evaluate_call(self, name: str, index: int, initial: int) -> int:
        _natural(index)
        _natural(initial)
        if name not in self.descriptions:
            raise ValueError(f"Unknown target description: {name}")
        # Cache entire prefixes. Each new entry is obtained by exactly one
        # application of the declared update term to (index, previous value).
        values = self.prefixes.setdefault((name, initial), [initial])
        update = self.descriptions[name].update
        while len(values) <= index:
            if self.total_steps >= self.step_limit:
                raise RuntimeError("Finite evaluation step budget exceeded")
            stage = len(values) - 1
            self.total_steps += 1
            self.steps[name] += 1
            values.append(self._term(update, (("n", stage), ("v", values[-1]))))
        return values[index]

    def statistics(self) -> dict:
        return {
            "descriptions": len(self.descriptions),
            "recursor_steps": self.total_steps,
            "steps_by_description": dict(sorted(self.steps.items())),
            "cached_initial_states": len(self.prefixes),
            "cached_prefix_values": sum(map(len, self.prefixes.values())),
            "term_cache_entries": self._cached_term.cache_info().currsize,
        }


class Arithmetic:
    """Term abbreviations; none of these methods evaluates native arithmetic."""

    def __init__(self, program: TargetProgram) -> None:
        self.program = program
        n, v = var("n"), var("v")
        program.declare("P", n)
        program.declare("B", ZERO)
        program.declare("A", succ(v))
        program.declare("M", self.pred(v))
        program.declare("U", self.add(v, succ(n)))
        program.declare("V", self.choose(
            self.delta(succ(n), self.triangle(succ(v))), succ(v), v))

    @staticmethod
    def pred(n: Term) -> Term:
        return call("P", n, ZERO)

    @staticmethod
    def gate(n: Term, a: Term) -> Term:
        return call("B", n, a)

    @staticmethod
    def add(x: Term, y: Term) -> Term:
        return call("A", x, y)

    @staticmethod
    def alpha(x: Term, y: Term) -> Term:
        """The term with intended value max(y - x, 0)."""
        return call("M", x, y)

    def choose(self, x: Term, u: Term, v: Term) -> Term:
        return self.add(self.gate(x, u), self.gate(self.gate(x, ONE), v))

    def delta(self, x: Term, y: Term) -> Term:
        return self.choose(self.alpha(x, y), self.alpha(y, x), ONE)

    @staticmethod
    def triangle(n: Term) -> Term:
        return call("U", n, ZERO)

    @staticmethod
    def diagonal(n: Term) -> Term:
        return call("V", n, ZERO)

    def pair(self, x: Term, y: Term) -> Term:
        return self.add(self.triangle(self.add(x, y)), y)

    def right(self, z: Term) -> Term:
        return self.alpha(self.triangle(self.diagonal(z)), z)

    def left(self, z: Term) -> Term:
        return self.alpha(self.right(z), self.diagonal(z))

    def tuple_code(self, elements: Sequence[Term]) -> Term:
        result = ZERO
        for element in reversed(elements):
            result = self.pair(element, result)
        return result

    def projection(self, code: Term, index: int) -> Term:
        if index < 0:
            raise ValueError("Tuple projection uses a nonnegative index")
        for _ in range(index):
            code = self.right(code)
        return self.left(code)


@dataclass(frozen=True)
class SourceDescription:
    name: str
    parameters: int
    base: Term
    update: Term


class SourceProgram:
    """Ordinary PR descriptions, with base context p0,... and step n,v,p0,..."""

    def __init__(self) -> None:
        self.descriptions: dict[str, SourceDescription] = {}
        self.prefixes: dict[tuple[str, tuple[int, ...]], list[int]] = {}

    @property
    def arities(self) -> dict[str, int]:
        return {name: d.parameters + 1 for name, d in self.descriptions.items()}

    def declare(self, name: str, parameters: int, base: Term, update: Term) -> None:
        if name in self.descriptions or type(parameters) is not int or parameters < 0:
            raise ValueError("A source declaration needs a fresh name and valid arity")
        context = frozenset(f"p{i}" for i in range(parameters))
        validate_term(base, context, self.arities)
        validate_term(update, context | {"n", "v"}, self.arities)
        self.descriptions[name] = SourceDescription(name, parameters, base, update)

    @cache
    def _term(self, term: Term, environment: tuple[tuple[str, int], ...]) -> int:
        if term.kind == "zero":
            return 0
        if term.kind == "var":
            return dict(environment)[term.name]
        if term.kind == "succ":
            return self._term(term.args[0], environment) + 1
        args = tuple(self._term(arg, environment) for arg in term.args)
        return self.evaluate_call(term.name, *args)

    def evaluate_call(self, name: str, index: int, *parameters: int) -> int:
        description = self.descriptions[name]
        if len(parameters) != description.parameters:
            raise ValueError("Wrong source call arity")
        for value in (index, *parameters):
            _natural(value)
        fixed = {f"p{i}": value for i, value in enumerate(parameters)}
        key = (name, parameters)
        if key not in self.prefixes:
            self.prefixes[key] = [self._term(description.base, tuple(sorted(fixed.items())))]
        values = self.prefixes[key]
        while len(values) <= index:
            env = {**fixed, "n": len(values) - 1, "v": values[-1]}
            values.append(self._term(description.update, tuple(sorted(env.items()))))
        return values[index]


@dataclass(frozen=True)
class CompiledDescription:
    name: str
    parameters: int
    recursor: str
    value: Term
    state: Term
    frame: Term


class Compiler:
    """Compile each source recursor into one restricted target recursor."""

    def __init__(self, source: SourceProgram, target: TargetProgram,
                 arithmetic: Arithmetic) -> None:
        self.source = source
        self.target = target
        self.arithmetic = arithmetic
        self.compiled: dict[str, CompiledDescription] = {}

    def translate(self, term: Term, environment: Mapping[str, Term]) -> Term:
        if term.kind == "zero":
            return ZERO
        if term.kind == "var":
            return environment[term.name]
        if term.kind == "succ":
            return succ(self.translate(term.args[0], environment))
        previous = self.compiled[term.name]
        args = [self.translate(arg, environment) for arg in term.args]
        substitutions = {"n": args[0]}
        substitutions.update({f"p{i}": arg for i, arg in enumerate(args[1:])})
        return substitute(previous.value, substitutions)

    def compile_all(self) -> None:
        for name, description in self.source.descriptions.items():
            if name in self.compiled:
                continue
            ar = self.arithmetic
            # The sole evolving variable v holds J(previous result, frame).
            index, state = var("n"), var("v")
            frame = ar.right(state)
            env = {"n": index, "v": ar.left(state)}
            env.update({f"p{i}": ar.projection(frame, i)
                        for i in range(description.parameters)})
            update = ar.pair(self.translate(description.update, env), frame)
            recursor = f"compiled_{name}"
            self.target.declare(recursor, update)

            parameters = tuple(var(f"p{i}") for i in range(description.parameters))
            code = ar.tuple_code(parameters)
            base_env = {f"p{i}": ar.projection(code, i)
                        for i in range(description.parameters)}
            initial = ar.pair(self.translate(description.base, base_env), code)
            state_term = call(recursor, index, initial)
            value_term = ar.left(state_term)
            context = frozenset(("n", *(f"p{i}" for i in range(description.parameters))))
            validate_term(value_term, context, self.target.arities)
            self.compiled[name] = CompiledDescription(
                name, description.parameters, recursor, value_term, state_term, code)

    def evaluate(self, name: str, index: int, *parameters: int) -> int:
        description = self.compiled[name]
        if len(parameters) != description.parameters:
            raise ValueError("Wrong compiled function arity")
        env = {"n": index, **{f"p{i}": a for i, a in enumerate(parameters)}}
        return self.target.evaluate(description.value, env)


@dataclass(frozen=True)
class Formula:
    kind: str
    parts: tuple["Formula", ...] = ()
    terms: tuple[Term, ...] = ()


def equal(left: Term, right: Term) -> Formula:
    return Formula("eq", terms=(left, right))


def connective(kind: str, *parts: Formula) -> Formula:
    return Formula(kind, tuple(parts))


def formula_error(formula: Formula, ar: Arithmetic) -> Term:
    """Compile a finite QF formula to the paper's zero-for-true error term."""
    if formula.kind == "eq" and len(formula.terms) == 2 and not formula.parts:
        return ar.delta(*formula.terms)
    if formula.terms:
        raise ValueError("Only equality atoms have term arguments")
    if formula.kind in {"top", "bottom"} and not formula.parts:
        return ZERO if formula.kind == "top" else ONE
    if formula.kind == "not" and len(formula.parts) == 1:
        return ar.choose(formula_error(formula.parts[0], ar), ONE, ZERO)
    if formula.kind in {"and", "or", "implies"} and len(formula.parts) == 2:
        a, b = (formula_error(part, ar) for part in formula.parts)
        if formula.kind == "and":
            return ar.choose(a, b, ONE)
        if formula.kind == "or":
            return ar.choose(a, ZERO, b)
        return ar.choose(a, b, ZERO)
    raise ValueError("Malformed quantifier-free formula")


def formula_truth(formula: Formula, target: TargetProgram,
                  environment: Mapping[str, int]) -> bool:
    """Independent ordinary finite truth-table evaluation for the tests."""
    if formula.kind == "eq":
        return (target.evaluate(formula.terms[0], environment)
                == target.evaluate(formula.terms[1], environment))
    if formula.kind == "top":
        return True
    if formula.kind == "bottom":
        return False
    values = [formula_truth(part, target, environment) for part in formula.parts]
    if formula.kind == "not":
        return not values[0]
    if formula.kind == "and":
        return values[0] and values[1]
    if formula.kind == "or":
        return values[0] or values[1]
    if formula.kind == "implies":
        return (not values[0]) or values[1]
    raise ValueError("Unknown formula constructor")


def example_source() -> SourceProgram:
    """Examples include two genuinely frozen parameters and nontrivial bases."""
    source = SourceProgram()
    n, v, a, b = var("n"), var("v"), var("p0"), var("p1")
    source.declare("addition", 1, a, succ(v))
    source.declare("multiplication", 1, ZERO, call("addition", v, a))
    source.declare("affine", 2, call("addition", a, b),
                   call("addition", call("multiplication", a, v), b))
    source.declare("index_sum", 1, a, call("addition", v, succ(n)))
    source.declare("triangular", 0, ZERO, call("addition", v, succ(n)))
    return source


if __name__ == "__main__":
    import json

    target = TargetProgram()
    arithmetic = Arithmetic(target)
    source = example_source()
    compiler = Compiler(source, target, arithmetic)
    compiler.compile_all()
    target.validate_all()
    examples = [("addition", (3, 2)), ("multiplication", (3, 2)),
                ("affine", (2, 2, 1)), ("index_sum", (3, 2))]
    print(json.dumps({
        "scope": "Finite standard-natural evaluations, not a universal proof",
        "examples": [{"function": name, "arguments": args,
                      "source": source.evaluate_call(name, *args),
                      "target": compiler.evaluate(name, *args)}
                     for name, args in examples],
        "statistics": target.statistics(),
    }, indent=2))
