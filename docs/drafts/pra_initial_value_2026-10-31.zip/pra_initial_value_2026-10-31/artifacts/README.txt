EXECUTABLE COMPANION: INITIAL-VALUE RECURSION FOR PRA
==================================================

Requirements
------------
Python 3.10 or later. Only the Python standard library is used. There are no
packages to install, no network calls, and no proof-assistant dependencies.

Files
-----
initial_value_compiler.py
    Immutable term and formula syntax, source and target declaration
    validators, equation interpreters, the six restricted arithmetic
    descriptions, and the source-to-target compiler.

test_initial_value_compiler.py
    Six test methods covering syntax restrictions, helper arithmetic,
    pairing and tuple projections, compiled programs and preserved parameter
    frames, and quantifier-free formula compilation.

initial_value_verification.json
    Machine-readable results of the included finite verification run.

Run commands
------------
After extracting the archive, change to its artifacts directory:

    cd pra_initial_value_2026-10-31/artifacts
    python3 test_initial_value_compiler.py --report initial_value_verification.json

The command exits with status 0 exactly when the suite passes. Omitting
--report runs the same tests without writing a report. To run four concise
source/target examples and display interpreter statistics:

    python3 initial_value_compiler.py

The full included test suite took approximately 12 seconds in the preparation
environment. Runtime and memory use depend on the interpreter and machine.
The default target evaluation budget is 8,000,000 recursion steps; exceeding
that budget raises an error, rather than silently changing evaluation methods.

Executable interface
--------------------
Terms use the constructors ZERO, var(name), succ(term), and call(name, *args).
There is no native arithmetic term constructor apart from successor.

A SourceProgram declaration has the form

    source.declare(name, parameter_count, base_term, update_term)

The base context is p0, ..., p(m-1). The update context additionally contains
n for the recursion index and v for the previous result. The declaration
represents ordinary primitive recursion with an arbitrary initial term and
frozen parameters. Every function reference must name an earlier declaration.

A TargetProgram declaration has the form

    target.declare(name, update_term)

Its binary initial-value equations are always

    I(0, a) = a,
    I(n + 1, a) = update_term[n, I(n, a)].

The ONLY permitted update variables are n and v. In particular, a and all p_i
are rejected. Validation happens before insertion, so both forward references
and self references are rejected. Wrong arities, unknown term constructors,
and duplicate names are also rejected. validate_all() independently walks the
completed target declaration list with an incrementally built earlier-symbol
table.

For a minimal API example:

    from initial_value_compiler import (
        Arithmetic, Compiler, TargetProgram, example_source,
    )

    target = TargetProgram()
    arithmetic = Arithmetic(target)
    source = example_source()
    compiler = Compiler(source, target, arithmetic)
    compiler.compile_all()
    target.validate_all()
    print(compiler.evaluate("multiplication", 3, 2))  # prints 6

Arithmetic(target) introduces exactly six earlier target descriptions:
P, B, A, M, U, and V. Predecessor, zero gating, addition, iterated predecessor,
triangular numbers, and diagonal inversion are then genuine target programs.
The selector, equality comparator, pairing J, projections L and R, and tuple
coding are term abbreviations assembled from them, not extra primitives.

Compiler.compile_all() translates source descriptions in declaration order.
It adds one restricted binary recursor per source description. A state pairs
the current result with the encoded tuple of frozen parameters. Each update
decodes that tuple from the current state and pairs the updated result with
the same tuple. CompiledDescription exposes the value, full state, and frame
terms so that preservation of the parameter tuple can be checked separately.
Empty parameter tuples are supported and exercised by the triangular example.

Template substitution is simultaneous. Inserted caller terms are not subjected
to another pass through the same substitution map. Consequently, a caller's
variables named n or p0 are not captured by those names in a callee template.
The term language has no variable-binding constructors. Earlier-reference
validation and the separate n/v versus p_i contexts supply the relevant scope
checks. The index-dependent and two-parameter examples exercise those scopes.

How target evaluation works
---------------------------
For a fixed target symbol and initial state, the interpreter stores a finite
prefix beginning with that initial state. Every additional entry evaluates
the declared update term on the current index and previous entry. An update
can invoke only earlier target descriptions, whose calls use the same rule.

All pairing and unpairing computations follow these equations, including
triangular-number inversion. There is no Python formula for pairing,
subtraction, multiplication, or diagonal inversion in this target evaluation
path. Python integers represent numerals; adding one implements the primitive
successor. Loop and cache bookkeeping also uses ordinary Python operations.
Native arithmetic appears separately in the tests as an independent numerical
oracle, never as a replacement for a target operation.

Memoization stores recursion prefixes and term evaluations. Term cache keys
retain only variables actually free in the term. This avoids storing the
same p(v) evaluation repeatedly under irrelevant values of n. It does not
alter the recursion equations or substitute arithmetic shortcuts.

What the included run verified
------------------------------
All six test methods passed. The report records:

  * 11 target descriptions satisfying the restricted grammar: six helpers
    and five compiled source descriptions;
  * 80 source-versus-target program values, and 80 corresponding checks that
    the decoded parameter frame remains unchanged;
  * addition and multiplication, a two-parameter affine recurrence with a
    nontrivial initial term, an index-dependent accumulated sum, and a
    parameter-free triangular recurrence;
  * 80 further comparisons against independent elementary numerical formulas;
  * 72 pairing-projection checks over 36 input pairs;
  * 102 tuple-projection checks for tuple lengths one through three, together
    with the empty-tuple case;
  * 128 checks that compiled error terms are zero exactly when their finite
    quantifier-free formulas are true;
  * bounded arithmetic, predecessor, selector, and equality-comparator checks;
  * rejection of eight invalid target declarations and four invalid source
    declarations.

The target interpreter performed 4,380,228 recursion steps during this run.
The complete case bounds and checked expressions are visible in the tests;
the JSON report records counts and evaluator statistics.

Verification boundary
---------------------
These are finite checks of executable syntax and selected standard-natural-
number computations. They do NOT prove the correctness of all primitive-
recursive descriptions, the infinite axiom schemas, derivability in
intuitionistic logic, behavior in nonstandard models, or conservative
definitional equivalence with PRA. In particular, ordinary Python truth-table
evaluation is not an intuitionistic proof checker.

The universal mathematical arguments, including the equality-comparator
bootstrap, one-parameter pairing proof, and preservation invariant for the
compiled parameter frame, are supplied in the accompanying paper. This
artifact independently exercises the specified construction and helps expose
finite implementation or scoping mistakes; it does not replace those proofs.
