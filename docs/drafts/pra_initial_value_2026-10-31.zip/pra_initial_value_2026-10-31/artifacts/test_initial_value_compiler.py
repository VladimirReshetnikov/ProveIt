#!/usr/bin/env python3
"""Finite checks of the restricted PRA compiler; Python standard library only.

Run:
    python3 test_initial_value_compiler.py
    python3 test_initial_value_compiler.py --report initial_value_verification.json

These tests validate finite syntax and selected standard-N executions. They do
not establish the infinite axiom schema, intuitionistic derivability, or the
universal conservativity theorem. No native numerical shortcuts replace the
target recursor interpreter.
"""

from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path
import unittest

from initial_value_compiler import (
    Arithmetic, Compiler, Formula, ONE, SourceProgram, TargetProgram, Term,
    ZERO, call, connective, equal, example_source, formula_error, formula_truth,
    free_vars, references, succ, var,
)


class InitialValueChecks(unittest.TestCase):
    counts: dict[str, int] = {}

    @classmethod
    def setUpClass(cls) -> None:
        cls.target = TargetProgram()
        cls.ar = Arithmetic(cls.target)
        cls.source = example_source()
        cls.compiler = Compiler(cls.source, cls.target, cls.ar)
        cls.compiler.compile_all()

    def counted(self, category: str, actual, expected) -> None:
        self.assertEqual(actual, expected)
        self.counts[category] = self.counts.get(category, 0) + 1

    def test_a_reject_invalid_syntax(self) -> None:
        bad_updates = [var("a"), var("p0"), call("future", ZERO, ZERO),
                       call("self", ZERO, ZERO), Term("succ"), Term("mystery")]
        for update in bad_updates:
            with self.assertRaises(ValueError):
                TargetProgram().declare("self", update)
            self.counts["rejected_target_declarations"] = (
                self.counts.get("rejected_target_declarations", 0) + 1)
        target = TargetProgram()
        target.declare("ok", var("v"))
        with self.assertRaises(ValueError):
            target.declare("wrong_arity", call("ok", ZERO))
        with self.assertRaises(ValueError):
            target.declare("ok", ZERO)
        self.counts["rejected_target_declarations"] += 2
        source = SourceProgram()
        for parameters, base, update in [
            (0, var("n"), ZERO), (1, var("p1"), ZERO),
            (1, ZERO, var("p1")), (0, ZERO, call("later", ZERO)),
        ]:
            with self.assertRaises(ValueError):
                source.declare("bad", parameters, base, update)
            self.counts["rejected_source_declarations"] = (
                self.counts.get("rejected_source_declarations", 0) + 1)

    def test_b_all_updates_obey_the_restricted_grammar(self) -> None:
        earlier = set()
        self.target.validate_all()
        for name, description in self.target.descriptions.items():
            self.assertLessEqual(free_vars(description.update), {"n", "v"})
            self.assertLessEqual(references(description.update), earlier)
            earlier.add(name)
            self.counts["valid_restricted_descriptions"] = (
                self.counts.get("valid_restricted_descriptions", 0) + 1)
        self.counted("source_translation_count",
                     len(self.compiler.compiled), len(self.source.descriptions))

    def test_c_bootstrap_arithmetic(self) -> None:
        x, y = var("x"), var("y")
        for a, b in itertools.product(range(7), repeat=2):
            env = {"x": a, "y": b}
            self.counted("addition", self.target.evaluate(self.ar.add(x, y), env), a + b)
            self.counted("monus", self.target.evaluate(self.ar.alpha(x, y), env),
                         max(b - a, 0))
            self.counted("equality_comparison",
                         self.target.evaluate(self.ar.delta(x, y), env) == 0, a == b)
            self.counted("selector",
                         self.target.evaluate(self.ar.choose(x, y, succ(y)), env),
                         b if a == 0 else b + 1)
        for a in range(12):
            env = {"x": a}
            self.counted("predecessor", self.target.evaluate(self.ar.pred(x), env),
                         max(a - 1, 0))
            self.counted("triangular_helper",
                         self.target.evaluate(self.ar.triangle(x), env), a * (a + 1) // 2)

    def test_d_pair_and_tuple_retractions(self) -> None:
        x, y = var("x"), var("y")
        pair = self.ar.pair(x, y)
        for a, b in itertools.product(range(6), repeat=2):
            env = {"x": a, "y": b}
            self.counted("pair_left", self.target.evaluate(self.ar.left(pair), env), a)
            self.counted("pair_right", self.target.evaluate(self.ar.right(pair), env), b)
        for size in range(4):
            names = [f"x{i}" for i in range(size)]
            code = self.ar.tuple_code([var(name) for name in names])
            for values in itertools.product(range(3), repeat=size):
                env = dict(zip(names, values))
                if size == 0:
                    self.counted("empty_tuple", self.target.evaluate(code, env), 0)
                for index, expected in enumerate(values):
                    self.counted("tuple_projection", self.target.evaluate(
                        self.ar.projection(code, index), env), expected)

    def test_e_compiler_and_preserved_parameter_frames(self) -> None:
        examples = [
            ("addition", itertools.product(range(4), repeat=2)),
            ("multiplication", itertools.product(range(4), repeat=2)),
            ("affine", itertools.product(range(3), repeat=3)),
            ("index_sum", itertools.product(range(4), repeat=2)),
            ("triangular", ((n,) for n in range(5))),
        ]
        for name, arguments in examples:
            description = self.compiler.compiled[name]
            for args in arguments:
                source_value = self.source.evaluate_call(name, *args)
                target_value = self.compiler.evaluate(name, *args)
                self.counted(f"compiled_{name}", target_value, source_value)
                env = {"n": args[0], **{f"p{i}": a for i, a in enumerate(args[1:])}}
                frame_value = self.target.evaluate(description.frame, env)
                preserved = self.target.evaluate(self.ar.right(description.state), env)
                self.counted("parameter_frame_preservation", preserved, frame_value)
                if name == "addition":
                    self.counted("independent_arithmetic_oracle", source_value,
                                 args[0] + args[1])
                elif name == "multiplication":
                    self.counted("independent_arithmetic_oracle", source_value,
                                 args[0] * args[1])
                elif name == "affine":
                    n, a, b = args
                    expected = a + b
                    for _ in range(n):
                        expected = a * expected + b
                    self.counted("independent_arithmetic_oracle", source_value, expected)
                elif name == "index_sum":
                    n, a = args
                    self.counted("independent_arithmetic_oracle", source_value,
                                 a + n * (n + 1) // 2)
                else:
                    n, = args
                    self.counted("independent_arithmetic_oracle", source_value,
                                 n * (n + 1) // 2)

    def test_f_quantifier_free_formula_compiler(self) -> None:
        x, y = var("x"), var("y")
        a, b = equal(x, ZERO), equal(y, ZERO)
        formulas = [Formula("top"), Formula("bottom"), equal(x, y),
                    connective("not", a)]
        formulas += [connective(kind, a, b) for kind in ("and", "or", "implies")]
        formulas.append(connective("and", connective("or", equal(x, y),
                                     equal(succ(x), y)),
                                   connective("implies", a, connective("not", b))))
        for formula in formulas:
            error = formula_error(formula, self.ar)
            for values in itertools.product(range(4), repeat=2):
                env = dict(zip(("x", "y"), values))
                self.counted("formula_compilation",
                             self.target.evaluate(error, env) == 0,
                             formula_truth(formula, self.target, env))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(InitialValueChecks)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    report = {
        "status": "passed" if result.wasSuccessful() else "failed",
        "scope": (
            "Finite syntax checks and selected standard-N executions. "
            "Not a formal proof of the infinite schemas, intuitionistic "
            "derivability, or universal definitional equivalence."
        ),
        "target_evaluation": (
            "All target helpers and compiled functions evaluated through "
            "their restricted initial-value equations, with prefix memoization; "
            "no native arithmetic or pairing fast path."
        ),
        "test_cases": result.testsRun,
        "source_descriptions": len(InitialValueChecks.source.descriptions),
        "finite_checks_by_category": dict(sorted(InitialValueChecks.counts.items())),
        "target_interpreter": InitialValueChecks.target.statistics(),
    }
    if args.report:
        args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
