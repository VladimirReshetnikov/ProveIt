PRA FROM INITIAL-VALUE RECURSION
Classical and intuitionistic versions
Prepared for Vladimir Reshetnikov, 31 October 2026

MAIN RESULT

The ordinary primitive-recursion generator can be restricted to binary
initial-value recursors indexed by one term h(n,v):

    I_h(0,a) = a
    I_h(Sn,a) = h(n,I_h(n,a)).

Only the counter n and current state v may occur freely in h. There is no
arbitrary base term and no frozen parameter available to the update.

Together with 0 != S0 and the existing one-parameter guarded equation
schema, these equations give a conservative definitional presentation of
ordinary PRA. The same arithmetic axioms work with classical or
intuitionistic first-order logic, separately.

The paper also gives a three-template option: retain the two computation
templates and use a two-term exclusive induction schema that includes the
separation content. That arithmetic pattern is inherited from a reviewed
draft; the new improvement is the restricted computation grammar.

CONTENTS

pra_initial_value.pdf
    Complete 15-page research article with explicit proofs.

pra_initial_value.tex
sections/bootstrap.tex
sections/comparison.tex
    Complete LaTeX source. Keep the sections directory when rebuilding.

axioms.txt
    Self-contained exact syntax, both axiom options, and theorem statement.

comparison.tsv
    Comparison of all five current PRA archives and the proposed systems.

artifacts/initial_value_compiler.py
artifacts/test_initial_value_compiler.py
artifacts/initial_value_verification.json
artifacts/README.txt
    Dependency-free symbolic compiler, genuine recursion-equation
    interpreter, finite verification suite and recorded results.

evidence/sources.json
    Pinned repository revision, five reviewed archive paths and hashes,
    and primary background sources.

evidence/proof_audit.txt
    Independent mathematical review scope and findings.

VALIDATION.txt
    Compilation, execution, rendering and mathematical verification scope.

SHA256SUMS.txt
    SHA-256 hashes for all other delivered files.

REBUILD THE PAPER

From this directory, with a standard TeX Live installation:

    latexmk -pdf -interaction=nonstopmode -halt-on-error pra_initial_value.tex

Without latexmk, run twice:

    pdflatex -interaction=nonstopmode -halt-on-error pra_initial_value.tex

The required LaTeX packages are listed in the source preamble. No external
image assets, bibliography database, shell escape or network access is needed.

RUN THE EXECUTABLE VERIFICATION

Python 3.10 or later; standard library only:

    cd artifacts
    python3 test_initial_value_compiler.py --report initial_value_verification.json

The suite checks syntax and finite standard-natural-number executions.
It does not prove the infinite axiom schemas or the universal equivalence
theorem. The latter is proved mathematically in the article; no new complete
Lean or Rocq formalization is claimed.

COMPARISON AND NOVELTY

Repository: https://github.com/VladimirReshetnikov/ProveIt
Pinned commit: 487040529a8792ae3239ae75e695424aee3d665c

All five PRA archives in docs/drafts were downloaded at that revision and
their Git blob hashes verified. The docs/incoming listing and entire index
were also inspected; its unrelated archives were not reviewed as PRA sources.

The earlier binary draft already supplies binary arity, one induction
parameter, guarded induction, and the constructive pairing proof.
This work removes arbitrary initialization and the frozen parameter from
the recursion generator and proves the needed state-preservation invariant.
The archive does not claim an absolute shortest encoding, historical
priority for parameter coding, or completion of the earlier one-term X1
candidate. It does not claim that updates can omit the counter.

These deliverables are prepared for review and possible integration.
No repository write, commit, push, or pull request was performed.
