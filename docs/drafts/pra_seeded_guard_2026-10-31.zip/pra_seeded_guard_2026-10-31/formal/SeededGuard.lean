/-!
# The syntactic core of seeded guarded PRA

Lean 4.19.0; no imports beyond Init; no Classical or choice.

This file verifies the logical reductions between the new guarded schema,
constructor coverage, equation induction, and the older guarded-equation
schema. Schema variables range over an ACTUAL finite term syntax with two
variables (index and parameter), not over arbitrary semantic functions.
The arbitrary binary symbols may be instantiated by the well-founded seeded
program descriptions in the paper. Predecessor and gate are displayed as
helper constructors; their two computation equations are explicit premises.

This is a scoped certificate. It does not formalize the complete first-order
proof calculus, the comparison/pairing bootstrap, or the compiler for all
primitive-recursive descriptions. Those proofs are in the accompanying paper.
-/

namespace SeededGuard

universe u v

inductive Var where
  | index
  | parameter
  deriving DecidableEq

inductive Term (Fn : Type u) where
  | var : Var → Term Fn
  | zero : Term Fn
  | succ : Term Fn → Term Fn
  | pred : Term Fn → Term Fn
  | gate : Term Fn → Term Fn → Term Fn
  | app : Fn → Term Fn → Term Fn → Term Fn

def Term.subst {Fn : Type u} (σ : Var → Term Fn) : Term Fn → Term Fn
  | .var x => σ x
  | .zero => .zero
  | .succ t => .succ (t.subst σ)
  | .pred t => .pred (t.subst σ)
  | .gate s t => .gate (s.subst σ) (t.subst σ)
  | .app f s t => .app f (s.subst σ) (t.subst σ)

structure Algebra (Fn : Type u) where
  Carrier : Type v
  zero : Carrier
  succ : Carrier → Carrier
  pred : Carrier → Carrier
  gate : Carrier → Carrier → Carrier
  app : Fn → Carrier → Carrier → Carrier

def Algebra.eval {Fn : Type u} (M : Algebra.{u,v} Fn)
    (ρ : Var → M.Carrier) : Term Fn → M.Carrier
  | .var x => ρ x
  | .zero => M.zero
  | .succ t => M.succ (M.eval ρ t)
  | .pred t => M.pred (M.eval ρ t)
  | .gate s t => M.gate (M.eval ρ s) (M.eval ρ t)
  | .app f s t => M.app f (M.eval ρ s) (M.eval ρ t)

def Algebra.env {Fn : Type u} (M : Algebra.{u,v} Fn)
    (n a : M.Carrier) : Var → M.Carrier
  | .index => n
  | .parameter => a

def Algebra.at {Fn : Type u} (M : Algebra.{u,v} Fn)
    (t : Term Fn) (n a : M.Carrier) : M.Carrier := M.eval (M.env n a) t

theorem eval_subst {Fn : Type u} (M : Algebra.{u,v} Fn)
    (σ : Var → Term Fn) (ρ : Var → M.Carrier) (t : Term Fn) :
    M.eval ρ (t.subst σ) = M.eval (fun x => M.eval ρ (σ x)) t := by
  induction t with
  | var x => rfl
  | zero => rfl
  | succ t ih => exact congrArg M.succ ih
  | pred t ih => exact congrArg M.pred ih
  | gate s t ihs iht =>
      change M.gate (M.eval ρ (s.subst σ)) (M.eval ρ (t.subst σ)) = _
      rw [ihs, iht]
      rfl
  | app f s t ihs iht =>
      change M.app f (M.eval ρ (s.subst σ)) (M.eval ρ (t.subst σ)) = _
      rw [ihs, iht]
      rfl

theorem eval_env_congr {Fn : Type u} (M : Algebra.{u,v} Fn)
    (ρ σ : Var → M.Carrier) (he : ∀ x, ρ x = σ x) (t : Term Fn) :
    M.eval ρ t = M.eval σ t := by
  induction t with
  | var x => exact he x
  | zero => rfl
  | succ t ih => exact congrArg M.succ ih
  | pred t ih => exact congrArg M.pred ih
  | gate s t ihs iht =>
      change M.gate (M.eval ρ s) (M.eval ρ t) = _
      rw [ihs, iht]
      rfl
  | app f s t ihs iht =>
      change M.app f (M.eval ρ s) (M.eval ρ t) = _
      rw [ihs, iht]
      rfl

def predSub {Fn : Type u} : Var → Term Fn
  | .index => .pred (.var .index)
  | .parameter => .var .parameter

def succSub {Fn : Type u} : Var → Term Fn
  | .index => .succ (.var .index)
  | .parameter => .var .parameter

theorem at_predSub {Fn : Type u} (M : Algebra.{u,v} Fn)
    (t : Term Fn) (n a : M.Carrier) :
    M.at (t.subst predSub) n a = M.at t (M.pred n) a := by
  unfold Algebra.at
  rw [eval_subst]
  apply eval_env_congr
  intro x
  cases x <;> rfl

theorem at_succSub {Fn : Type u} (M : Algebra.{u,v} Fn)
    (t : Term Fn) (n a : M.Carrier) :
    M.at (t.subst succSub) n a = M.at t (M.succ n) a := by
  unfold Algebra.at
  rw [eval_subst]
  apply eval_env_congr
  intro x
  cases x <;> rfl

structure HelperLaws {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop where
  pred_zero : M.pred M.zero = M.zero
  pred_succ : ∀ n, M.pred (M.succ n) = n
  gate_zero : ∀ y, M.gate M.zero y = y
  gate_succ : ∀ n y, M.gate (M.succ n) y = M.zero

def Premise {Fn : Type u} (M : Algebra.{u,v} Fn)
    (f g : Term Fn) (a : M.Carrier) : Prop :=
  M.at f M.zero a = M.zero ∧
  ∀ n, (n = M.zero ∨ M.at f n a = M.succ (M.at g n a)) →
    M.at f (M.succ n) a = M.succ (M.at g (M.succ n) a)

def Guarded {Fn : Type u} (M : Algebra.{u,v} Fn)
    (f g : Term Fn) (a : M.Carrier) : Prop :=
  Premise M f g a →
  M.succ (M.at g M.zero a) ≠ M.zero ∧
  ∀ n, n = M.zero ∨ M.at f n a = M.succ (M.at g n a)

def Xor (P Q : Prop) : Prop := (P ∨ Q) ∧ ¬(P ∧ Q)

def Exclusive {Fn : Type u} (M : Algebra.{u,v} Fn)
    (f g : Term Fn) (a : M.Carrier) : Prop :=
  Premise M f g a →
  ∀ n, Xor (n = M.zero) (M.at f n a = M.succ (M.at g n a))

def Kernel {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop :=
  ∀ (f g : Term Fn) (a : M.Carrier), Guarded M f g a

theorem guarded_iff_exclusive {Fn : Type u} (M : Algebra.{u,v} Fn)
    (f g : Term Fn) (a : M.Carrier) :
    Guarded M f g a ↔ Exclusive M f g a := by
  constructor
  · intro hg hp n
    obtain ⟨hnonzero, hpositive⟩ := hg hp
    refine ⟨hpositive n, ?_⟩
    intro hoverlap
    obtain ⟨hn, he⟩ := hoverlap
    rw [hn] at he
    exact hnonzero (he.symm.trans hp.1)
  · intro hx hp
    have hpositive : ∀ n, n = M.zero ∨
        M.at f n a = M.succ (M.at g n a) := fun n => (hx hp n).1
    refine ⟨?_, hpositive⟩
    intro hz
    exact (hx hp M.zero).2 ⟨rfl, hp.1.trans hz.symm⟩

theorem separation_and_coverage {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hl : HelperLaws M) (hk : Kernel M) :
    M.succ M.zero ≠ M.zero ∧
    ∀ n, n = M.zero ∨ n = M.succ (M.pred n) := by
  have h := hk (.var .index) (.pred (.var .index)) M.zero
  have hp : Premise M (.var .index) (.pred (.var .index)) M.zero := by
    refine ⟨rfl, ?_⟩
    intro n _
    change M.succ n = M.succ (M.pred (M.succ n))
    rw [hl.pred_succ]
  obtain ⟨hs, hc⟩ := h hp
  change M.succ (M.pred M.zero) ≠ M.zero at hs
  rw [hl.pred_zero] at hs
  exact ⟨hs, hc⟩

theorem successor_injective {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hl : HelperLaws M) {x y : M.Carrier} (h : M.succ x = M.succ y) :
    x = y := by
  have hp := congrArg M.pred h
  rw [hl.pred_succ, hl.pred_succ] at hp
  exact hp

theorem successor_nonzero {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hl : HelperLaws M) (hsep : M.succ M.zero ≠ M.zero)
    (n : M.Carrier) : M.succ n ≠ M.zero := by
  intro h
  have hn : n = M.zero := by
    have hp := congrArg M.pred h
    rw [hl.pred_succ, hl.pred_zero] at hp
    exact hp
  exact hsep ((congrArg M.succ hn).symm.trans h)

def liftF {Fn : Type u} (t : Term Fn) : Term Fn :=
  .gate (.gate (.var .index) (.succ .zero)) (.succ (t.subst predSub))

def liftG {Fn : Type u} (s : Term Fn) : Term Fn := s.subst predSub

theorem liftF_zero {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hl : HelperLaws M) (t : Term Fn) (a : M.Carrier) :
    M.at (liftF t) M.zero a = M.zero := by
  change M.gate (M.gate M.zero (M.succ M.zero)) _ = M.zero
  rw [hl.gate_zero, hl.gate_succ]

theorem liftF_succ {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hl : HelperLaws M) (t : Term Fn) (n a : M.Carrier) :
    M.at (liftF t) (M.succ n) a = M.succ (M.at t n a) := by
  change M.gate (M.gate (M.succ n) (M.succ M.zero))
    (M.succ (M.at (t.subst predSub) (M.succ n) a)) = _
  rw [hl.gate_succ, hl.gate_zero, at_predSub, hl.pred_succ]

theorem liftG_at {Fn : Type u} (M : Algebra.{u,v} Fn)
    (s : Term Fn) (n a : M.Carrier) :
    M.at (liftG s) n a = M.at s (M.pred n) a := at_predSub M s n a

theorem liftG_succ {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hl : HelperLaws M) (s : Term Fn) (n a : M.Carrier) :
    M.at (liftG s) (M.succ n) a = M.at s n a := by
  rw [liftG_at, hl.pred_succ]

def EquationInduction {Fn : Type u} (M : Algebra.{u,v} Fn)
    (s t : Term Fn) (a : M.Carrier) : Prop :=
  M.at s M.zero a = M.at t M.zero a →
  (∀ n, M.at s n a = M.at t n a →
    M.at s (M.succ n) a = M.at t (M.succ n) a) →
  ∀ n, M.at s n a = M.at t n a

theorem equation_induction {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hl : HelperLaws M) (hk : Kernel M) (s t : Term Fn) (a : M.Carrier) :
    EquationInduction M s t a := by
  intro hbase hstep
  obtain ⟨hsep, hcov⟩ := separation_and_coverage M hl hk
  have hp : Premise M (liftF t) (liftG s) a := by
    refine ⟨liftF_zero M hl t a, ?_⟩
    intro n hn
    have he : M.at s n a = M.at t n a := by
      rcases hn with hz | hfg
      · rw [hz]
        exact hbase
      · rcases hcov n with hz | hsucc
        · rw [hz]
          exact hbase
        · have hprev : M.at s (M.pred n) a = M.at t (M.pred n) a := by
            have hf := congrArg (fun k => M.at (liftF t) k a) hsucc
            change M.at (liftF t) n a =
              M.at (liftF t) (M.succ (M.pred n)) a at hf
            rw [liftF_succ M hl] at hf
            rw [hf, liftG_at] at hfg
            exact (successor_injective M hl hfg).symm
          have hnext := hstep (M.pred n) hprev
          rw [← hsucc] at hnext
          exact hnext
    rw [liftF_succ M hl, liftG_succ M hl]
    exact congrArg M.succ he.symm
  have hall := (hk (liftF t) (liftG s) a hp).2
  intro n
  rcases hall (M.succ n) with hz | he
  · exact False.elim (successor_nonzero M hl hsep n hz)
  · rw [liftF_succ M hl, liftG_succ M hl] at he
    exact (successor_injective M hl he).symm

def OldGuarded {Fn : Type u} (M : Algebra.{u,v} Fn)
    (s t : Term Fn) (a : M.Carrier) : Prop :=
  (∀ n, (n = M.zero ∨ M.at s n a = M.at t n a) →
    M.at s (M.succ n) a = M.at t (M.succ n) a) →
  ∀ n, n = M.zero ∨ M.at s n a = M.at t n a

theorem old_guarded {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hl : HelperLaws M) (hk : Kernel M) (s t : Term Fn) (a : M.Carrier) :
    OldGuarded M s t a := by
  intro hstep
  have hind := equation_induction M hl hk (s.subst succSub) (t.subst succSub) a
  have hbase : M.at (s.subst succSub) M.zero a =
      M.at (t.subst succSub) M.zero a := by
    rw [at_succSub, at_succSub]
    exact hstep M.zero (Or.inl rfl)
  have hnext : ∀ n, M.at (s.subst succSub) n a = M.at (t.subst succSub) n a →
      M.at (s.subst succSub) (M.succ n) a =
        M.at (t.subst succSub) (M.succ n) a := by
    intro n he
    rw [at_succSub, at_succSub] at he
    rw [at_succSub, at_succSub]
    exact hstep (M.succ n) (Or.inr he)
  have hall := hind hbase hnext
  intro n
  rcases (separation_and_coverage M hl hk).2 n with hz | hs
  · exact Or.inl hz
  · apply Or.inr
    have he := hall (M.pred n)
    rw [at_succSub, at_succSub, ← hs] at he
    exact he

inductive Formula (Fn : Type u) where
  | equal : Term Fn → Term Fn → Formula Fn
  | bottom : Formula Fn
  | and : Formula Fn → Formula Fn → Formula Fn
  | or : Formula Fn → Formula Fn → Formula Fn
  | imp : Formula Fn → Formula Fn → Formula Fn

def Formula.holds {Fn : Type u} (M : Algebra.{u,v} Fn)
    (n a : M.Carrier) : Formula Fn → Prop
  | .equal s t => M.at s n a = M.at t n a
  | .bottom => False
  | .and A B => A.holds M n a ∧ B.holds M n a
  | .or A B => A.holds M n a ∨ B.holds M n a
  | .imp A B => A.holds M n a → B.holds M n a

def QuantifierFreeInduction {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop :=
  ∀ (A : Formula Fn) (a : M.Carrier),
    A.holds M M.zero a →
    (∀ n, A.holds M n a → A.holds M (M.succ n) a) →
    ∀ n, A.holds M n a

theorem kernel_of_quantifier_free_induction {Fn : Type u}
    (M : Algebra.{u,v} Fn) (hnonzero : ∀ n, M.succ n ≠ M.zero)
    (hind : QuantifierFreeInduction M) : Kernel M := by
  intro f g a hp
  let B : Formula Fn := .or (.equal (.var .index) .zero) (.equal f (.succ g))
  have hbase : B.holds M M.zero a := Or.inl rfl
  have hstep : ∀ n, B.holds M n a → B.holds M (M.succ n) a := by
    intro n hn
    exact Or.inr (hp.2 n hn)
  exact ⟨hnonzero (M.at g M.zero a), hind B a hbase hstep⟩

#print axioms guarded_iff_exclusive
#print axioms separation_and_coverage
#print axioms equation_induction
#print axioms old_guarded
#print axioms kernel_of_quantifier_free_induction

end SeededGuard
