/-!
# Three-world Harrop gluing

Lean 4.19.0. No imports beyond Init and no classical axioms.

This certificate proves the logical gluing lemma used in the paper's
intuitionistic obstruction. Formula atoms carry their two terminal-world
truth values. At the root they are forced exactly when both values hold.
Universal/existential families permit a fixed domain of any type; finite
first-order formulas after assignments instantiate this semantics.

The arithmetic instance uses domain Nat × Nat, coordinatewise primitive
recursive operations, root equality in both coordinates and projected
equality at each leaf. The correspondence with that arithmetic structure
is explained in the paper; this file certifies the logical induction.
-/

namespace HarropGluing

universe u

inductive World where
  | root
  | left
  | right

def Accessible : World → World → Prop
  | .root, _ => True
  | .left, .left => True
  | .right, .right => True
  | _, _ => False

theorem accessible_trans (w v z : World)
    (hwv : Accessible w v) (hvz : Accessible v z) : Accessible w z := by
  cases w with
  | root => exact True.intro
  | left =>
      cases v with
      | root => exact False.elim hwv
      | right => exact False.elim hwv
      | left => exact hvz
  | right =>
      cases v with
      | root => exact False.elim hwv
      | left => exact False.elim hwv
      | right => exact hvz

inductive Formula (D : Type u) : Type (u+1) where
  | atom : Prop → Prop → Formula D
  | bottom : Formula D
  | and : Formula D → Formula D → Formula D
  | or : Formula D → Formula D → Formula D
  | imp : Formula D → Formula D → Formula D
  | all : (D → Formula D) → Formula D
  | ex : (D → Formula D) → Formula D

def atomForcing : World → Prop → Prop → Prop
  | .root, P, Q => P ∧ Q
  | .left, P, _ => P
  | .right, _, Q => Q

def Forces {D : Type u} (w : World) : Formula D → Prop
  | .atom P Q => atomForcing w P Q
  | .bottom => False
  | .and A B => Forces w A ∧ Forces w B
  | .or A B => Forces w A ∨ Forces w B
  | .imp A B => ∀ v, Accessible w v → Forces v A → Forces v B
  | .all Φ => ∀ d, Forces w (Φ d)
  | .ex Φ => ∃ d, Forces w (Φ d)

theorem persistent {D : Type u} (A : Formula D) (w v : World)
    (hwv : Accessible w v) : Forces w A → Forces v A := by
  induction A generalizing w v with
  | atom P Q =>
      intro h
      cases w with
      | root =>
          cases v with
          | root => exact h
          | left => exact h.1
          | right => exact h.2
      | left =>
          cases v with
          | root => exact False.elim hwv
          | left => exact h
          | right => exact False.elim hwv
      | right =>
          cases v with
          | root => exact False.elim hwv
          | left => exact False.elim hwv
          | right => exact h
  | bottom => intro h; exact False.elim h
  | and A B ihA ihB =>
      intro h
      exact ⟨ihA w v hwv h.1, ihB w v hwv h.2⟩
  | or A B ihA ihB =>
      intro h
      cases h with
      | inl hA => exact Or.inl (ihA w v hwv hA)
      | inr hB => exact Or.inr (ihB w v hwv hB)
  | imp A B _ _ =>
      intro h z hvz hA
      exact h z (accessible_trans w v z hwv hvz) hA
  | all Φ ih =>
      intro h d
      exact ih d w v hwv (h d)
  | ex Φ ih =>
      intro h
      obtain ⟨d, hd⟩ := h
      exact ⟨d, ih d w v hwv hd⟩

inductive Harrop {D : Type u} : Formula D → Prop where
  | atom (P Q : Prop) : Harrop (.atom P Q)
  | bottom : Harrop .bottom
  | and {A B : Formula D} : Harrop A → Harrop B → Harrop (.and A B)
  | imp (A : Formula D) {B : Formula D} : Harrop B → Harrop (.imp A B)
  | all (Φ : D → Formula D) : (∀ d, Harrop (Φ d)) → Harrop (.all Φ)

theorem root_of_leaves {D : Type u} {A : Formula D} (hh : Harrop A) :
    Forces .left A → Forces .right A → Forces .root A := by
  induction hh with
  | atom P Q => intro hP hQ; exact ⟨hP, hQ⟩
  | bottom => intro h _; exact False.elim h
  | and hA hB ihA ihB =>
      intro hl hr
      exact ⟨ihA hl.1 hr.1, ihB hl.2 hr.2⟩
  | imp A hB ihB =>
      intro hl hr w _ hA
      cases w with
      | root =>
          exact ihB
            (hl .left True.intro (persistent A .root .left True.intro hA))
            (hr .right True.intro (persistent A .root .right True.intro hA))
      | left => exact hl .left True.intro hA
      | right => exact hr .right True.intro hA
  | all Φ hΦ ih =>
      intro hl hr d
      exact ih d (hl d) (hr d)

theorem harrop_gluing {D : Type u} {A : Formula D} (hh : Harrop A) :
    Forces .root A ↔ (Forces .left A ∧ Forces .right A) := by
  constructor
  · intro h
    exact ⟨persistent A .root .left True.intro h,
      persistent A .root .right True.intro h⟩
  · intro h
    exact root_of_leaves hh h.1 h.2

def crossedDisjunction {D : Type u} : Formula D :=
  .or (.atom True False) (.atom False True)

theorem crossed_disjunction_failure {D : Type u} :
    Forces .left (@crossedDisjunction D) ∧
    Forces .right (@crossedDisjunction D) ∧
    ¬Forces .root (@crossedDisjunction D) := by
  refine ⟨Or.inl True.intro, Or.inr True.intro, ?_⟩
  intro h
  cases h with
  | inl h => exact h.2
  | inr h => exact h.1

#print axioms persistent
#print axioms harrop_gluing
#print axioms crossed_disjunction_failure

end HarropGluing
