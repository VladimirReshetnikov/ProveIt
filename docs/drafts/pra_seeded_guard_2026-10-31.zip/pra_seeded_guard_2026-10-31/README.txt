PRA FROM ITERATION AND ONE ARITHMETIC SCHEMA
31 October 2026
Prepared for Vladimir Reshetnikov

MAIN RESULT

The same three nonlogical templates axiomatize the appropriate theory in
classical or intuitionistic first-order logic with equality.

Every generated function is binary. A declaration contains one earlier
step term h(n,r), with NO separate passive parameter, and has equations

    I_h(0,a)  = a
    I_h(Sn,a) = h(n,I_h(n,a)).

The one additional arithmetic schema is in axioms.txt and on page 1 of
the paper. It uses two schematic terms and at most one fixed numerical
parameter. Full ordinary PRA is a conservative definitional extension.
Equality decidability and quantifier-free induction are derived, including
the constructive case. No arbitrary quantified induction is assumed.

WHAT IS NEW RELATIVE TO THE FIVE INSPECTED DRAFTS

The exclusive arithmetic schema is reduced from ten equality occurrences
to seven. Its initialization and fixed zero guard permit separation to be
checked at zero alone. It combines with the restricted initial-state
iteration grammar and one-parameter constructive arithmetic bootstrap.
The initialized iteration grammar itself is historical (Goodstein 1954).

The old guarded schema plus separate separation still has six equality
occurrences across two arithmetic templates. There is no claim of an
absolute shortest specification or a strict improvement on every metric.

The paper also proves a general intuitionistic obstruction: even all true
Harrop arithmetic axioms cannot imply positive constructor coverage.

CONTENTS

  pra_seeded_guard.pdf       Compiled, self-contained research paper
  pra_seeded_guard.tex       Main LaTeX source
  sections/*.tex             Complete included sections
  axioms.txt                 Exact plain-text axiom specification
  PROOF_SCOPE.txt            Boundaries of written/formal/numerical checks
  source_audit.json          Pinned repository provenance and source hashes
  formal/SeededGuard.lean    Syntactic constructive logical reduction
  formal/HarropGluing.lean   Three-world Harrop gluing argument
  formal/VALIDATION.txt      Compiler version, outputs, scope
  artifacts/                Grammar/compiler and formula-count checks
  build.sh                  Rebuild the paper with pdfLaTeX
  verify.sh                 Rerun Python and Lean checks
  SHA256SUMS                Checksums for all other archive files

REPRODUCTION

Requires a normal TeX Live installation for the PDF. Run:

    sh build.sh

The Python scripts need Python 3.10 or newer and use only the standard
library. The Lean certificates were checked with Lean 4.19.0, without
Mathlib or other packages. Run:

    PRA_LEAN=/absolute/path/to/lean sh verify.sh

If lean is already on PATH, simply run sh verify.sh.

PROVENANCE AND SCOPE

The comparison reads all five PRA archives at repository commit
487040529a8792ae3239ae75e695424aee3d665c, with Git blob hash verification.
The current incoming index has no relevant PRA entries; unrelated incoming
archives were not reviewed. This archive does not contain or reproduce the
five prior packages. Exact source references are in source_audit.json.

The main theorem is proved in the paper. Lean verifies specifically scoped
components; it is not a complete mechanization of the final equivalence.
The Python runs are supplementary finite/symbolic checks, not proofs for
all natural numbers or all models. The one-term fixed-point and the
constancy-plus-coverage reductions remain unresolved here.

No repository commit or pull request is part of this delivery.
