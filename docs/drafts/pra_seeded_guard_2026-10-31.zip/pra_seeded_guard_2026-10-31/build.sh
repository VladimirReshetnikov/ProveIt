#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build pra_seeded_guard.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build pra_seeded_guard.tex
cp build/pra_seeded_guard.pdf pra_seeded_guard.pdf
