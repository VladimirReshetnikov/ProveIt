#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 artifacts/count_schemata.py
python3 artifacts/check_seeded_recursion.py
PRA_LEAN_EXECUTABLE="${PRA_LEAN:-lean}"
"$PRA_LEAN_EXECUTABLE" --version
"$PRA_LEAN_EXECUTABLE" formal/SeededGuard.lean
"$PRA_LEAN_EXECUTABLE" formal/HarropGluing.lean
