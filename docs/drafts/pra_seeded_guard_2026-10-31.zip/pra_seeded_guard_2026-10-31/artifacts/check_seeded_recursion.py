#!/usr/bin/env python3
"""Executable checks for the seeded binary recursion construction.

Primitive symbols all have arity two and satisfy R(0,a)=a and
R(Sn,a)=h(n,R(n,a)), with no passive parameter in h. Named higher-arity helpers are term abbreviations,
expanded into binary primitive calls. The AST checks declaration order,
arity, and free-variable restrictions.

The numerical tests check finite standard-natural inputs. The symbolic
normalizer checks the stated beta reductions, explicitly recording the
previously proved addition, pairing, and state-invariant lemmas it uses. Neither component
is a formalization of first-order arithmetic, induction, or the full
equivalence proof in the paper.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from functools import lru_cache
import json
import math
from itertools import product
from pathlib import Path


@dataclass(frozen=True)
class Term:
    kind: str
    name: str = ""
    args: tuple["Term", ...] = ()


def var(name):
    return Term("var", name)


ZERO = Term("zero")


def succ(term):
    return Term("succ", args=(term,))


ONE = succ(ZERO)


def call(name, *args):
    return Term("call", name, tuple(args))


def substitute(term, mapping):
    if term.kind == "var":
        return mapping.get(term.name, term)
    return Term(term.kind, term.name,
                tuple(substitute(t, mapping) for t in term.args))


def variables(term):
    if term.kind == "var":
        return {term.name}
    return set().union(*(variables(t) for t in term.args))


def display(term):
    if term.kind == "zero":
        return "0"
    if term.kind == "var":
        return term.name
    if term.kind == "succ":
        return "S(" + display(term.args[0]) + ")"
    return term.name + "(" + ",".join(map(display, term.args)) + ")"


@dataclass(frozen=True)
class SeededRecursor:
    step: Term


@dataclass(frozen=True)
class Abbreviation:
    parameters: tuple[str, ...]
    body: Term


class Signature:
    def __init__(self):
        self.definitions = {}

    def check_term(self, term, allowed_variables):
        if not variables(term) <= set(allowed_variables):
            raise ValueError("Unexpected free variables in " + display(term))

        def inspect(t):
            if t.kind not in {"zero", "var", "succ", "call"}:
                raise ValueError("Unknown AST kind: " + t.kind)
            if t.kind == "succ" and len(t.args) != 1:
                raise ValueError("Successor must be unary")
            if t.kind in {"zero", "var"} and t.args:
                raise ValueError("Leaf terms cannot have arguments")
            if t.kind == "call":
                if t.name not in self.definitions:
                    raise ValueError("Undeclared or forward symbol: " + t.name)
                definition = self.definitions[t.name]
                arity = (2 if isinstance(definition, SeededRecursor)
                         else len(definition.parameters))
                if len(t.args) != arity:
                    raise ValueError("Wrong arity for " + t.name)
            for child in t.args:
                inspect(child)

        inspect(term)

    def add_recursor(self, name, step):
        if name in self.definitions:
            raise ValueError("Duplicate symbol: " + name)
        self.check_term(step, {"n", "r"})
        self.definitions[name] = SeededRecursor(step)

    def add_abbreviation(self, name, parameters, body):
        if name in self.definitions:
            raise ValueError("Duplicate abbreviation: " + name)
        if len(set(parameters)) != len(parameters):
            raise ValueError("Repeated abbreviation parameter")
        self.check_term(body, parameters)
        self.definitions[name] = Abbreviation(tuple(parameters), body)

    def evaluate(self, term, environment):
        if term.kind == "zero":
            return 0
        if term.kind == "var":
            value = environment[term.name]
            if not isinstance(value, int) or value < 0:
                raise ValueError("Natural-number input required")
            return value
        if term.kind == "succ":
            return 1 + self.evaluate(term.args[0], environment)
        values = tuple(self.evaluate(t, environment) for t in term.args)
        return self.evaluate_call(term.name, values)

    @lru_cache(maxsize=None)
    def evaluate_call(self, name, values):
        definition = self.definitions[name]
        if isinstance(definition, Abbreviation):
            return self.evaluate(definition.body,
                                 dict(zip(definition.parameters, values)))
        count, parameter = values
        result = parameter
        for index in range(count):
            result = self.evaluate(definition.step,
                                   {"n": index, "r": result})
        return result


n, r, a = map(var, ("n", "r", "a"))
u, v, x, y, z = map(var, ("u", "v", "x", "y", "z"))


def make_signature():
    signature = Signature()
    signature.add_recursor("pred_rec", n)
    signature.add_abbreviation("pred", ("x",), call("pred_rec", x, ZERO))
    signature.add_recursor("gate", ZERO)
    signature.add_abbreviation("mask", ("n", "a"),
                               call("gate", call("gate", n, ONE), a))
    signature.add_recursor("plus", succ(r))
    signature.add_recursor("countdown", call("pred", r))
    signature.add_abbreviation(
        "choose", ("n", "u", "v"),
        call("plus", call("gate", n, u), call("mask", n, v)),
    )
    signature.add_abbreviation(
        "error", ("x", "y"),
        call("choose", call("countdown", x, y),
             call("countdown", y, x), ONE),
    )
    signature.add_recursor("triangle_rec", call("plus", r, succ(n)))
    signature.add_abbreviation("triangle", ("x",), call("triangle_rec", x, ZERO))
    signature.add_recursor(
        "rank_rec",
        call("choose", call("error", succ(n), call("triangle", succ(r))),
             succ(r), r),
    )
    signature.add_abbreviation("rank", ("x",), call("rank_rec", x, ZERO))
    signature.add_abbreviation(
        "pair", ("x", "y"), call("plus", call("triangle", call("plus", x, y)), y),
    )
    signature.add_abbreviation(
        "right", ("x",), call("countdown", call("triangle", call("rank", x)), x),
    )
    signature.add_abbreviation(
        "left", ("x",), call("countdown", call("right", x), call("rank", x)),
    )
    return signature


def grammar_rejection_checks(signature):
    """Ensure the claimed restrictions are enforced, including hidden a."""
    invalid = [
        ("passive_parameter_in_step", a),
        ("undeclared_symbol", call("not_declared", n, r)),
        ("wrong_primitive_arity", call("plus", n, r, ZERO)),
        ("circular_declaration", call("bad_circular_declaration", n, r)),
    ]
    rejected = []
    for name, step in invalid:
        declaration = "bad_" + name
        try:
            signature.add_recursor(declaration, step)
        except ValueError as error:
            rejected.append({"case": name, "rejection": str(error)})
        else:
            raise AssertionError("Grammar accepted " + name)
    return rejected


def tuple_code(parameters):
    result = ZERO
    for parameter in reversed(parameters):
        result = call("pair", var(parameter), result)
    return result


def tuple_component(code, index):
    for _ in range(index):
        code = call("right", code)
    return call("left", code)


def translate_ordinary(signature, name, parameters, base, step):
    """Carry every passive source parameter in the left side of the state."""
    if set(parameters) & {"n", "r"}:
        raise ValueError("Source parameters cannot shadow n or r")
    signature.check_term(base, parameters)
    signature.check_term(step, {"n", "r", *parameters})
    code = call("left", r)
    replacements = {"r": call("right", r)}
    replacements.update({parameter: tuple_component(code, i)
                         for i, parameter in enumerate(parameters)})
    corrected = call("pair", code, substitute(step, replacements))
    seeded_name = name + "_seeded"
    signature.add_recursor(seeded_name, corrected)
    seed = call("pair", tuple_code(parameters), base)
    translated = call("right", call(seeded_name, n, seed))
    signature.add_abbreviation(name, ("n", *parameters), translated)
    return translated


def normalize(term, definitions, lemmas=(), fuel=20000):
    """Symbolic rewrite checker using only the explicitly supplied lemmas."""
    lemmas = set(lemmas)
    remaining = [fuel]

    def reduce(t):
        remaining[0] -= 1
        if remaining[0] < 0:
            raise RuntimeError("Symbolic rewrite budget exhausted")
        # Keep pairing as a proved interface in the symbolic checks. The
        # numerical evaluator above always expands its actual definitions.
        if "pairing_retractions" in lemmas and t.kind == "call":
            if t.name in {"left", "right"}:
                inner = t.args[0]
                if inner.kind == "call" and inner.name == "pair":
                    return reduce(inner.args[0 if t.name == "left" else 1])
                if ("state_first_projection" in lemmas and t.name == "left"
                        and inner.kind == "call" and inner.name == "V_star"):
                    return reduce(call("left", inner.args[1]))
        t = Term(t.kind, t.name, tuple(reduce(c) for c in t.args))
        if t.kind != "call":
            return t
        if "plus_right_zero" in lemmas and t.name == "plus" and t.args[1] == ZERO:
            return t.args[0]
        if "pairing_retractions" in lemmas and t.name in {"pair", "left", "right"}:
            if t.name in {"left", "right"}:
                inner = t.args[0]
                if inner.kind == "call" and inner.name == "pair":
                    return reduce(inner.args[0 if t.name == "left" else 1])
            return t
        definition = definitions.get(t.name)
        if isinstance(definition, Abbreviation):
            return reduce(substitute(definition.body,
                                     dict(zip(definition.parameters, t.args))))
        if isinstance(definition, SeededRecursor):
            index, parameter = t.args
            if index == ZERO:
                return parameter
            if index.kind == "succ":
                previous = index.args[0]
                return reduce(substitute(definition.step, {
                    "n": previous,
                    "r": call(t.name, previous, parameter),
                }))
        return t

    return reduce(term)


def symbolic_checks(signature):
    definitions = dict(signature.definitions)
    examples = [
        ("predecessor zero", call("pred", ZERO), ZERO, ()),
        ("predecessor successor", call("pred", succ(n)), n, ()),
        ("gate zero", call("gate", ZERO, a), a, ()),
        ("gate successor", call("gate", succ(n), a), ZERO, ()),
        ("mask zero", call("mask", ZERO, a), ZERO, ()),
        ("mask successor", call("mask", succ(n), a), a, ()),
        ("selector zero", call("choose", ZERO, u, v), u, ("plus_right_zero",)),
        ("selector successor", call("choose", succ(n), u, v), v, ()),
    ]
    # b and h below are metasyntactic placeholders, not new primitives of
    # the arithmetic language. Their arguments represent substitution.
    parameter_b = var("b")
    base = call("base", a, parameter_b)
    code = call("left", r)
    corrected = call("pair", code,
                     call("h", n, call("right", r),
                          tuple_component(code, 0), tuple_component(code, 1)))
    definitions["V_star"] = SeededRecursor(corrected)
    seed = call("pair", tuple_code(("a", "b")), base)

    def translated(index):
        return call("right", call("V_star", index, seed))

    examples += [
        ("state invariant base reduction", call("left", call("V_star", ZERO, z)),
         call("left", z), ("pairing_retractions",)),
        ("state invariant step reduction", call("left", call("V_star", succ(n), z)),
         call("left", call("V_star", n, z)), ("pairing_retractions",)),
        ("translated ordinary base", translated(ZERO), base, ("pairing_retractions",)),
        ("translated ordinary successor", translated(succ(n)),
         call("h", n, translated(n), a, parameter_b),
         ("pairing_retractions", "state_first_projection")),
    ]

    def delayed(index):
        return call("mask", index, succ(call("t", call("pred", index), a)))

    examples += [
        ("guarded-induction auxiliary zero", delayed(ZERO), ZERO, ()),
        ("guarded-induction auxiliary successor", delayed(succ(n)),
         succ(call("t", n, a)), ()),
    ]
    report = []
    for name, left, right, lemmas in examples:
        lnorm = normalize(left, definitions, lemmas)
        rnorm = normalize(right, definitions, lemmas)
        if lnorm != rnorm:
            raise AssertionError((name, display(lnorm), display(rnorm)))
        report.append({
            "name": name, "left": display(left), "right": display(right),
            "normal_form": display(lnorm),
            "extra_lemmas": list(lemmas),
        })
    return report


def numerical_checks(signature):
    helper_checks = 0
    for index in range(9):
        for left in range(10):
            environment = {"n": index, "a": left}
            for term, expected in [
                (call("pred", n), max(index - 1, 0)),
                (call("gate", n, a), left if index == 0 else 0),
                (call("mask", n, a), 0 if index == 0 else left),
                (call("plus", n, a), index + left),
                (call("countdown", n, a), max(left - index, 0)),
            ]:
                if signature.evaluate(term, environment) != expected:
                    raise AssertionError((display(term), environment, expected))
                helper_checks += 1
            for right in range(10):
                term = call("choose", n, u, v)
                value = signature.evaluate(term, {"n": index, "u": left, "v": right})
                if value != (left if index == 0 else right):
                    raise AssertionError((index, left, right, value))
                helper_checks += 1

    pairing_checks = 0
    for left in range(9):
        for right in range(9):
            encoded = signature.evaluate_call("pair", (left, right))
            expected = (left + right) * (left + right + 1) // 2 + right
            if encoded != expected:
                raise AssertionError((left, right, encoded, expected))
            decoded = (signature.evaluate_call("left", (encoded,)),
                       signature.evaluate_call("right", (encoded,)))
            if decoded != (left, right):
                raise AssertionError((left, right, decoded))
            pairing_checks += 1

    cases = [
        ("zero", (), ZERO, ZERO, lambda i: 0),
        ("fixed_parameter", ("a",), a, r, lambda i, p: p),
        ("fixed_successor_parameter", ("a",), succ(a), r, lambda i, p: p + 1),
        ("shifted_successor", ("a",), succ(a), succ(r), lambda i, p: p + 1 + i),
        ("double_geometric", (), ONE, call("plus", r, r), lambda i: 2 ** i),
        ("offset_sum", ("a",), call("plus", a, a), call("plus", n, r),
         lambda i, p: 2 * p + i * (i - 1) // 2),
        ("shifted_countdown", ("a",), succ(a), call("pred", r),
         lambda i, p: max(p + 1 - i, 0)),
        ("retain_original_parameter", ("a",), succ(a), call("plus", a, r),
         lambda i, p: p + 1 + i * p),
        ("times", ("a",), ZERO, call("plus", a, r), lambda i, p: i * p),
        ("factorial", (), ONE, call("times", succ(n), r), lambda i: math.factorial(i)),
        ("power", ("a",), ONE, call("times", a, r), lambda i, p: p ** i),
        ("two_passive_parameters", ("a", "b"), call("plus", a, var("b")),
         call("plus", a, r), lambda i, p, q: p + q + i * p),
    ]
    results = []
    for name, parameters, base, step, independent_expected in cases:
        term = translate_ordinary(signature, name, parameters, base, step)
        checked = 0
        for values in product(range(3), repeat=len(parameters)):
            assignment = dict(zip(parameters, values))
            reference = signature.evaluate(base, assignment)
            for index in range(5):
                translated_value = signature.evaluate(term, {"n": index, **assignment})
                expected = independent_expected(index, *values)
                if translated_value != reference or translated_value != expected:
                    raise AssertionError((name, index, values,
                                          translated_value, reference, expected))
                checked += 1
                if index < 4:
                    reference = signature.evaluate(step,
                                                   {"n": index, "r": reference,
                                                    **assignment})
        results.append({"function": name, "checked_inputs": checked,
                        "passive_source_parameters": list(parameters),
                        "base": display(base), "step": display(step),
                        "translated_term": display(term),
                        "seeded_step": display(signature.definitions[name + "_seeded"].step),
                        "seeded_step_free_variables": sorted(variables(
                            signature.definitions[name + "_seeded"].step))})
    return {"helper_checks": helper_checks, "pairing_checks": pairing_checks,
            "translation_examples": results,
            "translation_input_checks": sum(r["checked_inputs"] for r in results)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    signature = make_signature()
    rejections = grammar_rejection_checks(signature)
    symbolic = symbolic_checks(signature)
    numerical = numerical_checks(signature)
    primitive_count = sum(isinstance(d, SeededRecursor)
                          for d in signature.definitions.values())
    report = {
        "scope": (
            "Finite standard-natural computations and symbolic beta reductions. "
            "Not a formal verification of the first-order theory, its infinite "
            "axiom schema, the induction derivation, or conservativity."
        ),
        "grammar": {"primitive_symbol_arity": 2,
                    "recursor_step_free_variables": ["n", "r"],
                    "base_equation": "R_h(0,a)=a",
                    "step_equation": "R_h(Sn,a)=h(n,R_h(n,a))",
                    "checked_primitive_declarations": primitive_count,
                    "higher_arity_names_are": "expanded term abbreviations only"},
        "grammar_rejection_checks": rejections,
        "symbolic_reductions": symbolic,
        "symbolic_lemma_meanings": {
            "plus_right_zero": "plus(x,0)=x, proved by equation induction",
            "pairing_retractions": "left(pair(x,y))=x and right(pair(x,y))=y",
            "state_first_projection": (
                "left(V_star(n,z))=left(z), proved by equation induction "
                "from the separately checked base and step reductions"
            ),
        },
        "numerical_checks": numerical,
    }
    rendered = json.dumps(report, indent=2) + "\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
        print(f"Passed {len(symbolic)} symbolic reductions, "
              f"{numerical['helper_checks']} helper checks, and "
              f"{numerical['pairing_checks']} pairing checks; "
              f"{numerical['translation_input_checks']} translation examples.")
    else:
        print(rendered, end="")


if __name__ == "__main__":
    main()
