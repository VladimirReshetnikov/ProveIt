#!/usr/bin/env python3
"""Reproduce the declared formula-tree counts for four PRA presentations.

Counts expand XOR as (A or B) and not(A and B), but keep negation as
one node. Outer universal closure of the passive parameters is omitted
equally from every schema. The two shared computation templates are not
included. The old guarded presentation is counted as two separate
arithmetic templates, without inserting an artificial conjunction.

This is a syntactic check, not a proof of equivalence or minimality.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path


def node(tag, *args):
    return (tag, *args)


def eq(left, right):
    return node("equality", left, right)


def app(letter, x):
    return node("schematic_" + letter, x)


def xor(a, b):
    return node("and", node("or", a, b), node("not", node("and", a, b)))


def all_n(body):
    return node("forall_number", body)


def succ(x):
    return node("successor", x)


n = node("variable", "n")
zero = node("zero")
sn = succ(n)


def old_pair(x):
    r, u = app("first", x), app("second", x)
    return eq(r, zero), eq(r, succ(u))


def old_b(x):
    return node("or", *old_pair(x))


old_x = node(
    "implies",
    node("and", old_b(zero), all_n(node("implies", old_b(n), old_b(sn)))),
    all_n(xor(*old_pair(n))),
)


def new_e(x):
    return eq(app("first", x), succ(app("second", x)))


new_premise = node(
    "and", eq(app("first", zero), zero),
    all_n(node("implies", node("or", eq(n, zero), new_e(n)), new_e(sn))),
)

uniform_guard = node(
    "implies", new_premise, all_n(xor(eq(n, zero), new_e(n))),
)

factored_guard = node(
    "implies", new_premise,
    node("and", node("not", eq(succ(app("second", zero)), zero)),
         all_n(node("or", eq(n, zero), new_e(n)))),
)


def old_e(x):
    return eq(app("first", x), app("second", x))


old_guard = node(
    "implies",
    all_n(node("implies", node("or", eq(n, zero), old_e(n)), old_e(sn))),
    all_n(node("or", eq(n, zero), old_e(n))),
)
separation = node("not", eq(zero, succ(zero)))


def counts(*trees):
    result = Counter()

    def visit(t):
        if isinstance(t, tuple):
            result[t[0]] += 1
            for child in t[1:]:
                visit(child)

    for tree in trees:
        visit(tree)
    return result


KEYS = [
    "equality", "or", "and", "implies", "not", "forall_number",
    "schematic_first", "schematic_second",
]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    systems = {
        "old_exclusive_X": (old_x,),
        "uniform_guard": (uniform_guard,),
        "factored_guard": (factored_guard,),
        "old_G_plus_separation": (old_guard, separation),
    }
    expected = {
        "old_exclusive_X": [10, 4, 3, 2, 1, 2, 10, 5],
        "uniform_guard": [8, 2, 3, 2, 1, 2, 5, 4],
        "factored_guard": [7, 2, 2, 2, 1, 2, 4, 4],
        "old_G_plus_separation": [6, 2, 0, 2, 1, 2, 3, 3],
    }
    report = {
        "scope": (
            "Formula-tree counts only; XOR expanded, negation primitive, "
            "outer parameter closure and common computation axioms omitted. "
            "The old G and separation formulas are counted separately."
        ),
        "systems": {},
    }
    for name, trees in systems.items():
        result = counts(*trees)
        actual = [result[k] for k in KEYS]
        if actual != expected[name]:
            raise AssertionError((name, actual, expected[name]))
        report["systems"][name] = {key: result[key] for key in KEYS}
        report["systems"][name].update({
            "arithmetic_templates": len(trees),
            "schematic_term_placeholders": 2,
            "schematic_term_applications": (
                result["schematic_first"] + result["schematic_second"]
            ),
        })
    rendered = json.dumps(report, indent=2) + "\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
        print("Schema counts checked: equality occurrences 10, 8, 7, 6.")
    else:
        print(rendered, end="")


if __name__ == "__main__":
    main()
