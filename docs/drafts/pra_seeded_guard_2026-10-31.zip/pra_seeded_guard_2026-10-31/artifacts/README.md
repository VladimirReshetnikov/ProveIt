# Reproducible checks

These Python 3 programs use only the standard library. Run them from the
archive's top-level directory:

```bash
python3 artifacts/count_schemata.py --output artifacts/schema_counts.json
python3 artifacts/check_seeded_recursion.py --output artifacts/seeded_checks.json
```

## Formula counts

`count_schemata.py` constructs explicit formula trees for the old exclusive
schema, the new uniform exclusive schema, the new factored schema, and the
old guarded schema together with its separate separation axiom. It checks
equality-atom counts of 10, 8, 7, and 6, respectively. It also records the
logical connective counts, number of arithmetic templates, and occurrences
of the two schematic terms.

XOR is expanded to `(A or B) and not(A and B)`. Negation is counted as one
logical node. The common computation equations and outer quantifiers over
passive parameters are excluded equally. The two formulas in the old
guarded presentation are counted separately; the script does not insert an
extra conjunction. These conventions support the specific comparison in
the paper and do not establish a global minimum.

## The recursion grammar and its compiler

`check_seeded_recursion.py` implements a finite term and program AST. Every
primitive function symbol is binary. A new recursor has the equations

```text
R_h(0,a) = a
R_h(Sn,a) = h(n,R_h(n,a))
```

The step may use only `n` and the previous value `r`. The checker rejects a
free passive parameter in the step, an incorrect primitive arity, and
undeclared or circular references. Names with other arities are term
abbreviations that expand into the permitted binary calls.

The actual programs include predecessor, the zero gate, the positive mask,
addition, truncated subtraction, a selector, triangular numbers, their
interval index, and pairing with both projections. Pairing is implemented
by those programs; it is not a primitive instruction or a numerical
shortcut in the evaluator.

The ordinary-recursion compiler puts a code for the source parameters in
the left component of the state and the current recursive value in the
right component. The original parameters remain accessible through that
state, so the generated step contains no free passive parameter. The
report records the generated step terms and their actual free variables.

The execution checks comprise:

- 14 symbolic reductions for the helper equations, the induction auxiliary,
  the parameter-state invariant's base and step, and the translated
  recursion's two equations;
- 1,350 helper evaluations, with recursion inputs from 0 through 8 and
  value arguments from 0 through 9;
- 81 pairing and projection checks for pairs from `{0,...,8}²`;
- 180 evaluations of 12 compiled examples, using recursion inputs from
  0 through 4 and each source parameter from 0 through 2. The examples
  include constant functions, shifted initial values, arithmetic progressions,
  countdown, multiplication, factorial, powers, and a recurrence with two
  passive source parameters.

For each example, the compiled output is compared both with its source
recursion and with an independently stated numerical formula. The symbolic
checker names the mathematical lemmas it uses: `plus(x,0)=x`, the pairing
retractions, and preservation of the first state projection. The latter
invariant is an equation-induction theorem in the paper; checking its base
and step reductions does not replace that theorem.

These artifacts are computational checks and small symbolic consistency
checks. They are not Lean or Rocq proofs, do not verify the first-order
proof rules, and do not establish the infinite induction schema or the
conservativity theorem by testing. The mathematical proofs are in the
paper.
