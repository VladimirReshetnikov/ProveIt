#!/usr/bin/env python3
"""Reproduce arithmetic-formula counts; standard library only.

This is an explicit limited metric, not an absolute description-length claim.
Computation equations, term trees, fixed universal closures, parameter closure,
and the bounded-rewrite admission algorithm are deliberately excluded.
Negation counts as one connective, equivalently implication to bottom with
bottom itself omitted from the skeleton count. XOR is expanded explicitly.
"""
import json
from collections import Counter


def eq(label):
    return ("equality", label)


def node(tag, *children):
    return (tag, *children)


def neg(p):
    return node("not", p)


def conj(p, q):
    return node("and", p, q)


def disj(p, q):
    return node("or", p, q)


def imp(p, q):
    return node("implies", p, q)


def alln(p):
    return node("forall", p)


def xor(p, q):
    return conj(disj(p, q), neg(conj(p, q)))


def counts(f):
    if f[0] == "equality":
        return Counter(equalities=1)
    result = Counter(quantifiers=1) if f[0] == "forall" else Counter(connectives=1)
    for c in f[1:]:
        result.update(counts(c))
    return result


def main():
    E = eq("f(n,a)=g(n,a)")
    ES = eq("f(Sn,a)=g(Sn,a)")
    E1 = eq("f(1,a)=g(1,a)")
    Z = eq("n=0")
    SEP = neg(eq("0=1"))
    B = lambda suffix: disj(eq("r"+suffix+"=0"), eq("r"+suffix+"=S u"+suffix))
    exclusive = imp(conj(B("0"), alln(imp(B("n"), B("Sn")))),
                    alln(xor(eq("rn=0"), eq("rn=S un"))))
    guarded_successor = imp(
        conj(eq("r0=0"), alln(imp(disj(Z, eq("rn=S un")), eq("rSn=S uSn")))),
        alln(xor(Z, eq("rn=S un"))))
    seeded = imp(
        conj(eq("r0=0"), alln(imp(disj(Z, eq("rn=S un")), eq("rSn=S uSn")))),
        conj(neg(eq("0=S u0")), alln(disj(Z, eq("rn=S un")))))
    prescribed = imp(alln(imp(disj(Z, E), ES)), alln(xor(Z, E)))
    separated_guard = imp(alln(imp(disj(Z, E), ES)), alln(disj(Z, E)))
    one_term = imp(alln(imp(disj(Z, eq("n=S t(n)")), eq("n=t(Sn)"))),
                   alln(xor(Z, eq("n=S t(n)"))))
    transparent = imp(conj(E1, alln(imp(E, ES))), conj(SEP, alln(disj(Z, E))))
    admitted = imp(alln(imp(E, ES)), conj(SEP, alln(disj(Z, E))))
    theories = [
        ("binary exclusive", [exclusive], 10),
        ("guarded successor", [guarded_successor], 8),
        ("seeded guard", [seeded], 7),
        ("prescribed initial", [prescribed], 7),
        ("separated guarded plus separation", [separated_guard, SEP], 6),
        ("one-term exclusive plus Shift", [one_term, eq("Shift")], 8),
        ("positive base unrestricted PB", [transparent], 6),
        ("positive base admitted PB3", [admitted], 5),
    ]
    rows = []
    for name, formulas, expected_equalities in theories:
        total = Counter()
        for f in formulas:
            total.update(counts(f))
        assert total["equalities"] == expected_equalities, (name, total)
        rows.append({"presentation": name, "arithmetic_items": len(formulas),
                     **dict(total), "skeleton_nodes": sum(total.values())})
    return {"scope": __doc__.strip(), "rows": rows,
            "admission_cost": "PB3 additionally uses a common-reduct test with at most three seed-equation rewrites per side.",
            "template_cost": "Two common computation templates are omitted from every row."}


if __name__ == "__main__":
    print(json.dumps(main(), indent=2))
