# PRA from Induction Starting at One

Research report prepared for Vladimir Reshetnikov, 31 October 2026.

## Result

The report gives two exactly equivalent presentations of primitive recursive
arithmetic, separately in classical and intuitionistic first-order logic.
Both retain the narrow initialized-iteration grammar of the current seeded draft:

    I_h(0,a) = a
    I_h(Sn,a) = h(n,I_h(n,a))

The update h has only the counter n and evolving value as free variables.
There is no separate frozen parameter in the update. All generated symbols are
binary. The arithmetic schema has two term placeholders and one fixed numerical
parameter; arbitrary finite parameter tuples are recovered internally by pairing.

Write E(n,a) for f(n,a)=g(n,a). The compressed arithmetic schema is

    [forall n (E(n,a) -> E(Sn,a))]
       -> [0 != 1 and forall n (n=0 or E(n,a))].

It is admitted when f(1,a) and g(1,a) can each be reduced in at most THREE
forward seed-equation rewrites to a literally identical term. There are five
equality occurrences in its arithmetic formula. This admission check is an
explicit cost, not a claim of absolute shortestness.

The unrestricted alternative adds E(1,a) to the premise and admits all term
pairs. It has six equality occurrences and no bounded-rewrite admission test.

Neither theory needs a separate separation axiom, successor axiom, equality
decision axiom, fixed subtraction law, or semantic comparison bridge.

The paper includes a quantifier-free sequent-rule reading, full mathematical
proofs of equivalence, comparison with all six current repository drafts, a
countermodel explaining a constructive limitation, and Further research questions.

## Contents

- `pra_positive_base.tex`: complete, self-contained LaTeX source.
- `pra_positive_base.pdf`: compiled 14-page research paper.
- `formal/PositiveBasePRA.lean`: constructive proof certificate for the new core.
- `formal/lean_verification.log`: nine theorem-dependency checks from Lean 4.19.0.
- `artifacts/check_rewrites.py`: finite symbolic checks of the actual seed grammar,
  bounded admission certificates, padding, and delay terms.
- `artifacts/rewrite_certificates.json`: checked rewrite traces and scope notes.
- `artifacts/schema_sizes.py`: explicit formula-skeleton counting convention.
- `artifacts/schema_sizes.json`: reproduced comparison totals.
- `source_audit.json`: pinned repository commit, six verified archive blob hashes,
  SHA-256 hashes, source-file hashes, and incoming inventory scope.
- `validation.json`: verification summary and formalization boundaries.
- `build.sh`: local rebuild and verification commands.
- `SHA256SUMS`: delivered-file checksums, excluding this checksum file itself.

## Build

Requirements: Python 3.10 or later, a LaTeX distribution with the ordinary
packages listed in the source, and optionally Lean 4.19.0. No Python packages
or Lean packages are required. The build script never downloads dependencies.

From this directory:

```sh
sh build.sh
```

The script runs the symbolic and size checks, compiles the paper twice, and
runs the Lean file if `lean` is on PATH. To run the checks separately:

```sh
python3 artifacts/check_rewrites.py
python3 artifacts/schema_sizes.py
lean formal/PositiveBasePRA.lean
pdflatex -interaction=nonstopmode -halt-on-error pra_positive_base.tex
pdflatex -interaction=nonstopmode -halt-on-error pra_positive_base.tex
```

## What is and is not formally checked

The Lean file checks the new logical bootstrap, not the whole mathematical
paper. It assumes an explicit abstract syntactic interface with evaluation,
admissibility, and the displayed padding/delay identities. It does not quantify
the arithmetic schema over arbitrary semantic functions. The concrete seed
grammar and its finite rewrite witnesses are supplied in the paper and Python
artifact. Native comparison, the Boolean compiler, pairing, and conservative
definitional extension have complete written proofs but are not yet formalized
in this Lean file. All nine printed kernel theorems depend on no axioms; there
are no imports, `sorry`, or classical principles.

The three-step padding admission trace discards an opaque target tail. Its
bound therefore holds uniformly for arbitrary expanded target terms. Some
other helper traces display an opaque application for the target term; their
normalization lengths are schematic checks, not uniform bounds for terms that
duplicate their input. This distinction is documented in the checker output.

## Comparison and provenance

The reviewed repository is VladimirReshetnikov/ProveIt at commit
`1933ee3d1630a43f96bfe16aeb88a8371b52082e`. All six current draft archives were
read. The incoming inventory and index were checked; unrelated archive interiors
were not inspected. These source archives are not redistributed here.

The initialized-iteration grammar and the constructive comparator/pairing
techniques are credited to the current drafts. The new compression moves the
base to one, uses the zero exception to obtain positive coverage, and proves
completeness of the bounded-admission restriction by padding within the seed
grammar itself. The unrestricted six-equality form is acknowledged as a normal
form of the older guarded principle. The five-equality form improves that
literal count while adding the finite syntactic admission test.

No absolute minimality, optimal rewrite bound, worldwide priority, full Lean
formalization, or resolution of the earlier one-term-without-Shift problem is
claimed.
