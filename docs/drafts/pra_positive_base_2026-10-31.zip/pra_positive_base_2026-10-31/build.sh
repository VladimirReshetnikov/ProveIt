#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 artifacts/check_rewrites.py > artifacts/rewrite_certificates.json
python3 artifacts/schema_sizes.py > artifacts/schema_sizes.json
pdflatex -interaction=nonstopmode -halt-on-error pra_positive_base.tex
pdflatex -interaction=nonstopmode -halt-on-error pra_positive_base.tex
if command -v lean >/dev/null 2>&1; then
    lean formal/PositiveBasePRA.lean > formal/lean_verification.log
else
    echo 'PDF and symbolic checks complete. Lean was not on PATH; its check was skipped.'
fi
