/-
Positive-base induction: a constructive kernel certificate.
Lean 4.19.0; no imports or external packages.

The arithmetic domain A is arbitrary. No Nat induction or native Lean
natural-number facts are used to reason about that domain.

Precisely certified:
  * both the unrestricted and the bounded-admission positive-base schema
    derive separation and constructor coverage;
  * predecessor equations then derive the ordinary successor axioms;
  * a two-place delayed-term interface turns the schema into induction
    for every equation represented by the supplied syntax interface;
  * the converse schema instance follows from its one quantifier-free
    induction instance and the certified equality at one.

Scope of the interface: Term is an abstract syntax type, and eval has
exactly the induction input and one fixed numerical parameter. The
admissibility predicate is supplied by the syntax implementation, not
defined as semantic equality. The paper supplies its bounded forward
rewriting definition (a fixed finite computation-rewrite bound on each side to
one common term), its decision procedure, the concrete predecessor and
padding terms, and their finite rewrite certificates. Those syntax and
rewrite facts are explicitly represented by hypotheses below rather
than claimed as part of this formalization.

No fixed subtraction law, decidable equality, or classical principle is
assumed. The kernel does not yet formalize the subsequent equality-test
construction, arbitrary quantifier-free formulas, pairing, or the full
language translation to ordinary PRA.
-/

namespace PositiveBasePRA

universe u v

structure Arithmetic (A : Type v) where
  zero : A
  succ : A → A
  pred : A → A
  pred_zero : pred zero = zero
  pred_succ : ∀ x, pred (succ x) = x

structure Syntax {A : Type v} (C : Arithmetic A) where
  Term : Type u
  eval : Term → A → A → A
  admissible : Term → Term → Prop
  identity : Term
  succPred : Term
  identity_eval : ∀ n a, eval identity n a = n
  succPred_eval : ∀ n a, eval succPred n a = C.succ (C.pred n)
  coverage_admissible : admissible identity succPred
  pad : Term → Term
  pad_seed : A
  pad_zero : ∀ t a, eval (pad t) C.zero a = pad_seed
  pad_one : ∀ t a, eval (pad t) (C.succ C.zero) a = pad_seed
  pad_two : ∀ t n a,
    eval (pad t) (C.succ (C.succ n)) a = eval t n a
  padding_admissible : ∀ s t, admissible (pad s) (pad t)
  admissible_at_one : ∀ s t, admissible s t → ∀ a,
    eval s (C.succ C.zero) a = eval t (C.succ C.zero) a
  delay : Term → Term
  delay_zero : ∀ t a, eval (delay t) C.zero a = C.zero
  delay_succ : ∀ t n a, eval (delay t) (C.succ n) a = eval t n a

variable {A : Type v} (C : Arithmetic A) (T : Syntax.{u} C)

/-- Positive-base schema, only for admitted syntactic term pairs. -/
def PositiveBase : Prop :=
  ∀ s t, T.admissible s t → ∀ a,
    (∀ n, T.eval s n a = T.eval t n a →
      T.eval s (C.succ n) a = T.eval t (C.succ n) a) →
    C.zero ≠ C.succ C.zero ∧
      ∀ n, n = C.zero ∨ T.eval s n a = T.eval t n a

/-- Unrestricted schema with the equality at one as an explicit premise. -/
def TransparentPositiveBase : Prop :=
  ∀ s t a,
    T.eval s (C.succ C.zero) a = T.eval t (C.succ C.zero) a →
    (∀ n, T.eval s n a = T.eval t n a →
      T.eval s (C.succ n) a = T.eval t (C.succ n) a) →
    C.zero ≠ C.succ C.zero ∧
      ∀ n, n = C.zero ∨ T.eval s n a = T.eval t n a

/-- One usual equation-induction instance, with the parameter fixed. -/
def EquationInduction (s t : T.Term) (a : A) : Prop :=
  T.eval s C.zero a = T.eval t C.zero a →
  (∀ n, T.eval s n a = T.eval t n a →
    T.eval s (C.succ n) a = T.eval t (C.succ n) a) →
  ∀ n, T.eval s n a = T.eval t n a

theorem separation_and_coverage (H : PositiveBase C T) :
    C.zero ≠ C.succ C.zero ∧
      ∀ n, n = C.zero ∨ n = C.succ (C.pred n) := by
  have h := H T.identity T.succPred T.coverage_admissible C.zero (by
    intro n _
    rw [T.identity_eval, T.succPred_eval, C.pred_succ])
  refine ⟨h.1, ?_⟩
  intro n
  have hn := h.2 n
  rw [T.identity_eval, T.succPred_eval] at hn
  exact hn

theorem successor_injective {x y : A}
    (h : C.succ x = C.succ y) : x = y := by
  have hp := congrArg C.pred h
  rw [C.pred_succ, C.pred_succ] at hp
  exact hp

theorem successor_ne_zero (H : PositiveBase C T) (x : A) :
    C.succ x ≠ C.zero := by
  intro bad
  have hx := congrArg C.pred bad
  rw [C.pred_succ, C.pred_zero] at hx
  have badOne : C.succ C.zero = C.zero := by
    exact (congrArg C.succ hx).symm.trans bad
  exact (separation_and_coverage C T H).1 badOne.symm

theorem equation_induction (H : PositiveBase C T) (s t : T.Term) (a : A) :
    EquationInduction C T s t a := by
  intro base step
  have coverage := (separation_and_coverage C T H).2
  have paddedStep : ∀ n,
      T.eval (T.pad s) n a = T.eval (T.pad t) n a →
      T.eval (T.pad s) (C.succ n) a =
        T.eval (T.pad t) (C.succ n) a := by
    intro n hn
    rcases coverage n with hz | hs
    · rw [hz, T.pad_one, T.pad_one]
    · rcases coverage (C.pred n) with hpz | hps
      · have hnOne : n = C.succ C.zero := by
          exact hs.trans (congrArg C.succ hpz)
        rw [hnOne, T.pad_two, T.pad_two]
        exact base
      · have hnTwo : n = C.succ (C.succ (C.pred (C.pred n))) := by
          exact hs.trans (congrArg C.succ hps)
        rw [hnTwo, T.pad_two, T.pad_two] at hn
        rw [hnTwo, T.pad_two, T.pad_two]
        exact step (C.pred (C.pred n)) hn
  have result := H (T.pad s) (T.pad t)
    (T.padding_admissible s t) a paddedStep
  intro n
  rcases result.2 (C.succ (C.succ n)) with bad | good
  · exact False.elim (successor_ne_zero C T H (C.succ n) bad)
  · rw [T.pad_two, T.pad_two] at good
    exact good

theorem transparent_separation_and_coverage (H : TransparentPositiveBase C T) :
    C.zero ≠ C.succ C.zero ∧
      ∀ n, n = C.zero ∨ n = C.succ (C.pred n) := by
  have h := H T.identity T.succPred C.zero (by
    rw [T.identity_eval, T.succPred_eval, C.pred_succ]) (by
    intro n _
    rw [T.identity_eval, T.succPred_eval, C.pred_succ])
  refine ⟨h.1, ?_⟩
  intro n
  have hn := h.2 n
  rw [T.identity_eval, T.succPred_eval] at hn
  exact hn

theorem transparent_equation_induction (H : TransparentPositiveBase C T)
    (s t : T.Term) (a : A) : EquationInduction C T s t a := by
  intro base step
  have constructorFacts := transparent_separation_and_coverage C T H
  have coverage := constructorFacts.2
  have nonzero (x : A) : C.succ x ≠ C.zero := by
    intro bad
    have hx := congrArg C.pred bad
    rw [C.pred_succ, C.pred_zero] at hx
    exact constructorFacts.1 ((congrArg C.succ hx).symm.trans bad).symm
  have delayedBase : T.eval (T.delay s) (C.succ C.zero) a =
      T.eval (T.delay t) (C.succ C.zero) a := by
    rw [T.delay_succ, T.delay_succ]
    exact base
  have delayedStep : ∀ n,
      T.eval (T.delay s) n a = T.eval (T.delay t) n a →
      T.eval (T.delay s) (C.succ n) a =
        T.eval (T.delay t) (C.succ n) a := by
    intro n hn
    rcases coverage n with hz | hs
    · rw [hz, T.delay_succ, T.delay_succ]
      exact base
    · rw [hs, T.delay_succ, T.delay_succ] at hn
      rw [hs, T.delay_succ, T.delay_succ]
      exact step (C.pred n) hn
  have result := H (T.delay s) (T.delay t) a delayedBase delayedStep
  intro n
  rcases result.2 (C.succ n) with bad | good
  · exact False.elim (nonzero n bad)
  · rw [T.delay_succ, T.delay_succ] at good
    exact good

theorem transparent_implies_bounded (H : TransparentPositiveBase C T) :
    PositiveBase C T := by
  intro s t admit a step
  exact H s t a (T.admissible_at_one s t admit a) step

/--
The exact quantifier-free induction instance used in the reverse proof.
This is an explicit hypothesis, not induction for all semantic predicates.
-/
def GuardedEquationInduction (s t : T.Term) (a : A) : Prop :=
  (C.zero = C.zero ∨ T.eval s C.zero a = T.eval t C.zero a) →
  (∀ n,
    (n = C.zero ∨ T.eval s n a = T.eval t n a) →
    (C.succ n = C.zero ∨
      T.eval s (C.succ n) a = T.eval t (C.succ n) a)) →
  ∀ n, n = C.zero ∨ T.eval s n a = T.eval t n a

theorem reverse_instance (s t : T.Term) (admit : T.admissible s t)
    (a : A) (sep : C.zero ≠ C.succ C.zero)
    (ind : GuardedEquationInduction C T s t a)
    (step : ∀ n, T.eval s n a = T.eval t n a →
      T.eval s (C.succ n) a = T.eval t (C.succ n) a) :
    C.zero ≠ C.succ C.zero ∧
      ∀ n, n = C.zero ∨ T.eval s n a = T.eval t n a := by
  refine ⟨sep, ind (Or.inl rfl) ?_⟩
  intro n hn
  apply Or.inr
  rcases hn with hz | he
  · rw [hz]
    exact T.admissible_at_one s t admit a
  · exact step n he

theorem transparent_reverse_instance (s t : T.Term) (a : A)
    (sep : C.zero ≠ C.succ C.zero)
    (ind : GuardedEquationInduction C T s t a)
    (baseOne : T.eval s (C.succ C.zero) a = T.eval t (C.succ C.zero) a)
    (step : ∀ n, T.eval s n a = T.eval t n a →
      T.eval s (C.succ n) a = T.eval t (C.succ n) a) :
    C.zero ≠ C.succ C.zero ∧
      ∀ n, n = C.zero ∨ T.eval s n a = T.eval t n a := by
  refine ⟨sep, ind (Or.inl rfl) ?_⟩
  intro n hn
  apply Or.inr
  rcases hn with hz | he
  · rw [hz]
    exact baseOne
  · exact step n he

#print axioms separation_and_coverage
#print axioms successor_injective
#print axioms successor_ne_zero
#print axioms equation_induction
#print axioms transparent_separation_and_coverage
#print axioms transparent_equation_induction
#print axioms transparent_implies_bounded
#print axioms reverse_instance
#print axioms transparent_reverse_instance

end PositiveBasePRA
