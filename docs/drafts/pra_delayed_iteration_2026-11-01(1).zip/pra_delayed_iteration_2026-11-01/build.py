#!/usr/bin/env python3
"""Rebuild the supplied finite checks and PDF; optionally replay Lean."""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile


ROOT = Path(__file__).resolve().parent


def run(command: list[str], log: Path, *, env=None) -> dict:
    completed = subprocess.run(
        command, cwd=ROOT, env=env, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False,
    )
    log.write_text(completed.stdout, encoding="utf-8")
    result = {"command": command, "exit_code": completed.returncode,
              "log": str(log.relative_to(ROOT))}
    if completed.returncode:
        raise RuntimeError(f"Build step failed; see {result['log']}")
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--skip-pdf", action="store_true")
    parser.add_argument("--lean", help="Optional Lean 4.19.0 executable")
    args = parser.parse_args()
    audit = ROOT / "audit"
    audit.mkdir(exist_ok=True)
    summary = {"steps": [], "scope": "Finite diagnostics and document build"}
    summary["steps"].append(run(
        [os.sys.executable, "checks/check_schema.py"], audit / "python-check.log"))
    if not args.skip_pdf:
        if not shutil.which("latexmk"):
            raise RuntimeError("latexmk is required for the PDF build")
        env = os.environ.copy()
        stamp = datetime.datetime(2026, 11, 1, tzinfo=datetime.timezone.utc)
        env.setdefault("SOURCE_DATE_EPOCH", str(int(stamp.timestamp())))
        env.setdefault("FORCE_SOURCE_DATE", "1")
        with tempfile.TemporaryDirectory(prefix="pra-delayed-build-") as td:
            summary["steps"].append(run(
                ["latexmk", "-pdf", "-interaction=nonstopmode",
                 "-halt-on-error", f"-outdir={td}", "report.tex"],
                audit / "latex-build.log", env=env))
            pdf = Path(td) / "report.pdf"
            texlog = (Path(td) / "report.log").read_text(encoding="utf-8")
            warnings = [line for line in texlog.splitlines()
                        if any(s in line for s in
                               ("Warning", "Overfull", "Underfull", "undefined"))]
            (audit / "latex-final.log").write_text(texlog, encoding="utf-8")
            summary["latex_diagnostics"] = warnings
            if not pdf.is_file():
                raise RuntimeError("PDF was not created")
            shutil.copy2(pdf, ROOT / "report.pdf")
    if args.lean:
        summary["steps"].append(run(
            [args.lean, "formal/DelayedIteration.lean"],
            audit / "lean-replay.log"))
    (audit / "build_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    lines = []
    for path in sorted(ROOT.rglob("*")):
        if (path.is_file() and path.name != "SHA256SUMS.txt"
                and "__pycache__" not in path.parts):
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            lines.append(f"{digest}  {path.relative_to(ROOT).as_posix()}")
    (ROOT / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
