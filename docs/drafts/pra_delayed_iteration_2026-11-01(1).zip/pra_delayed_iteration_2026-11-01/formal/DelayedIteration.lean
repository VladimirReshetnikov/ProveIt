/-
Constructive kernel for the delayed-iteration presentation of PRA.

The carrier is arbitrary. The functions q, d, and ds below stand for the
interpretations of selected syntax-indexed operation symbols. They are not
an object-language sort of all functions. Every induction hypothesis is the
one explicitly displayed predicate instance required by the theorem.

Tested with Lean 4.19.0. No Mathlib or classical reasoning is used.
-/
import Init

namespace DelayedIteration

universe u
variable {A : Type u}

/-- One specified induction instance, rather than an assertion of full
    induction for arbitrary semantic predicates. -/
def InductionAt (zero : A) (succ : A → A) (P : A → Prop) : Prop :=
  P zero → (∀ n, P n → P (succ n)) → ∀ n, P n

/-- The arithmetic propagation schema, evaluated on one selected matrix. -/
def Propagation (succ : A → A) (F : A → A → Prop) : Prop :=
  ∀ a, (∀ n, F n a → F (succ n) a) → ∀ n, F n a

/-- A stationary admitted matrix is extracted without induction. -/
theorem stationary
    (zero : A) (succ : A → A) (P : A → Prop)
    (propagate : Propagation succ (fun _ a => P a)) :
    ∀ a, P a := by
  intro a
  exact propagate a (fun _ hp => hp) zero

/-- The guarded-reflexivity matrix with B = False yields separation. -/
theorem guarded_separation
    (zero : A) (succ : A → A) (delta : Prop)
    (propagate : Propagation succ (fun _ _ => (False ∨ delta) → False)) :
    ¬ delta := by
  intro hd
  have hf : (False ∨ delta) → False :=
    propagate zero (fun _ h => h) zero
  exact hf (Or.inr hd)

/-- The guarded matrix recovers exactly its underlying induction instance.
    The proof does not require separation or classical excluded middle. -/
theorem guarded_induction
    (zero : A) (succ : A → A) (delta : Prop) (H : A → A → Prop)
    (propagate : Propagation succ
      (fun n a => (H zero a ∨ delta) → H n a)) :
    ∀ a, InductionAt zero succ (fun n => H n a) := by
  intro a hbase hstep n
  have hf : ∀ m, (H zero a ∨ delta) → H m a := by
    apply propagate a
    intro m hm hguard
    exact hstep m (hm hguard)
  exact hf n (Or.inl hbase)

/-- q is the selected delayed iterator for the constant-one update.
    Its double-successor equation and d's reset law already give d(1,a)=a. -/
theorem seed_one
    (zero : A) (succ : A → A) (q d : A → A → A)
    (qstep : ∀ n a, q (succ (succ n)) a = succ zero)
    (reset : ∀ n a, d (q n zero) a = a) :
    ∀ a, d (succ zero) a = a := by
  intro a
  calc
    d (succ zero) a = d (q (succ (succ zero)) zero) a :=
      congrArg (fun x => d x a) (qstep zero zero).symm
    _ = a := reset (succ (succ zero)) a

/-- Applying the same argument to q first makes q(1,0)=0, which
    supplies the other initialization law without any induction. -/
theorem seed_zero
    (zero : A) (succ : A → A) (q d : A → A → A)
    (qstep : ∀ n a, q (succ (succ n)) a = succ zero)
    (qreset : ∀ n a, q (q n zero) a = a)
    (reset : ∀ n a, d (q n zero) a = a) :
    ∀ a, d zero a = a := by
  intro a
  have hq : q (succ zero) zero = zero :=
    seed_one zero succ q q qstep qreset zero
  calc
    d zero a = d (q (succ zero) zero) a :=
      congrArg (fun x => d x a) hq.symm
    _ = a := reset (succ zero) a

/-- Exact combined extraction of both base laws from the fused law. -/
theorem both_seeds
    (zero : A) (succ : A → A) (q d : A → A → A)
    (qstep : ∀ n a, q (succ (succ n)) a = succ zero)
    (qreset : ∀ n a, q (q n zero) a = a)
    (reset : ∀ n a, d (q n zero) a = a) :
    (∀ a, d zero a = a) ∧ (∀ a, d (succ zero) a = a) := by
  exact ⟨seed_zero zero succ q d qstep qreset reset,
    seed_one zero succ q d qstep reset⟩

/-- Conversely, the ordinary three-clause delayed laws imply reset.
    Only the displayed paired quantifier-free induction instance is used. -/
theorem reset_from_seeds
    (zero : A) (succ : A → A) (q d : A → A → A)
    (qzero : ∀ a, q zero a = a)
    (qone : ∀ a, q (succ zero) a = a)
    (qstep : ∀ n a, q (succ (succ n)) a = succ zero)
    (dzero : ∀ a, d zero a = a)
    (done : ∀ a, d (succ zero) a = a)
    (ind : ∀ a, InductionAt zero succ
      (fun n => d (q n zero) a = a ∧ d (q (succ n) zero) a = a)) :
    ∀ n a, d (q n zero) a = a := by
  intro n a
  have hz : d (q zero zero) a = a := by
    rw [qzero zero, dzero a]
  have ho : d (q (succ zero) zero) a = a := by
    rw [qone zero, dzero a]
  have hss : ∀ m, d (q (succ (succ m)) zero) a = a := by
    intro m
    rw [qstep m zero, done a]
  have hp : ∀ m,
      d (q m zero) a = a ∧ d (q (succ m) zero) a = a :=
    ind a ⟨hz, ho⟩ (fun m hm => ⟨hm.2, hss m⟩)
  exact (hp n).1

/-- Ordinary iteration is recovered by one successor shift. -/
def ordinary (succ : A → A) (d : A → A → A) (n a : A) : A :=
  d (succ n) a

theorem ordinary_zero
    (zero : A) (succ : A → A) (d : A → A → A)
    (done : ∀ a, d (succ zero) a = a) :
    ∀ a, ordinary succ d zero a = a := done

theorem ordinary_step
    (succ : A → A) (h : A → A) (d : A → A → A)
    (dstep : ∀ n a, d (succ (succ n)) a = h (d (succ n) a)) :
    ∀ n a, ordinary succ d (succ n) a = h (ordinary succ d n a) :=
  dstep

/-- The delayed iterator for successor provides predecessor. -/
def predecessor (zero : A) (ds : A → A → A) (n : A) : A := ds n zero

theorem predecessor_zero
    (zero : A) (ds : A → A → A)
    (dszero : ∀ a, ds zero a = a) :
    predecessor zero ds zero = zero := dszero zero

theorem predecessor_successor
    (zero : A) (succ : A → A) (ds : A → A → A)
    (dsone : ∀ a, ds (succ zero) a = a)
    (dsstep : ∀ n a, ds (succ (succ n)) a = succ (ds (succ n) a))
    (ind : InductionAt zero succ (fun n => ds (succ n) zero = n)) :
    ∀ n, predecessor zero ds (succ n) = n := by
  apply ind (dsone zero)
  intro n hn
  calc
    ds (succ (succ n)) zero = succ (ds (succ n) zero) := dsstep n zero
    _ = succ n := congrArg succ hn

theorem successor_injective
    (succ pred : A → A) (predSucc : ∀ n, pred (succ n) = n) :
    ∀ x y, succ x = succ y → x = y := by
  intro x y h
  calc
    x = pred (succ x) := (predSucc x).symm
    _ = pred (succ y) := congrArg pred h
    _ = y := predSucc y

theorem successor_nonzero
    (zero : A) (succ pred : A → A)
    (predZero : pred zero = zero)
    (predSucc : ∀ n, pred (succ n) = n)
    (separate : zero ≠ succ zero) :
    ∀ n, succ n ≠ zero := by
  intro n h
  have hn : n = zero := by
    calc
      n = pred (succ n) := (predSucc n).symm
      _ = pred zero := congrArg pred h
      _ = zero := predZero
  have hz : succ zero = zero := by
    calc
      succ zero = succ n := congrArg succ hn.symm
      _ = zero := h
  exact separate hz.symm

/-- This is the delayed-symbol round trip through ordinary iteration:
    I_h(pred n,a) = D_h(succ(pred n),a) = D_h(n,a). -/
theorem delayed_roundtrip
    (zero : A) (succ pred : A → A) (d : A → A → A)
    (dzero : ∀ a, d zero a = a)
    (done : ∀ a, d (succ zero) a = a)
    (predZero : pred zero = zero)
    (predSucc : ∀ n, pred (succ n) = n)
    (ind : ∀ a, InductionAt zero succ
      (fun n => d n a = d (succ (pred n)) a)) :
    ∀ n a, d n a = ordinary succ d (pred n) a := by
  intro n a
  apply ind a
  · rw [predZero, dzero a, done a]
  · intro m _
    rw [predSucc m]

/-- The other round trip is immediate from pred(succ n)=n. -/
theorem ordinary_roundtrip
    (succ pred : A → A) (i : A → A → A)
    (predSucc : ∀ n, pred (succ n) = n) :
    ∀ n a, i (pred (succ n)) a = i n a := by
  intro n a
  rw [predSucc n]

/-- Definable replacement for the older primitive counter projection K. -/
def counterProjection (pred : A → A) (iS i0 : A → A → A) (n a : A) : A :=
  iS (pred n) (i0 n a)

theorem counterProjection_zero
    (zero : A) (pred : A → A) (iS i0 : A → A → A)
    (predZero : pred zero = zero)
    (iSzero : ∀ a, iS zero a = a)
    (i0zero : ∀ a, i0 zero a = a) :
    ∀ a, counterProjection pred iS i0 zero a = a := by
  intro a
  unfold counterProjection
  rw [predZero, i0zero a, iSzero a]

theorem counterProjection_successor
    (zero : A) (succ pred : A → A) (iS i0 : A → A → A)
    (predSucc : ∀ n, pred (succ n) = n)
    (iSclock : ∀ n, iS n zero = n)
    (i0step : ∀ n a, i0 (succ n) a = zero) :
    ∀ n a, counterProjection pred iS i0 (succ n) a = n := by
  intro n a
  unfold counterProjection
  rw [predSucc n, i0step n a, iSclock n]

#print axioms stationary
#print axioms guarded_separation
#print axioms guarded_induction
#print axioms seed_one
#print axioms seed_zero
#print axioms both_seeds
#print axioms reset_from_seeds
#print axioms ordinary_zero
#print axioms ordinary_step
#print axioms predecessor_zero
#print axioms predecessor_successor
#print axioms successor_injective
#print axioms successor_nonzero
#print axioms delayed_roundtrip
#print axioms ordinary_roundtrip
#print axioms counterProjection_zero
#print axioms counterProjection_successor

end DelayedIteration
