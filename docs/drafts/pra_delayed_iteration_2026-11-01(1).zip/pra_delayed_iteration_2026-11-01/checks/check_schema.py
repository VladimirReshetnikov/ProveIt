#!/usr/bin/env python3
"""Finite syntax and bounded arithmetic checks for delayed-iteration PRA.

This is not a formal proof of the infinite theory's conservativity or
bi-interpretability.  It checks the explicit generator, scoping, finite
equational extraction skeletons, stated partial counts, and bounded
standard-natural-number examples.  No external packages are required.

Run: python3 checks/check_schema.py [--output PATH]
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path


# Finite immutable ASTs.  Descriptor strings are metadata, not active terms.
def V(name): return ("var", name)
def Z(): return ("zero",)
def S(t): return ("succ", t)
def D(h, n, a): return ("delay", h, n, a)
def Eq(s, t): return ("eq", s, t)
def Bot(): return ("bot",)
def And(a, b): return ("and", a, b)
def Or(a, b): return ("or", a, b)
def Imp(a, b): return ("imp", a, b)
def All(x, a): return ("all", x, a)


ZERO, ONE = Z(), S(Z())
N, A, U = V("n"), V("a"), V("v")
DELTA = Eq(ZERO, ONE)


def term_children(t):
    return () if t[0] in {"var", "zero"} else ((t[1],) if t[0] == "succ" else t[2:])


def fv_term(t):
    if t[0] == "var": return {t[1]}
    return set().union(*(fv_term(c) for c in term_children(t)))


def descriptor_refs(t):
    here = {t[1]} if t[0] == "delay" else set()
    return here.union(*(descriptor_refs(c) for c in term_children(t)))


def valid_term(t, known):
    if not isinstance(t, tuple) or not t: return False
    k = t[0]
    if k == "zero": return len(t) == 1
    if k == "var": return len(t) == 2 and isinstance(t[1], str)
    if k == "succ": return len(t) == 2 and valid_term(t[1], known)
    if k == "delay":
        return len(t) == 4 and t[1] in known and all(valid_term(c, known) for c in t[2:])
    return False


def subst_term(t, x, replacement):
    if t[0] == "var": return replacement if t[1] == x else t
    if t[0] == "zero": return t
    if t[0] == "succ": return S(subst_term(t[1], x, replacement))
    # Deliberately do not inspect, edit, or substitute inside t[1].
    return D(t[1], subst_term(t[2], x, replacement), subst_term(t[3], x, replacement))


def fv_formula(f):
    k = f[0]
    if k == "eq": return fv_term(f[1]) | fv_term(f[2])
    if k == "bot": return set()
    if k == "all": return fv_formula(f[2]) - {f[1]}
    return fv_formula(f[1]) | fv_formula(f[2])


def all_names(f):
    if f[0] == "eq": return fv_term(f[1]) | fv_term(f[2])
    if f[0] == "bot": return set()
    if f[0] == "all": return {f[1]} | all_names(f[2])
    return all_names(f[1]) | all_names(f[2])


def valid_formula(f, known, qf=False):
    if not isinstance(f, tuple) or not f: return False
    k = f[0]
    if k == "eq": return len(f) == 3 and all(valid_term(t, known) for t in f[1:])
    if k == "bot": return len(f) == 1
    if k in {"and", "or", "imp"}:
        return len(f) == 3 and all(valid_formula(g, known, qf) for g in f[1:])
    if k == "all":
        return not qf and len(f) == 3 and isinstance(f[1], str) and valid_formula(f[2], known)
    return False


def subst_formula(f, x, replacement):
    k = f[0]
    if k == "eq": return Eq(*(subst_term(t, x, replacement) for t in f[1:]))
    if k == "bot": return f
    if k in {"and", "or", "imp"}:
        return (k, subst_formula(f[1], x, replacement), subst_formula(f[2], x, replacement))
    binder, body = f[1], f[2]
    if binder == x or x not in fv_formula(body): return f
    if binder in fv_term(replacement):
        used = all_names(body) | fv_term(replacement) | {x, binder}
        i = 0
        while f"fresh{i}" in used: i += 1
        fresh = f"fresh{i}"
        body = subst_formula(body, binder, V(fresh))
        binder = fresh
    return All(binder, subst_formula(body, x, replacement))


def count_term(t): return 1 + sum(count_term(c) for c in term_children(t))


def count_formula(f):
    if f[0] == "eq": return 1 + count_term(f[1]) + count_term(f[2])
    if f[0] == "bot": return 1
    if f[0] == "all": return 1 + count_formula(f[2])
    return 1 + count_formula(f[1]) + count_formula(f[2])


def count_opaque_template(f):
    """Separate metasyntactic ledger: F is an opaque two-slot placeholder."""
    if f[0] == "F": return 1 + sum(count_term(t) for t in f[1:])
    if f[0] == "all": return 1 + count_opaque_template(f[2])
    if f[0] == "imp": return 1 + count_opaque_template(f[1]) + count_opaque_template(f[2])
    raise ValueError("not part of the deliberately partial template grammar")


def show_term(t):
    if t[0] == "var": return t[1]
    if t[0] == "zero": return "0"
    if t[0] == "succ": return f"S({show_term(t[1])})"
    return f"D[{t[1]}]({show_term(t[2])},{show_term(t[3])})"


def show_formula(f):
    if f[0] == "eq": return f"{show_term(f[1])} = {show_term(f[2])}"
    if f[0] == "bot": return "false"
    if f[0] == "all": return f"forall {f[1]}. ({show_formula(f[2])})"
    op = {"and": "and", "or": "or", "imp": "->"}[f[0]]
    return f"({show_formula(f[1])} {op} {show_formula(f[2])})"


class Registry:
    def __init__(self): self.bodies = {}

    def add(self, name, body):
        if name in self.bodies: raise ValueError("duplicate descriptor name")
        if not valid_term(body, self.bodies): raise ValueError("malformed body or non-earlier descriptor")
        if not fv_term(body) <= {"v"}: raise ValueError("stored update is not unary and closed in v")
        self.bodies[name] = body

    def body_at(self, name, value):
        return subst_term(self.bodies[name], "v", value)


def make_G(matrix, reg):
    if not valid_formula(matrix, reg.bodies, qf=True): raise ValueError("G requires a QF matrix")
    if not fv_formula(matrix) <= {"n", "a"}: raise ValueError("extra free variable")
    return Imp(Or(subst_formula(matrix, "n", ZERO), DELTA), matrix)


def seed_equation(h, n, a):
    return Eq(D(h, D("one", n, ZERO), a), a)


def step_equation(reg, h, n, a):
    return Eq(D(h, S(S(n)), a), reg.body_at(h, D(h, S(n), a)))


def make_A(h): return All("n", seed_equation(h, N, A))
def make_B(h, reg): return All("n", step_equation(reg, h, A, N))


def classify(f, reg):
    """Recognize only the exact three constructors, with literal naming."""
    if not valid_formula(f, reg.bodies): return None
    if f[0] == "imp" and f[1][0] == "or" and f[1][2] == DELTA:
        b = f[2]
        if valid_formula(b, reg.bodies, qf=True) and fv_formula(b) <= {"n", "a"}:
            if f == make_G(b, reg): return "G"
    for h in reg.bodies:
        if f == make_A(h): return "A"
        if f == make_B(h, reg): return "B"
    return None


def emit(f):
    return All("a", Imp(All("n", Imp(f, subst_formula(f, "n", S(N)))), All("n", f)))


def replace_exact(t, source, target):
    """Equality-congruence helper for extraction traces; not an admission rule."""
    if t == source: return target
    if t[0] in {"var", "zero"}: return t
    if t[0] == "succ": return S(replace_exact(t[1], source, target))
    return D(t[1], *(replace_exact(c, source, target) for c in t[2:]))


def rewrite_equation(eq, law):
    assert eq[0] == law[0] == "eq"
    return Eq(*(replace_exact(t, law[1], law[2]) for t in eq[1:]))


def eval_term(t, env, reg, mode="delayed"):
    if t[0] == "var": return env[t[1]]
    if t[0] == "zero": return 0
    if t[0] == "succ": return eval_term(t[1], env, reg, mode) + 1
    n = eval_term(t[2], env, reg, mode)
    a = eval_term(t[3], env, reg, mode)
    if mode == "missing_zero" and n == 0: return a + 1
    times = n if mode == "missing_one" else max(n - 1, 0)
    for _ in range(times):
        a = eval_term(reg.bodies[t[1]], {"v": a}, reg, mode)
    return a


def numeric_term(n):
    result = ZERO
    for _ in range(n): result = S(result)
    return result


def main(output):
    checks = []

    def check(name, condition):
        if not condition: raise AssertionError(name)
        checks.append(name)

    reg = Registry()
    for name, body in [
        ("zero", ZERO), ("one", ONE), ("succ", S(U)), ("id", U),
        ("pred", D("succ", U, ZERO)),
        ("double", D("succ", S(U), U)),
        ("threshold", D("one", U, ZERO)),
    ]:
        reg.add(name, body)

    rejected_descriptors = []
    for name, body in [
        ("reads_counter", S(V("n"))),
        ("free_parameter", D("succ", U, V("a"))),
        ("self", D("self", U, ZERO)),
        ("forward", D("not_yet_declared", U, ZERO)),
    ]:
        try: reg.add(name, body)
        except ValueError: rejected_descriptors.append(name)
        else: raise AssertionError("bad descriptor accepted")
    check("four_invalid_descriptor_controls", len(rejected_descriptors) == 4)
    check("all_updates_have_only_state_variable", all(fv_term(b) <= {"v"} for b in reg.bodies.values()))

    before = dict(reg.bodies)
    probe = D("succ", V("v"), V("a"))
    check("active_substitution_does_not_enter_descriptor",
          subst_term(probe, "v", ZERO) == D("succ", ZERO, A) and reg.bodies == before)
    capture = subst_formula(All("a", Eq(N, A)), "n", A)
    check("general_substitution_avoids_capture", fv_formula(capture) == {"a"} and capture[1] != "a")
    stationary_probe = make_A("succ")
    check("bound_induction_name_is_not_substituted",
          subst_formula(stationary_probe, "n", S(N)) == stationary_probe)

    atoms = [Eq(N, A), Eq(D("succ", N, A), S(A)), Eq(ZERO, ZERO), Bot()]
    matrices = atoms[:]
    for left in atoms:
        for right in atoms:
            matrices.extend([And(left, right), Or(left, right), Imp(left, right)])
    generated = [("G", make_G(m, reg)) for m in matrices]
    generated += [(kind, factory(h)) for h in reg.bodies for kind, factory in
                  [("A", make_A), ("B", lambda h: make_B(h, reg))]]
    for expected, f in generated:
        check(f"generated_{len(checks):03d}_is_exact_{expected}", classify(f, reg) == expected)
        axiom = emit(f)
        check(f"generated_{len(checks):03d}_is_closed_two_name_axiom",
              not fv_formula(axiom) and all_names(axiom) <= {"n", "a"})
        if expected in {"A", "B"}:
            check(f"stationary_{len(checks):03d}", "n" not in fv_formula(f) and subst_formula(f, "n", ZERO) == f)

    bad = {
        "reversed_delta_orientation": Imp(Or(Eq(ZERO, ZERO), Eq(ONE, ZERO)), Eq(N, N)),
        "wrong_G_zero_specialization": Imp(Or(Eq(A, A), DELTA), Eq(N, A)),
        "extra_free_parameter": Imp(Or(Eq(ZERO, V("b")), DELTA), Eq(N, V("b"))),
        "quantified_active_matrix": Imp(Or(All("n", Eq(N, N)), DELTA), All("n", Eq(N, N))),
        "wrong_reset_update": All("n", Eq(D("succ", D("zero", N, ZERO), A), A)),
        "wrong_reset_seed": All("n", Eq(D("succ", D("one", N, ONE), A), A)),
        "alpha_renamed_stationary_not_literal": All("b", seed_equation("succ", V("b"), A)),
        "step_missing_one_successor": All("n", Eq(D("succ", S(A), N), S(D("succ", S(A), N)))),
        "step_update_wrong_argument": All("n", Eq(D("succ", S(S(A)), N), S(D("succ", A, N)))),
    }
    for name, f in bad.items(): check("reject_" + name, classify(f, reg) is None)

    # Stationary extraction itself is a logical argument in the report.
    # Here we check its concrete computation substitutions and congruences.
    two = S(ONE)
    q_two = step_equation(reg, "one", ZERO, ZERO)
    check("q_two_zero_is_one_by_step", q_two == Eq(D("one", two, ZERO), ONE))
    one_laws = {}
    for h in reg.bodies:
        law = rewrite_equation(seed_equation(h, two, A), q_two)
        check("extract_one_seed_" + h, law == Eq(D(h, ONE, A), A))
        one_laws[h] = law
    q_one = subst_formula(one_laws["one"], "a", ZERO)
    check("q_one_zero_is_zero_by_derived_one_seed", q_one == Eq(D("one", ONE, ZERO), ZERO))
    for h in reg.bodies:
        law = rewrite_equation(seed_equation(h, ONE, A), q_one)
        check("extract_zero_seed_" + h, law == Eq(D(h, ZERO, A), A))

    def p(t): return D("succ", t, ZERO)
    pred_step = step_equation(reg, "succ", N, ZERO)
    induction_hypothesis = Eq(p(S(N)), N)
    check("predecessor_successor_induction_step",
          rewrite_equation(pred_step, induction_hypothesis) == Eq(p(S(S(N))), S(N)))
    for h in reg.bodies:
        check("shifted_ordinary_iterator_step_" + h,
              step_equation(reg, h, N, A) == Eq(D(h, S(S(N)), A), reg.body_at(h, D(h, S(N), A))))

    check("separation_is_G_of_bottom", make_G(Bot(), reg) == Imp(Or(Bot(), DELTA), Bot()))
    opaque_f = ("F", N, A)
    opaque_next = ("F", S(N), A)
    opaque_schema = All("a", Imp(All("n", Imp(opaque_f, opaque_next)), All("n", opaque_f)))
    check("opaque_outer_partial_AST_count", count_opaque_template(opaque_schema) == 15)
    old_zero = Eq(D("succ", ZERO, A), A)
    old_one = Eq(D("succ", ONE, A), A)
    new_seed = seed_equation("succ", N, A)
    check("raw_seed_atom_counts", (count_formula(old_zero), count_formula(old_one), count_formula(new_seed)) == (5, 6, 7))
    check("stationary_A_matrix_and_axiom_counts", count_formula(make_A("succ")) == 8 and count_formula(emit(make_A("succ"))) == 29)

    standard_checks = 0
    for h in reg.bodies:
        for n in range(9):
            for a in range(6):
                env = {"n": n, "a": a}
                for equation in [seed_equation(h, N, A), step_equation(reg, h, N, A)]:
                    check(f"bounded_{standard_checks:04d}", eval_term(equation[1], env, reg) == eval_term(equation[2], env, reg))
                    standard_checks += 1
                check(f"roundtrip_bounded_{standard_checks:04d}",
                      eval_term(D(h, N, A), env, reg) == eval_term(D(h, S(p(N)), A), env, reg))
                standard_checks += 1
    for n in range(15):
        check(f"predecessor_bounded_{n}", eval_term(p(numeric_term(n)), {}, reg) == max(n - 1, 0))

    # These staged standard-N structures satisfy the other two delayed
    # equations (and all QFI) while falsifying the omitted initial law.
    omitted = []
    for mode, counter in [("missing_one", 2), ("missing_zero", 1)]:
        for h in reg.bodies:
            for n in range(6):
                for a in range(4):
                    equation = step_equation(reg, h, N, A)
                    env = {"n": n, "a": a}
                    check(f"{mode}_retains_step_{h}_{n}_{a}",
                          eval_term(equation[1], env, reg, mode) == eval_term(equation[2], env, reg, mode))
        witness = seed_equation("succ", numeric_term(counter), ZERO)
        values = [eval_term(t, {}, reg, mode) for t in witness[1:]]
        check(mode + "_compressed_seed_law_rejects_model", values[0] != values[1])
        omitted.append({"omitted_initial_law": mode, "failed_compressed_seed_instance": show_formula(witness), "values": values})

    trace = [
        show_formula(q_two),
        show_formula(seed_equation("succ", two, A)),
        show_formula(one_laws["succ"]),
        show_formula(q_one),
        show_formula(seed_equation("succ", ONE, A)),
        show_formula(Eq(D("succ", ZERO, A), A)),
    ]
    result = {
        "status": "passed",
        "scope": "Finite syntax, substitution/scoping, extraction skeletons, partial counts, and bounded standard arithmetic; not a formal proof of the infinite bi-interpretability theorem.",
        "check_count": len(checks),
        "generated_matrix_count": len(generated),
        "negative_formula_controls": list(bad),
        "negative_descriptor_controls": rejected_descriptors,
        "descriptor_order": [{"name": name, "body": show_term(body), "body_AST_nodes": count_term(body), "earlier_references": sorted(descriptor_refs(body))} for name, body in reg.bodies.items()],
        "examples": {"G": show_formula(make_G(Eq(N, A), reg)), "A": show_formula(make_A("succ")), "B": show_formula(make_B("succ", reg))},
        "one_seed_then_zero_seed_extraction_trace": trace,
        "partial_counts": {
            "outer_opaque_matrix_template": 15,
            "separate_zero_and_one_seed_atoms": [5, 6],
            "compressed_reset_atom": 7,
            "compressed_reset_atom_quantified_in_n_and_a": 9,
            "stationary_reset_matrix": 8,
            "emitted_stationary_reset_axiom": 29,
            "old_K_plus_I_root_patterns": 4,
            "new_delayed_root_patterns": 2,
            "excluded_costs": "Stored update descriptors, entire generator implementation and logical calculus; the constant-one descriptor contains S0. The outer count additionally treats F as an opaque two-argument placeholder."
        },
        "bounded_standard_equation_and_roundtrip_checks": standard_checks,
        "omitted_initial_constraint_controls": omitted,
        "all_check_names": checks,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: result[key] for key in ["status", "check_count", "generated_matrix_count", "bounded_standard_equation_and_roundtrip_checks"]}))
    print("Result: " + str(output.resolve()))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("results.json"))
    args = parser.parse_args()
    main(args.output)
