A SHORTER GUARDED AXIOMATIZATION OF PRIMITIVE RECURSIVE ARITHMETIC
31 October 2026
================================================================

Main deliverables
-----------------
pra_guard_reduction.pdf       Complete mathematical paper.
pra_guard_reduction.tex       Main LaTeX source.
sections/*.tex               Included LaTeX sections.
axioms.txt                   Exact independent axiom specification.

Result
------
The initial-value premise f(0,a)=0 in the current seeded draft's FACTORED
arithmetic schema is redundant. Delete it with no replacement, added axiom,
admission condition, function symbol, or parameter. The shortened schema
contains six equality occurrences rather than seven. It also gives a direct
equation-induction reduction using f=S(s), g=t, removing the old masking and
delay argument.

Keep the restricted binary iteration equations
  I_h(0,a)=a; I_h(Sn,a)=h(n,I_h(n,a)),
where h has only n,v free. Together with the new schema these are three
axiom templates. The paper proves exact conservative definitional equivalence
to full ordinary PRA, separately in classical and intuitionistic logic.

The proof includes equality reflection, quantifier-free formula compilation,
one-parameter pairing, and state-carrying translation of general recursion.
Those constructions are inherited from, and attributed to, the existing
drafts. The new result is the premise deletion and direct core reduction.

Comparison scope
----------------
All six archives in docs/drafts at ProveIt commit
1933ee3d1630a43f96bfe16aeb88a8371b52082e were compared. Git blob hashes were
verified against the downloaded bytes. docs/incoming and its README had no
PRA entries at that snapshot. Its unrelated Con(PA) archives were not used.

The earlier separation-plus-G presentation remains smaller under the chosen
literal syntax-tree metric: 42 nodes versus the new single schema's 48.
The new schema improves the existing SINGLE arithmetic-schema architecture
(formerly 54 nodes) while retaining binary iteration and one parameter.
There is no absolute minimality or historical-priority claim.

Important distinction
---------------------
The premise can be deleted from the factored conclusion. Deleting it from
the uniform XOR conclusion is invalid. The paper gives the symbolic standard-
model counterexample f=1, g=0. The unresolved one-term proposal without its
extra subtraction law is not assumed or claimed complete.

Supporting artifacts
--------------------
formal/GuardedPRA.lean          New constructive certificate for the core.
formal/README.txt              Exact formalization scope and build command.
formal/verification.txt        Lean version and nine dependency checks.
artifacts/schema_counts.py     Executable formula AST counter.
artifacts/schema_counts.json   Reproduced count results.
evidence/source_audit.json     Source revision, sizes, hashes, member inventory.
evidence/proof_audit.txt       Independent core audit and XOR counterexample.
VALIDATION.txt                Reproduction and PDF validation status.
SHA256SUMS.txt                Hashes of final package files, excluding itself.

Build the PDF
-------------
Use a TeX installation with pdflatex, latexmk, and the packages named in the
main source (ordinary TeX Live installations provide them). From this folder:

  latexmk -pdf -interaction=nonstopmode -halt-on-error pra_guard_reduction.tex

The delivered PDF was compiled from the included source and visually checked.

Reproduce syntax counts
-----------------------
Requires Python 3.10 or newer, with the standard library only:

  python3 artifacts/schema_counts.py --output artifacts/schema_counts.json

Reproduce the scoped Lean check
------------------------------
With Lean 4.19.0 available as `lean`:

  lean formal/GuardedPRA.lean

No Mathlib or other dependency is needed. All nine printed theorems report
no axiom dependencies. This is a statement about the checked conditional
theorems, not an assertion that the mathematical hypotheses were omitted.
The full first-order equivalence theorem remains a complete written proof;
it is not claimed to be fully formalized by this scoped certificate.

No earlier draft archives or external toolchain binaries are redistributed.
