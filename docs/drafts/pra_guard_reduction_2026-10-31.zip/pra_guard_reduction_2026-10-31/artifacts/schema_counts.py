#!/usr/bin/env python3
"""Count five displayed PRA arithmetic schemata in an explicit AST grammar.

Run with Python 3.10 or later:
    python3 schema_counts.py
    python3 schema_counts.py --output schema_counts.json

Each variable, constant, function application, equality, logical connective,
and quantifier occurrence is one node. Binder names are metadata. Negation
is expanded to implication into bottom; exclusive disjunction is expanded
to (P or Q) and ((P and Q) -> bottom). Each schematic term application has
the displayed induction argument and every fixed numerical parameter as
children. Formula trees count occurrences, even if Python objects are shared.

G and Sep remain two separate formulas: no artificial conjunction is added.
Computation axioms, parentheses, commas, and the internal programs substituted
for the schematic terms are omitted. This is a syntactic comparison, not a
mathematical equivalence proof or an absolute minimality result.
"""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
import json
from pathlib import Path


@dataclass(frozen=True)
class Node:
    """An AST node; label records a variable, function, or bound-variable name."""

    kind: str
    children: tuple[Node, ...] = ()
    label: str = ""


def variable(name: str) -> Node:
    return Node("variable", label=name)


def zero() -> Node:
    return Node("constant", label="0")


def successor(term: Node) -> Node:
    return Node("function", (term,), "S")


def equals(left: Node, right: Node) -> Node:
    return Node("equality", (left, right))


def conjunction(left: Node, right: Node) -> Node:
    return Node("and", (left, right))


def disjunction(left: Node, right: Node) -> Node:
    return Node("or", (left, right))


def implies(left: Node, right: Node) -> Node:
    return Node("implies", (left, right))


def negation(formula: Node) -> Node:
    return implies(formula, Node("bottom"))


def exclusive(left: Node, right: Node) -> Node:
    return conjunction(disjunction(left, right), negation(conjunction(left, right)))


def forall(name: str, formula: Node) -> Node:
    return Node("forall", (formula,), name)


def schemata(parameter_count: int = 1) -> dict[str, tuple[Node, ...]]:
    """Construct the actual formula trees; there are no numerical count inputs."""
    if parameter_count < 0:
        raise ValueError("The parameter count must be nonnegative.")
    n = variable("n")
    parameters = tuple(variable(f"a{i}") for i in range(parameter_count))

    def term(name: str, argument: Node) -> Node:
        return Node("schematic_application", (argument, *parameters), name)

    def f(argument: Node) -> Node:
        return term("f", argument)

    def g(argument: Node) -> Node:
        return term("g", argument)

    def close(formula: Node) -> Node:
        for parameter in reversed(parameters):
            formula = forall(parameter.label, formula)
        return formula

    def e(argument: Node) -> Node:
        return equals(f(argument), successor(g(argument)))

    def guard(argument: Node) -> Node:
        return disjunction(equals(argument, zero()), e(argument))

    def old_zero(argument: Node) -> Node:
        return equals(f(argument), zero())

    def old_b(argument: Node) -> Node:
        return disjunction(old_zero(argument), e(argument))

    base = equals(f(zero()), zero())
    step = forall("n", implies(guard(n), e(successor(n))))
    anchor = negation(equals(zero(), successor(g(zero()))))
    positive_conclusion = forall("n", guard(n))

    old_x = close(implies(
        conjunction(old_b(zero()), forall("n", implies(old_b(n), old_b(successor(n))))),
        forall("n", exclusive(old_zero(n), e(n))),
    ))
    old_y1 = close(implies(
        conjunction(base, step),
        forall("n", exclusive(equals(n, zero()), e(n))),
    ))
    old_a = close(implies(
        conjunction(base, step),
        conjunction(anchor, positive_conclusion),
    ))
    new_a_prime = close(implies(step, conjunction(anchor, positive_conclusion)))

    def ordinary_e(argument: Node) -> Node:
        return equals(f(argument), g(argument))

    ordinary_step = forall("n", implies(
        disjunction(equals(n, zero()), ordinary_e(n)),
        ordinary_e(successor(n)),
    ))
    ordinary_guard = close(implies(
        ordinary_step,
        forall("n", disjunction(equals(n, zero()), ordinary_e(n))),
    ))
    separation = negation(equals(zero(), successor(zero())))
    return {
        "old_exclusive_X": (old_x,),
        "old_guarded_successor_Y1": (old_y1,),
        "old_seeded_factored_A": (old_a,),
        "new_base_free_A_prime": (new_a_prime,),
        "old_G_plus_Sep": (ordinary_guard, separation),
    }


def count_tree(tree: Node) -> Counter[str]:
    result = Counter({tree.kind: 1})
    for child in tree.children:
        result.update(count_tree(child))
    return result


def summarize(trees: tuple[Node, ...]) -> dict[str, object]:
    counts: Counter[str] = Counter()
    separate_sizes = []
    for tree in trees:
        current = count_tree(tree)
        counts.update(current)
        separate_sizes.append(sum(current.values()))
    return {
        "arithmetic_templates": len(trees),
        "atomic_equality_occurrences": counts["equality"],
        "schematic_term_applications": counts["schematic_application"],
        "total_AST_nodes": sum(counts.values()),
        "separate_formula_sizes": separate_sizes,
        "by_node_kind": dict(sorted(counts.items())),
    }


def make_report(parameter_count: int = 1) -> dict[str, object]:
    return {
        "metric": {
            "parameter_count": parameter_count,
            "unit": "One node per variable, constant, function application, equality, "
                    "connective, or quantifier occurrence.",
            "negation": "Expanded as A -> bottom.",
            "exclusive_disjunction": "Expanded as (A or B) and ((A and B) -> bottom).",
            "binders": "The outer parameter quantifiers count; binder names are metadata.",
            "schematic_terms": "Each f/g application counts once and its argument "
                               "and fixed parameters count separately.",
            "separate_formulas": "G and Sep are separately counted and their sizes added.",
            "omissions": "Shared computation templates, punctuation, and expansions "
                         "of f/g into particular primitive-recursive programs.",
            "scope": "A syntactic comparison in this grammar, not an absolute minimum.",
        },
        "systems": {
            name: summarize(trees)
            for name, trees in schemata(parameter_count).items()
        },
        "base_deletion_caution": {
            "valid_observation": "Under f(0,a)=0, forall n XOR(n=0,E(n,a)) is "
                "intuitionistically equivalent to 0!=S(g(0,a)) and "
                "forall n (n=0 or E(n,a)), where E is f=S(g).",
            "invalid_change": "Deleting the base from the unfactored XOR schema.",
            "counterexample": "In the standard naturals set f(n,a)=1 and g(n,a)=0. "
                "Every E(n,a) is true, hence the guarded step is universally true. "
                "At n=0 both alternatives of XOR are true, so the XOR conclusion "
                "is false. The new factored conclusion is true in this example.",
            "proof_status": "The counterexample is symbolic for all n, not a bounded test.",
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Write the JSON report to this path.")
    parser.add_argument("--parameters", type=int, default=1)
    args = parser.parse_args()
    report = make_report(args.parameters)
    rendered = json.dumps(report, indent=2, ensure_ascii=True) + "\n"
    if args.output is None:
        print(rendered, end="")
    else:
        args.output.write_text(rendered, encoding="utf-8")
        for name, result in report["systems"].items():
            print(f"{name}: {result['atomic_equality_occurrences']} equalities, "
                  f"{result['schematic_term_applications']} schematic applications, "
                  f"{result['total_AST_nodes']} AST nodes")


if __name__ == "__main__":
    main()
