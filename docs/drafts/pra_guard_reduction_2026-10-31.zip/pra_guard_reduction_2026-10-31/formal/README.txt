SCOPED LEAN CERTIFICATE
======================

File: GuardedPRA.lean
Compiler used: Lean 4.19.0 (commit 6caaee842e94).
Dependencies: implicit Init only; no Mathlib or package imports.

Run from the package root:
  lean formal/GuardedPRA.lean

Actual finite syntax
--------------------
The Term datatype has exactly the induction variable, one parameter variable,
zero, successor, and arbitrary binary function applications. It does not
replace syntactic schematic terms by quantification over arbitrary numerical
functions. Predecessor is the application of a distinguished binary symbol
at seed zero. Its two computation laws are explicit hypotheses.

Proved core reductions
----------------------
1. New schema -> separation and positive predecessor coverage.
2. Direct successor nonzeroness from f=Sa, g=a.
3. Successor injectivity from predecessor computation.
4. Successor nonzeroness from predecessor computation and separation.
5. Direct equation induction from f=S(s), g=t.
6. New schema -> all old guarded-equation instances.
7. Separation + all old guarded-equation instances -> new schema.
8. Equivalence of the two arithmetic bases.
9. Soundness from quantifier-free induction and successor nonzeroness,
   using an actual quantifier-free Formula datatype.

Limits
------
These are constructive model-level conditional deductions in Lean. The
complete first-order derivation calculus, well-founded primitive-recursion
description grammar, equality-reflection bootstrap, pairing, and conservative
definitional-extension theorem are not formalized in this file. The paper
supplies those proofs separately. No claim of full formal verification is made.

All nine #print axioms checks report no axiom dependencies. There are no
admitted proofs and no use of classical reasoning or choice. The explicit
arithmetic hypotheses remain part of the theorem statements.

The syntax-and-algebra organization is adapted, with attribution, from the
seeded-guard source archive at ProveIt revision
1933ee3d1630a43f96bfe16aeb88a8371b52082e. The new direct proof removes that
certificate's gate, masking, and delayed-substitution infrastructure.
