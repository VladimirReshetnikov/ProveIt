/-!
# The shortened guarded core of PRA

Lean 4.19.0; Init only. No classical reasoning or admitted proofs.

This certificate checks the new schema A' on actual finite terms with an
index variable, one parameter variable, 0, successor, and arbitrary binary
function applications. The predecessor helper is an ordinary application
of a distinguished binary symbol at seed 0. Its two displayed laws are
explicit assumptions, supplied by the seeded recursion equations in the
paper. No gate, selector, substitution, or delayed equation is needed.

The model-level proof is constructive and covers A' -> separation,
constructor coverage, successor laws, and equation induction; equivalence
with separation plus the earlier guarded equation schema; and the converse
from quantifier-free induction. It does not formalize first-order
derivations, the complete recursion-description grammar, equality-test
reflection, pairing, or the full conservative-extension theorem.

The syntax-and-algebra organization adapts the scoped certificate in the
ProveIt archive pra_seeded_guard_2026-10-31.zip, commit
1933ee3d1630a43f96bfe16aeb88a8371b52082e. The present direct reductions
remove the old base premise and the old mask/delay infrastructure.
-/

namespace GuardedPRA

universe u v

inductive Term (Fn : Type u) where
  | index : Term Fn
  | parameter : Term Fn
  | zero : Term Fn
  | succ : Term Fn -> Term Fn
  | app : Fn -> Term Fn -> Term Fn -> Term Fn

structure Algebra (Fn : Type u) where
  Carrier : Type v
  zero : Carrier
  succ : Carrier -> Carrier
  app : Fn -> Carrier -> Carrier -> Carrier

def Algebra.eval {Fn : Type u} (M : Algebra.{u,v} Fn)
    (t : Term Fn) (n a : M.Carrier) : M.Carrier :=
  match t with
  | .index => n
  | .parameter => a
  | .zero => M.zero
  | .succ s => M.succ (M.eval s n a)
  | .app f s t => M.app f (M.eval s n a) (M.eval t n a)

def Algebra.pred {Fn : Type u} (M : Algebra.{u,v} Fn)
    (p : Fn) (n : M.Carrier) : M.Carrier := M.app p n M.zero

structure PredecessorLaws {Fn : Type u} (M : Algebra.{u,v} Fn)
    (p : Fn) : Prop where
  at_zero : M.pred p M.zero = M.zero
  at_succ : forall n, M.pred p (M.succ n) = n

def Separation {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop :=
  M.zero ≠ M.succ M.zero

def Guard {Fn : Type u} (M : Algebra.{u,v} Fn)
    (f g : Term Fn) (n a : M.Carrier) : Prop :=
  n = M.zero \/ M.eval f n a = M.succ (M.eval g n a)

def Step {Fn : Type u} (M : Algebra.{u,v} Fn)
    (f g : Term Fn) (a : M.Carrier) : Prop :=
  forall n, Guard M f g n a ->
    M.eval f (M.succ n) a = M.succ (M.eval g (M.succ n) a)

def Kernel {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop :=
  forall (f g : Term Fn) (a : M.Carrier), Step M f g a ->
    M.zero ≠ M.succ (M.eval g M.zero a) /\
    forall n, Guard M f g n a

theorem successor_nonzero_from_kernel {Fn : Type u}
    (M : Algebra.{u,v} Fn) (hk : Kernel M) (n : M.Carrier) :
    M.succ n ≠ M.zero := by
  have hs : Step M (.succ .parameter) .parameter n := fun _ _ => rfl
  have h := (hk (.succ .parameter) .parameter n hs).1
  exact fun he => h he.symm

theorem separation_and_coverage {Fn : Type u} (M : Algebra.{u,v} Fn)
    (p : Fn) (hl : PredecessorLaws M p) (hk : Kernel M) :
    Separation M /\ forall n, n = M.zero \/ n = M.succ (M.pred p n) := by
  have hs : Step M .index (.app p .index .zero) M.zero := by
    intro n _
    change M.succ n = M.succ (M.pred p (M.succ n))
    rw [hl.at_succ]
  obtain ⟨hsep, hcov⟩ := hk .index (.app p .index .zero) M.zero hs
  change M.zero ≠ M.succ (M.pred p M.zero) at hsep
  rw [hl.at_zero] at hsep
  exact ⟨hsep, hcov⟩

theorem successor_injective {Fn : Type u} (M : Algebra.{u,v} Fn)
    (p : Fn) (hl : PredecessorLaws M p) {x y : M.Carrier}
    (he : M.succ x = M.succ y) : x = y := by
  have hp := congrArg (M.pred p) he
  rw [hl.at_succ, hl.at_succ] at hp
  exact hp

theorem successor_nonzero {Fn : Type u} (M : Algebra.{u,v} Fn)
    (p : Fn) (hl : PredecessorLaws M p) (hsep : Separation M)
    (n : M.Carrier) : M.succ n ≠ M.zero := by
  intro he
  have hn : n = M.zero := by
    have hp := congrArg (M.pred p) he
    rw [hl.at_succ, hl.at_zero] at hp
    exact hp
  exact hsep (he.symm.trans (congrArg M.succ hn))

def EquationInduction {Fn : Type u} (M : Algebra.{u,v} Fn)
    (s t : Term Fn) (a : M.Carrier) : Prop :=
  M.eval s M.zero a = M.eval t M.zero a ->
  (forall n, M.eval s n a = M.eval t n a ->
    M.eval s (M.succ n) a = M.eval t (M.succ n) a) ->
  forall n, M.eval s n a = M.eval t n a

theorem equation_induction {Fn : Type u} (M : Algebra.{u,v} Fn)
    (p : Fn) (hl : PredecessorLaws M p) (hk : Kernel M)
    (s t : Term Fn) (a : M.Carrier) : EquationInduction M s t a := by
  intro hbase hstep
  have extract : forall n, Guard M (.succ s) t n a ->
      M.eval s n a = M.eval t n a := by
    intro n hn
    rcases hn with hz | he
    · rw [hz]
      exact hbase
    · exact successor_injective M p hl he
  have hs : Step M (.succ s) t a := by
    intro n hn
    exact congrArg M.succ (hstep n (extract n hn))
  intro n
  exact extract n ((hk (.succ s) t a hs).2 n)

def OldGuarded {Fn : Type u} (M : Algebra.{u,v} Fn)
    (s t : Term Fn) (a : M.Carrier) : Prop :=
  (forall n, (n = M.zero \/ M.eval s n a = M.eval t n a) ->
    M.eval s (M.succ n) a = M.eval t (M.succ n) a) ->
  forall n, n = M.zero \/ M.eval s n a = M.eval t n a

theorem old_guarded {Fn : Type u} (M : Algebra.{u,v} Fn)
    (p : Fn) (hl : PredecessorLaws M p) (hk : Kernel M)
    (s t : Term Fn) (a : M.Carrier) : OldGuarded M s t a := by
  intro hstep
  have extract : forall n, Guard M (.succ s) t n a ->
      n = M.zero \/ M.eval s n a = M.eval t n a := by
    intro n hn
    rcases hn with hz | he
    · exact Or.inl hz
    · exact Or.inr (successor_injective M p hl he)
  have hs : Step M (.succ s) t a := by
    intro n hn
    exact congrArg M.succ (hstep n (extract n hn))
  intro n
  exact extract n ((hk (.succ s) t a hs).2 n)

theorem kernel_of_old_guarded {Fn : Type u} (M : Algebra.{u,v} Fn)
    (p : Fn) (hl : PredecessorLaws M p) (hsep : Separation M)
    (hg : forall s t a, OldGuarded M s t a) : Kernel M := by
  intro f g a hs
  refine ⟨?_, hg f (.succ g) a hs⟩
  intro he
  exact successor_nonzero M p hl hsep (M.eval g M.zero a) he.symm

theorem kernel_iff_old_guarded {Fn : Type u} (M : Algebra.{u,v} Fn)
    (p : Fn) (hl : PredecessorLaws M p) :
    Kernel M <-> Separation M /\ forall s t a, OldGuarded M s t a := by
  constructor
  · intro hk
    exact ⟨(separation_and_coverage M p hl hk).1, old_guarded M p hl hk⟩
  · intro h
    exact kernel_of_old_guarded M p hl h.1 h.2

inductive Formula (Fn : Type u) where
  | equal : Term Fn -> Term Fn -> Formula Fn
  | bottom : Formula Fn
  | and : Formula Fn -> Formula Fn -> Formula Fn
  | or : Formula Fn -> Formula Fn -> Formula Fn
  | imp : Formula Fn -> Formula Fn -> Formula Fn

def Formula.holds {Fn : Type u} (M : Algebra.{u,v} Fn)
    (A : Formula Fn) (n a : M.Carrier) : Prop :=
  match A with
  | .equal s t => M.eval s n a = M.eval t n a
  | .bottom => False
  | .and B C => B.holds M n a /\ C.holds M n a
  | .or B C => B.holds M n a \/ C.holds M n a
  | .imp B C => B.holds M n a -> C.holds M n a

def QuantifierFreeInduction {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop :=
  forall (A : Formula Fn) (a : M.Carrier), A.holds M M.zero a ->
    (forall n, A.holds M n a -> A.holds M (M.succ n) a) ->
    forall n, A.holds M n a

theorem kernel_of_quantifier_free_induction {Fn : Type u}
    (M : Algebra.{u,v} Fn) (hnonzero : forall n, M.succ n ≠ M.zero)
    (hind : QuantifierFreeInduction M) : Kernel M := by
  intro f g a hs
  let B : Formula Fn := .or (.equal .index .zero) (.equal f (.succ g))
  have hb : B.holds M M.zero a := Or.inl rfl
  have hstep : forall n, B.holds M n a -> B.holds M (M.succ n) a := by
    intro n hn
    exact Or.inr (hs n hn)
  refine ⟨?_, hind B a hb hstep⟩
  intro he
  exact hnonzero (M.eval g M.zero a) he.symm

#print axioms separation_and_coverage
#print axioms successor_nonzero_from_kernel
#print axioms successor_injective
#print axioms successor_nonzero
#print axioms equation_induction
#print axioms old_guarded
#print axioms kernel_of_old_guarded
#print axioms kernel_iff_old_guarded
#print axioms kernel_of_quantifier_free_induction

end GuardedPRA
