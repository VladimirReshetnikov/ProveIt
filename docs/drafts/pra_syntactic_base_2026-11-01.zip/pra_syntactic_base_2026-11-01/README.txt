PRA FROM ONE SCHEMA WITH A SYNTACTIC BASE CONDITION
Research report prepared for Vladimir Reshetnikov, 1 November 2026

RESULT

Two complete effective presentations are proved equivalent to first-order
primitive recursive arithmetic, separately in classical and intuitionistic
logic. Every function symbol has arity at most two, and every nonlogical
axiom uses at most two individual variable names. Each presentation has
one nonlogical schema and an explicit finite syntactic admission test.

D: a 29-node displayed schema. Its three-slot context A(x,z,c) is admitted
when A(0,R_h(0,c),c) is literally (B or 0=S0) -> B. The actual axiom uses
the diagonal A(n,a,a). Admission uses substitution and tree comparison.

N: a 26-node displayed schema. Its two-slot formula F(n,a) is admitted
when its zero instance, normalized by the two explicit rules
R_h(0,t) -> t and (0=S0) -> bottom, is literally B -> B.

Both recover initialization, successor computation, separation, and
one-parameter quantifier-free induction. A complete written constructive
pairing proof recovers arbitrary parameters and ordinary PR descriptions.
Both interpretation domains are the full carrier; both round trips are
internally the identity. A common conservative definitional extension
is proved, which is stronger than equiconsistency.

The counts are PARTIAL SCHEMA-DISPLAY COUNTS. They do not include the
language grammar, admission algorithm, arbitrary substituted formulas,
or update bodies. No absolute minimality claim is made. The 26-node
version has the smallest display found here; D gives the simpler
admission operation if arithmetic normalization is to be avoided.

CONTENTS

report.pdf                  Compiled, complete mathematical report.
report.tex                  Main LaTeX source.
normalization_variant.tex   Complete specification and proof for N.
pairing_appendix.tex         Full one-parameter arithmetic bootstrap.
formal/DiagonalSchema.lean  Finite syntax and logical equivalence for D.
formal/NormalizedSchema.lean
                            Normalization and logical equivalence for N.
artifacts/check_syntax.py   Independent executable syntax/metric checker.
artifacts/syntax_results.json
                            Full finite check results and template trees.
audit/source_manifest.json  Five compared archives, commit, immutable URLs,
                            Git blob checks, SHA-256 and source-member hashes.
audit/lean_results.json      Exact checked source hashes, compiler, output,
                            exit codes, and formalization boundary.
audit/validation.json        Build and final verification summary.
Makefile                    Portable rebuild/check targets.
SHA256SUMS                  Integrity hashes for the delivered files.

BUILD THE PDF

Requires a standard TeX Live installation, latexmk, and the packages named
in report.tex. From this directory:

    make pdf

or:

    latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build report.tex

The Makefile copies build/report.pdf to report.pdf.

CHECK THE LEAN FILES

Verified with Lean 4.19.0. No Mathlib or external packages are needed.
With `lean` on PATH:

    make formal

or from the formal directory:

    lean -o DiagonalSchema.olean DiagonalSchema.lean
    LEAN_PATH=. lean -o NormalizedSchema.olean NormalizedSchema.lean

The second module imports syntax infrastructure from the first; it does
not assume the D schema. Each module independently proves its schema's
equivalence to the binary one-parameter base. The main equivalence and
admission-check correctness theorems report only propext and Quot.sound
as Lean axiom dependencies. No Classical.choice or sorryAx is used.

FORMALIZATION BOUNDARY

Checked: actual finite terms and quantifier-free formulas; simultaneous
substitution; syntactic admission and executable checkers; the two
constructive logical equivalences; normalization soundness under the
base principles recovered from N.

Written proof only: the complete first-order proof calculus, restriction
to the finite well-founded recursion-description language, the entire
arithmetic/parameter compiler, and the final bi-interpretability theorem.
The Lean metatheoretic structures range over indexed binary signatures.
The report supplies the effective description grammar and its compiler.

CHECK THE INDEPENDENT SYNTAX DIAGNOSTICS

Requires Python 3.10 or later and only its standard library:

    make syntax

or:

    python3 artifacts/check_syntax.py --outfile artifacts/syntax_results.json

All 27 checks pass. Both induction-normalization constructions are tested
on 519 matrices, including 512 reproducibly generated cases. The exact
display counts are D=29, N=26, FI=42, NI=39, and implicit initialization
37+5r for r=0,1,2,3. These finite diagnostics are not proof verification.

COMPARISON

Repository: https://github.com/VladimirReshetnikov/ProveIt
Snapshot:   0bf6525f9b09421e5ffacdd5fba7648d28b7fcff
Directory:  docs/drafts

All five current archives were read and their downloaded bytes checked
against Git blob identifiers. Their previous eight-archive comparisons
are historical, not the inventory used for this report. The binary
language and one-parameter pairing construction are inherited and
credited; the new contribution is the proved logical compression and
its combination with the bounded variable interface.

The report includes explicit limits, countermodels to tempting deletions,
and a Further research questions section. The repository was only read.
