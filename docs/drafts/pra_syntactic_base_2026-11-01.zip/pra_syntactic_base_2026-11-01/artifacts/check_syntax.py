#!/usr/bin/env python3
"""Finite syntax checks and a disclosed, partial schema-tree size ledger.

Run with Python 3.10 or later; only the standard library is used::

    python3 artifacts/check_syntax.py --outfile artifacts/syntax_results.json

This program checks finite syntax manipulations, representative instances,
and display counts.  It does not check a first-order derivation, quantify
over all formula descriptions, or establish bi-interpretability.  The
mathematical arguments and the boundary of these diagnostics are in the
accompanying report.

Ledger convention: every variable, constant, function application, equality,
connective, quantifier, and schematic formula application is one node.
Displayed arguments are children and are charged.  Binder names label
quantifier nodes and are not separately charged.  Schematic A and h bodies,
the language grammar, and the admission algorithm are not included.  This
is a partial display metric, not a complete description-length measure.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path
import random
from typing import Mapping


@dataclass(frozen=True)
class AST:
    kind: str
    name: str = ""
    args: tuple["AST", ...] = ()

    @property
    def size(self) -> int:
        return 1 + sum(child.size for child in self.args)

    def data(self):
        """A JSON-compatible exact syntax tree, not pretty-printed notation."""
        return [self.kind, self.name, [child.data() for child in self.args]]


def var(name: str) -> AST:
    return AST("var", name)


def fun(name: str, *args: AST) -> AST:
    return AST("fun", name, tuple(args))


def eq(left: AST, right: AST) -> AST:
    return AST("eq", args=(left, right))


def conj(left: AST, right: AST) -> AST:
    return AST("and", args=(left, right))


def disj(left: AST, right: AST) -> AST:
    return AST("or", args=(left, right))


def impl(left: AST, right: AST) -> AST:
    return AST("imp", args=(left, right))


def forall(name: str, body: AST) -> AST:
    return AST("forall", name, (body,))


def quantifiers(names: list[str], body: AST) -> AST:
    for name in reversed(names):
        body = forall(name, body)
    return body


def schematic(name: str, *args: AST) -> AST:
    """Used only for the partial ledger, never as an admitted real formula."""
    return AST("schematic", name, tuple(args))


ZERO = fun("0")
BOTTOM = AST("bottom")
X, Z, C = var("x"), var("z"), var("c")
A, N = var("a"), var("n")


def succ(term: AST) -> AST:
    return fun("S", term)


def rec(first: AST, second: AST, symbol: str = "R_h") -> AST:
    return fun(symbol, first, second)


ERROR = eq(ZERO, succ(ZERO))


def free_variables(tree: AST) -> frozenset[str]:
    if tree.kind == "var":
        return frozenset([tree.name])
    result = frozenset().union(*(free_variables(t) for t in tree.args))
    if tree.kind == "forall":
        return result - {tree.name}
    return result


def is_term(tree: AST) -> bool:
    if tree.kind == "var":
        return not tree.args
    if tree.kind != "fun" or not all(is_term(t) for t in tree.args):
        return False
    if tree.name == "0":
        return not tree.args
    if tree.name == "S":
        return len(tree.args) == 1
    return len(tree.args) == 2


def is_qf_formula(tree: AST) -> bool:
    if tree.kind == "bottom":
        return not tree.args
    if tree.kind == "eq":
        return len(tree.args) == 2 and all(is_term(t) for t in tree.args)
    if tree.kind in {"and", "or", "imp"}:
        return len(tree.args) == 2 and all(is_qf_formula(t) for t in tree.args)
    return False


def substitute(tree: AST, replacements: Mapping[str, AST]) -> AST:
    """Literal simultaneous substitution on a quantifier-free syntax tree.

    A replacement is returned as given, without applying the replacement
    map again inside it.  Thus substitution is simultaneous, not sequential.
    Formula matrices contain no binders, so capture cannot occur.  Reject
    binders here rather than silently claiming capture-avoiding support for
    arbitrary first-order formulas.
    """
    if tree.kind == "forall":
        raise ValueError("Admission substitution is only for binder-free trees")
    if tree.kind == "var":
        return replacements.get(tree.name, tree)
    return AST(tree.kind, tree.name, tuple(substitute(t, replacements)
                                          for t in tree.args))


def guarded_admitted(matrix: AST, symbol: str = "R_h") -> bool:
    if not is_qf_formula(matrix) or not free_variables(matrix) <= {"x", "z", "c"}:
        return False
    at_base = substitute(matrix, {"x": ZERO, "z": rec(ZERO, C, symbol)})
    if at_base.kind != "imp":
        return False
    left, right = at_base.args
    return (left.kind == "or" and left.args[1] == ERROR
            and left.args[0] == right)


def normalize_term(term: AST, symbol: str = "R_h") -> AST:
    """Bottom-up use of just R_h(0,t) -> t for the selected description."""
    if not is_term(term):
        raise ValueError("Expected a term")
    if term.kind == "var":
        return term
    children = tuple(normalize_term(t, symbol) for t in term.args)
    if term.name == symbol and len(children) == 2 and children[0] == ZERO:
        return children[1]
    return AST(term.kind, term.name, children)


def normalize_formula(formula: AST, symbol: str = "R_h") -> AST:
    """The optional 26-node variant's explicitly restricted normalizer.

    First normalize terms bottom-up by R_h(0,t) -> t.  Replace an equality
    only when its normalized ordered sides are literally 0 and S(0), in
    that order.  No symmetry, equality proof, Boolean simplification, or
    successor computation is performed.
    """
    if not is_qf_formula(formula):
        raise ValueError("Expected a quantifier-free formula")
    if formula.kind == "bottom":
        return formula
    if formula.kind == "eq":
        result = eq(*(normalize_term(t, symbol) for t in formula.args))
        return BOTTOM if result == ERROR else result
    return AST(formula.kind, formula.name,
               tuple(normalize_formula(t, symbol) for t in formula.args))


def normalized_admitted(matrix: AST, symbol: str = "R_h") -> bool:
    if not is_qf_formula(matrix) or not free_variables(matrix) <= {"x", "c"}:
        return False
    at_base = normalize_formula(substitute(matrix, {"x": ZERO}), symbol)
    return at_base.kind == "imp" and at_base.args[0] == at_base.args[1]


def normalized_induction_instance(matrix: AST) -> AST:
    return impl(substitute(matrix, {"x": ZERO}), matrix)


def guarded_induction_instance(matrix: AST) -> AST:
    return impl(disj(substitute(matrix, {"x": ZERO}), ERROR), matrix)


def computation_matrices() -> tuple[AST, AST]:
    base = eq(rec(ZERO, A), A)
    step = eq(rec(succ(N), A), fun("h", N, rec(N, A)))
    return base, step


def progress(current: AST, successor: AST) -> AST:
    return forall("n", impl(current, successor))


def fused_template(diagonal: bool) -> AST:
    """29 nodes for three displayed A slots, 26 for two displayed slots."""
    parameters = [A, A] if diagonal else [A]
    current = schematic("A", N, *parameters)
    following = schematic("A", succ(N), *parameters)
    _, step = computation_matrices()
    return forall("a", impl(progress(current, following),
                            forall("n", conj(current, step))))


def baseline_fi_trees() -> list[AST]:
    base, step = computation_matrices()
    at_zero = schematic("A", ZERO, A)
    current = schematic("A", N, A)
    following = schematic("A", succ(N), A)
    fi = forall("a", impl(conj(disj(at_zero, ERROR),
                               progress(current, following)),
                          forall("n", current)))
    return [forall("a", base), quantifiers(["n", "a"], step), fi]


def baseline_ni_trees() -> list[AST]:
    base, step = computation_matrices()
    current = schematic("A", N, A)
    following = schematic("A", succ(N), A)
    ni = forall("a", impl(progress(current, following), forall("n", current)))
    return [forall("a", base), quantifiers(["n", "a"], step),
            impl(ERROR, BOTTOM), ni]


def implicit_initialization_template(extra_parameters: int) -> AST:
    if extra_parameters < 0:
        raise ValueError("The extra parameter count must be nonnegative")
    names = ["a"] + [f"c{i}" for i in range(extra_parameters)]
    extra = [var(name) for name in names[1:]]
    base = schematic("A", ZERO, rec(ZERO, A), *extra)
    current = schematic("A", N, A, *extra)
    following = schematic("A", succ(N), A, *extra)
    _, step = computation_matrices()
    premise = conj(disj(base, ERROR), progress(current, following))
    return quantifiers(names, impl(premise, forall("n", conj(current, step))))


def generated_matrices(seed: int, count: int) -> list[AST]:
    """A reproducible finite sample of genuine QF matrices in x,c."""
    rng = random.Random(seed)

    def term(depth: int) -> AST:
        if depth == 0 or rng.randrange(4) == 0:
            return rng.choice([ZERO, X, C])
        if rng.randrange(3) == 0:
            return succ(term(depth - 1))
        return rec(term(depth - 1), term(depth - 1),
                   rng.choice(["R_h", "R_g"]))

    def formula(depth: int) -> AST:
        if depth == 0 or rng.randrange(3) == 0:
            return BOTTOM if rng.randrange(6) == 0 else eq(term(2), term(2))
        return rng.choice([conj, disj, impl])(formula(depth - 1), formula(depth - 1))

    special = [BOTTOM, eq(ZERO, ZERO), ERROR, eq(X, C),
               eq(rec(X, C), rec(C, X)),
               impl(eq(X, C), BOTTOM),
               conj(eq(X, ZERO), disj(eq(C, ZERO), ERROR))]
    return special + [formula(3) for _ in range(count)]


def run_checks() -> dict:
    checks: list[dict] = []

    def check(name: str, condition: bool) -> None:
        if not condition:
            raise AssertionError(name)
        checks.append({"name": name, "passed": True})

    seed = 20261101
    matrices = generated_matrices(seed, 512)
    zero_seed = rec(ZERO, C)
    guarded_probes = {
        "successor_computation": impl(disj(eq(ZERO, ZERO), ERROR), eq(ZERO, ZERO)),
        "separation": impl(disj(BOTTOM, ERROR), BOTTOM),
        "initialization": impl(disj(eq(zero_seed, zero_seed), ERROR), eq(Z, zero_seed)),
    }
    normalized_probes = {
        "successor_computation": impl(eq(ZERO, ZERO), eq(ZERO, ZERO)),
        "separation": impl(ERROR, BOTTOM),
        "initialization": impl(eq(C, C), eq(zero_seed, C)),
    }
    for name, matrix in guarded_probes.items():
        check("guarded probe: " + name, guarded_admitted(matrix))
    for name, matrix in normalized_probes.items():
        check("normalized probe: " + name, normalized_admitted(matrix))

    check("guarded admission rejects bottom", not guarded_admitted(BOTTOM))
    check("normalized admission rejects bottom", not normalized_admitted(BOTTOM))
    check("guarded admission rejects bare reflexive implication",
          not guarded_admitted(impl(eq(C, C), eq(C, C))))
    check("guarded admission is ordered, not commutative",
          not guarded_admitted(impl(disj(ERROR, eq(C, C)), eq(C, C))))
    check("guarded admission rejects a fourth free variable",
          not guarded_admitted(impl(disj(eq(var("d"), C), ERROR), eq(var("d"), C))))
    check("normalized admission rejects a third free variable",
          not normalized_admitted(impl(eq(Z, C), eq(Z, C))))
    check("reversed separation equality is not silently normalized",
          not normalized_admitted(impl(eq(succ(ZERO), ZERO), BOTTOM)))
    check("different recursor is not silently normalized",
          not normalized_admitted(impl(eq(C, C), eq(rec(ZERO, C, "R_g"), C))))
    check("no successor computation is silently normalized",
          normalize_term(rec(succ(ZERO), C)) == rec(succ(ZERO), C))
    check("bottom-up normalization exposes outer zero seeds",
          normalize_term(rec(rec(ZERO, ZERO), rec(ZERO, C))) == C)
    check("normalizer also sees normalized equality arguments",
          normalize_formula(eq(rec(ZERO, ZERO), succ(rec(ZERO, ZERO)))) == BOTTOM)
    check("literal substitution is simultaneous",
          substitute(eq(Z, C), {"z": rec(ZERO, C), "c": A})
          == eq(rec(ZERO, C), A))
    check("substitution does not mutate the original tree", eq(Z, C).args == (Z, C))
    try:
        substitute(forall("c", eq(X, C)), {"x": C})
    except ValueError:
        binder_rejected = True
    else:
        binder_rejected = False
    check("binder-bearing substitution is explicitly rejected", binder_rejected)

    for index, matrix in enumerate(matrices):
        if not (is_qf_formula(matrix) and free_variables(matrix) <= {"x", "c"}):
            raise AssertionError(f"Invalid generated matrix {index}")
        if not guarded_admitted(guarded_induction_instance(matrix)):
            raise AssertionError(f"Guarded QFI normalization failed at {index}")
        if not normalized_admitted(normalized_induction_instance(matrix)):
            raise AssertionError(f"Rewrite QFI normalization failed at {index}")
    checks.append({"name": "guarded QFI normalization on every sampled matrix",
                   "passed": True, "instances": len(matrices)})
    checks.append({"name": "rewrite QFI normalization on every sampled matrix",
                   "passed": True, "instances": len(matrices)})

    g29, n26 = fused_template(True), fused_template(False)
    fi, ni = baseline_fi_trees(), baseline_ni_trees()
    counts = {
        "guarded_diagonal_single_schema": g29.size,
        "optional_normalized_single_schema": n26.size,
        "one_parameter_FI_basis": sum(t.size for t in fi),
        "one_parameter_NI_basis": sum(t.size for t in ni),
        "implicit_initialization": [
            {"extra_parameters": r,
             "nodes": implicit_initialization_template(r).size,
             "formula": "37 + 5*r"}
            for r in range(4)
        ],
    }
    check("guarded display has 29 nodes", g29.size == 29)
    check("normalized display has 26 nodes", n26.size == 26)
    check("one-parameter FI basis has 42 nodes", counts["one_parameter_FI_basis"] == 42)
    check("one-parameter NI basis has 39 nodes", counts["one_parameter_NI_basis"] == 39)
    check("implicit initialization display is 37 + 5*r for r=0,...,3",
          all(row["nodes"] == 37 + 5 * row["extra_parameters"]
              for row in counts["implicit_initialization"]))
    return {
        "status": "passed",
        "scope": "Finite syntax and partial template-tree diagnostics only; not a formal proof.",
        "sample": {"random_seed": seed, "random_matrices": 512,
                   "hand_selected_matrices": 7, "total_matrices": len(matrices)},
        "checks": checks,
        "counts": counts,
        "metric": {
            "unit": "one node per syntax-tree constructor",
            "binder_names": "labels on quantifier nodes, not extra nodes",
            "formula_placeholders": "application node plus every displayed argument",
            "excluded": ["arbitrary substituted formula bodies", "stored update bodies",
                         "language grammar", "admission algorithm", "axiom enumeration"],
        },
        "basis_components": {
            "FI": [t.size for t in fi],
            "NI": [t.size for t in ni],
        },
        "template_trees": {
            "guarded29": g29.data(), "normalized26": n26.data(),
            "FI42": [t.data() for t in fi], "NI39": [t.data() for t in ni],
            "implicit37": implicit_initialization_template(0).data(),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--outfile", type=Path,
                        help="Also write the JSON result to this path")
    args = parser.parse_args()
    result = run_checks()
    encoded = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.outfile is not None:
        args.outfile.parent.mkdir(parents=True, exist_ok=True)
        args.outfile.write_text(encoded, encoding="utf-8")
        print(json.dumps({"status": result["status"],
                          "checks": len(result["checks"]),
                          "matrices": result["sample"]["total_matrices"],
                          "counts": result["counts"],
                          "full_results": str(args.outfile)}, indent=2))
    else:
        print(encoded, end="")


if __name__ == "__main__":
    main()
