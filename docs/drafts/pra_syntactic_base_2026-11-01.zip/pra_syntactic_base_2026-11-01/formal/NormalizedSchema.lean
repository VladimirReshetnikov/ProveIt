import DiagonalSchema

/-
Optional 26-node display variant.

Unlike DiagonalSchema.lean, this admission test uses two explicit arithmetic
normalizations: R_k(0,t) becomes t, and the literal atom 0=S0 becomes bottom.
The normalizer is bottom-up. Its semantic correctness is proved from the
very Base and Separation principles recovered from the new schema.
No arbitrary rewriting, proof search, or semantic admission test is used.
-/

namespace NormalizedSchema

open DiagonalSchema

def reduceApp {V : Type} (k i : Nat) (s t : Term V) : Term V :=
  if i = k then
    match s with
    | .zero => t
    | _ => .app i s t
  else .app i s t

def normTerm {V : Type} (k : Nat) : Term V → Term V
  | .var v => .var v
  | .zero => .zero
  | .succ t => .succ (normTerm k t)
  | .app i s t => reduceApp k i (normTerm k s) (normTerm k t)

def reduceEq {V : Type} : Term V → Term V → Formula V
  | .zero, .succ .zero => .bot
  | s, t => .eq s t

def normFormula {V : Type} (k : Nat) : Formula V → Formula V
  | .eq s t => reduceEq (normTerm k s) (normTerm k t)
  | .bot => .bot
  | .conj A B => .conj (normFormula k A) (normFormula k B)
  | .disj A B => .disj (normFormula k A) (normFormula k B)
  | .imp A B => .imp (normFormula k A) (normFormula k B)

theorem eval_reduceApp {V D : Type} (M : Model D) (k i : Nat)
    (hb : Base M k) (s t : Term V) (e : V → D) :
    (reduceApp k i s t).eval M e = M.app i (s.eval M e) (t.eval M e) := by
  by_cases hik : i = k
  · subst i
    cases s <;> simp [reduceApp, Term.eval, hb]
    exact (hb (t.eval M e)).symm
  · simp [reduceApp, hik, Term.eval]

theorem eval_normTerm {V D : Type} (M : Model D) (k : Nat)
    (hb : Base M k) (t : Term V) (e : V → D) :
    (normTerm k t).eval M e = t.eval M e := by
  induction t with
  | var v => rfl
  | zero => rfl
  | succ t ih => simp only [normTerm, Term.eval, ih]
  | app i s t ihs iht =>
    simp only [normTerm, eval_reduceApp M k i hb, Term.eval, ihs, iht]

theorem eval_reduceEq {V D : Type} (M : Model D) (he : Separation M)
    (s t : Term V) (e : V → D) :
    (reduceEq s t).eval M e ↔ s.eval M e = t.eval M e := by
  cases s <;> cases t <;> try rfl
  case zero.succ u =>
    cases u <;> try rfl
    exact ⟨False.elim, he⟩

theorem eval_normFormula {V D : Type} (M : Model D) (k : Nat)
    (hb : Base M k) (he : Separation M) (A : Formula V) (e : V → D) :
    (normFormula k A).eval M e ↔ A.eval M e := by
  induction A with
  | eq s t =>
    simp only [normFormula, eval_reduceEq M he, eval_normTerm M k hb, Formula.eval]
  | bot => rfl
  | conj A B ihA ihB => simp only [normFormula, Formula.eval, ihA, ihB]
  | disj A B ihA ihB => simp only [normFormula, Formula.eval, ihA, ihB]
  | imp A B ihA ihB => simp only [normFormula, Formula.eval, ihA, ihB]

def Admitted (k : Nat) (F : Formula Two) : Prop :=
  ∃ B : Formula Unit, normFormula k (F.subst zeroSub) = .imp B B

def admissionCheck (k : Nat) (F : Formula Two) : Bool :=
  match normFormula k (F.subst zeroSub) with
  | .imp B C => decide (B = C)
  | _ => false

theorem admissionCheck_correct (k : Nat) (F : Formula Two) :
    admissionCheck k F = true ↔ Admitted k F := by
  unfold admissionCheck Admitted
  cases e : normFormula k (F.subst zeroSub) with
  | eq s t => simp
  | bot => simp
  | conj A B => simp
  | disj A B => simp
  | imp A B =>
    simp only [decide_eq_true_eq]
    constructor
    · intro h
      subst B
      exact ⟨A, rfl⟩
    · rintro ⟨C, h⟩
      have hh := Formula.imp.inj h
      exact hh.1.trans hh.2.symm

def Schema {D : Type} (M : Model D) (k : Nat) (h : Term Two) : Prop :=
  ∀ F : Formula Two, Admitted k F → ∀ a : D,
    (∀ n, F.eval M (envTwo n a) → F.eval M (envTwo (M.succ n) a)) →
    ∀ n, F.eval M (envTwo n a) ∧
      M.app k (M.succ n) a = h.eval M (envTwo n (M.app k n a))

def separationProbe : Formula Two := .imp guard .bot

theorem separationProbe_admitted (k : Nat) : Admitted k separationProbe :=
  ⟨.bot, rfl⟩

theorem schema_separation {D : Type} (M : Model D) (k : Nat) (h : Term Two)
    (H : Schema M k h) : Separation M := by
  exact (H separationProbe (separationProbe_admitted k) M.zero
    (by intro n hn; exact hn) M.zero).1

def truthProbe : Formula Two := .imp .bot .bot

theorem truthProbe_admitted (k : Nat) : Admitted k truthProbe :=
  ⟨.bot, rfl⟩

theorem schema_step {D : Type} (M : Model D) (k : Nat) (h : Term Two)
    (H : Schema M k h) : Step M k h := by
  intro n a
  exact (H truthProbe (truthProbe_admitted k) a
    (by intro n hn; exact hn) n).2

def initProbe (k : Nat) : Formula Two :=
  .imp (.eq (.var .seed) (.var .seed))
    (.eq (.app k .zero (.var .seed)) (.var .seed))

theorem initProbe_admitted (k : Nat) : Admitted k (initProbe k) := by
  refine ⟨.eq (.var ()) (.var ()), ?_⟩
  simp [initProbe, Formula.subst, Term.subst, zeroSub, normFormula,
    normTerm, reduceApp, reduceEq]

theorem schema_base {D : Type} (M : Model D) (k : Nat) (h : Term Two)
    (H : Schema M k h) : Base M k := by
  intro a
  have p := (H (initProbe k) (initProbe_admitted k) a
    (by intro n hn; exact hn) M.zero).1
  exact p rfl

def freezeCounter : Two → Term Two
  | .counter => .zero
  | .seed => .var .seed

def inductionProbe (F : Formula Two) : Formula Two :=
  .imp (F.subst freezeCounter) F

theorem inductionProbe_admitted (k : Nat) (F : Formula Two) :
    Admitted k (inductionProbe F) := by
  refine ⟨normFormula k (F.subst zeroSub), ?_⟩
  have hcomp : (fun v => (freezeCounter v).subst zeroSub) = zeroSub := by
    funext v
    cases v <;> rfl
  simp only [inductionProbe, Formula.subst, Formula.subst_subst, hcomp, normFormula]

theorem eval_inductionProbe {D : Type} (M : Model D) (F : Formula Two)
    (n a : D) :
    (inductionProbe F).eval M (envTwo n a) ↔
      (F.eval M (envTwo M.zero a) → F.eval M (envTwo n a)) := by
  have he : (fun v => (freezeCounter v).eval M (envTwo n a)) =
      envTwo M.zero a := by
    funext v
    cases v <;> rfl
  simp only [inductionProbe, Formula.eval, Formula.eval_subst, he]

theorem schema_induction {D : Type} (M : Model D) (k : Nat) (h : Term Two)
    (H : Schema M k h) : QFInduction M := by
  intro F a hz hs n
  have prog : ∀ m, (inductionProbe F).eval M (envTwo m a) →
      (inductionProbe F).eval M (envTwo (M.succ m) a) := by
    intro m hm
    apply (eval_inductionProbe M F (M.succ m) a).2
    intro hb
    exact hs m ((eval_inductionProbe M F m a).1 hm hb)
  have p := (H (inductionProbe F) (inductionProbe_admitted k F) a prog n).1
  exact (eval_inductionProbe M F n a).1 p hz

theorem eval_atZero {D : Type} (M : Model D) (F : Formula Two) (a : D) :
    (F.subst zeroSub).eval M (fun _ => a) ↔
      F.eval M (envTwo M.zero a) := by
  have he : (fun v => (zeroSub v).eval M (fun _ => a)) = envTwo M.zero a := by
    funext v
    cases v <;> rfl
  rw [Formula.eval_subst, he]

theorem base_induction_schema {D : Type} (M : Model D) (k : Nat) (h : Term Two)
    (hb : Base M k) (hs : Step M k h) (he : Separation M)
    (hi : QFInduction M) : Schema M k h := by
  intro F had a hp n
  obtain ⟨B, hsyntax⟩ := had
  have normBase : (normFormula k (F.subst zeroSub)).eval M (fun _ => a) := by
    rw [hsyntax]
    intro hB
    exact hB
  have rawBase := (eval_normFormula M k hb he (F.subst zeroSub) (fun _ => a)).1 normBase
  exact ⟨hi F a ((eval_atZero M F a).1 rawBase) hp n, hs n a⟩

theorem schema_iff {D : Type} (M : Model D) (k : Nat) (h : Term Two) :
    Schema M k h ↔ Base M k ∧ Step M k h ∧ Separation M ∧ QFInduction M := by
  constructor
  · intro H
    exact ⟨schema_base M k h H, schema_step M k h H,
      schema_separation M k h H, schema_induction M k h H⟩
  · rintro ⟨hb, hs, he, hi⟩
    exact base_induction_schema M k h hb hs he hi

#print axioms schema_iff
#print axioms admissionCheck_correct
#print axioms eval_normFormula

end NormalizedSchema
