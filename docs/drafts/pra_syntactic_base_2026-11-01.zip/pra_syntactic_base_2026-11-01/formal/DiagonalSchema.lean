/-
Core-only logical verification of guarded diagonal PRA schema.

This verifies finite quantifier-free syntax, simultaneous substitution,
the literal guarded-base admission condition, and equivalence to initialized
binary recursion, separation, and quantifier-free induction with one parameter.
The arithmetic compilation from this binary base to PRA is a separate theorem
proved in the accompanying mathematical report, not claimed by this kernel.
-/

namespace DiagonalSchema

inductive Two where
  | counter | seed
  deriving DecidableEq

inductive Three where
  | counter | moved | seed
  deriving DecidableEq

inductive Term (V : Type) where
  | var : V → Term V
  | zero : Term V
  | succ : Term V → Term V
  | app : Nat → Term V → Term V → Term V
  deriving DecidableEq

inductive Formula (V : Type) where
  | eq : Term V → Term V → Formula V
  | bot : Formula V
  | conj : Formula V → Formula V → Formula V
  | disj : Formula V → Formula V → Formula V
  | imp : Formula V → Formula V → Formula V
  deriving DecidableEq

structure Model (D : Type) where
  zero : D
  succ : D → D
  app : Nat → D → D → D

def Term.subst {V W : Type} (s : V → Term W) : Term V → Term W
  | .var v => s v
  | .zero => .zero
  | .succ t => .succ (t.subst s)
  | .app i t u => .app i (t.subst s) (u.subst s)

def Formula.subst {V W : Type} (s : V → Term W) : Formula V → Formula W
  | .eq t u => .eq (t.subst s) (u.subst s)
  | .bot => .bot
  | .conj A B => .conj (A.subst s) (B.subst s)
  | .disj A B => .disj (A.subst s) (B.subst s)
  | .imp A B => .imp (A.subst s) (B.subst s)

def Term.eval {V D : Type} (M : Model D) (e : V → D) : Term V → D
  | .var v => e v
  | .zero => M.zero
  | .succ t => M.succ (t.eval M e)
  | .app i t u => M.app i (t.eval M e) (u.eval M e)

def Formula.eval {V D : Type} (M : Model D) (e : V → D) : Formula V → Prop
  | .eq t u => t.eval M e = u.eval M e
  | .bot => False
  | .conj A B => A.eval M e ∧ B.eval M e
  | .disj A B => A.eval M e ∨ B.eval M e
  | .imp A B => A.eval M e → B.eval M e

theorem Term.subst_subst {U V W : Type} (t : Term U)
    (s : U → Term V) (r : V → Term W) :
    (t.subst s).subst r = t.subst (fun v => (s v).subst r) := by
  induction t with
  | var v => rfl
  | zero => rfl
  | succ t ih => simp only [Term.subst, ih]
  | app i t u iht ihu => simp only [Term.subst, iht, ihu]

theorem Formula.subst_subst {U V W : Type} (A : Formula U)
    (s : U → Term V) (r : V → Term W) :
    (A.subst s).subst r = A.subst (fun v => (s v).subst r) := by
  induction A with
  | eq t u => simp only [Formula.subst, Term.subst_subst]
  | bot => rfl
  | conj A B ihA ihB => simp only [Formula.subst, ihA, ihB]
  | disj A B ihA ihB => simp only [Formula.subst, ihA, ihB]
  | imp A B ihA ihB => simp only [Formula.subst, ihA, ihB]

theorem Term.eval_subst {V W D : Type} (M : Model D)
    (t : Term V) (s : V → Term W) (e : W → D) :
    (t.subst s).eval M e = t.eval M (fun v => (s v).eval M e) := by
  induction t with
  | var v => rfl
  | zero => rfl
  | succ t ih => simp only [Term.subst, Term.eval, ih]
  | app i t u iht ihu => simp only [Term.subst, Term.eval, iht, ihu]

theorem Formula.eval_subst {V W D : Type} (M : Model D)
    (A : Formula V) (s : V → Term W) (e : W → D) :
    (A.subst s).eval M e ↔ A.eval M (fun v => (s v).eval M e) := by
  induction A with
  | eq t u => simp only [Formula.subst, Formula.eval, Term.eval_subst]
  | bot => rfl
  | conj A B ihA ihB => simp only [Formula.subst, Formula.eval, ihA, ihB]
  | disj A B ihA ihB => simp only [Formula.subst, Formula.eval, ihA, ihB]
  | imp A B ihA ihB => simp only [Formula.subst, Formula.eval, ihA, ihB]

def envTwo {D : Type} (n a : D) : Two → D
  | .counter => n
  | .seed => a

def envThree {D : Type} (n z a : D) : Three → D
  | .counter => n
  | .moved => z
  | .seed => a

def guard {V : Type} : Formula V := .eq .zero (.succ .zero)

def baseSub (k : Nat) : Three → Term Unit
  | .counter => .zero
  | .moved => .app k .zero (.var ())
  | .seed => .var ()

def guarded {V : Type} (B : Formula V) : Formula V :=
  .imp (.disj B guard) B

def Admitted (k : Nat) (A : Formula Three) : Prop :=
  ∃ B : Formula Unit, A.subst (baseSub k) = guarded B

/- An executable, purely syntactic admission test. -/
def admissionCheck (k : Nat) (A : Formula Three) : Bool :=
  match A.subst (baseSub k) with
  | .imp (.disj B E) C => decide (E = guard ∧ B = C)
  | _ => false

theorem admissionCheck_correct (k : Nat) (A : Formula Three) :
    admissionCheck k A = true ↔ Admitted k A := by
  unfold admissionCheck Admitted
  cases e : A.subst (baseSub k) with
  | eq t u => simp [guarded]
  | bot => simp [guarded]
  | conj B C => simp [guarded]
  | disj B C => simp [guarded]
  | imp P Q =>
    cases P with
    | eq t u => simp [guarded]
    | bot => simp [guarded]
    | conj B C => simp [guarded]
    | imp B C => simp [guarded]
    | disj B E =>
      simp only [decide_eq_true_eq]
      constructor
      · rintro ⟨hE, hQ⟩
        subst E
        subst Q
        exact ⟨B, rfl⟩
      · rintro ⟨C, heq⟩
        have hh := Formula.imp.inj heq
        have hd := Formula.disj.inj hh.1
        exact ⟨hd.2, hd.1.trans hh.2.symm⟩

def diagonalSub : Three → Term Two
  | .counter => .var .counter
  | .moved => .var .seed
  | .seed => .var .seed

def zeroSub : Two → Term Unit
  | .counter => .zero
  | .seed => .var ()

def liftSub : Two → Term Three
  | .counter => .var .counter
  | .seed => .var .seed

def fixedZeroSub : Two → Term Three
  | .counter => .zero
  | .seed => .var .seed

def normalize (F : Formula Two) : Formula Three :=
  .imp (.disj (F.subst fixedZeroSub) guard) (F.subst liftSub)

theorem normalize_admitted (k : Nat) (F : Formula Two) :
    Admitted k (normalize F) := by
  refine ⟨F.subst zeroSub, ?_⟩
  have h₁ : (fun v => (fixedZeroSub v).subst (baseSub k)) = zeroSub := by
    funext v
    cases v <;> rfl
  have h₂ : (fun v => (liftSub v).subst (baseSub k)) = zeroSub := by
    funext v
    cases v <;> rfl
  simp only [normalize, Formula.subst, Formula.subst_subst, h₁, h₂]
  rfl

def QFInduction {D : Type} (M : Model D) : Prop :=
  ∀ F : Formula Two, ∀ a : D,
    F.eval M (envTwo M.zero a) →
    (∀ n, F.eval M (envTwo n a) → F.eval M (envTwo (M.succ n) a)) →
    ∀ n, F.eval M (envTwo n a)

def Base {D : Type} (M : Model D) (k : Nat) : Prop :=
  ∀ a, M.app k M.zero a = a

def Step {D : Type} (M : Model D) (k : Nat) (h : Term Two) : Prop :=
  ∀ n a, M.app k (M.succ n) a =
    h.eval M (envTwo n (M.app k n a))

def Separation {D : Type} (M : Model D) : Prop :=
  M.zero = M.succ M.zero → False

def Schema {D : Type} (M : Model D) (k : Nat) (h : Term Two) : Prop :=
  ∀ A : Formula Three, Admitted k A → ∀ a : D,
    (∀ n, A.eval M (envThree n a a) →
      A.eval M (envThree (M.succ n) a a)) →
    ∀ n, A.eval M (envThree n a a) ∧
      M.app k (M.succ n) a = h.eval M (envTwo n (M.app k n a))

def falseProbe : Formula Three := guarded .bot

theorem falseProbe_admitted (k : Nat) : Admitted k falseProbe :=
  ⟨.bot, rfl⟩

theorem schema_separation {D : Type} (M : Model D) (k : Nat) (h : Term Two)
    (H : Schema M k h) : Separation M := by
  have p := (H falseProbe (falseProbe_admitted k) M.zero
    (by intro n hn; exact hn) M.zero).1
  intro e
  exact p (Or.inr e)

theorem schema_step {D : Type} (M : Model D) (k : Nat) (h : Term Two)
    (H : Schema M k h) : Step M k h := by
  intro n a
  exact (H falseProbe (falseProbe_admitted k) a
    (by intro n hn; exact hn) n).2

def seedAtZero (k : Nat) : Term Three := .app k .zero (.var .seed)

def initProbe (k : Nat) : Formula Three :=
  .imp (.disj (.eq (seedAtZero k) (seedAtZero k)) guard)
    (.eq (.var .moved) (seedAtZero k))

theorem initProbe_admitted (k : Nat) : Admitted k (initProbe k) :=
  ⟨.eq (.app k .zero (.var ())) (.app k .zero (.var ())), rfl⟩

theorem schema_base {D : Type} (M : Model D) (k : Nat) (h : Term Two)
    (H : Schema M k h) : Base M k := by
  intro a
  have p := (H (initProbe k) (initProbe_admitted k) a
    (by intro n hn; exact hn) M.zero).1
  exact (p (Or.inl rfl)).symm

theorem eval_normalize {D : Type} (M : Model D) (F : Formula Two)
    (n a : D) :
    (normalize F).eval M (envThree n a a) ↔
      ((F.eval M (envTwo M.zero a) ∨ M.zero = M.succ M.zero) →
        F.eval M (envTwo n a)) := by
  have h₁ : (fun v => (fixedZeroSub v).eval M (envThree n a a)) =
      envTwo M.zero a := by
    funext v
    cases v <;> rfl
  have h₂ : (fun v => (liftSub v).eval M (envThree n a a)) =
      envTwo n a := by
    funext v
    cases v <;> rfl
  simp only [normalize, Formula.eval, Formula.eval_subst, h₁, h₂,
    guard, Term.eval]

theorem schema_induction {D : Type} (M : Model D) (k : Nat) (h : Term Two)
    (H : Schema M k h) : QFInduction M := by
  intro F a hz hs n
  have prog : ∀ m, (normalize F).eval M (envThree m a a) →
      (normalize F).eval M (envThree (M.succ m) a a) := by
    intro m hm
    apply (eval_normalize M F (M.succ m) a).2
    intro b
    exact hs m ((eval_normalize M F m a).1 hm b)
  have p := (H (normalize F) (normalize_admitted k F) a prog n).1
  exact (eval_normalize M F n a).1 p (Or.inl hz)

theorem eval_diagonal {D : Type} (M : Model D) (A : Formula Three)
    (n a : D) :
    (A.subst diagonalSub).eval M (envTwo n a) ↔
      A.eval M (envThree n a a) := by
  have he : (fun v => (diagonalSub v).eval M (envTwo n a)) =
      envThree n a a := by
    funext v
    cases v <;> rfl
  rw [Formula.eval_subst, he]

theorem eval_base {D : Type} (M : Model D) (k : Nat) (A : Formula Three)
    (a : D) :
    (A.subst (baseSub k)).eval M (fun _ => a) ↔
      A.eval M (envThree M.zero (M.app k M.zero a) a) := by
  have he : (fun v => (baseSub k v).eval M (fun _ => a)) =
      envThree M.zero (M.app k M.zero a) a := by
    funext v
    cases v <;> rfl
  rw [Formula.eval_subst, he]

theorem base_induction_schema {D : Type} (M : Model D) (k : Nat) (h : Term Two)
    (hb : Base M k) (hs : Step M k h) (he : Separation M)
    (hi : QFInduction M) : Schema M k h := by
  intro A had a hp n
  obtain ⟨B, hsyntax⟩ := had
  have rawBase : (A.subst (baseSub k)).eval M (fun _ => a) := by
    rw [hsyntax]
    intro hguard
    exact hguard.elim (fun hB => hB) (fun e => False.elim (he e))
  have atBase : A.eval M (envThree M.zero a a) := by
    have e := (eval_base M k A a).1 rawBase
    rw [hb a] at e
    exact e
  have diagBase := (eval_diagonal M A M.zero a).2 atBase
  have diagStep : ∀ m, (A.subst diagonalSub).eval M (envTwo m a) →
      (A.subst diagonalSub).eval M (envTwo (M.succ m) a) := by
    intro m hm
    exact (eval_diagonal M A (M.succ m) a).2
      (hp m ((eval_diagonal M A m a).1 hm))
  exact ⟨(eval_diagonal M A n a).1
    (hi (A.subst diagonalSub) a diagBase diagStep n), hs n a⟩

theorem schema_iff {D : Type} (M : Model D) (k : Nat) (h : Term Two) :
    Schema M k h ↔ Base M k ∧ Step M k h ∧ Separation M ∧ QFInduction M := by
  constructor
  · intro H
    exact ⟨schema_base M k h H, schema_step M k h H,
      schema_separation M k h H, schema_induction M k h H⟩
  · rintro ⟨hb, hs, he, hi⟩
    exact base_induction_schema M k h hb hs he hi

#print axioms schema_iff
#print axioms admissionCheck_correct

end DiagonalSchema
