CONSTRUCTIVE LEAN KERNEL: INITIALIZED SWAP AND RELATIVE POINTED CONSTANCY

File: SwapPointed.lean
Checked with Lean 4.19.0, commit 6caaee842e94.
Reproduce from the package directory: lean formal/SwapPointed.lean
The exact successful version, command, exit status, and output are in lean-check.log.
No external libraries are required. All source lines are at most 100 characters.

BASIS AND TERM SCOPE

The carrier alpha is arbitrary. Basis contains the computation equations for the
three designated programs C, D, T, the ground inequality 0 != S0, and relative
pointed constancy. It does not assume the old off-diagonal law or stationary
separation; the off-diagonal law is derived from constant instances.

The predicate Basis.term marks denotations of finite terms with fixed parameters.
Its closure fields cover variables, constants (fixed numerical parameters),
composition, successor, and the three designated operations. Relative pointed
constancy requires a proof of term membership. Every use of that schema in this
file supplies such a proof; it is not assumed for all functions alpha -> alpha.

This is an abstract semantic interface to finite terms, rather than a formalized
enumeration of the entire program-description language. The intended instance is
the class of term denotations in that language. Formula.WellFormed records term
membership of atomic expressions, and formula_error_term proves closure of the
formula compiler. Quantifier-free induction requires a well-formed formula.

WHAT THE THEOREMS CHECK

The following 19 endpoints were audited with #print axioms. Each reports that it
does not depend on any axioms. All names have prefix PRASwapPointed.Basis.

  off
  succ_injective
  succ_ne_zero
  succ_ne_self
  stationary_one
  stationary_zero
  near_diagonal_zero
  near_next_one
  trans_successor_diagonal
  zero_classification
  error_zero_iff
  equality_decision
  constancy
  ordinary_recursion_from_swap
  shifted_latch_induction
  formula_error_term
  formula_compiler
  zero_latch_induction
  quantifier_free_induction

The ordinary_recursion_from_swap theorem takes one selected swap-recursion
function R satisfying the displayed equations. It proves that its delayed
diagonal F(n) = R(Sn,Sn) has the required base value and ordinary recursion
equation. The theorem does not assert that arbitrary set-theoretic update
functions have recursors. The paper's finite description grammar supplies the
specific legal R used for each ordinary primitive-recursive description.

The latch theorems assume a term-denoting latch r and its base and step equations.
They prove the induction conclusion constructively, under the fixed base and
step hypotheses. They do not assume induction on the carrier. Existence and term
formation of the needed latch follow from the ordinary-recursion construction in
the paper; the complete grammar-level existence theorem is not formalized here.

WHAT IS NOT FORMALIZED

This is a verification of the constructive forward proof kernel. It does not
formalize full first-order syntax or derivations, the effective schema enumerator,
the reverse diagonal-fold compiler, internal uniqueness of every description, or
either interpretation round trip. The written paper proves those additional
claims. Accordingly, this artifact is not a complete Lean formalization of
bi-interpretability or equiconsistency.

"No axioms" in the Lean output means the theorems follow constructively from the
explicit Basis hypotheses without global axioms such as Classical.choice or
propext. It does not mean the arithmetic hypotheses themselves were proved by
pure logic. There are no sorry/admit placeholders, no classical-equality
instance, and no induction principle for the arbitrary carrier.

PROVENANCE

The proof is adapted from InitializedSwap.lean in the inspected archive
VladimirReshetnikov/ProveIt, docs/drafts/pra_initialized_swap_2026-10-31.zip,
Git blob 3b83cef6a485d249d9f3f581046205577f330289. The new basis, pointed-schema
bootstrap, term restrictions, closure proofs, and contextual constancy argument
were added for this report. Existing constructive selector, ordinary-recursion,
and latch arguments were adapted to the new assumptions.
