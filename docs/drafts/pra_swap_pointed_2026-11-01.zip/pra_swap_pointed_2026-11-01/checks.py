#!/usr/bin/env python3
"""Reproduce syntax counts and finite diagnostics for the pointed swap basis.

Usage: python3 checks.py [--verify-sources /path/to/downloaded/sources]

Only the Python standard library is required.  No network calls are made.
No code from the comparison archives is imported or executed.  The optional
source check reads the seven ZIP archives as data and verifies their hashes,
their cited JSON artifacts, and the extracted comparison counts.

The formula-tree counts are exact for the displayed syntax.  Numerical tests
are finite diagnostics, not proofs of universal axioms, intuitionistic logical
validity, internal uniqueness in nonstandard models, or bi-interpretability.
The mathematical arguments belong to the accompanying paper.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from functools import lru_cache
import hashlib
import itertools
import json
from pathlib import Path
from typing import Callable
import zipfile


SOURCE_COMMIT = "e6474c41337c6495c4589970d8d1bfdcfce65b66"
# Embedded provenance is inserted from the inspected local source bytes.
SOURCE_RECORDS = [{'id': 'initialized_biinterpretation',
  'archive': 'pra_initialized_biinterpretation_2026-11-01.zip',
  'local_archive': 'pra_initialized_biinterpretation_2026-11-01.zip',
  'url': 'https://github.com/VladimirReshetnikov/ProveIt/blob/e6474c41337c6495c4589970d8d1bfdcfce65b66/docs/drafts/pra_initialized_biinterpretation_2026-11-01.zip',
  'git_blob_sha1': 'add51d733a235a2e55ef591ce6d2a0a462f39a47',
  'archive_sha256': 'c51beb22fc947c153be0a27d225a121d9d2563238070a1540ac3766aefdf627e',
  'size_bytes': 2653152,
  'metric_artifact': 'pra_initialized_biinterpretation_2026-11-01/artifacts/check-results.json',
  'metric_sha256': '9c43be969f7ed4a6b93b6546d56ed20ffdf71f42e1fc9c6d2356479af8383b8a',
  'observed_counts': {'computation': 20,
                      'fixed_arithmetic': 11,
                      'arithmetic_schema': 22,
                      'total': 53,
                      'selected_body_nodes': 28},
  'grammar_key': 'initialized_substitution',
  'schema_key': 'SS',
  'fixed_key': 'O',
  'relative_bridge': True,
  'stored_descriptor_inputs': 2,
  'body_count_scope': 'all stored h,k bodies; initialized base in grammar'},
 {'id': 'initialized_swap',
  'archive': 'pra_initialized_swap_2026-10-31.zip',
  'local_archive': 'pra_initialized_swap_2026-10-31.zip',
  'url': 'https://github.com/VladimirReshetnikov/ProveIt/blob/e6474c41337c6495c4589970d8d1bfdcfce65b66/docs/drafts/pra_initialized_swap_2026-10-31.zip',
  'git_blob_sha1': '3b83cef6a485d249d9f3f581046205577f330289',
  'archive_sha256': '6663391ab4c11b687aa6d00f0c893b1d86febde1b2f7a8803ff1cb6d588a47ee',
  'size_bytes': 403646,
  'metric_artifact': 'pra_initialized_swap_2026-10-31/artifacts/schema_metrics.json',
  'metric_sha256': '4c058f846af649e845d19f479094d60542551567677d0abd9794d09a27b14366',
  'observed_counts': {'computation': 19,
                      'fixed_arithmetic': 11,
                      'arithmetic_schema': 22,
                      'total': 52,
                      'selected_body_nodes': 13},
  'grammar_key': 'swap',
  'schema_key': 'SS',
  'fixed_key': 'O',
  'relative_bridge': True,
  'stored_descriptor_inputs': 1,
  'body_count_scope': 'update bodies only; initialized base in grammar'},
 {'id': 'pointed_constancy',
  'archive': 'pra_pointed_constancy_2026-10-31.zip',
  'local_archive': 'pra_pointed_constancy_2026-10-31.zip',
  'url': 'https://github.com/VladimirReshetnikov/ProveIt/blob/e6474c41337c6495c4589970d8d1bfdcfce65b66/docs/drafts/pra_pointed_constancy_2026-10-31.zip',
  'git_blob_sha1': '08ef8d55d33ae503716715ec185dbc796d496cbd',
  'archive_sha256': '98375e0be550f384d69ca42c11310b2d064f368dffd815f21012fe1f79c779e9',
  'size_bytes': 390707,
  'metric_artifact': 'pra_pointed_constancy_2026-10-31/artifacts/schema_metrics.json',
  'metric_sha256': 'e70d147fca347382db531dbee16bb064a177b0c63deb4d2a715373417c33599f',
  'observed_counts': {'computation': 21,
                      'fixed_arithmetic': 6,
                      'arithmetic_schema': 25,
                      'total': 52,
                      'selected_body_nodes': 19},
  'grammar_key': 'substitution',
  'schema_key': 'pointed',
  'fixed_key': 'Sep',
  'relative_bridge': False,
  'stored_descriptor_inputs': 3,
  'body_count_scope': 'all stored g,h,k bodies'},
 {'id': 'probe_constancy',
  'archive': 'pra_probe_constancy_2026-10-31.zip',
  'local_archive': 'pra_probe_constancy_2026-10-31.zip',
  'url': 'https://github.com/VladimirReshetnikov/ProveIt/blob/e6474c41337c6495c4589970d8d1bfdcfce65b66/docs/drafts/pra_probe_constancy_2026-10-31.zip',
  'git_blob_sha1': 'dcda5527699b37abc589e6be40d93a194585a2f3',
  'archive_sha256': '0fbdd7d7aca5a1f62869be1190bc51fbe893b228f89aef3bbe528291a7a1d8a5',
  'size_bytes': 371617,
  'metric_artifact': 'pra_probe_constancy_2026-10-31/artifacts/schema_metrics.json',
  'metric_sha256': 'dccc497a849fbdae280a917b1ee8ca91249747d7df20058730d95b1f33b28abc',
  'observed_counts': {'computation': 21,
                      'fixed_arithmetic': 6,
                      'arithmetic_schema': 25,
                      'total': 52,
                      'selected_body_nodes': 18},
  'grammar_key': 'substitution',
  'schema_key': 'probe',
  'fixed_key': 'Sep',
  'relative_bridge': False,
  'stored_descriptor_inputs': 3,
  'body_count_scope': 'all stored g,h,k bodies'},
 {'id': 'stationary_agreement',
  'archive': 'pra_stationary_agreement_2026-10-31.zip',
  'local_archive': 'pra_stationary_agreement_2026-10-31.zip',
  'url': 'https://github.com/VladimirReshetnikov/ProveIt/blob/e6474c41337c6495c4589970d8d1bfdcfce65b66/docs/drafts/pra_stationary_agreement_2026-10-31.zip',
  'git_blob_sha1': '807ea21e181b6f5ad8bba017808760015b1def6a',
  'archive_sha256': 'f9050708060c0e4def471242242912c67fcaead1a50927662b0e969ea81fab83',
  'size_bytes': 368372,
  'metric_artifact': 'pra_stationary_agreement_2026-10-31/artifacts/check_results.json',
  'metric_sha256': 'eeb9697010f16cd8f01e163ab37131842cd59339b09b8dbf3050ecdf5069d117',
  'observed_counts': {'computation': 20,
                      'fixed_arithmetic': 11,
                      'arithmetic_schema': 23,
                      'total': 54,
                      'selected_body_nodes': 17},
  'grammar_key': 'ordinary',
  'schema_key': 'SA',
  'fixed_key': 'O',
  'relative_bridge': False,
  'stored_descriptor_inputs': 2,
  'body_count_scope': 'all stored g,h bodies'},
 {'id': 'stationary_comparison_fixed_predecessor',
  'archive': 'pra_stationary_comparison_2026-10-31 (1).zip',
  'local_archive': 'pra_stationary_comparison_2026-10-31_variant.zip',
  'url': 'https://github.com/VladimirReshetnikov/ProveIt/blob/e6474c41337c6495c4589970d8d1bfdcfce65b66/docs/drafts/pra_stationary_comparison_2026-10-31%20(1).zip',
  'git_blob_sha1': '010874fa09bfec035b60e72a8918904b1f3af641',
  'archive_sha256': 'f73ccc9752a4c98cccacc3dff8db06031144e83a1e74864edd1ff791ab69a5e0',
  'size_bytes': 402749,
  'metric_artifact': 'pra_stationary_comparison_2026-10-31/artifacts/schema_metrics.json',
  'metric_sha256': '809691c5cdf8039ce0c4fb6a13c4eab507b1ec6a87b533e6c183fd5cdcbd2502',
  'observed_counts': {'computation': 21,
                      'fixed_arithmetic': 6,
                      'arithmetic_schema': 25,
                      'total': 52,
                      'selected_body_nodes': 13},
  'grammar_key': 'fixed_predecessor',
  'schema_key': 'probe',
  'fixed_key': 'Sep',
  'relative_bridge': False,
  'stored_descriptor_inputs': 2,
  'body_count_scope': 'all stored g,h bodies; fixed predecessor transformer in grammar'},
 {'id': 'stationary_comparison',
  'archive': 'pra_stationary_comparison_2026-10-31.zip',
  'local_archive': 'pra_stationary_comparison_2026-10-31.zip',
  'url': 'https://github.com/VladimirReshetnikov/ProveIt/blob/e6474c41337c6495c4589970d8d1bfdcfce65b66/docs/drafts/pra_stationary_comparison_2026-10-31.zip',
  'git_blob_sha1': '95c55aca753eb8dec6320b67c00f9e088f5b08cc',
  'archive_sha256': 'd53501922b54d7f571145f8695e202653a83593ecc40e9dadda2a8304fe20f6f',
  'size_bytes': 381426,
  'metric_artifact': 'pra_stationary_comparison_2026-10-31/artifacts/schema_metrics.json',
  'metric_sha256': '094f136c57c805204d3c8ad4cc11bed65c0f5f45bcf571e6c28bcf2455843e45',
  'observed_counts': {'computation': 21,
                      'fixed_arithmetic': 6,
                      'arithmetic_schema': 25,
                      'total': 52,
                      'selected_body_nodes': 19},
  'grammar_key': 'substitution',
  'schema_key': 'uniform_comparison',
  'fixed_key': 'Sep',
  'relative_bridge': False,
  'stored_descriptor_inputs': 3,
  'body_count_scope': 'all stored g,h,k bodies'}]


@dataclass(frozen=True)
class Expr:
    label: str
    children: tuple["Expr", ...] = ()
    binder: str | None = None

    def nodes(self) -> int:
        return 1 + sum(child.nodes() for child in self.children)

    def tree(self) -> str:
        if self.binder is not None:
            return f"({self.label} {self.binder} {self.children[0].tree()})"
        if not self.children:
            return self.label
        return "(" + self.label + " " + " ".join(
            child.tree() for child in self.children
        ) + ")"


def node(label: str, *children: Expr) -> Expr:
    return Expr(label, children)


def all_of(names: list[str], body: Expr) -> Expr:
    for name in reversed(names):
        body = Expr("forall", (body,), name)
    return body


ZERO = node("0")
BOTTOM = node("bottom")


def succ(term: Expr) -> Expr:
    return node("S", term)


def eq(left: Expr, right: Expr) -> Expr:
    return node("=", left, right)


def ne(left: Expr, right: Expr) -> Expr:
    return node("implies", eq(left, right), BOTTOM)


def computation(m: int, kind: str) -> tuple[Expr, Expr]:
    """Universally closed templates; m includes the active seed a."""
    if m < 1:
        raise ValueError("The measured swap template has m >= 1.")
    names = ["a"] + [f"b{i}" for i in range(1, m)]
    params = [node(name) for name in names]
    a, frozen = params[0], params[1:]
    n = node("n")
    if kind in {"swap", "initialized_substitution"}:
        initial = a
    else:
        initial = node("g", *params)
    base = all_of(names, eq(node("R", ZERO, *params), initial))
    if kind == "swap":
        recurse = node("R", a, n, *frozen)
    elif kind in {"substitution", "initialized_substitution"}:
        recurse = node("R", n, node("k", a), *frozen)
    elif kind == "fixed_predecessor":
        recurse = node("R", n, node("p", a), *frozen)
    elif kind == "ordinary":
        recurse = node("R", n, *params)
    else:
        raise ValueError(kind)
    update = node("h", n, *params, recurse)
    step = all_of(["n"] + names, eq(node("R", succ(n), *params), update))
    return base, step


def arithmetic(m: int, kind: str) -> Expr:
    names = ["a"] + [f"b{i}" for i in range(1, m)]
    params = [node(name) for name in names]
    a, n = params[0], node("n")
    f0 = node("f", ZERO, *params)
    fn = node("f", n, *params)
    fs = node("f", succ(n), *params)
    stationary = all_of(["n"], eq(fs, fn))
    if kind == "PC":
        conclusion = all_of(["n"], node(
            "or", eq(node("T", f0, a), a), eq(fn, a)
        ))
    elif kind == "SS":
        conclusion = all_of(["n"], ne(succ(fn), f0))
    elif kind == "pointed":
        conclusion = all_of(["n"], node(
            "or", eq(node("e", f0, a), ZERO), eq(fn, a)
        ))
    elif kind == "probe":
        conclusion = all_of(["n"], node(
            "or", eq(fn, a), eq(node("e", f0, a), ZERO)
        ))
    elif kind == "uniform_comparison":
        conclusion = node(
            "or", all_of(["n"], eq(fn, a)), eq(node("e", f0, a), ZERO)
        )
    elif kind == "SA":
        conclusion = all_of(["n"], ne(node("e", fn, f0), ZERO))
    else:
        raise ValueError(kind)
    return all_of(names, node("implies", stationary, conclusion))


def bridge(relative: bool) -> Expr:
    x, y = node("x"), node("y")
    first = eq(node("T" if relative else "e", x, y), y if relative else ZERO)
    return all_of(["x", "y"], node("or", first, eq(x, y)))


def source_counts(source_id: str, data: dict) -> dict:
    """Read only documented metrics from the cited JSON artifact."""
    if source_id == "initialized_biinterpretation":
        f = data["formula_nodes"]
        computation_nodes = f["D0_new"] + f["DS"]
        fixed, schema = f["O_star"], f["SS"]
        stored = sum(data["descriptor_nodes"].values())
    elif source_id == "initialized_swap":
        row = data["rows"][0]
        computation_nodes = row["new_computation"]
        fixed, schema = row["new_bridge"], row["stationary_separation"]
        stored = data["selected_update_total"]
    elif source_id == "pointed_constancy":
        f = data["one_parameter_counts"]
        computation_nodes = f["D_base"] + f["D_substitution_step"]
        fixed, schema = f["Sep"], f["Pointed"]
        # P and B each have the three one-node g,h,k bodies; e is in this JSON.
        stored = 6 + sum(data["unchanged_e_descriptor_body_nodes"].values())
    elif source_id == "probe_constancy":
        f = data["one_parameter_new"]
        computation_nodes = f["D_base"]["nodes"] + f["D_step"]["nodes"]
        fixed, schema = f["Sep"]["nodes"], f["Probe"]["nodes"]
        stored = data["all_designated_descriptor_body_nodes"]
    elif source_id == "stationary_agreement":
        row = data["metrics"]["current_drafts_and_new_basis"][-1]
        computation_nodes = row["computation"]
        fixed, schema = row["fixed"], row["arithmetic_schema"]
        stored = data["program"]["body_node_total"]
    elif source_id == "stationary_comparison":
        row = data["parameter_checks"][0]
        computation_nodes = row["D_base"] + row["D_step"]
        fixed, schema = row["Sep"], row["SC"]
        stored = data["selected_program_costs"]["selected_program_total"]
    elif source_id == "stationary_comparison_fixed_predecessor":
        computation_nodes = sum(
            row["nodes"] for row in data["one_parameter_computations"]["fixed_p"]
        )
        fixed = data["fixed_axioms"]["Sep"]["nodes"]
        schema = data["one_parameter_schemas"]["CE"]["nodes"]
        stored = data["selected_descriptors"]["fixed_p_without_Z"]["total"]
    else:
        raise ValueError(source_id)
    return {
        "computation": computation_nodes,
        "fixed_arithmetic": fixed,
        "arithmetic_schema": schema,
        "total": computation_nodes + fixed + schema,
        "selected_body_nodes": stored,
    }


def metric_report() -> dict:
    separation = ne(ZERO, succ(ZERO))
    old_bridge = bridge(relative=True)
    assert separation.nodes() == 6
    assert old_bridge.nodes() == 11
    rows = []
    for m in range(1, 5):
        base, step = computation(m, "swap")
        pc, ss = arithmetic(m, "PC"), arithmetic(m, "SS")
        dsize = base.nodes() + step.nodes()
        old_total = dsize + ss.nodes() + old_bridge.nodes()
        new_total = dsize + pc.nodes() + separation.nodes()
        assert dsize == 13 + 6 * m
        assert pc.nodes() == 20 + 5 * m
        assert ss.nodes() == 17 + 5 * m
        assert new_total == 39 + 11 * m
        assert old_total == 41 + 11 * m
        assert old_total - new_total == 2
        rows.append({
            "displayed_parameters": m,
            "D_base": base.nodes(), "D_step": step.nodes(),
            "D_total": dsize, "PC": pc.nodes(), "separation": 6,
            "SS": ss.nodes(), "old_bridge": 11,
            "new_total": new_total, "old_swap_total": old_total, "saving": 2,
        })
    n, a, b, v = (node(name) for name in ("n", "a", "b", "v"))
    updates = {
        "C": b,
        "D": v,
        "T": node("C", node("D", a, n),
                  node("C", node("D", n, a), a, ZERO), a),
    }
    update_counts = {name: expression.nodes() for name, expression in updates.items()}
    assert update_counts == {"C": 1, "D": 1, "T": 11}
    comparison = []
    for source in SOURCE_RECORDS:
        base, step = computation(1, source["grammar_key"])
        schema = arithmetic(1, source["schema_key"])
        fixed = bridge(source["relative_bridge"]) if source["fixed_key"] == "O" else separation
        independent = {
            "computation": base.nodes() + step.nodes(),
            "fixed_arithmetic": fixed.nodes(),
            "arithmetic_schema": schema.nodes(),
            "total": base.nodes() + step.nodes() + fixed.nodes() + schema.nodes(),
        }
        for key, value in independent.items():
            assert source["observed_counts"][key] == value, (source["id"], key)
        comparison.append({
            "archive": source["archive"],
            "grammar": source["grammar_key"],
            "stored_descriptor_inputs": source["stored_descriptor_inputs"],
            **source["observed_counts"],
            "body_count_scope": source["body_count_scope"],
            "source_metric_artifact": source["metric_artifact"],
            "source_metric_sha256": source["metric_sha256"],
            "independent_display_recount": "PASS",
        })
    sample_base, sample_step = computation(1, "swap")
    return {
        "status": "PASS",
        "convention": (
            "One node per variable occurrence, constant, application, equality, connective, "
            "falsity, and individual quantifier. A bound-variable label is metadata, not a "
            "second quantifier child. Expand 1 as S(0) and negation as implication to bottom."
        ),
        "limits": (
            "Exact displayed AST counts, not complete theory bit lengths. Schematic calls "
            "charge shown arguments, not substituted bodies; grammar, binders, names, and "
            "enumerator encodings are separate. Every finite parameter arity is admitted."
        ),
        "uniform_formulas": {
            "D_swap": "13 + 6*m", "PC": "20 + 5*m", "separation": 6,
            "old_swap_total": "41 + 11*m", "new_total": "39 + 11*m",
            "range": "m >= 1",
        },
        "parameter_rows": rows,
        "one_parameter_trees": {
            "D_base": sample_base.tree(), "D_step": sample_step.tree(),
            "PC": arithmetic(1, "PC").tree(), "separation": separation.tree(),
            "SS": arithmetic(1, "SS").tree(), "old_bridge": old_bridge.tree(),
        },
        "selected_update_bodies": {
            name: {"nodes": value.nodes(), "tree": value.tree()}
            for name, value in updates.items()
        },
        "selected_update_total": sum(update_counts.values()),
        "unchanged_common_initialized_base": "The seed a is fixed in the grammar.",
        "signature_scope": "0, S, and countably many generated recursion symbols.",
        "comparison_commit": SOURCE_COMMIT,
        "current_seven_archives": comparison,
        "classical_biconditional_caution": {
            "stationary_agreement_alternative_total_with_primitive_iff": 47,
            "same_alternative_with_iff_expanded": 63,
            "reason": "The 47-node value uses a different logical alphabet.",
        },
    }


Update = Callable[[int, int, tuple[int, ...], int], int]


def make_swap(update: Update):
    """Direct numerical semantics; each recursive call decreases x+a by one."""
    @lru_cache(maxsize=None)
    def recursive(x: int, a: int, frozen: tuple[int, ...] = ()) -> int:
        if x < 0 or a < 0 or any(b < 0 for b in frozen):
            raise ValueError("Natural-number arguments are required.")
        if x == 0:
            return a
        n = x - 1
        return update(n, a, frozen, recursive(a, n, frozen))
    return recursive


def pred(x: int) -> int:
    return max(x - 1, 0)


def compiled_swap(
    update: Update, x: int, y: int, frozen: tuple[int, ...] = (),
    mutation: str | None = None,
) -> int:
    """Ordinary PR diagonal fold V; independent of direct swap recursion."""
    d, e = max(x - y, 0), max(y - x, 0)
    m = x - d
    if d == 0:
        value = 0 if mutation == "wrong_zero_axis" else e
    else:
        value = update(pred(d), 0, frozen, pred(d))
    for j in range(m):
        inner = update(e + j, d + j, frozen, value)
        outer_seed = e + j if mutation == "missing_successor" else 1 + e + j
        value = update(d + j, outer_seed, frozen, inner)
    return value


C_PROGRAM = make_swap(lambda n, a, frozen, value: frozen[0])
D_PROGRAM = make_swap(lambda n, a, frozen, value: value)


def C(z: int, u: int, w: int) -> int:
    return C_PROGRAM(z, u, (w,))


def D(x: int, y: int) -> int:
    return D_PROGRAM(x, y)


def eraser_update(n: int, a: int, frozen: tuple[int, ...], value: int) -> int:
    return C(D(a, n), C(D(n, a), a, 0), a)


T_PROGRAM = make_swap(eraser_update)


def T(x: int, y: int) -> int:
    return T_PROGRAM(x, y)


def equality_bit(x: int, y: int) -> int:
    return C(T(x + 1, y + 1), 1, 0)


def compiler_checks() -> dict:
    updates: list[tuple[str, Update]] = [
        ("previous_value", lambda n, a, b, v: v),
        ("counter", lambda n, a, b, v: n),
        ("seed", lambda n, a, b, v: a),
        ("zero", lambda n, a, b, v: 0),
        ("successor_value", lambda n, a, b, v: v + 1),
        ("all_inputs", lambda n, a, b, v: 2*n + 3*a + v + sum(b)),
        ("nonlinear_mod_257", lambda n, a, b, v: (v*v + n*a + sum(b)) % 257),
        ("conditional", lambda n, a, b, v: v + a if n % 2 == 0 else n + sum(b)),
        ("frozen_positions", lambda n, a, b, v: v + sum((i+1)*x for i, x in enumerate(b))),
    ]
    parameter_tuples = [(), (0,), (2,), (0, 3), (4, 1), (2, 0, 3)]
    grid = range(25)
    comparisons = 0
    for name, update in updates:
        direct = make_swap(update)
        for frozen in parameter_tuples:
            for x, y in itertools.product(grid, repeat=2):
                assert direct(x, y, frozen) == compiled_swap(update, x, y, frozen), (
                    name, x, y, frozen
                )
                comparisons += 1
    successor_equations = 0
    for name, update in updates:
        for frozen in parameter_tuples:
            for n, a in itertools.product(range(17), repeat=2):
                lhs = compiled_swap(update, n + 1, a, frozen)
                rhs = update(n, a, frozen, compiled_swap(update, a, n, frozen))
                assert lhs == rhs, (name, n, a, frozen)
                successor_equations += 1
    return {
        "status": "PASS", "direct_vs_diagonal_compiler_cases": comparisons,
        "input_grid": [0, 24], "named_updates": [name for name, _ in updates],
        "frozen_parameter_tuples": [list(item) for item in parameter_tuples],
        "compiled_successor_equation_cases": successor_equations,
        "equation_grid": [0, 16],
        "scope": "Standard natural-number samples of two independently implemented algorithms.",
    }


def program_checks() -> dict:
    selector_cases = 0
    for z, u, w in itertools.product(range(9), repeat=3):
        assert C(z, u, w) == (u if z == 0 else w)
        selector_cases += 1
    pairs = 0
    for x, y in itertools.product(range(65), repeat=2):
        expected_d = max(y - x, 0) + pred(max(x - y, 0))
        assert D(x, y) == expected_d
        assert T(x, y) == (0 if x == y else y)
        assert equality_bit(x, y) == int(x == y)
        assert T(x, y) == y or x == y
        pairs += 1
    for n in range(65):
        assert D(n, n) == 0
        assert D(n, n + 1) == 1
        assert T(n + 1, n + 1) == 0
    return {
        "status": "PASS", "selector_cases": selector_cases,
        "ordered_pairs": pairs, "pair_grid": [0, 64],
        "checked": [
            "C constructor selector", "D monus formula", "T equality eraser",
            "direct equality bit", "off-diagonal alternative",
            "D zero diagonal", "D successor diagonal", "T positive diagonal",
        ],
    }


def ordinary_to_swap(base, update, mutation: str | None = None):
    """F(n,b)=R_h(Sn,Sn,b), using only C and the computed equality bit."""
    def swap_update(n, a, frozen, value):
        counter = n if mutation == "missing_predecessor" else pred(n)
        delayed = C(equality_bit(n, 0), update(counter, frozen, value), base(frozen))
        return C(equality_bit(a, n), delayed, value)
    recursive = make_swap(swap_update)
    return lambda n, frozen=(): recursive(n + 1, n + 1, frozen)


def ordinary_recursion_checks() -> dict:
    cases = [
        ("identity", lambda b: 0, lambda n, b, v: v + 1, [()]),
        ("triangular", lambda b: 0, lambda n, b, v: v + n, [()]),
        ("factorial", lambda b: 1, lambda n, b, v: (n + 1)*v, [()]),
        ("addition", lambda b: b[0], lambda n, b, v: v + 1,
         [(a,) for a in (0, 1, 2, 5)]),
        ("multiplication", lambda b: 0, lambda n, b, v: v + b[0],
         [(a,) for a in (0, 1, 2, 5)]),
        ("power", lambda b: 1, lambda n, b, v: v*b[0],
         [(a,) for a in (0, 1, 2, 5)]),
        ("falling_factorial", lambda b: 1,
         lambda n, b, v: max(b[0] - n, 0)*v, [(a,) for a in (0, 1, 2, 5)]),
        ("two_parameters", lambda b: b[0] + b[1],
         lambda n, b, v: (v*v + 2*n + 3*b[0] + b[1]) % 257,
         list(itertools.product(range(4), repeat=2))),
    ]
    comparisons = 0
    recurrence_cases = 0
    for name, base, update, parameter_tuples in cases:
        translated = ordinary_to_swap(base, update)
        for frozen in parameter_tuples:
            expected = base(frozen)
            for n in range(17):
                assert translated(n, frozen) == expected, (name, n, frozen)
                comparisons += 1
                next_value = update(n, frozen, expected)
                assert translated(n + 1, frozen) == next_value, (name, n, frozen)
                recurrence_cases += 1
                expected = next_value
    return {
        "status": "PASS", "counter_range": [0, 16],
        "programs": [item[0] for item in cases],
        "direct_vs_translated_values": comparisons,
        "translated_recurrence_equations": recurrence_cases,
        "scope": "Finite samples; the update uses the declared C,T equality bit.",
    }


def eval_formula(formula, valuation):
    if formula[0] == "atom":
        return bool(valuation[formula[1]])
    if formula[0] == "false":
        return False
    if formula[0] == "true":
        return True
    left, right = (eval_formula(x, valuation) for x in formula[1:])
    if formula[0] == "and":
        return left and right
    if formula[0] == "or":
        return left or right
    return (not left) or right


def compile_formula_bit(formula, valuation):
    if formula[0] == "atom":
        return valuation[formula[1]]
    if formula[0] == "false":
        return 0
    if formula[0] == "true":
        return 1
    left, right = (compile_formula_bit(x, valuation) for x in formula[1:])
    if formula[0] == "and":
        return C(left, 0, right)
    if formula[0] == "or":
        return C(left, right, 1)
    return C(left, 1, right)


def boolean_and_latch_checks() -> dict:
    leaves = [("atom", "p"), ("atom", "q"), ("false",), ("true",)]
    depth_one = leaves + [
        (op, left, right)
        for op in ("and", "or", "implies")
        for left, right in itertools.product(leaves, repeat=2)
    ]
    depth_two = leaves + [
        (op, left, right)
        for op in ("and", "or", "implies")
        for left, right in itertools.product(depth_one, repeat=2)
    ]
    formula_cases = 0
    for p, q in itertools.product((0, 1), repeat=2):
        valuation = {"p": p, "q": q}
        for formula in depth_two:
            result = compile_formula_bit(formula, valuation)
            assert result in (0, 1)
            assert result == int(eval_formula(formula, valuation))
            formula_cases += 1
    local_latch_cases = 0
    for bit, next_bit, old_value in itertools.product((0, 1), (0, 1), range(8)):
        if bit == 1 and next_bit == 0:
            continue
        next_value = C(bit, 0, old_value)
        second_value = C(next_bit, 0, next_value)
        assert second_value == next_value
        local_latch_cases += 1
    sequences = 0
    hypotheses_satisfied = 0
    for bits in itertools.product((0, 1), repeat=12):
        values = [1]
        for bit in bits:
            values.append(C(bit, 0, values[-1]))
        sequences += 1
        hypotheses = bits[0] == 1 and all(
            not bits[i] or bits[i + 1] for i in range(len(bits) - 1)
        )
        if hypotheses:
            hypotheses_satisfied += 1
            assert all(value == 1 for value in values)
            assert all(bits)
    return {
        "status": "PASS", "formulas_of_depth_at_most_two": len(depth_two),
        "Boolean_valuations_per_formula": 4, "formula_cases": formula_cases,
        "local_latch_stationarity_cases": local_latch_cases,
        "arbitrary_previous_latch_values": [0, 7],
        "Boolean_sequences_of_length_twelve": sequences,
        "sequences_satisfying_induction_hypotheses": hypotheses_satisfied,
        "scope": (
            "Bit-operation diagnostics and the local shifted-latch identity. "
            "No claim of an automated proof of intuitionistic formula equivalence."
        ),
    }


def negative_controls() -> list[dict]:
    witnesses = []
    update = lambda n, a, frozen, value: a
    direct = make_swap(update)
    for mutation in ("wrong_zero_axis", "missing_successor"):
        witness = None
        for x, y in itertools.product(range(6), repeat=2):
            correct = direct(x, y)
            wrong = compiled_swap(update, x, y, mutation=mutation)
            if correct != wrong:
                witness = {
                    "mutation": mutation, "detected": True,
                    "input": [x, y], "expected": correct, "mutated": wrong,
                    "update": "h(n,a,v)=a",
                }
                break
        assert witness is not None, mutation
        witnesses.append(witness)
    base = lambda frozen: 0
    update_ord = lambda n, frozen, value: value + n
    ordinary_bad = ordinary_to_swap(base, update_ord, "missing_predecessor")
    expected = 0
    witness = None
    for n in range(8):
        got = ordinary_bad(n)
        if got != expected:
            witness = {
                "mutation": "ordinary_update_uses_n_instead_of_pred_n", "detected": True,
                "input": [n], "expected": expected, "mutated": got,
                "program": "F(0)=0; F(Sn)=F(n)+n",
            }
            break
        expected += n
    assert witness is not None
    witnesses.append(witness)
    bad_t = make_swap(lambda n, a, frozen, value: C(D(a, n), C(D(a, n), a, 0), a))
    witness = None
    for x, y in itertools.product(range(6), repeat=2):
        expected = 0 if x == y else y
        got = bad_t(x, y)
        if got != expected:
            witness = {
                "mutation": "eraser_inner_D_arguments_reversed", "detected": True,
                "input": [x, y], "expected": expected, "mutated": got,
            }
            break
    assert witness is not None
    witnesses.append(witness)
    return witnesses


def verify_sources(directory: Path) -> None:
    for record in SOURCE_RECORDS:
        archive = directory / record["local_archive"]
        data = archive.read_bytes()
        assert len(data) == record["size_bytes"], archive
        assert hashlib.sha256(data).hexdigest() == record["archive_sha256"], archive
        git_hash = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        assert git_hash == record["git_blob_sha1"], archive
        with zipfile.ZipFile(archive) as zipped:
            metric = zipped.read(record["metric_artifact"])
        assert hashlib.sha256(metric).hexdigest() == record["metric_sha256"], archive
        assert source_counts(record["id"], json.loads(metric)) == record["observed_counts"]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify-sources", type=Path, default=None)
    args = parser.parse_args()
    if args.verify_sources is not None:
        verify_sources(args.verify_sources)
    metrics = metric_report()
    report = {
        "status": "PASS",
        "scope": (
            "Exact syntax counts and deterministic finite numerical diagnostics. "
            "This is not a proof-assistant verification of the axiomatization or its "
            "bi-interpretability theorem. No downloaded source code is executed."
        ),
        "swap_compiler": compiler_checks(),
        "designated_programs": program_checks(),
        "ordinary_recursion_compiler": ordinary_recursion_checks(),
        "Boolean_compiler_and_latch": boolean_and_latch_checks(),
        "negative_controls": negative_controls(),
        "source_provenance": {
            "repository": "VladimirReshetnikov/ProveIt", "commit": SOURCE_COMMIT,
            "method": "The seven original ZIP byte streams and cited JSON were read as data.",
            "archives": SOURCE_RECORDS,
        },
    }
    script_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    metrics["generator_sha256"] = script_hash
    report["generator_sha256"] = script_hash
    output = Path(__file__).resolve().parent / "artifacts"
    output.mkdir(exist_ok=True)
    for name, data in (("checks.json", report), ("schema_metrics.json", metrics)):
        (output / name).write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "status": "PASS", "new_display": metrics["parameter_rows"][0]["new_total"],
        "old_display": metrics["parameter_rows"][0]["old_swap_total"],
        "swap_compiler_cases": report["swap_compiler"]["direct_vs_diagonal_compiler_cases"],
        "ordinary_compiler_cases": report["ordinary_recursion_compiler"]["direct_vs_translated_values"],
        "negative_controls_detected": len(report["negative_controls"]),
        "outputs": ["artifacts/checks.json", "artifacts/schema_metrics.json"],
    }, sort_keys=True))


if __name__ == "__main__":
    main()
