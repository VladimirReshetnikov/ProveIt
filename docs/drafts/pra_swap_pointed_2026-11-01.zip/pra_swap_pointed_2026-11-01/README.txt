PRA FROM INITIALIZED SWAP RECURSION AND POINTED CONSTANCY
Research package prepared for Vladimir Reshetnikov
1 November 2026

MAIN RESULT

The same effective nonlogical specification works in classical and
intuitionistic first-order equality logic. In each case it is definitionally
equivalent, hence bi-interpretable and equiconsistent, with the corresponding
version of first-order PRA. Both interpreted domains are the full carrier,
both equalities are native equality, and both round-trip isomorphisms are
the identity. The paper proves these statements, including internal
uniqueness at nonstandard arguments.

The basis combines initialized swap recursion with one ground inequality
and one pointed-constancy schema. Compared with the current initialized-swap
draft, it changes only the arithmetic axioms and gives exactly the same
theory in the same language.

Measured improvement: 50 rather than 52 formula-tree nodes at one displayed
parameter. The selected update bodies stay unchanged at 13 nodes. Thus the
display-plus-selected-body subtotal improves from 65 to 63. The saving is
two display nodes at every parameter arity. This is not a claim of absolute
minimality under every possible language or encoding.

CONTENTS

  report.tex                    Complete, self-contained LaTeX manuscript.
  report.pdf                    Compiled paper, including an axiom card.
  checks.py                     Standard-library Python diagnostics and AST counts.
  artifacts/checks.json          Results, mutation controls, source metrics/hashes.
  artifacts/schema_metrics.json  Exact displayed syntax trees and counts.
  formal/SwapPointed.lean        Constructive forward proof kernel.
  formal/lean-check.log          Successful Lean run and 19 global-axiom audits.
  formal/README.txt              Exact formalization scope and reproduction notes.
  lean-toolchain                Lean compiler version used.
  audit/source_manifest.json    Seven immutable comparison archives and hashes.
  audit/validation.json         Build, formal-check, diagnostic, and review record.
  SHA256SUMS                    SHA-256 checksums of delivered package files.
  Makefile                      Convenient build/check commands.

REPRODUCTION

Rebuild the PDF with a standard TeX Live installation:

  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex

Run exact formula-tree counts and finite numerical diagnostics:

  python3 checks.py

No network calls or external Python libraries are used. The JSON reports
are deterministically regenerated. To additionally verify the seven original
ZIP files, download the exact immutable URLs listed in the manifest and use:

  python3 checks.py --verify-sources /path/to/source-archives

The duplicate-named stationary-comparison archive is expected locally as
pra_stationary_comparison_2026-10-31_variant.zip; this mapping is recorded
in the manifest and checker. Downloaded scripts are never executed.

Check the formal kernel with Lean 4.19.0 (no Mathlib or other dependency):

  lean formal/SwapPointed.lean

Each of the 19 printed endpoint audits should report no global axioms.
This means the theorems follow constructively from explicit Basis hypotheses;
it does not remove the arithmetic hypotheses themselves.

VERIFY WHAT THE ARTIFACTS CLAIM

The Lean proof uses an arbitrary carrier and an explicit predicate marking
term denotations. Every pointed-constancy invocation supplies membership
evidence. It checks the new arithmetic bootstrap, contextual constancy,
equality recognition, the ordinary-recursion equation interface, the formula
compiler, and the latch/induction interface. It does not assume induction
on the carrier, a decidable-equality instance, classical choice, or admitted
proofs. The latch's term membership and computation equations are explicit
inputs; the mathematical construction in the paper supplies them.

Full first-order syntax, the entire generated description grammar, the
reverse compiler, general internal uniqueness, and both interpretation
composites are written mathematical proofs, not a complete Lean
formalization. Finite Python tests are diagnostics, not universal proofs.

SOURCES AND ATTRIBUTION

The seven current PRA drafts were inspected at ProveIt commit:
e6474c41337c6495c4589970d8d1bfdcfce65b66

The initialized swap grammar, the three designated programs, and the reverse
diagonal-fold compiler come from pra_initialized_swap_2026-10-31.zip.
The pointed-constancy idea is adapted from pra_pointed_constancy_2026-10-31.zip
to the initialized relative-value comparator. The new strict simplification
is their compatible arithmetic basis, with the constructive bootstrap and
same-language equivalence proved here. The new Lean kernel credits the
source certificate it adapts. Bibliographic references are in the paper.

The archive does not include copies of the seven comparison ZIP files;
immutable URLs and exact hashes identify them without duplicating them.

LOGICAL CONVENTIONS

The classical and intuitionistic results are separate matching-logic
equivalences. The theory is effectively infinite, with arbitrary finite
parameter tuples. Three designated programs are not a three-symbol total
signature. No finite first-order axiomatization or universal PR evaluator
is claimed. The first-order target allows general quantified formulas and
restricts only induction matrices to quantifier-free formulas.
