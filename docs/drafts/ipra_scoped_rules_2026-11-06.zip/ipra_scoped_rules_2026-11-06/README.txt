A SMALLER PROOF SYSTEM FOR iPRA
Prepared for Vladimir Reshetnikov, 6 November 2026

START HERE

  report.pdf       Complete self-contained mathematical report.
  report.tex       LaTeX source, with sections/ and results/numbers.tex.
  checker.py       The entire trusted acceptance program.
  FORMAT.txt       Complete concrete syntax and a worked certificate.

RESULT

The standalone checker is smaller than the coordinatewise lower envelope of
the SIX CURRENT draft checkers at repository commit:
  820ef51b6ad3c13ce4a500673a9e81d951fbc06c

                              Current envelope     This construction
  AST nodes                         712                  687
  Significant source tokens        664                  644
  Normalized tokens                 662                  642
  Normalized UTF-8 source bytes    2,150                2,078
  Original file bytes             2,441                2,396

The same [context, claimed_formula, proof] JSON interface is retained.
The comparison counts the full executable checker, including formation,
substitution, logic, arithmetic, JSON input, and the error/success interface.
Python and its standard JSON parser are the common platform assumptions.

The mathematical basis is inherited with attribution from the supplied
draft series. The improvement combines a shared fresh-number transition
for introductions and the numerical rule, indexed checked hypotheses,
inferred existential conclusions, and structural computation certificates.
No necessary scope or syntax check has been deleted.

The native calculus faithfully presents a conventional first-order theory
that is bi-interpretable with full first-order intuitionistic primitive
recursive arithmetic with quantifier-free induction. Both interpretations
use the whole number sort; equality gives both internally definable
round-trip isomorphisms. The conventional realization explicitly retains
ordinary numerical coverage and a bridge to genuine falsity.

This is an incremental finite comparison, not an absolute minimality theorem.
The program is not claimed formally verified in Lean or Rocq. The report
contains the soundness/completeness and bi-interpretability arguments.

RUN

Python 3.10+ and the standard library suffice. The recorded metrics use
CPython 3.12.14; a different ast.unparse version may change normalized size.

  python3 checker.py examples/reflexivity.json
  python3 reproduce.py
  python3 reproduce.py --pdf

The first command prints ACCEPT. The second reruns the independent audit,
the source measurements, and the predecessor proof translations offline.
The third also rebuilds the PDF using pdfLaTeX. To build a fresh ZIP:

  python3 build.py --zip

VALIDATION

  34,480 independent finite implementation checks; zero failures.
  150 DISTINCT translated positive certificates accepted by a separate
    explicit-rule oracle using fresh named variables for substitution.
  149 predecessor certificates translated forward and back, each rechecked
    by the corresponding checker with identical contexts and conclusions.
  Four extra numerical-premise tests use a hypothesis as the old premise,
    including free parameters and quantified matrices.
  107 legacy raw negative certificates, plus new-format focused negatives.
  CLI behavior checked with and without Python -O.

The two source corpora overlap. They are not 299 distinct positive examples.
Proof-tree roundtrip equality is not claimed; the numerical translation can
insert an eta-expansion. Tests provide finite implementation evidence, not
a proof of the Python runtime or a replacement for the mathematical report.

COMPARISON PROVENANCE

comparison/manifest.json pins all six source archives by exact SHA-256 and
Git blob identity. The current comparison includes a 168-source census
(787 occurrences), three additional standalone sources, and 74 historical
dependency groups, with 198 distinct frozen Python files in total. All
recorded acceptance dependencies of a group are counted together.

Historical variants are not all independently certified sound and complete;
the finite inventory includes favorable core-only boundaries. The observed
minima are complete standalone checkers. The additional historical sources
do not improve on the current six-draft envelope.

TRUST BOUNDARY

Only checker.py and its Python/JSON runtime participate in acceptance.
No proof generator, translator, oracle, comparator, LaTeX tool, result file,
or source archive is imported by checker.py.

Candidate SHA-256:
  21204fe46d0677f27f5ee1737d6659dbecf2bdbea201a9710fff7d7821cafe8e

CONTENTS

  comparison/             Exact-byte frozen sources and measurement tool.
  validation/run.py       Independent grammar, substitution and rule audit.
  validation/rule_oracle.py  Explicit independent proof interpreter.
  validation/named_syntax.py Independent named-variable syntax operations.
  validation/corpus/      150 positive new-format certificates.
  validation/legacy_negative/ 107 raw negative fixtures and their manifest.
  validation/reference/   Frozen predecessor and its 149-certificate corpus.
  validation/translate_curried.py  Untrusted two-way proof translator.
  validation/replay.py    Recheck both translation directions.
  examples/               Selected small logical and arithmetic proofs.
  results/                Full metrics, finite-audit and replay reports.
  MANIFEST.sha256         Integrity hashes of all other packaged files.

The report includes a Further research questions section.
