#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 artifacts/check_axioms.py
lean_bin=${PRA_LEAN:-lean}
if command -v "$lean_bin" >/dev/null 2>&1; then
  "$lean_bin" formal/AnchoredInvolution.lean
else
  printf '%s\n' 'Lean rerun skipped: set PRA_LEAN to a Lean 4.19.0 executable.'
  printf '%s\n' 'The original successful compiler audit is in formal/lean_check.log.'
fi
