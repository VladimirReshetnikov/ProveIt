PRA FROM BOUNDED REFLECTION AND POSITIVE CONSTANCY
================================================
Research report prepared for Vladimir Reshetnikov, 31 October 2026.

RESULT
The following same nonlogical basis works over classical and intuitionistic
first-order equality logic, separately:

  all ordinary effective PR defining equations;
  0 != S0;
  R(R(x,y),y)=x;
  positive constancy PC.

Here R is the SPECIFIED primitive-recursive bounded reflection
R(0,a)=a; R(Sn,a)=C(M(a,Sn),M(Sn,a),Sn).
The exact language, scopes, and definitions are in SPECIFICATION.txt.

The theories are deductively equal to corresponding PRA in the same
language. Thus both interpretations and both round trips are identities;
equiconsistency follows as well.

WHAT IS NEW RELATIVE TO THE INSPECTED DRAFTS
The minimum-symmetry draft already proposed an abstract anchored involution.
This report completes that suggestion with a simple explicit program and a
complete constructive internal PRA proof. Native equality reflection takes
three lines and precedes all induction. One parameter-free PC instance
gives constructor coverage; a direct latch yields all quantifier-free
induction. An alternative zero/parameter transposition is also proved.

The fixed equation has 9 nodes versus the minimum identity's 13. The complete
arithmetic display at one displayed parameter has 41 versus 42 for the current
full-language PI basis and 45 (43 delayed) for retraction. The main theorem
allows arbitrary finite parameter tuples. Some other inspected presentations
have shorter displays with different vocabularies/grammars. All program and
grammar costs are disclosed; no absolute shortestness is claimed.

FILES
pra_anchored_involution.tex / .pdf   Complete manuscript and compiled report.
SPECIFICATION.txt                  Standalone exact axioms and scope.
formal/AnchoredInvolution.lean      Constructive Lean 4.19.0 local kernel.
formal/lean_check.log               Original successful endpoint audit.
formal/README.txt                   Precise formal scope and limits.
artifacts/check_axioms.py           Reproducible counts and finite diagnostics.
artifacts/check_results.json        Recorded diagnostic results.
audit/source_audit.json             Pinned source identities and review scope.
audit/validation.json               Build and validation summary.
build.sh / check.sh                 Reproduction commands.
SHA256SUMS                         File checksums, except this manifest itself.

REBUILD
  sh build.sh
Requires latexmk and pdfLaTeX with ordinary TeX Live packages listed in the
source preamble. No external bibliography program is needed.

CHECK
  sh check.sh
or, if Lean is not on PATH:
  PRA_LEAN=/absolute/path/to/lean sh check.sh
The Python diagnostics require only Python 3 and its standard library.
To check delivered bytes before rebuilding:
  sha256sum -c SHA256SUMS

VERIFICATION LIMITS
The written report proves the entire common-language equivalence. Lean
checks the arbitrary-carrier constructive kernel through formula compilation
and induction transfer, with explicit per-term PC/latch premises. Its 21
global axiom-dependency audits are empty; the arithmetic hypotheses remain
explicit assumptions. It does not formalize all PR syntax, the reverse
bounded-reflection proof, or the entire first-order bi-interpretation.
Numerical grid checks are diagnostics only, not universal proofs.

SOURCE SNAPSHOT
ProveIt commit 3af028c8eb45b393331630537c5a94939c536341.
All six current docs/drafts PRA archives were inspected. Incoming directory
inventory/index had no additional PRA archive. Sources are not redistributed.
No repository changes were made.
