#!/usr/bin/env python3
"""Reproducible syntax counts and finite diagnostics; not universal proofs.

No third-party dependencies. Numerical functions below execute the defining
recursions. Formula nodes count variable occurrences, applications, logical
symbols, and individual quantifiers; negation expands to implication to false.
"""
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
import json


@dataclass(frozen=True)
class Node:
    name: str
    children: tuple = ()


def node(name, *children):
    return Node(name, children)


def size(t):
    return 1 + sum(size(c) for c in t.children)


def eq(a, b):
    return node('=', a, b)


def implies(a, b):
    return node('implies', a, b)


def negate(a):
    return implies(a, node('false'))


def forall(v, body):
    return node('forall:' + v, body)


def all_vars(vs, body):
    for v in reversed(vs):
        body = forall(v.name, body)
    return body


Z = node('0')
n, x, y, a, v, k, u = [node(s) for s in ('n', 'x', 'y', 'a', 'v', 'k', 'u')]
S = lambda t: node('S', t)
M = lambda t, z: node('M', t, z)
C = lambda z, t, w: node('C', z, t, w)
R = lambda t, z: node('R', t, z)
one = S(Z)


def pc(parameter_count):
    ps = [node('a' + str(i)) for i in range(parameter_count)]
    f = lambda t: node('f', t, *ps)
    return all_vars(ps, implies(
        forall('n', eq(f(S(S(n))), f(S(n)))),
        forall('n', node('or', eq(n, Z), eq(f(n), f(one))))))


def full_definitions(parameter_count):
    ps = [node('a' + str(i)) for i in range(parameter_count)]
    F = lambda t: node('F_g_h', t, *ps)
    base = all_vars(ps, eq(F(Z), node('g', *ps)))
    step = all_vars([n] + ps, eq(F(S(n)), node('h', n, F(n), *ps)))
    return base, step


sep = negate(eq(Z, one))
inv = all_vars([x, y], eq(R(R(x, y), y), x))
minimum = all_vars([x, y], eq(M(M(x, y), y), M(M(y, x), x)))
bounded_update = C(M(a, S(n)), M(S(n), a), S(n))
swap_update = C(M(S(n), a), C(M(a, S(n)), Z, S(n)), S(n))


def syntax_counts():
    results = {
        'Sep': size(sep),
        'Inv': size(inv),
        'minimum_identity': size(minimum),
        'PC_one_parameter': size(pc(1)),
        'new_arithmetic_one_parameter': size(sep) + size(inv) + size(pc(1)),
        'full_D_base_one_parameter': size(full_definitions(1)[0]),
        'full_D_step_one_parameter': size(full_definitions(1)[1]),
        'full_D_one_parameter': sum(map(size, full_definitions(1))),
        'new_display_total_one_parameter':
            size(sep) + size(inv) + size(pc(1)) + sum(map(size, full_definitions(1))),
        'bounded_reflection_update': size(bounded_update),
        'transposition_update': size(swap_update),
        'bounded_reflection_selected_description_terms': 2 + 3 + 2 + 1 + size(bounded_update),
        'transposition_selected_description_terms': 2 + 3 + 2 + 1 + size(swap_update),
    }
    expected = [6, 9, 13, 26, 41, 7, 13, 20, 61, 11, 15, 19, 23]
    assert list(results.values()) == expected, results
    for m in range(8):
        assert size(pc(m)) == 21 + 5*m
        assert sum(map(size, full_definitions(m))) == 13 + 7*m
    return results


def pred(n):
    assert n >= 0
    return 0 if n == 0 else n - 1


@lru_cache(maxsize=None)
def monus(counter, seed):
    """M(0,a)=a; M(Sn,a)=p(M(n,a)), implemented by its finite iteration."""
    value = seed
    for _ in range(counter):
        value = pred(value)
    return value


def choose(z, left, right):
    return left if z == 0 else right


def gate(z, seed):
    return seed if z == 0 else 0


def reflection(x, a):
    if x == 0:
        return a
    return choose(monus(a, x), monus(x, a), x)


def transposition(x, a):
    if x == 0:
        return a
    return choose(monus(x, a), choose(monus(a, x), 0, x), x)


def run_numerical_checks(bound=128):
    assertions = 0

    def check(statement):
        nonlocal assertions
        assert statement
        assertions += 1

    for a0 in range(bound + 1):
        check(reflection(0, a0) == a0)
        check(transposition(0, a0) == a0)
        for x0 in range(bound + 1):
            rx = reflection(x0, a0)
            tx = transposition(x0, a0)
            check(rx == (a0 - x0 if x0 <= a0 else x0))
            check(tx == (a0 if x0 == 0 else 0 if x0 == a0 else x0))
            check(reflection(rx, a0) == x0)
            check(transposition(tx, a0) == x0)
            check((rx == 0) == (x0 == a0))
            check((tx == 0) == (x0 == a0))
            check(monus(x0, a0) == max(a0-x0, 0))
            check(monus(x0, x0+a0) == a0)
            check(a0 == x0+monus(x0, a0) or x0 == a0+monus(a0, x0))

    def pc_error_pair(pair):
        return tuple(reflection(t, pred(t)+1) for t in pair)

    witness = (0, 1)
    check(witness != (0, 0))
    check(witness != tuple(pred(t)+1 for t in witness))
    check(pc_error_pair(witness) == (1, 0))
    check(pc_error_pair(witness) != pc_error_pair((1, 1)))
    for i in range(8):
        for j in range(8):
            check(pc_error_pair((i+1, j+1)) == (0, 0))
    return {
        'inclusive_grid_bound': bound,
        'ordered_pairs_per_function': (bound+1)**2,
        'passed_assertions': assertions,
        'product_model_witness': list(witness),
        'coverage_error_at_witness': list(pc_error_pair(witness)),
        'scope': 'Finite implementation diagnostics only. The report proves universal/internal claims.'
    }


if __name__ == '__main__':
    result = {
        'convention': 'Each variable, constant, application, equality, connective, bottom, or individual quantifier is one node; negation and 1 are expanded.',
        'program_scope': 'Descriptions are explicitly separated from displayed formula sizes; these are not bit-length minimality bounds.',
        'syntax': syntax_counts(),
        'parameter_formulas': {'PC_m': '21 + 5*m', 'arithmetic_m': '36 + 5*m', 'full_D_m': '13 + 7*m'},
        'diagnostics': run_numerical_checks(),
    }
    output = Path(__file__).with_name('check_results.json')
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
