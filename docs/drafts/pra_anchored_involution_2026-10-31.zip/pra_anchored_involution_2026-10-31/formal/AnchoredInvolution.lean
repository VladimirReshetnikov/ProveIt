/-
  Anchored involution: constructive local proof kernel, Lean 4.19.0.

  The carrier is arbitrary. No induction principle for that carrier occurs.
  PositiveConstancyInstance is a premise for ONE displayed term instance,
  never a global axiom about all semantic functions. The Core uses only the
  coverage term R(n,S(P(n,0))). The induction theorem additionally takes the latch
  for its chosen error term and that latch's individual PC instance.

  Formula syntax below has already evaluated atomic operands. Its structural
  induction verifies the finite propositional compiler, not the syntax of
  primitive recursion or the complete first-order bi-interpretation theorem.
-/

universe u
namespace AnchoredInvolution

/-- The exact positive-constancy implication for one chosen term. -/
def PositiveConstancyInstance {A : Type u} (zero : A) (succ : A → A)
    (f : A → A) : Prop :=
  (∀ n, f (succ (succ n)) = f (succ n)) →
  ∀ n, n = zero ∨ f n = f (succ zero)

/-- The only PC input here is the one parameter-free coverage term. -/
structure Core (A : Type u) where
  zero : A
  succ : A → A
  P : A → A → A
  B : A → A → A
  R : A → A → A
  pZero : ∀ a, P zero a = a
  pSucc : ∀ n a, P (succ n) a = n
  bZero : ∀ a, B zero a = a
  bSucc : ∀ n a, B (succ n) a = zero
  separated : zero ≠ succ zero
  pcCoverage : PositiveConstancyInstance zero succ (fun n => R n (succ (P n zero)))
  anchor : ∀ a, R zero a = a
  involution : ∀ x y, R (R x y) y = x

namespace Core
variable {A : Type u} (K : Core A)

def one : A := K.succ K.zero

def select (z u v : A) : A := K.P (K.B z (K.succ u)) v

/-- Column involution at x=0 forces the zero diagonal. -/
theorem diagonal (a : A) : K.R a a = K.zero := by
  calc
    K.R a a = K.R (K.R K.zero a) a :=
      congrArg (fun t => K.R t a) (K.anchor a).symm
    _ = K.zero := K.involution K.zero a

/-- This reflection proof requires no arithmetic induction or case split. -/
theorem reflects_equality (x y : A) : K.R x y = K.zero ↔ x = y := by
  constructor
  · intro h
    calc
      x = K.R (K.R x y) y := (K.involution x y).symm
      _ = K.R K.zero y := congrArg (fun t => K.R t y) h
      _ = y := K.anchor y
  · intro h
    subst y
    exact K.diagonal x

theorem successor_injective (x y : A) (h : K.succ x = K.succ y) : x = y := by
  have hp : K.P (K.succ x) K.zero = K.P (K.succ y) K.zero :=
    congrArg (fun t => K.P t K.zero) h
  rw [K.pSucc, K.pSucc] at hp
  exact hp

theorem successor_nonzero (x : A) : K.succ x ≠ K.zero := by
  intro h
  have hp : K.P (K.succ x) K.zero = K.P K.zero K.zero :=
    congrArg (fun t => K.P t K.zero) h
  rw [K.pSucc, K.pZero] at hp
  apply K.separated
  rw [hp] at h
  exact h.symm

/-- The coverage error is zero at every successor by computation. -/
theorem coverage_error_successor (n : A) :
    K.R (K.succ n) (K.succ (K.P (K.succ n) K.zero)) = K.zero := by
  rw [K.pSucc]
  exact K.diagonal (K.succ n)

/-- A single parameter-free PC instance supplies native constructor coverage. -/
theorem coverage (n : A) : n = K.zero ∨ n = K.succ (K.P n K.zero) := by
  have htail : ∀ k,
      K.R (K.succ (K.succ k)) (K.succ (K.P (K.succ (K.succ k)) K.zero)) =
      K.R (K.succ k) (K.succ (K.P (K.succ k) K.zero)) := by
    intro k
    rw [K.coverage_error_successor, K.coverage_error_successor]
  have h := K.pcCoverage htail n
  change n = K.zero ∨ K.R n (K.succ (K.P n K.zero)) =
    K.R (K.succ K.zero) (K.succ (K.P (K.succ K.zero) K.zero)) at h
  rw [K.coverage_error_successor] at h
  cases h with
  | inl hz => exact Or.inl hz
  | inr hr => exact Or.inr ((K.reflects_equality n (K.succ (K.P n K.zero))).mp hr)

theorem gate_alternative (n a : A) : n = K.zero ∨ K.B n a = K.zero := by
  cases K.coverage n with
  | inl hz => exact Or.inl hz
  | inr hs =>
      apply Or.inr
      calc
        K.B n a = K.B (K.succ (K.P n K.zero)) a := congrArg (fun t => K.B t a) hs
        _ = K.zero := K.bSucc (K.P n K.zero) a

theorem gate_nonzero (n a : A) (hn : n ≠ K.zero) : K.B n a = K.zero := by
  cases K.gate_alternative n a with
  | inl hz => exact False.elim (hn hz)
  | inr h => exact h

theorem gate_zero_seed (n : A) : K.B n K.zero = K.zero := by
  cases K.gate_alternative n K.zero with
  | inl hz => rw [hz, K.bZero]
  | inr h => exact h

theorem zero_decision (n : A) : n = K.zero ∨ n ≠ K.zero := by
  cases K.coverage n with
  | inl hz => exact Or.inl hz
  | inr hs =>
      apply Or.inr
      intro hz
      exact K.successor_nonzero (K.P n K.zero) (hs.symm.trans hz)

include K in
theorem equality_decision (x y : A) : x = y ∨ x ≠ y := by
  cases K.zero_decision (K.R x y) with
  | inl hz => exact Or.inl ((K.reflects_equality x y).mp hz)
  | inr hn =>
      exact Or.inr (fun h => hn ((K.reflects_equality x y).mpr h))

theorem select_zero (u v : A) : K.select K.zero u v = u := by
  unfold select
  rw [K.bZero, K.pSucc]

theorem select_nonzero (z u v : A) (hz : z ≠ K.zero) : K.select z u v = v := by
  unfold select
  rw [K.gate_nonzero z (K.succ u) hz, K.pZero]

theorem select_same (z u : A) : K.select z u u = u := by
  cases K.zero_decision z with
  | inl hz => rw [hz, K.select_zero]
  | inr hn => exact K.select_nonzero z u u hn

/-- Exactly the latch equations and one PC instance for its chosen term.
    A separate finite-description argument in the paper constructs this
    latch for each syntactic error term with its frozen parameter tuple. -/
theorem zero_test_induction (e q : A → A)
    (qZero : q K.zero = K.one)
    (qStep : ∀ n, q (K.succ n) = K.B (e n) (q n))
    (pcLatch : PositiveConstancyInstance K.zero K.succ q)
    (base : e K.zero = K.zero)
    (step : ∀ n, e n = K.zero → e (K.succ n) = K.zero) :
    ∀ n, e n = K.zero := by
  have qOne : q (K.succ K.zero) = K.one := by
    rw [qStep, base, K.bZero, qZero]
  have stationary : ∀ n, q (K.succ (K.succ n)) = q (K.succ n) := by
    intro n
    cases K.zero_decision (e n) with
    | inl hz => rw [qStep (K.succ n), step n hz, K.bZero]
    | inr hn =>
        have hq : q (K.succ n) = K.zero := by
          rw [qStep n, K.gate_nonzero (e n) (q n) hn]
        rw [qStep (K.succ n), hq, K.gate_zero_seed]
  have positive : ∀ n, q (K.succ n) = K.one := by
    intro n
    cases pcLatch stationary (K.succ n) with
    | inl hz => exact False.elim (K.successor_nonzero n hz)
    | inr h => exact h.trans qOne
  intro n
  cases K.zero_decision (e n) with
  | inl hz => exact hz
  | inr hn =>
      have hq : q (K.succ n) = K.zero := by
        rw [qStep n, K.gate_nonzero (e n) (q n) hn]
      exact False.elim (K.separated (hq.symm.trans (positive n)))

theorem and_error (a b : A) :
    K.select a b K.one = K.zero ↔ a = K.zero ∧ b = K.zero := by
  cases K.zero_decision a with
  | inl ha =>
      rw [ha, K.select_zero]
      constructor
      · intro hb
        exact ⟨rfl, hb⟩
      · intro h
        exact h.2
  | inr ha =>
      rw [K.select_nonzero a b K.one ha]
      constructor
      · intro h
        exact False.elim (K.separated h.symm)
      · intro h
        exact False.elim (ha h.1)

theorem or_error (a b : A) :
    K.select a K.zero b = K.zero ↔ a = K.zero ∨ b = K.zero := by
  cases K.zero_decision a with
  | inl ha =>
      rw [ha, K.select_zero]
      constructor
      · intro _
        exact Or.inl rfl
      · intro _
        rfl
  | inr ha =>
      rw [K.select_nonzero a K.zero b ha]
      constructor
      · intro hb
        exact Or.inr hb
      · intro h
        cases h with
        | inl h => exact False.elim (ha h)
        | inr h => exact h

theorem implication_error (a b : A) :
    K.select a b K.zero = K.zero ↔ (a = K.zero → b = K.zero) := by
  cases K.zero_decision a with
  | inl ha =>
      rw [ha, K.select_zero]
      constructor
      · intro hb _
        exact hb
      · intro h
        exact h rfl
  | inr ha =>
      rw [K.select_nonzero a b K.zero ha]
      constructor
      · intro _ h
        exact False.elim (ha h)
      · intro _
        rfl

end Core

/-- Finite formulas after term operands have been evaluated in the carrier. -/
inductive QF (A : Type u) where
  | atom : A → A → QF A
  | bot : QF A
  | top : QF A
  | conj : QF A → QF A → QF A
  | disj : QF A → QF A → QF A
  | impl : QF A → QF A → QF A

namespace QF
variable {A : Type u}

def holds : QF A → Prop
  | .atom s t => s = t
  | .bot => False
  | .top => True
  | .conj p q => holds p ∧ holds q
  | .disj p q => holds p ∨ holds q
  | .impl p q => holds p → holds q

def error (K : Core A) : QF A → A
  | .atom s t => K.R s t
  | .bot => K.one
  | .top => K.zero
  | .conj p q => K.select (error K p) (error K q) K.one
  | .disj p q => K.select (error K p) K.zero (error K q)
  | .impl p q => K.select (error K p) (error K q) K.zero

/-- Structural induction on finite formulas; not arithmetic induction. -/
theorem error_correct (K : Core A) (f : QF A) : error K f = K.zero ↔ holds f := by
  induction f with
  | atom s t => exact K.reflects_equality s t
  | bot =>
      constructor
      · intro h
        exact K.separated h.symm
      · intro h
        exact False.elim h
  | top =>
      constructor
      · intro _
        exact True.intro
      · intro _
        rfl
  | conj p q ip iq =>
      have hc := K.and_error (error K p) (error K q)
      constructor
      · intro h
        have hh := hc.mp h
        exact ⟨ip.mp hh.1, iq.mp hh.2⟩
      · intro h
        exact hc.mpr ⟨ip.mpr h.1, iq.mpr h.2⟩
  | disj p q ip iq =>
      have hc := K.or_error (error K p) (error K q)
      constructor
      · intro h
        cases hc.mp h with
        | inl h => exact Or.inl (ip.mp h)
        | inr h => exact Or.inr (iq.mp h)
      · intro h
        apply hc.mpr
        cases h with
        | inl h => exact Or.inl (ip.mpr h)
        | inr h => exact Or.inr (iq.mpr h)
  | impl p q ip iq =>
      have hc := K.implication_error (error K p) (error K q)
      constructor
      · intro h hp
        exact iq.mp ((hc.mp h) (ip.mpr hp))
      · intro h
        apply hc.mpr
        intro hp
        exact iq.mpr (h (ip.mp hp))

theorem decision (K : Core A) (f : QF A) : holds f ∨ ¬holds f := by
  cases K.zero_decision (error K f) with
  | inl h => exact Or.inl ((error_correct K f).mp h)
  | inr h => exact Or.inr (fun hf => h ((error_correct K f).mpr hf))

/-- Checks the final induction transfer for a supplied formula family and
    its one specified PR latch. It does not postulate existence of latches
    or PC for arbitrary semantic functions. -/
theorem induction_from_latch (K : Core A) (F : A → QF A) (q : A → A)
    (qZero : q K.zero = K.one)
    (qStep : ∀ n, q (K.succ n) = K.B (error K (F n)) (q n))
    (pcLatch : PositiveConstancyInstance K.zero K.succ q)
    (base : holds (F K.zero))
    (step : ∀ n, holds (F n) → holds (F (K.succ n))) :
    ∀ n, holds (F n) := by
  have hb : error K (F K.zero) = K.zero := (error_correct K _).mpr base
  have hs : ∀ n, error K (F n) = K.zero → error K (F (K.succ n)) = K.zero := by
    intro n hn
    exact (error_correct K _).mpr (step n ((error_correct K _).mp hn))
  have he := K.zero_test_induction (fun n => error K (F n)) q qZero qStep pcLatch hb hs
  intro n
  exact (error_correct K _).mp (he n)

end QF

#print axioms Core.diagonal
#print axioms Core.reflects_equality
#print axioms Core.successor_injective
#print axioms Core.successor_nonzero
#print axioms Core.coverage_error_successor
#print axioms Core.coverage
#print axioms Core.gate_alternative
#print axioms Core.gate_nonzero
#print axioms Core.gate_zero_seed
#print axioms Core.zero_decision
#print axioms Core.equality_decision
#print axioms Core.select_zero
#print axioms Core.select_nonzero
#print axioms Core.select_same
#print axioms Core.zero_test_induction
#print axioms Core.and_error
#print axioms Core.or_error
#print axioms Core.implication_error
#print axioms QF.error_correct
#print axioms QF.decision
#print axioms QF.induction_from_latch

end AnchoredInvolution
