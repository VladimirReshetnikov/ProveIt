FORMAL KERNEL: ANCHORED INVOLUTION
=================================

File: AnchoredInvolution.lean
Compiler: Lean 4.19.0 (no imports beyond Lean's implicit Init)
Run: lean AnchoredInvolution.lean
The verified output is retained in lean_check.log.

WHAT THE KERNEL CHECKS

The carrier A is arbitrary. The Core record supplies the computation
identities of the initialized predecessor P and zero gate B, separation
0 != S0, one coverage-term positive-constancy instance, and the two laws

  R(0,a) = a
  R(R(x,y),y) = x.

From the last two laws the file proves, without any arithmetic induction,
R(a,a)=0 and R(x,y)=0 iff x=y. It also proves successor injectivity and
nonzeroness. For c(n)=R(n,S(P(n,0))), computation makes c(Sn)=0.
The single PC instance for c therefore gives native constructor coverage
n=0 or n=S(P(n,0)). Coverage yields positive gate alternatives and zero
and native-equality decisions. The subsequent checked results are
the zero/nonzero selector equations, and zero-test induction from one
specified primitive-recursive latch and its own positive-constancy instance.

The finite QF datatype then checks the propositional error compiler for
native equality, falsity, truth, conjunction, disjunction, and implication.
Negation is implication to falsity. Atoms contain already evaluated carrier
values. Structural induction over this finite formula datatype is external
syntax induction; it does not assume induction for the arithmetic carrier.
The final theorem checks the transfer from the error latch to each formula
family to which the supplied latch equations and PC instance apply.

SCHEMA SCOPE AND LIMITS

PositiveConstancyInstance is a predicate describing ONE supplied instance.
There is no axiom saying that every semantic function is positive-constant.
Core.pcCoverage concerns only the one parameter-free syntactic term
R(n,S(P(n,0))). zero_test_induction and induction_from_latch additionally
receive the single PC instance for their specified q. Their arbitrary e,
F, and q parameters are parameters of conditional proof-checking theorems;
no postulate constructs latches for arbitrary set-theoretic functions.

The paper separately supplies finite-description construction of each latch
with its frozen parameter tuple, the designated R computation program,
proof that ordinary PRA proves the column-involution law, the treatment of
first-order quantifiers, the two interpretations, and both identity round
trips. This file does NOT claim to formalize those metatheoretic components
or the entire first-order derivability relation.

AXIOM AUDIT

All twenty-one printed endpoint audits say 'does not depend on any axioms'.
In particular the checked proofs use no sorryAx, Classical.choice,
propext, or quotient axiom. The explicit fields of Core and the explicit
latch premises remain mathematical hypotheses; an empty global-axiom list
does not remove or silently prove these hypotheses.
