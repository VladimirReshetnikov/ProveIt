#!/usr/bin/env python3
"""Rebuild the independently checked counts and the complete LaTeX paper."""
from pathlib import Path
import shutil
import subprocess
import sys


def main() -> None:
    root = Path(__file__).resolve().parent
    subprocess.run([sys.executable, "checks/verify.py"], cwd=root, check=True)
    latexmk = shutil.which("latexmk")
    if latexmk is None:
        raise SystemExit("latexmk is required; install the TeX dependencies in README.txt.")
    subprocess.run(
        [
            latexmk,
            "-pdf",
            "-interaction=nonstopmode",
            "-halt-on-error",
            "-outdir=build",
            "report.tex",
        ],
        cwd=root,
        check=True,
    )
    shutil.copy2(root / "build" / "report.pdf", root / "report.pdf")
    print("Built report.pdf.")


if __name__ == "__main__":
    main()
