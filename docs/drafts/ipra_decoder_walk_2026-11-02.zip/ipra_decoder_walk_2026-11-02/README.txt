A SMALLER AXIOMATIZATION OF INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov, 2 November 2026
=====================================================================

MAIN DELIVERABLE

report.pdf is the complete mathematical paper.
report.tex and sections/*.tex are its complete editable LaTeX sources.
AXIOMS.txt is the standalone exact specification of the optimized theory.

RESULT

The construction is for full first-order intuitionistic PRA, with
quantifier-free induction and every fixed finite tuple of parameters.
The paper proves whole-carrier bi-interpretability, internally identified
identity composites, and syntactic equiconsistency.

The main new arithmetic argument replaces the earlier clamped counter
by a decoder that either increments or resets to zero. A retained
induction base handles resets. This reduces the seven special arithmetic
seed equations, of total size 176, to two sentences of size 89 in the
four-place-chain presentation (88 in the three-place presentation).
The four-place diagonal boundary costs F+14.

Certified simplification of an update body h to g permits an explicit
recursor alias costing H+G+9. If g is the identity update v, the complete
recursion module costs H+7. There is an explicit infinite family with
unbounded savings over the best computation modules in the inspected
current drafts. Guarded folded recursion provides another improvement.

The recommended T34* presentation pays for both logical definitions so
its recurring computation envelope is no larger than the current
supported envelope. The one-connective T4* and T3* versions have smaller
fixed charges and the explicitly stated recurring tradeoffs.

SCOPE OF THE COMPARISON

The source comparison is pinned to ProveIt commit:
6f293758d174c06a313e3de5caa25a4c16ad392b

All five current and five archived proposals were inspected. All five
current packages improve some coordinate of the archived frontier.
See provenance/source_manifest.json and provenance/comparison.csv.
The comparison uses their fully charged, unshared syntax-tree convention.
It is not an absolute minimality theorem, a proof-length bound, or a
claim that every small finite proof packet is cheaper in the new format.

CONTENTS

  report.pdf                 Compiled paper
  report.tex                 Main LaTeX source
  sections/*.tex             Complete paper sections
  AXIOMS.txt                 Exact optimized axiom specification
  checks/verify.py           Newly written syntax/size checks and diagnostics
  checks/verification.json   Recorded checker results
  checks/reviewer_notes.txt  Mathematical proof-dependency review
  provenance/*.json,*.csv    Immutable source identities and comparisons
  build.py                   Rebuild checker output and PDF
  SHA256SUMS.txt              Integrity hashes for the included files

REBUILD

Requires Python 3.10+ and a TeX distribution with latexmk, pdfLaTeX,
amsmath, amssymb, amsthm, mathtools, lmodern, geometry, microtype,
booktabs, enumitem, needspace, xcolor, hyperref, and fancyhdr.

From this directory:
  python3 checks/verify.py
  python3 build.py

The checker requires only the Python standard library. The build script
does not download dependencies. It writes LaTeX intermediates into build/
and copies the compiled result to report.pdf.

VERIFICATION STATUS

The full theorem is established by the written constructive proof.
The Python artifact checks exact syntax, size formulas, frozen-variable
handling, normalization certificates, and finite numerical diagnostics.
It is not a full formalization of first-order derivations, the optimized
boundary generator, or bi-interpretability in Lean/Rocq.

LOGICAL INTERFACE

The main theories preserve ordinary logical falsity. The optional positive
core instead designates 0=S0 as absurdity and derives explosion.
Its exact proof translations are stated separately; its collapsed
singleton model is not misrepresented as an ordinary iPRA model.
