#!/usr/bin/env python3
"""Exact syntax checks and finite diagnostics for the decoder-walk iPRA paper.

This script is an independent, newly written artifact.  Its assertions check
finite syntax, exact sizes, rewriting traces, and bounded numerical examples.
They are NOT a formal verification of the infinite theory or bi-interpretation.
Run with Python 3.10 or newer; no third-party package is required.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import random
from typing import Mapping


@dataclass(frozen=True)
class Term:
    kind: str
    args: tuple["Term", ...] = ()
    name: str = ""


def var(name: str) -> Term:
    return Term("var", name=name)


ZERO = Term("zero")


def succ(term: Term) -> Term:
    return Term("succ", (term,))


def rec(body: Term, counter: Term, initial: Term) -> Term:
    """The first child is a frozen descriptor, not an active argument."""
    return Term("rec", (body, counter, initial))


V, W = var("v"), var("w")
A, N, U, X, Y, B, Z, R = (var(k) for k in "anuxybzr")
ONE = succ(ZERO)


@lru_cache(maxsize=None)
def size(term: Term) -> int:
    """Every descriptor is charged in full at EVERY recursor occurrence."""
    return 1 + sum(size(child) for child in term.args)


@lru_cache(maxsize=None)
def rank(term: Term) -> int:
    """Maximum function-symbol rank occurring in a term."""
    if term.kind == "rec":
        body, counter, initial = term.args
        return max(1 + rank(body), rank(counter), rank(initial))
    return max((rank(child) for child in term.args), default=0)


def function_rank(body: Term) -> int:
    return rank(body) + 1


def active_children(term: Term) -> tuple[Term, ...]:
    return term.args[1:] if term.kind == "rec" else term.args


def replace_active_children(term: Term, children: tuple[Term, ...]) -> Term:
    if term.kind == "rec":
        return rec(term.args[0], children[0], children[1])
    return Term(term.kind, children, term.name)


def substitute(term: Term, mapping: Mapping[str, Term]) -> Term:
    if term.kind == "var":
        return mapping.get(term.name, term)
    children = tuple(substitute(c, mapping) for c in active_children(term))
    return replace_active_children(term, children)


def active_count(term: Term, name: str) -> int:
    return int(term.kind == "var" and term.name == name) + sum(
        active_count(child, name) for child in active_children(term)
    )


def active_variables(term: Term) -> frozenset[str]:
    if term.kind == "var":
        return frozenset((term.name,))
    result: frozenset[str] = frozenset()
    for child in active_children(term):
        result |= active_variables(child)
    return result


def replace_successor_counter(term: Term, replacement: Term) -> Term:
    """Replace active literal S(w), never an occurrence inside a descriptor."""
    if term == succ(W):
        return replacement
    children = tuple(
        replace_successor_counter(c, replacement) for c in active_children(term)
    )
    return replace_active_children(term, children)


def successor_counter_count(term: Term) -> int:
    if term == succ(W):
        return 1
    return sum(successor_counter_count(c) for c in active_children(term))


def dagger(body: Term, state: Term, counter: Term, successor: Term) -> Term:
    """Simultaneous guarded substitution; an auxiliary slot avoids capture."""
    marker = var("__guarded_successor__")
    marked = replace_successor_counter(body, marker)
    return substitute(marked, {"v": state, "w": counter, marker.name: successor})


# The six earlier numerical descriptors.  These are terms, not extra symbols.
Q_BODY = W
Z_BODY = ZERO
ADD_BODY = succ(V)


def q(counter: Term, initial: Term) -> Term:
    return rec(Q_BODY, counter, initial)


def zrec(counter: Term, initial: Term) -> Term:
    return rec(Z_BODY, counter, initial)


def add(left: Term, right: Term) -> Term:
    return rec(ADD_BODY, right, left)


SUB_BODY = q(V, ZERO)


def sub(left: Term, right: Term) -> Term:
    return rec(SUB_BODY, right, left)


def pred(term: Term) -> Term:
    return q(term, ZERO)


def select(condition: Term, zero_value: Term, successor_value: Term) -> Term:
    return q(zrec(condition, succ(zero_value)), successor_value)


def error(left: Term, right: Term) -> Term:
    return q(sub(succ(left), right), ONE)


def equal_bit(left: Term, right: Term) -> Term:
    return zrec(error(left, right), ONE)


TRIANGLE_BODY = add(V, succ(W))


def triangle(term: Term) -> Term:
    return rec(TRIANGLE_BODY, term, ZERO)


INDEX_BODY = add(V, equal_bit(succ(W), triangle(succ(V))))


def index(term: Term) -> Term:
    return rec(INDEX_BODY, term, ZERO)


def pair(left: Term, right: Term) -> Term:
    return add(triangle(add(left, right)), right)


def delta(term: Term) -> Term:
    return sub(term, triangle(index(term)))


def first(term: Term) -> Term:
    return sub(index(term), delta(term))


@dataclass(frozen=True)
class Formula:
    kind: str
    args: tuple["Formula | Term", ...] = ()
    binder: str = ""


def eq(left: Term, right: Term) -> Formula:
    return Formula("eq", (left, right))


def connective(kind: str, *args: Formula) -> Formula:
    return Formula(kind, args)


def conj(left: Formula, right: Formula) -> Formula:
    return connective("and", left, right)


def disj(left: Formula, right: Formula) -> Formula:
    return connective("or", left, right)


def implies(left: Formula, right: Formula) -> Formula:
    return connective("implies", left, right)


def c3(a: Formula, b: Formula, c: Formula) -> Formula:
    return connective("C3", a, b, c)


def c4(a: Formula, b: Formula, c: Formula, d: Formula) -> Formula:
    return connective("C4", a, b, c, d)


def quantify(kind: str, variables: str, formula: Formula) -> Formula:
    for name in reversed(variables):
        formula = Formula(kind, (formula,), name)
    return formula


def all_(variables: str, formula: Formula) -> Formula:
    return quantify("forall", variables, formula)


def exists(variables: str, formula: Formula) -> Formula:
    return quantify("exists", variables, formula)


def formula_size(formula: Formula | Term) -> int:
    if isinstance(formula, Term):
        return size(formula)
    return 1 + sum(formula_size(child) for child in formula.args)


def ordinary(body: Term) -> tuple[Formula, Formula]:
    return (
        all_("a", eq(rec(body, ZERO, A), A)),
        all_("an", eq(rec(body, succ(N), A),
                      substitute(body, {"v": rec(body, N, A), "w": N}))),
    )


def graph3(body: Term) -> Formula:
    return all_("anu", c3(
        conj(eq(N, ZERO), eq(U, A)),
        eq(rec(body, N, A), U),
        eq(rec(body, succ(N), A), substitute(body, {"v": U, "w": N})),
    ))


def graph_plain(body: Term) -> Formula:
    return all_("anu", implies(
        eq(rec(body, N, A), U),
        conj(implies(eq(N, ZERO), eq(U, A)),
             eq(rec(body, succ(N), A), substitute(body, {"v": U, "w": N}))),
    ))


def table(body: Term, arity: int, guarded: bool = True) -> Formula:
    update = (dagger(body, U, N, X) if guarded
              else substitute(body, {"v": U, "w": N}))
    left = conj(eq(X, N), eq(Y, U))
    middle = eq(rec(body, X, A), Y)
    guard, value = eq(X, succ(N)), eq(Y, update)
    chain = (c3(left, middle, implies(guard, value)) if arity == 3
             else c4(left, middle, guard, value))
    return all_("an", exists("u", conj(
        implies(eq(N, ZERO), eq(U, A)), all_("xy", chain),
    )))


def folded(body: Term, guarded: bool = True) -> Formula:
    previous = rec(body, pred(N), A)
    update = (dagger(body, previous, pred(N), N) if guarded
              else substitute(body, {"v": previous, "w": pred(N)}))
    return all_("an", eq(rec(body, N, A), select(N, A, update)))


def state_free_folded(body: Term) -> Formula:
    assert active_count(body, "v") == 0
    update = dagger(body, ZERO, Z, N)
    return all_("anz", implies(
        eq(pred(N), Z), eq(rec(body, N, A), select(N, A, update)),
    ))


def alias(body: Term, normalized: Term) -> Formula:
    return all_("an", eq(rec(body, N, A), rec(normalized, N, A)))


def normalized_identity(body: Term) -> Formula:
    return all_("an", eq(rec(body, N, A), A))


def boundary(equation: Formula, arity: int) -> Formula:
    if arity == 3:
        matrix = c3(eq(succ(X), B), equation, implies(eq(X, B), eq(B, A)))
    else:
        matrix = c4(eq(succ(X), B), equation, eq(X, B), eq(B, A))
    return all_("a", exists("b", all_("x", matrix)))


def serialize(term: Term) -> str:
    if term.kind == "var":
        return term.name
    if term.kind == "zero":
        return "0"
    if term.kind == "succ":
        return "S(" + serialize(term.args[0]) + ")"
    body, counter, initial = term.args
    return "R[" + serialize(body) + "](" + serialize(counter) + "," + serialize(initial) + ")"


def normalize(body: Term) -> tuple[Term, list[dict[str, object]]]:
    """Two-rule normalization with independently replayable local certificates."""
    trace: list[dict[str, object]] = []

    def walk(term: Term, path: tuple[int, ...]) -> Term:
        children = tuple(walk(c, path + (i,)) for i, c in enumerate(active_children(term)))
        current = replace_active_children(term, children)
        if current.kind != "rec":
            return current
        descriptor, counter, initial = current.args
        if counter == ZERO:
            result, rule = initial, "initialized-base"
        elif descriptor == Q_BODY and counter.kind == "succ":
            result, rule = counter.args[0], "Q-successor"
        else:
            return current
        assert size(result) < size(current)
        trace.append({
            "path_in_active_tree": list(path),
            "rule": rule,
            "before": serialize(current),
            "after": serialize(result),
            "before_size": size(current),
            "after_size": size(result),
            "support_function_rank": function_rank(descriptor),
        })
        return result

    result = walk(body, ())
    assert active_variables(result) <= active_variables(body)
    assert function_rank(result) <= function_rank(body)
    for item in trace:
        assert item["support_function_rank"] < function_rank(body)
    if trace:
        assert size(result) < size(body)
    return result, trace


def metric_checks() -> dict[str, object]:
    helpers = [Q_BODY, Z_BODY, ADD_BODY, SUB_BODY, TRIANGLE_BODY, INDEX_BODY]
    assert [size(t) for t in helpers] == [1, 1, 2, 4, 6, 30]
    inverse3 = all_("axr", c3(
        eq(A, add(R, X)), eq(sub(A, X), R), disj(eq(R, ZERO), eq(add(X, R), A)),
    ))
    inverse4 = all_("axrz", c4(
        eq(A, add(R, X)), eq(sub(A, X), R), eq(R, succ(Z)), eq(add(X, R), A),
    ))
    pair_identity = all_("an", eq(index(pair(A, N)), add(A, N)))
    invariant = eq(X, add(triangle(index(X)), delta(X)))
    separation = implies(eq(ZERO, ONE), Formula("bottom"))
    coverage = all_("z", exists("y", disj(eq(Z, ZERO), eq(Z, succ(Y)))))
    assert formula_size(separation) == 6
    assert formula_size(coverage) == 10
    old = [
        eq(add(succ(A), X), succ(add(A, X))),
        eq(sub(succ(A), succ(X)), sub(A, X)),
        eq(sub(add(A, X), X), A),
        eq(sub(add(X, A), X), A),
        eq(sub(A, add(X, A)), ZERO),
        eq(select(sub(A, X), A, add(X, sub(A, X))), A),
        eq(zrec(sub(X, A), error(index(add(triangle(A), X)), A)), ZERO),
    ]
    old_sizes = [formula_size(e) for e in old]
    assert old_sizes == [13, 17, 13, 13, 13, 26, 67]
    assert sum(formula_size(all_("ax", e)) for e in old) == 176
    assert formula_size(inverse3) == 31
    assert formula_size(inverse4) == 32
    assert formula_size(pair_identity) == 57
    assert size(delta(X)) == 47
    assert size(first(X)) == 85
    assert formula_size(invariant) == 93
    for equation in old + [invariant, eq(X, A), eq(X, X)]:
        f = formula_size(equation)
        assert formula_size(boundary(equation, 3)) == f + 15
        assert formula_size(boundary(equation, 4)) == f + 14

    # Regression: a normalized defining RHS need not be literally the raw RHS.
    # Expanding the left side is disallowed here because it would INCREASE size.
    regression_body = zrec(ZERO, succ(V))
    regression_previous = rec(regression_body, X, A)
    regression_left = rec(regression_body, succ(X), A)
    regression_right = succ(regression_previous)
    regression_raw_rhs = substitute(
        regression_body, {"v": regression_previous, "w": X}
    )
    regression_normal_rhs, regression_trace = normalize(regression_raw_rhs)
    assert size(regression_body) == 5
    assert size(regression_left) == 9
    assert size(regression_raw_rhs) == 12
    assert size(regression_raw_rhs) > size(regression_left)
    assert regression_raw_rhs != regression_right
    assert regression_normal_rhs == regression_right
    assert formula_size(eq(regression_left, regression_right)) == 19
    assert len(regression_trace) == 1

    samples = [V, W, ZERO, succ(V), succ(W), SUB_BODY, TRIANGLE_BODY, INDEX_BODY]
    samples += [q(succ(V), ZERO), q(succ(W), V), add(succ(W), W)]
    rng = random.Random(20261102)
    for _ in range(90):
        chosen = rng.choice(samples[-20:])
        form = rng.randrange(5)
        if form == 0:
            term = succ(chosen)
        elif form == 1:
            term = q(succ(chosen), rng.choice([V, W, ZERO]))
        elif form == 2:
            term = rec(rng.choice(helpers[:4]), ZERO, chosen)
        elif form == 3:
            term = add(chosen, rng.choice([V, W, succ(W)]))
        else:
            term = rec(rng.choice(helpers[:4]), chosen, rng.choice([V, W, ZERO]))
        samples.append(term)

    state_free_count = 0
    rewrite_count = 0
    for body in samples:
        h = size(body)
        k = active_count(body, "v")
        ell = active_count(body, "w")
        j = successor_counter_count(body)
        remaining = active_count(replace_successor_counter(body, var("guard")), "w")
        assert ell == j + remaining
        assert size(dagger(body, U, N, X)) == h - j
        assert sum(formula_size(f) for f in ordinary(body)) == 3*h + 13 + k*(h+2)
        assert formula_size(graph3(body)) == 3*h + 21
        assert formula_size(graph_plain(body)) == 3*h + 22
        assert formula_size(table(body, 3)) == 2*h - j + 33
        assert formula_size(table(body, 4)) == 2*h - j + 32
        assert formula_size(table(body, 3, False)) == 2*h + 33
        assert formula_size(table(body, 4, False)) == 2*h + 32
        assert formula_size(folded(body)) == (k+2)*h + 13 + 5*k + 3*ell - 4*j
        assert formula_size(folded(body, False)) == (k+2)*h + 13 + 5*k + 3*ell
        if k == 0:
            assert formula_size(state_free_folded(body)) == 2*h - j + 21
            state_free_count += 1
        normalized, trace = normalize(body)
        assert formula_size(alias(body, normalized)) == h + size(normalized) + 9
        assert formula_size(normalized_identity(body)) == h + 7
        rewrite_count += len(trace)

        # A substitution changes only active arguments of a recursor application.
        application = rec(body, V, W)
        changed = substitute(application, {"v": succ(N), "w": ZERO})
        assert changed.args[0] is body
        assert changed.args[1:] == (succ(N), ZERO)
        assert active_count(application, "v") == 1
        assert active_count(application, "w") == 1

    return {
        "descriptor_sizes": dict(zip(["Q", "Z", "A", "D", "U", "V"],
                                     [size(t) for t in helpers])),
        "inverse_C3": formula_size(inverse3),
        "inverse_C4": formula_size(inverse4),
        "pair_identity": formula_size(pair_identity),
        "fixed_arithmetic": {"separation": 6, "coverage": 10},
        "logical_definition_records": {"C3": 12, "C4": 15},
        "finite_seed_and_fixed_totals": {"old_D7_C3": 204,
                                         "new_C3": 116, "new_C4": 120,
                                         "new_C34": 131},
        "delta_term": size(delta(X)),
        "first_projection_term": size(first(X)),
        "walk_invariant_equation": formula_size(invariant),
        "old_seven_equation_sizes": old_sizes,
        "old_seven_universal_total": 176,
        "diagonal_overheads": {"C3": 15, "C4": 14},
        "samples_checked": len(samples),
        "state_free_samples_checked": state_free_count,
        "certified_local_rewrites": rewrite_count,
        "normalized_step_regression": {
            "body": serialize(regression_body),
            "body_size": 5,
            "left": serialize(regression_left),
            "left_size": 9,
            "raw_defining_rhs": serialize(regression_raw_rhs),
            "raw_rhs_size": 12,
            "normalized_rhs": serialize(regression_normal_rhs),
            "equation_size": 19,
            "left_expansion_is_shrinking": False,
            "normalized_rhs_matches": True,
            "certificate": regression_trace,
            "scope": "One normalized defining-equation regression, not the full generator.",
        },
        "checks": ["frozen descriptors", "active substitution", "module sizes",
                   "guarded substitution", "rank decrease", "strict size decrease",
                   "normalized defining-step recognition regression"],
    }


def infinite_family_checks() -> dict[str, object]:
    body = V
    rows: list[dict[str, int]] = []
    certificate: dict[str, object] = {}
    for m in range(21):
        if m:
            body = q(succ(body), ZERO)
        assert size(body) == 4*m + 1
        assert active_count(body, "v") == 1
        assert active_count(body, "w") == 0
        normalized, trace = normalize(body)
        assert normalized == V
        assert len(trace) == m
        if m == 0:
            continue  # Literal v already has the old eight-node identity module.
        h = size(body)
        d = 3*h + 13 + (h+2)
        g = 3*h + 21
        t = 2*h + 32  # Best old table across the supported logical bases.
        p = 3*h + 18
        old = min(d, g, t, p)
        new = formula_size(normalized_identity(body))
        assert new == 4*m + 8
        assert new < old
        if m >= 4:
            assert old == 8*m + 34
            assert old - new == 4*m + 26
        if m in (1, 2, 3, 4, 5, 10, 20):
            rows.append({"m": m, "H": h, "old_envelope": old,
                         "new_identity": new, "saving": old-new})
        if m == 4:
            certificate = {
                "input": serialize(body), "output": serialize(normalized),
                "input_function_rank": function_rank(body),
                "output_function_rank": function_rank(normalized), "steps": trace,
            }
    expected = {4: (66, 24), 10: (114, 48), 20: (194, 88)}
    for row in rows:
        if row["m"] in expected:
            assert (row["old_envelope"], row["new_identity"]) == expected[row["m"]]
    return {
        "definition": "h_0=v; h_(m+1)=Q(S(h_m),0)",
        "descriptor_size": "4m+1",
        "new_identity_size": "4m+8",
        "old_envelope_for_m_ge_4": "8m+34",
        "saving_for_m_ge_4": "4m+26",
        "rows": rows,
        "m4_normalization_certificate": certificate,
        "interpretation": "The symbolic general theorem is proved in the paper.",
    }


def numerical_diagnostics() -> dict[str, object]:
    """Finite standard-number diagnostics, intentionally separate from syntax."""
    def tri(n: int) -> int:
        result = 0
        for counter in range(n):
            result += counter + 1
        return result

    def eq_bit(left: int, right: int) -> int:
        residual = max(left + 1 - right, 0)
        error_value = 1 if residual == 0 else residual - 1
        return int(error_value == 0)

    limit = 1000
    indices = [0]
    for counter in range(limit):
        previous = indices[-1]
        indices.append(previous + eq_bit(counter+1, tri(previous+1)))
    deltas = [max(n-tri(indices[n]), 0) for n in range(limit+1)]
    for n in range(limit+1):
        assert n == tri(indices[n]) + deltas[n]
        if n < limit:
            assert deltas[n+1] in (0, deltas[n]+1)
    pair_cases = 0
    for a in range(20):
        for n in range(20):
            code = tri(a+n)+n
            assert indices[code] == a+n
            assert deltas[code] == n
            assert max(indices[code]-deltas[code], 0) == a
            pair_cases += 1

    # Every Boolean predicate on the finite prefix, not merely random patterns.
    scan_cases = 0
    prefix = 9
    for bits in range(1 << prefix):
        truth = [bool(bits & (1 << j)) for j in range(prefix)]
        boundary_value = 0
        for target in range(prefix):
            if target and truth[boundary_value]:
                boundary_value = target
            b = boundary_value
            assert 0 <= b <= target
            assert not truth[b] or b == target
            assert b == 0 or truth[b-1]
            for x in range(prefix):
                assert x+1 != b or truth[x]
                assert not (truth[x] and x == b) or b == target
            scan_cases += 1

    # Check both new folded formulas for representative finite update programs.
    updates = [lambda v, w: v+w+1, lambda v, w: w,
               lambda v, w: w+1, lambda v, w: v, lambda v, w: 0]
    folded_cases = 0
    for update in updates:
        for initial in range(6):
            values = [initial]
            for counter in range(12):
                values.append(update(values[-1], counter))
            for n in range(13):
                p = max(n-1, 0)
                right = initial if n == 0 else update(values[p], p)
                assert values[n] == right
                folded_cases += 1
    return {
        "status": "Finite diagnostics only; not a proof of the infinite theory.",
        "walk_arguments_checked": limit+1,
        "pair_retraction_cases": pair_cases,
        "boolean_scan_prefix_length": prefix,
        "boolean_predicates_exhausted": 1 << prefix,
        "scan_boundary_cases": scan_cases,
        "folded_recursion_cases": folded_cases,
    }


def main() -> None:
    report = {
        "status": "passed",
        "scope": "Exact finite syntax checks and bounded standard-number diagnostics.",
        "not_claimed": "Machine-checked proof of iPRA bi-interpretability or minimality.",
        "metrics": metric_checks(),
        "infinite_family": infinite_family_checks(),
        "numerical_diagnostics": numerical_diagnostics(),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    destination = Path(__file__).with_name("verification.json")
    destination.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print("PASS: exact syntax and metric checks; finite diagnostics.")
    print("Report:", destination)
    print("No full formal verification is claimed.")


if __name__ == "__main__":
    main()
