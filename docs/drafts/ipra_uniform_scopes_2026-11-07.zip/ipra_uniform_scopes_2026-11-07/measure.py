#!/usr/bin/env python3
"""Reproduce complete-source measurements using the unchanged inherited metric."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import tempfile

ROOT = Path(__file__).resolve().parent
FIELDS = ('source_tokens', 'normalized_tokens', 'ast_nodes', 'normalized_bytes', 'raw_bytes')
NORMAL = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
spec = importlib.util.spec_from_file_location('inherited_measure', ROOT / 'comparison/source_measure.py')
metric = importlib.util.module_from_spec(spec)
spec.loader.exec_module(metric)


def envelope(rows, fields=NORMAL):
    return {key: min(row[key] for row in rows) for key in fields}


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    rows = []
    for entry in manifest['programs']:
        path = ROOT / 'comparison' / entry['local_file']
        measured = metric.metrics(path)
        if measured['sha256'] != entry['sha256']:
            raise ValueError('Changed comparator: ' + entry['local_file'])
        rows.append({**entry, **{key: value for key, value in measured.items() if key != 'core'}})
    candidates = []
    for name in ('checker.py', 'checker_direct.py'):
        path = ROOT / name
        if path.exists():
            measured = metric.metrics(path)
            candidates.append({'file': name, **{k: v for k, v in measured.items() if k != 'core'}})

    expanded_manifest = json.loads((ROOT / 'comparison/expanded_manifest.json').read_text())
    expanded = []
    for entry in expanded_manifest['sources']:
        path = ROOT / 'comparison' / entry['local_file']
        row = metric.metrics(path)
        if row['sha256'] != entry['sha256']:
            raise ValueError('Changed expanded source: ' + entry['local_file'])
        expanded.append({key: row[key] for key in (*NORMAL, 'sha256')})

    conventional = ROOT / 'comparison/current/ipra_truth_completion_2026-11-07__checker_scalar.py'
    tree = ast.parse(conventional.read_text())
    start = next(i for i, node in enumerate(tree.body) if isinstance(node, ast.Try))
    driver = tree.body[start:]
    controls = []
    with tempfile.TemporaryDirectory() as tmp:
        target = Path(tmp) / 'control.py'
        for entry in rows + candidates:
            path = ROOT / entry['file'] if 'file' in entry else ROOT / 'comparison' / entry['local_file']
            source = ast.parse(path.read_text())
            start = next(i for i, node in enumerate(source.body) if isinstance(node, ast.Try))
            source.body = source.body[:start] + copy.deepcopy(driver)
            target.write_text(ast.unparse(source) + '\n')
            row = metric.metrics(target)
            controls.append({'label': entry.get('file', entry.get('label')),
                             **{key: row[key] for key in NORMAL}})

        # Orthogonal ablations of the two new representation changes.
        source = (ROOT / 'checker.py').read_text()
        uniform = "(0, b'\\2', (b'\\1\\1', 0)[d % 2], b'\\4\\4\\4')[len(a)]"
        original = "(0, 0, b'\\2', b'\\0', b'\\1\\1', 0, b'\\4\\4\\4', b'\\0\\0\\2')[len(a) * 2 + d % 2]"
        if uniform not in source:
            raise ValueError('Expected uniform scope table not found')
        arity_first = source[source.index('    try:\n'):source.index('\n\n\ndef check')]
        traversal = arity_first.splitlines()[1].strip()
        typed = ('    if isinstance(a, int):\n'
                 '        return a if k <= a < d else inst(t, d=1)\n'
                 '    ' + traversal)
        ablations = []
        for label, variant in (
            ('compatible inherited combination', source.replace(arity_first, typed).replace(uniform, original)),
            ('uniform scopes only', source.replace(arity_first, typed)),
            ('arity-first opening only', source.replace(uniform, original)),
            ('both changes', source),
        ):
            target.write_text(variant)
            row = metric.metrics(target)
            ablations.append({'label': label, **{key: row[key] for key in NORMAL}})

    current_minimum = envelope(rows, FIELDS)
    common_minimum = envelope(controls[:len(rows)])
    result = {
        'python': platform.python_version(), 'implementation': platform.python_implementation(),
        'repository': manifest['repository'], 'commit': manifest['commit'],
        'archive_count': len(manifest['archives']), 'root_program_count': len(rows),
        'normalizer_sha256': hashlib.sha256((ROOT / 'comparison/source_measure.py').read_bytes()).hexdigest(),
        'coordinatewise_minimum': current_minimum, 'current_programs': rows,
        'candidates': candidates,
        'common_driver': {'source': str(conventional.relative_to(ROOT)),
                          'minimum': common_minimum, 'programs': controls},
        'expanded_inventory': {'path_count': expanded_manifest['path_count'],
                               'unique_count': len(expanded),
                               'minimum': envelope(expanded), 'sources': expanded},
        'ablations': ablations,
    }
    for candidate in candidates:
        if not all(candidate[key] < current_minimum[key] for key in NORMAL):
            raise ValueError('Candidate fails strict current comparison: ' + candidate['file'])
    for candidate in controls[len(rows):]:
        if not all(candidate[key] < common_minimum[key] for key in NORMAL):
            raise ValueError('Candidate fails common-driver comparison: ' + candidate['label'])
    (ROOT / 'results/measurements.json').write_text(json.dumps(result, indent=2) + '\n')
    scalar = next(row for row in candidates if row['file'] == 'checker.py')
    macros = { 'NewTokens': scalar['normalized_tokens'], 'NewAST': scalar['ast_nodes'],
               'NewBytes': scalar['normalized_bytes'], 'ExpandedPaths': expanded_manifest['path_count'],
               'ExpandedUnique': len(expanded) }
    for row in candidates:
        if row['file'] == 'checker_direct.py':
            macros.update({'DirectTokens': row['normalized_tokens'], 'DirectAST': row['ast_nodes'],
                           'DirectBytes': row['normalized_bytes']})
    (ROOT / 'results/macros.tex').write_text('\n'.join(
        '\\newcommand{\\' + key + '}{' + format(value, ',') + '}' for key, value in macros.items()) + '\n')

    def table(filename, headings, values):
        lines = [r'\begin{center}', r'\begin{tabular}{@{}l' + 'r' * (len(headings)-1) + r'@{}}',
                 r'\toprule', ' & '.join(headings) + r'\\', r'\midrule']
        for row in values:
            lines.append(' & '.join(str(x) if isinstance(x, str) else format(x, ',') for x in row) + r'\\')
        lines += [r'\bottomrule', r'\end{tabular}', r'\end{center}']
        (ROOT / 'results' / filename).write_text('\n'.join(lines) + '\n')

    display = [('Current coordinatewise minimum', current_minimum)]
    display += [('New scalar checker' if row['file']=='checker.py' else 'New direct checker', row) for row in candidates]
    table('main_table.tex', ['Complete source', 'Tokens', 'AST nodes', 'Norm. bytes'],
          [[label] + [row[key] for key in NORMAL] for label, row in display])
    common_display = [('Current coordinatewise minimum', common_minimum)] + [
        ('New scalar checker' if row['label']=='checker.py' else 'New direct checker', row)
        for row in controls[len(rows):]]
    table('common_table.tex', ['Identical conventional driver', 'Tokens', 'AST nodes', 'Norm. bytes'],
          [[label] + [row[key] for key in NORMAL] for label, row in common_display])
    table('ablation_table.tex', ['Scalar variant', 'Tokens', 'AST nodes', 'Norm. bytes'],
          [[row['label']] + [row[key] for key in NORMAL] for row in ablations])
    table('current_table.tex', ['Current archive / checker', 'Tokens', 'AST nodes', 'Norm. bytes'],
          [[row['label'].replace('ipra_', '').replace('_2026-11-07', '').replace('_', r'\_')]
           + [row[key] for key in NORMAL] for row in rows])
    print(json.dumps({'status': 'PASS', 'python': result['python'], 'current_minimum': current_minimum,
                      'candidates': candidates, 'common_minimum': common_minimum,
                      'expanded': {k:v for k,v in result['expanded_inventory'].items() if k != 'sources'},
                      'ablations': ablations}, indent=2))


if __name__ == '__main__':
    main()
