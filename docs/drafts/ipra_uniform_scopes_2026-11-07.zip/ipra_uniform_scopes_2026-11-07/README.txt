UNIFORM SCOPES: A SMALLER COMPLETE PRESENTATION OF iPRA
Prepared for Vladimir Reshetnikov, 7 November 2026
====================================================

START HERE

report.pdf is the complete mathematical paper. report.tex, foundation/,
sections/, and generated results/*.tex are its editable LaTeX source.
The archive is self-contained and can be reproduced without network access.

RESULT

Both complete standalone checkers are below the actual current frontier
of the six supplied ProveIt archives at commit
ea1bd900ee0c8b3d4d108cfc3deb176bab9a039a.

                               normalized tokens   AST nodes   norm. bytes
Current nine root checkers:                  367         392          1076
checker.py (scalar iteration):               356         378          1038
checker_direct.py (full recursion):          363         384          1050

With an identical conventional input/output driver:
Current coordinatewise minimum:              369         395          1105
Scalar:                                     360         383          1075
Direct:                                     367         389          1087

The inherited metric removes genuine docstrings, then uses ast.unparse.
The recorded runtime is CPython 3.12.14. Raw source sizes are recorded
separately; explanatory comments/docstrings are not a raw-byte improvement
claim. Every project-specific trusted operation is in the counted file.

The new representation pads numerical binding scopes with zero-valued
dummy slots. Unary and ternary nodes can then share their scope rows with
logical binders. The scalar update uses two aliases of its previous state;
the direct update uses a distinct previous state and previous counter.
Arity-first opening additionally replaces a scalar type test with a
conservative interval-coordinate interpretation. The report proves the
scope-erasure and capture-avoidance obligations for all accepted packets.

The arithmetic and five-pattern logical basis are inherited and credited.
The paper states all primitive schemas and rules, reconstructs full
intuitionistic first-order logic, and proves whole-domain bi-interpretability
with iPRA. Both composite isomorphisms are internally given by x = y.

There is also a new shorter scalar predecessor proof: after the inherited
comparator, two equation inductions replace the older saturation family
and several intermediate lemmas. The direct companion has an immediate
predecessor and a much shorter arithmetic reconstruction. It is useful when
the simplicity of the mathematical proof matters more than seven extra
normalized checker tokens.

These are finite-corpus, fixed-measure improvements and explicit written
mathematical proofs. Absolute shortestness and a new arithmetic axiom basis
are not established. There is no Lean/Rocq formalization of the full metatheory.

RUN A CHECKER

  python3 checker.py examples/zero.json

See examples/index.json for scalar examples and examples/direct_index.json
for direct examples and their expected verdicts. Each program prints ACCEPT
and exits 0, or prints REJECT and exits 1. The same contract holds with -O.
Use Python 3.10 or later. No nonstandard Python package is required.

The two programs have different numerical meanings for the two update slots;
do not blindly interchange their proof packets. Canonical translated fixtures
are separated by arithmetic profile. FORMAT.txt and the paper give the raw
syntax, scope conventions, instruction semantics, and public trust boundary.

REPRODUCE

  python3 reproduce.py
  python3 build.py

The first command reruns all reported source measurements and verification
programs using the standard library. Exact source metrics should be compared
under the same Python version. The second requires pdfLaTeX and the packages
declared in report.tex. It refreshes tables and checks final compilation logs
for unresolved references and overfull boxes.

The main individual entry points are:

  python3 measure.py
  python3 validation/validate.py
  python3 validation/direct_validate.py
  python3 validation/independent/audit_uniform_semantics.py
  python3 validation/check_predecessor_shift.py
  python3 validation/predecessor/check_conditional.py
  python3 evidence.py

The last script checks exact source-hash agreement between measurements and
validation. All finite-test results are recorded separately; overlapping
populations are not summed as independent theorems.

CONDITIONAL CERTIFICATE LIMIT

validation/predecessor/ contains a native derivation of the shifted-iterate
lemma under three explicitly declared conjugacy assumptions. It checks all
38 instruction cells using a frozen supplied scalar kernel. It does not
prove those assumptions or claim a closed public-driver predecessor theorem.
Its receipt records hypotheses_proved=false. The complete mathematical
derivations are in the paper. The 239 finite numerical identity checks are
additional evidence, not a replacement for the universal proofs.

CONTENTS

  report.tex / report.pdf        Full paper and compiled PDF
  foundation/ / sections/        Complete mathematical development
  checker.py                    Entire trusted scalar acceptance program
  checker_direct.py             Entire trusted direct acceptance program
  FORMAT.txt                    Raw syntax and certificate contract
  examples/                     Runnable positive and negative proof packets
  validation/                   Independent oracles, fixtures, finite evidence
  results/                      Exact metrics, hashes, test and build receipts
  comparison/current/           Nine byte-for-byte current comparator sources
  comparison/expanded/          Broader heuristic inventory, with provenance
  comparison/source_measure.py  Unchanged inherited source metric
  source_snapshot.json          Pinned archive paths, sizes, Git and SHA hashes
  reproduce.py / build.py        Offline reproduction and PDF build
  evidence.py / measure.py       Evidence linkage and comparison entry points
  package.py / SHA256SUMS.txt    Repackaging and integrity data
  ATTRIBUTION.txt                Inherited/new contribution boundaries
  LICENSE-inherited.txt          Preserved MIT-0 source/documentation license

No ProveIt repository change or publication is needed to use the deliverable.

