#!/usr/bin/env python3
"""Check a declared-context native derivation using a frozen supplied kernel.

This validation harness is untrusted and is never imported by the production
checker. It transparently loads all top-level definitions preceding the frozen
checker's public driver, without rewriting any function, then invokes check
with the explicitly supplied hypotheses and parameter floor. It does not
establish those hypotheses or claim to check a closed theorem packet.
"""

import ast
import copy
import hashlib
import json
from pathlib import Path
import types

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
CHECKER_RELATIVE = 'comparison/current/ipra_direct_kernel_2026-11-07__checker_scalar.py'
CHECKER_SHA256 = '356b52502563e0843e11d68d1d1b5e8bab3273573c05d76d5806c816808c62bc'


def main():
    source = ROOT / CHECKER_RELATIVE
    raw_source = source.read_bytes()
    observed_hash = hashlib.sha256(raw_source).hexdigest()
    if observed_hash != CHECKER_SHA256:
        raise ValueError('frozen checker hash does not match the audited source')

    syntax = ast.parse(raw_source, filename=str(source))
    prefix = []
    for node in syntax.body:
        if isinstance(node, ast.Try):
            break
        prefix.append(node)
    module = types.ModuleType('unchanged_frozen_scalar_kernel')
    exec(compile(ast.Module(body=prefix, type_ignores=[]), str(source), 'exec'), module.__dict__)

    certificate_path = HERE / 'conditional_certificate.json'
    certificate = json.loads(certificate_path.read_text())
    if certificate['kind'] != 'conditional_native_derivation':
        raise ValueError('unexpected certificate kind')
    if certificate['initial_parameter_floor'] != -2:
        raise ValueError('expected exactly the two declared parameters m and t')
    if certificate['parameters'] != {'-1': 'm', '-2': 't'}:
        raise ValueError('parameter convention differs from the stated lemma')
    if len(certificate['context']) != 3:
        raise ValueError('expected the three explicitly declared assumptions')

    module.k = -2
    context = copy.deepcopy(certificate['context'])
    for formula in context:
        if module.inst(formula) != formula:
            raise ValueError('ill-formed declared context')
    stack = copy.deepcopy(certificate['packet'])
    goal = stack.pop()
    module.take = stack.pop
    accepted = bool(module.check(goal, context))
    if not accepted or stack:
        raise ValueError(('native conditional derivation failed', accepted, len(stack)))

    receipt = {
        'status': 'PASS',
        'kind': 'conditional_native_derivation',
        'claim': certificate['claim'],
        'checker': CHECKER_RELATIVE,
        'checker_sha256': observed_hash,
        'certificate': 'validation/predecessor/conditional_certificate.json',
        'certificate_sha256': hashlib.sha256(certificate_path.read_bytes()).hexdigest(),
        'certificate_bytes': certificate_path.stat().st_size,
        'instruction_cells': len(certificate['packet']) - 1,
        'remaining_cells': len(stack),
        'initial_parameter_floor': -2,
        'final_parameter_floor': module.k,
        'context_assumptions': certificate['context_descriptions'],
        'hypotheses_proved': False,
        'closed_public_driver_theorem': False,
    }
    (HERE / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
