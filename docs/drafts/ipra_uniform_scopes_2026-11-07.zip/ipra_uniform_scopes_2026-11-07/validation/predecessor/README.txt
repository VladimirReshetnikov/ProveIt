CONDITIONAL NATIVE CERTIFICATE FOR THE PREDECESSOR PROOF
=====================================================

What is checked
---------------
The native scalar-iterator checker validates the derivation

    V(S t, S S m) = S V(t, S m)

under exactly three declared assumptions:

  1. A_(S S m)(0) = S 0;
  2. A_(S S m)(S 0) = S A_(S m)(0);
  3. Q_u [A_(S S m)(S u) = S A_(S m)(u)].

Here Q_u B(u) has the native meaning B(0) -> forall u B(u). Thus assumptions
2 and 3 together supply the pointwise successor-conjugacy equation. These
are the assumptions proved in the paper's shifted-conjugacy lemma. They are
NOT proved by this certificate.

The update and iterator are the actual finite scalar terms from the paper:

    A_m(u) = C(L(S S u,m),u,S u)
    V(t,m) = I(t,0; u.A_m(u)).

C and L are fully expanded inside the certificate into 0, successor and
scalar iteration, including the inherited comparator construction. There
are no assumed function constants, numerical evaluation oracle or extra
inference rules in the certificate.

Parameter and context convention
-------------------------------
The two initially declared rigid numerical parameters are -1 for m and -2
for t. The initial parameter floor is therefore k=-2. The equation-induction
step allocates -3 as its fresh counter. The context is explicitly stored in
conditional_certificate.json and is validated at floor -2 before checking.

The certificate has 38 instruction cells, all consumed. Its derivation uses
the scalar computation equations, equality transport, hypothesis use, closure
elimination, and equation-induction closure introduction. It changes no
assumption during an active fixed-parameter induction.

How to reproduce
----------------
From the package root, run:

    python3 validation/predecessor/check_conditional.py

The script verifies the frozen checker's SHA-256 hash, parses it with Python's
ast module, and executes its unchanged imports, constants and function
definitions preceding the public file driver. It then invokes the unchanged
check(goal,context) function with the explicitly declared floor and context.
The resulting receipt.json records the checked source and certificate hashes.
No external work directory, network access, or unfrozen reference is needed.

Scope of the evidence
---------------------
This is a checked CONDITIONAL derivation. It is not an accepted closed packet
under the public driver's empty-context interface, a mechanization of the
comparator construction, or a formal verification of the full predecessor
theorem. The receipt deliberately records hypotheses_proved=false and
closed_public_driver_theorem=false. The paper supplies the missing ordinary
mathematical derivations from the three comparator equations and explains the
final diagonal substitution and equation induction proving P(Sm)=m.

The proof was assembled by an untrusted producer adapted from the supplied
direct-kernel archive's validation/generate_cases.py, with a new named term
encoder and the new V-shift proof. Checking depends solely on the frozen
checker functions and the declared context, not on the producer.
