#!/usr/bin/env python3
"""Finite evidence for the new scalar predecessor proof.

All numerical operations below implement the stated 0/S/I terms.
Orbit caches only reuse values computed by the two scalar-iteration
equations. No predecessor, subtraction, order test, integer division,
modulo, or exponentiation implements L or P. Python ranges select finite
test domains, not object-theory inference. Passing these tests is not a
formal proof of the identities or of the mathematical interpretation.
"""

import json
from pathlib import Path


def S(n):
    return n + 1


def I(n, a, h):
    for _ in range(n):
        a = h(a)
    return a


def C(n, a, b):
    return I(n, a, lambda _: b)


def plus(a, b):
    return I(b, a, S)


def Z(n):
    return C(n, 1, 0)


class Orbit:
    """A fixed initializer and fixed update, cached by scalar counter."""

    def __init__(self, a, h):
        self.values = [a]
        self.h = h

    def __call__(self, n):
        while len(self.values) <= n:
            self.values.append(self.h(self.values[-1]))
        return self.values[n]


N = Orbit(0, Z)
M = Orbit(0, lambda u: plus(plus(Z(u), N(u)), N(u)))
G = Orbit(0, lambda u: S(plus(u, M(u))))
E = Orbit(1, lambda u: plus(u, u))


def H(u):
    return C(N(u), G(u), u)


def L(x, y):
    return N(I(y, E(x), H))


def A(m, u):
    return C(L(S(S(u)), m), u, S(u))


def V(t, m):
    return I(t, 0, lambda u: A(m, u))


def P(m):
    return V(m, m)


def main():
    count = {}

    def verify(name, left, right):
        if left != right:
            raise AssertionError((name, left, right))
        count[name] = count.get(name, 0) + 1

    for x in range(7):
        for y in range(7):
            verify('comparator_zero', L(0, y), 1)
            verify('comparator_successor_zero', L(S(x), 0), 0)
            verify('comparator_cancel', L(S(x), S(y)), L(x, y))
    for m in range(6):
        verify('update_shift_base', A(S(S(m)), 0), 1)
        for u in range(6):
            verify('update_shift_step', A(S(S(m)), S(u)), S(A(S(m), u)))
        for t in range(6):
            verify('iterator_shift', V(S(t), S(S(m))), S(V(t, S(m))))
        verify('diagonal_recurrence', P(S(S(m))), S(P(S(m))))
        verify('predecessor_successor', P(S(m)), m)
    verify('predecessor_zero', P(0), 0)
    verify('predecessor_one', P(1), 0)
    result = {
        'status': 'PASS',
        'evidence_type': 'finite evaluation of explicit scalar terms; not formalization',
        'counts': count,
        'total': sum(count.values()),
        'ranges': {'comparator_x_y': '0..6', 'shift_m_t_u': '0..5'},
        'cached_orbit_lengths': {
            name: len(orbit.values) for name, orbit in [('N', N), ('M', M), ('G', G), ('E', E)]
        },
    }
    print(json.dumps(result, indent=2))
    Path(__file__).with_suffix('.json').write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()
