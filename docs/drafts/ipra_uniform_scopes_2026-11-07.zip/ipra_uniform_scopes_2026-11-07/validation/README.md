# Reproduce the implementation checks

The complete checkers require Python 3.10 or later because their rule dispatch
uses structural pattern matching. The validation uses only Python's standard
library. From the package directory, run:

```sh
python3 validation/validate.py
python3 validation/direct_validate.py
python3 validation/independent/audit_uniform_semantics.py
```

These commands also work when invoked by absolute path from another working
directory. The scalar runner writes `results/validation.json`;
the optional direct-recursion runner writes `results/direct_validation.json`.
Both receipts identify the exact checker, oracle, fixture, and runner hashes.
Neither production checker imports any validation module or fixture.

`positive_certificates.json` contains 147 scalar certificates translated from the
pinned truth-completion draft. `direct_positive_certificates.json` contains its
55 direct-recursion certificates translated into the new dummy-scope syntax.
Each record gives the upstream commit, source path, exact source-file hash, and a
hash of the included translated packet. These runners check the bundled target
certificates directly; they do not fetch upstream files or rerun an unbundled
translation program. The source provenance was checked when the fixture bundle
was generated.

`oracle_uniform.py` is a readable, named-rule interpreter adapted from the pinned
truth-completion draft, with its original file hash recorded in the docstring.
It uses distinct numerical and formula traversals, explicit binding counts, and
ordinary conditionals. It does not use the production opening routine, packed
scope table, or structural match dispatch. Its two modes distinguish diagonal
state aliases from separate state and counter arguments.

The scalar and direct runners compare verdicts, consumed packet lengths, and
fresh-name floors; test mutations, malformed packets, and targeted false
conclusions; compare scope opening at boundary values; and evaluate numerical
substitution and computation independently. Finite floating aliases are tested
at five protected depths, alongside negative rigid names. The direct runner
also compares its two staged openings with an independent simultaneous
substitution and checks that two deliberately incorrect opening variants admit
false equations detected by the tests.

Every bundled positive and published example is additionally run through the
actual JSON/file command-line boundary, normally and with Python's `-O` option.
Malformed JSON, absent arguments/files, directory arguments, and active
nonfinite numerical atoms must return `REJECT` with exit status 1. Nonfinite
labels are parser extensions in CPython; they are not standard JSON numbers.
The examples' expected verdicts and descriptions are in `examples/index.json`
and `examples/direct_index.json`.

These finite checks support implementation confidence. They are not a
machine-checked proof of the mathematical soundness, completeness,
consistency, or bi-interpretability arguments in the report.
