#!/usr/bin/env python3
"""Write file hashes and a reproducible ZIP, then verify every archived member."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
STEM = 'ipra_uniform_scopes_2026-11-07'


def files():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and '__pycache__' not in p.parts
                  and p.name != 'SHA256SUMS.txt'
                  and p.suffix not in ('.pyc', '.aux', '.out', '.toc', '.synctex'))


def main():
    members = files()
    sums = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in members}
    manifest = ROOT / 'SHA256SUMS.txt'
    manifest.write_text(''.join(digest + '  ' + name + '\n' for name, digest in sums.items()))
    archive = ROOT.parent / (STEM + '.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(members + [manifest]):
            info = zipfile.ZipInfo(STEM + '/' + str(p.relative_to(ROOT)), (2026, 11, 7, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, p.read_bytes())
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise ValueError('ZIP integrity check failed')
        for name, digest in sums.items():
            if hashlib.sha256(z.read(STEM + '/' + name)).hexdigest() != digest:
                raise ValueError('ZIP hash mismatch: ' + name)
    print('PASS: ' + str(archive))
    print('Files: ' + str(len(members) + 1))
    print('Bytes: ' + str(archive.stat().st_size))
    print('SHA-256: ' + hashlib.sha256(archive.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
