#!/usr/bin/env python3
"""Link exact measurements and validation hashes, and render the evidence table."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def read(path):
    return json.loads((ROOT / path).read_text())


def main():
    measured = read('results/measurements.json')
    scalar = read('results/validation.json')
    direct = read('results/direct_validation.json')
    independent = read('results/independent_semantics.json')
    predecessor = read('validation/check_predecessor_shift.json')
    conditional = read('validation/predecessor/receipt.json')
    hashes = {row['file']: row['sha256'] for row in measured['candidates']}
    for name, receipt in [('checker.py', scalar), ('checker_direct.py', direct)]:
        actual = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
        if actual != hashes[name] or actual != receipt['checker']['sha256']:
            raise ValueError('Measurement/test/source identity mismatch: ' + name)
        if receipt['status'] != 'PASS' or receipt['failures']:
            raise ValueError('Validation is not PASS: ' + name)
    if independent['checker_sha256'] != hashes['checker.py']:
        raise ValueError('Independent audit tested a different scalar source')
    for key in ('opening_mismatches', 'source_oracle_mismatches', 'source_false_equations', 'schema_failures'):
        if independent[key]:
            raise ValueError('Independent audit failure: ' + key)
    if not all(case['passed'] for case in independent['focused_cases']):
        raise ValueError('A focused audit case failed')
    if predecessor['status'] != 'PASS' or conditional['status'] != 'PASS':
        raise ValueError('Predecessor evidence did not pass')
    if conditional['hypotheses_proved'] or conditional['closed_public_driver_theorem']:
        raise ValueError('Conditional evidence claim changed')
    counts = [
        ('Scalar translated positive certificates', scalar['fixture']['positive_records']),
        ('Direct translated positive certificates', direct['fixture']['positive_records']),
        ('Scalar packet/oracle comparisons', scalar['packet_comparisons']),
        ('Direct packet/oracle comparisons', direct['packet_comparisons']),
        ('Scalar public CLI runs (normal and optimized)', scalar['public_cli']['runs']),
        ('Direct public CLI runs (normal and optimized)', direct['public_cli']['runs']),
        ('Separate independent opening comparisons', independent['opening_comparisons']),
        ('Separate random computation attempts', independent['schema_attempts']),
        ('Accepted attempts independently evaluated equal', independent['schema_evaluated']),
        ('Additional accepted root equations evaluated equal', independent['source_closed_equations_evaluated']),
        ('Explicit predecessor identities on finite ranges', predecessor['total']),
        ('Conditional native shift derivation instruction cells', conditional['instruction_cells']),
    ]
    lines = [r'\begin{center}', r'\begin{tabular}{@{}lr@{}}', r'\toprule',
             r'Finite validation category & Count\\', r'\midrule']
    lines += [name + ' & ' + format(value, ',') + r'\\' for name, value in counts]
    lines += [r'\bottomrule', r'\end{tabular}', r'\end{center}']
    (ROOT / 'results/validation_table.tex').write_text('\n'.join(lines) + '\n')
    result = {'status': 'PASS', 'source_hashes': hashes, 'counts': dict(counts),
              'metatheory_status': 'written proofs, not proof-assistant formalization',
              'test_populations_may_overlap': True}
    (ROOT / 'results/evidence_summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
