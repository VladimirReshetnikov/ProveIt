"""Run the complete offline comparison and the delivered validation drivers."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
STEPS = ('comparison/measure.py', 'validation/differential/replay.py',
         'validation/independent/audit.py',
         'validation/independent/demand_policy.py')


def main():
    destination = ROOT / 'results'
    destination.mkdir(exist_ok=True)
    rows = []
    for index, script in enumerate(STEPS, 1):
        completed = subprocess.run([sys.executable, '-B', str(ROOT / script)],
                                   cwd=ROOT, text=True, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT)
        (destination / f'reproduction-{index}.txt').write_text(completed.stdout)
        rows.append({'script': script, 'exit_code': completed.returncode})
        print(('PASS ' if completed.returncode == 0 else 'FAIL ') + script)
        if completed.returncode:
            print(completed.stdout)
            break
    passed = len(rows) == len(STEPS) and all(row['exit_code'] == 0 for row in rows)
    result = {'passed': passed, 'steps': rows,
              'scope': 'Finite source measurements, differential replay, '
                       'named-binder audit, and public witness-policy checks.'}
    (destination / 'reproduction.json').write_text(json.dumps(result, indent=2) + '\n')
    if not passed:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
