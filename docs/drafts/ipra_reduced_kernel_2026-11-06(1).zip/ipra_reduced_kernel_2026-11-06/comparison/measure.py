"""Reproduce full-program source measurements with byte-identical baselines.

All grammar, substitution, rules, JSON parsing, file handling and verdict code
is counted. Only comments and actual docstrings are excluded. The identical
Python runtime and its standard-library modules are outside every boundary.
"""
import ast
import csv
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

ROOT = Path(__file__).resolve().parent
FIELDS = ('ast_nodes', 'source_tokens', 'normalized_tokens',
          'normalized_bytes', 'raw_bytes')
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL,
           tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
           tokenize.ENDMARKER}


def measure(path):
    raw = Path(path).read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef,
                             ast.AsyncFunctionDef, ast.ClassDef)) and node.body:
            doc = node.body[0]
            if (isinstance(doc, ast.Expr) and
                    isinstance(doc.value, ast.Constant) and
                    isinstance(doc.value.value, str)):
                node.body.pop(0)
                spans.append(((doc.lineno, doc.col_offset),
                              (doc.end_lineno, doc.end_col_offset)))
    normalized = ast.unparse(tree) + '\n'

    def tokens(text, omitted=()):
        return sum(token.type not in IGNORED and not any(
            first <= token.start and token.end <= last
            for first, last in omitted)
            for token in tokenize.generate_tokens(io.StringIO(text).readline))

    return {'sha256': hashlib.sha256(raw).hexdigest(),
            'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'source_tokens': tokens(source, spans),
            'normalized_tokens': tokens(normalized),
            'normalized_bytes': len(normalized.encode('utf-8')),
            'raw_bytes': len(raw)}


def envelope(rows):
    return {field: min(row[field] for row in rows) for field in FIELDS}


def core_measure(path):
    """Diagnostic: remove imports/CLI, identically for every source.

    Some comparators put context validation in their CLI. Thus this gives
    those comparators a favorable boundary; it is not the primary measure.
    """
    tree = ast.parse(Path(path).read_text())
    tree.body = [node for node in tree.body
                 if not isinstance(node, (ast.Import, ast.ImportFrom, ast.If))
                 and not (isinstance(node, ast.Expr) and
                          isinstance(node.value, ast.Constant) and
                          isinstance(node.value.value, str))]
    normalized = ast.unparse(tree) + '\n'
    return {'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'normalized_tokens': sum(token.type not in IGNORED for token in
                tokenize.generate_tokens(io.StringIO(normalized).readline)),
            'normalized_bytes': len(normalized.encode('utf-8'))}


def main():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    rows = []
    for entry in manifest['checkers']:
        row = {**entry, **measure(ROOT / entry['source'])}
        if row['sha256'] != entry['sha256']:
            raise ValueError('Changed baseline: ' + entry['source'])
        rows.append(row)
    candidate = {'source': '../checker.py', 'interface': 'open_sequent',
                 'witness_policy': 'strict', **measure(ROOT.parent / 'checker.py')}
    demand = {'source': '../checker_demand.py', 'interface': 'open_sequent',
              'witness_policy': 'demand', **measure(ROOT.parent / 'checker_demand.py')}
    minima = envelope(rows)
    result = {
        'python_version': platform.python_version(),
        'repository': manifest['repository'], 'commit': manifest['commit'],
        'boundary': 'Entire acceptance program; comments and docstrings excluded.',
        'baseline_count': len(rows), 'baselines': rows,
        'all_current_minima': minima,
        'strict_open_minima': envelope([row for row in rows
            if row['interface'] == 'open_sequent' and row['witness_policy'] == 'strict']),
        'candidate': candidate,
        'demand_candidate': demand,
        'strictly_below_all_current': {
            key: candidate[key] < minima[key] for key in FIELDS},
        'demand_strictly_below_all_current': {
            key: demand[key] < minima[key] for key in FIELDS},
        'reduction_percent': {
            key: 100 * (1 - candidate[key] / minima[key]) for key in FIELDS}}
    cores = [{**entry, **core_measure(ROOT / entry['source'])}
             for entry in manifest['checkers']]
    core_fields = ('ast_nodes', 'normalized_tokens', 'normalized_bytes')
    result['core_diagnostic'] = {
        'boundary': 'Imports and complete top-level CLI removed; favorable '
                    'to comparators placing context validation inside their CLI.',
        'baselines': cores,
        'minima': {key: min(row[key] for row in cores) for key in core_fields},
        'strict': core_measure(ROOT.parent / 'checker.py'),
        'demand': core_measure(ROOT.parent / 'checker_demand.py')}
    destination = ROOT.parent / 'results'
    destination.mkdir(exist_ok=True)
    (destination / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    with (destination / 'metrics.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, ['source', 'interface', 'witness_policy',
                                        *FIELDS, 'sha256'], extrasaction='ignore')
        writer.writeheader()
        writer.writerows([*rows, candidate, demand])
    if not all(result['strictly_below_all_current'].values()):
        raise ValueError('Candidate does not strictly beat every current coordinate')
    if not all(result['demand_strictly_below_all_current'].values()):
        raise ValueError('Demand candidate does not beat every current coordinate')
    if not all(result['core_diagnostic']['demand'][key] <
               result['core_diagnostic']['minima'][key] for key in core_fields):
        raise ValueError('Demand core does not beat the core diagnostic envelope')
    macros = {'NewAST': candidate['ast_nodes'],
              'NewSourceTokens': candidate['source_tokens'],
              'NewNormTokens': candidate['normalized_tokens'],
              'NewNormBytes': candidate['normalized_bytes'],
              'NewRawBytes': candidate['raw_bytes'],
              'DemandAST': demand['ast_nodes'],
              'DemandSourceTokens': demand['source_tokens'],
              'DemandNormTokens': demand['normalized_tokens'],
              'DemandNormBytes': demand['normalized_bytes'],
              'DemandRawBytes': demand['raw_bytes']}
    (ROOT.parent / 'sections/numbers.tex').write_text(''.join(
        '\\newcommand{\\' + name + '}{' + f'{value:,}' + '}\n'
        for name, value in macros.items()))
    summary = {key: value for key, value in result.items()
               if key not in {'baselines', 'core_diagnostic'}}
    summary['core_diagnostic'] = {
        key: value for key, value in result['core_diagnostic'].items()
        if key != 'baselines'}
    print(json.dumps(summary, indent=2))
    return result


if __name__ == '__main__':
    main()
