"""Rebuild a deterministic ZIP and its complete SHA-256 inventory."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent


def files():
    return sorted(path for path in ROOT.rglob('*') if path.is_file()
                  and not any(part.startswith('.') or part == '__pycache__'
                              for part in path.relative_to(ROOT).parts)
                  and path.suffix != '.pyc')


def main():
    manifest = ROOT / 'MANIFEST.sha256'
    rows = [hashlib.sha256(path.read_bytes()).hexdigest() + '  ' +
            path.relative_to(ROOT).as_posix()
            for path in files() if path != manifest]
    manifest.write_text('\n'.join(rows) + '\n')
    destination = ROOT.with_suffix('.zip')
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in files():
            entry = zipfile.ZipInfo(ROOT.name + '/' + path.relative_to(ROOT).as_posix(),
                                    date_time=(2026, 11, 6, 12, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, path.read_bytes())
    with zipfile.ZipFile(destination) as archive:
        bad = archive.testzip()
        if bad:
            raise ValueError('Archive integrity failure: ' + bad)
    print(destination.name, destination.stat().st_size, 'bytes')
    print('SHA-256', hashlib.sha256(destination.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
