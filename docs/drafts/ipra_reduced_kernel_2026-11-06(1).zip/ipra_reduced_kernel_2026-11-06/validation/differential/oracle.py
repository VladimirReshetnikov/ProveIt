"""Independent formation, named-substitution, and rule oracle.

This untrusted audit module imports no function from either candidate checker.
The syntax and rules are implemented directly.  Substitution converts indices
to unique binder identities, replaces named free variables, then reconstructs
indices; it does not copy the candidate's cutoff/substitution recursion.

The named representation is adapted from the supplied ProveIt goal-calculus
draft, validation/named_oracle.py, pinned by comparison/manifest.json.  Its
ancestor credits the shared-transition draft's independent_audit.py.  The
positive-index convention and goal-only strict rule interpreter are new here.
The supplied source license is comparison/LICENSE_SOURCE.txt.
"""

import itertools
from collections import Counter


def valid(a, formula):
    if type(a) is int:
        return not formula and a >= 0
    if type(a) is not list or not a or type(a[0]) is not str:
        return False
    tag = a[0]
    if formula:
        if tag == "=":
            return len(a) == 3 and valid(a[1], False) and valid(a[2], False)
        if tag == "pi":
            return len(a) == 3 and valid(a[1], True) and valid(a[2], True)
        if tag == "ex":
            return len(a) == 2 and valid(a[1], True)
    else:
        if tag == "s":
            return len(a) == 2 and valid(a[1], False)
        if tag == "r":
            return len(a) == 4 and all(valid(t, False) for t in a[1:])
    return False


def require(condition, message="independent audit rejected"):
    if not condition:
        raise ValueError(message)


_fresh = itertools.count()


def named(a, stack=()):
    if type(a) is int:
        if a == 0:
            return ("zero",)
        if a <= len(stack):
            return ("bound", stack[a - 1])
        return ("free", a - 1 - len(stack))
    tag = a[0]
    if tag == "s":
        return ("succ", named(a[1], stack))
    if tag == "r":
        state, counter = next(_fresh), next(_fresh)
        return ("rec", named(a[1], stack), named(a[2], stack), state,
                counter, named(a[3], (state, counter, *stack)))
    if tag == "=":
        return ("equal", named(a[1], stack), named(a[2], stack))
    variable = next(_fresh)
    if tag == "pi":
        return ("all", variable, named(a[1], (variable, *stack)),
                named(a[2], (variable, *stack)))
    if tag == "ex":
        return ("exists", variable, named(a[1], (variable, *stack)))
    raise ValueError("invalid named input")


def indices(a, stack=()):
    tag = a[0]
    if tag == "zero":
        return 0
    if tag == "bound":
        return stack.index(a[1]) + 1
    if tag == "free":
        return a[1] + len(stack) + 1
    if tag == "succ":
        return ["s", indices(a[1], stack)]
    if tag == "rec":
        return ["r", indices(a[1], stack), indices(a[2], stack),
                indices(a[5], (a[3], a[4], *stack))]
    if tag == "equal":
        return ["=", indices(a[1], stack), indices(a[2], stack)]
    if tag == "all":
        return ["pi", indices(a[2], (a[1], *stack)),
                indices(a[3], (a[1], *stack))]
    if tag == "exists":
        return ["ex", indices(a[2], (a[1], *stack))]
    raise ValueError("invalid named expression")


def replace_free(a, replacements, delta):
    tag = a[0]
    if tag == "free":
        i = a[1]
        return replacements[i] if i < len(replacements) else ("free", i + delta)
    if tag in ("zero", "bound"):
        return a
    if tag == "succ":
        return (tag, replace_free(a[1], replacements, delta))
    if tag == "rec":
        return (tag, replace_free(a[1], replacements, delta),
                replace_free(a[2], replacements, delta), a[3], a[4],
                replace_free(a[5], replacements, delta))
    if tag == "equal":
        return (tag, replace_free(a[1], replacements, delta),
                replace_free(a[2], replacements, delta))
    if tag == "all":
        return (tag, a[1], replace_free(a[2], replacements, delta),
                replace_free(a[3], replacements, delta))
    if tag == "exists":
        return (tag, a[1], replace_free(a[2], replacements, delta))
    raise ValueError("invalid named expression")


def subst(a, env=(1,), depth=0, formula=True):
    require(valid(a, formula), "malformed syntax")
    require(type(depth) is int and depth >= 0, "invalid external cutoff")
    require(env and type(env[-1]) is int, "invalid substitution shift")
    require(all(valid(t, False) for t in env[:-1]), "malformed replacement")
    stack = tuple(next(_fresh) for _ in range(depth))
    replacements = [named(t) for t in env[:-1]]
    return indices(replace_free(named(a, stack), replacements, env[-1]), stack)


def _rule(a, p, g, counts):
    require(valid(a, True) and all(valid(h, True) for h in g),
            "malformed goal or retained context")
    if a[0] == "pi" and type(p) is list and len(p) == 1:
        h, b = a[1:]
        if h == subst(b, [0, 0]):
            if b[0] == "=":
                h = b
                counts["equation_induction"] += 1
            else:
                counts["compound_cases"] += 1
            b = subst(b, [["s", 1], 0])
        else:
            counts["ordinary_guarded_introduction"] += 1
        return _rule(b, p[0], [*[subst(h) for h in g], h], counts)

    if a[0] == "ex" and type(p) is list and len(p) == 2:
        witness, child = p
        require(valid(witness, False), "malformed existential witness")
        h = ["=", 1, subst(witness, formula=False)]
        counts["existential_introduction"] += 1
        return _rule(a[1], child, [*[subst(h) for h in g], h], counts)

    if (type(p) is list and len(p) >= 2
            and type(p[0]) is list and len(p[0]) >= 1):
        major, major_proof, *args = p
        # A false well-formed major falls through to hypothesis membership.
        # A malformed major raises, exactly as at the public checker boundary.
        if _rule(major, major_proof, g, counts):
            if major[0] == "ex":
                require(len(args) == 1, "existential elimination arity")
                counts["existential_elimination"] += 1
                return _rule(subst(a), args[0],
                             [*[subst(h) for h in g], major[1]], counts)
            require(len(args) == 2, "binary elimination arity")
            template_or_witness, child = args
            if major[0] == "=":
                require(valid(template_or_witness, True), "malformed motive")
                source, target = [subst(template_or_witness, [t, -1])
                                  for t in major[1:]]
                counts["equality_transport"] += 1
            else:
                require(major[0] == "pi", "unexpected elimination major")
                require(valid(template_or_witness, False),
                        "malformed universal witness, including vacuous use")
                source, target = [subst(part, [template_or_witness, -1])
                                  for part in major[1:]]
                counts["guarded_elimination"] += 1
            return target == a and _rule(source, child, g, counts)

    if (a[0] == "=" and type(a[1]) is list and a[1][0] == "r"
            and type(p) is list and len(p) == 0):
        n, initial, update = a[1][1:]
        if n == 0:
            rhs = initial
            counts["computation_zero"] += 1
        else:
            require(type(n) is list and len(n) == 2 and n[0] == "s",
                    "computation requires zero or successor counter")
            predecessor = n[1]
            rhs = subst(update,
                        [["r", predecessor, initial, update], predecessor, -2],
                        formula=False)
            counts["computation_successor"] += 1
        return rhs == a[2]

    counts["hypothesis_membership"] += 1
    return a in g


def check(data):
    require(type(data) is list and len(data) >= 2, "invalid public input arity")
    a, p, *g = data
    counts = Counter()
    require(_rule(a, p, g, counts), "proof obligations not discharged")
    return counts


def accepted(data):
    try:
        check(data)
        return True
    except Exception:
        return False
