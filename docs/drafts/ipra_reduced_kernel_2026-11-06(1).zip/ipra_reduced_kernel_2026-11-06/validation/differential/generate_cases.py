"""Exact deterministic generator for the 12,000 differential JSON cases.

The packaged random_cases.jsonl freezes the resulting values, so replay does
not depend on a future Python version retaining the same random algorithms.
replay.py also checks this generator against that frozen corpus.
"""
import random

SEED = 20261106
COUNT = 12000
LEAVES = [None, False, True, -1, -2, 0, 1, 2, 1.5, '',
          's', 'r', '=', 'pi', 'ex']


def random_json(rng, depth):
    if depth <= 0 or rng.randrange(3) == 0:
        return rng.choice(LEAVES)
    if rng.randrange(8) == 0:
        return {str(rng.choice(LEAVES)): random_json(rng, depth - 1)}
    return [random_json(rng, depth - 1) for _ in range(rng.randrange(5))]


def cases():
    rng = random.Random(SEED)
    for index in range(COUNT):
        if index % 2:
            goal = rng.choice([
                ['=', 0, 0],
                ['pi', ['=', 0, 0], ['=', 0, 0]],
                ['ex', ['=', 1, 0]],
            ])
            data = [goal, random_json(rng, 3)]
            if rng.randrange(2):
                data.append(goal)
        else:
            data = random_json(rng, 3)
        yield data
