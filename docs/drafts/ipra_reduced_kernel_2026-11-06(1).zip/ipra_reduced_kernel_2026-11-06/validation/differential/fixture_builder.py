"""Inherited rule/formation fixtures, extracted from the pinned goal-only draft.

The five definitions below are unchanged source segments.  replay.py assigns
this module's oracle to the separately loaded, byte-identical oracle.py before
calling fixtures().  No candidate checker helper is used to build the data.
See provenance.json for source hashes and ../../LICENSE_SOURCE.txt for license.
"""

def eq(s, t):
    return ["=", s, t]


def succ(t):
    return ["s", t]


def rec(n, a, h):
    return ["r", n, a, h]


def reflexivity(t):
    """Untrusted builder, using independent substitution only."""
    r = rec(0, t, 0)
    major = eq(r, t)
    motive = eq(1, oracle.subst(t, formula=False))
    return [major, [], motive, []]


def fixtures():
    result = []

    def add(name, expected, a, p, *g):
        result.append({"name": name, "expected": expected,
                       "data": [a, p, *g]})

    truth, falsehood = eq(0, 0), eq(0, succ(0))
    add("hypothesis-membership", True, truth, None, truth)
    add("unused-proof-object-is-a-hypothesis", True, truth, {"unused": []}, truth)
    add("unconditional-falsehood-rejected", False, falsehood, None)
    add("unproved-reflexivity-is-not-an-axiom", False, truth, None)
    add("derived-reflexivity", True, truth, reflexivity(0))
    add("reflexivity-with-sparse-parameter", True, eq(17, 17), reflexivity(17))
    for i, initial in enumerate((0, 1, succ(4), rec(3, 0, succ(1)))):
        term = rec(0, initial, rec(2, 1, succ(3)))
        add("computation-zero-%d" % i, True, eq(term, initial), [])
        add("computation-zero-wrong-rhs-%d" % i, False,
            eq(term, succ(initial)), [])
    updates = (1, 2, succ(1), rec(2, 1, succ(3)),
               rec(3, rec(2, 1, 4), rec(2, 3, succ(5))))
    for i, update in enumerate(updates):
        r = rec(succ(1), 2, update)
        rhs = oracle.subst(update, [rec(1, 2, update), 1, -2], formula=False)
        add("successor-update-binding-%d" % i, True, eq(r, rhs), [])
        add("successor-update-wrong-rhs-%d" % i, False, eq(r, succ(rhs)), [])
    add("counter-variable-cannot-compute", False, eq(rec(1, 0, 1), 0), [])
    add("counter-recursor-cannot-compute", False,
        eq(rec(rec(0, 0, 0), 0, 1), 0), [])
    add("computation-needs-empty-certificate", False,
        eq(rec(0, 0, 0), 0), None)

    identity = ["pi", eq(1, 1), eq(1, 1)]
    add("ordinary-guarded-introduction", True, identity, [None])
    add("guarded-introduction-empty-arity", False, identity, [])
    add("guarded-introduction-extra-arity", False, identity, [None, None])
    add("retained-parameter-is-shifted", True,
        ["pi", eq(1, 1), eq(2, 0)], [None], eq(1, 0))
    add("retained-parameter-cannot-be-captured", False,
        ["pi", eq(1, 1), eq(1, 0)], [None], eq(1, 0))
    for i, t in enumerate((0, 1, succ(3), rec(2, 0, succ(1)))):
        goal = ["ex", eq(1, oracle.subst(t, formula=False))]
        add("existential-witness-%d" % i, True, goal, [t, None])
    existence = ["ex", eq(1, 0)]
    add("existential-empty-arity", False, existence, [])
    add("existential-short-arity", False, existence, [0])
    add("existential-extra-arity", False, existence, [0, None, None])
    add("existential-witness-must-match", False, existence, [succ(0), None])
    add("existential-witness-is-lifted", False, ["ex", eq(1, 1)], [1, None])

    # A genuinely recursive equation induction step uses its induction equation.
    b = eq(rec(1, 0, succ(1)), 1)
    step_lhs = rec(succ(1), 0, succ(1))
    motive = eq(oracle.subst(step_lhs, formula=False), succ(1))
    child = [b, None, motive, []]
    induction = ["pi", oracle.subst(b, [0, 0]), b]
    add("equation-induction-uses-hypothesis", True, induction, [child])
    add("equation-induction-wrong-step", False, induction, [None])
    constant_compound = ["ex", eq(1, 1)]
    add("compound-automatic-collision", True,
        ["pi", constant_compound, constant_compound], [None])
    compound = ["ex", eq(1, 2)]
    compound_goal = ["pi", oracle.subst(compound, [0, 0]), compound]
    add("compound-numerical-cases", True, compound_goal, [[succ(1), None]])
    # This certificate would work if the compound branch supplied B(n).
    # Correct cases supplies only B(0), so its attempted B(n) major must fail.
    bad_compound_step = [compound, None, [succ(2), None]]
    add("compound-cases-does-not-give-induction-hypothesis", False,
        compound_goal, [bad_compound_step])
    add("automatic-numerical-branch-is-not-optional", False,
        ["pi", eq(0, 0), eq(1, 0)], [None])

    witness = rec(0, succ(0), 0)
    add("guarded-elimination", True, eq(witness, witness),
        [identity, [None], witness, reflexivity(witness)])
    vacuous = ["pi", truth, truth]
    add("vacuous-valid-witness", True, truth,
        [vacuous, [None], 0, None], truth)
    add("equality-transport", True, eq(succ(1), 0),
        [eq(1, succ(1)), None, eq(1, 0), None], eq(1, succ(1)), eq(1, 0))
    nested_motive = ["ex", eq(rec(2, 0, succ(1)), 2)]
    nested_source = oracle.subst(nested_motive, [1, -1])
    nested_target = oracle.subst(nested_motive, [succ(1), -1])
    add("equality-transport-nested-binder", True, nested_target,
        [eq(1, succ(1)), None, nested_motive, None],
        eq(1, succ(1)), nested_source)
    add("existential-elimination", True, truth,
        [existence, None, reflexivity(0)], existence)
    add("existential-eigenvariable-cannot-escape", False, eq(1, 0),
        [existence, None, None], existence)
    add("failed-major-hypothesis-fallback", True, truth,
        [falsehood, None, 0, None], truth)
    add("failed-major-does-not-prove-new-goal", False, truth,
        [falsehood, None, 0, None])
    add("malformed-major-does-not-fallback", False, truth,
        [["=", True, 0], None, 0, None], truth)

    for i, bad in enumerate((None, False, 0.0, -1, "junk", [], ["s"],
                              ["s", 0, 0], ["=", 0, 0], {},
                              rec(0, 0, ["bad"]))):
        add("strict-vacuous-universal-witness-%d" % i, False, truth,
            [vacuous, [None], bad, None], truth)
        add("strict-existential-witness-%d" % i, False,
            existence, [bad, None])

    for tag, major, major_proof, args, target, context in (
            ("pi", vacuous, [None], [0, None], truth, [truth]),
            ("eq", eq(0, 0), None, [truth, None], truth, [truth]),
            ("ex", existence, None, [reflexivity(0)], truth, [existence])):
        for count in range(5):
            if count == len(args):
                continue
            malformed_args = (args + [None] * 5)[:count]
            add("%s-elimination-arity-%d" % (tag, count), False,
                target, [major, major_proof, *malformed_args], *context)

    invalid_expressions = (
        None, True, False, 0, 1.0, -1, "=", {}, [], ["="], ["=", 0],
        ["=", 0, 0, 0], ["=", True, 0], ["=", 0.0, 0],
        ["=", -1, 0], ["=", ["s"], 0], ["=", ["s", 0, 1], 0],
        ["=", ["r", 0, 0], 0], ["=", ["r", 0, 0, 0, 0], 0],
        ["=", ["r", 0, 0, ["pi", truth, truth]], 0],
        ["pi", truth], ["pi", truth, truth, truth], ["pi", 0, truth],
        ["ex"], ["ex", truth, truth], ["ex", 0], ["unknown", truth],
        ["ex", ["=", False, 0]], ["pi", truth, ["=", 1.0, 0]],
    )
    for i, bad in enumerate(invalid_expressions):
        add("malformed-public-goal-%d" % i, False, bad, None, truth)
        add("malformed-unused-context-%d" % i, False,
            truth, reflexivity(0), bad)
    return result
