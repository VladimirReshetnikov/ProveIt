OFFLINE DIFFERENTIAL REPLAY

From the package root:

    python3 validation/differential/replay.py

The script also works from an unrelated working directory when invoked by
its absolute path. It uses only Python's standard library and local files.
It writes ../../results/differential.json relative to this directory.

Both final acceptance programs are compared with their byte-identical
goal-only predecessors, already retained in ../../comparison/sources/.
For EACH policy, the replay checks the same 148 inherited rule/formation
fixtures, all 19 packaged examples, and all 12,000 frozen JSON corpus values.
It checks source/candidate equality, and additionally checks the independent
strict expected labels for the strict policy. A demand fixture's expected
verdict is the unchanged demand predecessor's verdict.

fixtures.json contains every fixture and strict expected label.
fixture_builder.py retains five unchanged function definitions extracted
from the pinned draft's validation/audit.py. The byte-identical oracle.py
constructs their numerical substitutions by named binding, independently
of the candidate helpers. The replay regenerates all 148 fixtures and
requires exact agreement with the frozen data.

random_cases.jsonl retains every random input, in execution order, using
compact ASCII JSON and one newline per case. generate_cases.py retains the
exact seed (20261106) and construction recipe from the original experiment.
The replay regenerates and verifies all corpus bytes before testing them.
The frozen corpus permits inspection without relying on a future random
number library's behavior. Recorded results include corpus and verdict hashes.

provenance.json identifies the pinned repository commit, archive identity,
inherited source hashes, extracted source relationships, candidate/predecessor
hashes, and example/data/support hashes. Inherited code is covered by the
source license retained at ../../LICENSE_SOURCE.txt. No checker imports any
file in this directory.

This evidence is finite and partly differential. It supplements the paper's
proof of acceptance equivalence and the separate independent audit. It is
not a machine-checked universal soundness or bi-interpretability theorem.
The fixture, example and random suites overlap, and the two policies replay
the same input corpus; counts must not be added as distinct theorem counts.
