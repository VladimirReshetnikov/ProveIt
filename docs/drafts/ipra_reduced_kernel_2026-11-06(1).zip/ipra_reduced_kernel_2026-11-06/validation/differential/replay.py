"""Portable offline replay of the two candidates' differential evidence.

No candidate imports this support.  All paths are relative to this file.
The inherited oracle builds fixtures independently of candidate helpers;
the acceptance comparisons use byte-identical predecessor checkers.
"""
import hashlib
import importlib.util
import json
import platform
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PACKAGE = HERE.parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def accepts(module, data):
    try:
        return module.check(*data) is True
    except Exception:
        return False


def corpus_bytes(cases):
    return ''.join(json.dumps(case, ensure_ascii=True, separators=(',', ':'))
                   + '\n' for case in cases).encode('utf-8')


def verify_provenance(provenance):
    for group in ('source_checkers', 'candidate_checkers', 'examples'):
        for item in provenance[group]:
            path = (HERE / item['path']).resolve()
            if digest(path) != item['sha256']:
                raise ValueError('Changed ' + group + ' member: ' + item['path'])
    for key in ('fixture_data', 'random_data'):
        item = provenance[key]
        if digest(HERE / item['path']) != item['sha256']:
            raise ValueError('Changed differential data: ' + item['path'])
    for item in provenance['support_files']:
        if digest(HERE / item['path']) != item['sha256']:
            raise ValueError('Changed differential support: ' + item['path'])


def main():
    provenance = json.loads((HERE / 'provenance.json').read_text(encoding='utf-8'))
    verify_provenance(provenance)
    fixtures = json.loads((HERE / 'fixtures.json').read_text(encoding='utf-8'))
    frozen_corpus = (HERE / 'random_cases.jsonl').read_bytes()
    random_cases = [json.loads(line) for line in frozen_corpus.splitlines()]
    if len(fixtures) != 148 or len(random_cases) != 12000:
        raise ValueError('Incorrect frozen corpus size')

    oracle = load('ipra_diff_oracle', HERE / 'oracle.py')
    builder = load('ipra_diff_fixtures', HERE / 'fixture_builder.py')
    builder.oracle = oracle
    if builder.fixtures() != fixtures:
        raise ValueError('The inherited fixture builder does not reproduce its data')
    generator = load('ipra_diff_generator', HERE / 'generate_cases.py')
    if corpus_bytes(generator.cases()) != frozen_corpus:
        raise ValueError('The seeded generator does not reproduce its data')

    examples = [(item['path'], json.loads((HERE / item['path']).read_text(
        encoding='utf-8'))) for item in provenance['examples']]
    report = {
        'python': platform.python_version(),
        'repository_commit': provenance['commit'],
        'fixture_count': len(fixtures),
        'example_count': len(examples),
        'random_case_count': len(random_cases),
        'random_seed': generator.SEED,
        'random_corpus_sha256': hashlib.sha256(frozen_corpus).hexdigest(),
        'fixture_regeneration': True,
        'random_corpus_regeneration': True,
        'variants': {},
        'failures': [],
        'limits': (
            'Finite differential evidence, not a universal soundness proof. '
            'Strict fixtures also have independent expected labels. Demand '
            'fixtures are compared with the frozen demand predecessor. The '
            'same 148 fixtures, 19 examples and 12000 corpus values are used '
            'under each policy; these are not distinct theorem counts. '
            'This driver checks acceptance functions; the independent audit '
            'provides separate public-CLI coverage.'
        ),
    }
    for policy, filename in (('strict', 'checker.py'),
                             ('demand', 'checker_demand.py')):
        source_path = (PACKAGE / 'comparison/sources/'
                       'ipra_goal_only_2026-11-06' / filename)
        candidate_path = PACKAGE / filename
        source = load('ipra_diff_source_' + policy, source_path)
        candidate = load('ipra_diff_candidate_' + policy, candidate_path)
        fixture_rows = []
        example_rows = []
        failures = []
        for item in fixtures:
            before = accepts(source, item['data'])
            after = accepts(candidate, item['data'])
            expected = item['expected'] if policy == 'strict' else before
            row = {'name': item['name'], 'source': before,
                   'candidate': after, 'expected': expected}
            fixture_rows.append(row)
            if before != after or after != expected:
                failures.append({'stage': 'fixture', **row})
        for name, data in examples:
            before, after = accepts(source, data), accepts(candidate, data)
            row = {'path': name, 'source': before, 'candidate': after}
            example_rows.append(row)
            if not before or not after:
                failures.append({'stage': 'example', **row})
        random_source_accepts = 0
        random_candidate_accepts = 0
        verdicts = bytearray()
        for index, data in enumerate(random_cases):
            before, after = accepts(source, data), accepts(candidate, data)
            random_source_accepts += before
            random_candidate_accepts += after
            verdicts.extend((before, after))
            if before != after:
                failures.append({'stage': 'random', 'index': index,
                                 'source': before, 'candidate': after})
        result = {
            'candidate_sha256': digest(candidate_path),
            'source_sha256': digest(source_path),
            'fixtures': fixture_rows,
            'fixture_accepts': sum(row['candidate'] for row in fixture_rows),
            'fixture_rejects': sum(not row['candidate'] for row in fixture_rows),
            'examples': example_rows,
            'random_cases_executed': len(random_cases),
            'random_source_accepts': random_source_accepts,
            'random_candidate_accepts': random_candidate_accepts,
            'random_verdicts_sha256': hashlib.sha256(verdicts).hexdigest(),
            'failures': failures,
            'passed': not failures,
        }
        report['variants'][policy] = result
        report['failures'].extend({'policy': policy, **failure}
                                  for failure in failures)
    report['passed'] = not report['failures']
    destination = PACKAGE / 'results/differential.json'
    destination.parent.mkdir(exist_ok=True)
    destination.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    summary = {key: report[key] for key in (
        'passed', 'fixture_count', 'example_count', 'random_case_count',
        'fixture_regeneration', 'random_corpus_regeneration')}
    summary['variants'] = {
        policy: {key: result[key] for key in (
            'passed', 'fixture_accepts', 'fixture_rejects',
            'random_cases_executed', 'random_candidate_accepts')}
        for policy, result in report['variants'].items()
    }
    print(json.dumps(summary, indent=2))
    if not report['passed']:
        raise SystemExit(1)
    return report


if __name__ == '__main__':
    main()
