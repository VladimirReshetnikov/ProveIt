INDEPENDENT NAMED-BINDER AND PUBLIC-BOUNDARY AUDIT

From the extracted package root, run:

    python3 validation/independent/audit.py
    python3 validation/independent/demand_policy.py

Both scripts also work when invoked by absolute path from another directory.
They locate checker.py, checker_demand.py, and results/ relative to the package.
All dependencies are Python's standard library and the supplied named oracle.
No network, absolute source-workspace path, or installed mathematical prover is
required. Optional path arguments allow another compatible checker to be tested.

The main audit has 100 manually labeled rule/formation cases: 25 expected
acceptances and 75 expected rejections. Its actual CLI replay includes those 100
cases, 16 optimized-Python cases, and 8 malformed-JSON/input/command-line cases,
for 124 public CLI runs. There are also 864 deterministic substitutions compared
with a named-variable algorithm, 8 literal hand-checked substitution anchors,
and 100 JSON write/read comparisons. Ten fixtures are explicitly paired
certificate mutations. These categories overlap and are not independent
mathematical theorems.

The accepted cases visit every native rule branch: ordinary guarded
introduction, equation induction, compound numerical cases, existential
introduction and elimination, guarded elimination, equality transport, both
recursion computations, and hypothesis membership. Rejection cases cover
capture and eigenvariable escape, unlicensed compound induction, false-major
fallback versus malformed-major errors, exact elimination arities, malformed
unused updates and assumptions, and Boolean/floating-point/negative-index
aliases. Public goal and context formation are checked independently of whether
an annotation is used.

The smaller demand-policy audit has 14 focused fixtures and 41 actual CLI runs.
Seven certificates with vacuous applications intentionally distinguish the two programs:
the demand checker accepts their erased, malformed annotations and the strict
checker rejects them. In every case, replacing the annotation with the term 0
gives a certificate accepted by both the strict checker and the independent
strict oracle. One of these certificates evaluates an unsuccessful major before
falling back to hypothesis membership: its inner demand call returns False after
visiting a malformed vacuous annotation. Replacing only that annotation by 0
preserves the False result and the successful outer fallback. This checks repair
over completed evaluation traces, including calls returning False, rather than
only the successful premises of selected rules.

Four additional universal cases reject malformed witnesses
which occur in the guard, consequent, beneath an existential, or in a recursion
update. Two existential witnesses and one equality motive confirm that their
validation remains strict. Thirteen explicit zero repairs are checked in total.

INDEPENDENCE AND PROVENANCE

named_oracle.py is an exact, attributed copy of validation/oracle.py in the
current goal-only draft. See provenance.json for its repository commit, ZIP
identity, and SHA-256. It imports no candidate code. It has an explicit syntax
validator and rule interpreter. Its substitution proceeds by decoding de Bruijn
indices to unique named binders, replacing named free parameters, and encoding
indices again; it does not use the candidate's cutoff recursion or binding
signature table.

The fixture labels are judgments made from the mathematical rules. The source
oracle is checked against those labels as well as the actual candidate. The
candidate is imported only for direct substitution comparisons. Exactly the
same JSON certificates go to the source oracle and the strict checker: no
certificate translator or trusted adapter is involved. Constructor and rule
names match the frozen current source at

    comparison/sources/ipra_goal_only_2026-11-06/checker.py

The scripts and expected cases are outside the proof-acceptance path. The
scripts write results/independent_strict.json, results/independent_cases.json,
results/demand_policy.json, and results/demand_policy_cases.json. Evidence
records include source hashes and all individual CLI verdicts.

WHY THE IMPLEMENTATION CHANGES PRESERVE RULE SELECTION

The strict checker's syntax validation runs before pattern matching. Therefore:

1. A valid formula represented by a two-entry array can only be existential.
2. A valid formula whose first child is a four-entry array can only be equality
   with a recursor on its left: compound formula constructors have two or three
   entries, and a four-entry term constructor is exactly the recursor.
3. Zero is the only false-valued well-formed term. Positive variable indices and
   successor/recursor arrays are truthy. Boolean, float, and malformed counters
   have already been rejected. Hence `if n` and `if n != 0` select the same case.
4. A malformed atomic value which fails the nonnegative-integer term test cannot
   become valid by falling through to constructor destructuring. There are no
   zero-argument array constructors which could validate an iterable string
   leaf. Unknown tags, wrong sorts, and wrong arities fail the signature lookup
   or strict child traversal.

These are finite-grammar arguments, not conclusions inferred merely from the
tests. They justify the discarded redundant literal-tag checks. The named
binding comparisons and focused rejection fixtures check the actual code
against the remaining high-risk details of those arguments.

LIMITS

These tests are finite and deterministic. They do not establish the universal
soundness, completeness, bi-interpretability, or consistency metatheorems, and
they are not a Lean or Rocq formalization. The paper supplies mathematical
arguments for those claims. Runtime resource exhaustion can reject very large
certificates, just as it can for the comparison programs; no finite execution
test proves implementation behavior beyond the available resources.
