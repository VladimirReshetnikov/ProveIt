"""Independent public-boundary and named-binder audit for the iPRA kernel.

The oracle uses an attributed, frozen named-variable implementation.  This
driver constructs labeled examples from the mathematical rules, serializes
them through JSON, and invokes the actual candidate command line.  It imports
the candidate only for substitution comparisons, never to derive verdicts or
expected substitutions.  All support here is outside the trusted checker.
"""

import argparse
import hashlib
import importlib.util
import json
import random
import subprocess
import sys
import tempfile
from collections import Counter
from pathlib import Path

import named_oracle as oracle

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
SEED = 2026110607


def eq(a, b):
    return ["=", a, b]


def succ(a):
    return ["s", a]


def rec(n, a, h):
    return ["r", n, a, h]


def refl(t):
    computation = eq(rec(0, t, 0), t)
    motive = eq(1, oracle.subst(t, formula=False))
    return [computation, [], motive, []]


def fixtures():
    result = []

    def add(name, expected, goal, proof, *context, mutation_of=None, reason=""):
        result.append({"name": name, "expected": expected,
                       "data": [goal, proof, *context],
                       "reason": reason, "mutation_of": mutation_of})

    truth = eq(0, 0)
    contradiction = eq(0, succ(0))
    add("hypothesis", True, truth, None, truth,
        reason="The goal occurs in the retained context.")
    add("irrelevant-leaf-payload", True, truth, {"unused": [None]}, truth,
        reason="A non-rule proof object may certify hypothesis membership.")
    add("contradiction-without-premises", False, contradiction, None,
        reason="There is no hypothesis or computation proving the contradiction.")
    add("reflexivity-needs-a-derivation", False, truth, None,
        reason="Reflexivity is derived, not a primitive leaf axiom.")
    add("derived-reflexivity", True, truth, refl(0),
        reason="A zero computation transports itself to reflexivity.")
    add("derived-reflexivity-sparse-parameter", True, eq(37, 37), refl(37),
        reason="The same derivation works with a sparse free-parameter index.")

    for index, initial in enumerate((0, succ(4), rec(3, 0, succ(1)))):
        left = rec(0, initial, rec(2, 1, succ(3)))
        name = "zero-computation-%d" % index
        add(name, True, eq(left, initial), [],
            reason="The zero computation returns the initializer.")
        add(name + "-wrong-result", False, eq(left, succ(initial)), [],
            mutation_of=name, reason="The result was changed to a distinct syntax tree.")

    updates = (1, 2, rec(3, rec(2, 1, 4), rec(2, 3, succ(5))))
    for index, update in enumerate(updates):
        left = rec(succ(1), 2, update)
        right = oracle.subst(update, [rec(1, 2, update), 1, -2], formula=False)
        name = "successor-computation-%d" % index
        add(name, True, eq(left, right), [],
            reason="Named substitution supplies the old value and predecessor simultaneously.")
        add(name + "-wrong-result", False, eq(left, succ(right)), [],
            mutation_of=name, reason="The expected successor-computation result was changed.")

    add("variable-counter-cannot-compute", False, eq(rec(1, 0, 1), 0), [],
        reason="A free counter is neither the zero constructor nor a successor node.")
    add("nested-counter-is-not-normalized", False,
        eq(rec(rec(0, 0, 0), 0, 1), 0), [],
        reason="The primitive computation axiom does not perform recursive normalization.")
    add("computation-certificate-required", False, eq(rec(0, 0, 0), 0), None,
        reason="This equality is not an assumption and the computation certificate is absent.")
    add("unused-update-is-still-validated", False,
        eq(rec(0, 0, ["ex", truth]), 0), [],
        reason="An unused recursion update must nevertheless be a well-formed term.")

    identity = ["pi", eq(1, 1), eq(1, 1)]
    add("ordinary-introduction", True, identity, [None],
        reason="Its guard differs from the literal zero instance of the body.")
    add("introduction-retains-shifted-parameter", True,
        ["pi", eq(1, 1), eq(2, 0)], [None], eq(1, 0),
        reason="The free parameter in the retained assumption shifts past the new binder.")
    add("introduction-capture-rejected", False,
        ["pi", eq(1, 1), eq(1, 0)], [None], eq(1, 0),
        mutation_of="introduction-retains-shifted-parameter",
        reason="The new eigenvariable cannot replace the old free parameter.")
    add("introduction-missing-child", False, identity, [],
        reason="A guarded introduction requires one child derivation.")
    add("introduction-extra-child", False, identity, [None, None],
        reason="An extra child does not form a guarded introduction or an applicable elimination.")

    for index, witness in enumerate((0, 1, succ(3), rec(2, 0, succ(1)))):
        goal = ["ex", eq(1, oracle.subst(witness, formula=False))]
        add("existential-introduction-%d" % index, True, goal, [witness, None],
            reason="The local witness equation is exactly the existential matrix.")
    existence = ["ex", eq(1, 0)]
    add("existential-short-certificate", False, existence, [0],
        reason="Existential introduction needs a witness and child.")
    add("existential-extra-certificate", False, existence, [0, None, None],
        reason="An extra entry is not an existential introduction.")
    add("existential-wrong-witness", False, existence, [succ(0), None],
        reason="The witness equation does not equal the matrix.")
    add("existential-witness-capture", False, ["ex", eq(1, 1)], [1, None],
        reason="The free witness index is lifted; it is not the new bound variable.")

    body = eq(rec(1, 0, succ(1)), 1)
    step_left = rec(succ(1), 0, succ(1))
    motive = eq(oracle.subst(step_left, formula=False), succ(1))
    induction = ["pi", oracle.subst(body, [0, 0]), body]
    child = [body, None, motive, []]
    add("equation-induction", True, induction, [child],
        reason="The successor proof transports the induction equation through successor.")
    add("equation-induction-missing-step", False, induction, [None],
        mutation_of="equation-induction",
        reason="The induction hypothesis is not itself the requested successor equation.")
    constant_compound = ["ex", eq(1, 1)]
    add("constant-compound-collision", True,
        ["pi", constant_compound, constant_compound], [None],
        reason="In a constant numerical case, the retained base assumption proves the step.")
    compound = ["ex", eq(1, 2)]
    compound_goal = ["pi", oracle.subst(compound, [0, 0]), compound]
    add("compound-cases", True, compound_goal, [[succ(1), None]],
        reason="At a successor, that successor itself is the existential witness.")
    add("compound-induction-is-not-available", False, compound_goal,
        [[compound, None, [succ(2), None]]], mutation_of="compound-cases",
        reason="The compound branch retains B(0), never the unlicensed induction hypothesis B(n).")
    add("automatic-branch-cannot-be-ignored", False,
        ["pi", eq(0, 0), eq(1, 0)], [None],
        reason="A matching base guard selects a successor premise automatically.")

    witness = rec(0, succ(0), 0)
    add("guarded-elimination", True, eq(witness, witness),
        [identity, [None], witness, refl(witness)],
        reason="Universal elimination instantiates both guard and body with the same term.")
    vacuous = ["pi", truth, truth]
    add("vacuous-guarded-elimination", True, truth,
        [vacuous, [None], 0, None], truth,
        reason="A valid vacuous witness is allowed.")
    add("equality-transport", True, eq(succ(1), 0),
        [eq(1, succ(1)), None, eq(1, 0), None], eq(1, succ(1)), eq(1, 0),
        reason="The premise and target are the two instances of one formula motive.")
    nested_motive = ["ex", eq(rec(2, 0, succ(1)), 2)]
    source = oracle.subst(nested_motive, [1, -1])
    target = oracle.subst(nested_motive, [succ(1), -1])
    add("transport-below-logical-and-recursion-binders", True, target,
        [eq(1, succ(1)), None, nested_motive, None], eq(1, succ(1)), source,
        reason="The equality motive crosses both one-variable and two-variable binders.")
    add("existential-elimination", True, truth,
        [existence, None, refl(0)], existence,
        reason="The local existential witness is fresh for the retained conclusion.")
    add("existential-eigenvariable-escape", False, eq(1, 0),
        [existence, None, None], existence, mutation_of="existential-elimination",
        reason="The conclusion's old free variable is shifted and cannot become the opened witness.")
    add("failed-major-hypothesis-fallback", True, truth,
        [contradiction, None, 0, None], truth,
        reason="A false well-formed major permits the final hypothesis-membership alternative.")
    add("failed-major-without-hypothesis", False, truth,
        [contradiction, None, 0, None],
        reason="A failed major cannot establish a new conclusion.")
    add("malformed-major-has-no-fallback", False, truth,
        [["=", True, 0], None, 0, None], truth,
        reason="Malformed source syntax raises before hypothesis fallback.")

    for index, bad in enumerate((None, False, 0.0, -1, [], eq(0, 0))):
        add("invalid-vacuous-universal-witness-%d" % index, False, truth,
            [vacuous, [None], bad, None], truth,
            reason="Witness terms must be formed even when the bound variable is unused.")
        add("invalid-existential-witness-%d" % index, False, existence,
            [bad, None], reason="Existential witnesses are checked as terms.")

    for label, major, proof, args, goal, context in (
            ("universal", vacuous, [None], [0, None], truth, [truth]),
            ("equality", truth, None, [truth, None], truth, [truth]),
            ("existential", existence, None, [refl(0)], truth, [existence])):
        add(label + "-elimination-short", False, goal,
            [major, proof, *args[:-1]], *context,
            reason="A successfully proved major selects elimination, whose required arguments are missing.")
        add(label + "-elimination-long", False, goal,
            [major, proof, *args, None], *context,
            reason="A successfully proved major selects elimination, whose argument count is exact.")

    malformed = (
        None, False, 0, 1.0, {}, [],
        ["="], ["=", 0, 0, 0], ["=", True, 0], ["=", -1, 0],
        ["=", ["s", 0, 1], 0], ["=", ["r", 0, 0], 0],
        ["pi", truth, truth, truth], ["pi", 0, truth], ["ex", 0],
    )
    for index, bad in enumerate(malformed):
        add("malformed-goal-%d" % index, False, bad, None, truth,
            reason="Public goals must belong to the formula grammar.")
        add("malformed-unused-assumption-%d" % index, False,
            truth, refl(0), bad,
            reason="The public boundary validates every retained assumption, including unused ones.")
    for tag in ("01", "001"):
        add("unknown-signature-" + tag, False, [tag, 0, 0], None, truth,
            reason="A string of scope digits is not automatically an allowed constructor.")
    assert len(result) == 100, len(result)
    return result


def random_term(rng, depth):
    if depth == 0 or rng.randrange(3) == 0:
        return rng.choice((0, 1, 2, 3, 4, 7, 17, 37))
    if rng.randrange(2):
        return succ(random_term(rng, depth - 1))
    return rec(*(random_term(rng, depth - 1) for _ in range(3)))


def random_formula(rng, depth):
    if depth == 0 or rng.randrange(3) == 0:
        return eq(random_term(rng, 3), random_term(rng, 3))
    if rng.randrange(2):
        return ["ex", random_formula(rng, depth - 1)]
    return ["pi", random_formula(rng, depth - 1), random_formula(rng, depth - 1)]


def anchors():
    """Literal expected outputs, hand checked independently of both algorithms."""
    return [
        (eq(1, 2), [succ(0), -1], 0, True, eq(succ(0), 1)),
        (["ex", eq(1, 2)], [succ(0), -1], 0, True,
         ["ex", eq(1, succ(0))]),
        (["pi", eq(1, 2), ["ex", eq(2, 3)]], [succ(0), -1], 0, True,
         ["pi", eq(1, succ(0)), ["ex", eq(2, succ(0))]]),
        (rec(1, 2, rec(2, 1, succ(3))), [succ(0), -1], 0, False,
         rec(succ(0), 1, rec(2, 1, succ(3)))),
        (rec(2, 1, succ(3)), [7, 8, -2], 0, False, rec(8, 7, succ(9))),
        (eq(1, 2), [succ(0), -1], 1, True, eq(1, succ(0))),
        (rec(4, 1, succ(6)), [7, -1], 3, False, rec(10, 1, succ(12))),
        (["ex", eq(rec(2, 3, succ(4)), 1)], [succ(1), 0], 0, True,
         ["ex", eq(rec(succ(2), 3, succ(succ(4))), 1)]),
    ]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checker", type=Path, nargs="?", default=PROJECT / "checker.py")
    parser.add_argument("--output", type=Path, default=PROJECT / "results")
    options = parser.parse_args()
    candidate_path = options.checker.resolve()
    options.output.mkdir(parents=True, exist_ok=True)
    candidate_bytes = candidate_path.read_bytes()
    spec = importlib.util.spec_from_file_location("audited_candidate", candidate_path)
    candidate = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(candidate)
    cases = fixtures()
    failures = []
    source_records = []
    cli_records = []
    coverage = Counter()
    readback_count = 0

    for case in cases:
        actual = oracle.accepted(case["data"])
        passed = actual == case["expected"]
        source_records.append({"name": case["name"], "expected": case["expected"],
                               "oracle": actual, "passed": passed})
        if actual:
            coverage.update(oracle.check(case["data"]))
        if not passed:
            failures.append({"stage": "oracle-label", **case, "oracle": actual})

    with tempfile.TemporaryDirectory(prefix="ipra_independent_audit_") as temporary:
        input_path = Path(temporary) / "proof.json"

        def cli(name, raw, expected, optimized=False, extra=()):
            input_path.write_text(raw, encoding="utf-8")
            command = [sys.executable, *(["-O"] if optimized else []),
                       str(candidate_path), str(input_path), *extra]
            run = subprocess.run(command, capture_output=True, text=True, timeout=15)
            passed = (run.returncode == (0 if expected else 1)
                      and run.stdout.strip() == ("ACCEPT" if expected else "REJECT"))
            row = {"name": name, "optimized": optimized, "expected": expected,
                   "exit_code": run.returncode, "stdout": run.stdout.strip(),
                   "passed": passed}
            cli_records.append(row)
            if not passed:
                failures.append({"stage": "public-cli", **row, "stderr": run.stderr})

        for case in cases:
            raw = json.dumps(case["data"], ensure_ascii=True, allow_nan=False)
            input_path.write_text(raw, encoding="utf-8")
            readback = json.loads(input_path.read_text(encoding="utf-8"))
            readback_count += 1
            if json.dumps(readback, ensure_ascii=True, allow_nan=False) != raw:
                failures.append({"stage": "json-readback", "name": case["name"]})
            cli(case["name"], raw, case["expected"])

        optimized_names = {
            "hypothesis", "derived-reflexivity", "zero-computation-0",
            "successor-computation-2", "ordinary-introduction", "equation-induction",
            "compound-cases", "existential-introduction-3", "guarded-elimination",
            "equality-transport", "existential-elimination",
            "compound-induction-is-not-available", "existential-eigenvariable-escape",
            "invalid-vacuous-universal-witness-1", "malformed-unused-assumption-1",
            "unknown-signature-01",
        }
        for case in cases:
            if case["name"] in optimized_names:
                cli(case["name"], json.dumps(case["data"]),
                    case["expected"], optimized=True)

        for name, raw in (("empty-json", ""), ("truncated-json", "["),
                          ("trailing-json", "[] []"), ("object-root", "{}"),
                          ("null-root", "null"), ("empty-input", "[]"),
                          ("missing-proof", json.dumps([eq(0, 0)]))):
            cli(name, raw, False)
        cli("extra-command-line-argument", json.dumps(cases[0]["data"]),
            False, extra=("unexpected",))

    rng = random.Random(SEED)
    environments = ((1,), (2,), (0, 0), (succ(1), 0),
                    (rec(1, 2, succ(1)), -1), (rec(1, 2, succ(1)), 7, -2))
    substitution_count = 0
    for is_formula in (False, True):
        for _ in range(24):
            expression = random_formula(rng, 3) if is_formula else random_term(rng, 4)
            for cutoff in (0, 1, 3):
                for env in environments:
                    expected = oracle.subst(expression, env, cutoff, is_formula)
                    actual = candidate.subst(expression, list(env), cutoff, is_formula)
                    substitution_count += 1
                    if actual != expected:
                        failures.append({"stage": "named-substitution",
                                         "expression": expression, "env": env,
                                         "cutoff": cutoff, "formula": is_formula,
                                         "expected": expected, "actual": actual})

    literal_anchors = anchors()
    for expression, env, cutoff, is_formula, expected in literal_anchors:
        independent = oracle.subst(expression, env, cutoff, is_formula)
        actual = candidate.subst(expression, env, cutoff, is_formula)
        if independent != expected or actual != expected:
            failures.append({"stage": "literal-substitution-anchor",
                             "expression": expression, "env": env, "cutoff": cutoff,
                             "expected": expected, "oracle": independent, "candidate": actual})

    report = {
        "passed": not failures,
        "checker": candidate_path.name,
        "checker_sha256": hashlib.sha256(candidate_bytes).hexdigest(),
        "oracle_sha256": hashlib.sha256((HERE / "named_oracle.py").read_bytes()).hexdigest(),
        "audit_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "python": sys.version, "seed": SEED,
        "rule_and_formation_cases": len(cases),
        "expected_acceptances": sum(case["expected"] for case in cases),
        "expected_rejections": sum(not case["expected"] for case in cases),
        "labeled_certificate_mutations": sum(case["mutation_of"] is not None for case in cases),
        "json_serialization_readbacks": readback_count,
        "public_cli_runs": len(cli_records),
        "optimized_cli_runs": sum(row["optimized"] for row in cli_records),
        "named_substitution_comparisons": substitution_count,
        "literal_substitution_anchors": len(literal_anchors),
        "accepted_fixture_rule_visits": dict(coverage),
        "source_oracle_results": source_records,
        "cli_results": cli_records,
        "failures": failures,
        "limitations": [
            "Finite deterministic checks; no exhaustive certificate search or formal metatheory.",
            "The public CLI runs replay the labeled fixtures; category counts overlap.",
            "Named substitution is a frozen, attributed implementation independent of the candidate's cutoff algorithm.",
            "Fixture labels are mathematical judgments; the oracle and candidate were checked against those labels.",
            "Exactly the same public JSON is supplied to the source oracle and the candidate; no certificate adapter is used.",
        ],
    }
    (options.output / "independent_strict.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8")
    (options.output / "independent_cases.json").write_text(
        json.dumps(cases, indent=2) + "\n", encoding="utf-8")
    keys = ("passed", "checker_sha256", "rule_and_formation_cases",
            "expected_acceptances", "expected_rejections", "public_cli_runs",
            "optimized_cli_runs", "named_substitution_comparisons", "literal_substitution_anchors")
    print(json.dumps({key: report[key] for key in keys}, indent=2))
    if failures:
        print(json.dumps(failures[:10], indent=2))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
