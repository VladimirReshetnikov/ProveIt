"""Focused public-CLI audit of the unused-universal-witness policy.

Run from any directory.  Defaults refer to the enclosing deliverable, not the
current working directory.  Both checkers are executed as separate programs.
The frozen independent named oracle verifies strict verdicts and every repair.
"""

import argparse
import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path

import named_oracle as oracle

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]


def eq(a, b):
    return ["=", a, b]


def contains_first_parameter(formula):
    """Identify free parameter 1 after decoding binders to unique identities."""
    def contains(tree):
        if type(tree) is not tuple:
            return False
        if tree[0] == "free":
            return tree[1] == 0
        return any(contains(child) for child in tree[1:])
    return contains(oracle.named(formula))


def fixtures():
    truth = eq(0, 0)
    cases = []

    def universal(name, major, target, annotation, expected_demand, reason):
        original = [target, [major, None, annotation, None], major, truth]
        repaired = [target, [major, None, 0, None], major, truth]
        uses_witness = any(contains_first_parameter(part) for part in major[1:])
        cases.append({"name": name, "kind": "universal", "data": original,
                      "expected_strict": False, "expected_demand": expected_demand,
                      "witness_occurs": uses_witness, "repair": repaired,
                      "expected_repaired_strict": True, "reason": reason})

    vacuous = ["pi", truth, truth]
    for index, bad in enumerate((None, False, 0.0, -1, [], eq(0, 0))):
        universal("vacuous-malformed-annotation-%d" % index, vacuous, truth, bad,
                  True, "The unused annotation can be replaced by the well-formed term 0.")

    # This completed demand evaluation contains an inner call which returns
    # False, not just the successful premises of the final fallback proof.
    # Repairing its unused witness must preserve that False return so the
    # strict checker reaches the same final hypothesis-membership alternative.
    unsuccessful_major = eq(["s", 0], ["s", 0])
    inner = [vacuous, None, {}, None]
    repaired_inner = [vacuous, None, 0, None]
    cases.append({
        "name": "failed-major-vacuous-annotation-before-fallback",
        "kind": "universal",
        "data": [truth, [unsuccessful_major, inner, None], vacuous, truth],
        "expected_strict": False,
        "expected_demand": True,
        "witness_occurs": any(contains_first_parameter(part) for part in vacuous[1:]),
        "repair": [truth, [unsuccessful_major, repaired_inner, None], vacuous, truth],
        "expected_repaired_strict": True,
        "reason": (
            "The demand check of the inner major returns False after evaluating a vacuous "
            "universal application with a malformed annotation. The outer goal is then a "
            "retained hypothesis. Replacing only that inner annotation by 0 preserves the "
            "False result and lets the strict checker reach the same successful fallback."
        ),
    })

    universal("used-in-guard", ["pi", eq(1, 0), truth], truth, None, False,
              "A witness occurring only in the guard must still be checked.")
    universal("used-in-consequent", ["pi", truth, eq(1, 1)], truth, False, False,
              "A witness occurring only in the consequent must still be checked.")
    universal("used-below-existential", ["pi", truth, ["ex", eq(1, 2)]],
              ["ex", eq(1, 0)], eq(0, 0), False,
              "Occurrence detection must pass the existential binder without capturing it.")
    universal("used-in-zero-counter-update",
              ["pi", truth, eq(["r", 0, 0, 3], 0)],
              eq(["r", 0, 0, 0], 0), -1, False,
              "The occurrence in a two-variable update counts even at a zero recursion counter.")

    existence = ["ex", eq(1, 0)]
    for index, bad in enumerate((None, False)):
        cases.append({"name": "existential-witness-remains-strict-%d" % index,
                      "kind": "existential", "data": [existence, [bad, None]],
                      "expected_strict": False, "expected_demand": False,
                      "repair": [existence, [0, None]], "expected_repaired_strict": True,
                      "reason": "The demand policy does not erase existential witnesses."})
    cases.append({"name": "malformed-equality-motive-remains-rejected",
                  "kind": "equality", "data": [truth, [truth, None, False, None], truth],
                  "expected_strict": False, "expected_demand": False,
                  "repair": None,
                  "reason": "Substitution still validates every equality motive as a formula."})
    return cases


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--strict", type=Path, default=PROJECT / "checker.py")
    parser.add_argument("--demand", type=Path, default=PROJECT / "checker_demand.py")
    parser.add_argument("--output", type=Path, default=PROJECT / "results")
    options = parser.parse_args()
    paths = {"strict": options.strict.resolve(), "demand": options.demand.resolve()}
    cases = fixtures()
    failures = []
    cli_records = []
    oracle_records = []

    with tempfile.TemporaryDirectory(prefix="ipra_demand_policy_") as temporary:
        input_path = Path(temporary) / "proof.json"

        def run(name, kind, data, expected):
            input_path.write_text(json.dumps(data, allow_nan=False), encoding="utf-8")
            completed = subprocess.run([sys.executable, str(paths[kind]), str(input_path)],
                                       text=True, capture_output=True, timeout=15)
            passed = (completed.returncode == (0 if expected else 1)
                      and completed.stdout.strip() == ("ACCEPT" if expected else "REJECT"))
            row = {"name": name, "checker": kind, "expected": expected,
                   "exit_code": completed.returncode, "stdout": completed.stdout.strip(),
                   "passed": passed}
            cli_records.append(row)
            if not passed:
                failures.append({"stage": "public-cli", **row, "stderr": completed.stderr})

        for case in cases:
            independent = oracle.accepted(case["data"])
            oracle_records.append({"name": case["name"], "repaired": False,
                                   "expected": case["expected_strict"], "actual": independent})
            if independent != case["expected_strict"]:
                failures.append({"stage": "strict-oracle-label", "name": case["name"]})
            if case["kind"] == "universal" and case["witness_occurs"] == case["expected_demand"]:
                failures.append({"stage": "named-vacuity", "name": case["name"]})
            for kind in paths:
                run(case["name"], kind, case["data"], case["expected_" + kind])
            if case["repair"] is not None:
                independent = oracle.accepted(case["repair"])
                oracle_records.append({"name": case["name"], "repaired": True,
                                       "expected": True, "actual": independent})
                if not independent:
                    failures.append({"stage": "strict-oracle-repair", "name": case["name"]})
                run(case["name"] + "-zero-repair", "strict", case["repair"], True)

    report = {
        "passed": not failures,
        "python": sys.version,
        "strict_sha256": hashlib.sha256(paths["strict"].read_bytes()).hexdigest(),
        "demand_sha256": hashlib.sha256(paths["demand"].read_bytes()).hexdigest(),
        "oracle_sha256": hashlib.sha256((HERE / "named_oracle.py").read_bytes()).hexdigest(),
        "driver_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "fixtures": len(cases),
        "vacuous_universal_differences": sum(case["expected_demand"] for case in cases),
        "used_universal_witness_rejections": sum(case.get("witness_occurs", False) for case in cases),
        "strict_zero_repairs": sum(case["repair"] is not None for case in cases),
        "public_cli_runs": len(cli_records),
        "oracle_results": oracle_records,
        "cli_results": cli_records,
        "failures": failures,
        "limitations": (
            "Focused finite examples of the stated erasure theorem. Acceptance differences are intentional. "
            "The general repair theorem is justified in the paper, not established by this finite test suite."
        ),
    }
    options.output.mkdir(parents=True, exist_ok=True)
    (options.output / "demand_policy.json").write_text(json.dumps(report, indent=2) + "\n")
    (options.output / "demand_policy_cases.json").write_text(json.dumps(cases, indent=2) + "\n")
    keys = ("passed", "fixtures", "vacuous_universal_differences", "used_universal_witness_rejections",
            "strict_zero_repairs", "public_cli_runs")
    print(json.dumps({key: report[key] for key in keys}, indent=2))
    if failures:
        print(json.dumps(failures, indent=2))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
