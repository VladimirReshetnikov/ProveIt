"""Rebuild the complete mathematical paper with pdfLaTeX."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    executable = shutil.which('pdflatex')
    if not executable:
        raise SystemExit('Install pdfLaTeX and the packages declared in report.tex.')
    build = ROOT / '.build'
    build.mkdir(exist_ok=True)
    command = [executable, '-interaction=nonstopmode', '-halt-on-error',
               '-file-line-error', '-output-directory=' + str(build), 'report.tex']
    for number in range(1, 4):
        completed = subprocess.run(command, cwd=ROOT, text=True,
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (build / f'pass-{number}.txt').write_text(completed.stdout)
        if completed.returncode:
            print(completed.stdout)
            raise SystemExit(completed.returncode)
    log = (build / 'report.log').read_text(errors='replace')
    failures = [line for line in log.splitlines()
                if 'undefined' in line.lower() or 'Overfull' in line
                or 'Rerun to get' in line]
    if failures:
        raise SystemExit('\n'.join(failures))
    shutil.copyfile(build / 'report.pdf', ROOT / 'report.pdf')
    print('Built report.pdf with resolved references and no overfull boxes.')


if __name__ == '__main__':
    main()
