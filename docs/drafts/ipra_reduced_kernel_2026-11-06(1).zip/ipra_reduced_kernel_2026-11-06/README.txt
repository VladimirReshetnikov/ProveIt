A SMALLER COMPLETE PROOF PRESENTATION OF iPRA
============================================
Prepared for Vladimir Reshetnikov -- 6 November 2026 (Pacific time)

RESULT

This package gives a complete presentation of full first-order intuitionistic
primitive recursive arithmetic and a strictly smaller proof checker than the
current finite corpus. The paper states every native axiom, schema, and rule,
derives all intuitionistic connectives and quantifier-free induction, and proves
whole-domain bi-interpretability with iPRA. Equality defines both internal
composite isomorphisms. Equiconsistency follows.

                                AST     Source    Normalized   Normalized   Raw
                               nodes    tokens      tokens       bytes     bytes
Current 13-program minimum       562       541         543         1688      1777
New strict open checker          549       535         539         1685      1735
New demand open checker          537       525         529         1640      1696

Every coordinate is a strict improvement. The minima are computed separately
across all thirteen current top-level variants in all six draft archives; older
baseline numbers quoted inside their reports are not used. The entire acceptance
program is counted, including syntax, binding, substitution, logical/arithmetic
rules, context validation, JSON input, filename argument checking, and rejection.
Only comments and docstrings are excluded from normalized metrics. Python and
its standard json/sys runtime are treated identically for all programs.

The smallest demand core also beats the current diagnostic envelope after all
imports and command-line blocks are removed: 472 AST / 472 normalized tokens /
1370 normalized bytes, versus minima 483 / 474 / 1376. Some baseline cores omit
context validation under that diagnostic, making it favorable to them. The
strict core does not beat this separate envelope in every coordinate.

This is a strict finite-corpus improvement, not an absolute minimality theorem.
The reduction preserves the existing mathematical basis and exact goal-only
certificate format. The arithmetic, logical reconstruction, and automatic-rule
completeness proofs are inherited and explicitly attributed. The new contribution
is a smaller complete checking implementation and its current-corpus comparison.

START HERE

report.pdf                     Complete research paper.
report.tex, sections/*.tex      Complete editable LaTeX source.
checker.py                     Strict standalone open-sequent checker.
checker_demand.py              Smallest companion; same consequence relation.
FORMAT.txt                     Exact JSON grammar, binders, rules and policies.
examples/                      Nineteen unchanged executable source certificates.
comparison/                    Thirteen exact baseline sources and pinned provenance.
validation/differential/        Portable comparisons and concrete seeded JSON corpus.
validation/independent/         Named-binder oracle and independent public-CLI audit.
results/                       Executed measurements and verification records.
reproduce.py                   Reproduce all Python evidence offline.
build.py                       Rebuild report.pdf with pdfLaTeX.
package.py                     Refresh the SHA-256 inventory and rebuild the ZIP.
ATTRIBUTION.txt                 Inherited and new contributions.
LICENSE_SOURCE.txt              Preserved source license.
MANIFEST.sha256                 Hash of every other packaged file.

QUICK START

Use Python 3.10 or newer; exact recorded AST normalization uses CPython 3.12.14.
From this package directory:

    python3 checker.py examples/reflexivity.json
    python3 checker.py examples/automatic_collision.json
    python3 checker_demand.py examples/residual.json
    python3 reproduce.py

All Python artifacts require only the standard library, with no network access.
The complete input is [goal, proof, hypothesis_0, hypothesis_1, ...]. Empty context
means a theorem; free number variables are arbitrary parameters. Acceptance prints
ACCEPT and exits 0. Rejection prints REJECT and exits nonzero. The checks remain
active under python -O. Use the public program for untrusted input.

The strict checker validates every selected numerical witness even when unused.
The demand checker omits only a redundant validation before universal/equality
instances are formed. A universal annotation absent from both matrices can be
ignored; replacing it with 0 gives the same strict inference. Equality motives
and existential witnesses retain their required validation. Both programs prove
the same well-formed sequents.

EXECUTED EVIDENCE

* All six downloaded archives verified against their Git blob identities.
* All thirteen complete source hashes checked before measurement.
* Per policy: 148 rule/formation fixtures, 19 examples, and the same 12,000
  concrete seeded JSON cases compared with the unchanged matching predecessor;
  zero discrepancies. Strict fixtures also match independent expected labels.
* Independent strict audit: 100 labeled cases (25 accept, 75 reject), 124 actual
  CLI runs including 16 optimized-Python runs, 864 named-variable substitution
  comparisons plus 8 literal anchors, and 100 JSON readbacks; zero failures.
* Demand-policy audit: 14 focused fixtures, 41 actual CLI runs, 7 intentional
  vacuous-witness differences, 4 used-witness rejections, and 13 explicit zero
  repairs accepted by strict checking and the named oracle; zero failures.

The categories overlap and are not counts of distinct theorems. These finite
tests supplement the paper's structural proofs. Soundness, completeness, and
bi-interpretability are written mathematical proofs, not a completed Lean/Rocq
formalization. Physical recursion, memory, and time limits can reject very large
otherwise valid finite certificates.

BUILD AND PACKAGE

    python3 build.py
    python3 package.py

The PDF build needs pdfLaTeX plus the packages listed in report.tex. The compiled
PDF is supplied, so TeX is not needed to check proofs or replay the Python evidence.
package.py excludes temporary build and Python bytecode files.

SOURCE SNAPSHOT

Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: fa581763b2bb75e8ba055da8e56280c9fd5dd890
Directory: docs/drafts

The exact archive and source identities are in comparison/manifest.json.
This deliverable is self-contained; no repository write is required to use it.
