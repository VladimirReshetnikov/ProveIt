# Local abundance in union-closed families

Open **union_closed_abundance.pdf** for the complete manuscript. Its LaTeX source is a single file, **union_closed_abundance.tex**. The results concern finite families of distinct finite sets. A point is abundant when its frequency is at least one half.

## Results

* Nine sharp local thresholds for prescribed co-singletons on five or six points, strictness in eight cases, and a stability inequality in the remaining case.
* A uniform asymptotic formula, including the bounded rounding term, for the same threshold in arbitrary dimension.
* The exact minimum number of missing sets for up to seven deficient coordinates, the unique minimizer, and a logarithmic multiplicity bound in every dimension.
* A quantitative gap above half for unions of translates, the sharp effective two-point constant, and a finite theorem for adding arbitrary large generators.

The computations below check finite certificates used in the proof. The general statements also use the mathematical arguments in the manuscript, including the published theorems it cites.

## Reproducing the results

From this directory on a system with Python 3.10 or newer and a C++20 compiler, run the following commands. The Python programs use only the standard library. Run Python with assertions enabled, as in the commands below.

```sh
c++ -std=c++20 -O2 code/verify_coatoms.cpp -o verify_coatoms
./verify_coatoms
python3 code/verify_coatoms_graphs.py
python3 code/local_constructions.py
python3 code/dense_check.py
python3 code/translate_check.py
```

* **verify_coatoms.cpp** certifies the integer inequalities and the equality types for the five- and six-point local problems.
* **verify_coatoms_graphs.py** checks the same lower bounds using a separate representation by graphs and loops. It generates its own graph isomorphism representatives and tries every placement of the distinguished labels.
* **local_constructions.py** checks every limiting marginal using exact rational arithmetic. It also constructs the 829-set example and verifies all pairwise unions.
* **dense_check.py** tests all labeled union-closed families up to four coordinates. A second calculation finds the minimum number of deletions up to four coordinates even when slices are allowed to vary independently.
* **translate_check.py** checks cyclic patterns through order 12, the two-orbit example on 20 points, and the integer part of the 50.2% theorem for every order from 21 to 9999.

The **verification/** directory contains the output from running all five programs. The recurrence in the manuscript handles the sharp two-point result in arbitrarily large groups. The entropy estimate covers orders from 10000 onward in the finite mixed-generator theorem.

## The concrete 829-set family

**data/five_point_example.txt** has one decimal integer per line, written as a bit mask. Bit position 0 is the least significant bit. The designated points labeled 1 through 5 in the paper have positions 0 through 4. The remaining 16 positions form successive blocks of sizes 3, 3, 3, 3 and 4. Two sets have union given by bitwise OR. Run the following to regenerate the file in a separate location.

```sh
python3 code/local_constructions.py --write-example example_copy.txt
```

## Rebuilding the paper

Use a standard TeX Live installation and compile twice to resolve internal references.

```sh
pdflatex union_closed_abundance.tex
pdflatex union_closed_abundance.tex
```
