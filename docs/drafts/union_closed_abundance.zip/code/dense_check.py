#!/usr/bin/env python3
"""Integer checks for the shortfall inequality and small-dimensional thresholds."""

from itertools import combinations, permutations


def union_closed(mask, cube_size):
    """Members of a family are represented by the set bits in mask."""
    members = [x for x in range(cube_size) if mask & (1 << x)]
    return all(mask & (1 << (a | b)) for a, b in combinations(members, 2))


def remove_dominated(vectors):
    """Retain coordinatewise maximal vectors. Equal vectors are interchangeable."""
    kept = []
    for v in sorted(set(vectors), key=sum, reverse=True):
        if not any(all(x <= y for x, y in zip(v, w)) for w in kept):
            kept.append(v)
    return kept


def check_dimension(n):
    cube_size = 1 << n
    full_mask = (1 << cube_size) - 1
    columns = [sum(1 << x for x in range(cube_size) if x & (1 << i))
               for i in range(n)]
    families = 0
    inequalities = 0
    profiles = [set() for _ in range(cube_size)]
    for mask in range(full_mask + 1):
        if not union_closed(mask, cube_size):
            continue
        families += 1
        d = cube_size - mask.bit_count()
        margins = tuple(mask.bit_count() - 2 * (mask & c).bit_count()
                        for c in columns)
        if 0 < d < cube_size:
            profiles[d].add(tuple(sorted(margins)))
        positive = [s for s in margins if s > 0]
        for r in range(2, len(positive) + 1):
            q = 1 << r
            for chosen in combinations(positive, r):
                maximum = max(chosen)
                assert (2*d-q)*(2*d+maximum) >= q*(sum(chosen)-maximum)
                assert d > q//2
                inequalities += 1
    return families, inequalities, profiles


def minimum_for_multiple_fibers(profiles, n):
    """Optimize over arbitrary collections of union-closed n-dimensional slices.

    The search includes collections with no union-closure relation across slices.
    At cost b, store sorted attainable shortfall vectors up to coordinatewise
    dominance. Relabeling coordinates permits every permutation of a new slice.
    The slice with just the empty set present guarantees a solution at 2**n-1.
    """
    limit = (1 << n) - 1
    options = [[] for _ in range(limit + 1)]
    for cost in range(1, limit + 1):
        for v in remove_dominated(profiles[cost]):
            options[cost].extend(set(permutations(v)))
    best = [[(0,) * n]]
    for total in range(1, limit + 1):
        possible = set()
        for cost in range(1, total + 1):
            for left in best[total - cost]:
                for right in options[cost]:
                    vector = tuple(sorted(x+y for x, y in zip(left, right)))
                    if vector[0] > 0:
                        return total
                    possible.add(vector)
        best.append(remove_dominated(possible))
    raise AssertionError("The explicit construction should give a solution.")


def check_examples():
    for n in range(3, 11):
        for r in range(2, n):
            cube = 1 << n
            family = [x for x in range(cube) if x == 0 or x >= 1 << r]
            margins = [len(family) - 2*sum(bool(x & (1 << i)) for x in family)
                       for i in range(n)]
            assert cube - len(family) == (1 << r) - 1
            assert margins[:r] == [1] * r
            assert all(s < 0 for s in margins[r:])


if __name__ == '__main__':
    for n in range(2, 5):
        count, tests, profiles = check_dimension(n)
        optimum = minimum_for_multiple_fibers(profiles, n)
        print(f"n={n}: {count} union-closed families, {tests} shortfall checks, "
              f"minimum missing sets over arbitrary collections of fibers: {optimum}")
    check_examples()
    print("Sharpness examples checked through dimension 10.")
