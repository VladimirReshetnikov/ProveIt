#!/usr/bin/env python3
"""Exact checks for the translate-union abundance estimates, in cyclic groups."""
from argparse import ArgumentParser
from fractions import Fraction
from math import comb


def rotate(mask, shift, n):
    return ((mask << shift) | (mask >> (n - shift))) & ((1 << n) - 1)


def translate_family(generators):
    members = {0}
    for generator in generators:
        members.update([member | generator for member in members])
    return members


def verify(n, pattern):
    translates = {rotate(pattern, shift, n) for shift in range(n)}
    period = n // len(translates)
    k = pattern.bit_count() // period
    family = translate_family(translates)
    count = len(family)
    hits = sum(member & 1 for member in family)
    excess = 2 * hits - count
    missing = count - hits
    assert (excess == 0) == (k == 1)
    first = next(iter(translates))
    full = sum((member & first) == first for member in family)
    assert full == missing
    if k >= 2:
        assert excess > 0
        if k == 2:
            assert 29 * hits >= 17 * count
        # stronger of an exponential switching and an elementary linear bound
        assert missing <= min(2 ** (k - 1) + 1, k + 1) * excess
        # z log2(z) <= 2(k-1), z = missing/excess - 1.
        # Raise 2 to a power and clear the rational denominator.
        z = Fraction(missing - excess, excess)
        if z > 1:
            a, b = z.as_integer_ratio()
            assert a ** a <= (b ** a) << (2 * (k - 1) * b)
    return count, hits, k


def check_two_orbit_example():
    # The entropy comparison in (T5), with no floating-point logarithms.
    assert 275 ** 275 < 2 ** 125 * 26 ** 26 * 249 ** 249
    n = 20
    small = sum(1 << i for i in (0, 1, 3, 7))
    large = sum(1 << (2 * i) for i in range(9))
    small_orbit = {rotate(small, j, n) for j in range(n)}
    large_orbit = {rotate(large, j, n) for j in range(n)}
    budget = sum(max(0, n // 2 - 9 - j) * comb(n - 9, j)
                 for j in range(n - 9 + 1))
    assert len(large_orbit) * budget < Fraction(n * 2 ** 5, 22)
    members = translate_family(small_orbit | large_orbit)
    hits = sum(member & 1 for member in members)
    assert (len(members), hits) == (27233, 18985)
    print(f'Two-orbit example on 20 points: {hits}/{len(members)}.')


def check_finite_mixed_bound():
    assert 275**1100 < 2**497 * 26**104 * 249**996
    for n in range(21, 10000):
        b = (9*n + 19) // 20
        v = 251*n - 500*b
        coefficient, deficit = 1, 0
        for j in range((v + 499) // 500):
            deficit += (v - 500*j) * coefficient
            coefficient = coefficient * (n-b-j) // (j+1)
        assert 11*deficit < 239 * 2**((n+3)//4)
    print("Finite 50.2% certificate checked for each n from 21 to 9999.")


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--max-n', type=int, default=12,
                        help='maximum cyclic group order for exhaustive checks (default 12)')
    args = parser.parse_args()
    if args.max_n < 1:
        parser.error('--max-n must be positive')
    patterns = 0
    representatives = 0
    for n in range(1, args.max_n + 1):
        seen = set()
        for mask in range(1, 1 << n):
            patterns += 1
            if mask in seen:
                continue
            seen.update(rotate(mask, shift, n) for shift in range(n))
            verify(n, mask)
            representatives += 1
    print(f'Cyclic groups of orders 1..{args.max_n}: {patterns} nonempty patterns, '
          f'{representatives} translate classes verified.')
    for n, elems in [(9, (0, 3, 6)), (6, (0, 1)), (8, (0, 1, 2)),
                     (7, (0, 1, 3)), (10, (0, 1, 3))]:
        count, hits, k = verify(n, sum(1 << i for i in elems))
        print(f'n={n}, R={elems}, k={k}, family={count}, hits={hits}, '
              f'p={Fraction(hits, count)}')

    check_two_orbit_example()
    check_finite_mixed_bound()


if __name__ == '__main__':
    main()
