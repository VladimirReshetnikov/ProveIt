#!/usr/bin/env python3
"""Exact upper certificates for local bounds, plus an explicit 21-point example."""
from argparse import ArgumentParser
from fractions import Fraction as F
from itertools import combinations
from math import ceil, floor
from pathlib import Path


def small_fiber(n, t, j):
    u = (1 << n) - 1
    return {s for s in range(u + 1) if s & j == s} | {u ^ (1 << i) for i in range(t)} | {u}


def target_mixture(n, t):
    """Mass on triples (size of J, size of J intersect I, mass)."""
    if n == 5:
        return {
            2: [(3, 1, F(1, 2)), (3, 2, F(1, 2))],
            3: [(3, 3, F(40, 97)), (4, 2, F(57, 97))],
            4: [(4, 3, F(80, 113)), (4, 4, F(33, 113))],
            5: [(5, 5, F(1))],
        }[t]
    if t == 6:
        return [(5, 5, F(1))]
    mean = F(t * (38 - t), 48)
    if mean.denominator == 1:
        return [(4, int(mean), F(1))]
    return [(4, floor(mean), ceil(mean) - mean), (4, ceil(mean), mean - floor(mean))]


def verify_mixture(n, t, target):
    local_labels = (1 << t) - 1
    marginal = [F(0)] * n
    total = F(0)
    for size, overlap, mass in target_mixture(n, t):
        choices = [j for j in range(1 << n)
                   if j.bit_count() == size and (j & local_labels).bit_count() == overlap]
        for j in choices:
            h = small_fiber(n, t, j)
            for i in range(n):
                marginal[i] += mass * F(sum(bool(s & (1 << i)) for s in h), len(h) * len(choices))
        total += mass
    assert total == 1 and marginal == [target] * n
    print(f"n={n}, t={t}: all {n} limiting frequencies equal {target}.")


def concrete_example():
    # Local points 0..4, prescribed sets missing 0..3 in turn.
    # Auxiliary coordinates are four 3-bit blocks and one 4-bit block.
    n, t = 5, 4
    u = (1 << n) - 1
    v = ((1 << 16) - 1) << n
    bottom = {0, u} | {u ^ (1 << i) for i in range(t)}
    family = bottom | {v | x for x in range(1 << n)}
    offset = n
    for i, (width, copies) in enumerate([(3, 7)] * 4 + [(4, 11)]):
        full = (1 << width) - 1
        block = full << offset
        local = small_fiber(n, t, u ^ (1 << i))
        # Integer order extends subset inclusion. These are all but the largest
        # member of an upward-closed final interval of size copies + 1.
        for y in range(full - copies, full):
            tag = (v ^ block) | (y << offset)
            family.update(tag | x for x in local)
        offset += width
    assert len(family) == 829
    assert all((a | b) in family for a, b in combinations(family, 2))
    counts = [sum(bool(s & (1 << i)) for s in family) for i in range(21)]
    assert counts[:5] == [411, 411, 411, 411, 412]
    print(f"Example: {len(family)} sets on 21 points, all unions checked; local counts {counts[:5]}.")
    return family


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--write-example", type=Path, help="write 21-bit integer masks, one per line")
    args = parser.parse_args()
    for n, row in [(5, ["5/11", "139/291", "391/791", "1/2"]),
                   (6, ["8/19", "53/120", "29/63", "21/44", "37/76"])]:
        for t, value in enumerate(row, 2):
            verify_mixture(n, t, F(value))
    example = concrete_example()
    if args.write_example:
        args.write_example.write_text("".join(f"{s}\n" for s in sorted(example)), encoding="ascii")
