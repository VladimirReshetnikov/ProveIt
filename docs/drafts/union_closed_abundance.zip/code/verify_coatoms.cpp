// Exact certificate for the five- and six-point coatom spectra.
// Build with: c++ -std=c++20 -O2 verify_coatoms.cpp -o verify_coatoms
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <limits>
#include <set>
#include <vector>

using Family = std::uint64_t;
using std::popcount;

struct Certificate {
    int n, t, weight_in, weight_out, target;
};

Family member(int mask) { return Family{1} << mask; }

class Verification {
    Certificate c;
    int top;
    std::vector<int> low;
    std::array<Family, 6> misses{};
    std::set<Family> zero_fibers;
    std::size_t count = 0;
    int minimum = std::numeric_limits<int>::max();
    int proper_surplus = std::numeric_limits<int>::max();

    // Form the family of all S union {i} over S in family.
    Family adjoin_point(Family family, int i) const {
        return (family & ~misses[i]) | ((family & misses[i]) << (1 << i));
    }

    // Visit once for each choice of generators from the small sets.
    void enumerate(std::size_t next, Family closure) {
        if (next < low.size()) {
            int x = low[next];
            enumerate(next + 1, closure);
            Family shifted = closure;
            for (int i = 0; i < c.n; ++i) {
                if (x & (1 << i)) shifted = adjoin_point(shifted, i);
            }
            enumerate(next + 1, closure | shifted | member(x));
            return;
        }
        Family fiber = closure | member(top);
        for (int i = 0; i < c.t; ++i) {
            if (closure & misses[i]) fiber |= member(top ^ (1 << i));
        }
        int score = -c.target * popcount(fiber);
        for (int i = 0; i < c.n; ++i) {
            int weight = i < c.t ? c.weight_in : c.weight_out;
            score += weight * popcount(fiber & ~misses[i]);
        }
        if (c.n == 5 && c.t == 5 && popcount(fiber) < 32) {
            int size_sum = 0;
            for (int i = 0; i < c.n; ++i) size_sum += popcount(fiber & ~misses[i]);
            proper_surplus = std::min(proper_surplus, 21 * size_sum - 53 * popcount(fiber));
        }
        minimum = std::min(minimum, score);
        if (score == 0) zero_fibers.insert(fiber);
        ++count;
    }

    // Cubes with a coatom layer, including only those with zero score.
    std::set<Family> predicted_zeros() const {
        std::set<Family> predicted;
        for (int j = 0; j <= top; ++j) {
            Family fiber = member(top);
            for (int i = 0; i < c.t; ++i) fiber |= member(top ^ (1 << i));
            for (int s = 0; s <= top; ++s) {
                if ((s & j) == s) fiber |= member(s);
            }
            int score = -c.target * popcount(fiber);
            for (int i = 0; i < c.n; ++i) {
                int weight = i < c.t ? c.weight_in : c.weight_out;
                score += weight * popcount(fiber & ~misses[i]);
            }
            if (score == 0) predicted.insert(fiber);
        }
        return predicted;
    }

public:
    explicit Verification(Certificate input) : c(input), top((1 << c.n) - 1) {
        for (int s = 0; s <= top; ++s) {
            if (popcount(static_cast<unsigned>(s)) <= 2) low.push_back(s);
            for (int i = 0; i < c.n; ++i) {
                if (!(s & (1 << i))) misses[i] |= member(s);
            }
        }
    }

    bool run() {
        enumerate(0, 0);
        bool classification = zero_fibers == predicted_zeros();
        bool antichain = true, balanced_possible = false;
        for (Family f : zero_fibers) {
            for (Family g : zero_fibers) {
                if (f != g && (f & g) == f) antichain = false;
            }
            bool balanced = true;
            for (int i = 1; i < c.n; ++i) {
                if (popcount(f & ~misses[i]) != popcount(f & ~misses[0])) balanced = false;
            }
            if (balanced) balanced_possible = true;
        }
        std::cout << c.n << " " << c.t << " " << count << " " << minimum << " "
                  << zero_fibers.size() << " " << classification << " "
                  << antichain << " " << balanced_possible << "\n";
        bool half_case = c.n == 5 && c.t == 5;
        if (half_case) std::cout << "proper (5,5) minimum surplus: " << proper_surplus << "\n";
        return (!half_case || proper_surplus == 0) && count == (std::size_t{1} << low.size()) && minimum == 0 &&
               classification && antichain && balanced_possible == half_case;
    }
};

int main() {
    std::vector<Certificate> certificates = {
        {5,2,11,11,25}, {5,3,112,123,278}, {5,4,152,183,391}, {5,5,2,2,5},
        {6,2,19,19,48}, {6,3,20,20,53}, {6,4,21,21,58}, {6,5,22,22,63},
        {6,6,38,38,111}
    };
    std::cout << "n t subcollections min_score zero_fibers cube_class antichain balanced\n";
    bool ok = true;
    for (Certificate c : certificates) {
        if (!Verification(c).run()) ok = false;
    }
    return ok ? 0 : 1;
}
