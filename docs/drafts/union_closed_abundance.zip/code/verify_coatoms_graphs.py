#!/usr/bin/env python3
"""Independent integer check using graphs, loops, and vertex relabeling."""
from itertools import combinations, permutations


ROWS = {
    5: {2: (11, 11, 25), 3: (112, 123, 278),
        4: (152, 183, 391), 5: (2, 2, 5)},
    6: {2: (19, 19, 48), 3: (20, 20, 53), 4: (21, 21, 58),
        5: (22, 22, 63), 6: (38, 38, 111)}
}


def underlying_graphs(n):
    """Generate an orbit representative for every labeled simple graph."""
    edges = list(combinations(range(n), 2))
    maps = []
    for p in permutations(range(n)):
        maps.append([1 << edges.index(tuple(sorted((p[i], p[j]))))
                     for i, j in edges])
    covered = set()
    for graph in range(1 << len(edges)):
        if graph in covered:
            continue
        ids = [i for i in range(len(edges)) if graph & (1 << i)]
        for permuted_edges in maps:
            covered.add(sum(permuted_edges[i] for i in ids))
        yield [edges[i] for i in ids]
    assert len(covered) == 1 << len(edges)


def verify(n):
    universe = (1 << n) - 1
    present = [sum(1 << s for s in range(1 << n) if s & (1 << i))
               for i in range(n)]
    top = 1 << universe
    rows = ROWS[n]
    # All placements of the prescribed labels must be tried for each
    # graph representative, since a graph relabeling may move them.
    settings = []
    for t, (a, b, d) in rows.items():
        for omitted in combinations(range(n), t):
            layer = sum(1 << (universe ^ (1 << i)) for i in omitted)
            settings.append((t, a, b, d, omitted, layer))
    minima = {t: 10**9 for t in rows}
    tested = {t: 0 for t in rows}
    min_proper_surplus = 10**9
    graph_count = 0
    for edges in underlying_graphs(n):
        graph_count += 1
        neighbors = [0] * n
        for i, j in edges:
            neighbors[i] |= 1 << j
            neighbors[j] |= 1 << i
        # A nonempty S is a union of selected low sets iff every isolated
        # vertex in the graph induced on S has a selected singleton (loop).
        isolated = [sum(1 << i for i in range(n)
                        if s & (1 << i) and not s & neighbors[i])
                    for s in range(1 << n)]
        for loops in range(1 << n):
            nonempty = sum(1 << s for s in range(1, 1 << n)
                           if not isolated[s] & ~loops)
            for empty_chosen in (0, 1):
                core = nonempty | empty_chosen
                reachable = sum(1 << (universe ^ (1 << i)) for i in range(n)
                                if core & ~present[i])
                for t, a, b, d, omitted, layer in settings:
                    fiber = core | top | (reachable & layer)
                    counts = [(fiber & col).bit_count() for col in present]
                    score = b * sum(counts) - d * fiber.bit_count()
                    if a != b:
                        score += (a-b) * sum(counts[i] for i in omitted)
                    if n == 5 and t == 5 and fiber.bit_count() < 32:
                        surplus = 21 * sum(counts) - 53 * fiber.bit_count()
                        min_proper_surplus = min(min_proper_surplus, surplus)
                    if score == 0:
                        # Singletons recover the candidate cube uniquely.
                        j = sum(1 << i for i in range(n)
                                if fiber & (1 << (1 << i)))
                        cube = sum(1 << s for s in range(1 << n)
                                   if not s & ~j)
                        assert fiber == (cube | layer | top)
                        size = j.bit_count()
                        if n == 5 and t == 3:
                            labels = sum(1 << i for i in omitted)
                            assert j == labels or (size == 4 and
                                                   (universe ^ j) & labels)
                        else:
                            target_size = {5: {2: 3, 4: 4, 5: 5},
                                           6: {2: 4, 3: 4, 4: 4, 5: 4, 6: 5}}
                            assert size == target_size[n][t]
                    minima[t] = min(minima[t], score)
                    tested[t] += 1
    assert graph_count == {5: 34, 6: 156}[n]
    for t in rows:
        print(n, t, graph_count, tested[t], minima[t])
        assert minima[t] == 0
    if n == 5:
        print('proper (5,5) minimum of 21 * total size - 53 * cardinality:',
              min_proper_surplus)
        assert min_proper_surplus == 0


if __name__ == '__main__':
    print('n t graph_orbits label_placements_tested minimum_score')
    verify(5)
    verify(6)
