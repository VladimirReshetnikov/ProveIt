#!/usr/bin/env python3
"""Exact finite checks of the sharp missing-pair entropy cap.

Enumerates every nonempty family on each labelled ground set of size 0..4.
Both the real-valued relaxation and the sharp odd-integer cap are checked
through integer powers, not logarithms. An extremizer is also checked for
every admissible parameter pair with family size at most 32 by default.
This is supporting verification, not a proof for arbitrary families.
"""

from __future__ import annotations

import argparse
from collections import Counter
import json
from math import prod
from pathlib import Path
import platform
import time


def multiplicities(family: list[int]) -> Counter[int]:
    result: Counter[int] = Counter()
    for index, a in enumerate(family):
        result[a] += 1
        for b in family[index + 1:]:
            result[a | b] += 2
    return result


def cap_data(n: int, bad: int) -> tuple[int, int, int]:
    """Return (j,k,T), using k=0 for exact union closure."""
    if not bad:
        return n, 0, 0
    k = 1
    while k * (k + 1) < bad:
        k += 1
    assert 1 <= k <= n - 1
    assert k * (k - 1) <= bad <= k * (k + 1)
    j = n - k
    total = n * n - bad - j * j
    assert total > 0
    assert k * (2 * j - 1) <= total <= k * (2 * j + 1)
    return j, k, total


def verify(family: list[int]) -> tuple[int, bool]:
    n = len(family)
    assert n > 0
    members = set(family)
    assert len(members) == n
    counts = multiplicities(family)
    assert sum(counts.values()) == n * n
    inside = sorted(counts[a] for a in family)
    outside = [r for s, r in counts.items() if s not in members]
    assert all(r > 0 and r % 2 == 1 for r in inside)
    assert all(r >= 2 and r % 2 == 0 for r in outside)
    bad = sum(outside)
    assert bad % 2 == 0 and 0 <= bad <= n * (n - 1)
    j, k, total = cap_data(n, bad)

    prefix = 0
    for ell, value in enumerate(inside, 1):
        prefix += value
        assert prefix <= ell * ell, (family, "prefix", ell)
        if bad and ell > j:
            assert k * prefix <= k * j * j + (ell - j) * total
    assert prefix == n * n - bad

    actual = prod(r ** r for r in counts.values())
    initial = prod((2 * i - 1) ** (2 * i - 1) for i in range(1, j + 1))
    if not bad:
        sharp_right = initial
    else:
        # First check the intermediate cap with a real-valued plateau.
        left = actual * k ** total
        right = initial * total ** total * 2 ** bad
        assert left >= right, (family, bad, "relaxed", (j, k, total))
        # Internal multiplicities are odd. Their sharp balanced tail lies
        # on the two adjacent odd integers 2*j-1 and 2*j+1.
        upper = (k * (k + 1) - bad) // 2
        assert 0 <= upper <= k
        assert 2 * upper == k * (k + 1) - bad
        low_value, high_value = 2 * j - 1, 2 * j + 1
        sharp_right = (initial * low_value ** ((k - upper) * low_value)
                       * high_value ** (upper * high_value) * 2 ** bad)
        assert sharp_right * k ** total >= right
    assert actual >= sharp_right, (family, bad, "sharp", (j, k, total))
    return bad, actual == sharp_right


def sharp_family(n: int, bad: int) -> list[int]:
    if not bad:
        return [(1 << i) - 1 for i in range(n)]
    j, k, _ = cap_data(n, bad)
    upper = (k * (k + 1) - bad) // 2
    lower = k - upper
    base = (1 << (j - 1)) - 1
    central = 1 << (j - 1)
    chain = [(1 << i) - 1 for i in range(1, j)]
    distinguished = base | central
    branches = [base | (1 << (j + i)) for i in range(lower)]
    above = [base | central | (1 << (j + lower + i)) for i in range(upper)]
    family = chain + [distinguished] + branches + above
    assert len(family) == n and len(set(family)) == n
    return family


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--max-ground", type=int, default=4)
    parser.add_argument("--sharp-max-size", type=int, default=32)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if not 0 <= args.max_ground <= 4:
        parser.error("--max-ground must be between 0 and 4")
    start = time.perf_counter()
    levels = []
    for ground in range(args.max_ground + 1):
        universe = 1 << ground
        tested = union_closed = equality = nonclosed_equality = 0
        for family_mask in range(1, 1 << universe):
            family = [s for s in range(universe) if (family_mask >> s) & 1]
            bad, sharp = verify(family)
            tested += 1
            union_closed += bad == 0
            equality += sharp
            nonclosed_equality += sharp and bad > 0
        levels.append({
            "ground_size": ground,
            "families_tested": tested,
            "union_closed_families": union_closed,
            "sharp_entropy_equalities": equality,
            "non_union_closed_sharp_equalities": nonclosed_equality,
            "passed": True,
        })

    sharp_checks = 0
    for n in range(2, args.sharp_max_size + 1):
        for requested_bad in range(0, n * (n - 1) + 1, 2):
            bad, sharp = verify(sharp_family(n, requested_bad))
            assert bad == requested_bad and sharp
            sharp_checks += 1

    report = {
        "claim": "Exact maximum union entropy at fixed family size and failed ordered-pair count",
        "method": "Exhaustive family enumeration, integer prefix checks, integer product inequalities, and all-parameter extremizers",
        "python_version": platform.python_version(),
        "levels": levels,
        "total_exhaustive_families": sum(level["families_tested"] for level in levels),
        "sharp_construction_parameter_pairs": sharp_checks,
        "sharp_max_size": args.sharp_max_size,
        "elapsed_seconds": round(time.perf_counter() - start, 3),
        "passed": True,
        "scope": "Finite supporting checks only; the general proof is in the manuscript.",
    }
    rendered = json.dumps(report, indent=2) + "\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")


if __name__ == "__main__":
    main()
