#!/usr/bin/env python3
"""Reproduce finite checks for sharp union entropy and frequency bounds.

The combinatorial checks use exact integers.  Entropy order comparisons for
two inputs use products prod r**r, so those comparisons are exact too.
Only the abundance comparisons and the displayed table use interval arithmetic.

Requires Python >= 3.10 and mpmath >= 1.3.  Run:
    python3 verify_union_bounds.py --output-dir results

These finite checks supplement mathematical proofs; they do not prove Frankl's
conjecture and do not independently verify Jiang's external scalar certificate.
"""

from __future__ import annotations

import argparse
from collections import Counter
from fractions import Fraction
from functools import lru_cache
from itertools import combinations
import json
import math
from pathlib import Path
import random
import time

from mpmath import iv

iv.dps = 70
PHI = (1 + iv.sqrt(5)) / 2
PSI = 1 - 1 / PHI
JIANG_C = iv.mpf(1531541) / 4000000
JIANG_M = iv.mpf(2468459) / 4000000
JIANG_W0 = iv.mpf(8102221) / 10000000
JIANG_K = JIANG_M * JIANG_W0
LIMIT_DEFICIT = iv.ln(2) - iv.mpf(1) / 2


def interval_fraction_endpoint(x, upper=False):
    sign, mantissa, exponent, _bitcount = x._mpi_[int(upper)]
    value = Fraction((-1 if sign else 1) * mantissa)
    return value * (2 ** exponent) if exponent >= 0 else value / (2 ** -exponent)


def fixed_decimal(integer, places):
    sign = "-" if integer < 0 else ""
    digits = str(abs(integer)).zfill(places + 1)
    return f"{sign}{digits[:-places]}.{digits[-places:]}" if places else sign + digits


def enclosure(x, places=18):
    """Convert binary endpoints to decimal endpoints, rounding outwards."""
    scale = 10 ** places
    lo = interval_fraction_endpoint(x) * scale
    hi = interval_fraction_endpoint(x, True) * scale
    lower = lo.numerator // lo.denominator
    upper = -(-hi.numerator // hi.denominator)
    return {"lower": fixed_decimal(lower, places), "upper": fixed_decimal(upper, places)}


def interval_at_most_fraction(x, y):
    return interval_fraction_endpoint(x, True) <= y


def is_union_closed(family):
    members = set(family)
    return all(a | b in members for a in family for b in family)


def is_chain(family):
    return all((a | b) == a or (a | b) == b for a, b in combinations(family, 2))


def incomparable_pairs(family):
    return [(a, b) for a, b in combinations(family, 2)
            if (a | b) != a and (a | b) != b]


def is_terminal_fork(family):
    pairs = incomparable_pairs(family)
    if len(pairs) != 1:
        return False
    a, b = pairs[0]
    top = 0
    for member in family:
        top |= member
    return (a | b) == top


def union_counts(family, order):
    counts = Counter({a: 1 for a in family})
    for _ in range(1, order):
        new = Counter()
        for a, multiplicity in counts.items():
            for b in family:
                new[a | b] += multiplicity
        counts = new
    return [counts[a] for a in family]


def chain_counts(size, order):
    return [j ** order - (j - 1) ** order for j in range(1, size + 1)]


def fork_counts(size):
    assert size >= 3
    return list(range(1, 2 * size - 6, 2)) + [2 * size - 5, 2 * size - 5, 2 * size + 1]


def entropy_product(counts):
    return math.prod(count ** count for count in counts)


@lru_cache(None)
def chain_entropy_product(size):
    return entropy_product(chain_counts(size, 2))


@lru_cache(None)
def fork_entropy_product(size):
    return entropy_product(fork_counts(size))


@lru_cache(None)
def direct_deficit(size):
    n = iv.mpf(size)
    return sum(iv.mpf(2 * j - 1) * iv.ln(iv.mpf(2 * j - 1) / n)
               for j in range(1, size + 1)) / (n * n)


def deficit_interval(size):
    if size <= 10000:
        return direct_deficit(size), "direct outward-rounded logarithmic sum"
    n = iv.mpf(size)
    error_upper = (LIMIT_DEFICIT + (1 + iv.ln(n - 1)) / 12) / (n * n)
    lo = interval_fraction_endpoint(LIMIT_DEFICIT - error_upper)
    hi = interval_fraction_endpoint(LIMIT_DEFICIT, True)
    # iv.mpf([numerator/denominator,...]) would convert via a Python float.
    low_interval = iv.mpf(lo.numerator) / lo.denominator
    high_interval = iv.mpf(hi.numerator) / hi.denominator
    d = iv.make_mpf((low_interval._mpi_[0], high_interval._mpi_[1]))
    return d, "certified midpoint-remainder bound"


@lru_cache(None)
def frequency_bounds(size):
    d = direct_deficit(size)
    logn = iv.ln(size)
    return PSI + d / (PHI * logn), JIANG_C + JIANG_K * d / logn


def check_family(family, stats, exact_entropy=True):
    """All input families here are nonempty, with at least two members."""
    size = len(family)
    assert size >= 2
    assert is_union_closed(family)
    chain = is_chain(family)
    stats["families_checked"] += 1
    stats["chains_checked"] += int(chain)
    for order in (2, 3, 4):
        counts = union_counts(family, order)
        baseline = chain_counts(size, order)
        assert sum(counts) == size ** order
        running = 0
        for k, count in enumerate(sorted(counts), 1):
            running += count
            assert running <= k ** order, (family, order, k)
        assert (sorted(counts) == baseline) == chain, (family, order)
        stats["exact_majorization_checks"] += 1
        if order != 2:
            continue
        assert all(r % 2 == 1 for r in counts)
        square_total = sum(r * r for r in counts)
        chain_square_total = size * (4 * size * size - 1) // 3
        assert square_total >= chain_square_total
        assert (square_total == chain_square_total) == chain
        pairs = incomparable_pairs(family)
        if not chain:
            assert square_total >= chain_square_total + 16
            assert square_total >= chain_square_total + 8 * len(pairs) + 8
            if square_total < chain_square_total + 16 * len(pairs):
                stats["strong_collision_16I_counterexamples"] += 1
                if "first_strong_collision_16I_counterexample" not in stats:
                    stats["first_strong_collision_16I_counterexample"] = {
                        "family": family, "incomparable_pair_count": len(pairs),
                        "square_gap": square_total - chain_square_total,
                    }
            assert (square_total == chain_square_total + 16) == (len(pairs) == 1)
        # A linear extension is obtained by sorting sets by size then bitmask.
        ordered = sorted(zip(family, counts), key=lambda item: (item[0].bit_count(), item[0]))
        q = chain_counts(size, 2)
        running = 0
        escapes = []
        for k, (_member, count) in enumerate(ordered, 1):
            running += count
            escapes.append(k * k - running)
        exact_identity_rhs = sum((r - s) ** 2 for (_a, r), s in zip(ordered, q)) + 4 * sum(escapes)
        assert square_total - chain_square_total == exact_identity_rhs
        stats["exact_collision_checks"] += 1
        if exact_entropy:
            product = entropy_product(counts)
            assert product >= chain_entropy_product(size)
            assert (product == chain_entropy_product(size)) == chain
            stats["exact_entropy_order_checks"] += 1
            if not chain:
                assert product >= fork_entropy_product(size), (family, sorted(counts))
                assert (product == fork_entropy_product(size)) == is_terminal_fork(family)
                stats["exact_second_extremum_checks"] += 1
    top = 0
    for member in family:
        top |= member
    max_count = max(sum(bool(a & (1 << bit)) for a in family)
                    for bit in range(top.bit_length()))
    p = Fraction(max_count, size)
    boppana, jiang = frequency_bounds(size)
    assert interval_at_most_fraction(boppana, p), (family, "Boppana")
    assert interval_at_most_fraction(jiang, p), (family, "Jiang")
    stats["interval_frequency_checks"] += 2


def new_stats():
    return {"families_checked": 0, "chains_checked": 0,
            "exact_majorization_checks": 0, "exact_collision_checks": 0,
            "exact_entropy_order_checks": 0, "exact_second_extremum_checks": 0,
            "interval_frequency_checks": 0,
            "strong_collision_16I_counterexamples": 0}


def exhaustive_checks():
    results = []
    for n in range(1, 5):
        stats = new_stats()
        stats["ground_set_size"] = n
        stats["subfamilies_enumerated"] = 1 << (1 << n)
        stats["union_closed_including_empty_family"] = 0
        for family_mask in range(1 << (1 << n)):
            family = [a for a in range(1 << n) if family_mask & (1 << a)]
            if not is_union_closed(family):
                continue
            stats["union_closed_including_empty_family"] += 1
            if len(family) >= 2:
                check_family(family, stats)
        results.append(stats)
    return results


def closure(generators):
    family = {0}
    for generator in generators:
        family |= {member | generator for member in family}
    return sorted(family)


def random_checks(seed=20261125, count=60):
    rng = random.Random(seed)
    stats = new_stats()
    stats["seed"] = seed
    stats["sampling"] = "OR closure of independently sampled generator masks, with optional removal of the empty set"
    stats["examples"] = []
    for trial in range(count):
        n = rng.choice([5, 6, 7, 8, 9, 10, 11, 12])
        generator_count = rng.randint(2, 9)
        density = rng.choice([0.2, 0.35, 0.5, 0.65, 0.8])
        generators = [sum((1 << j) for j in range(n) if rng.random() < density)
                      for _ in range(generator_count)]
        family = closure(generators)
        remove_empty = bool(rng.getrandbits(1)) and len(family) > 2
        if remove_empty:
            family.remove(0)
        if len(family) < 2:
            family = [0, (1 << n) - 1]
        check_family(family, stats)
        stats["examples"].append({"ground_set_size": n, "generators": generators,
                                  "removed_empty": remove_empty, "family_size": len(family)})
    return stats


def numerical_table():
    sizes = [2, 3, 10, 55, 100, 1000, 10 ** 6, 10 ** 12, 10 ** 100]
    table = []
    for size in sizes:
        d, method = deficit_interval(size)
        logn = iv.ln(size)
        boppana = PSI + d / (PHI * logn)
        jiang = JIANG_C + JIANG_K * d / logn
        old_jiang = JIANG_C + JIANG_K * iv.ln(2 * size - 1) ** 2 / (64 * size ** 2 * logn ** 2)
        table.append({"N": str(size), "deficit_nats": enclosure(d),
                      "Boppana_plus_chain_deficit": enclosure(boppana),
                      "Jiang_mixture_plus_chain_deficit": enclosure(jiang),
                      "Jiang_2026_size_only_correction": enclosure(old_jiang),
                      "deficit_evaluation": method})
    return table


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path("results"))
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    start = time.perf_counter()
    exhaustive = exhaustive_checks()
    random_result = random_checks()
    table = numerical_table()
    report = {"status": "all assertions passed", "interval_precision_decimal_digits": iv.dps,
              "exact_checks": "majorization, k-input equality, collision identities and inequalities, two-input entropy ordering, second entropy extremum",
              "entropy_comparison_method": "exact integer products prod r^r; no floating point entropy comparison",
              "frequency_comparison_method": "outward-rounded mpmath interval endpoints compared with exact rational frequencies",
              "external_dependency": "The Jiang-based abundance formula uses the cited 2026 entropy mixture theorem; this script does not reverify its scalar interval certificate.",
              "exhaustive": exhaustive, "random": random_result,
              "elapsed_seconds": round(time.perf_counter() - start, 3)}
    (args.output_dir / "verification_summary.json").write_text(json.dumps(report, indent=2) + "\n")
    (args.output_dir / "numerical_bounds.json").write_text(json.dumps(table, indent=2) + "\n")
    lines = ["N,deficit_lower,deficit_upper,boppana_lower,boppana_upper,jiang_lower,jiang_upper,old_jiang_lower,old_jiang_upper"]
    for row in table:
        fields = [row["N"]]
        for key in ("deficit_nats", "Boppana_plus_chain_deficit", "Jiang_mixture_plus_chain_deficit", "Jiang_2026_size_only_correction"):
            fields.extend([row[key]["lower"], row[key]["upper"]])
        lines.append(",".join(fields))
    (args.output_dir / "numerical_bounds.csv").write_text("\n".join(lines) + "\n")
    print(json.dumps({"status": report["status"], "exhaustive_family_checks": sum(s["families_checked"] for s in exhaustive),
                      "random_family_checks": random_result["families_checked"], "elapsed_seconds": report["elapsed_seconds"],
                      "results": str(args.output_dir.resolve())}, indent=2))


if __name__ == "__main__":
    main()
