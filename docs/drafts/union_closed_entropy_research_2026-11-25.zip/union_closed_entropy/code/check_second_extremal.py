#!/usr/bin/env python3
"""Independent exhaustive checks of the structural lemmas on <=4 points.

All structural comparisons are exact integers except Shannon entropy.
The mathematical proofs, not this finite check, establish the theorems.
"""
from collections import Counter
from itertools import combinations
import json
import math


def is_chain(family):
    return all((a | b) in (a, b) for a, b in combinations(family, 2))


def verify_family(family):
    n = len(family)
    if n == 0:
        return None
    counts = Counter(a | b for a in family for b in family)
    if len(counts) != n or any(c not in family for c in counts):
        return None
    ordered = sorted(family, key=lambda s: (s.bit_count(), s))
    r = [counts[a] for a in ordered]
    q = list(range(1, 2*n, 2))
    sorted_r = sorted(r)
    assert all(x % 2 == 1 and x > 0 for x in r)
    assert sum(r) == n*n
    assert all(sum(sorted_r[:k]) <= k*k for k in range(1, n+1))
    escapes = [k*k - sum(r[:k]) for k in range(n+1)]
    assert all(e >= 0 and e % 2 == 0 for e in escapes)
    baseline = n*(4*n*n-1)//3
    excess = sum(x*x for x in r) - baseline
    assert excess == sum((x-y)**2 for x, y in zip(r, q)) + 4*sum(escapes)
    incomparables = [(a,b) for a,b in combinations(family, 2)
                    if (a|b) not in (a,b)]
    incomparable_count = len(incomparables)
    chain = incomparable_count == 0
    assert (sorted_r == q) == chain
    assert (excess == 0) == chain
    if not chain:
        assert excess >= 16
        assert (excess == 16) == (incomparable_count == 1)
        assert excess >= 8*incomparable_count + 8
        v = list(range(1, 2*n-6, 2)) + [2*n-5, 2*n-5, 2*n+1]
        assert len(v) == n and sum(v) == n*n
        entropy_cost = sum(x*math.log(x) for x in r)
        threshold_cost = sum(x*math.log(x) for x in v)
        assert entropy_cost + 1e-10 >= threshold_cost
        equality = abs(entropy_cost - threshold_cost) < 1e-10
        assert equality == (sorted_r == v)
        # A second-entropy extremizer has one incomparable pair and
        # their join is the unique remaining element above them.
        shape = False
        if incomparable_count == 1:
            a, b = incomparables[0]
            upper = [c for c in family if a != c and b != c
                     and (a|c) == c and (b|c) == c]
            shape = len(upper) == 1
        assert equality == shape
    return {
        "chain": chain,
        "second_entropy_equality": (not chain and sorted_r == v),
        "second_collision_equality": excess == 16,
        "stronger_collision_conjecture_passes": excess >= 16*incomparable_count,
    }


def main():
    result = {}
    for ground_n in range(5):
        subsets = 1 << ground_n
        summary = Counter()
        for mask in range(1, 1 << subsets):
            family = {s for s in range(subsets) if mask & (1 << s)}
            stats = verify_family(family)
            if stats is None:
                continue
            summary["union_closed_nonempty_families"] += 1
            for key, value in stats.items():
                summary[key] += int(value)
        result[str(ground_n)] = dict(summary)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
