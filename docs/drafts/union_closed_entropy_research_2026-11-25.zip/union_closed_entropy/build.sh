#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
pdflatex -interaction=nonstopmode -halt-on-error union_closed_entropy.tex
pdflatex -interaction=nonstopmode -halt-on-error union_closed_entropy.tex
