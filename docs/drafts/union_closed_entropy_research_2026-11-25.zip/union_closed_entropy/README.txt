SHARP ENTROPY BOUNDS FOR UNIONS
Finite-family refinements of Frankl's union-closed sets conjecture
25 November 2026

READ FIRST
----------
union_closed_entropy.pdf is the complete mathematical report.
union_closed_entropy.tex is its main LaTeX source.
second_extremal.tex and approximate.tex are included source sections.

The report does not prove Frankl's full 1/2 conjecture.
It proves a sharp upper bound on independent union entropy, with chains
as the equality cases, and explicit finite-size frequency consequences.
The proposed novelty is documented and qualified: priority is unconfirmed.
The chain example and its asymptotic entropy were already computed by
Anthony Quas in 2022 and are explicitly credited.

MAIN RESULT
-----------
For N >= 2, define

  D_N = (1/N^2) sum_{i=1}^N (2i-1) log((2i-1)/N).

Every union-closed family of N distinct finite sets with a nonempty
member has an element in at least a proportion

  (3-sqrt(5))/2 + D_N / (((1+sqrt(5))/2) log N)

of its members. The number of occurrences can be rounded up to an integer.
The proof of this bound is provided in full in the report.

A second bound, 0.38288525 + 0.500000008685975 D_N/log N, uses Jiang's
2026 computer-assisted entropy inequality as an external theorem.
The new upper bound does not depend on that theorem. This package does
not replay Jiang's scalar interval certificate.

CONTENTS
--------
union_closed_entropy.pdf       Complete report.
union_closed_entropy.tex       Main source, including bibliography.
second_extremal.tex            Sharp non-chain and collision theorems.
approximate.tex                Exact entropy maximum with a specified number of failed unions.
build.sh                       Rebuild the PDF with pdflatex.
requirements.txt               Dependency for the main numerical checker.
novelty_audit.txt               Sources searched, close antecedents, limitations.
review_notes.txt               Scope and findings of independent internal review.
code/verify_union_bounds.py    Exact integer and interval checks.
code/check_second_extremal.py  Independent structural check.
code/check_approximate.py      Exact checks for arbitrary families.
data/main/                    Actual output of the main checker and interval table.
data/structural_results.json   Actual independent structural-check output.
data/approximate_results.json  Actual arbitrary-family check output.
data/sources.json             Source metadata from the literature audit.
SHA256SUMS                    Checksums of the deliverable files.

REPRODUCING
-----------
Python 3.10 or later is required. The main checker additionally uses
mpmath 1.3.0 or later. The other two checkers use only the standard library.

From this directory:

  python3 code/verify_union_bounds.py --output-dir data/main
  python3 code/check_second_extremal.py > data/structural_results.json
  python3 code/check_approximate.py --output data/approximate_results.json
  bash build.sh

The PDF build requires pdflatex and the packages listed in the main source.
The report has no external image dependency and uses no external bibliography
processor.

VERIFICATION SCOPE
------------------
The main program checks all 5,066 union-closed families with at least two
members over labelled ground sets of sizes 1 through 4, and 60 seeded
random larger closures. Families on smaller supports can occur more than
once when different ground-set sizes are enumerated.

The arbitrary-family program checks 65,809 nonempty families over labelled
ground sets of sizes 0 through 4, plus 5,487 sharpness constructions covering every admissible even failure
count for each family size from 2 through 32.
It verifies its entropy inequality by exact integer products.

The main checker compares two-sample entropies through exact integers
prod r^r. Its displayed numerical bounds use 70-digit interval arithmetic
and exact conversion of binary endpoints to outward-rounded decimal endpoints.
For enormous N it uses the analytic midpoint error bound from the report.

The independently written structural checker uses exact integers for
majorization and collision identities and ordinary floating point for its
Shannon-entropy comparison. That same entropy comparison is checked by
exact integers in the main program.

The scripts also record a tested but unproved stronger collision inequality
as an exploratory statistic. That statistic is not used in any theorem.

The finite checks are validation of the accompanying mathematical proofs.
They do not prove Frankl's full conjecture, establish historical priority,
or constitute a proof-assistant formalization.
