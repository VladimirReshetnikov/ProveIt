#!/bin/sh
set -eu
package_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
build_dir=$(mktemp -d)
trap 'rm -rf "$build_dir"' EXIT HUP INT TERM
cd "$package_dir"
latexmk -pdf -interaction=nonstopmode -halt-on-error \
  -outdir="$build_dir" pra_positive_uniqueness.tex
cp "$build_dir/pra_positive_uniqueness.pdf" "$package_dir/pra_positive_uniqueness.pdf"
mkdir -p "$package_dir/audit"
cp "$build_dir/pra_positive_uniqueness.log" "$package_dir/audit/latex_final.log"
