#!/usr/bin/env bash
set -euo pipefail
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
lean_bin="${LEAN_BIN:-lean}"
"$lean_bin" "$script_dir/UnaryPositiveUniqueness.lean"
"$lean_bin" "$script_dir/PositiveUniqueness.lean"
