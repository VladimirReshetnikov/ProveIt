Positive recursive uniqueness -- formal certificate
=================================================

UnaryPositiveUniqueness.lean checks the report's unary-update schema.
PositiveUniqueness.lean additionally checks the intermediate variant whose
update may inspect a counter. Both were checked with Lean 4.19.0, without
imports. They contain no sorry, no invocation of classical reasoning, and
no added Lean axioms. Each printed dependency check reports that the theorem
does not depend on any axioms.

The abstract carrier has no available induction principle. Computation
equations and the positive-uniqueness callback are explicit hypotheses.
The certificate verifies successor injectivity, separation, successor
nonzeroness, addition by one, constructor coverage, zero decidability,
ordinary recurrence uniqueness, common-recurrence uniqueness, the converse
from separation/coverage/recurrence uniqueness, addition by zero, the
right-successor law for addition, and the simultaneous-successor monus law.
The unary file additionally checks the gate case laws and the error-latch
argument recovering induction for e(n)=0. The latch is explicitly supplied
with its parameter-bearing recursive equations. This last step uses
recurrence uniqueness only for the unary identity update.

There are sixteen theorem dependency checks in the unary file and thirteen
in the counter-dependent intermediate file.

Scope limitation: the callback quantifies over Lean functions. The file
therefore checks the constructive logical derivations under an abstract
schema interface; it does not formalize the finite-syntax restrictions of
the first-order schema, the full proof calculus, or the full equivalence
with primitive recursive arithmetic. Those claims are handled in the
mathematical report. In each displayed first-order instance all frozen
parameters are held fixed when the term is supplied as a Lean function.

To reproduce, install Lean 4.19.0 and run:

    lean UnaryPositiveUniqueness.lean

or run check.sh, setting LEAN_BIN to a compiler path if necessary.

The recorded compiler outputs are unary_verification.log and
verification.log, respectively.
