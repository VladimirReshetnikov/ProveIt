/-
Positive recursive uniqueness: constructive logical kernel.

Lean 4.19.0, no imports, no classical choice, no sorry.
The carrier is abstract: it is not Lean's Nat, and its induction principle
is unavailable. The positive-uniqueness schema is represented by an
abstract functional callback. This file checks the displayed derivations,
not the finite-syntax membership discipline or the entire first-order PRA
equivalence theorem. Numerical parameters in an instantiated first-order
term are held fixed when that term is represented by a Lean function.
-/

universe u

namespace PositiveUniqueness

structure Computation (A : Type u) where
  zero : A
  succ : A → A
  pred : A → A
  iter : (A → A → A) → A → A → A
  pred_zero : pred zero = zero
  pred_succ : ∀ n, pred (succ n) = n
  iter_zero : ∀ h a, iter h zero a = a
  iter_succ : ∀ h n a, iter h (succ n) a = h n (iter h n a)

variable {A : Type u}

def One (d : Computation A) : A := d.succ d.zero

def Add (d : Computation A) (x y : A) : A :=
  d.iter (fun _ v => d.succ v) x y

def Monus (d : Computation A) (x y : A) : A :=
  d.iter (fun _ v => d.pred v) x y

def PRU (d : Computation A) : Prop :=
  ∀ (f : A → A) (h : A → A → A),
    (∀ n, f (d.succ (d.succ n)) = h n (f (d.succ n))) →
    d.zero ≠ One d ∧
      ∀ n, n = d.zero ∨ f n = d.iter h (d.pred n) (f (One d))

def RU (d : Computation A) : Prop :=
  ∀ (f : A → A) (h : A → A → A),
    (∀ n, f (d.succ n) = h n (f n)) →
      ∀ n, f n = d.iter h n (f d.zero)

def Coverage (d : Computation A) : Prop :=
  ∀ n, n = d.zero ∨ n = d.succ (d.pred n)

theorem successor_injective (d : Computation A) :
    ∀ x y, d.succ x = d.succ y → x = y := by
  intro x y h
  have hp := congrArg d.pred h
  rw [d.pred_succ, d.pred_succ] at hp
  exact hp

theorem separation (d : Computation A) (hp : PRU d) :
    d.zero ≠ One d := by
  exact (hp (fun n => n) (fun _ v => d.succ v) (fun _ => rfl)).1

theorem successor_nonzero (d : Computation A)
    (hs : d.zero ≠ One d) : ∀ n, d.succ n ≠ d.zero := by
  intro n hn
  have hn0 : n = d.zero := by
    have hh := congrArg d.pred hn
    rw [d.pred_succ, d.pred_zero] at hh
    exact hh
  apply hs
  change d.zero = d.succ d.zero
  rw [hn0] at hn
  exact hn.symm

theorem add_one (d : Computation A) (hp : PRU d) :
    ∀ n, Add d n (One d) = d.succ n := by
  intro n
  have hb := hp (fun x => x) (fun _ v => d.succ v) (fun _ => rfl)
  cases hb.2 (d.succ n) with
  | inl h => exact False.elim (successor_nonzero d hb.1 n h)
  | inr h =>
      rw [d.pred_succ] at h
      exact h.symm

theorem coverage (d : Computation A) (hp : PRU d) : Coverage d := by
  intro n
  have hb := hp (fun x => x) (fun _ v => d.succ v) (fun _ => rfl)
  cases hb.2 n with
  | inl h => exact Or.inl h
  | inr h =>
      apply Or.inr
      change n = Add d (d.pred n) (One d) at h
      exact h.trans (add_one d hp (d.pred n))

theorem zero_decidable (d : Computation A) (hp : PRU d) :
    ∀ n, n = d.zero ∨ n ≠ d.zero := by
  intro n
  cases coverage d hp n with
  | inl h => exact Or.inl h
  | inr h =>
      apply Or.inr
      intro hn
      exact successor_nonzero d (separation d hp) (d.pred n) (h.symm.trans hn)

theorem recursion_uniqueness (d : Computation A) (hp : PRU d) : RU d := by
  intro f h hf n
  have hb := hp (fun x => f (d.pred x)) h (by
    intro x
    change f (d.pred (d.succ (d.succ x))) = h x (f (d.pred (d.succ x)))
    rw [d.pred_succ, d.pred_succ]
    exact hf x)
  cases hb.2 (d.succ n) with
  | inl hn => exact False.elim (successor_nonzero d hb.1 n hn)
  | inr hn =>
      change f (d.pred (d.succ n)) =
        d.iter h (d.pred (d.succ n)) (f (d.pred (d.succ d.zero))) at hn
      rw [d.pred_succ, d.pred_succ] at hn
      exact hn

theorem common_recurrence (d : Computation A) (hu : RU d)
    (f g : A → A) (h : A → A → A)
    (hb : f d.zero = g d.zero)
    (hf : ∀ n, f (d.succ n) = h n (f n))
    (hg : ∀ n, g (d.succ n) = h n (g n)) :
    ∀ n, f n = g n := by
  intro n
  calc
    f n = d.iter h n (f d.zero) := hu f h hf n
    _ = d.iter h n (g d.zero) := congrArg (d.iter h n) hb
    _ = g n := (hu g h hg n).symm

theorem pru_of_coverage_and_ru (d : Computation A)
    (hs : d.zero ≠ One d) (hc : Coverage d) (hu : RU d) : PRU d := by
  intro f h hf
  refine And.intro hs ?_
  have ht := hu (fun n => f (d.succ n)) h hf
  intro n
  cases hc n with
  | inl hn => exact Or.inl hn
  | inr hn =>
      apply Or.inr
      calc
        f n = f (d.succ (d.pred n)) := congrArg f hn
        _ = d.iter h (d.pred n) (f (d.succ d.zero)) := ht (d.pred n)
        _ = d.iter h (d.pred n) (f (One d)) := rfl

theorem pru_iff (d : Computation A) :
    PRU d ↔ d.zero ≠ One d ∧ Coverage d ∧ RU d := by
  constructor
  · intro hp
    exact ⟨separation d hp, coverage d hp, recursion_uniqueness d hp⟩
  · intro h
    exact pru_of_coverage_and_ru d h.1 h.2.1 h.2.2

theorem add_zero (d : Computation A) (hp : PRU d) :
    ∀ n, Add d n d.zero = n := by
  intro n
  exact (recursion_uniqueness d hp (fun x => x)
    (fun _ v => d.succ v) (fun _ => rfl) n).symm

theorem add_successor_right (d : Computation A) (hp : PRU d) :
    ∀ n a, Add d n (d.succ a) = d.succ (Add d n a) := by
  intro n a
  have hh := recursion_uniqueness d hp (fun x => d.succ (Add d x a))
    (fun _ v => d.succ v) (by
      intro x
      change d.succ (d.iter (fun _ v => d.succ v) (d.succ x) a) =
        d.succ (d.succ (d.iter (fun _ v => d.succ v) x a))
      rw [d.iter_succ]) n
  change d.succ (Add d n a) =
    d.iter (fun _ v => d.succ v) n
      (d.succ (d.iter (fun _ v => d.succ v) d.zero a)) at hh
  rw [d.iter_zero] at hh
  exact hh.symm

theorem monus_shift (d : Computation A) (hp : PRU d) :
    ∀ n a, Monus d (d.succ n) (d.succ a) = Monus d n a := by
  intro n a
  have hh := recursion_uniqueness d hp
    (fun x => d.pred (Monus d x (d.succ a)))
    (fun _ v => d.pred v) (by
      intro x
      change d.pred (d.iter (fun _ v => d.pred v) (d.succ x) (d.succ a)) =
        d.pred (d.pred (d.iter (fun _ v => d.pred v) x (d.succ a)))
      rw [d.iter_succ]) n
  change d.pred (Monus d n (d.succ a)) =
    d.iter (fun _ v => d.pred v) n
      (d.pred (d.iter (fun _ v => d.pred v) d.zero (d.succ a))) at hh
  rw [d.iter_zero, d.pred_succ] at hh
  change d.iter (fun _ v => d.pred v) (d.succ n) (d.succ a) = Monus d n a
  rw [d.iter_succ]
  exact hh

#print axioms successor_injective
#print axioms separation
#print axioms successor_nonzero
#print axioms add_one
#print axioms coverage
#print axioms zero_decidable
#print axioms recursion_uniqueness
#print axioms common_recurrence
#print axioms pru_of_coverage_and_ru
#print axioms pru_iff
#print axioms add_zero
#print axioms add_successor_right
#print axioms monus_shift

end PositiveUniqueness
