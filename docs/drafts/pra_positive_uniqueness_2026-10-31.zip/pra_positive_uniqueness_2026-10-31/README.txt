PRA FROM POSITIVE ITERATION UNIQUENESS
31 October 2026
====================================

MAIN RESULT

A four-equality arithmetic schema with a unary update and no base-admission
test axiomatizes ordinary PRA, separately in classical and intuitionistic
first-order equality logic. At one fixed parameter its expanded formula
has 38 nodes, compared with 39 / five equalities for the current
reflexive-base schema.

The equivalence theorem is in the ordinary full primitive-recursive
description language. It permits general function definitions with
counters and fixed parameters, and arbitrary finite parameter tuples in
arithmetic instances. This is an explicit tradeoff against the current
drafts' restricted initialized-binary generator. Completeness of the
shorter schema in that narrower language is NOT claimed.

The proof uses only the unary arithmetic updates S, predecessor, and
identity. One fixed instance supplies the constructor laws and coverage.
The paper then proves native equality reflection and every contextual
quantifier-free induction axiom.

START HERE

  pra_positive_uniqueness.pdf   Complete report and full written proofs.
  axioms.txt                   Exact standalone specification.

CONTENTS

  pra_positive_uniqueness.tex   Main editable LaTeX source.
  sections/equivalence.tex      Complete constructive equivalence proof.
  formal/                      Lean 4.19.0 kernels, scope notes, and logs.
  artifacts/schema_metrics.py  Exact expanded formula-tree counter.
  audit/schema_metrics.json    Actual counts and one-parameter formula trees.
  comparison.tsv               Counts for 0--4 fixed parameters.
  audit/source_audit.json       Pinned source identities and verified hashes.
  audit/proof_review.txt        Independent mathematical review record.
  VALIDATION.txt               Final build/check/render results.
  build.sh                     Rebuild the PDF.
  check.sh                     Run syntax and formal checks.
  lean-toolchain               Lean version pin.
  SHA256SUMS                   Package member checksums.

REBUILD

  sh build.sh
  sh check.sh

Requirements: Python 3.10 or later; pdfLaTeX/latexmk and the normal packages
listed in the TeX preamble; Lean 4.19.0 for formal replay.
Set LEAN_BIN=/absolute/path/to/lean if Lean is not on PATH.
The scripts do not download dependencies.

VERIFICATION BOUNDARY

The final unary Lean file checks sixteen theorems, including the error
latch; the counter-update comparison file checks thirteen. All twenty-nine
printed dependency checks report no global Lean axioms. Computation and
schema hypotheses remain explicit theorem inputs.

The schema is represented by a functional callback over an abstract
carrier. These files are not a complete finite-syntax formalization of the
PRA proof calculus or of the entire equivalence theorem. The maximum
identity, general formula compiler, and full equivalence have detailed
written proofs, independently reviewed. Finite syntax counts are not
substituted for mathematical proofs.

SOURCE SNAPSHOT

VladimirReshetnikov/ProveIt
66372d99e4f4e1d3a48822b9d322ae9e9ae7e7e3

All four current docs/drafts archives were compared. The docs/incoming
inventory/index had no PRA-labelled archive or relevant entry; unrelated
archive interiors were not inspected. No repository mutation was made.
The original source archives and the third-party journal PDF are not
redistributed in this package.

The report includes a "Further research questions" section.
No absolute minimality or historical-priority claim is made.
