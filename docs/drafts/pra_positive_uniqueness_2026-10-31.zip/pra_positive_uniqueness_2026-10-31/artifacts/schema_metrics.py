#!/usr/bin/env python3
"""Count actual formula trees for four PRA arithmetic-schema displays.

This is a syntax audit, not a proof checker.  In particular, it does not
establish completeness of any restricted-language uniqueness principle.

One node is charged for each term variable, constant, function application,
equality, connective, falsity constant, and quantifier occurrence.  The name
bound by a quantifier is a label, not an additional variable occurrence.
Negation is implication to falsity; 1 is S(0); p(n) is P(n,0), where P is
the already declared binary counter iterator.  An iterator symbol I_h is
one function symbol: its defining description is not re-expanded at each
occurrence.  Schematic terms f, s, t, H, h are charged as applications at
their displayed arities, not expanded into arbitrary substitutions.

Every fixed numerical parameter is charged separately, both at every
application and in its own outer universal quantifier.  Thus a tuple of m
parameters is never treated as one syntax node.

The compared displays share a value of m, not necessarily the same full
language or theorem.  The supplied PB0/Swap drafts use initialized binary
iteration and one fixed parameter.  The main PIU theorem in the present
report uses the ordinary primitive-recursive language and arbitrary finite
fixed parameter tuples.  Its ARITHMETIC schema has a unary update h(v);
its COMPUTATION grammar still permits general primitive recursion with
counter and frozen parameters.  Full equivalence for the more restrictive
initialized-binary, one-parameter proposal remains unresolved here.
"""

from __future__ import annotations

import argparse
import csv
import io
import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Node:
    kind: str
    label: str
    children: tuple["Node", ...] = ()


def var(name: str) -> Node:
    return Node("variable", name)


def const(name: str) -> Node:
    return Node("constant", name)


def app(name: str, *arguments: Node) -> Node:
    return Node("application", name, arguments)


def eq(left: Node, right: Node) -> Node:
    return Node("equality", "=", (left, right))


def binary(name: str, left: Node, right: Node) -> Node:
    return Node("connective", name, (left, right))


def forall(name: str, body: Node) -> Node:
    return Node("quantifier", "forall " + name, (body,))


def quantify_parameters(parameters: tuple[Node, ...], body: Node) -> Node:
    for parameter in reversed(parameters):
        body = forall(parameter.label, body)
    return body


ZERO = const("0")
ONE = app("S", ZERO)
BOTTOM = const("false")
N = var("n")


def succ(term: Node) -> Node:
    return app("S", term)


def separation() -> Node:
    return binary("implies", eq(ZERO, ONE), BOTTOM)


def make_pb0(m: int, *, swap: bool = False, separated: bool = False) -> tuple[Node, ...]:
    """PB0, or its automatic-boundary Swap subfamily, with m parameters."""
    parameters = tuple(var(f"a{i + 1}") for i in range(m))

    def equation(n: Node) -> Node:
        if swap:
            return eq(app("H", n, ONE, *parameters), app("H", ONE, n, *parameters))
        return eq(app("s", n, *parameters), app("t", n, *parameters))

    premise = forall("n", binary("implies", equation(N), equation(succ(N))))
    positive = forall("n", binary("or", eq(N, ZERO), equation(N)))
    output = positive if separated else binary("and", separation(), positive)
    schema = quantify_parameters(parameters, binary("implies", premise, output))
    return (separation(), schema) if separated else (schema,)


def make_pru(m: int, *, unary: bool = False, separated: bool = False) -> tuple[Node, ...]:
    """PRU with h(n,v), or PIU with h(v), and m fixed parameters in f."""
    parameters = tuple(var(f"a{i + 1}") for i in range(m))

    def f(n: Node) -> Node:
        return app("f", n, *parameters)

    updated = app("h", f(succ(N))) if unary else app("h", N, f(succ(N)))
    premise = forall("n", eq(f(succ(succ(N))), updated))
    canonical = app("I_h", app("P", N, ZERO), f(ONE))
    positive = forall("n", binary("or", eq(N, ZERO), eq(f(N), canonical)))
    output = positive if separated else binary("and", separation(), positive)
    schema = quantify_parameters(parameters, binary("implies", premise, output))
    return (separation(), schema) if separated else (schema,)


def walk(tree: Node):
    yield tree
    for child in tree.children:
        yield from walk(child)


def counts(formulas: tuple[Node, ...]) -> dict[str, int]:
    nodes = [node for formula in formulas for node in walk(formula)]
    return {
        "arithmetic_items": len(formulas),
        "ast_nodes": len(nodes),
        "equality_occurrences": sum(node.kind == "equality" for node in nodes),
        "quantifier_occurrences": sum(node.kind == "quantifier" for node in nodes),
    }


def as_data(tree: Node) -> dict:
    return {
        "kind": tree.kind,
        "label": tree.label,
        "children": [as_data(child) for child in tree.children],
    }


def build_report(max_parameters: int) -> dict:
    rows = []
    for m in range(max_parameters + 1):
        for separated in (False, True):
            makers = (
                ("PB0", make_pb0(m, separated=separated), 5, 32 + 7 * m),
                ("Swap", make_pb0(m, swap=True, separated=separated), 5, 44 + 7 * m),
                ("PRU", make_pru(m, separated=separated), 4, 34 + 5 * m),
                ("PIU", make_pru(m, unary=True, separated=separated), 4, 33 + 5 * m),
            )
            for name, formulas, expected_equalities, packed_nodes in makers:
                measured = counts(formulas)
                assert measured["equality_occurrences"] == expected_equalities
                assert measured["ast_nodes"] == packed_nodes - int(separated)
                rows.append({
                    "schema": name,
                    "packaging": "separated" if separated else "packed",
                    "fixed_parameters": m,
                    **measured,
                })

    one_parameter = {
        row["schema"]: row
        for row in rows
        if row["fixed_parameters"] == 1 and row["packaging"] == "packed"
    }
    assert one_parameter["PB0"]["ast_nodes"] == 39
    assert one_parameter["Swap"]["ast_nodes"] == 51
    assert one_parameter["PRU"]["ast_nodes"] == 39
    assert one_parameter["PIU"]["ast_nodes"] == 38

    return {
        "scope": "Exact finite syntax counts; not a proof of arithmetic equivalence.",
        "metric": {
            "node_cost": "One per occurrence: variable, constant, application, equality, connective, quantifier.",
            "negation": "A -> false",
            "one": "S(0)",
            "predecessor": "P(n,0), with P the declared binary counter iterator",
            "iterator_indices": "Declared function-symbol identities; descriptions are not re-expanded per occurrence.",
            "schematic_terms": "Applications at their actual displayed arities; arbitrary substituted term bodies are not counted.",
            "parameters": "Every parameter occurrence and every parameter quantifier is counted separately.",
            "separated_formulas": "Their tree sizes are added without an artificial conjunction.",
            "excluded": "The common computation formulas, full language grammar, recognizer code, and proof compiler.",
        },
        "closed_forms": {
            "packed_PB0_nodes": "32 + 7*m",
            "packed_Swap_nodes": "44 + 7*m",
            "packed_PRU_nodes": "34 + 5*m",
            "packed_PIU_nodes": "33 + 5*m",
            "separated_nodes": "Subtract one from the corresponding packed count.",
            "PB0_equalities": 5,
            "Swap_equalities": 5,
            "PRU_equalities": 4,
            "PIU_equalities": 4,
        },
        "comparison_caveat": (
            "This compares arithmetic displays at the same parameter arity. "
            "The existing PB0/Swap drafts prove completeness for a more restrictive "
            "initialized-binary language with one fixed parameter. The main PIU "
            "theorem here uses the ordinary primitive-recursive language with "
            "arbitrary finite fixed parameter tuples. PIU has a counter-free unary "
            "update in its arithmetic schema, not in the general primitive-recursion "
            "computation grammar. No dominance of the complete "
            "language-plus-schema description is asserted. Restricted binary "
            "one-parameter uniqueness has only its constructor/uniqueness core established here."
        ),
        "rows": rows,
        "one_parameter_packed_trees": {
            "PB0": [as_data(t) for t in make_pb0(1)],
            "Swap": [as_data(t) for t in make_pb0(1, swap=True)],
            "PRU": [as_data(t) for t in make_pru(1)],
            "PIU": [as_data(t) for t in make_pru(1, unary=True)],
        },
    }


def to_tsv(report: dict) -> str:
    stream = io.StringIO(newline="")
    fields = ["schema", "packaging", "fixed_parameters", "arithmetic_items",
              "ast_nodes", "equality_occurrences", "quantifier_occurrences"]
    writer = csv.DictWriter(stream, fields, delimiter="\t", lineterminator="\n")
    writer.writeheader()
    writer.writerows(report["rows"])
    return stream.getvalue()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--max-parameters", type=int, default=4)
    parser.add_argument("--output", type=Path, help="Write complete JSON audit to this file.")
    parser.add_argument("--tsv", type=Path, help="Write the numeric comparison table to this file.")
    args = parser.parse_args()
    if args.max_parameters < 1:
        parser.error("--max-parameters must be at least one")
    report = build_report(args.max_parameters)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if args.tsv:
        args.tsv.parent.mkdir(parents=True, exist_ok=True)
        args.tsv.write_text(to_tsv(report), encoding="utf-8")
    if args.output or args.tsv:
        print("PASS: actual formula trees agree with all stated counts.")
        print("Packed PIU: 33+5m nodes / 4 equalities; PRU: 34+5m / 4; PB0: 32+7m / 5; Swap: 44+7m / 5.")
        print("Language and parameter-scope caveats are recorded in the JSON audit.")
    else:
        print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
