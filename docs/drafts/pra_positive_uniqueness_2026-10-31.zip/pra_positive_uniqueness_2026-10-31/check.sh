#!/bin/sh
set -eu
package_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$package_dir"
python3 artifacts/schema_metrics.py --max-parameters 4 > /dev/null
printf '%s\n' 'Expanded formula metrics: all assertions passed.'
if [ -n "${LEAN_BIN:-}" ] || command -v lean >/dev/null 2>&1; then
  bash formal/check.sh
else
  printf '%s\n' 'Lean replay skipped: set LEAN_BIN to a Lean 4.19.0 executable.'
fi
