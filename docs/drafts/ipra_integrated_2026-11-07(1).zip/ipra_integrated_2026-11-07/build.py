"""Build the complete report with pdfLaTeX; no shell escape or network."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    build = ROOT / 'build'
    build.mkdir(exist_ok=True)
    results = ROOT / 'results'
    results.mkdir(exist_ok=True)
    for run in range(1, 4):
        result = subprocess.run(['pdflatex', '-no-shell-escape', '-interaction=nonstopmode',
                                 '-halt-on-error', '-file-line-error', '-output-directory=build', 'report.tex'],
                                cwd=ROOT, capture_output=True, text=True, check=False)
        (results / ('latex_pass_' + str(run) + '.txt')).write_text(result.stdout + result.stderr)
        if result.returncode:
            raise RuntimeError('LaTeX build failed; see results/latex_pass_' + str(run) + '.txt')
    log = (build / 'report.log').read_text()
    if 'undefined references' in log or 'Citation `' in log or 'Reference `' in log:
        raise RuntimeError('Unresolved report references; inspect build/report.log')
    shutil.copy2(build / 'report.pdf', ROOT / 'report.pdf')
    print('Built report.pdf')


if __name__ == '__main__':
    main()
