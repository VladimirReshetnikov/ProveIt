"""Verify the artifact and reproduce measurements and finite kernel checks."""
from pathlib import Path
import hashlib
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    manifest = ROOT / 'SHA256SUMS'
    if manifest.exists():
        for line in manifest.read_text().splitlines():
            digest, name = line.split('  ', 1)
            path = ROOT / name
            if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
                raise ValueError('Changed artifact: ' + name)
        print('PASS: artifact hashes', flush=True)
    subprocess.run([sys.executable, 'measure.py'], cwd=ROOT, check=True)
    subprocess.run([sys.executable, 'validation/verify_integrated.py'], cwd=ROOT, check=True)
    result = subprocess.run([sys.executable, 'checker.py', 'validation/cases/reject_sort_confusion.json'],
                            cwd=ROOT, capture_output=True, text=True, check=False)
    if (result.returncode, result.stdout.strip(), result.stderr) != (1, 'REJECT', ''):
        raise ValueError('The sort-confusion counterexample was not rejected')
    print('PASS: sort-confusion rejection')
    print('PASS: all reproduction checks')


if __name__ == '__main__':
    main()
