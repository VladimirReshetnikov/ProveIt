"""Portable finite replay of the integrated scalar checker, using only this archive.

Run from any working directory: python3 PATH/validation/verify_integrated.py
No production checker imports any validation module. No network is used.
"""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import platform
import sys

from audit_support import cli, load_kernel, mutation_agreement, opening_audit, require, run
from generate_cases import generated
from named_oracle import Oracle

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def unwrap_instructions(packet):
    """Translate the old singleton-wrapped instruction format to raw witnesses.

    Only top-level proof cells are unwrapped; the final goal is unchanged.
    A malformed or wholly unused instruction need not retain the same verdict.
    Those differences are recorded, not silently folded into theorem equivalence.
    """
    result = deepcopy(packet)
    if type(result) is list:
        result[:-1] = [cell[0] if type(cell) is list and len(cell) == 1 else cell
                       for cell in result[:-1]]
    return result


def main():
    candidate_path = ROOT / 'checker.py'
    baseline_path = HERE / 'baseline_scope_checker.py'
    candidate = load_kernel(candidate_path)
    baseline = load_kernel(baseline_path)
    rows = generated(1)
    case_dir = HERE / 'cases'
    case_dir.mkdir(exist_ok=True)
    fixtures = []
    for row in rows:
        outcome = run(candidate, row['packet'])
        oracle = Oracle(1).run(row['packet'])
        require(outcome['accepted'] == oracle['accepted'] == row['expected'],
                ('fixture verdict', row['name'], outcome, oracle))
        if outcome['accepted']:
            require(outcome['final_k'] == oracle['final_k'], ('fixture fresh clock', row['name']))
            require(outcome['remaining'] == oracle['remaining'], ('fixture proof consumption', row['name']))
        path = case_dir / (row['name'] + '.json')
        path.write_text(json.dumps(row['packet']) + '\n')
        cli_runs = [cli(candidate_path, path, row['expected'], optimized=value)
                    for value in (False, True)]
        fixtures.append({'name': row['name'], 'case': str(path.relative_to(ROOT)),
                         'expected': row['expected'], 'outcome': outcome,
                         'oracle_rules': oracle['rules'], 'cli': cli_runs})

    inherited = []
    for filename in ('inherited_fixtures.json', 'new_fixtures.json', 'new_scope_cases.json'):
        for row in json.loads((HERE / filename).read_text()):
            old_outcome = run(baseline, row['packet'])
            packet = unwrap_instructions(row['packet'])
            outcome = run(candidate, packet)
            oracle = Oracle(1).run(packet)
            require(outcome['accepted'] == oracle['accepted'],
                    ('converted named-oracle verdict', filename, row['name'], outcome, oracle))
            if outcome['accepted']:
                require(outcome['final_k'] == oracle['final_k'],
                        ('converted named-oracle clock', filename, row['name']))
                require(outcome['remaining'] == oracle['remaining'],
                        ('converted named-oracle consumption', filename, row['name']))
            # Every successful supplied wrapped fixture must retain a successful
            # corresponding raw-witness certificate in this finite replay.
            require(not old_outcome['accepted'] or outcome['accepted'],
                    ('lost supplied positive certificate', filename, row['name']))
            record = {'cohort': filename, 'name': row['name'],
                      'historical_expected': row['expected'],
                      'current_wrapped_baseline': old_outcome,
                      'integrated_raw_candidate': outcome}
            if old_outcome['accepted'] != outcome['accepted']:
                record['reason'] = ('The raw-witness format admits the scalar or otherwise unmatched '
                                    'introduction instruction. Its witness is valid or wholly unused; '
                                    'the wrapped format required a singleton instruction wrapper. '
                                    'This is an input-language boundary difference, not a new theorem.')
            inherited.append(record)

    opening = opening_audit(candidate, 1)
    mutations = mutation_agreement(candidate, rows, 1, 2000)
    changed_current = [row for row in inherited
                       if row['current_wrapped_baseline']['accepted'] !=
                          row['integrated_raw_candidate']['accepted']]
    historical = [row for row in inherited
                  if row['historical_expected'] != row['current_wrapped_baseline']['accepted']]
    result = {
        'scope': 'Finite executable validation; not a formal metatheorem verification',
        'python': platform.python_version(),
        'implementation': platform.python_implementation(),
        'candidate': {'file': 'checker.py', 'sha256': sha256(candidate_path.read_bytes()).hexdigest()},
        'baseline': {'file': 'validation/baseline_scope_checker.py',
                     'sha256': sha256(baseline_path.read_bytes()).hexdigest()},
        'classification': 'Integration of previously supplied implementation choices',
        'counts': {'fixtures': len(fixtures),
                   'fixture_accepts': sum(row['expected'] for row in fixtures),
                   'fixture_rejects': sum(not row['expected'] for row in fixtures),
                   'public_cli_runs': 2 * len(fixtures),
                   'opening_comparisons': sum(opening.values()),
                   'mutation_comparisons': mutations['cases'],
                   'converted_inherited_fixtures': len(inherited),
                   'current_format_boundary_changes': len(changed_current),
                   'historical_expectations_predating_current_baseline': len(historical)},
        'fixtures': fixtures,
        'opening_audit': opening,
        'mutation_audit': mutations,
        'converted_inherited_fixtures': inherited,
        'current_to_candidate_boundary_changes': changed_current,
        'historical_metadata_differences': historical,
        'boundary_explanation': (
            'The frozen current baseline itself already accepts negative aliases in explicit '
            'one-hole motives. Some inherited fixture expectation fields describe an older '
            'strict-positive convention. Those historical differences are separated from '
            'the current-to-candidate changes caused by the raw-witness certificate format. '
            'The candidate still rejects unallocated parameters in closed goals and used images.')}
    require(result['counts']['fixtures'] == 53, 'Unexpected staged scalar fixture inventory')
    require(result['counts']['opening_comparisons'] == 7832, 'Unexpected opening inventory')
    require(result['counts']['converted_inherited_fixtures'] == 226, 'Unexpected inherited inventory')
    out = ROOT / 'results'
    out.mkdir(exist_ok=True)
    (out / 'validation.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'counts': result['counts'], 'opening_audit': opening,
                      'mutation_audit': mutations,
                      'current_format_changes': [{'cohort': row['cohort'], 'name': row['name']}
                                                 for row in changed_current],
                      'historical_metadata_changes': [{'cohort': row['cohort'], 'name': row['name']}
                                                       for row in historical]}, indent=2))


if __name__ == '__main__':
    main()
