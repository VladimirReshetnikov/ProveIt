PORTABLE VALIDATION FOR THE INTEGRATED SCALAR CHECKER
===================================================

Run from any working directory:

  python3 /path/to/ipra_integrated_2026-11-07/validation/verify_integrated.py

Only files in this archive and the Python standard library are needed.
The production checker imports none of the validation support.
The replay refreshes results/validation.json and the generated cases/ files.

Successful replay, 7 November 2026:

  53 staged scalar proof fixtures: 27 ACCEPT, 26 REJECT.
  106 production public-CLI invocations: normal Python and Python -O.
  7,832 independent named-binder opening comparisons.
  2,000 deterministic whole-packet mutation comparisons.
  226 inherited fixtures replayed after singleton-witness unwrapping.

The tests include zero/successor computation, equality transport, both
logical binders and their eliminations, atomic equation induction,
addition 2+3=5, multiplication 2*3=6, exponentiation 2^3=8, malformed
syntax, capture attempts, forbidden compound-formula induction, future
parameters, unused bodies, and failed-major fallback.

INTERPRETING THE TWO CURRENT BOUNDARY CHANGES

The frozen current scope-complement checker requires an introduction
instruction [t]; the integrated checker uses the raw witness t. The
replay unwraps singleton proof cells without changing the final goal.
Two old negative tests contain already-raw instructions 0 and null
before the paired truth goal D(0=0). The integrated format accepts them:
0 is a valid unused witness, and null is wholly unused and can be replaced
by 0 in the extracted derivation. The old wrapped format rejects those
unmatched instructions. These are explicit certificate-format differences;
they do not add mathematical theorems.

ONE SEPARATE HISTORICAL METADATA DIFFERENCE

The fixture named new/used_future_motive_parameter carries an expected
REJECT from a pre-complement convention. Both the frozen current
scope-complement checker and the integrated checker accept its negative
open-motive alias. The replay records this historical expectation
separately. Closed goals and used numerical images still reject undeclared
parameters. This is not a new regression of the integrated candidate.

EVIDENCE BOUNDARY

The oracle parses named binders and performs named substitution, rather
than copying the production packed-depth traversal. Its one documented
adaptation admits negative hole aliases in open templates, exactly as in
the existing scope-complement draft. Every successful fixture also checks
eigenparameter allocation and proof-cell consumption against that oracle.
These finite audits support implementation confidence. They are not a
proof of soundness, consistency, completeness, or bi-interpretability and
are not a Lean or Rocq formalization.

See ATTRIBUTION.txt and provenance.json for the exact inherited components,
adaptations, source snapshot, licenses, and file identities.
