"""Untrusted, portable validation helpers extracted from the staged-opening draft.

The selected function bodies are preserved verbatim. They import the local
independent named-binder oracle with the documented scope-complement change.
The production checker imports none of this module.
"""
import ast
from collections import Counter
from copy import deepcopy
import random
import subprocess
import sys
import types
from named_oracle import Oracle, opening

def require(condition, detail):
    if not condition:
        raise AssertionError(detail)


def load_kernel(path, source=None):
    source = path.read_text() if source is None else source
    tree = ast.parse(source, filename=str(path))
    body = []
    for node in tree.body:
        if isinstance(node, (ast.Import, ast.ImportFrom, ast.FunctionDef)):
            body.append(node)
        elif isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'k'
                                                  for t in node.targets):
            body.append(node)
    module = types.ModuleType(path.stem)
    exec(compile(ast.Module(body=body, type_ignores=[]), str(path), 'exec'), module.__dict__)
    return module


def run(module, packet):
    module.k = 0
    stack = deepcopy(packet)
    try:
        module.take = stack.pop
        accepted = bool(module.check(stack.pop(), []))
        error = None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    return {'accepted': accepted, 'final_k': module.k,
            'remaining': len(stack) if type(stack) is list else None, 'error': error}


def agreement(module, packet, width, name):
    actual = run(module, packet)
    expected = Oracle(width).run(packet)
    require(actual['accepted'] == expected['accepted'], ('oracle verdict', name, actual, expected))
    if actual['accepted']:
        for field in ('final_k', 'remaining'):
            require(actual[field] == expected[field], ('successful trace', name, field, actual, expected))
    return actual, expected


def opening_audit(module, width):
    atoms = [-3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 999,
             True, False, 0.0, 1.0, None, {}, '0']
    terms = [*atoms, [], [0], [1], [999], [0, 0], [0, 0, 1],
             [0, 0, 3], [0, 0, 5], [0, 0, 999],
             [1, 0, [0, 3, 7]], [0, 0, [0, 1, 999]],
             [3, 1, [5, 7, [1]]]]
    formulas = [[term, 0] for term in terms]
    formulas += [[[t, 0]] for t in (-2, 0, 1, 2, 3, 4, 5, 7, 999)]
    formulas += [[[t, 0], [1, 2], [3, 4]] for t in (-2, 0, 1, 2, 3, 4, 5, 7, 999)]
    formulas += [[], None, {}, [True], [[0, 0], [5, 5], [0, 0]],
                 [[[5, 1]], [[3, 4]], [[1, 2]]],
                 [[[[0, 0, 999], 5]], [0, 0], [0, 0]]]
    images = [None, 0, -1, -3, 1, 2, [0], [0, 0, 1], [0, 0, 3], True, {}]
    counts = Counter()
    for formula, values in ((True, formulas), (False, terms)):
        for value in values:
            for depth in (0, 1, 2, 3):
                for lower in (0, -2):
                    for image in images:
                        module.k = lower
                        try:
                            actual = module.inst(deepcopy(value), deepcopy(image),
                                                 2 * depth + (not formula))
                            valid = True
                        except Exception:
                            actual, valid = None, False
                        try:
                            expected = opening(deepcopy(value), deepcopy(image), formula=formula,
                                               depth=depth, lower=lower, width=width)
                            valid_expected = True
                        except Exception:
                            expected, valid_expected = None, False
                        require(valid == valid_expected and (not valid or actual == expected),
                                ('opening', width, value, image, formula, depth, lower, actual, expected))
                        counts['accepted' if valid else 'rejected'] += 1
    return dict(counts)


def paths(value, path=()):
    result = [path]
    if type(value) is list:
        for i, child in enumerate(value):
            result.extend(paths(child, (*path, i)))
    return result


def mutate(value, rng):
    value = deepcopy(value)
    path = rng.choice(paths(value))
    replacements = [None, True, False, -999, -1, 0, 1, 2, 3, 5, 999,
                    [], [0], [0, 0], [0, 0, 0, 0], {'bad': 0}, 'x', 0.0]
    replacement = deepcopy(rng.choice(replacements))
    if not path:
        return replacement
    parent = value
    for position in path[:-1]:
        parent = parent[position]
    parent[path[-1]] = replacement
    return value


def mutation_agreement(module, rows, width, count=2000):
    rng = random.Random(2026110803 + width)
    eligible = [row['packet'] for row in rows if row['expected'] and len(row['packet']) < 150]
    counts = Counter()
    for i in range(count):
        value = mutate(rng.choice(eligible), rng)
        actual, _ = agreement(module, value, width, 'mutation_' + str(i))
        counts['accepted' if actual['accepted'] else 'rejected'] += 1
    return {'cases': count, 'seed': 2026110803 + width, **dict(counts)}


def cli(path, packet_path, expected, optimized=False):
    command = [sys.executable, *(['-O'] if optimized else []), str(path), str(packet_path)]
    process = subprocess.run(command, capture_output=True, text=True, timeout=15)
    actual = (process.returncode, process.stdout.strip(), process.stderr)
    wanted = (0, 'ACCEPT', '') if expected else (1, 'REJECT', '')
    require(actual == wanted, ('public CLI', path.name, packet_path.name, optimized, actual))
    return {'optimized': optimized, 'exit_status': process.returncode,
            'stdout': process.stdout.strip()}
