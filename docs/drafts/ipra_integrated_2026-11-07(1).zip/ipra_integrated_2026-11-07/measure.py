"""Recompute the whole-program comparison, common driver, and ablations."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import tempfile

ROOT = Path(__file__).resolve().parent
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
spec = importlib.util.spec_from_file_location('source_measure', ROOT / 'comparison/source_measure.py')
metric = importlib.util.module_from_spec(spec)
spec.loader.exec_module(metric)


def minimum(rows):
    return {key: min(row['metrics'][key] for row in rows) for key in KEYS}


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    groups = {}
    for group in ('current_programs', 'expanded_complete_programs'):
        rows = []
        for item in manifest[group]:
            path = ROOT / item['file']
            if hashlib.sha256(path.read_bytes()).hexdigest() != item['sha256']:
                raise ValueError('Changed comparator: ' + item['file'])
            rows.append({**item, 'metrics': metric.metrics(path)})
        groups[group] = rows
    candidate = {'file': 'checker.py', 'metrics': metric.metrics(ROOT / 'checker.py')}
    baseline = minimum(groups['current_programs'])
    if minimum(groups['expanded_complete_programs']) != baseline:
        raise ValueError('The expanded comparison changes the frontier')
    candidate_tree = ast.parse((ROOT / 'checker.py').read_text())
    first_try = next(i for i, node in enumerate(candidate_tree.body) if isinstance(node, ast.Try))
    driver = candidate_tree.body[first_try:]
    controlled = []
    ablations = []
    scope = next(row for row in groups['current_programs']
                 if row['source_path'].endswith('ipra_scope_complement_2026-11-07/checker.py'))
    with tempfile.TemporaryDirectory(prefix='ipra_measure_') as tmp:
        for i, row in enumerate(groups['current_programs']):
            tree = ast.parse((ROOT / row['file']).read_text())
            last_function = max(j for j, node in enumerate(tree.body) if isinstance(node, ast.FunctionDef))
            tree.body = tree.body[:last_function + 1] + copy.deepcopy(driver)
            path = Path(tmp) / ('controlled_' + str(i) + '.py')
            path.write_text(ast.unparse(tree) + '\n')
            controlled.append({'source_path': row['source_path'], 'metrics': metric.metrics(path)})
        for raw_witness, shared_driver in ((False, False), (True, False), (False, True), (True, True)):
            tree = ast.parse((ROOT / scope['file']).read_text())
            if raw_witness:
                match = next(node for node in ast.walk(tree) if isinstance(node, ast.Match))
                introduction = next(case for case in match.cases
                                    if isinstance(case.pattern, ast.MatchSequence) and len(case.pattern.patterns) == 1)
                introduction.pattern = introduction.pattern.patterns[0]
                match.cases.remove(introduction)
                match.cases.append(introduction)
            if shared_driver:
                last_function = max(i for i, node in enumerate(tree.body) if isinstance(node, ast.FunctionDef))
                tree.body = tree.body[:last_function + 1] + copy.deepcopy(driver)
            path = Path(tmp) / ('ablation_' + str(len(ablations)) + '.py')
            path.write_text(ast.unparse(ast.fix_missing_locations(tree)) + '\n')
            ablations.append({'raw_witness': raw_witness, 'shared_driver': shared_driver,
                              'metrics': metric.metrics(path)})
    common = minimum(controlled)
    for name, frontier in (('supplied', baseline), ('common_driver', common)):
        if not all(candidate['metrics'][key] < frontier[key] for key in KEYS):
            raise ValueError('Candidate does not improve every ' + name + ' coordinate')
    result = {'python': platform.python_version(), 'implementation': platform.python_implementation(),
              'commit': manifest['commit'], 'archive_count': len(manifest['files']),
              'current_count': len(groups['current_programs']),
              'expanded_count': len(groups['expanded_complete_programs']),
              'expanded_paths': manifest['expanded_path_count'],
              'supplied_minimum': baseline, 'common_driver_minimum': common,
              'candidate': candidate, 'ablations': ablations, 'controlled': controlled, 'groups': groups}
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results/metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    table = ['\\begin{longtable}{@{}p{.63\\linewidth}rrr@{}}',
             '\\toprule Current complete program & Tokens & Nodes & Bytes\\\\\\midrule', '\\endhead']
    for row in groups['current_programs']:
        path = Path(row['source_path'])
        label = path.parts[0].replace('ipra_', '').replace('_2026-11-07', '') + ' / ' + path.name
        label = label.replace('_', '\\_')
        table.append('\\texttt{' + label + '} & ' + ' & '.join(str(row['metrics'][k]) for k in KEYS) + '\\\\')
    table += ['\\midrule Integrated candidate & ' + ' & '.join(str(candidate['metrics'][k]) for k in KEYS) + '\\\\',
              '\\bottomrule', '\\end{longtable}']
    (ROOT / 'results/current_table.tex').write_text('\n'.join(table) + '\n')
    print(json.dumps({key: result[key] for key in ('python', 'current_count', 'expanded_count',
                                                'expanded_paths', 'supplied_minimum', 'common_driver_minimum', 'candidate', 'ablations')}, indent=2))


if __name__ == '__main__':
    main()
