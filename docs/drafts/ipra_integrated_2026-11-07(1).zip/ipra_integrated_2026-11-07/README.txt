A SMALLER INTEGRATED KERNEL FOR iPRA
Prepared for Vladimir Reshetnikov, 7 November 2026
================================================

Read report.pdf. The complete editable report.tex and all included TeX
sections are supplied. This archive is self-contained for reproduction.

POSITIVE RESULT

The complete standalone checker.py measures:

  372 normalized Python tokens / 399 AST nodes / 1107 normalized bytes.

The current six-archive corpus at the pinned commit has ten root programs
and coordinatewise minimum 375 / 403 / 1117. A broader scan of 153 distinct
complete checkers at 742 source paths has the same minimum. With exactly
the candidate's command-line driver, the current envelope is 374/400/1109.
The candidate improves all three coordinates in both comparisons.

This small positive reduction integrates existing scope-complement opening,
raw witness instructions, and the public driver. It is not a new arithmetic
foundation or a proof of absolute shortestness. The report makes that
attribution explicit and gives isolated ablations.

MATHEMATICAL RESULT

The report strengthens two supplied initializer obstructions. A mixed
language of full counter-dependent recursions with fixed, update-derived,
and diagonal seeds has a finite rectangular unary decomposition for every
term, even with arbitrary unary helpers. Therefore finite lists of terms
cannot cover addition, and no infinite finite-dimensional quotient has an
injective pairing whose outputs admit a fixed finite native term cover.

The full-counter and diagonal grammar was already in the smaller-kernel
draft's domination theorem. The rectangular invariant and finite-cover
quotient obstruction were already proved for a narrower scalar grammar in
the staged-opening draft. The new contribution is the stronger invariant
for the mixed grammar.

A further proof combines this invariant with finite-witness extraction
from cut-free intuitionistic proofs. If the theory has the specified
H_vee axiom shape and the interpretation domain has that shape too, every
provably total graph admits a finite native term cover. Consequently no
such iPRA interpretation exists, even for arbitrary operation graphs and
quotient equality. This covers whole domains, quantifier-free domains,
and Harrop domains, and applies to ordinary fixed-seed full recursion
with equation induction and coverage. The report gives the exact grammar
and proof. Arbitrary definable domains remain open. The general
cut-elimination principle is standard; its application to this mixed
language and interpretation problem is the additional extension here.

STRENGTH

The delivered checker accepts the inherited five-pattern scalar-iteration
calculus. The report states every primitive schema and inference rule,
reconstructs full intuitionistic first-order logic, includes the internal
predecessor/reflection/pairing proofs, and gives both ordinary interpretation
composites. The ordinary realization is bi-interpretable and equiconsistent
with full first-order iPRA on the identity domain.

These are written mathematical proofs. No Lean or Rocq certification is
claimed. Finite tests support the implementation; they do not replace the
mathematical metatheory.

RUN

  python3 reproduce.py
  python3 checker.py validation/cases/addition_two_three.json
  python3 build.py

checker.py prints ACCEPT and exits 0, or prints REJECT and exits 1.
Reproduction uses only Python's standard library. Rebuilding the PDF also
requires pdfLaTeX and the packages listed in report.tex. No network is used.

FILES

  report.tex / report.pdf       Complete report and compiled PDF.
  checker.py                   Entire measured acceptance program.
  FORMAT.txt                   Public raw certificate format.
  sections/                    Result, kernel proof, obstruction, evidence.
  foundation/                  Attributed complete inherited strength proof.
  comparison/                  Frozen current and expanded sources and metric.
  validation/                  Independent named oracle, fixtures, replay.
  results/                     Metrics, validation results, build records.
  reproduce.py / build.py       Offline reproduction commands.
  ATTRIBUTION.txt               Exact contribution and provenance boundaries.
  LICENSE_INHERITED.txt         Preserved inherited source license.
  SHA256SUMS                   Final artifact hashes.

PINNED SOURCE

  Repository: VladimirReshetnikov/ProveIt
  Commit: 25e16049bbc73c92703296181e0696370c987577
  https://github.com/VladimirReshetnikov/ProveIt/tree/25e16049bbc73c92703296181e0696370c987577/docs/drafts

Do not use older quoted minima from the individual reports as the current
baseline. This archive remeasures the actual source files at this commit.
