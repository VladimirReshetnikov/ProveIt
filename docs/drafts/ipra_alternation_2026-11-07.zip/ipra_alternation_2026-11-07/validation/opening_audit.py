#!/usr/bin/env python3
"""Differential opening audit; proof formats are intentionally not compared here."""
from __future__ import annotations
import copy
import importlib.util
import hashlib
import itertools
import json
import random
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / 'comparison/sources/draft_5_checker.py'

def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj

reviewed_files = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in [BASELINE, ROOT / 'checker.py']}
old = module(BASELINE, 'scope_original')
new = module(ROOT / 'checker.py', 'scope_candidate')
counts = {}

def normalize(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'))

def inst_state(mod, a, env, d, initial):
    mod.k = initial
    try:
        result = mod.inst(copy.deepcopy(a), copy.deepcopy(env), d)
        return ('return', normalize(result), mod.k)
    except Exception:
        return ('error', None, mod.k)

def run(mod, document, context=()):
    stream = copy.deepcopy(document)
    mod.k = 0
    mod.take = stream.pop
    try:
        answer = mod.check(mod.take(), copy.deepcopy(list(context)))
        status = 'accept' if answer else 'false'
    except Exception:
        status = 'error'
    return (status, mod.k, normalize(stream))

# Exact comparison over a systematic shallow grammar, including every invalid
# root arity 0..4, scalar type, parity/depth class and multiple environments.
leaves = [None, False, True, -4, -1, 0, 1, 2, 3, '', {}, []]
shapes = list(leaves)
for n in range(1, 5):
    shapes.extend(list(t) for t in itertools.product(leaves, repeat=n))
shapes.extend([[0], [1], [0, 0], [[1, 1]], [[1, 1], [0, 0], [0, 0]],
               [0, 0, 1], [[0], 0, [1]], [[0], 0, [0, 0, 4]],
               [[[0], 0, [0, 0, 4]], 0]])
inst_cases = 0
for a in shapes:
    for d, env, initial in [(0, (), 0), (1, (), 0), (2, (), -8), (3, (), 0),
                             (4, [0, -5], 0), (5, [[0], [0, 0, 1]], 0),
                             (6, [False, 0], -1), (7, [[1], 0], 0)]:
        before = normalize(a)
        lhs = inst_state(old, a, env, d, initial)
        rhs = inst_state(new, a, env, d, initial)
        assert lhs == rhs, ('inst', a, env, d, lhs, rhs)
        assert normalize(a) == before
        inst_cases += 1
counts['systematic_inst_states'] = inst_cases

# On successful empty-environment validation, the cached result must be a
# structurally identical deep copy. This justifies replacing b = a by b=inst(a).
identity_cases = 0
for a in shapes:
    for d in range(8):
        new.k = 0
        try:
            b = new.inst(copy.deepcopy(a), d=d)
        except Exception:
            continue
        assert normalize(a) == normalize(b), ('identity', a, d, b)
        identity_cases += 1
counts['successful_empty_environment_identities'] = identity_cases


report = {'status': 'all opening comparisons passed', 'counts': counts, 'reviewed_files': reviewed_files,
          'scope': 'Substitution/validation only. The old and new proof stream languages intentionally differ.'}
output = ROOT / 'validation/opening_results.json'
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
