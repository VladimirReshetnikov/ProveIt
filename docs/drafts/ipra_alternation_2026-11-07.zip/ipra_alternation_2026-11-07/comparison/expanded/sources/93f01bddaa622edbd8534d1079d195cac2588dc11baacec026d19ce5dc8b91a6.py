"""Complete iPRA theorem checker with one certificate input stream."""
import json
import sys

def subst(a, env=[1], sort=True, d=0):
    if type(a) is int and not sort:
        i = a - d
        return a if i <= 0 else subst(env[i], [d], False) if i < len(env) else a + env[0]
    tag, *args = a
    return [tag] + [
        subst(b, env, width == 1, d + width)
        for b, width in zip(
            args,
            ({'=': b'\0\0', 'q': b'\1', 'ex': b'\1'}
             if sort else {'s': b'\0', 'r': b'\0\0\2'})[tag],
            strict=True,
        )
    ]

def check(a, g):
    subst(a)
    match (a, take()):
        case [['q', b], []]:
            h = [subst(b, [0, 0]), b][:len(b) - 1]
            b = subst(b, [0, ['s', 1]])
        case [['ex', b], [t]]:
            h = [['=', 1, subst(t, sort=False)]]
        case [_, [[tag, *parts] as m, t]] if check(m, g):
            if tag == 'ex':
                b, h = subst(a), parts
            else:
                if tag == 'q':
                    t, *parts = *parts, 0, subst(t, [0], False)
                b, c = (subst(t, [-1, v]) for v in parts)
                return c == a and check(b, g)
        case [[_, [_, n, t, h], b], []]:
            if n:
                _, n = n
                t = subst(h, [-2, ['r', n, t, h], n], False)
            return b == t
        case _:
            return a in g
    h += map(subst, g)
    return check(b, h)
if __name__ == '__main__':
    try:
        take = json.load(open(sys.argv[1])).pop
        if not check(take(), []):
            raise ValueError
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
