"""Complete fixed-slot iPRA theorem checker; input [goal, proof_stack].

The proof stack is consumed from its end.  Only this file and json/sys
participate in acceptance.  Negative integers are rigid parameter names,
not negative numbers.  Positive integers are de Bruijn coordinates.

The substitution state is d = 2 * binder_depth + sort, with sort 0 for
formulas and 1 for terms.  Thus constructor edges add 1 for equality's
term arguments, 2 for a unary formula binder, 0 for successor or the first
two recursor arguments, and 4 for the recursor's double-bound body.
Q elimination always instantiates at coordinate 1; its auxiliary annotation
is ignored.  Existential introduction still validates its numerical witness.
"""
import json
import sys

def subst(a, env=(1,), d=0):
    if type(a) is int and d % 2:
        i = a - d // 2
        return a if i <= 0 else subst(env[i - 1], (d // 2,), 1) if i < len(env) else a + env[-1]
    tag, *args = a
    return [tag] + [subst(b, env, d + width) for b, width in zip(args, ({'s': b'\0', 'r': b'\0\0\4'} if d % 2 else {'=': b'\1\1', 'q': b'\2', 'ex': b'\2'})[tag], strict=True)]

def check(a, p, g):
    subst(a)
    match (a, p.pop()):
        case [['q', b], []]:
            h = [subst(b, [0, 0]), b][:len(b) - 1]
            b = subst(b, [['s', 1], 0])
        case [['ex', b], [t]]:
            h = [['=', 1, subst(t, d=1)]]
        case [_, [[tag, *parts] as m, t]] if check(m, p, g):
            if tag == 'ex':
                b = subst(a)
                h = parts
            else:
                if tag == 'q':
                    t = parts[0]
                    parts = [0, 1]
                b, c = (subst(t, [v, -1]) for v in parts)
                return c == a and check(b, p, g)
        case [[_, [_, n, t, h], b], []]:
            if n:
                _, n = n
                t = subst(h, [['r', n, t, h], n, -2], d=1)
            return b == t
        case _:
            return a in g
    return check(b, p, list(map(subst, g)) + h)
if __name__ == '__main__':
    try:
        _, path = sys.argv
        if not check(*json.load(open(path, 'rb')), []):
            raise ValueError
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
