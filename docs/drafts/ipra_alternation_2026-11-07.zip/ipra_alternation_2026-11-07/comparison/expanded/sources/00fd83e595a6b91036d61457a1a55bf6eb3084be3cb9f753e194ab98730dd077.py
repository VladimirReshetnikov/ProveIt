"""iPRA theorem checker: unary closure, stack proofs, rigid parameters."""
import json
import sys

def subst(a, env=(1,), d=0, formula=True):
    if not formula and type(a) is int:
        i = a - d
        return a if i <= 0 else subst(env[i - 1], (d,), formula=False) if i < len(env) else a + env[-1]
    tag, *args = a
    return [tag, *(subst(b, env, d + width, width == 1) for b, width in zip(args, ({'=': b'\0\0', 'q': b'\1', 'ex': b'\1'} if formula else {'s': b'\0', 'r': b'\0\0\2'})[tag], strict=True))]

def check(a, p, g):
    subst(a)
    match (a, p.pop()):
        case [['q', b], []]:
            h = [subst(b, [0, 0])] + ([b] if b[0] == '=' else [])
            b = subst(b, [['s', 1], 0])
        case [['ex', b], [t]]:
            h = [['=', 1, subst(t, formula=False)]]
        case [_, [[tag, *parts] as m, t]] if check(m, p, g):
            if tag == 'ex':
                b, h = subst(a), parts
            else:
                if tag == 'q':
                    parts, t = [0, t], parts[0]
                b, c = (subst(t, [v, -1]) for v in parts)
                return c == a and check(b, p, g)
        case [[_, [_, n, t, h], b], []]:
            if n:
                _, n = n
                t = subst(h, [['r', n, t, h], n, -2], formula=False)
            return b == t
        case _:
            return a in g
    return check(b, p, [*map(subst, g), *h])
if __name__ == '__main__':
    try:
        _, path = sys.argv
        if not check(*json.load(open(path, 'rb')), []):
            raise ValueError
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
