"""Strict iPRA checker: arity syntax, fixed-variable closure, one input stream.

See report.tex and ATTRIBUTION.txt for the calculus, proof, and source lineage.
Only json/sys and this file participate in acceptance.  Environments are read
only; in particular the shared default list is never mutated.
"""
import json
import sys


def subst(a, env=[1], d=0, formula=True):
    if not formula and type(a) is int:
        i = a - d
        return a if i <= 0 else subst(env[i], [d], formula=False) if i < len(env) else a + env[0]
    return [subst(b, env, d + width, width == 1) for b, width in zip(a + [], ((None, b'\0', b'', b'\0\0\2'), (None, b'\1', b'\0\0', b'\1\1\1'))[formula][len(a)], strict=True)]

def check(a, g):
    b = subst(a)
    match (a, take()):
        case [_, [m, t]] if check(m, g):
            if len(m) == 3:
                h = m[:1]
            else:
                if len(m) == 1:
                    t, m = m[0], [0, 1]
                b, c = (subst(t, [-1, v]) for v in m)
                return c == a and check(b, g)
        case [[b], []]:
            h = [subst(b, [0, 0]), b][:2 - len(b) % 2]
            b = subst(b, [0, [1]])
        case [[b, _, _], [t]]:
            h = [[1, subst(t, formula=False)]]
        case [[[n, t, h], b], []]:
            if n:
                n, = n
                t = subst(h, [-2, [n, t, h], n], formula=False)
            return b == t
        case _:
            return a in g
    h += map(subst, g)
    return check(b, h)
if __name__ == '__main__':
    try:
        take = json.load(open(sys.argv[1])).pop
        if not check(take(), []):
            raise ValueError
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
