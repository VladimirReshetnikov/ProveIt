"""Complete iPRA stack checker with unary closure and rigid parameters."""
import json
import sys

def subst(a, env=(1,), d=0, formula=True):
    if type(a) is int and not formula:
        i = a - d
        return a if i <= 0 else subst(env[i - 1], (d,), formula=False) if i < len(env) else a + env[-1]
    tag, *args = a
    return [tag, *(subst(b, env, d + width, width == 1) for b, width in zip(args, ({'=': b'\0\0', 'u': b'\1', 'ex': b'\1'} if formula else {'s': b'\0', 'r': b'\0\0\2'})[tag], strict=True))]

def check(a, p, g):
    lifted = subst(a)
    match (a, p.pop()):
        case [['u', b], []]:
            h = [subst(b, [0, 0]), b][:len(b) - 1]
            b = subst(b, [['s', 1], 0])
        case [['ex', b], [t]]:
            h = [['=', 1, subst(t, formula=False)]]
        case [_, [[tag, *parts] as m, t]] if check(m, p, g):
            if tag == 'ex':
                b, h = lifted, parts
            else:
                if tag == 'u':
                    t, parts = *parts, [0, t]
                b, c = (subst(t, [v, -1]) for v in parts)
                return c == a and check(b, p, g)
        case [[_, [_, n, t, h], b], []]:
            if n:
                _, n = n
                t = subst(h, [['r', n, t, h], n, -2], formula=False)
            return b == t
        case _:
            return a in g
    return check(b, p, [*map(subst, g), *h])
if __name__ == '__main__':
    try:
        _, path = sys.argv
        if not check(*json.load(open(path, 'rb')), []):
            raise ValueError
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
