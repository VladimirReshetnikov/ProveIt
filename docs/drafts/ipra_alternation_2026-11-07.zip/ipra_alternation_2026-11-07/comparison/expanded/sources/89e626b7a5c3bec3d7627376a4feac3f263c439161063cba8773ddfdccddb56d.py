"""Complete iPRA theorem checker using constructor arities; demand witness validation."""
import json
import sys


def subst(a, env=(1,), d=0, formula=True):
    if not formula and type(a) is int:
        i = a - d
        return a if i <= 0 else subst(env[i - 1], (d,), formula=False) if i < len(env) else a + env[-1]
    assert type(a) is list
    return [subst(b, env, d + width, width == 1) for b, width in zip(a, ((b'\0', b'', b'\0\0\2'), (b'\1', b'\0\0', b'\1\1\1'))[formula][len(a) - 1], strict=True)]

def check(a, p, g):
    subst(a)
    match (a, p.pop()):
        case [[b], []]:
            h = [subst(b, [0, 0]), b][:2 - len(b) % 2]
            b = subst(b, [[1], 0])
        case [[b, _, _], [t]]:
            h = [[1, subst(t, formula=False)]]
        case [_, [m, t]] if check(m, p, g):
            if len(m) == 3:
                b, h = subst(a), m[:1]
            else:
                if len(m) == 1:
                    t, m = m[0], [0, t]
                b, c = (subst(t, [v, -1]) for v in m)
                return c == a and check(b, p, g)
        case [[[n, t, h], b], []]:
            if n:
                n, = n
                t = subst(h, [[n, t, h], n, -2], formula=False)
            return b == t
        case _:
            return a in g
    return check(b, p, [*map(subst, g), *h])
if __name__ == '__main__':
    try:
        _, path = sys.argv
        if not check(*json.load(open(path, 'rb')), []):
            raise ValueError
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
