"""Complete strict iPRA checker: input [goal, stack], next item at the END.
Only this file and json/sys participate in acceptance. See FORMAT.txt.
Negative integers name rigid free parameters, not negative numbers.
"""
import json
import sys


def subst(a, env=(1,), d=0, formula=True):
    """Validate and substitute; env[:-1] replaces slots, env[-1] shifts the rest.
    d counts bound slots. Default: raise ordinary free slots, preserve rigid names.
    Scope widths 0,2 select terms; 1 selects a formula. Strict zip checks arity.
    """
    if not formula and type(a) is int:
        i = a - d
        return a if i <= 0 else subst(env[i - 1], (d,), formula=False) if i < len(env) else a + env[-1]
    tag, *args = a
    return [tag, *(subst(b, env, d + int(width), width == '1') for b, width in zip(args, ({'=': '00', 'q': '1', 'ex': '1'} if formula else {'s': '0', 'r': '002'})[tag], strict=True))]

def check(a, p, g):
    """Consume a stack under a well-formed context; the public context is empty.
    Local assumptions preserve validity. Unused leading annotations are allowed.
    """
    subst(a)
    match (a, p.pop()):
        case [['q', b], []]:
            # Retain B(0), and zero or one copies of the equation-only IH.
            h = [subst(b, [0, 0])] + [b] * (b[0] == '=')
            b = subst(b, [['s', 1], 0])
        case [['ex', b], [t]]:
            h = [['=', 1, subst(t, formula=False)]]
        case [_, [[tag, *parts] as m, t]] if check(m, p, g):
            if tag == 'ex':
                b, h = subst(a), parts
            else:
                if tag == 'q':
                    # Validate even a numerical witness absent from the matrix.
                    subst(t, formula=False)
                    parts, t = [0, t], *parts
                b, c = (subst(t, [v, -1]) for v in parts)
                return c == a and check(b, p, g)
        case [[_, [_, n, t, h], b], []]:
            # Sorted syntax and these arities force equality and recursion.
            if n:
                _, n = n
                t = subst(h, [['r', n, t, h], n, -2], formula=False)
            return b == t
        case _:
            return a in g
    return check(b, p, [*map(subst, g), *h])
if __name__ == '__main__':
    try:
        _, path = sys.argv
        if not check(*json.load(open(path, 'rb')), []):
            raise ValueError
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
