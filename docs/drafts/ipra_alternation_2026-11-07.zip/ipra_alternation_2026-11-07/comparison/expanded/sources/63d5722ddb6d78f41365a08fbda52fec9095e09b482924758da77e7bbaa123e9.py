"""Independent focused audit of chosen locally closed arity checker.
No package validation code is imported. This checks the public CLI as well
as explicit negative-name freshness and malformed-syntax invariants.
"""
from copy import deepcopy
from pathlib import Path
import hashlib,importlib.util,json,random,subprocess,sys,tempfile
HERE=Path(__file__).resolve().parent
CANDIDATE=HERE.parent/'checker.py'
spec=importlib.util.spec_from_file_location('chosen_fresh',CANDIDATE)
K=importlib.util.module_from_spec(spec);spec.loader.exec_module(K)

def accepted(doc):
    try:
        p=deepcopy(doc);K.k=0;K.take=p.pop
        result=K.check(K.take(),[])
        return result is True,K.k,len(p)
    except Exception:return False,K.k,None

def formation(a,formula=True,depth=0):
    if not formula and type(a) is int:return a<=depth
    if type(a) is not list:return False
    if formula:
        if len(a)==2:return all(formation(x,False,depth) for x in a)
        if len(a) in (1,3):return all(formation(x,True,depth+1) for x in a)
        return False
    if len(a)==1:return formation(a[0],False,depth)
    if len(a)==3:
        return formation(a[0],False,depth) and formation(a[1],False,depth) and formation(a[2],False,depth+2)
    return False

rows=[]
def check(name,doc,want):
    got,k,left=accepted(doc)
    if got!=want:raise AssertionError((name,want,got,k,doc))
    rows.append({'name':name,'document':doc,'expected':want,'allocator_after':k,'unread_prefix':left})
T=[0,0];D=[0,[0]];q=[0,0,0];C=[q,0]
reflex=[[],[],[C,[1,0]]]
M=[[1,0],T,T]
major_proof=reflex+[[0]]
check('primitive computation',[[],C],True)
check('derived reflexivity',reflex+[T],True)
check('ordinary existential introduction',major_proof+[M],True)
check('valid existential elimination',
      [None,None,[[-1,0],[1,0]]]+major_proof+[[M,None],T],True)
for index,p in enumerate([-1,-2,-999999999]):
    check(f'existential eigenvariable escape {index}',[None]+major_proof+[[M,None],[p,0]],False)
# An unused ghost reserves its rigid parameter, so the fresh name is -7001.
Mg=[[1,0],[-7000,-7000],T]
check('ghost parameter reserves allocator',
      [None,None,[[-7001,0],[1,0]]]+major_proof+[[Mg,None],T],True)
check('ghost parameter prevents stale fresh name',
      [None,None,[[-1,0],[1,0]]]+major_proof+[[Mg,None],T],False)
# No ghost may be used as a logical hypothesis, even though it is scanned.
Mbad=[C,D,D]
check('existential ghosts never become assumptions',[None,[],[0],[Mbad,None],D],False)
check('unbound positive coordinate goal',[[],[[0,1,0],1]],False)
check('bound accumulator allowed',[[],[[0,0,1],0]],True)
check('bound predecessor allowed',[[],[[0,0,2],0]],True)
check('unbound recursor update coordinate',[[],[[0,0,3],0]],False)
check('unbound quantified coordinate',[None,[],[[1,2]]],False)
check('nonconstructor numerical counter',[[],[[-1,0,0],0]],False)
check('recursive numerical counter is not zero syntax',[[],[[q,0,0],0]],False)
check('false arithmetic equation',[[],D],False)
check('wrong successor computation',[[],[[[0],0,[1]],0]],False)

invalid_terms=[None,True,False,0.0,1.2,'','x',{},[],[0,0],[0,0,0,0],[True],[0,0,True],1,17]
for i,t in enumerate(invalid_terms):
    check(f'strict vacuous existential witness {i}',[[],[t],[C,T,T]],False)
    check(f'malformed zero-recursion update {i}',[[],[[0,0,t],0]],False) if not (type(t) is int and t in (1,2)) else None
    check(f'malformed zero-recursion initializer {i}',[[],[[0,t,0],t]],False)
invalid_formulas=[None,False,True,0,1,-1,0.0,'',{},[],[0],[0,0,0],[0,0,0,0],[True,0]]
for i,f in enumerate(invalid_formulas):
    check(f'malformed first ghost {i}',major_proof+[[[1,0],f,T]],False)
    check(f'malformed second ghost {i}',major_proof+[[[1,0],T,f]],False)

# This formation function is independent of the kernel's parity/signature table.
rng=random.Random(1447)
raw=[None,False,True,0,1,2,3,-1,-17,1.0,'',{},[],[0],[0,0],[0,0,0],[[0,0]],[[1,1]], [[0,0],[0,0],[0,0]], [0,0,1],[0,0,2],[0,0,3]]
for _ in range(180):raw.append([deepcopy(rng.choice(raw[:24])) for _ in range(rng.randrange(5))])
formation_count=0
for a in raw:
    for formula in (False,True):
        for depth in range(3):
            K.k=0
            try:K.inst(a,(),2*depth+int(not formula));result=True
            except Exception:result=False
            want=formation(a,formula,depth)
            if result!=want:raise AssertionError(('formation',a,formula,depth,result,want))
            formation_count+=1

cli=[]
with tempfile.TemporaryDirectory() as td:
    for i,row in enumerate(rows):
        p=Path(td)/f'{i}.json';p.write_text(json.dumps(row['document'])+'\n')
        for optimized in (False,True):
            args=[sys.executable]+(['-O'] if optimized else [])+[str(CANDIDATE),str(p)]
            proc=subprocess.run(args,capture_output=True,text=True,timeout=5)
            expected=row['expected']
            if proc.returncode!=(0 if expected else 1) or proc.stdout.strip()!=('ACCEPT' if expected else 'REJECT') or proc.stderr:
                raise AssertionError(('CLI',row['name'],optimized,proc.returncode,proc.stdout,proc.stderr))
            cli.append({'name':row['name'],'optimized':optimized,'passed':True})
result={'candidate_sha256':hashlib.sha256(CANDIDATE.read_bytes()).hexdigest(),
        'focused_cases':len(rows),'focused_acceptances':sum(r['expected'] for r in rows),
        'focused_rejections':sum(not r['expected'] for r in rows),
        'independent_formation_comparisons':formation_count,
        'actual_cli_runs':len(cli),'normal_cli_runs':len(rows),'optimized_cli_runs':len(rows),'failures':[],
        'case_results':[{k:v for k,v in r.items() if k!='document'} for r in rows],'cli_results':cli}
(HERE.parent/'results/independent_audit.json').write_text(json.dumps(result,indent=2)+'\n')
(HERE.parent/'results/independent_fixtures.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('case_results','cli_results')},indent=2))
