"""Untrusted, named-AST demonstration of the alternating-prefix normalizer.

This is NOT a proof checker, a proof-certificate translator, or a machine
formalization of the metatheorem. Its finite tests check syntax, binding,
idempotence, and substitution coherence; they do not establish intuitionistic
soundness or completeness. No acceptance program imports this file.

Terms (tuples in Python, arrays in JSON):
  ("0",), ("v", name), ("S", term), ("R", counter, initial, u, v, update)
Only the update is in the scope of the two distinct recursor names u and v.
Formulas: ("=", left, right), ("Q", name, matrix), ("E", name, matrix).

Run from the archive root:
  python3 research/alternating_normalizer.py
This runs the finite structural checks and writes results/normal_forms.json.
"""
from itertools import product
import argparse
import json
from pathlib import Path


ZERO = ("0",)


def names(tree):
    """A conservative set of every string in a syntax tree."""
    if isinstance(tree, str):
        return {tree}
    if isinstance(tree, (tuple, list)):
        return set().union(*(names(child) for child in tree))
    raise ValueError("Syntax contains a non-string, non-sequence object")


class Fresh:
    def __init__(self, used, prefix="_a"):
        self.used, self.prefix, self.counter = set(used), prefix, 0

    def __call__(self):
        while f"{self.prefix}{self.counter}" in self.used:
            self.counter += 1
        name = f"{self.prefix}{self.counter}"
        self.used.add(name)
        self.counter += 1
        return name


def term_free(t):
    """Term validation and a separate, scope-sensitive free-variable pass."""
    match t:
        case ("0",):
            return set()
        case ("v", str(x)):
            return {x}
        case ("S", a):
            return term_free(a)
        case ("R", n, a, str(u), str(v), h) if u != v:
            return term_free(n) | term_free(a) | (term_free(h) - {u, v})
        case _:
            raise ValueError(f"Malformed term: {t!r}")


def formula_free(a):
    match a:
        case ("=", s, t):
            return term_free(s) | term_free(t)
        case ("Q" | "E", str(x), b):
            return formula_free(b) - {x}
        case _:
            raise ValueError(f"Malformed formula: {a!r}")


def gate(z, a, fresh):
    """G_z, used only with a selector name fresh for the whole source."""
    if a[0] == "=":
        def selector(t):
            u, v = fresh(), fresh()
            return ("R", ("v", z), ZERO, u, v, t)
        return ("=", selector(a[1]), selector(a[2]))
    return (a[0], a[1], gate(z, a[2], fresh))


def normalize(a):
    """Implement the two displayed clauses of the mathematical N map."""
    formula_free(a)
    fresh = Fresh(names(a))

    def visit(f):
        if f[0] == "=":
            return f
        tag, x, child = f
        b = visit(child)
        if tag == "Q" and b[0] == "Q":
            return ("Q", x, ("E", fresh(), b))
        if tag == "E" and b[0] != "Q":
            z = fresh()
            return ("E", x, ("Q", z, gate(z, b, fresh)))
        return (tag, x, b)

    return visit(a)


def prefix(a):
    result = []
    while a[0] in ("Q", "E"):
        result.append(a[0])
        a = a[2]
    return "".join(result)


def canonical(a):
    word = prefix(a)
    return (not word or word[-1] == "Q") and all(
        left != right for left, right in zip(word, word[1:])
    )


def alpha_key(tree, environment=()):
    """Independent nameless representation for alpha-equivalence checks.

    Recursor binders scope only over the update. For a shadowed name,
    environment.index selects its nearest binding occurrence.
    """
    tag = tree[0]
    if tag == "v":
        x = tree[1]
        return ("bound", environment.index(x)) if x in environment else ("free", x)
    if tag in ("Q", "E"):
        return (tag, alpha_key(tree[2], (tree[1],) + environment))
    if tag == "R":
        _, n, a, u, v, h = tree
        return (tag, alpha_key(n, environment), alpha_key(a, environment),
                alpha_key(h, (u, v) + environment))
    return (tag,) + tuple(alpha_key(c, environment) for c in tree[1:])


def substitute(a, variable, replacement):
    """Capture-avoiding substitution via prior global binder freshening.

    This routine is independent of normalize/gate. All input binders are
    renamed away from the source and replacement names. Ordinary replacement
    of the remaining free occurrences is then capture avoiding.
    """
    formula_free(a)
    term_free(replacement)
    fresh = Fresh(names(a) | names(replacement) | {variable}, "_r")

    def rename(tree, environment):
        tag = tree[0]
        if tag == "v":
            return (tag, environment.get(tree[1], tree[1]))
        if tag in ("Q", "E"):
            _, x, b = tree
            y = fresh()
            return (tag, y, rename(b, environment | {x: y}))
        if tag == "R":
            _, n, a0, u, v, h = tree
            u1, v1 = fresh(), fresh()
            return (tag, rename(n, environment), rename(a0, environment), u1, v1,
                    rename(h, environment | {u: u1, v: v1}))
        return (tag,) + tuple(rename(c, environment) for c in tree[1:])

    def replace(tree):
        if not isinstance(tree, (tuple, list)):
            return tree
        if tree[0] == "v" and tree[1] == variable:
            return replacement
        return tuple(replace(c) for c in tree)

    return replace(rename(a, {}))


def wrap(word, atom):
    for i in reversed(range(len(word))):
        # Repeated names deliberately exercise ordinary lexical shadowing.
        atom = (word[i], f"x{i % 3}", atom)
    return atom


def self_check():
    v = lambda x: ("v", x)
    matrices = [
        ("=", ZERO, ("S", ZERO)),
        ("=", v("outside"), v("x0")),
        ("=", ("R", v("x0"), v("outside"), "x0", "q",
               ("R", v("q"), v("x0"), "x0", "q", ("S", v("x0")))),
         v("x1")),
        ("=", v("_a0"), ("R", v("x1"), v("_a1"), "u", "v", ("S", v("u")))),
    ]
    substitutions = [
        ("outside", ZERO),
        ("outside", v("x0")),  # Would be captured without freshening.
        ("x0", ("S", v("_a0"))),
        ("_a0", ("R", v("x1"), v("outside"), "u", "v", v("u"))),
    ]
    formulas = coherence = 0
    for length in range(7):
        for letters in product("QE", repeat=length):
            for atom in matrices:
                a = wrap("".join(letters), atom)
                b = normalize(a)
                assert canonical(b)
                assert normalize(b) == b
                assert formula_free(a) == formula_free(b)
                assert (a[0] == "=") == (b[0] == "=")
                assert a[0] == b[0]
                # Freshening preserves binding independently of normalization.
                assert alpha_key(substitute(a, "absent", ZERO)) == alpha_key(a)
                formulas += 1
                for x, t in substitutions:
                    left = normalize(substitute(a, x, t))
                    right = substitute(b, x, t)
                    assert alpha_key(left) == alpha_key(right)
                    coherence += 1

    # A deliberate capture error must not pass the nameless comparison.
    captured = ("Q", "x", ("=", v("x"), ZERO))
    intended = substitute(("Q", "x", ("=", v("outside"), ZERO)), "outside", v("x"))
    assert alpha_key(captured) != alpha_key(intended)
    # A variable in the initializer is outside the recursor's binder scope.
    scoped = ("R", ZERO, v("u"), "u", "v", v("u"))
    assert term_free(scoped) == {"u"}
    assert alpha_key(scoped)[2] == ("free", "u")
    assert alpha_key(scoped)[3] == ("bound", 0)

    return {"formula_cases": formulas, "substitution_coherence_cases": coherence,
            "negative_capture_control": "passed", "recursor_scope_control": "passed",
            "scope": "finite structural tests; not a formal proof of the metatheorem"}


def main():
    default = Path(__file__).resolve().parents[1] / "results" / "normal_forms.json"
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=default)
    args = parser.parse_args()
    atom = ("=", ("v", "x0"), ("v", "x1"))
    examples = []
    for word in ("", "Q", "E", "QQ", "EE", "QEQE", "QQEEEQ"):
        source = wrap(word, atom)
        target = normalize(source)
        examples.append({"source_prefix": word, "target_prefix": prefix(target),
                         "source": source, "normalized": target})
    result = {"artifact": "untrusted alternating-prefix formula compiler",
              "tests": self_check(), "examples": examples}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result["tests"], sort_keys=True))


if __name__ == "__main__":
    main()
