"""Create a clean reproducible archive and a manifest of package contents."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent


def included(path):
    relative = path.relative_to(ROOT)
    return (path.is_file() and '__pycache__' not in relative.parts
            and path.suffix not in {'.pyc', '.pyo', '.aux', '.log', '.toc', '.out'}
            and not any(part.startswith('.') for part in relative.parts))


def main():
    files = sorted(path for path in ROOT.rglob('*')
                   if included(path) and path.name != 'MANIFEST.sha256')
    text = ''.join(hashlib.sha256(path.read_bytes()).hexdigest() + '  '
                   + path.relative_to(ROOT).as_posix() + '\n' for path in files)
    manifest = ROOT / 'MANIFEST.sha256'
    manifest.write_text(text)
    destination = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted([*files, manifest]):
            info = zipfile.ZipInfo(ROOT.name + '/' + path.relative_to(ROOT).as_posix(),
                                   date_time=(2026, 11, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise ValueError('Archive integrity failure')
    print(destination)
    print('Files:', len(files) + 1)
    print('Bytes:', destination.stat().st_size)
    print('SHA256:', hashlib.sha256(destination.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
