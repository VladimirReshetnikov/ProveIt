"""Reproduce the complete-program comparison against the pinned current corpus."""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import platform

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('unchanged_source_measure', ROOT / 'comparison/source_measure.py')
measurement = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measurement)
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    rows = []
    for item in manifest['programs']:
        actual = measurement.metrics(ROOT / item['local_file'])
        if actual['sha256'] != item['sha256']:
            raise ValueError('Changed baseline: ' + item['local_file'])
        rows.append({**item, **actual})
    minimum = {key: min(row[key] for row in rows) for key in KEYS}
    core_minimum = {key: min(row['core'][key] for row in rows) for key in KEYS}
    proposed = measurement.metrics(ROOT / 'checker.py')
    expanded = json.loads((ROOT / 'comparison/expanded/manifest.json').read_text())
    extra = []
    for item in expanded['programs']:
        actual = measurement.metrics(ROOT / item['local_file'])
        if actual['sha256'] != item['sha256']:
            raise ValueError('Changed expanded baseline: ' + item['local_file'])
        extra.append(actual)
    expanded_minimum = {key: min(row[key] for row in extra) for key in KEYS}
    if expanded_minimum != minimum:
        raise ValueError('Expanded inventory has a different envelope')
    if not all(proposed[key] < minimum[key] for key in KEYS):
        raise ValueError('The full-program reduction was not reproduced')
    if not all(proposed['core'][key] < core_minimum[key] for key in KEYS):
        raise ValueError('The core reduction was not reproduced')
    results = {
        'python': platform.python_version(), 'implementation': platform.python_implementation(),
        'commit': manifest['commit'], 'archive_count': len(manifest['archives']),
        'program_count': len(rows), 'coordinatewise_minimum': minimum,
        'core_coordinatewise_minimum': core_minimum,
        'expanded_paths': expanded['paths'], 'expanded_distinct_sources': len(extra),
        'expanded_coordinatewise_minimum': expanded_minimum,
        'proposed': proposed, 'programs': rows,
        'relative_reduction': {key: (minimum[key] - proposed[key]) / minimum[key] for key in KEYS},
        'measurement_source_sha256': hashlib.sha256((ROOT / 'comparison/source_measure.py').read_bytes()).hexdigest(),
        'scope': 'Strict finite-corpus comparison. No global shortestness claim.'}
    out = ROOT / 'results'
    out.mkdir(exist_ok=True)
    (out / 'metrics.json').write_text(json.dumps(results, indent=2) + '\n')
    with (out / 'comparison.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, ('archive', 'member', 'interface', *KEYS, 'sha256'), extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)
    labels = ['Arity parameters', 'Combined', 'Fresh arity', 'Integrated (1)', 'Integrated', 'Scope']
    table = ['\\begin{tabular}{@{}llrrr@{}}', '\\toprule',
             'Archive & Program & Tokens & AST nodes & Bytes\\\\', '\\midrule']
    for row in rows:
        index = int(Path(row['local_file']).name.split('_')[1])
        program = Path(row['member']).name.replace('_', '\\_')
        table.append(f"{labels[index]} & \\texttt{{{program}}} & {row['normalized_tokens']} & {row['ast_nodes']} & {row['normalized_bytes']}\\\\")
    table.extend(['\\midrule',
        f"\\multicolumn{{2}}{{l}}{{Coordinatewise minima}} & {minimum['normalized_tokens']} & {minimum['ast_nodes']} & {minimum['normalized_bytes']}\\\\",
        f"\\multicolumn{{2}}{{l}}{{Proposed checker}} & \\textbf{{{proposed['normalized_tokens']}}} & \\textbf{{{proposed['ast_nodes']}}} & \\textbf{{{proposed['normalized_bytes']}}}\\\\",
        '\\bottomrule', '\\end{tabular}'])
    (out / 'comparison_table.tex').write_text('\n'.join(table) + '\n')
    numbers = {'NewTokens': proposed['normalized_tokens'], 'NewAST': proposed['ast_nodes'],
               'NewBytes': proposed['normalized_bytes'], 'BaseTokens': minimum['normalized_tokens'],
               'BaseAST': minimum['ast_nodes'], 'BaseBytes': minimum['normalized_bytes'],
               'NewCoreTokens': proposed['core']['normalized_tokens'], 'NewCoreAST': proposed['core']['ast_nodes'],
               'NewCoreBytes': proposed['core']['normalized_bytes'],
               'BaseCoreTokens': core_minimum['normalized_tokens'], 'BaseCoreAST': core_minimum['ast_nodes'],
               'BaseCoreBytes': core_minimum['normalized_bytes']}
    (out / 'numbers.tex').write_text(''.join('\\newcommand{\\' + key + '}{' + str(value) + '}\n' for key, value in numbers.items()))
    print(json.dumps({key: results[key] for key in ('python', 'program_count', 'coordinatewise_minimum',
          'core_coordinatewise_minimum', 'expanded_paths', 'expanded_distinct_sources', 'proposed')}, indent=2))


if __name__ == '__main__':
    main()
