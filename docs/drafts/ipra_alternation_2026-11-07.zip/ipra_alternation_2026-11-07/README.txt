A SMALLER iPRA CHECKER AND AN ALTERNATING-PREFIX PRESENTATION
==========================================================
Prepared for Vladimir Reshetnikov, 7 November 2026 (Pacific date).

RESULT
------
The complete standalone checker is strictly below each separate minimum
among all TEN current top-level checkers in SIX ProveIt draft archives at:

    8b00e6ea50c664476e3a3289a78287946e5e0a34

Complete-program normalized measurements, CPython 3.12.14:

                               Tokens    AST nodes    UTF-8 bytes
  Current coordinatewise minima   457          469          1352
  Proposed checker                448          466          1348

The main checker retains arbitrary free numerical parameters. The
comparison includes the previous narrower closed-sentence checker.
The expanded inventory (110 source paths / 50 distinct programs) has
the same envelope. The diagnostic core also beats all three minima:
388 / 401 / 1088, versus 397 / 404 / 1092.

The gain is modest: 9 tokens, 3 AST nodes, and 4 normalized bytes. This
is a finite-corpus result, not an absolute shortestness theorem.

MATHEMATICAL CONTENT
--------------------
The native language has 0, successor, initialized primitive recursion,
equality, closure Q, and existence E. Q_x B reads B(0) -> forall x B.
There are six inference patterns and two recursion-computation schemas.
Closure introduction retains B(0), and supplies B(y) only for a literal
equation. The article states every rule, derives full intuitionistic
logic and quantifier-free induction, and proves whole-domain ordinary
bi-interpretability with iPRA. Both composite object isomorphisms are
the identity graph x=y.

The arithmetic foundation and much of its detailed proof are inherited
from the supplied scope draft and its predecessors, with attribution.

NEW CONTRIBUTIONS RELATIVE TO THE INSPECTED DRAFTS
------------------------------------------------
1. An assumption already present in the context closes its goal without
   consuming an instruction. Every finite derivation admits this pruning.
   The delivered old-to-new certificate translator handles entire pruned
   subtrees, scoped eigenvariable renaming, and specialization of free
   auxiliary parameters absent from the external sequent.
2. An exact flattened grammar table, cached validation, and reordered
   reusable induction assumptions produce the measured checker reduction.
3. Every native derivation can be translated to a restricted language
   with a strictly alternating Q/E prefix, ending in Q above its equation.
   The prefix needs only its length. The article proves the translation
   inside the restricted calculus. This is not a prenex theorem for the
   ordinary intuitionistic forall/exists vocabulary. The first separate
   prefix-length checker was larger, so it is not delivered as an improved
   acceptance kernel.

START HERE
----------
  report.pdf                  Complete compiled article
  report.tex, sections/*.tex   Complete LaTeX sources
  checker.py                  The entire measured acceptance program
  FORMAT.txt                  Syntax, instruction, and error contract
  translator.py               Untrusted transport from frozen scope proofs
  examples/transported/       49 empty-context public theorem certificates
  research/alternating_normalizer.py
                              Untrusted named-syntax normal-form compiler

QUICK RUN
---------
  python3 checker.py examples/reflexivity_zero.json
  python3 checker.py examples/vacuous_closure.json
  python3 checker.py examples/transported/pruned_allocation_and_later_free_name.json

Each prints ACCEPT and returns exit status 0. Rejection prints REJECT
and returns exit status 1. The kernel requires Python 3.10 or newer.
It imports only json and sys. It uses no assert as an acceptance gate.

REPRODUCE OFFLINE
----------------
  python3 reproduce.py
  python3 build.py

Or run python3 reproduce.py --pdf. The validation uses only the Python
standard library. Building the PDF requires pdfLaTeX and the ordinary
packages named in report.tex. Exact normalized counts were measured
with CPython 3.12.14. No reproduction step accesses the network.

The complete source measurement function is copied unchanged from the
arity-parameters archive. Baselines are byte-for-byte frozen and hashed.
The independent numeric evaluator computes bounded closed recursor terms
by iteration and does not call the kernel's instantiation function.

EVIDENCE
--------
  results/metrics.json, comparison.csv
      All ten complete-source measurements and the expanded envelope.
  results/transport.json
      45 inherited public theorems, 21 internal open sequents, 4 focused
      public examples, 6 rejected inputs, and 159 actual CLI executions.
      The inherited 901 source instructions become 860 target instructions.
  validation/opening_results.json
      181,128 differential opening states and 664 cached-copy checks.
  validation/independent_results.json
      Independent numerical checks, malformed-input checks, 7,921 equation
      attacks, 11,750 proof mutations, and all 49 transported public goals.
  results/normal_forms.json
      508 normalization cases and 2,032 substitution-coherence cases,
      including capture and recursor-scope controls.

These cohorts are distinct kinds of evidence and are not added into a
count of distinct mathematical theorems. All tests passed. Finite tests
are not a machine-checked proof of the metatheory or of consistency.

IMPORTANT INTERFACES
--------------------
The public checker ALWAYS starts with an empty assumption context.
The 21 open-sequent fixtures are internal tests with explicit hypotheses;
they are not public theorem certificates. Old streams need translation
because automatic hypothesis leaves do not consume instructions.

Witness validation is demand based: every used substitution image is
checked as a locally closed numerical term; unused witness data may be
ignored. Inert existential fields are validated formulas. An unused
prefix of the certificate stream is ignored. Canonical emitted proofs
have no unused cells. See FORMAT.txt for the precise contract.

As with the supplied Python kernels, algorithmic completeness presumes
unbounded execution resources; Python's finite parser/recursion/memory
limits can reject sufficiently large otherwise valid certificates.

ATTRIBUTION AND INTEGRITY
-------------------------
  ATTRIBUTION.txt              What is inherited and what is added
  LICENSE_SOURCE.txt           Upstream MIT No Attribution license
  comparison/manifest.json    Current archive identities and source hashes
  comparison/expanded/        50 exact baseline sources and 110 path mappings
  validation/source_transport/manifest.json
                              Frozen certificate provenance
  MANIFEST.sha256              Hashes of all delivered package files

Before rebuilding, verify with:
  sha256sum -c MANIFEST.sha256

The archive can be regenerated with python3 package.py. Rebuilding or
deliberately editing files changes their hashes; package.py regenerates
the manifest. The archive includes no temporary PDF renders or unvalidated
experimental acceptance program. No Lean/Rocq formalization or globally
minimal complete combinator calculus is claimed.
