"""Rerun all delivered measurements and implementation checks offline."""
from pathlib import Path
import argparse
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pdf', action='store_true')
    args = parser.parse_args()
    jobs = ['measure.py', 'validation/transport_test.py', 'validation/opening_audit.py',
            'validation/independent_review.py', 'research/alternating_normalizer.py']
    if args.pdf:
        jobs.append('build.py')
    for filename in jobs:
        print('Running ' + filename, flush=True)
        subprocess.run([sys.executable, str(ROOT / filename)], cwd=ROOT, check=True)
    print('All requested reproduction steps passed.')


if __name__ == '__main__':
    main()
