"""Build report.pdf from the complete local LaTeX sources."""
from pathlib import Path
import json
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def main():
    with tempfile.TemporaryDirectory(prefix='ipra_tex_') as directory:
        command = ['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
                   '-output-directory=' + directory, 'report.tex']
        for _ in range(3):
            result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
            if result.returncode:
                raise RuntimeError(result.stdout[-12000:] + result.stderr[-2000:])
        log = (Path(directory) / 'report.log').read_text(errors='replace')
        if 'There were undefined references' in log or 'Citation `' in log:
            raise RuntimeError('Unresolved references or citations in final LaTeX pass')
        shutil.copyfile(Path(directory) / 'report.pdf', ROOT / 'report.pdf')
        warnings = [line for line in log.splitlines() if 'Overfull' in line or 'Warning:' in line]
        (ROOT / 'results/build.json').write_text(json.dumps({
            'status': 'compiled', 'passes': 3, 'command': command[:3] + ['report.tex'],
            'warnings': warnings,
            'engine': subprocess.run(['pdflatex', '--version'], text=True, capture_output=True).stdout.splitlines()[0]
        }, indent=2) + '\n')
        print('Compiled report.pdf')
        for warning in warnings:
            print(warning)


if __name__ == '__main__':
    main()
