#!/usr/bin/env python3
"""Verify distributed payload hashes before regenerating receipts."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def main():
    manifest=json.loads((ROOT/'MANIFEST.json').read_text())
    for item in manifest['files']:
        path=ROOT/item['path']
        data=path.read_bytes()
        if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:
            raise ValueError('Payload mismatch: '+item['path'])
    print(f"Verified {len(manifest['files'])} payload files.")


if __name__=='__main__':
    main()
