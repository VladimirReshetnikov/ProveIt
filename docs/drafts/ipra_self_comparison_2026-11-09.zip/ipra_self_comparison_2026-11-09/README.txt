SELF-COMPARISON AND IMPLICIT SPECIFICATION FOR iPRA
=================================================
Research prepared for Vladimir Reshetnikov
9 November 2026 (Pacific time)

RESULT AND LIMIT
----------------
The report proves a new self-comparison presentation of full first-order
intuitionistic primitive recursive arithmetic. The presentation is
equiconsistent and bi-interpretable with iPRA, with identity numerical
domains and actual equality in both directions. The proof treats every
finite primitive-recursive description relative to the initially
unspecified comparison operation.

The mathematical change replaces the old failed reset destination
sigma(P(e(a,b))) by e(e(a,b),1). A general finite-avoidance calibration
theorem allows unbounded destinations and proves that this self-comparison
forces e to be precisely Boolean inequality. A further normal-form theorem
classifies feedback q(e(a,b)) by the positive zero set of q.

The final complete readable checker measures 3270 normalized tokens,
3489 AST nodes, and 13254 normalized bytes. Its matched predecessor
measures 3316 / 3526 / 13382. This is a strict local improvement.

IT DOES NOT BEAT THE ENTIRE CURRENT NATIVE FRONTIER. The observed native
coordinate envelope is 305 / 340 / 820, attained by different programs
with documented input-contract differences. No absolute minimum, overall
record, or historical-priority claim is made. The request for a complete
construction below that entire frontier remains unresolved.

START HERE
----------
ipra_self_comparison.pdf       Complete 20-page research report
ipra_self_comparison.tex       Standalone LaTeX source, all inputs expanded
report.tex                    Modular master source
sections/                     Modular mathematical proof and audit text
CLAIMS.json                   Machine-readable claim and limitation inventory
IMPLEMENTATION.txt            Detailed checker interface and validation notes

EXECUTABLE AND AUDIT ARTIFACTS
----------------------------
code/self_comparison_checker.py   Final standalone proof-checker program
self_fixtures/                   Accepting and rejecting certificate examples
code/check_finite_avoidance.py    Independent finite combinatorial audit
code/validate_self_comparison.py  Final public-interface validation suite
code/verify_self_change.py        Exact AST-change and representation checks
code/measure.py                  Whole-source metric reproduction
reference/                       Frozen comparison programs and normalizer
evidence/                        Executed checks, measurements, PDF build receipt
reviews/                         Independent assistant reviews and research notes
source_snapshot.json             All 20 pinned draft archives and their hashes
corpus_audit.json                 Per-archive contribution and scope assessment
SELF_SOURCE_CHANGE.patch          Exact change from matched feedback checker
MANIFEST.json                    SHA-256 and byte length of every payload file

Some intermediate checkers and receipts are retained to distinguish the
self-comparison change from the final choice sigma(x)=C(x,0,1). They are
development evidence, not extra trusted dependencies of the final checker.
Historical review notes retain the terminology and intermediate measurements
from their review stage. The final report, CLAIMS.json, and final receipts
identify the delivered construction and measurements.

REPRODUCING THE RESULTS
----------------------
Extract the ZIP and run these commands from its root directory, in order:

  python3 verify_archive.py
  python3 reproduce.py
  python3 build.py

The first verifies the distributed bytes before other commands regenerate
receipts. The second runs the finite combinatorial checks, 176 final public
interface checks, exact-source checks, and whole-source measurements. The
third rebuilds the standalone source and compiles the PDF three times with
shell escape disabled.

Python scripts use only the standard library. Exact reported metric
reproduction uses CPython 3.12.14 because AST unparsing can change between
Python versions. Compilation requires pdfLaTeX and the packages named in
report.tex. On a TeX installation whose LaTeX sources are installed but
whose pdflatex format is missing, build.py can create a temporary local
format without changing the system installation or using the network.

A direct proof-checking example is:

  python3 code/self_comparison_checker.py < self_fixtures/arbitrary_anchor_schema.json

The expected result is ACCEPT with exit status 0. Rejected certificates
produce a REJECT message on stderr and exit status 1. The checker imports
neither test producers nor another acceptance program.

To repackage an updated local copy, run:

  python3 package.py

This refreshes MANIFEST.json, writes a ZIP in the parent directory, and
checks ZIP CRCs and every payload hash. Regenerated evidence can differ
in incidental metadata; verify_archive.py intentionally verifies the
specific distributed bytes rather than promising byte-identical builds
across operating systems or TeX/Python versions.

VALIDATION SCOPE
----------------
The final checker suite exercises all 18 primitive instruction tags,
acceptance and rejection, scope and capture, ordinary PR descriptions,
the selected sign endpoints, malformed input, and both normal and -O
Python execution. The independent finite audit exhausts the sign-word
combinatorics used by the three-spike proof. These checks supplement the
written proofs; they are not a Lean/Rocq mechanization or external peer
review of the interpretation theorems.

SOURCE SNAPSHOT
---------------
All 20 top-level draft archives were pinned at ProveIt commit
718c23f33f04b6b914699a0b02face47bd211be3. Their local bytes were verified
against GitHub Git blob identities, then additionally SHA-256 hashed.

https://github.com/VladimirReshetnikov/ProveIt/tree/718c23f33f04b6b914699a0b02face47bd211be3/docs/drafts

No repository changes were made. See ATTRIBUTION.txt for the relationship
between this new contribution and the inherited reports and programs.
