# Independent audit: comparison feedback

## Verdict

The principal rule with failed destination `e(e(a,b),1)` is sound and
whole-domain bi-interpretable with full first-order iPRA, using the specified
ordinary PR descriptions relative to otherwise unspecified e, the chosen
sign sigma(x)=C(x,0,1), Boolean range for that sign, separation, and ordinary intuitionistic equality logic. This is an
independent assistant audit, not a Lean/Rocq formalization or external review.

## Generic calibration, checked independently

Write E(a,b)=sigma(e(a,b)). For any fixed numerical destination v(a,b), the
rule f(C(E(f(z),c),Sz,v(f(z),c)))=c implies f(t)=c has the following derivable
consequences under the retained boundary sentences.

First construct three disjoint isolated indicators chi_k, for k=2,3,4,
using the entire finite sign word 1^k0 along z,Pz,...,P^kz. Their ranges,
pairwise disjointness, and successor-isolation are finite consequences of
the computation equations and Boolean sign range. The complete prefix is
necessary: merely testing adjacent 10 at distinct positions is insufficient
to make the supports disjoint. No coverage or induction is used.

Two arbitrary points activate at most two of these three indicators.
Consequently one spike avoids both destinations v(a,a) and v(b,a). Under
E(a,a)=1, the corresponding two-valued spike satisfies the reset premise
and the rule forces b=a. Finite case elimination, Boolean range, and
separation therefore yield the zero diagonal E(a,a)=0.

The ordinary sign ramp C(sigma(z),a,b) then proves E(a,b)=0 implies a=b,
because both its value branches have guard zero and every successor has
value b. Equality transport gives the converse. Thus E reflects actual
equality on the full original domain.

The generic failed-destination calibration requires the exact-zero ramp
C(E(z,0),a,b), used only after this equality reflection. For d=v(a,b), split
E(d,0). The zero branch gives d=0. In the one branch the ramp has value b
at d and at every successor; the latter follows from Sz!=0, proved by
sigma computations and separation without coverage. Under E(a,b)=1, the
rule therefore forces a=b, a contradiction. Hence every failed destination
is actually zero. Using the old sign ramp here would be circular, because
sigma's reflection of zero has not yet been proved.

Zero-equation induction follows by splitting E(f(z),0): the good branch
uses the supplied induction step, and the failed branch uses the supplied
base at its now-proved zero destination. Numerical coverage and sign
reflection then follow by the established j(n)=C(sigma(n),0,S(Pn)) argument.

## Why the new destination specifies all of e

Choose v(a,b)=e(e(a,b),1). The generic failed-destination law gives

    E(a,b)=1  ->  e(e(a,b),1)=0.

Already after E's equality reflection, and even before coverage, the
following implication is available:

    e(u,v)=0  ->  E(u,v)=sigma(0)=0  ->  u=v.

Applying it to the displayed failed destination yields

    E(a,b)=1  ->  e(a,b)=1.

After coverage, E(a,b)=0 also gives e(a,b)=0 by sign reflection. Thus e
has Boolean range and is exactly the inequality characteristic. No value
of the new primitive remains unspecified, including on equal arguments.

The inner e in the feedback must be raw e(a,b), not its normalized E(a,b):
using E there would not force every raw comparison value to be Boolean.
The use of predecessor in derived spike proofs is legitimate because the
full PR-description grammar remains present. Only the trusted rule's fixed
predecessor data and helper are eliminated.

## Target interpretation and composites

Interpret e in iPRA by a fixed ordinary PR Boolean inequality characteristic
epsilon. If f(z)=c, the normalized guard is zero and the destination is Sz.
If f(z)!=c, epsilon(f(z),c)=1 and the destination is epsilon(1,1)=0.
At z=0 the premise therefore gives the ordinary equation-induction base;
under f(z)=c it gives the successor step. Contextual equation induction
validates the rule with arbitrary retained first-order formulas.

Conversely the source has recovered full quantifier-free induction by
Boolean characteristic compilation, plus successor injectivity and
separation, so its ordinary PR reduct interprets iPRA. On the source
composite, the complete comparison specification identifies e with epsilon.
External induction over each fixed finite relative description, using
internal equation induction at recursion nodes, identifies every source
operation with its returned translation at arbitrary elements. Both domain
maps are identity and both equalities remain actual equality. This is
full bi-interpretability, not only standard-model or equiconsistency evidence.

## Evidence boundary

The complete standalone checker is an exact derivative of the supplied
feedback checker. Only the failed destination and its now-unused predecessor
constant/helper change. Finite interface checks preserve all 18 rule tags
and ordinary predecessor certificates. The candidate is smaller than the
two matched readable baselines in all three reported source coordinates.
It remains larger than the compact native frontier. No global minimum,
literature-wide priority, or formal metatheory verification is claimed.

## Final selector-sign choice

The final principal checker defines sigma(x) literally as C(x,0,1), and
removes the separately fixed SIGN recursion description. Its computation
endpoints follow from C's equations without any induction. The generic
calibration proof uses only these endpoints and BR, so it applies without
change. It does not need a pre-induction identification of this chosen sign
with the old independent sign recursion symbol.

The old sign recursion remains an allowed ordinary PR description, and
its equality with the new section follows after recovered induction.
Changing the chosen sign changes the primitive BR and FR term patterns,
so the final checker is not claimed to accept exactly the old JSON inputs.
The endpoint derivations are explicit checked certificates. The final
checker has 3270 normalized tokens, 3489 AST nodes, and 13254 normalized
bytes; its complete ordinary/optimized interface validation has 176 runs.
