# Final mathematical review of assembled manuscript

Files reviewed:
- output/ipra_self_comparison_2026-11-09/report.tex
- sections/calibration.tex
- sections/classification.tex
- sections/evidence.tex
- sections/research.tex

## Verdict

The assembled main self-comparison theorem, the generic feedback calibration, the full source-relative induction claim, the ordinary-q classification, and the whole-domain bi-interpretations are mathematically sound under their displayed assumptions. I found no substantive mathematical defect requiring a change to the construction.

The final choice sigma(x)=C(x,0,1) is valid. The proofs require only its two endpoints and the explicitly retained BR schema. The displayed C=Rec(pi_0^2,pi_3^4) and P=Rec(Z_0,pi_0^2), with zero-based projections and recursion arguments (n,state,parameters), are correctly indexed. No predecessor declaration is needed in the trusted reset expression, while predecessor is legitimately available in derived proofs through the full ordinary PR grammar.

## Checks performed

1. Three-spike finite avoidance does not require numerical coverage, support-singleton claims, general excluded middle, or a choice principle.
2. Equality reflection is obtained before sign reflection. The exact-zero ramp correctly forces actual failed-destination zero and avoids the potentially circular implication sigma(d)=0 -> d=0.
3. Self-comparison forces nonzero output one before coverage; equal-case raw zero is established after zero induction calibrates the numerical retraction.
4. The q-free principal theorem has actual Boolean e, and hence fully eliminates all relative PR descriptions. Source-side operation agreement is proved through recursion nodes by derived equation induction; agreement only on standard numerals is not used.
5. The generic normal form uses expanded QF induction for all relative descriptions. The reverse implication is valid for v containing e as long as no independent fresh-index dependence is introduced.
6. R_q includes an actual root constant. Parameter lifting F^sharp(x,r) is explicit and correctly preserves recursion. At-most-one positive root gives T_q/R_q bi-interpretability; the stated standard-root existence hypothesis suffices for bare iPRA. Multiple-root cases and arbitrary alternative interpretations are carefully separated.
7. The larger labelled family v(a,b)=e(e(a,b),h(a,b)) is valid for ordinary h provably nonzero off the diagonal. Its labelled ordinary realization makes failed feedback e(h,h)=0.
8. Direct-power BR independence and the finite-order automorphism obstruction are correct for the stated ordinary first-order presentation. Contexts need not project to scalar true contexts; the universal reset premise suffices coordinatewise.
9. Main conclusions explicitly disclaim the requested global checker minimum. Local arithmetic change and whole-program measurements are distinguished from native-kernel figures.
10. A mechanical scan found no duplicate labels, no unresolved ref/eqref labels, and no unresolved citation keys in the assembled source and sections. The checked feedback, orbit-pulse, and stationarity archive titles match the bibliography.

## Proof-tightening correction recommended

The finite-avoidance lemma claims that Sep is unnecessary, but its occupancy prose says 'at each point at most one indicator is one.' Taken literally this is false in the collapsed 0=1 case, even though the desired Avoid formula is still true and its no-Sep proof is valid.

Recommended addition before the occupancy argument:

> If a Boolean branch has two indicators equal to one, disjointness yields 0=1. BR then rewrites all six indicator values to zero, so the first disjunct of Avoid holds. In every remaining branch at most one index is occupied at each point, and the following finite occupancy argument applies.

This repairs the stated stronger no-Sep dependency claim without changing any theorem. The main source includes Sep in any case.

## Completeness addition recommended

The interpretation currently invokes a fixed ordinary Boolean inequality characteristic epsilon without writing one explicit definition in this manuscript. A brief explicit target-side description makes the translation entirely concrete:

    epsilon(a,b)=sigma((a dotminus b)+(b dotminus a)),

where addition and truncated subtraction have their displayed standard PR recurrences. Ordinary target QF induction proves Boolean range and epsilon(a,b)=0 iff a=b. This is not needed to rescue the theorem—the iPRA equality-characteristic lemma is standard—but is helpful given the claim of a full written construction and the user's preference for explicitness. It must be clearly target-side reasoning, after the target's ordinary induction is available.

## Remaining qualification

This is an independent assistant mathematical review, not a Lean/Rocq formalization or external peer review. I did not independently establish universal code-checker correctness or verify the finalized metric table; those are separate executable evidence obligations handled by the implementation agent/root.

## Follow-up: explicit ordinary target comparator

Reviewed the added `sections/target_comparator.tex`. Its residual detector is correct, with no additional assumption needed.

- The equation D(n,Pu)=P(D(n,u)) follows by equation induction on n with u passive, and gives D(Sn,Su)=D(n,u).
- The diagonal r(a,a)=1 follows by equation induction on a using this cancellation.
- The residual invariant r(a,b)!=0 -> A(b,r(a,b))=Sa has exactly the displayed quantifier-free implication as its induction matrix; a remains passive. Under P(u)!=0, P0=0 gives u!=0, and target coverage gives u=S(Pu). The induction hypothesis and A(b,Su)=S(A(b,u)) then give the step.
- At r=1, the stated A identities yield A(b,1)=S(A(b,0))=Sb; successor injectivity yields b=a.
- The final zero/successor cases for r yield Boolean epsilon and epsilon=0 iff equality.

No universally quantified induction or hidden parameter-uniformity argument is used. The new concrete description resolves the earlier completeness recommendation.
