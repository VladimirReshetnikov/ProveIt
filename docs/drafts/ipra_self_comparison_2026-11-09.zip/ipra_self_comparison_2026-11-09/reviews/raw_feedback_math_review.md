# Independent mathematical review: arbitrary feedback and self-validation

Reviewer task: adversarially inspect source-internal calibration, induction, all relative descriptions, whole-domain composites, and novelty relative to the 20 pinned archives.

## Verdict

The proposed self-validating reset is mathematically valid under the stated source inventory:

- ordinary intuitionistic first-order logic with actual equality and genuine falsity;
- the full finite PR description grammar relative to one primitive binary operation e, with no equations or range axioms for e;
- the usual defining equations for every fixed description;
- Boolean range for the designated ordinary sign function sigma;
- 0=1 -> false;
- the sole additional rule

    [Gamma proves f(C(sigma(e(f(z),c)), S z, e(e(f(z),c),1))) = c]
       ----------------------------------------------------------
                       Gamma proves f(t)=c.

Here f is one fixed term template, c and t are fixed passive terms, z is fresh for the retained context and all fixed data, and substitutions avoid capture. An anchored c=f(1) variant gives the same complete theory after the supplied base and step first prove f(1)=0 in the induction derivation.

I found no circularity or missing arithmetic premise in the dependency chain below. This is an independent mathematical audit, not a Lean/Rocq formalization or a verified complete proof-checker theorem. No global smallestness or whole-corpus checker record follows from the mathematical result.

## 1. The generic finite-avoidance theorem is sound

Let E(a,b)=sigma(e(a,b)), and let v(a,b) be any fixed numerical feedback term. It may use e, but it must depend on the fresh induction index only through the displayed compared value f(z). Fixed passive parameters are harmless. Consider the same rule with failed destination v(f(z),c).

For k=2,3,4, form the Boolean indicator chi_k(z) for the finite sign word

    sigma(z), sigma(Pz), ..., sigma(P^k z) = 1,...,1,0.

This is a finite nested-selector term. The PR defining equations provide P0=0 and P(Sz)=z. Boolean range applies to every displayed sign value. Finite Boolean case analysis proves:

- each chi_k has range {0,1};
- chi_k(0)=chi_k(1)=0 and chi_k(k)=1;
- chi_k(z)=1 implies chi_k(Sz)=0;
- the three indicators have pairwise disjoint exceptional supports.

The last two assertions do not say the support is a singleton. Before coverage, it can contain nonstandard/junk inputs. The finite word and its shift are all the proof needs. Sep permits incompatible bit cases to close intuitionistically.

For any two elements d,d', one of the three indicators vanishes at both. This is a finite disjunction of three conjunctions, proved from decidability of the finitely many bits and pairwise disjointness; no numerical choice or general excluded middle is used.

Under E(a,a)=1, set d=v(a,a), d'=v(b,a), and choose a branch k where both are avoided. H_k(z)=C(chi_k(z),a,b) has H_k(d)=H_k(d')=a, H_k(k)=b, and H_k(Sz)=a on its exceptional branch. These facts prove the EXACT reset premise in each bit case. The reset conclusion gives b=a. Taking b=0,1 contradicts Sep; hence E(a,a)=0.

Freshness is preserved: d,d',a,b,k are passive data, and the finite case assumptions do not contain the fresh z used in the reset instance.

## 2. Equality reflection occurs before coverage

With E(a,b)=0 retained, the simple ramp F(z)=C(sigma(z),a,b) takes the values a or b. Its guard is zero in both cases, using the retained premise and the newly derived diagonal. The reset always evaluates at Sz, where F=b. The rule at target zero gives a=b. Conversely equality transports the diagonal. Therefore

    E(a,b)=0 iff a=b

holds over the whole source domain without numerical coverage or sign reflection.

## 3. The exact-zero ramp repairs the genuinely dangerous gap

To constrain an ARBITRARY unbounded failure destination d=v(a,b), the simple sign ramp is insufficient before sigma reflects zero. The proposed replacement is correct:

    F(z)=C(E(z,0),a,b).

Successor separation follows already from sigma(Sz)=1, sigma0=0, and Sep. Equality reflection plus BR therefore gives E(Sz,0)=1, and hence F(Sz)=b, while F0=a.

Assume E(a,b)=1. Split E(d,0). Its zero branch gives d=0 by reflection. In its one branch F(d)=b. Where F(z)=a, the failure destination is d; where F(z)=b, the diagonal selects Sz. Both branches evaluate to b. The reset rule at zero gives a=b, contradicting E(a,b)=1 and reflection. Thus d=0.

This proves

    E(a,b)=1 -> v(a,b)=0

before coverage. The proof does NOT silently infer d=0 from sigma(d)=0. That is the most important dependency check in this construction.

## 4. Self-validation forces the nonzero output immediately

Take v(a,b)=e(e(a,b),1). The generic failure theorem gives

    E(a,b)=1 -> e(e(a,b),1)=0.

Apply sigma to the equality and use sigma0=0. This yields E(e(a,b),1)=0, and the already proved reflection yields e(a,b)=1.

This inference itself does not even need coverage or raw-zero reflection: raw equality to zero always implies equality of its sign to zero. The equal-input raw output still requires the subsequent sign calibration, as expected.

## 5. Induction and coverage are obtained in a noncircular order

The generic calibration supplies both E-reflection and failed destination zero. A supplied zero-equation induction base f0=0 and step fz=0 -> f(Sz)=0 now prove the reset premise with c=0, by splitting E(fz,0). Hence contextual zero-equation induction follows for EVERY fixed e-relative term, with arbitrary retained first-order assumptions.

Define j(n)=C(sigma(n),0,S(Pn)) and r(n)=E(j(n),n). Computation gives j0=0 and j(Sn)=Sn, so the diagonal gives r0=0 and r(Sn)=0 without an induction hypothesis. Zero-equation induction yields r(n)=0, and E-reflection yields j(n)=n. Now BR yields coverage and sigma(n)=0 iff n=0.

In the E(a,b)=0 branch, sign reflection makes e(a,b)=0. In the E(a,b)=1 branch, self-validation already gave e(a,b)=1. Thus e has its full Boolean inequality specification. Boolean characteristics of all fixed quantifier-free formulas, including implication and all e-relative function terms, yield full contextual QF induction. This uses only decidability of those fixed QF formulas, not excluded middle for arbitrary quantified formulas.

## 6. Target soundness and every composite check

Interpret e by a fixed ordinary PR Boolean inequality characteristic epsilon, retaining the whole numerical domain and actual equality. The reset destination is

    C(epsilon(fz,c), Sz, epsilon(epsilon(fz,c),1)).

On the unequal branch the inner epsilon is 1 and its self-test is epsilon(1,1)=0. On the equal branch the guard is zero, so the self-test epsilon(0,1)=1 is ignored. Thus the ordinary reset proof by equation induction validates every source rule instance under the same retained context.

The source recovers ordinary iPRA in its literal ordinary PR reduct. The target round trip is the identity. For the source round trip, the derived e specification and the recovered ordinary iPRA correctness of epsilon prove e(a,b)=epsilon(a,b) throughout the whole domain. External induction on each finite description proves all remaining operation identities:

- initial constructors are immediate;
- composition uses congruence and preceding identities;
- each recursion description uses derived equation induction to compare the two recursors with their equal bases and equal update descriptions.

This induction is legitimate in the e-relative language, which has already received full QF induction. It must not be replaced by agreement only on standard numerals. Structural formula induction then gives the full logical composite. Both domain isomorphisms have graph x=y, and genuine falsity is preserved. Thus full bi-interpretability and equiconsistency follow.

## 7. The ordinary-q classification is also correct, with its caveats

For fixed ORDINARY PR q and feedback v(a,b)=q(e(a,b)), the same source proof derives exactly the expanded iPRA^e specification

    e(a,b)=0 iff a=b,
    a!=b -> q(e(a,b))=0,

together with all e-relative defining equations and QF induction. Conversely those principles validate the q-reset by ordinary equation induction. This is deductive equivalence in the shared expanded language.

Let A_q be iPRA with a constant r and axioms sigma(r)=1 and q(r)=0. Then mutual interpretations are:

- T_q into A_q: e(a,b)=C(epsilon(a,b),0,r);
- A_q into T_q: r=e(0,1), with ordinary functions unchanged.

Every relative description translates to an ordinary PR description with r passed as an extra passive parameter. No universal evaluator or unstated function oracle is used. A_q is equiconsistent with iPRA plus existence of such an r, by the ordinary witness-constant extension argument.

If iPRA proves AT MOST ONE positive zero of q, these interpretations are bi-interpretations between T_q and A_q. For bi-interpretability with bare iPRA one additionally needs provable existence (a fixed positive numeral root suffices). For q=P the unique positive root is 1. No condition on q(0) is needed because the failed destination is ignored on the zero-guard branch. For example q(x)=C(x,1,Px) also has the right unique positive zero despite q(0)=1.

For q=id the theory is inconsistent. For q constantly zero, off-diagonal e values can be arbitrary positive values; the displayed natural composite does not eliminate that freedom. Do not infer a general non-bi-interpretability theorem for every possible alternative interpretation from failure of this particular composite.

A q with no standard positive zero can still have a positive zero in a nonstandard iPRA model if the absence statement is not provable. Therefore consistency cannot be assessed solely by standard numerical sampling. The q-root condition is a genuine arithmetic existence condition.

The self-validation main result is not an instance of the ordinary-q classification without qualification: its effective validator depends on the unknown e. It is justified directly by the more general arbitrary-feedback theorem above.

## 8. Conservative novelty statement

The pinned 20-archive corpus already contains: arbitrary passive targets; single-spike diagonal calibration for bounded reset destinations; primitive unspecified e; self-calibration of e by the bounded destination sigma(P(e)); all ordinary logical infrastructure; and the method for eliminating the e-relative language after its specification is proved. These should be attributed.

The new steps relative to that corpus are:

1. three disjoint isolated spikes and finite avoidance remove EVERY prior bound on the failed destination;
2. the exact-zero ramp, available after guard reflection but before coverage, forces the arbitrary failed destination to zero;
3. the unknown comparator can validate its own output via e(e(a,b),1), removing predecessor and the separate numerical validator from the trusted reset expression;
4. the ordinary-q classification identifies the precise positive-zero-fibre condition controlling implicit specification and consistency.

I searched the non-reference main TeX sources of all 20 archives for finite-avoidance, three-spike, unbounded-feedback/destination, positive-root, and nested e(e(...)) formulations; none occurred. The feedback report's Further research question 3 explicitly asks for a general implicit-specification theorem distinguishing unique definability from remaining label freedom. The q classification answers a precise broad subcase of that question.

Recommended claim: "A new corpus-relative arbitrary-feedback calibration theorem and a self-validating comparison rule, with full whole-domain bi-interpretability with iPRA." Avoid historical priority, absolute minimality, or a completed global below-frontier claim unless independent whole-checker evidence establishes the latter.

The proof still uses ordinary predecessor descriptions to construct its derived spikes. What disappears is predecessor from the trusted reset pattern and associated checker helper, not from every derived mathematical proof or from the full PR language.
