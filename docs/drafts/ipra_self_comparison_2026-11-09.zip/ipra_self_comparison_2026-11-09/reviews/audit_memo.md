# Audit of complementary current iPRA drafts

Snapshot: `718c23f33f04b6b914699a0b02face47bd211be3`. Input archives in this workspace were independently matched to repository Git blob identities by the parent agent.

## Findings

I read the main contributions/proof interfaces of the nine assigned archives. No obvious invalid step was found in the central positive proofs reviewed. This is a mathematical audit, not a formal verification. The archives themselves generally distinguish their local improvements from the still-unmet complete-checker objective.

| Proposal | Genuine result | Important limitations/dependencies |
| --- | --- | --- |
| `boolean_bootstrap` | Removes the extra clock diagonal from the earlier closed-iterator reset by proving Boolean-valued induction first, then clock calibration, then actual equality reflection. | Retains ordinary intuitionistic logic, Boolean range BR, Sep, staged closed iteration, and the raw reset. Does not beat the complete checker. Later pulse calibration subsumes its comparator requirements. |
| `clock_and_kernel` | Whole-domain predecessor term using the existing factor conversion clock, reducing the derived predecessor description from 130 to 93 body nodes and 22 to 16 declarations. | No trusted rule deletion. Separate 306-token/340-AST/859-byte checker changes malformed input aliases and relies on CPython recursion guards. Strict variant 308/341/894 is not an all-coordinate improvement. |
| `one_fixed_recurrence` | A single specified signed update B and its uniqueness rule derive the formerly additional half/double retraction, arbitrary-value stationarity, parity decomposition, and all iPRA. | Full PR description grammar, ordinary logic, coverage, separation remain. Source proof of two-sided inverses is explicit and avoids prematurely cancelling nonstandard iterates. |
| `progress_closure` | A one-assumption paired introduction is made complete by additional local progression eliminations; full formula normalization and bi-interpretation are addressed. | Six native rule patterns replace an earlier four. Readable checker is much larger. Removing the last atomic hypothesis is NOT proved impossible; proposed transfer needs substitution coherence. |
| `pulse_calibration` | Any Boolean-range closed-iterator raw comparator placed in the anchored-reset rule self-calibrates its diagonal, separating endpoint, clock, and actual equality reflection. A transient single-trajectory pulse replaces two opposing comparison trajectories. | Needs source-internal spike interface, BR, Sep, staged terms and ordinary logic. Complete-checker comparisons do not establish a global frontier improvement. |
| `recurrence_boundary` | Linear-fibre model validates broad classes of fixed-recursion uniqueness yet fails literal-equation induction. Standardly identical update descriptions can have different foundational strengths. Also proves exact fixed-retraction versus stationarity trade. | Obstruction uses ordinary definable first-order bi-interpretation. Does not settle successor uniqueness SU0 or bouncing predecessor W. |
| `two_diagonal` | Closed-iteration reset derives its own clock and equality reflection via ordinary and clock diagonal masks. | Superseded locally by Boolean-bootstrap and pulse calibration. Source calibration is separate from target correctness and compiler correctness. |
| `unbounded_depth` | Explicit formulas with classically constant truth set need arbitrarily large native binder depth under HA/iPRA provable equivalence. Negative-only decoded grammars cannot recover full intuitionistic formulas. | Fixed grammar/decoding and PR numerical terms; does not bound checker source length, other connectives, or changed-domain interpretations. No new smaller theory. |
| `package_reconstructed` | Anchored reset is deductively equivalent to full iPRA in shared full-PR language, with identity-domain interpretations. | Inherited baseline, later raw/closed comparator improvements supersede parts. Ordinary logical rules count. |

## Strongest relevant bootstrap

Pulse calibration is the best general theorem among these sources. Over closed initialized iteration

`I_h(0,a)=a`, `I_h(Sn,a)=h(I_h(n,a))`,

Boolean range for Z and ordinary equality logic, let e(a,b) be any fixed source term with provable Boolean range, and add the anchored reset

`[for every fresh z, f(M(e(f(z),f(1)),Sz))=f(1)] => f(t)=f(1)`.

One does NOT need e(a,a)=0 or e(1,0)=1 as axioms/computational side conditions. A spike q with q(0)=q(1)=0, q(2)=1 and q(z)=1 => q(Sz)=0, combined with a ramp whose exceptional value is c(b)=I_S(b,0), first shows e(a,a)=1 => c(b)=a. Using b=0,1 proves e(a,a)=0 by equality transport, without explosion. Restricted reflection e(c(a),b)=0 => c(a)=b then yields e(1,0)=1. Boolean-valued induction calibrates e(c(n),n), proving c(n)=n and full reflection. Sep is not used until genuine falsity/separation is needed.

Exact files: `ipra_pulse_calibration_2026-11-09/.../sections/03_calibration.tex` and `04_equivalence.tex`.

## The whole-theory obligations are real

The strongest source proofs keep arbitrary quantified retained contexts throughout induction/rule translations. They retain the entire domain and actual equality, and establish every composite rather than just standard numerical equivalence. Equational or numerical sampling alone does not establish these claims.

The closed-iterator compiler must preserve passive parameters by packing them into explicit states. Its fixed index h may have only its state variable free; no universal PR evaluator or capture of ambient parameters is legitimate. In the native logical calculus the induction hypothesis is available only when the matrix is literally atomic. Giving it to arbitrary nested native formulas yields stronger induction.

## Countermodels and already-explored failures

1. **BR independence.** In the direct product N^2 with coordinatewise terms, CI, Sep and all raw anchored-reset instances hold. At (0,1), Z takes value (1,0), neither the zero vector nor the one vector. Thus BR cannot merely be dropped. This is proved in pulse calibration `sections/07_boundaries.tex`.
2. **Sep independence.** The collapsed one-element model satisfies all equations and reset principles. Ordinary genuine falsity needs its separation bridge. A native designated-absurdity convention is a different logical interface and must be stated explicitly.
3. **Even very strong zero-test induction can miss actual equality.** The linear-fibre cover in recurrence boundary has singleton fibres over standard numerals, nontrivial vector fibres over nonstandard elements, all PR defining equations, coverage, cancellative semiring operations without zero divisors, designated successor-clock and identity-iterator repairs, and induction for ALL formulas whose atoms are t=0. A syntactically distinct identity recursion Q(n) still erases fibres; Q(n)=n has its base and step yet fails.
4. **Bounded state observations cannot repair that cover.** If a fixed finite number of update steps factors, provably in PR equations, through a uniformly bounded state observation, the cover validates the corresponding full uniqueness rule. All such rules can hold simultaneously. Unbounded numerical output is insufficient if dependence on the old state still passes only through bounded observations.
5. **Standard dynamics are insufficient evidence.** Every state-masked update h(n,Q(u),p) has the same standard numerical function as h, and every corresponding uniqueness rule is valid in the bad cover. In particular B and B composed with Q have the same ordinary function but different foundational strength before source-internal calibration.
6. **Bouncing predecessor remains open.** W(0)=1, W(Sn)=n gives I_W(n,S^m n)=m for each fixed EXTERNAL natural m. This does not justify the variable-seed retraction I_W(n,I_S(n,a))=a. The tempting test I_W(a,b)=0 and I_W(a,Sb)=1 is false at a=b+2.
7. **Constant-value induction remains open.** CVI gives arbitrary-value stationarity and all fibre induction f(n)=a, but no existing proof reduces general equalizers s(n)=t(n) to fibres without faithful difference/comparison. Comparison-shift/absorption identities are the bottleneck; treating them as defining equations is circular.
8. **Negative-only logic is insufficient.** Decidable equality closed under implication and universal quantification yields only stable formulas. Full formula round trips would imply stability of halting excluded-middle instances and contradict realizability. Existential/nonstable logical force must occur somewhere.

## A general product obstruction

The following clean abstraction of the boundary proofs may be useful in the report; its proof is elementary and should not be marketed as a new positive axiomatization.

**Theorem.** Let T be an ordinary first-order theory with a model A having at least two elements. Suppose all nonempty direct powers A^I are models of T. Then T cannot be definably bi-interpretable with iPRA, even when at most countably many parameters are allowed across the interpretation data.

**Proof.** Choose |I| > |A|^(aleph_0). Any countable family of parameters in A^I gives at most |A|^(aleph_0) coordinate profiles. Two coordinates have identical profiles. Their transposition is a nonidentity involution of A^I fixing every selected parameter. Every classical iPRA model has a definable linear order, so any finite-order automorphism is identity. A bi-interpretation transports the involution to such an automorphism and then to identity on the double interpretation. The definable injective round-trip map forces the source involution to be identity, contradiction. For quotient interpretations include representatives of interpretation parameters in the fixed family.

This applies immediately to universal Horn model classes and to many purely equational recurrence-closure systems whose power preservation can be checked directly. It does not apply to native logics with nonstandard designated falsity/decoding unless their relevant model category also has the stated closure.

## Avenues worth pursuing

- Collapse arithmetic and logical checking together. Local predecessor/comparator reductions cannot beat a native kernel that does not evaluate those derived helpers.
- Preserve the pulse calibration theorem while reducing the actual fixed comparator; only target soundness, source Boolean range and well-stagedness now constrain it. This avenue is assigned to the arithmetic agent.
- Resolve the constant-value induction equalizer-versus-fibre gap. A changed domain with a faithful algebraic difference could make the reduction immediate, but the cost of that algebraic structure and the natural-number round trip must be charged.
- Try a rule that explicitly supplies the non-product-preserving case distinction required by the obstruction while eliminating another native logical branch. Merely changing a recurrence to a tiny finite-state update is excluded by the cover theorem.

No verified overall smaller axiomatization was obtained in this audit.
