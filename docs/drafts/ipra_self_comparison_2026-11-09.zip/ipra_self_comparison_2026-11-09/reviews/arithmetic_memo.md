# Arithmetic memo: unbounded feedback by finite avoidance

Source comparison: verified archives from ProveIt commit `718c23f33f04b6b914699a0b02face47bd211be3`, principally `ipra_feedback_2026-11-09.zip` and `ipra_raw_reset_2026-11-09.zip`.

## Status

The following is a proved mathematical simplification of the feedback proposal. It removes the outer sign operation from the failed-reset destination, without adding an axiom, an inference schema, or a defining equation. It does **not** establish a complete checker below all current native kernels, and it is too small a reduction to call a major global breakthrough. Its underlying finite-avoidance calibration theorem is substantially more general than the one-spike bounded-feedback proof.

The original feedback rule is

\[
 \frac{\Gamma\vdash f(C(\sigma(e(f(z),c)),Sz,\sigma(P(e(f(z),c)))))=c}
 {\Gamma\vdash f(t)=c}.
\]

Replace it by

\[
 \boxed{\frac{\Gamma\vdash f(C(\sigma(e(f(z),c)),Sz,P(e(f(z),c))))=c}
 {\Gamma\vdash f(t)=c}.}
 \tag{UF}
\]

Use precisely the full primitive-recursive description grammar relative to an otherwise unspecified binary operation `e`, their defining equations, ordinary intuitionistic first-order equality logic, and the same two boundary axioms

\[
 \forall x\,[\sigma(x)=0\vee\sigma(x)=1],\qquad 0=1\to\bot.
 \tag{BR,Sep}
\]

Here `P`, `C`, and `sigma` are finite ordinary descriptions with equations

\[
 P0=0,\quad P(Sx)=x;\qquad C(0,a,b)=a,\quad C(Sx,a,b)=b;
 \qquad\sigma0=0,\quad\sigma(Sx)=1.
\]

If desired define sigma literally by `C(x,0,1)`. No coverage, comparison equation, range of e, induction, or uniqueness schema is otherwise assumed. `f` and `c` are fixed term data, and `z` is fresh for the retained context, target, and all passive parameters. The anchored form `c=f(1)` also works.

## 1. Three disjoint isolated spikes, before coverage

Write `s_i(z)=sigma(P^i z)`. For each fixed positive integer k define a Boolean term by

\[
 \chi_k(z)=C(s_0(z),0,C(s_1(z),0,\ldots C(s_{k-1}(z),0,C(s_k(z),1,0))\ldots)).
\]

Thus `chi_k=1` exactly when the finite sign word is `1^k 0`; all other Boolean sign words give zero. This description is finite for each of `k=2,3,4` and is used only in derived proofs.

The computation equations and BR prove:

1. Each chi is zero or one.
2. `chi_k(0)=chi_k(1)=0` and `chi_k(k)=1` for k in {2,3,4}.
3. `chi_k(z)=1` implies `chi_k(Sz)=0`.
4. For distinct k,l in {2,3,4}, `chi_k(z)=1` implies `chi_l(z)=0`.

For (3), the sign word of `Sz` is `1,s_0(z),s_1(z),...`; its kth position is `s_{k-1}(z)=1`, whereas chi_k would require zero there. For (4), the first zero occurs at different positions. Every argument is finite Boolean case analysis, not numerical induction or a claim that the support consists only of its standard numeral. Sep permits the usual incompatible-case contradiction; alternatively the required numerical identities survive the collapsed case by `0=1` rewriting.

**Finite avoidance lemma.** For arbitrary d,d', at least one k in {2,3,4} satisfies `chi_k(d)=chi_k(d')=0`.

Proof: each of the two points activates at most one of the three pairwise disjoint Boolean indicators. Explicitly split the finitely many Boolean values, or prove the corresponding three-disjunct propositional tautology. No quantification over k or choice principle occurs.

For fixed a,b let

\[
 H_k(z)=C(\chi_k(z),a,b).
\]

Then H_k(0)=H_k(1)=a, H_k(k)=b, and its exceptional branch has H_k(Sz)=a.

## 2. Diagonal calibration with arbitrary destinations

Let `E(a,b)=sigma(e(a,b))`. Retain `E(a,a)=1`. Fix arbitrary b, and put

\[
 d=P(e(a,a)),\qquad d'=P(e(b,a)).
\]

By finite avoidance choose one of the three k with H_k(d)=H_k(d')=a. This means a finite disjunction elimination, not an additional rule.

Apply UF to H_k with target k and anchor c=a. For a fresh z split chi_k(z):

- If zero, H_k(z)=a, so its failed diagonal sends it to d and H_k(d)=a.
- If one, H_k(z)=b and H_k(Sz)=a. Split the Boolean E(b,a). At zero the destination is Sz; at one it is d'. Both give a.

Thus the exact UF premise is established, so b=H_k(k)=a. We have proved `E(a,a)=1 -> b=a` for arbitrary b. BR, Sep, and the choices b=0,1 give `E(a,a)=0`. One can retain the original numerical-collapse proof instead: put d=E(a,a), and under its one branch use b=0 and b=d to get 0=a=d.

**General form.** The diagonal argument works with any fixed numerical feedback term v(a,b), with no range axiom at all, in

\[
 f(C(E(f(z),c),Sz,v(f(z),c)))=c\quad\Rightarrow\quad f(t)=c.
\]

There are only two possible feedback values when f is a two-valued spike. Three disjoint isolated spikes avoid both. More generally, finitely many feedback values can be avoided with one more pairwise disjoint isolated spike than there are values. The old bounded-destination hypothesis was a convenience of using one predetermined spike, not a requirement of the calibration mechanism.

## 3. Equality reflection

Retain E(a,b)=0 and take `F(z)=C(sigma(z),a,b)`, c=b, target zero. BR gives F(z)=a or b. In the first case its guard is the retained zero; in the second it is the calibrated zero diagonal. Therefore the destination is Sz and F(Sz)=b in both cases. UF gives a=F(0)=b. Conversely a=b implies E(a,b)=E(a,a)=0. Hence

\[
 E(a,b)=0\quad\longleftrightarrow\quad a=b.
 \tag{Eq}
\]

This is actual equality throughout the original domain, before numerical coverage or any induction.

## 4. Arbitrary failed destinations are forced to zero

This step requires a different ramp from the original feedback proof. After Eq, use the **exact-zero ramp**

\[
 F(z)=C(E(z,0),a,b).
\]

Sep and sigma's computation equations prove `Sz != 0` without coverage. Eq and BR then give E(Sz,0)=1, so F(Sz)=b. Also F(0)=a, and BR gives F(z) in {a,b}.

Retain E(a,b)=1 and write d=P(e(a,b)). Split E(d,0). If zero, Eq gives d=0. If one, F(d)=b. At any z where F(z)=a, the failed destination is d, with value b. At any z where F(z)=b, the calibrated zero diagonal makes the destination Sz, again with value b. Thus UF gives a=b, contrary to E(a,b)=1 and Eq. Ex falso gives d=0. Consequently

\[
 E(a,b)=1\quad\longrightarrow\quad P(e(a,b))=0.
 \tag{Fail}
\]

This avoids the gap that would result from proving only sigma(Pe)=0 and silently assuming that sign already reflects zero.

In the general feedback theorem above, the identical proof yields `E(a,b)=1 -> v(a,b)=0`. Thus arbitrary feedback is internally specified on precisely the branch where the rule consults it.

## 5. Induction, coverage, complete specification, and both composites

Suppose Gamma proves f(0)=0 and, under f(z)=0, proves f(Sz)=0. In UF with c=0 split E(f(z),0): zero gives f(z)=0 by Eq and hence the progress value; one gives failed destination zero by Fail and hence the base value. Thus contextual zero-equation induction follows.

Define `j(n)=C(sigma(n),0,S(Pn))` and `r(n)=E(j(n),n)`. Computation and the zero diagonal give r(0)=0 and r(Sn)=0. Zero-equation induction yields r(n)=0, and Eq yields j(n)=n. BR now proves numerical coverage n=0 or n=S(Pn), and also sigma(n)=0 iff n=0.

Let d=e(a,b). If E(a,b)=0, sign reflection gives d=0. If E(a,b)=1, Fail gives Pd=0, while coverage of d and Sep imply d=S(Pd)=1. Thus e itself is Boolean and is the actual inequality characteristic. There are no remaining unspecified e values.

Compile each fixed quantifier-free formula into its standard Boolean characteristic using E, C, and Sep; zero-equation induction gives full contextual quantifier-free induction, including arbitrary retained first-order contexts. All original e-relative finite descriptions are covered.

Conversely interpret e in iPRA by an ordinary Boolean inequality characteristic. At unequal arguments its predecessor is zero, and at equal arguments its sign is zero. UF becomes the usual reset encoding of equation induction, so is valid in iPRA.

On the source round trip, the derived Boolean specification gives equality of e with its ordinary PR realization. Induction on each finite description tree, using the now-derived equation induction at recursion nodes, identifies every relative description with its translated ordinary version. Both interpreted domains are the whole numerical domain, both equalities are actual equality, both logical translations are identity, and both composite isomorphisms have graph x=y. This proves full bi-interpretability and equiconsistency, not merely standard-model agreement.

## 6. What cannot be deleted by this method

The BR boundary cannot simply be dropped from the purely equational/reset presentation. The direct product of two copies of N, with all numerical operations and e interpreted coordinatewise, satisfies the defining equations, Sep, and every contextual UF instance by coordinatewise ordinary induction. But at x=(0,1), sigma(x)=(0,1), which is neither the all-zero nor the all-one element; BR fails. A disjunctive or equivalent non-Horn calibration mechanism is needed to exclude these models. This product obstruction is already present in the pulse-calibration draft; applying it to UF adds no claim of novelty.

Removing the guard normalization sigma as well is not justified. On points outside the successor image, computation equations do not ensure C(x,a,b) depends only on sigma(x), so C(e,Sz,Pe) need not make a binary choice. The finite-avoidance proof handles arbitrary *failed destinations*, not an arbitrary uninterpreted selector guard.

## 7. Assessment of other assigned sources

- Raw reset already removed the diagonal mask, with a generic Boolean-comparator calibration proof. Repeating that deletion is not new.
- Feedback already removed all equations and range axioms for the new primitive e. Its original failure destination sigma(Pe) is bounded by BR, enabling one fixed spike. UF above is a strictly shorter trusted pattern via a new finite-avoidance proof.
- Orbit pulse reduced a particular closed-iterator comparator to 52 expanded numerical tree nodes and calibrated it with the inherited generic reset theorem. It does not attain the complete native checker minima.
- Rotation replaces arbitrary signed-update uniqueness with one fixed rotation equation while retaining zero-initialized successor uniqueness. It correctly separates zero-equation induction from actual equality reflection; deleting Rot remains unproved there.
- Recurrence projections and stationarity envelope derive a directed congruence quotient from W-uniqueness, with singleton standard-numeral fibres. They explicitly leave quotient preservation of the uniqueness schema and equality reflection unresolved. There is no hidden existing proof of one-recurrence completeness in those reports.

No absolute minimality or global below-frontier claim follows from this memo.
