#!/usr/bin/env python3
"""Create the standalone TeX and compile it with shell escape disabled."""
import json
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
NAME='ipra_self_comparison'


def prepare_tex_environment(env, build):
    """Local-only missing-format fallback, adapted from the supplied forward-left build script."""
    lookup=subprocess.run(['kpsewhich','pdflatex.fmt'],capture_output=True,text=True)
    if lookup.stdout.strip():
        return False
    lookup=subprocess.run(['kpsewhich','-var-value=TEXMFDIST'],capture_output=True,text=True,check=True)
    dist=Path(lookup.stdout.strip())
    if not (dist/'tex/latex/base/latex.ltx').is_file():
        raise RuntimeError('Install a TeX distribution with the LaTeX sources and report packages.')
    roots=[p for p in (Path('/etc/texmf'),Path('/usr/share/texmf'),dist) if p.is_dir()]
    env['TEXMF']='{'+','.join(['.']+[str(p) for p in roots])+'}'
    result=subprocess.run(['pdftex','-ini','-etex','-jobname=pdflatex','-progname=pdflatex',
                           '-interaction=nonstopmode','-halt-on-error','pdflatex.ini'],
                          cwd=build,env=env,capture_output=True,text=True,timeout=120)
    if result.returncode:
        raise RuntimeError(result.stdout+result.stderr)
    maps=[]
    for root in roots:
        lm=root/'fonts/map/dvips/lm/lm.map'
        if lm.is_file():maps.append(lm)
        maps.extend(sorted((root/'fonts/map/dvips/amsfonts').glob('*.map')))
    (build/'pdftex.map').write_text('\n'.join(p.read_text() for p in maps))
    env['TEXFORMATS']=str(build)+':'
    env['TEXFONTMAPS']=':'.join([str(build)+'//']+[str(p/'fonts/map')+'//' for p in roots])+':'
    return True


def expand(path):
    text=path.read_text()
    return re.sub(r'\\input\{([^}]+)\}',lambda m:expand(ROOT/m.group(1)),text)


def main():
    tex=ROOT/(NAME+'.tex')
    tex.write_text(expand(ROOT/'report.tex'))
    env=os.environ.copy()
    env['SOURCE_DATE_EPOCH']='1794265200'
    env['FORCE_SOURCE_DATE']='1'
    with tempfile.TemporaryDirectory(prefix='ipra-self-build-') as temporary:
        build=Path(temporary)
        (build/tex.name).write_bytes(tex.read_bytes())
        fallback=prepare_tex_environment(env,build)
        runs=[]
        for _ in range(3):
            result=subprocess.run(['pdflatex','-no-shell-escape','-interaction=nonstopmode',
                                   '-halt-on-error',tex.name],cwd=build,env=env,
                                  capture_output=True,text=True,timeout=120)
            runs.append({'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
            if result.returncode:
                (ROOT/'evidence/pdf_build_failure.json').write_text(json.dumps(runs,indent=2)+'\n')
                print(result.stdout)
                raise SystemExit(result.returncode)
        log=(build/(NAME+'.log')).read_text(errors='replace')
        shutil.copyfile(build/(NAME+'.pdf'),ROOT/(NAME+'.pdf'))
        warnings=[line for line in log.splitlines() if any(word in line for word in
                    ('Warning:','Overfull','Underfull','undefined'))]
        (ROOT/'evidence/pdf_build.json').write_text(json.dumps({'runs':len(runs),
            'all_exit_zero':True,'temporary_format_fallback':fallback,
            'warnings':warnings,'log':log},indent=2)+'\n')
        print(json.dumps({'pdf':NAME+'.pdf','warnings':warnings},indent=2))


if __name__=='__main__':
    main()
