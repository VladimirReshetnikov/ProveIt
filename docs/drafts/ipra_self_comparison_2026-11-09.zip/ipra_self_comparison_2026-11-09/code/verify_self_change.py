"""Exact final source changes and selector-sign interface checks.

The sign section C(x,0,1) changes the primitive BR representation. No
all-input equivalence with the previous sign-description interface is claimed.
"""

import ast
import difflib
import hashlib
import json
import subprocess
import sys
from pathlib import Path

import upstream_fixtures as u
import validate_self_comparison as v

ROOT = Path(__file__).resolve().parent


def without_module_docstring(source):
    tree = ast.parse(source)
    if tree.body and isinstance(tree.body[0], ast.Expr):
        if isinstance(tree.body[0].value, ast.Constant) and isinstance(tree.body[0].value.value, str):
            tree.body.pop(0)
    return ast.dump(tree, include_attributes=False)


def main():
    baseline = ROOT / "baseline_feedback.py"
    candidate = ROOT / "self_comparison_checker.py"
    previous = ROOT / "comparison_feedback_checker.py"
    original = baseline.read_text()
    if hashlib.sha256(baseline.read_bytes()).hexdigest() != "9ffe0e1034651fbedd47883587db94b5d51b5d1e10c644830244db36f60b46fa":
        raise ValueError("Changed baseline source")
    changes = [
        ("return choose(sign(comparison), successor(index), sign(predecessor(comparison)))",
         "return choose(sign(comparison), successor(index), app(COMPARISON, comparison, successor(zero())))"),
        ('PREDECESSOR = ["rec", ["zero", 0], ["proj", 2, 0]]\n', ''),
        ('def predecessor(t):\n    return app(PREDECESSOR, t)\n\n\n', ''),
        ('SIGN = ["rec", ["zero", 0], ["comp", 2, ["succ"], [["zero", 2]]]]\n', ''),
        ('def sign(t):\n    return app(SIGN, t)',
         'def sign(t):\n    return choose(t, zero(), successor(zero()))')
    ]
    expected = original
    for before, after in changes:
        if expected.count(before) != 1:
            raise ValueError("Expected one occurrence of each listed source change")
        expected = expected.replace(before, after)
    if without_module_docstring(expected) != without_module_docstring(candidate.read_text()):
        raise ValueError("Unexpected executable change")
    (ROOT.parent / "SELF_SOURCE_CHANGE.patch").write_text(''.join(difflib.unified_diff(
        original.splitlines(keepends=True), candidate.read_text().splitlines(keepends=True),
        fromfile="baseline_feedback.py", tofile="self_comparison_checker.py")))

    current_schema = v.feedback_schema(u.v("z"), u.v("t"), u.v("c"), ["c", "t"])
    original_reset = v.reset

    def previous_reset(value, anchor, index, old=False):
        test = v.comparison(value, anchor)
        return u.select(u.call(u.SG, test), u.s(index), v.comparison(test, u.ONE))

    v.reset = previous_reset
    try:
        previous_schema = v.feedback_schema(u.v("z"), u.v("t"), u.v("c"), ["c", "t"])
    finally:
        v.reset = original_reset

    receipts = []
    for label, packet in (("selector_sign", current_schema), ("separate_sign", previous_schema)):
        for checker in (candidate, previous):
            expected_accept = (label == "selector_sign") == (checker == candidate)
            for flags in ([], ["-O"]):
                run = subprocess.run([sys.executable, *flags, str(checker)],
                                     input=json.dumps(packet), text=True,
                                     capture_output=True, timeout=15)
                accepted = run.returncode == 0 and run.stdout == "ACCEPT\n" and not run.stderr
                rejected = run.returncode == 1 and not run.stdout and run.stderr.startswith("REJECT:")
                passed = accepted if expected_accept else rejected
                if not passed:
                    raise ValueError("Selector sign interface distinction failed")
                receipts.append({"schema": label, "checker": checker.name,
                                 "optimized": bool(flags), "expected_accept": expected_accept,
                                 "passed": passed})

    result = {"exact_executable_delta_verified": True,
              "representation_change": "sigma(x) is literally C(x,0,1); no all-input equivalence claim.",
              "baseline": u.measure(baseline), "candidate": u.measure(candidate),
              "separate_sign_comparison": u.measure(previous),
              "raw_predecessor": u.measure(ROOT / "raw_predecessor_feedback.py"),
              "earlier_raw_reset": u.measure(ROOT / "baseline_raw_reset.py"),
              "interface_runs": receipts,
              "scope": "Finite exact-delta and interface checks; written metatheory required."}
    fields = ("normalized_tokens", "ast_nodes", "normalized_bytes")
    result["matched_savings"] = {k: result["baseline"][k] - result["candidate"][k] for k in fields}
    result["earlier_reset_savings"] = {k: result["earlier_raw_reset"][k] - result["candidate"][k] for k in fields}
    (ROOT.parent / "self_exact_change.json").write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({"exact_executable_delta_verified": True,
                      "interface_runs": len(receipts),
                      "matched_savings": result["matched_savings"],
                      "earlier_reset_savings": result["earlier_reset_savings"]}, indent=2))


if __name__ == "__main__":
    main()
