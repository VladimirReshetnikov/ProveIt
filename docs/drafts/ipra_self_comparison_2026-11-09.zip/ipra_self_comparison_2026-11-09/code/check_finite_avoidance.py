#!/usr/bin/env python3
"""Exhaustive finite checks for the unbounded-feedback calibration lemma.

These checks concern the finite Boolean combinatorics before coverage.
They are not a formalization of the first-order equivalence theorem.
No samples of natural-number arithmetic are substituted for its proof.
"""

from itertools import product
import json
from pathlib import Path


INDICES = (2, 3, 4)
WORDS = tuple(product((0, 1), repeat=5))


def spike(word, index):
    """Independent truth-table definition: initial word must be 1^k 0."""
    return int(all(word[j] == 1 for j in range(index)) and word[index] == 0)


def selector(flag, zero_value, one_value):
    return zero_value if flag == 0 else one_value


def expanded_spike(word, index):
    """Evaluate the displayed nested C syntax separately from its truth table."""
    value = selector(word[index], 1, 0)
    for j in reversed(range(index)):
        value = selector(word[j], 0, value)
    return value


def standard_sign_word(number):
    return tuple(int(max(number - j, 0) != 0) for j in range(5))


counts = {}
for word in WORDS:
    active = tuple(k for k in INDICES if spike(word, k))
    assert len(active) <= 1
    shifted = (1,) + word[:-1]
    for k in INDICES:
        assert expanded_spike(word, k) == spike(word, k)
        if spike(word, k):
            assert spike(shifted, k) == 0
counts['boolean_words_checked'] = len(WORDS)
counts['nested_selector_checks'] = len(WORDS) * len(INDICES)

for k in INDICES:
    assert spike(standard_sign_word(0), k) == 0
    assert spike(standard_sign_word(1), k) == 0
    assert spike(standard_sign_word(k), k) == 1
counts['endpoint_checks'] = len(INDICES) * 3

avoidance_pairs = 0
diagonal_cases = 0
for d_word, d_prime_word in product(WORDS, repeat=2):
    choices = tuple(k for k in INDICES
                    if spike(d_word, k) == 0 and spike(d_prime_word, k) == 0)
    assert choices
    avoidance_pairs += 1
    for k in choices:
        # Check every source sign word and both possible E(b,a) guards.
        # E(a,a)=1 is the retained failed-diagonal hypothesis.
        for z_word, guard_ba in product(WORDS, (0, 1)):
            current = 'b' if spike(z_word, k) else 'a'
            if current == 'a':
                destination_word = d_word
            elif guard_ba == 1:
                destination_word = d_prime_word
            else:
                destination_word = (1,) + z_word[:-1]
            result = 'b' if spike(destination_word, k) else 'a'
            assert result == 'a'
            diagonal_cases += 1
counts['avoidance_pairs_checked'] = avoidance_pairs
counts['diagonal_premise_cases_checked'] = diagonal_cases

# Two disjoint spikes cannot avoid two arbitrary destinations: the obstruction
# is concrete at their own two standard endpoints, before any proof theory.
for k, ell in ((2, 3), (2, 4), (3, 4)):
    d_word = standard_sign_word(k)
    d_prime_word = standard_sign_word(ell)
    assert not any(spike(d_word, j) == 0 and spike(d_prime_word, j) == 0
                   for j in (k, ell))
counts['two_spike_counterexamples_checked'] = 3

# Exact-zero ramp after equality calibration: E(a,b)=1, E(b,b)=0,
# d != 0, and Sz != 0. In every branch the premise value is b.
for z_is_zero in (False, True):
    current = 'a' if z_is_zero else 'b'
    if current == 'a':
        destination_is_zero = False  # d != 0
    else:
        destination_is_zero = False  # Sz != 0
    assert ('a' if destination_is_zero else 'b') == 'b'
counts['exact_zero_ramp_cases_checked'] = 2

report = {
    'result': 'PASS',
    'counts': counts,
    'scope': 'finite Boolean spike/avoidance/diagonal combinatorics and exact-zero ramp cases',
    'limits': 'does not mechanize first-order logic, induction recovery, relative-description compilation, or bi-interpretability',
}
destination = Path(__file__).resolve().parent.parent / 'evidence' / 'finite_avoidance_results.json'
destination.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
