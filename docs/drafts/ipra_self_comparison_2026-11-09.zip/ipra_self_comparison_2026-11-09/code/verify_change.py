"""Exact source-delta and three-way public reset-pattern comparison.

This is untrusted validation, not a proof of the calibration metatheorems.
"""

import ast
import difflib
import hashlib
import json
import subprocess
import sys
from pathlib import Path

import upstream_fixtures as u
import validate_comparison_feedback as v

ROOT = Path(__file__).resolve().parent


def without_module_docstring(source):
    tree = ast.parse(source)
    if tree.body and isinstance(tree.body[0], ast.Expr):
        if isinstance(tree.body[0].value, ast.Constant) and isinstance(tree.body[0].value.value, str):
            tree.body.pop(0)
    return ast.dump(tree, include_attributes=False)


def main():
    baseline = ROOT / "baseline_feedback.py"
    candidate = ROOT / "comparison_feedback_checker.py"
    raw_predecessor = ROOT / "raw_predecessor_feedback.py"
    original = baseline.read_text()
    if hashlib.sha256(baseline.read_bytes()).hexdigest() != "9ffe0e1034651fbedd47883587db94b5d51b5d1e10c644830244db36f60b46fa":
        raise ValueError("Changed baseline source")
    changes = [
        ("return choose(sign(comparison), successor(index), sign(predecessor(comparison)))",
         "return choose(sign(comparison), successor(index), app(COMPARISON, comparison, successor(zero())))"),
        ('PREDECESSOR = ["rec", ["zero", 0], ["proj", 2, 0]]\n', ''),
        ('def predecessor(t):\n    return app(PREDECESSOR, t)\n\n\n', '')
    ]
    expected = original
    for before, after in changes:
        if expected.count(before) != 1:
            raise ValueError("Expected one occurrence of each stated source change")
        expected = expected.replace(before, after)
    if without_module_docstring(expected) != without_module_docstring(candidate.read_text()):
        raise ValueError("Unexpected executable change")
    (ROOT.parent / "SOURCE_CHANGE.patch").write_text(''.join(difflib.unified_diff(
        original.splitlines(keepends=True), candidate.read_text().splitlines(keepends=True),
        fromfile="baseline_feedback.py", tofile="comparison_feedback_checker.py")))

    resets = {
        "comparison": lambda value, anchor, index, old=False:
            u.select(u.sign(v.comparison(value, anchor)), u.s(index),
                     v.comparison(v.comparison(value, anchor), u.ONE)),
        "raw_predecessor": lambda value, anchor, index, old=False:
            u.select(u.sign(v.comparison(value, anchor)), u.s(index),
                     u.call(u.PRED, v.comparison(value, anchor))),
        "bounded_predecessor": lambda value, anchor, index, old=False:
            u.select(u.sign(v.comparison(value, anchor)), u.s(index),
                     u.sign(u.call(u.PRED, v.comparison(value, anchor))))
    }
    checkers = {"comparison": candidate, "raw_predecessor": raw_predecessor,
                "bounded_predecessor": baseline}
    original_reset = v.reset
    receipts = []
    try:
        for label, reset in resets.items():
            v.reset = reset
            packet = v.feedback_schema(u.v("z"), u.v("t"), u.v("c"), ["c", "t"])
            for checker_label, checker in checkers.items():
                expected_accept = label == checker_label
                for flags in ([], ["-O"]):
                    run = subprocess.run([sys.executable, *flags, str(checker)],
                                         input=json.dumps(packet), text=True,
                                         capture_output=True, timeout=15)
                    accepted = run.returncode == 0 and run.stdout == "ACCEPT\n" and not run.stderr
                    rejected = run.returncode == 1 and not run.stdout and run.stderr.startswith("REJECT:")
                    passed = accepted if expected_accept else rejected
                    if not passed:
                        raise ValueError("Reset interface distinction failed")
                    receipts.append({"schema": label, "checker": checker.name,
                                     "optimized": bool(flags), "expected_accept": expected_accept,
                                     "passed": passed})
    finally:
        v.reset = original_reset

    result = {"exact_executable_delta_verified": True,
              "baseline": u.measure(baseline), "candidate": u.measure(candidate),
              "raw_predecessor": u.measure(raw_predecessor),
              "earlier_raw_reset": u.measure(ROOT / "baseline_raw_reset.py"),
              "interface_runs": receipts,
              "scope": "Finite exact-delta and interface checks; written metatheory required."}
    fields = ("normalized_tokens", "ast_nodes", "normalized_bytes")
    result["matched_savings"] = {k: result["baseline"][k] - result["candidate"][k] for k in fields}
    result["earlier_reset_savings"] = {k: result["earlier_raw_reset"][k] - result["candidate"][k] for k in fields}
    (ROOT.parent / "exact_change.json").write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({"exact_executable_delta_verified": True,
                      "interface_runs": len(receipts),
                      "matched_savings": result["matched_savings"],
                      "earlier_reset_savings": result["earlier_reset_savings"]}, indent=2))


if __name__ == "__main__":
    main()
