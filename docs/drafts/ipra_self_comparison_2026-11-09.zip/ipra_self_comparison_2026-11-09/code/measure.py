"""Whole-source comparison using the unchanged inherited normalizer."""
import hashlib
import importlib.util
import json
import platform
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main():
    normalizer = ROOT / "reference/native/source_measure.py"
    spec = importlib.util.spec_from_file_location("source_measure", normalizer)
    measure = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(measure)
    candidates = [
        ("Earlier raw reset", "code/baseline_raw_reset.py"),
        ("Bounded predecessor feedback", "code/baseline_feedback.py"),
        ("Raw predecessor feedback", "code/raw_predecessor_feedback.py"),
        ("Self-comparison, separate sign", "code/comparison_feedback_checker.py"),
        ("Self-comparison, selector sign", "code/self_comparison_checker.py"),
        ("Orbit-pulse ordinary checker", "reference/orbit_pulse_checker.py"),
    ]
    rows = [dict(label=label, file=name, **measure.metrics(ROOT / name))
            for label, name in candidates]
    native_manifest = json.loads((ROOT / "reference/native/manifest.json").read_text())
    native = []
    for item in native_manifest["programs"]:
        path = ROOT / "reference/native" / item["local_file"]
        result = measure.metrics(path)
        if result["sha256"] != item["sha256"]:
            raise ValueError("Changed native comparator: " + item["local_file"])
        native.append(dict(file="reference/native/"+item["local_file"], **result))
    fields = ("normalized_tokens", "ast_nodes", "normalized_bytes")
    envelope = {k: min(r[k] for r in native) for k in fields}
    strict = [r for r in native if not r["file"].endswith("iterable_306.py")]
    snapshot = json.loads((ROOT / "source_snapshot.json").read_text())
    result = {
        "python": platform.python_version(),
        "snapshot": snapshot["commit"],
        "normalizer_sha256": hashlib.sha256(normalizer.read_bytes()).hexdigest(),
        "scope": "Whole modules, true docstrings removed, ast.unparse normalization; standard-library source not expanded.",
        "ordinary_checkers": rows,
        "native_checkers": native,
        "observed_native_coordinate_envelope": envelope,
        "strict_native_coordinate_envelope": {k:min(r[k] for r in strict) for k in fields},
        "native_attainers": {k:[r["file"] for r in native if r[k]==envelope[k]] for k in fields},
        "final_savings_against_bounded_feedback": {k:rows[1][k]-rows[4][k] for k in fields},
        "final_savings_against_raw_reset": {k:rows[0][k]-rows[4][k] for k in fields},
    }
    (ROOT / "evidence/whole_source_metrics.json").write_text(json.dumps(result,indent=2)+"\n")
    table = [r"\begin{center}\small", r"\begin{tabular}{@{}lrrr@{}}",
             r"\toprule", r"Complete program & Tokens & AST nodes & Bytes\\\midrule"]
    for row in rows:
        table.append(f"{row['label']} & {row['normalized_tokens']} & {row['ast_nodes']} & {row['normalized_bytes']}"+r"\\")
    table.append(r"\midrule")
    for name in ("indexed_major.py","iterable_306.py","padded_major.py"):
        row=next(r for r in native if r["file"].endswith("/"+name))
        label={"indexed_major.py":"Native token attainer", "iterable_306.py":"Native AST attainer (iterable input)", "padded_major.py":"Native byte attainer"}[name]
        table.append(f"{label} & {row['normalized_tokens']} & {row['ast_nodes']} & {row['normalized_bytes']}"+r"\\")
    table += [r"\bottomrule",r"\end{tabular}",r"\end{center}"]
    (ROOT / "evidence/metrics_table.tex").write_text("\n".join(table)+"\n")
    print(json.dumps({k:v for k,v in result.items() if k not in ('ordinary_checkers','native_checkers')},indent=2))


if __name__ == "__main__":
    main()
