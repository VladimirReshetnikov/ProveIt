#!/usr/bin/env python3
"""Build a deterministic ZIP and a manifest of all final payload bytes."""
import hashlib
import json
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def payloads():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and '__pycache__' not in p.parts and not any(s.startswith('.') for s in p.relative_to(ROOT).parts)
                  and p.suffix not in ('.pyc','.aux','.log','.out','.toc')
                  and p.name!='MANIFEST.json')


def main():
    files=payloads()
    items=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,
            'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
    (ROOT/'MANIFEST.json').write_text(json.dumps({'format':1,'files':items},indent=2)+'\n')
    files.append(ROOT/'MANIFEST.json')
    dest=ROOT.parent/(ROOT.name+'.zip')
    with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(files):
            item=zipfile.ZipInfo(ROOT.name+'/'+str(p.relative_to(ROOT)),date_time=(2026,11,9,16,0,0))
            item.compress_type=zipfile.ZIP_DEFLATED
            item.external_attr=0o100644<<16
            z.writestr(item,p.read_bytes())
    with zipfile.ZipFile(dest) as z:
        if z.testzip() is not None: raise ValueError('ZIP CRC check failed')
        for item in items:
            data=z.read(ROOT.name+'/'+item['path'])
            if hashlib.sha256(data).hexdigest()!=item['sha256']:raise ValueError('ZIP payload hash mismatch')
    print(json.dumps({'archive':str(dest),'bytes':dest.stat().st_size,
                      'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'payload_files':len(items)},indent=2))


if __name__=='__main__':
    main()
