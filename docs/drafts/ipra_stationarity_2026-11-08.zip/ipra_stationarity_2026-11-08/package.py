"""Create a self-contained release ZIP and verify every archived file."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

root = Path(__file__).resolve().parent
excluded_suffixes = {".aux", ".log", ".out", ".toc", ".pyc"}
files = sorted(
    path for path in root.rglob("*")
    if path.is_file()
    and path.name != "SHA256SUMS"
    and path.suffix not in excluded_suffixes
    and "__pycache__" not in path.parts
    and not any(part.startswith(".") for part in path.relative_to(root).parts)
)
manifest = root / "SHA256SUMS"
manifest.write_text("".join(
    f"{sha256(path.read_bytes()).hexdigest()}  {path.relative_to(root).as_posix()}\n"
    for path in files
), encoding="utf-8")
files = sorted(files + [manifest])
destination = root.with_suffix(".zip")
with ZipFile(destination, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
    for path in files:
        name = f"{root.name}/{path.relative_to(root).as_posix()}"
        info = ZipInfo(name, date_time=(2026, 11, 9, 0, 0, 0))
        info.compress_type = ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, path.read_bytes(), compresslevel=9)
with ZipFile(destination) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(files)
    for path in files:
        name = f"{root.name}/{path.relative_to(root).as_posix()}"
        assert archive.read(name) == path.read_bytes(), name
print(f"Verified {len(files)} files in {destination.name}")
print(f"SHA-256: {sha256(destination.read_bytes()).hexdigest()}")
