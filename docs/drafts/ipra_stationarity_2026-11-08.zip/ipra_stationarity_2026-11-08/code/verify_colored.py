#!/usr/bin/env python3
"""Finite diagnostics for the ambient height/tag operations.

These calculations are NOT a verification of the nonstandard model.
The finite standard tagged test grid is not a model of the coverage/STAT
theory: it is not closed under successor, and ambient points (0, c) with
c != 0 already violate numerical coverage.  No sampling establishes
stationarity, zero-test induction, a nonstandard cut, or bi-interpretability.

We evaluate exact, untruncated natural-number pairs on finite input grids.
The checked properties are computation equations, numerical projection,
threshold congruences, tag swaps, and the displayed clock examples.  The
paper supplies the universal and nonstandard arguments.

All update descriptions are fixed unary syntax trees.  Declaration checks
reject unknown or forward names, duplicate names, undeclared variables, and
unsupported syntax.  A repaired iterator must have an update that reduces
to successor by the zero-iteration computation alone.  There is no eval,
external package, numerical program evaluator, or dependency on source
archives.  Only Python's standard library is used.
"""

from collections import Counter
from functools import lru_cache
import json
from pathlib import Path


ZERO = (0, 0)
U = ("u",)
Z = ("zero",)


class DeclarationError(ValueError):
    """A fixed update description violates the staged syntax."""


class DiagnosticFailure(ValueError):
    """An expected finite property failed."""


def successor(value):
    return value[0] + 1, value[1]


def validate_pair(value):
    if type(value) is not tuple or len(value) != 2:
        raise TypeError("Expected one exact (height, tag) tuple")
    if any(type(part) is not int or part < 0 for part in value):
        raise ValueError("Pair coordinates must be nonnegative integers")


def threshold(left, right, bound):
    """Equal heights; tags must agree precisely below the threshold."""
    return left[0] == right[0] and (
        left[0] >= bound or left[1] == right[1]
    )


def swap_tags(value):
    """The transposition of tags 1 and 2, fixing 0 and every other tag."""
    height, tag = value
    return height, {1: 2, 2: 1}.get(tag, tag)


class Registry:
    """A finite staged list of unary update descriptions.

    Each iterator has two ordinary numerical arguments: count and initial
    state.  Its update has only the one local variable 'u'.  Descriptions
    are literal trees; distinct descriptions are never identified by
    pointwise functional equality.
    """

    def __init__(self, repaired=()):
        self.descriptions = {}
        self.repaired = frozenset(repaired)
        self.sealed = False

    def validate_term(self, term):
        if type(term) is not tuple or not term:
            raise DeclarationError("Update syntax must be a nonempty tuple")
        head = term[0]
        if head in ("u", "zero") and len(term) == 1:
            return
        if head == "succ" and len(term) == 2:
            self.validate_term(term[1])
            return
        if head == "iter" and len(term) == 4:
            name = term[1]
            if type(name) is not str or name not in self.descriptions:
                raise DeclarationError("Unknown or forward iterator name")
            self.validate_term(term[2])
            self.validate_term(term[3])
            return
        raise DeclarationError("Unknown constructor, free variable, or arity")

    def reduce_zero_calls(self, term):
        """Use only J_h(0,a)=a, recursively, to certify a successor alias."""
        if term[0] in ("u", "zero"):
            return term
        if term[0] == "succ":
            return "succ", self.reduce_zero_calls(term[1])
        name = term[1]
        count = self.reduce_zero_calls(term[2])
        initial = self.reduce_zero_calls(term[3])
        if count == Z:
            return initial
        return "iter", name, count, initial

    def declare(self, name, update):
        if self.sealed:
            raise DeclarationError("Registry is sealed")
        if type(name) is not str or not name.isidentifier():
            raise DeclarationError("Iterator name must be an identifier")
        if name in self.descriptions:
            raise DeclarationError("Duplicate iterator name")
        self.validate_term(update)
        if name in self.repaired and self.reduce_zero_calls(update) != (
            "succ", U
        ):
            raise DeclarationError("Repair requires a computation successor alias")
        self.descriptions[name] = update

    def seal(self):
        if not self.repaired.issubset(self.descriptions):
            raise DeclarationError("A requested repaired name was not declared")
        self.sealed = True
        return self

    @lru_cache(maxsize=None)
    def evaluate(self, term, argument):
        if term == U:
            return argument
        if term == Z:
            return ZERO
        if term[0] == "succ":
            return successor(self.evaluate(term[1], argument))
        name, count, initial = term[1:]
        return self.iterate(
            name,
            self.evaluate(count, argument),
            self.evaluate(initial, argument),
        )

    @lru_cache(maxsize=None)
    def iterate(self, name, count, initial):
        if not self.sealed or name not in self.descriptions:
            raise DeclarationError("Evaluation requires a known sealed declaration")
        validate_pair(count)
        validate_pair(initial)
        if name in self.repaired:
            return count[0] + initial[0], count[1] or initial[1]
        value = initial
        for _ in range(count[0]):
            value = self.evaluate(self.descriptions[name], value)
        return value

    @lru_cache(maxsize=None)
    def numerical_term(self, term, argument):
        """Separate scalar interpretation, without tags or repair dispatch."""
        if term == U:
            return argument
        if term == Z:
            return 0
        if term[0] == "succ":
            return self.numerical_term(term[1], argument) + 1
        name, count, initial = term[1:]
        return self.numerical_iteration(
            name,
            self.numerical_term(count, argument),
            self.numerical_term(initial, argument),
        )

    @lru_cache(maxsize=None)
    def numerical_iteration(self, name, count, initial):
        value = initial
        for _ in range(count):
            value = self.numerical_term(self.descriptions[name], value)
        return value


def make_registry(repaired=()):
    registry = Registry(repaired)
    registry.declare("identity", U)
    registry.declare("zero", Z)
    registry.declare("successor", ("succ", U))
    alias_one = ("iter", "identity", Z, ("succ", U))
    alias_two = ("iter", "identity", Z, alias_one)
    registry.declare("successor_alias_one", alias_one)
    registry.declare("successor_alias_two", alias_two)
    registry.declare("successor_twice", ("succ", ("succ", U)))
    registry.declare("zero_test", ("iter", "zero", U, ("succ", Z)))
    registry.declare(
        "reset_then_successor",
        ("succ", ("iter", "zero", U, ("succ", U))),
    )
    registry.declare(
        "nested_successor_iteration",
        ("iter", "successor_alias_two", U, Z),
    )
    return registry.seal()


def require_zero_equation(operation, initial):
    if operation(ZERO, initial) != initial:
        raise DiagnosticFailure("Zero computation lost the initializer")


def run_diagnostics():
    checks = Counter()
    negative_controls = []

    def check(category, condition):
        if not condition:
            raise DiagnosticFailure(category)
        checks[category] += 1

    def expect_rejection(label, action, expected_error=DeclarationError):
        try:
            action()
        except expected_error:
            negative_controls.append(label)
        else:
            raise DiagnosticFailure("Negative control was not rejected: " + label)

    default = make_registry()
    repaired = make_registry(("successor", "successor_alias_one"))
    registries = {"default": default, "two_clock_repairs": repaired}
    states = [(height, tag) for height in range(5) for tag in range(4)]
    bounds = list(range(6))

    for registry_name, registry in registries.items():
        for name, update in registry.descriptions.items():
            for initial in states:
                check(
                    "zero_computation",
                    registry.iterate(name, ZERO, initial) == initial,
                )
                for count in states:
                    value = registry.iterate(name, count, initial)
                    check(
                        "successor_computation",
                        registry.iterate(name, successor(count), initial)
                        == registry.evaluate(update, value),
                    )
                    check(
                        "numerical_projection",
                        value[0]
                        == registry.numerical_iteration(name, count[0], initial[0]),
                    )
                    check(
                        "tag_transposition",
                        swap_tags(value)
                        == registry.iterate(name, swap_tags(count), swap_tags(initial)),
                    )
                    if count[1] == 0 and initial[1] == 0:
                        check("canonical_tags", value[1] == 0)

        for bound in bounds:
            related = [
                (left, right)
                for left in states
                for right in states
                if threshold(left, right, bound)
            ]
            for left, right in related:
                check(
                    "successor_threshold_congruence",
                    threshold(successor(left), successor(right), bound),
                )
            for name in registry.descriptions:
                for count_left, count_right in related:
                    for initial_left, initial_right in related:
                        check(
                            "iterator_threshold_congruence",
                            threshold(
                                registry.iterate(name, count_left, initial_left),
                                registry.iterate(name, count_right, initial_right),
                                bound,
                            ),
                        )

        for count in states:
            for initial in states:
                check(
                    "identity_iteration",
                    registry.iterate("identity", count, initial) == initial,
                )
            zero_test = registry.iterate("zero", count, successor(ZERO))
            check("zero_test_range", zero_test in (ZERO, successor(ZERO)))
            check("successor_tag_transposition", swap_tags(successor(count))
                  == successor(swap_tags(count)))

    colored_positive = [value for value in states if value[0] > 0 and value[1] > 0]
    for name in ("successor", "successor_alias_one", "successor_alias_two"):
        for count in colored_positive:
            check("default_clock_forgets_count_tag",
                  default.iterate(name, count, ZERO) == (count[0], 0)
                  and default.iterate(name, count, ZERO) != count)

    for name in repaired.repaired:
        for count in states:
            check("specified_repaired_clock", repaired.iterate(name, count, ZERO) == count)
    for count in colored_positive:
        check("fresh_alias_still_forgets_count_tag",
              repaired.iterate("successor_alias_two", count, ZERO) == (count[0], 0)
              and repaired.iterate("successor_alias_two", count, ZERO) != count)

    # Each control tests an actual rejection path, rather than merely
    # comparing a Boolean flag in a fabricated result object.
    expect_rejection("invalid_declaration_name", lambda: Registry().declare("bad name", U))
    expect_rejection("forward_reference", lambda: Registry().declare(
        "early", ("iter", "not_yet_declared", Z, U)))
    expect_rejection("undeclared_update_variable", lambda: Registry().declare(
        "capture", ("ambient_parameter",)))

    def duplicate_name():
        registry = Registry()
        registry.declare("identity", U)
        registry.declare("identity", Z)

    expect_rejection("duplicate_declaration", duplicate_name)
    expect_rejection("non_successor_repair", lambda: Registry(("bad",)).declare("bad", U))
    expect_rejection("sealed_registry_mutation", lambda: default.declare("later", U))
    expect_rejection("missing_repaired_declaration", lambda: Registry(("missing",)).seal())

    def corrupted_repair(count, initial):
        # The intended rule uses the initial tag when the count tag is zero.
        # This deliberately wrong rule loses that tag at zero.
        return count[0] + initial[0], count[1]

    expect_rejection(
        "corrupted_repair_drops_initializer_at_zero",
        lambda: require_zero_equation(corrupted_repair, (2, 3)),
        DiagnosticFailure,
    )

    witness = (3, 1)
    zero_coverage_counterexample = (0, 1)
    check("ambient_grid_is_not_coverage_model",
          zero_coverage_counterexample != ZERO and zero_coverage_counterexample[0] == 0)

    return {
        "status": "PASS",
        "verification_scope": "Finite ambient arithmetic diagnostics only; no nonstandard-model verification.",
        "not_verified": [
            "existence or properties of the external nonstandard cut",
            "universal stationarity or induction validity",
            "automorphism groups or non-bi-interpretability",
            "the soundness of a complete iPRA proof checker",
        ],
        "finite_grid_warning": (
            "The test grid is not a model of the coverage/STAT theory. "
            "It is not successor-closed, and (0,1) violates coverage in the standard ambient algebra. "
            "All computed outputs are exact and untruncated."
        ),
        "grid": {
            "heights": list(range(5)),
            "tags": list(range(4)),
            "threshold_bounds": bounds,
            "tag_transposition": [1, 2],
            "pair_count": len(states),
        },
        "registries": {
            label: {
                "declaration_order": list(registry.descriptions),
                "descriptions": registry.descriptions,
                "repaired_iterators": sorted(registry.repaired),
            }
            for label, registry in registries.items()
        },
        "positive_checks": dict(sorted(checks.items())),
        "positive_check_count": sum(checks.values()),
        "negative_controls": negative_controls,
        "negative_control_count": len(negative_controls),
        "total_checks": sum(checks.values()) + len(negative_controls),
        "clock_witness": {
            "count": witness,
            "initial": ZERO,
            "default_successor_iterator": default.iterate("successor", witness, ZERO),
            "repaired_successor_iterator": repaired.iterate("successor", witness, ZERO),
            "repaired_successor_alias_one": repaired.iterate("successor_alias_one", witness, ZERO),
            "fresh_successor_alias_two": repaired.iterate("successor_alias_two", witness, ZERO),
        },
        "corrupted_repair_control": {
            "count": ZERO,
            "initial": (2, 3),
            "wrong_output": corrupted_repair(ZERO, (2, 3)),
            "required_output": (2, 3),
            "rejected_by": "zero computation equation",
        },
    }


def main():
    result = run_diagnostics()
    output = Path(__file__).resolve().parents[1] / "evidence" / "colored_diagnostics.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "positive_checks": result["positive_check_count"],
        "negative_controls": result["negative_control_count"],
        "total_checks": result["total_checks"],
        "output": str(output),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
