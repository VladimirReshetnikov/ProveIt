"""Finite local checks for the reflected-stationarity construction.

This is not an iPRA proof checker. The universal proof is in sections 3--5.
All domains and negative controls are explicit in the generated receipt.
Truth is coded by 0 and falsehood by 1.
"""
from itertools import product
from pathlib import Path
import json


def select(n, a, b):
    return a if n == 0 else b


def sign(n):
    return int(n != 0)


def equality_test(a, b):
    residual = max(a + 1 - b, 0)
    k = select(residual, 1, max(residual - 1, 0))
    return sign(k)


def characteristic(formula, values):
    if isinstance(formula, str):
        return values[formula]
    op, *args = formula
    if op == "bottom":
        assert not args
        return 1
    assert op in ("and", "or", "imp") and len(args) == 2
    left, right = [characteristic(a, values) for a in args]
    if op == "and":
        return select(left, right, 1)
    if op == "or":
        return select(left, 0, right)
    return select(left, right, 0)


def semantic_truth(formula, values):
    if isinstance(formula, str):
        return values[formula] == 0
    op, *args = formula
    if op == "bottom":
        return False
    left, right = [semantic_truth(a, values) for a in args]
    return {"and": left and right, "or": left or right,
            "imp": (not left) or right}[op]


def update(state, new_test):
    return select(state, new_test, 1)


def run():
    counts = {}
    atoms = ["A", "B", ("bottom",)]
    formulas = atoms + [(op, a, b) for op in ("and", "or", "imp")
                        for a in atoms for b in atoms]
    formulas += [(op, a, b) for op in ("and", "or", "imp")
                 for a in tuple(formulas) for b in atoms]
    n = 0
    for formula in formulas:
        for a, b in product((0, 1), repeat=2):
            valuation = {"A": a, "B": b}
            result = characteristic(formula, valuation)
            assert result in (0, 1)
            assert (result == 0) == semantic_truth(formula, valuation)
            n += 1
    counts["formula_valuations"] = n

    n = 0
    for state in range(17):
        for new_test in (0, 1):
            result = update(state, new_test)
            assert result in (0, 1)
            assert result != 0 or new_test == 0
            n += 1
    counts["arbitrary_state_transition_checks"] = n

    rows = []
    for state, old_test, new_test in product((0, 1), repeat=3):
        terminal = state != 0 or old_test == 0
        progress = old_test != 0 or new_test == 0
        result = update(state, new_test)
        if terminal and progress:
            assert result == state
        rows.append({"state": state, "old_test": old_test,
                     "new_test": new_test, "terminal_premise": terminal,
                     "progress_premise": progress, "next_state": result})
    counts["progress_truth_table_rows"] = len(rows)

    n = 0
    for bits in product((0, 1), repeat=9):
        states = [bits[0]]
        for bit in bits[1:]:
            states.append(update(states[-1], bit))
        for state, bit in zip(states, bits):
            assert state in (0, 1) and (state != 0 or bit == 0)
        progresses = all(x != 0 or y == 0 for x, y in zip(bits, bits[1:]))
        if progresses:
            assert len(set(states)) == 1
            if bits[0] == 0:
                assert all(bit == 0 for bit in bits)
        n += 1
    counts["finite_sequences_length_9"] = n

    for a, b in product(range(41), repeat=2):
        assert (equality_test(a, b) == 0) == (a == b)
    counts["equality_detector_pairs_0_to_40"] = 41 ** 2

    negative_controls = {}
    # Omitting the successor from Sa dotminus b equates all a <= b.
    bad_eq = lambda a, b: sign(max(a - b, 0))
    assert bad_eq(0, 1) == 0 and equality_test(0, 1) == 1
    negative_controls["removed_successor_detected_at_0_1"] = True
    # Returning the old state on a false branch loses saturation.
    bad_update = lambda state, bit: select(state, bit, state)
    assert bad_update(2, 0) not in (0, 1)
    negative_controls["unsaturated_update_detected_at_2_0"] = True
    # Resetting an already failed latch to the latest test breaks stationarity.
    reset_update = lambda state, bit: bit
    assert reset_update(1, 0) != 1 and update(1, 0) == 1
    negative_controls["reset_after_failure_detected_at_1_0"] = True

    receipt = {
        "status": "PASS", "scope": "finite local diagnostics, not formal verification",
        "counts": counts, "progress_truth_table": rows,
        "negative_controls": negative_controls,
        "universal_proofs": ["sections/04_latch.tex", "sections/05_equivalence.tex"],
    }
    out = Path(__file__).resolve().parents[1] / "evidence/latch_diagnostics.json"
    out.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"latch_diagnostics": "PASS", "counts": counts}))
    return receipt


if __name__ == "__main__":
    run()
