"""Reproduce source measurements and the disclosed finite diagnostics offline."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
for script in ("comparison/measure.py", "code/verify_latch.py", "code/verify_colored.py"):
    subprocess.run([sys.executable, str(root / script)], cwd=root, check=True)
print("All three reproduction steps passed. Mathematical proof status is unchanged.")
