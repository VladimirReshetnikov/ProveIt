STATIONARITY, BOOLEAN REFLECTION, AND THE iPRA MINIMIZATION PROBLEM
=================================================================
Prepared for Vladimir Reshetnikov, November 8, 2026 (Pacific time).

STATUS FIRST
------------
The requested strict complete-checker improvement is NOT achieved.
This is a mathematical research package, not a claimed smallest kernel.

It contains:
1. A fully specified intuitionistic theory S_B using a one-premise
   stationarity rule and three explicit arithmetic boundary axioms.
   Complete proof translations establish deductive equivalence and
   identity-domain bi-interpretability with full first-order iPRA.
2. A new obstruction relative to the six current drafts: in the small
   scalar-iteration language, stationarity plus numerical coverage,
   successor laws, Boolean range, and zero-test induction still does not
   recover literal-equation induction. Finitely many specified successor
   clock repairs do not suffice. A stronger model even satisfies uniform
   extensionality for fixed closed updates and all successor clocks, but
   its addition fails commutativity and contextual equation induction.
   These models have finite-order automorphisms
   excluding bi-interpretability even through quotient domains and with
   countably many parameters.
3. An exact, qualified single-variable recoding of the existing paired
   logical binder. Its arithmetic bootstrap remains a dependency.
4. Reproduction of the true current complete-program envelope:
   313 normalized tokens / 347 AST nodes / 878 normalized UTF-8 bytes.
   These minima have different attainers and are not universal lower bounds.

START HERE
----------
report.pdf             Compiled mathematical paper.
report.tex             Main LaTeX source; sections/ contains all inputs.
evidence/claims.json    Exact proof and implementation status of each claim.

REPRODUCE OFFLINE
----------------
From this directory:
    python3 reproduce.py
    python3 build.py

To regenerate the checksum manifest and the release ZIP after making
changes, run:
    python3 package.py
The ZIP excludes LaTeX intermediate files and Python bytecode caches.

Python 3.12 is the pinned source-normalization version. The first command
uses only the Python standard library and checks source hashes before
measuring. The build requires pdfLaTeX and the standard packages listed in
report.tex. There is no network dependency for either command.

comparison/ includes all sixteen complete comparator sources unchanged,
the source normalizer, exact source/archive provenance, and inherited
license/attribution records. The source programs are measured as text and
are not imported or executed during measurement. The six original ZIPs
are not duplicated; their pinned identities are in the manifest.

WHAT THE DIAGNOSTICS DO NOT PROVE
--------------------------------
code/verify_latch.py and code/verify_colored.py check local finite cases
and deliberately damaged controls. They are not complete iPRA proof
checkers and are not size competitors. In particular, a finite tagged
ambient algebra is not the nonstandard model constructed in the paper.
Universal results have written proofs; no Lean/Rocq formalization is claimed.

PROVENANCE AND CONTRIBUTION
---------------------------
The current repository was pinned to:
12a94890af11b5e75f753260f3be00bb11ae7f08
https://github.com/VladimirReshetnikov/ProveIt/tree/12a94890af11b5e75f753260f3be00bb11ae7f08/docs/drafts

All six ZIP payloads were checked against their byte sizes and Git blob
SHA-1 values. The new obstruction is not the earlier zero-test model with
its identity iterator altered: that earlier repair violates stationarity.
The new construction keeps identity iteration correct and uses threshold
congruences to prove stationarity for every fixed term. Finite repair
means finitely many literal clock equations. A separate, stronger
construction validates the entire fixed closed-update extensionality
schema and all successor clocks. Its scope does not include updates with
varying free numerical parameters or arbitrary further axioms.

The scalar arithmetic basis, original paired calculus, equality-detector
construction, and prior zero-test/symmetry arguments are attributed to the
inspected drafts. No literature-wide priority or smallestness is claimed.
See report.pdf, sections 1, 2, and 8, for the complete scope distinctions.

SHA256SUMS covers delivered files except itself. Regenerate it after
changing files or rebuilding a new release.
