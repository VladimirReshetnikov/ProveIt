"""Build the paper with pdfLaTeX, including references and the contents table."""
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
if not shutil.which("pdflatex"):
    raise SystemExit("Install pdfLaTeX with the standard LaTeX packages used by report.tex.")
for run in range(3):
    result = subprocess.run(
        ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
        cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
    )
    (root / "evidence/latex_build.txt").write_text(result.stdout)
    if result.returncode:
        print(result.stdout)
        raise SystemExit(result.returncode)
print("Built report.pdf with pdfLaTeX (three passes).")
