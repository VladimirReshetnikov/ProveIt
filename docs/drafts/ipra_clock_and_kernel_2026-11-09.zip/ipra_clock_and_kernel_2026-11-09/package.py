#!/usr/bin/env python3
"""Create a standalone TeX source, payload manifest, and verified ZIP."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

root = Path(__file__).resolve().parent
def expand(path):
    source = path.read_text()
    def insert(match):
        relative = match.group(1)
        return '\n% BEGIN '+relative+'\n'+expand(root/relative)+'\n% END '+relative+'\n'
    source=re.sub(r'\\input\{([^}]+)\}', insert, source)
    def listing(match):
        options=match.group(1)
        body=(root/match.group(2)).read_text()
        return '\\begin{lstlisting}'+options+'\n'+body+'\\end{lstlisting}'
    return re.sub(r'\\lstinputlisting(\[[^\]]*\])\{([^}]+)\}',listing,source)
(root/'report_standalone.tex').write_text(expand(root/'report.tex'))
excluded = {'.aux','.log','.out','.toc','.pyc','.synctex.gz'}
files = sorted(p for p in root.rglob('*')
               if p.is_file() and p.suffix not in excluded
               and '__pycache__' not in p.parts and '.texcache' not in p.parts
               and p.name!='MANIFEST.json')
records = [{'path':p.relative_to(root).as_posix(), 'bytes':p.stat().st_size,
            'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
(root/'MANIFEST.json').write_text(json.dumps({'format':'ipra-research-payload-v1','files':records},indent=2)+'\n')
archive = root.parent/(root.name+'.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in files+[root/'MANIFEST.json']:
        info = zipfile.ZipInfo(root.name+'/'+path.relative_to(root).as_posix(), (2026,11,9,12,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED
        info.external_attr=0o644<<16
        z.writestr(info,path.read_bytes())
with zipfile.ZipFile(archive) as z:
    if z.testzip() is not None:
        raise RuntimeError('ZIP CRC failure')
    for record in records:
        data=z.read(root.name+'/'+record['path'])
        if len(data)!=record['bytes'] or hashlib.sha256(data).hexdigest()!=record['sha256']:
            raise RuntimeError('ZIP content mismatch: '+record['path'])
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,
                  'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
                  'payload_files':len(records)+1}))
