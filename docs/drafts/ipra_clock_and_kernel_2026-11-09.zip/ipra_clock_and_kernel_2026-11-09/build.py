#!/usr/bin/env python3
"""Compile the report offline, with shell escape disabled."""
from pathlib import Path
import json
import os
import shutil
import subprocess

root = Path(__file__).resolve().parent
logs = []
environment = os.environ.copy()
probe = subprocess.run(['kpsewhich', 'pdflatex.fmt'], text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
if not probe.stdout.strip():
    # Local-format bootstrap adapted from the supplied one-fixed-recurrence
    # package. It changes no system TeX files and downloads nothing.
    cache = root/'.texcache'
    trees = [Path('/usr/share/texmf'), Path('/usr/share/texlive/texmf-dist')]
    if not all(p.is_dir() for p in trees):
        raise SystemExit('Configure the installed LaTeX format before building.')
    cache.mkdir(exist_ok=True)
    environment['TEXMF'] = '{'+','.join(map(str,[cache,*trees]))+'}'
    target = cache/'web2c/pdftex/pdflatex.fmt'
    if not target.exists():
        target.parent.mkdir(parents=True,exist_ok=True)
        result = subprocess.run(
            ['pdftex','-ini','-etex','-no-shell-escape','-interaction=nonstopmode',
             '-halt-on-error','-jobname=pdflatex','-progname=pdflatex','pdflatex.ini'],
            cwd=cache,env=environment,text=True,stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT)
        logs.append(result.stdout)
        if result.returncode:
            raise SystemExit(result.stdout[-5000:])
        shutil.move(cache/'pdflatex.fmt',target)
    maps=[trees[0]/'fonts/map/dvips/lm/lm.map']
    maps+=sorted((trees[1]/'fonts/map/dvips/amsfonts').glob('*.map'))
    fontmap=cache/'fonts/map/pdftex/local/pdftex.map'
    fontmap.parent.mkdir(parents=True,exist_ok=True)
    fontmap.write_text('\n'.join(p.read_text() for p in maps))
for number in range(3):
    result = subprocess.run(
        ['pdflatex', '-no-shell-escape', '-halt-on-error',
         '-interaction=nonstopmode', 'report.tex'],
        cwd=root, env=environment, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    logs.append(result.stdout)
    if result.returncode:
        (root/'evidence/latex_build.txt').write_text('\n'.join(logs))
        raise SystemExit(result.stdout[-5000:])
(root/'evidence/latex_build.txt').write_text('\n'.join(logs))
last_log=(root/'report.log').read_text()
if 'There were undefined references' in last_log or 'undefined citations' in last_log:
    raise SystemExit('Unresolved references in report.log')
print(json.dumps({'pdf': str(root/'report.pdf'), 'passes': len(logs),
                  'bytes': (root/'report.pdf').stat().st_size}))
