#!/usr/bin/env python3
"""Reproduce the numerical diagnostics and implementation comparisons."""
from pathlib import Path
import shutil
import subprocess
import sys

root=Path(__file__).resolve().parent
for relative in ('code/check_clock.py','code/native/verify_checker.py','code/measure_checkers.py'):
    subprocess.run([sys.executable,str(root/relative)],cwd=root,check=True)
shutil.copy2(root/'code/clock_checks.json',root/'evidence/clock_checks.json')
shutil.copy2(root/'code/native/checker_validation.json',root/'evidence/checker_validation.json')
print('All packaged reproduction checks passed.')
