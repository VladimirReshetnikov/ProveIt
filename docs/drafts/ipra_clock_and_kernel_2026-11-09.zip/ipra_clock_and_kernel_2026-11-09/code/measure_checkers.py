#!/usr/bin/env python3
"""Measure complete executable sources with the unchanged inherited normalizer."""
from pathlib import Path
import importlib.util
import hashlib
import json
import platform

root = Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('inherited_source_measure',root/'reference/source_measure.py')
measure=importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
manifest=json.loads((root/'reference/frontier_manifest.json').read_text())
rows=[]
for entry in manifest['programs']:
    if entry['status']!='complete':
        continue
    path=root/entry['file']
    if hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']:
        raise RuntimeError('Changed reference: '+entry['file'])
    rows.append({'label':entry['label'],'path':entry['file'],**measure.metrics(path)})
keys=('normalized_tokens','ast_nodes','normalized_bytes')
minimum={k:min(r[k] for r in rows) for k in keys}
candidates=[]
for name in ('checker.py','strict_checker.py'):
    path=root/'code/native'/name
    if path.exists():
        candidates.append({'label':name,**measure.metrics(path)})
result={'scope':'Entire sources after genuine-docstring removal and ast.unparse; no core-only scores.',
        'python':platform.python_version(),'reference_count':len(rows),
        'reference_minima':minimum,'references':rows,'candidates':candidates}
(root/'evidence/checker_metrics.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'reference_count':len(rows),'reference_minima':minimum,'candidates':candidates},indent=2))
