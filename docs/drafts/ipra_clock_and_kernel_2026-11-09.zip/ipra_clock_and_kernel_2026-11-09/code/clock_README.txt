ODD-STATE PREDECESSOR CLOCK
==========================

Written theorem: clock.tex proves a shorter fixed predecessor term in the
bare unshifted closed-iteration equational calculus. It uses equational
reasoning and contextual induction on a literal equation, with fixed
parameters. It assumes neither numerical coverage nor Boolean range
as a disjunction, and no successor separation or conjunction induction.

New finite descriptions
-----------------------
Use the inherited prefix for addition, selector C (zero selects its first
value), parity N, three-cycle M, G(n)=floor(3n/2), and E(n)=2^n. These
standard equalities are explanations, not defining shortcuts in the term
table. All helpers have explicit closed-iteration definitions.

 T(u) = C(N(u), C(N(G(u)), G(u), 1), u+2)
 V(t,n) = I_T(t, 2E(n))
 A(n) = V(G(n), n)
 P(n) = C(N(A(n)), 0, A(n)+N(n))

The proof establishes P(0)=0 and P(Sn)=n on the entire domain. It also
avoids general three-way gluing or any finite-range assertion for M:
one literal-equation induction proves M(G(n))=N(n) using only Boolean
gluing at N(n). Relative
to the inherited unshifted construction it deletes H,d4,M4,e,r,R.
The auxiliary K used in the proof is not needed to define P.

Files
-----
clock.tex: manuscript proof fragment for inclusion in the parent report.
check_clock.py: standard-library numerical diagnostics and term validator.
closed_definitions.json: all old/new definitions, emitted by the program.
clock_checks.json: executed check results and exact description DAG counts.
clock_run.txt: stdout receipt from the same run.
provenance.json: exact source archive, member hashes, inherited/new boundary.
independent_review.txt: independent written proof audit.

Run: python3 check_clock.py

Verification boundary
---------------------
This program is not a proof assistant or full iPRA proof checker. It
checks finite numerical examples and rejects malformed staged descriptions.
The infinite whole-domain assertion rests on the written equational proof.
Only I_S(n,a)=a+n and I_0(n,a)=a if n=0 else 0 are accelerated, and the
script checks both against literal iteration on a separate small grid.
Other iterator updates are evaluated from their declared closed terms.
A branch-reversal mutation is detected by the predecessor diagnostics.

Metric boundary
---------------
Each 0, variable occurrence, successor, and named application contributes
one term node; an iterator contributes one constructor node plus one
update-description reference, then its two argument bodies. Numerals are
successor strings. Each helper body reachable from P is charged once.
The result is 22 definitions / 130 body nodes for the old term and
16 definitions / 93 body nodes for the new term. This omits spelling and
arity-declaration overhead equally on both sides. It is a description DAG
comparison, not a complete proof-checker source-size claim.

The arithmetic construction depends on the unshifted initialized-iterator
basis. No direct transfer to the weaker pre-predecessor shifted basis is
claimed. New definitions are attributable to this investigation, using
the current ProveIt closed-equational common prefix and gluing theorem.
