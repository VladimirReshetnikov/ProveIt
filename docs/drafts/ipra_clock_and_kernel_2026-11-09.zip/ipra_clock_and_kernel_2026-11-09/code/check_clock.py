#!/usr/bin/env python3
"""Finite diagnostics for the odd-state predecessor clock.

The universal result is the written equational proof in clock.tex. This
program validates finite closed descriptions and numerical samples only.
Two iterator accelerations, successor and constant zero, are explicitly
identified and checked against literal iteration on a separate small grid.
No proof of nonstandard-model validity is claimed.
"""
import json
from pathlib import Path

V = lambda x: ["v", x]
Z = ["0"]
S = lambda x: ["S", x]
N = lambda n: Z if n == 0 else S(N(n-1))
C = lambda name, *xs: ["call", name, *xs]
I = lambda h, n, a: ["I", h, n, a]
ADD = lambda a, b: C("add", a, b)
TWO = lambda a: ADD(a, a)
THREE = lambda a: ADD(a, TWO(a))
u, n, a, b, t, v = map(V, ("u", "n", "a", "b", "t", "v"))
DEFS = []
def decl(name, args, body):
    DEFS.append({"name": name, "args": args.split(), "body": body})

decl("succ", "u", S(u))
decl("zero", "u", Z)
decl("add", "a b", I("succ", b, a))
decl("Z", "n", I("zero", n, N(1)))
decl("C", "n a b", ADD(I("zero", n, a), I("zero", C("Z", n), b)))
decl("N", "n", I("Z", n, Z))
decl("j", "u", ADD(C("Z", u), TWO(C("N", u))))
decl("M", "n", I("j", n, Z))
decl("g", "u", S(ADD(u, C("M", u))))
decl("G", "n", I("g", n, Z))
decl("H", "u", C("C", C("N", u), C("G", u), u))
decl("D", "u", TWO(u))
decl("E", "n", I("D", n, N(1)))
decl("d4", "u", C("C", C("M", u), C("Z", C("N", u)), S(u)))
decl("M4", "n", I("d4", n, Z))

# Old construction, copied as mathematical definitions from the current
# closed-equational predecessor section, using explicit repeated addition.
decl("e_old", "v", C("Z", C("j", v)))
decl("r_old", "u", S(ADD(u, C("e_old", C("M4", u)))))
decl("R_old", "n", I("r_old", n, Z))
decl("T_old", "u", C("C", C("M", u), C("C", C("N", u), C("H", u), N(1)), ADD(u, N(3))))
decl("K_old", "u", C("C", C("M", u), THREE(u), u))
decl("V_old", "t n", I("T_old", t, THREE(C("E", n))))
decl("A_old", "n", C("V_old", C("R_old", n), n))
decl("P_old", "n", C("C", C("M", C("A_old", n)), C("e_old", C("M", n)), S(ADD(C("A_old", n), C("M", n)))))

# New construction uses G directly; H and the four-cycle are absent from its dependency DAG.
decl("T_new", "u", C("C", C("N", u), C("C", C("N", C("G", u)), C("G", u), N(1)), ADD(u, N(2))))
decl("K_new", "u", C("C", C("N", u), THREE(u), u))
decl("V_new", "t n", I("T_new", t, TWO(C("E", n))))
decl("A_new", "n", C("V_new", C("G", n), n))
decl("P_new", "n", C("C", C("N", C("A_new", n)), Z, ADD(C("A_new", n), C("N", n))))


def validate(defs):
    prior = {}
    def term(q, allowed):
        if not isinstance(q, list) or not q:
            raise ValueError("term must be a nonempty list")
        tag = q[0]
        if tag == "0" and len(q) == 1:
            return
        if tag == "v" and len(q) == 2 and q[1] in allowed:
            return
        if tag == "S" and len(q) == 2:
            term(q[1], allowed); return
        if tag == "call" and len(q) >= 2 and q[1] in prior:
            if len(q)-2 != len(prior[q[1]]["args"]):
                raise ValueError("wrong helper arity")
            for x in q[2:]: term(x, allowed)
            return
        if tag == "I" and len(q) == 4 and q[1] in prior:
            if len(prior[q[1]]["args"]) != 1:
                raise ValueError("an update must be closed unary")
            term(q[2], allowed); term(q[3], allowed); return
        raise ValueError("unknown, forward, malformed, or unbound expression")
    for d in defs:
        if d["name"] in prior or len(set(d["args"])) != len(d["args"]):
            raise ValueError("duplicate name or formal argument")
        term(d["body"], set(d["args"]))
        prior[d["name"]] = d
    return prior


class Eval:
    def __init__(self, defs):
        self.defs = validate(defs)
        self.orbits = {}
    def call(self, name, *args):
        d = self.defs[name]
        if len(args) != len(d["args"]):
            raise ValueError("evaluation arity mismatch")
        return self.term(d["body"], dict(zip(d["args"], args)))
    def iterate(self, name, count, initial):
        if count < 0 or initial < 0:
            raise ValueError("natural-number inputs required")
        if name == "succ":
            return initial + count
        if name == "zero":
            return initial if count == 0 else 0
        orbit = self.orbits.setdefault((name, initial), [initial])
        while len(orbit) <= count:
            orbit.append(self.call(name, orbit[-1]))
        return orbit[count]
    def term(self, q, env):
        tag = q[0]
        if tag == "0": return 0
        if tag == "v": return env[q[1]]
        if tag == "S": return self.term(q[1], env)+1
        if tag == "call": return self.call(q[1], *(self.term(x, env) for x in q[2:]))
        if tag == "I": return self.iterate(q[1], self.term(q[2], env), self.term(q[3], env))
        raise ValueError("invalid expression")


def node_count(q):
    """One per 0/variable/S/application; iterator plus one update reference."""
    if q[0] in ("0", "v"): return 1
    if q[0] == "S": return 1+node_count(q[1])
    if q[0] == "call": return 1+sum(map(node_count, q[2:]))
    if q[0] == "I": return 2+node_count(q[2])+node_count(q[3])
    raise ValueError(q)

def dependencies(q):
    if q[0] in ("0", "v"): return set()
    if q[0] == "S": return dependencies(q[1])
    if q[0] == "call": return {q[1]} | set().union(*(dependencies(x) for x in q[2:]))
    if q[0] == "I": return {q[1]} | dependencies(q[2]) | dependencies(q[3])
    raise ValueError(q)

def dependency_metrics(prior, root):
    seen = set()
    def visit(name):
        if name in seen: return
        seen.add(name)
        for dep in dependencies(prior[name]["body"]): visit(dep)
    visit(root)
    names = [d["name"] for d in DEFS if d["name"] in seen]
    return {"root": root, "definition_count": len(names),
            "body_nodes": sum(node_count(prior[x]["body"]) for x in names),
            "definitions": {x: node_count(prior[x]["body"]) for x in names}}


def check():
    ev = Eval(DEFS)
    checks = {}
    def record(name, conditions):
        count = 0
        for condition in conditions:
            if not condition: raise RuntimeError("failed diagnostic: " + name)
            count += 1
        checks[name] = count
    record("iterator_accelerators_against_literal_iteration", (
        ev.iterate(h, n, a) == literal(h, n, a)
        for h in ("succ", "zero") for n in range(12) for a in range(12)))
    record("common_prefix_identities", (
        ev.call("N", u+1) == 1-ev.call("N", u)
        and ev.call("N", 3*u) == ev.call("N", u)
        and ev.call("G", u+1) == ev.call("G", u)+1+ev.call("N", u)
        and ev.call("G", 2*u) == 3*u
        and ev.call("G", 3*u) == 3*ev.call("G", u)+ev.call("N", u)
        and ev.call("E", u+1) == 2*ev.call("E", u)
        for u in range(250)))
    record("clock_commutation", (
        ev.call("T_new", ev.call("K_new", u)) == ev.call("K_new", ev.call("T_new", u))
        for u in range(250)))
    record("diagonal_shift", (
        ev.call("V_new", t+1, n+1) == ev.call("K_new", ev.call("V_new", t, n))
        for t in range(8) for n in range(8)))
    record("clock_and_predecessor", (
        ev.call("N", ev.call("A_new", n+2)) == 1
        and ev.call("A_new", n+2)+ev.call("N", n) == n+1
        and ev.call("P_new", n) == max(n-1, 0)
        and ev.call("P_new", n+1) == n
        for n in range(9)))
    record("old_predecessor_comparator", (
        ev.call("P_old", n) == ev.call("P_new", n) == max(n-1, 0)
        for n in range(10)))
    bads = []
    for mutate in (lambda d: d[2].update(body=["call", "P_new", V("a")]),
                   lambda d: d[5].update(body=I("add", V("n"), Z)),
                   lambda d: d[2].update(body=V("unbound")),
                   lambda d: d[2].update(body=["S", V("a"), V("b")])):
        bad = json.loads(json.dumps(DEFS)); mutate(bad)
        try: validate(bad)
        except ValueError: bads.append(True)
        else: bads.append(False)
    record("malformed_definition_rejections", bads)
    # A genuine semantic mutation: reverse the zero/nonzero branch of N(G(u)).
    wrong = json.loads(json.dumps(DEFS))
    for d in wrong:
        if d["name"] == "T_new":
            d["body"] = C("C", C("N", u), C("C", C("N", C("G", u)), N(1), C("G", u)), ADD(u, N(2)))
    wrong_ev = Eval(wrong)
    wrong_values = [wrong_ev.call("P_new", n) for n in range(5)]
    if all(x == max(n-1, 0) for n, x in enumerate(wrong_values)):
        raise RuntimeError("semantic mutation was not detected")
    return {"scope": "Finite numerical diagnostics and closed-description checks; not a formal proof.",
            "accelerators": ["I_succ(n,a)=a+n", "I_zero(n,a)=a if n=0 else 0"],
            "checks": checks,
            "semantic_mutation": {"reversed_parity_branch_values": wrong_values, "rejected": True},
            "metrics_scope": "Shared finite-description DAG, unexpanded named helper applications. Not checker source size.",
            "old": dependency_metrics(ev.defs, "P_old"),
            "new": dependency_metrics(ev.defs, "P_new")}

def literal(h, n, a):
    x = a
    for _ in range(n):
        x = x+1 if h == "succ" else 0
    return x


if __name__ == "__main__":
    root = Path(__file__).resolve().parent
    result = check()
    (root / "closed_definitions.json").write_text(json.dumps(DEFS, indent=2)+"\n")
    (root / "clock_checks.json").write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result, indent=2))
