"""Compile the report, including a local-format fallback for minimal TeX installs."""
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent

def run(args, *, cwd=ROOT, env=None):
    result = subprocess.run(args, cwd=cwd, env=env, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if result.returncode:
        print(result.stdout[-10000:])
        raise SystemExit(result.returncode)
    return result.stdout

def main():
    if not shutil.which('pdflatex'):
        raise SystemExit('A LaTeX installation with pdflatex is required.')
    env = dict(os.environ)
    found = subprocess.run(['kpsewhich','pdflatex.fmt'], env=env,
                           stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    if not found.stdout.strip():
        trees = [p for p in ('/usr/share/texlive/texmf-dist','/usr/share/texmf') if Path(p).is_dir()]
        if trees:
            env['TEXMF'] = '{'+','.join(trees)+'}'
        cache = ROOT/'build'/'texformat'
        cache.mkdir(parents=True, exist_ok=True)
        if not (cache/'pdflatex.fmt').exists():
            run(['pdftex','-ini','-etex','-jobname=pdflatex','-interaction=nonstopmode',
                 '-halt-on-error','pdflatex.ini'], cwd=cache, env=env)
        maps = [Path('/usr/share/texmf/fonts/map/dvips/lm/lm.map'),
                Path('/usr/share/texlive/texmf-dist/fonts/map/dvips/amsfonts/cm.map'),
                Path('/usr/share/texlive/texmf-dist/fonts/map/dvips/amsfonts/cmextra.map'),
                Path('/usr/share/texlive/texmf-dist/fonts/map/dvips/amsfonts/symbols.map')]
        if all(p.exists() for p in maps):
            (cache/'pdftex.map').write_text('\n'.join(p.read_text() for p in maps))
            env['TEXFONTMAPS'] = str(cache)+os.pathsep
        env['TEXFORMATS'] = str(cache)+os.pathsep
    (ROOT/'results').mkdir(exist_ok=True)
    logs=[]
    for _ in range(3):
        logs.append(run(['pdflatex','-interaction=nonstopmode','-halt-on-error',
                         '-output-directory=results','report.tex'], env=env))
    (ROOT/'results'/'latex-build.txt').write_text(logs[-1])
    shutil.copyfile(ROOT/'results'/'report.pdf', ROOT/'report.pdf')
    print('Compiled report.pdf')

if __name__ == '__main__':
    main()
