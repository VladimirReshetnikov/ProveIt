"""Reproducible finite diagnostics; none replace the report's internal proofs."""
import json
from pathlib import Path
import closed_terms as c

ROOT = Path(__file__).resolve().parents[1]

def iterate(f, n, a):
    for _ in range(n):
        a = f(a)
    return a

# Fast standard-number reference functions, deliberately distinct from the
# literal evaluator.  R, T, P and the pairing projections still use their
# displayed iteration formulas.  Modulo and division here are reference
# operations, never primitives of the proposed formal theory.
def H(u):
    return 3 * (u // 2) if u % 2 == 0 else u

def T(u):
    return (H(u) if u % 2 == 0 else 1) if u % 3 == 0 else u + 3

def K(u):
    return 3 * u if u % 3 == 0 else u

def R(n):
    return iterate(lambda u: u + 1 + int(u % 4 == 2), n, 0)

def V(t, n):
    return iterate(T, t, 3 * 2 ** n)

def A(n):
    return V(R(n), n)

def P(n):
    a = A(n)
    return int(n % 3 == 2) if a % 3 == 0 else a + n % 3 + 1

def halver(u):
    return u // 2 if u % 2 == 0 else u

def tagged_halver(z):
    if z % 2:
        return z + 2
    q = z // 2
    return 2 * (q // 2) if q % 2 == 0 else 1

def pair(x, y):
    return iterate(lambda u: 2 * u, x, 2 * y + 1)

def pi1(z):
    return iterate(halver, z, z) // 2

def pi0(z):
    return max(0, z - iterate(tagged_halver, z + 1, 2 * z) // 2)

def require(condition, message):
    if not condition:
        raise AssertionError(message)

def main():
    audit = c.audit()
    failures = 0
    for bad in [c.var(1), ('iter', 'future_update', c.zero(), c.zero())]:
        try:
            c.validate(bad, 1, set(c.UPDATES))
        except ValueError:
            failures += 1
    require(failures == 2, 'Closure/staging malformed examples')

    literal = []
    for n in range(9):
        actual = c.evaluate(c.P(c.numeral(n)))
        require(actual == max(0, n-1), 'Literal predecessor at ' + str(n))
        literal.append({'n': n, 'P(n)': actual})

    checks = {'commutation': 0, 'diagonal_shift': 0, 'predecessor': 0,
              'ramp': 0, 'counting_invariant': 0, 'pairing': 0}
    for u in range(2000):
        require(T(K(u)) == K(T(u)), 'Commutation')
        checks['commutation'] += 1
    for n in range(25):
        for t in range(40):
            require(V(t+1,n+1) == K(V(t,n)), 'Diagonal shift')
            checks['diagonal_shift'] += 1
    for n in range(121):
        require(P(n) == max(0,n-1), 'Reference predecessor')
        checks['predecessor'] += 1
        require(R(n) == n + n//3 and R(n+3) == R(n)+4, 'Ramp')
        checks['ramp'] += 1
        b = A(n+3)
        require(b % 3 == 1 and b+n%3 == n+1, 'Counting invariant')
        checks['counting_invariant'] += 1
    for x in range(9):
        for y in range(13):
            z = pair(x,y)
            require(pi0(z) == x and pi1(z) == y, 'Pairing projections')
            checks['pairing'] += 1

    trajectory = []
    u = 3 * 2 ** 6
    for t in range(R(6)+1):
        trajectory.append({'step': t, 'state': u})
        u = T(u)
    result = {'status': 'PASS', 'scope': 'finite diagnostics, not formal proof',
              'closed_update_audit': audit, 'malformed_definitions_rejected': failures,
              'literal_predecessor': literal, 'reference_checks': checks,
              'trajectory_n6': trajectory,
              'reference_acceleration': 'H, parity, remainder, halving use standard-number reference identities'}
    (ROOT/'results'/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
    (ROOT/'artifacts'/'closed_update_definitions.json').write_text(json.dumps(c.UPDATES,indent=2)+'\n')
    print(json.dumps({'status':'PASS','literal_predecessor_cases':len(literal),
                      'closed_updates':len(audit),'reference_checks':checks},indent=2))

if __name__ == '__main__':
    main()
