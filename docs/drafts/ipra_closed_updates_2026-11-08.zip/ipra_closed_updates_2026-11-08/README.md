# Closed-update intuitionistic arithmetic

Prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific time).

The complete report is **report.pdf**, compiled from **report.tex** and the
included section files.

## Main result

All initialized iteration updates may be restricted to fixed closed unary
terms. Their only possible free variable is their state argument. Arbitrary
numerical parameters occur only in the count and initializer arguments.

The report proves predecessor using only literal-equation induction, derives
quantifier-free reflection, supplies a closed-update pairing and both
projections, and compiles every fixed primitive-recursive description by
packing its parameters into the numerical state. It proves whole-domain
bi-interpretability with full intuitionistic PRA; both interpretation
composites have the identity graph x=y.

This closes the internal predecessor/pairing gap explicitly left in the
current foundation audit. The classical standard-number functional
completeness of pure iteration is attributed to Gladstone, with Severin's
primary account as an accessible reference. No global priority claim is made.

## Important comparison limit

The current twelve-archive checker envelope is 317 normalized tokens,
348 AST nodes, and 885 normalized bytes. This package does not establish a
complete accepting program below those minima or an absolutely simplest
axiomatization. It establishes a mathematical parameter-elimination theorem.
The old logical clausal basis is inherited and attributed, not claimed as new.

## Contents

- `report.tex`, `sections/`, `report.pdf`: complete statement and proofs.
- `artifacts/closed_terms.py`: staged closed-update definitions, syntax audit,
  and literal evaluator. This is not a theorem prover or proof checker.
- `artifacts/closed_update_definitions.json`: exported finite update trees.
- `artifacts/validate.py`: finite numerical diagnostics, separated from proofs.
- `comparison/`: twelve frozen current root checker programs, source hashes,
  archive provenance, inherited normalizer, and complete measurements.
- `results/`: validation results, comparison table, build record, PDF QA record.
- `attribution/`: provenance and inherited license.
- `build.py`, `reproduce.py`: reproducible build and diagnostics.
- `SHA256SUMS.txt`: checksums for the package files.

The proofs are written mathematical derivations, not Lean or Rocq
formalizations. The report contains a Further research questions section.

## Reproduce

Python 3.12 and a standard LaTeX installation with pdflatex are sufficient.

```sh
python3 reproduce.py
```

Or run just the mathematical diagnostics:

```sh
python3 artifacts/validate.py
```

The build includes a local-format fallback for installations that provide
the TeX sources but omit a prebuilt pdflatex format. It does not modify the
system TeX installation or require a network connection.

## Source snapshot

Repository: `VladimirReshetnikov/ProveIt`

Commit: `06e097f723c659030816e0194e5eb7e8c607ba9b`

The archive names, Git blob IDs, SHA-256 checksums, and checker member paths
are preserved in `comparison/manifest.json`. All twelve current archives
were inspected. The report distinguishes inherited mathematics, the new
internal constructions, and the remaining checker-size question.
