"""Run the source comparison, mathematical diagnostics, and PDF build."""
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
for path in ['comparison/source_measure.py','artifacts/validate.py','build.py']:
    subprocess.run([sys.executable,str(ROOT/path)],cwd=ROOT,check=True)
