"""Build the paper from its complete local LaTeX sources."""

from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent


if __name__ == "__main__":
    subprocess.run(
        ["latexmk", "-pdf", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
        cwd=ROOT,
        check=True,
    )
