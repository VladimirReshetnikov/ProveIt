"""Untrusted, finite proof translations between two complete checkers.

Neither acceptance program imports this module. A translator failure is not a
rejection by the candidate. Both boundary certificates are checked explicitly.
"""

import hashlib
import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REFERENCE_SHA256 = "b9d315f5f37f7504ad7848cfda57e45fb051186971e7f36b34915a546ea4d0e5"
REFERENCE_PATH = ROOT / "comparison/sources" / (REFERENCE_SHA256 + ".py")


def load_module(name, path):
    specification = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


if hashlib.sha256(REFERENCE_PATH.read_bytes()).hexdigest() != REFERENCE_SHA256:
    raise ValueError("Frozen reference checker has changed")

reference = load_module("frozen_sorted_checker", REFERENCE_PATH)
candidate = load_module("compact_checker", ROOT / "checker.py")


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def forward_proof(proof, context, statistics):
    """Translate an already checked reference proof.

Only existential eliminations lose a field. Source hypothesis aliases are
replaced by the actual validated formula returned from the source context.
"""
    match proof:
        case ["lam", guard, child]:
            local = [*map(reference.subst, context), guard]
            return ["lam", guard, forward_proof(child, local, statistics)]
        case ["pack", witness, child]:
            equation = ["=", 0, reference.subst(witness, formula=False)]
            local = [*map(reference.subst, context), equation]
            return ["pack", witness, forward_proof(child, local, statistics)]
        case ["use", principal, argument, minor]:
            conclusion = reference.infer(principal, context)
            major = forward_proof(principal, context, statistics)
            if conclusion[0] == "ex":
                statistics["existential_conclusion_fields_removed"] += 1
                local = [*map(reference.subst, context), conclusion[1]]
                return ["use", major, forward_proof(minor, local, statistics)]
            return ["use", major, argument,
                    forward_proof(minor, context, statistics)]
        case ["nat", matrix, step]:
            return ["nat", matrix, forward_proof(step, context, statistics)]
        case ["r", _, _, _]:
            return proof
        case _:
            stored = context[context.index(proof)]
            if encoded(proof) != encoded(stored):
                statistics["hypothesis_aliases_canonicalized"] += 1
            return stored


def backward_proof(proof, context, statistics):
    """Recover the explicit existential conclusion from checked inference."""
    match proof:
        case ["lam", guard, child]:
            local = [*map(candidate.subst, context), guard]
            return ["lam", guard, backward_proof(child, local, statistics)]
        case ["pack", witness, child]:
            equation = ["=", 0, candidate.subst(witness, formula=False)]
            local = [*map(candidate.subst, context), equation]
            return ["pack", witness, backward_proof(child, local, statistics)]
        case ["use", principal, minor]:
            existential = candidate.infer(principal, context)
            conclusion = candidate.infer(proof, context)
            statistics["existential_conclusion_fields_restored"] += 1
            local = [*map(candidate.subst, context), existential[1]]
            return ["use", backward_proof(principal, context, statistics),
                    conclusion, backward_proof(minor, local, statistics)]
        case ["use", principal, argument, minor]:
            return ["use", backward_proof(principal, context, statistics),
                    argument, backward_proof(minor, context, statistics)]
        case ["nat", matrix, step]:
            return ["nat", matrix, backward_proof(step, context, statistics)]
        case _:
            return proof


def new_statistics():
    return {"existential_conclusion_fields_removed": 0,
            "existential_conclusion_fields_restored": 0,
            "hypothesis_aliases_canonicalized": 0}


def forward(data, statistics=None):
    if statistics is None:
        statistics = new_statistics()
    canonical = reference.erase(data)
    reference.check(canonical)
    context, conclusion, proof = canonical
    result = [context, conclusion, forward_proof(proof, context, statistics)]
    candidate.check(result)
    return result


def backward(data, statistics=None):
    if statistics is None:
        statistics = new_statistics()
    candidate.check(data)
    context, conclusion, proof = data
    result = [context, conclusion, backward_proof(proof, context, statistics)]
    reference.check(result)
    return result


if __name__ == "__main__":
    direction, path = sys.argv[1:]
    with open(path, encoding="utf-8") as stream:
        data = json.load(stream)
    transform = {"forward": forward, "backward": backward}[direction]
    print(json.dumps(transform(data), separators=(",", ":")))
