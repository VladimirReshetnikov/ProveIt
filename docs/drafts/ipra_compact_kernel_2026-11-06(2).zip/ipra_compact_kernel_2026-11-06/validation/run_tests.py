"""Reproduce the finite verification evidence using only this package.

The complete checker imports none of this code. Source expectations come
from frozen labelled fixtures or explicit written formation/scope contracts.
This executable audit is not a machine-checked metatheorem.
"""

import hashlib
import json
import platform
import subprocess
import sys
from pathlib import Path

from transport import (ROOT, REFERENCE_SHA256, backward, candidate, encoded,
                       forward, new_statistics, reference)

HERE = Path(__file__).resolve().parent
REJECTIONS = (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError)


def require(condition, explanation):
    if not condition:
        raise RuntimeError(explanation)


def accepts(module, data):
    try:
        return module.check(data) is True
    except REJECTIONS:
        return False


def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, separators=(",", ":")) + "\n", encoding="utf-8")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit_reference_corpus():
    manifest = json.loads((HERE / "reference_manifest.json").read_text())
    records = []
    statistics = new_statistics()
    alias_files = []
    for record in manifest["records"]:
        path = ROOT / record["path"]
        require(digest(path) == record["sha256"], "Changed fixture: " + record["path"])
        data = json.loads(path.read_text())
        expected = record["expected"]
        observed = accepts(reference, data)
        require(observed == expected, "Reference label changed: " + record["name"])
        row = {"name": record["name"], "expected": expected,
               "reference_result": observed}
        if expected:
            per_file = new_statistics()
            translated = forward(data, per_file)
            restored = backward(translated, per_file)
            require(reference.erase(data)[:2] == translated[:2] == restored[:2],
                    "A proof translation changed the declared sequent")
            for key, count in per_file.items():
                statistics[key] += count
            if per_file["hypothesis_aliases_canonicalized"]:
                alias_files.append(record["name"])
            destination = HERE / "translated" / record["name"]
            save_json(destination, translated)
            if record["name"].startswith("examples/"):
                save_json(ROOT / record["name"], translated)
            row.update({"candidate_result": True, "reverse_reference_result": True,
                        "translated_path": str(destination.relative_to(ROOT)),
                        "translated_sha256": digest(destination),
                        "restored_sha256": hashlib.sha256(encoded(restored).encode()).hexdigest(),
                        "transformations": per_file})
        else:
            # These fixtures have unchanged proof-record syntax. In particular,
            # none is an invalid old existential elimination whose result field
            # would be discarded by the new format.
            canonical = reference.erase(data)
            observed = accepts(candidate, canonical)
            require(not observed, "Candidate accepted a shared-format rejection: " + record["name"])
            row.update({"candidate_result": False,
                        "treatment": "unchanged syntax after public falsity expansion"})
        records.append(row)
    return {"source_commit": manifest["commit"],
            "reference_checker_sha256": REFERENCE_SHA256,
            "accepted_reference_certificates": sum(x["expected"] for x in records),
            "forward_checked": sum(x["expected"] for x in records),
            "backward_checked": sum(x["expected"] for x in records),
            "selected_shared_format_rejections": sum(not x["expected"] for x in records),
            "transformations": statistics, "canonicalized_alias_files": alias_files,
            "records": records}


def audit_distinct_introduction_tags():
    truth = ["=", -1, -1]
    records = []
    # These hypotheses must enter the formula-leaf clause, never an
    # introduction clause. Using native pi/ex as proof tags breaks this test.
    for label, formula in [
            ("literal_pi_hypothesis", ["pi", ["=", 0, 0], ["=", 0, 0]]),
            ("literal_ex_hypothesis", ["ex", ["=", 0, 0]])]:
        data = [[formula], formula, formula]
        require(accepts(candidate, data), "Constructor collision: " + label)
        path = ROOT / "examples" / (label + ".json")
        save_json(path, data)
        records.append({"name": label, "api": "check", "expected": True,
                        "path": str(path.relative_to(ROOT))})
    # A direct inference contract tests an unused guard without also relying
    # on rejection of an ill-formed declared goal in the outer envelope.
    for number, guard in enumerate([0, True, ["=", -1], ["pi", truth, 0]]):
        proof = ["lam", guard, truth]
        try:
            candidate.infer(proof, [truth])
        except REJECTIONS:
            pass
        else:
            raise RuntimeError("Malformed unused guard reached an inferred result")
        records.append({"name": "malformed_unused_guard_" + str(number),
                        "api": "infer", "expected": False,
                        "proof": proof, "context": [truth]})
    return {"cases": len(records), "positive": 2, "negative": 4, "records": records}


def audit_changed_certificate_format():
    """Record why rejection preservation is not asserted for arbitrary inputs."""
    truth = ["=", -1, -1]
    existential = ["ex", truth]
    records = []
    for label, old_result in [
            ("malformed_old_result", 0),
            ("incorrect_old_result", ["=", -1, ["s", -1]])]:
        old_data = [[existential], truth,
                    ["use", existential, old_result, truth]]
        new_data = [[existential], truth, ["use", existential, truth]]
        require(not accepts(reference, old_data), "Expected bad old-format record")
        require(accepts(candidate, new_data), "Valid inferred result was rejected")
        try:
            forward(old_data)
        except REJECTIONS:
            pass
        else:
            raise RuntimeError("Public translator failed to validate its source")
        old_path = HERE / "format_changes" / (label + ".old.json")
        new_path = HERE / "format_changes" / (label + ".new.json")
        save_json(old_path, old_data)
        save_json(new_path, new_data)
        records.append({"name": label, "old_expected": False, "new_expected": True,
                        "public_forward_translator_rejects_bad_source": True,
                        "old_path": str(old_path.relative_to(ROOT)),
                        "new_path": str(new_path.relative_to(ROOT)),
                        "explanation": "The new record omits a defective old result annotation; its continuation still proves the stated valid theorem."})
    return {"cases": len(records), "records": records}


def audit_cli():
    positive = ROOT / "examples/reflexivity.json"
    negative = HERE / "reference/validation/direct/numerical_rule_wrong_premise_00.json"
    records = []
    for optimized in (False, True):
        for path, expected in [(positive, True), (negative, False)]:
            command = [sys.executable]
            if optimized:
                command.append("-O")
            command.extend([str(ROOT / "checker.py"), str(path)])
            process = subprocess.run(command, capture_output=True, text=True, timeout=30)
            require(process.returncode == (0 if expected else 1), "CLI status mismatch")
            require(process.stdout.strip() == ("ACCEPT" if expected else "REJECT"),
                    "CLI output mismatch")
            require(not process.stderr, "Unexpected CLI stderr")
            records.append({"optimized": optimized,
                            "path": str(path.relative_to(ROOT)),
                            "expected": expected, "exit_code": process.returncode,
                            "stdout": process.stdout.strip()})
    return records


def main():
    corpus = audit_reference_corpus()
    tags = audit_distinct_introduction_tags()
    formats = audit_changed_certificate_format()
    cli = audit_cli()
    # The independently authored scope audit computes expectations from
    # binder depths, not by using candidate.subst to generate its answers.
    command = [sys.executable, str(HERE / "scope_audit.py"),
               str(ROOT / "checker.py"), str(HERE / "scope_audit_results.json")]
    process = subprocess.run(command, capture_output=True, text=True, timeout=60)
    require(process.returncode == 0, "Independent scope audit failed:\n" + process.stderr)
    scope = json.loads((HERE / "scope_audit_results.json").read_text())
    require(scope["all_checks_passed"], "Independent scope audit did not pass")
    result = {"status": "passed", "python_version": platform.python_version(),
              "checker_sha256": digest(ROOT / "checker.py"),
              "reference_replay": corpus, "introduction_tag_regressions": tags,
              "certificate_format_changes": formats, "cli_checks": cli,
              "independent_scope_audit": {key: value for key, value in scope.items()
                                          if key != "concrete_certificate_cases"},
              "qualification": "Finite regression, proof-transport and independent scope tests support the written metatheory. They are not a formalized proof of checker soundness, completeness, or absolute minimality."}
    (HERE / "verification.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"],
                      "accepted_reference_certificates": corpus["accepted_reference_certificates"],
                      "forward_checked": corpus["forward_checked"],
                      "backward_checked": corpus["backward_checked"],
                      "selected_reference_rejections": corpus["selected_shared_format_rejections"],
                      "proof_transformations": corpus["transformations"],
                      "distinct_tag_and_guard_cases": tags["cases"],
                      "format_change_examples": formats["cases"],
                      "cli_checks": len(cli),
                      "independent_scope_audit": result["independent_scope_audit"]}, indent=2))


if __name__ == "__main__":
    main()
