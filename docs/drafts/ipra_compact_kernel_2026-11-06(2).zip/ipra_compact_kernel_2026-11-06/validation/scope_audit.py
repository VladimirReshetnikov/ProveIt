"""Untrusted, independent tests for the scope/formation contract.

Expected answers below are constructed from the written syntax contract,
without calling the candidate's substitution to generate them.  This is a
finite executable audit, not a formalized soundness proof.
"""

import hashlib
import importlib.util
import json
import sys
from pathlib import Path


def load(path):
    spec = importlib.util.spec_from_file_location("audited_kernel", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


REJECTIONS = (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError)
T = ["=", -1, -1]


def equation(a, b=None):
    return ["=", a, a if b is None else b]


def successor(t):
    return ["s", t]


def accepts(module, data):
    try:
        return module.check(data) is True
    except REJECTIONS:
        return False


def wrap(index, rec_depth, form_depth, mode):
    """Place one variable under a known number of syntactic binders."""
    term = index
    for _ in range(rec_depth):
        # The body is inspected even though R0 would not evaluate it.
        term = ["r", -1, -1, term]
    result = equation(term, -1)
    for level in range(form_depth):
        choice = mode if mode < 3 else level % 3
        if choice == 0:
            result = ["ex", result]
        elif choice == 1:
            result = ["pi", result, T]
        else:
            result = ["pi", T, result]
    return result


def main():
    root = Path(__file__).resolve().parents[1]
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else root / "checker.py"
    module = load(path)
    scope = []

    def scope_case(label, original, expected):
        try:
            actual = module.subst(original, [None, -1])
        except REJECTIONS:
            assert expected is None, (label, "unexpected deletion rejection")
        else:
            assert expected is not None, (label, "escaped eigenvariable")
            assert actual == expected, (label, actual, expected)
            assert module.subst(actual) == original, (label, "failed lift round trip")
        principal = ["ex", original]
        certificate = [[principal], T if expected is None else expected,
                       ["use", principal, original]]
        assert accepts(module, certificate) == (expected is not None), label
        scope.append({"name": label, "accepted": expected is not None})

    # Every constructor position that contributes binder depth appears here.
    # A target eigenvariable is index d at depth d; indices below d are local.
    for rec_depth in range(4):
        for form_depth in range(5):
            depth = 2 * rec_depth + form_depth
            for mode in range(4):
                positions = [(depth, None), (depth + 1, depth),
                             (depth + 3, depth + 2)]
                if depth:
                    positions.extend([(0, 0), (depth - 1, depth - 1)])
                for original_index, expected_index in positions:
                    original = wrap(original_index, rec_depth, form_depth, mode)
                    expected = None if expected_index is None else wrap(
                        expected_index, rec_depth, form_depth, mode)
                    label = f"r{rec_depth}_f{form_depth}_m{mode}_i{original_index}"
                    scope_case(label, original, expected)

    # Recursor counters and initializers have scope width zero.  These cases
    # also combine them with the two separate scopes of nested recursor bodies.
    scope_case("rec_counter_escape", equation(["r", 0, -1, -1], -1), None)
    scope_case("rec_initializer_escape", equation(["r", -1, 0, -1], -1), None)
    scope_case("rec_counter_parameter", equation(["r", 1, -1, -1], -1),
               equation(["r", 0, -1, -1], -1))
    scope_case("rec_initializer_parameter", equation(["r", -1, 1, -1], -1),
               equation(["r", -1, 0, -1], -1))
    scope_case("mixed_rec_scopes",
               ["pi", T, equation(["r", 2, 0, ["r", 2, 4, 6]], -1)],
               ["pi", T, equation(["r", 1, 0, ["r", 2, 3, 5]], -1)])
    for name, inner in [("inner_counter", ["r", 3, 4, 6]),
                        ("inner_initializer", ["r", 2, 3, 6]),
                        ("inner_body", ["r", 2, 4, 5])]:
        scope_case(name + "_escape",
                   ["pi", T, equation(["r", 2, 0, inner], -1)], None)

    e0 = equation(0)
    e1 = equation(1)
    principal = ["ex", e0]
    quantified = ["pi", T, T]
    r0 = ["r", -1, -1, -1]
    cases = []

    def case(name, data, expected):
        actual = accepts(module, data)
        assert actual == expected, (name, actual, expected, data)
        cases.append({"name": name, "accepted": actual, "certificate": data})

    case("literal_integer_hypothesis", [[e0], e0, e0], True)
    case("boolean_lookup_key_is_rejected", [[e0], e0, equation(False)], False)
    case("float_lookup_key_is_rejected", [[e0], e0, equation(0.0)], False)
    case("boolean_lookup_key_does_not_hide_escape",
         [[principal], T, ["use", principal, equation(False)]], False)
    case("float_lookup_key_does_not_hide_escape",
         [[principal], T, ["use", principal, equation(0.0)]], False)
    independent = ["ex", e1]
    case("boolean_alias_of_outer_parameter_is_rejected",
         [[independent], e0, ["use", independent, equation(True)]], False)
    case("null_is_never_an_input_term", [[equation(None)], T, T], False)

    malformed_terms = [None, True, False, -1.0, 0.0, -2, "s", "ss", {},
                       {"s": -1}, ["s"], ["s", -1, -1], ["r", -1, -1],
                       ["r", -1, -1, -1, -1], T, ["ex", T], ["unknown", -1]]
    for number, bad in enumerate(malformed_terms):
        case(f"unused_pi_witness_{number}",
             [[quantified, T], T, ["use", quantified, bad, T]], False)
        case(f"unused_existential_witness_{number}",
             [[T], ["ex", T], ["pack", bad, T]], False)
        # Constant transport erases the computed equation from the final goal.
        case(f"hidden_unused_R0_body_{number}",
             [[T], T, ["use", ["r", -1, -1, bad], T, T]], False)
        case(f"hidden_unused_RS_initializer_{number}",
             [[T], T, ["use", ["r", ["s", -1], bad, -1], T, T]], False)
        case(f"hidden_malformed_rec_counter_{number}",
             [[T], T, ["use", ["r", bad, -1, -1], T, T]], False)

    for number, counter in enumerate([0, 1, 100, r0,
                                       ["r", ["s", -1], -1, 0]]):
        case(f"well_formed_noncomputing_counter_{number}",
             [[T], T, ["use", ["r", counter, -1, -1], T, T]], False)

    for number, counter in enumerate([-1, ["s", -1], ["s", 0], ["s", r0]]):
        case(f"recognized_computing_counter_{number}",
             [[T], T, ["use", ["r", counter, -1, -1], T, T]], True)

    for number, bad_formula in enumerate([0, -1, None, True, "=", ["="],
                                          ["=", -1], ["=", -1, -1, -1],
                                          equation(-1.0), equation(False),
                                          ["ex", -1], ["s", -1],
                                          {"=": None, "s": None, "r": None}]):
        case(f"malformed_declared_goal_{number}",
             [[T], bad_formula, T], False)
        case(f"malformed_stored_context_{number}",
             [[T, bad_formula], T, T], False)
        case(f"malformed_equality_template_{number}",
             [[T], T, ["use", T, bad_formula, T]], False)
        case(f"malformed_numerical_matrix_{number}",
             [[T], T, ["nat", bad_formula, T]], False)

    # Inferred existential elimination requires exactly one branch certificate.
    for number, args in enumerate([[], [T, T], [T, None], [T, T, T]]):
        closed = ["ex", T]
        case(f"existential_use_wrong_arity_{number}",
             [[closed, T], T, ["use", closed, *args]], False)
    case("valid_closed_existential_elimination",
         [[["ex", T]], T, ["use", ["ex", T], T]], True)

    # Literal equation induction is permitted; quantified induction is not.
    matrix = equation(0)
    step = ["pi", matrix, equation(successor(0))]
    case("equation_induction_rule",
         [[step], ["pi", T, matrix], ["nat", matrix, step]], True)
    compound = ["ex", equation(1)]
    compound_base = ["ex", T]
    compound_successor = ["ex", equation(successor(1))]
    forbidden_step = ["pi", compound, compound_successor]
    good_step = ["pi", compound_base, compound_successor]
    case("quantified_induction_hypothesis_rejected",
         [[forbidden_step], ["pi", compound_base, compound],
          ["nat", compound, forbidden_step]], False)
    case("quantified_case_step_accepted",
         [[good_step], ["pi", compound_base, compound],
          ["nat", compound, good_step]], True)

    result = {"candidate": path.name, "candidate_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
              "scope_cases": len(scope),
              "scope_direct_and_complete_certificates": 2 * len(scope),
              "scope_accepted": sum(x["accepted"] for x in scope),
              "scope_rejected": sum(not x["accepted"] for x in scope),
              "adversarial_certificate_cases": len(cases),
              "adversarial_expected_accepts": sum(x["accepted"] for x in cases),
              "adversarial_expected_rejects": sum(not x["accepted"] for x in cases),
              "all_checks_passed": True, "concrete_certificate_cases": cases}
    destination = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(__file__).with_name("scope_audit_results.json")
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items()
                      if key != "concrete_certificate_cases"}, indent=2))


if __name__ == "__main__":
    main()
