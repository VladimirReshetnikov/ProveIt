Verification artifacts
======================

Run from any working directory:

    python3 /path/to/package/validation/run_tests.py

The runner uses only files within this package and the Python standard
library. Neither checker imports any verification or proof-generation code.
The frozen comparison checker is addressed by its exact SHA-256 filename in
comparison/sources; transport.py checks that hash before importing it.

reference_manifest.json records the repository commit, source archive hash,
member paths, frozen file hashes, original expectation labels, and selection
policy. The positive corpus comprises all 16 labelled positive direct cases,
all 116 labelled positive translated cases, and all 18 current-format examples
from the sorted-certificates draft. Example metadata and the two explicitly
legacy-format .old files are identified separately, not tested as new-format
certificates. Fourteen negative cases are selected because their proof-record
syntax is unchanged in the candidate.

The runner validates each frozen positive in the reference checker, translates
it to the candidate, checks the result, translates back, and checks that result
in the reference checker. The complete declared context and conclusion are
preserved. It regenerates the new certificates in translated/ and the eighteen
arithmetic examples in ../examples/. Literal Pi/Ex hypothesis examples are
added separately to guard against introduction-tag collisions.

The source checker permits Boolean/integer equality aliases in hypothesis
lookup keys. The translator replaces them by the validated context formula.
The candidate revalidates its literal formula leaves, so it rejects Boolean
and floating-point aliases. The replay records exactly which two source
certificates required this representational normalization.

The new existential-elimination record has no explicit result field. Arbitrary
invalid old-format records are therefore not claimed to remain invalid after
mechanically deleting that field. format_changes/ contains two concrete
examples: an invalid or incorrect old result annotation is omitted, while the
remaining continuation proves the stated valid theorem. The public forward
translator rejects those invalid source records before transformation. New
scope-escape tests exercise the new record format directly.

scope_audit.py is independently authored. It derives its expected substitutions
from known binder depths rather than asking the candidate to construct them.
It tests deletion and inverse lifting across Pi, Ex and the two local recursor
binders, including unevaluated recursor bodies, and also malformed finite-JSON
syntax, ignored witnesses and payloads, and the induction/cases boundary.

verification.json and scope_audit_results.json are generated reports. Counts
refer to executed instances; they are not claims that every formula is distinct.
The tests are finite evidence, not a formal proof of soundness or completeness.
The mathematical invariants and equivalence proof are in report.tex/report.pdf.

No test broadens the checker's trusted dependencies: the complete acceptance
program remains checker.py, importing only json and sys.
