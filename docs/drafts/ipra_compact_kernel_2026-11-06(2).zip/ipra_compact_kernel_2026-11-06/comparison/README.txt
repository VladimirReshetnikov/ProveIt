REPRODUCIBLE FINITE COMPARISON

Repository: VladimirReshetnikov/ProveIt
Commit: 473749742630b5a7779e7c3a36cd23ebd9cb53b5
Directory: docs/drafts

The six ZIP archives at this pinned commit contain 632 occurrences of Python
modules with top-level check and infer function definitions. Deduplication by
the exact original source SHA256 gives 151 source versions. All six principal
checker.py programs, the canonical checker_core.py companion, the additional
falsity-alias companion, and the frontier split-introduction control are named
explicitly in the provenance manifest and comparison table.

FILES

  manifest.json          Every source hash and every archive/member occurrence;
                         archive SHA256, Git blob SHA, byte size, pinned URL,
                         source role, exact member path and pinned commit.
  source_snapshot.json   The recorded GitHub directory metadata and commit.
  sources/<SHA256>.py    Exact original bytes, one file per distinct source.
  metrics.json           Measurements, definitions, all minimizers, candidate
                         measurements and coordinatewise improvement flags.
  table.tex, macros.tex  Generated LaTeX comparison material.
  freeze.py              Optional script to rebuild sources and manifest from
                         the six original ZIPs. Every archive is checked against
                         its actual Git blob SHA and byte size before use.

REPRODUCE THE MEASUREMENTS OFFLINE

  python3 measure.py
  python3 measure.py --require-strict-improvement

These commands use the parent directory's measure.py. No compared program is
imported or executed. The measurement script reads each exact source file with
Python's AST parser and tokenizer and verifies its SHA256 before counting it.
The whole acceptance program is counted, including validation, rule/schema
construction, imports and command-line handling. Shared Python and its JSON
standard library are the runtime boundary, not unmeasured proof machinery.

Five coordinates are reported:

  source_tokens      Significant tokens in the original source, with comments,
                     layout and docstrings excluded. Original parentheses remain.
  normalized_tokens Same token count after ast.unparse of the AST without
                     docstrings. This can differ from source_tokens.
  ast_nodes          Every ast.walk node of that AST, including contexts and
                     operators. Docstrings alone are removed.
  normalized_bytes  UTF-8 bytes of ast.unparse of that AST plus one newline.
  raw_bytes          Every byte of the original source, including documentation
                     and formatting. This is a supplementary layout-sensitive
                     coordinate rather than the primary conceptual measure.

The run's exact Python version is recorded in metrics.json. AST structure and
normalization can depend on that version. The recorded run uses CPython 3.12.14.

THE LOWER ENVELOPE

In CPython 3.12.14, the coordinatewise finite baseline minima are:

  703 source tokens; 701 normalized tokens; 750 AST nodes;
  2,265 normalized bytes; 2,574 raw bytes.

The sorted-certificates canonical checker attains the token minima and an AST
minimum. Its split-introduction canonical control shares that AST minimum and
attains the byte minima. Consequently no single baseline file is silently used
as the minimizer for all five coordinates.

This is a finite source census. It includes historical copies and controls;
inclusion does not certify every candidate's correctness. The lower envelope
is not an absolute lower bound for iPRA axiomatizations. A smaller measured
candidate establishes an implementation comparison against these frozen files,
not a theorem of global minimality.

OPTIONAL PROVENANCE RECONSTRUCTION

Obtain the exact six archives at the pinned URLs in manifest.json, put them in
one directory with their original filenames, and run:

  python3 comparison/freeze.py /absolute/path/to/the/archives
  python3 measure.py

The current pinned GitHub directory metadata is already included as
source_snapshot.json. No original archive is needed for ordinary offline
measurement of the frozen files.
