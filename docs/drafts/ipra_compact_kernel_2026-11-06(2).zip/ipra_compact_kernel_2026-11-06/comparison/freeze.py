"""Freeze exact checker sources from the six pinned comparison ZIP archives.

This optional ingestion utility is not needed for offline measurement. It never
imports or executes a compared program. Its input directory must contain the
original ZIPs; the pinned GitHub directory response is included in this package.
Run: python3 comparison/freeze.py /absolute/path/to/research_input
"""

import argparse
import ast
import hashlib
import json
from pathlib import Path
from urllib.parse import quote
import zipfile


ROOT = Path(__file__).resolve().parent.parent
REPOSITORY = "VladimirReshetnikov/ProveIt"


def role(member):
    parts = Path(member).parts
    if len(parts) == 2 and parts[-1] == "checker.py":
        return "main"
    if len(parts) == 2 and parts[-1] == "checker_core.py":
        return "core"
    if parts[-1] == "step_literal_canonical.py":
        return "frontier_control"
    if len(parts) == 2 and parts[-1] == "checker_with_falsity_alias.py":
        return "public_alias_companion"
    if "controls" in parts or "ablation" in parts or "ablations" in parts:
        return "bundled_control"
    return "bundled_historical_source"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_directory", type=Path)
    args = parser.parse_args()
    snapshot = json.loads((ROOT / "comparison" / "source_snapshot.json").read_text())
    commit = snapshot["commit"]
    sources = {}
    archives = []
    destination = ROOT / "comparison" / "sources"
    destination.mkdir(parents=True, exist_ok=True)

    for entry in snapshot["drafts"]:
        path = args.input_directory / entry["name"]
        data = path.read_bytes()
        archive_sha256 = hashlib.sha256(data).hexdigest()
        git_blob_sha = hashlib.sha1(
            b"blob " + str(len(data)).encode("ascii") + b"\0" + data
        ).hexdigest()
        if git_blob_sha != entry["sha"] or len(data) != entry["size"]:
            raise ValueError("Archive does not match pinned Git object: " + str(path))
        archive = {
            "archive": entry["name"],
            "repository_path": entry["path"],
            "archive_bytes": len(data),
            "archive_sha256": archive_sha256,
            "git_blob_sha": git_blob_sha,
            "pinned_url": "https://github.com/" + REPOSITORY + "/blob/" + commit
                          + "/" + quote(entry["path"], safe="/"),
        }
        archives.append(archive)
        with zipfile.ZipFile(path) as bundle:
            for member in bundle.infolist():
                if not member.filename.endswith(".py"):
                    continue
                body = bundle.read(member)
                try:
                    tree = ast.parse(body.decode("utf-8"), filename=member.filename)
                except (UnicodeDecodeError, SyntaxError):
                    continue
                definitions = {
                    node.name for node in tree.body
                    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                }
                if not {"check", "infer"} <= definitions:
                    continue
                digest = hashlib.sha256(body).hexdigest()
                if digest not in sources:
                    target = destination / (digest + ".py")
                    target.write_bytes(body)
                    sources[digest] = {
                        "sha256": digest,
                        "vendored_path": str(target.relative_to(ROOT)),
                        "source_bytes": len(body),
                        "origins": [],
                    }
                sources[digest]["origins"].append({
                    "archive": entry["name"],
                    "archive_sha256": archive_sha256,
                    "git_blob_sha": git_blob_sha,
                    "repository_path": entry["path"],
                    "member_path": member.filename,
                    "role": role(member.filename),
                })

    rows = []
    for digest, row in sorted(sources.items()):
        row["origins"].sort(key=lambda origin: (origin["archive"], origin["member_path"]))
        row["roles"] = sorted({origin["role"] for origin in row["origins"]})
        rows.append(row)
    manifest = {
        "schema_version": 1,
        "repository": REPOSITORY,
        "commit": commit,
        "directory": "docs/drafts",
        "selection": "Every UTF-8 Python archive member whose parsed module has top-level check and infer function definitions; deduplicated by exact source SHA256.",
        "qualification": "A finite source census, including historical copies and controls. Inclusion is not a correctness certification or a global minimum claim.",
        "roles": {
            "main": "Top-level checker.py in one of the six current archives.",
            "core": "Top-level canonical companion checker_core.py.",
            "frontier_control": "Bundled step_literal_canonical.py: the control attaining the smallest normalized and raw byte counts in this census.",
            "public_alias_companion": "Top-level checker_with_falsity_alias.py.",
            "bundled_control": "Other comparison or ablation controls.",
            "bundled_historical_source": "Earlier source versions retained in a current archive.",
        },
        "archive_count": len(archives),
        "unique_source_count": len(rows),
        "source_occurrence_count": sum(len(row["origins"]) for row in rows),
        "archives": archives,
        "sources": rows,
    }
    output = ROOT / "comparison" / "manifest.json"
    output.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print("Frozen", len(rows), "distinct sources from", manifest["source_occurrence_count"],
          "archive-member occurrences in", len(archives), "archives.")
    print("Pinned commit:", commit)
    print("Manifest:", output)


if __name__ == "__main__":
    main()
