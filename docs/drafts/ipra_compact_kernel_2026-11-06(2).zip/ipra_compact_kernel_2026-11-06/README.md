# A smaller proof kernel for iPRA

This package gives an explicit native axiomatization of intuitionistic
primitive recursive arithmetic, a complete standalone Python certificate
checker, a paper with whole-domain bi-interpretations, and reproducible
comparisons with the six supplied ProveIt draft archives.

## Result

The complete **checker.py** has **681 normalized tokens, 732 AST nodes,
2,234 normalized bytes, and 2,510 raw bytes**. Its original-source significant
token count is **683**. These are strictly below the coordinatewise finite
envelope **701 / 750 / 2,265 / 2,574**, with **703** original-source tokens,
across **151 distinct candidate sources** in the six archives.

Snapshot: VladimirReshetnikov/ProveIt at
473749742630b5a7779e7c3a36cd23ebd9cb53b5.
All source identities, archive hashes, and original member paths are recorded.

This is a synthesis of the sorted-certificate and small-kernel drafts:
infer existential-elimination conclusions by checked scope deletion,
use validated term shape to recognize successors, and validate hypothesis
leaves strictly. The underlying mathematical basis is retained. This is
an improvement over the pinned finite set, not a proof of absolute minimality.

## Read first

- **report.pdf**: compiled paper.
- **report.tex** and **sections/*.tex**: complete paper source.
- **checker.py**: entire trusted acceptance program.
- **comparison/metrics.json**: measured results and precise metric definitions.
- **validation/verification.json**: executed certificate/audit results.
- **validation/scope_audit.txt**: independent correctness audit of the reduction.

The ordinary theory presented by the native calculus is intuitionistic
first-order arithmetic with initialized fixed-description recursion,
literal-equation induction, numerical coverage, and the falsity bridge
0 = S0 implies bottom. The paper proves its bi-interpretability with full
first-order iPRA with quantifier-free induction. Both interpretation domains
are the whole number sort and both composite isomorphisms are equality.
The paper explicitly distinguishes ordinary disjunction from its native
encoding, and proves substitution coherence for each fixed recursion.

## Verify and build

With Python 3.11 or later, no third-party Python packages are needed:

    python3 reproduce.py
    python3 checker.py examples/coverage.json
    python3 checker.py examples/zero_plus_n.json

The reproduction script remeasures every frozen comparator and runs proof
transport, focused rejection cases, scope-deletion audits, and CLI tests.
It does not trust a test generator as part of certificate acceptance.
The recorded normalization uses CPython 3.12.14.

To compile the paper, install a TeX distribution with latexmk, pdflatex,
and the standard packages named in the main LaTeX source, then run:

    python3 build.py

The complete package works offline. Re-fetching original archives is not
needed. **comparison/freeze.py** is optional provenance reconstruction for
someone who has those six ZIPs locally; see **comparison/README.txt**.

## Certificate interface

A certificate is a JSON array [context, conclusion, proof].
Numerical zero is encoded as integer -1; nonnegative integers are
de Bruijn variable indices. Formulas use only equality (=),
guarded universal implication (pi), and existence (ex).
The arithmetic false formula is ["=", -1, ["s", -1]].

The command-line checker prints ACCEPT and exits zero on success.
It prints REJECT and exits one for invalid certificates.
Only json and sys are imported by the checker. There is no
eval, exec, imported theorem database, arbitrary-program evaluator,
or proof-generator dependency. Python optimization does not remove checks.

Proof certificates can be large, and normal Python resource limits apply.
The checker and full metatheory have not been formally verified in Lean/Rocq.
The paper gives the correctness proofs; executed tests are supporting evidence.

## Evidence

- 150 accepted reference certificates translated and accepted.
- 150 reverse translations accepted by the frozen reference.
- 102 redundant existential conclusion fields removed/restored.
- Two legacy Boolean hypothesis aliases replaced by their valid stored formulas.
- 400 binding cases checked directly and through complete certificates:
  315 valid and 85 escaping.
- 161 focused cases: eight accepts and 153 rejections.
- 14 shared-syntax negative reference cases.
- Six introduction/guard regression cases.
- Four CLI runs covering valid/invalid inputs, normally and with -O.

Two format-change examples explicitly explain why erasing an incorrect old
redundant conclusion can turn that old malformed record into a valid new
record. Accepted proofs and theorem conclusions are preserved; arbitrary
rejected old byte strings need not remain rejected after erasure.

## Attribution and integrity

The native mathematical basis and prior checker techniques are attributed
to the supplied drafts in the report. Frozen comparison sources remain
byte-for-byte identical to their archived originals.
**MANIFEST.sha256** covers the delivered files other than itself.
The ZIP contains the LaTeX sources, compiled PDF, checker, examples,
validation artifacts, and frozen source comparison.
