"""Reproduce the complete-checker comparison without executing compared code.

Python's AST parser and tokenizer are the only readers of checker sources.
Run from any directory: python3 /path/to/this/measure.py
Optionally require strict improvement: --require-strict-improvement
"""

import argparse
import ast
import copy
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize


ROOT = Path(__file__).resolve().parent
FIELDS = ("source_tokens", "normalized_tokens", "ast_nodes", "normalized_bytes", "raw_bytes")
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
ROLE_ORDER = {"main": 0, "core": 1, "frontier_control": 2,
              "public_alias_companion": 3, "bundled_control": 4,
              "bundled_historical_source": 5}
LABELS = {
    "ipra_canonical_leaf_2026-11-06.zip": "Canonical leaf",
    "ipra_factored_checker_2026-11-06.zip": "Factored checker",
    "ipra_indexed_kernel_2026-11-06.zip": "Indexed kernel",
    "ipra_shared_rules_2026-11-06.zip": "Shared rules",
    "ipra_small_kernel_2026-11-06(1).zip": "Small kernel",
    "ipra_sorted_certificates_2026-11-06.zip": "Sorted certificates",
}


def docstrings(tree):
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if node.body and isinstance(node.body[0], ast.Expr):
                value = node.body[0].value
                if isinstance(value, ast.Constant) and isinstance(value.value, str):
                    yield node.body[0]


def tokens(source, omitted=()):
    return sum(
        item.type not in IGNORED and not any(
            start <= item.start and item.end <= end for start, end in omitted
        )
        for item in tokenize.generate_tokens(io.StringIO(source).readline)
    )


def measure(path):
    data = path.read_bytes()
    source = data.decode("utf-8")
    original = ast.parse(source, filename=str(path))
    spans = [((node.lineno, node.col_offset), (node.end_lineno, node.end_col_offset))
             for node in docstrings(original)]
    stripped = copy.deepcopy(original)
    ids = {id(node) for node in docstrings(stripped)}
    for node in ast.walk(stripped):
        if hasattr(node, "body") and isinstance(node.body, list):
            node.body = [child for child in node.body if id(child) not in ids]
    normalized = ast.unparse(stripped) + "\n"
    try:
        display_path = str(path.relative_to(ROOT))
    except ValueError:
        display_path = str(path)
    return {
        "path": display_path,
        "sha256": hashlib.sha256(data).hexdigest(),
        "normalized_sha256": hashlib.sha256(normalized.encode("utf-8")).hexdigest(),
        "source_tokens": tokens(source, spans),
        "normalized_tokens": tokens(normalized),
        "ast_nodes": sum(1 for _ in ast.walk(stripped)),
        "normalized_bytes": len(normalized.encode("utf-8")),
        "raw_bytes": len(data),
    }


def envelope(rows):
    return {field: min(row[field] for row in rows) for field in FIELDS}


def label(origin):
    result = LABELS[origin["archive"]]
    if origin["role"] == "core":
        result += ", canonical"
    elif origin["role"] == "frontier_control":
        result = "Sorted split-introduction control"
    elif origin["role"] == "public_alias_companion":
        result += ", falsity alias"
    elif origin["archive"] == "ipra_sorted_certificates_2026-11-06.zip":
        result += ", public"
    return result


def write_tex(result):
    rows = []
    for row in result["sources"]:
        for origin in row["highlighted_origins"]:
            rows.append((origin["archive"], ROLE_ORDER[origin["role"]], label(origin), row))
    lines = [r"\begin{tabular}{@{}lrrrrr@{}}", r"\toprule",
             r"Complete checker & Src. tok. & Norm. tok. & AST & Norm. B & Raw B \\",
             r"\midrule"]
    for _, _, name, row in sorted(rows):
        lines.append(name + " & " + " & ".join(f"{row[key]:,}" for key in FIELDS) + r" \\")
    lower = result["all_source_lower_envelope"]
    lines += [r"\midrule", "Finite lower envelope & "
              + " & ".join(f"{lower[key]:,}" for key in FIELDS) + r" \\"]
    candidate = result["candidate"]
    if candidate:
        lines.append(r"\textbf{New compact kernel} & "
                     + " & ".join(r"\textbf{" + f"{candidate[key]:,}" + "}" for key in FIELDS)
                     + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}", ""]
    (ROOT / "comparison" / "table.tex").write_text("\n".join(lines), encoding="utf-8")

    macros = {
        "ComparedSourceCount": result["unique_source_count"],
        "ComparedOccurrenceCount": result["source_occurrence_count"],
        "ComparedArchiveCount": result["archive_count"],
    }
    names = {"source_tokens": "SourceTokens", "normalized_tokens": "Tokens",
             "ast_nodes": "AST", "normalized_bytes": "Bytes", "raw_bytes": "RawBytes"}
    for key, name in names.items():
        macros["Baseline" + name] = lower[key]
        if candidate:
            macros["Candidate" + name] = candidate[key]
    lines = [r"% Generated by measure.py; token macros use normalized tokens unless Source is explicit."]
    for name, value in macros.items():
        lines.append("\\newcommand{\\" + name + "}{" + f"{value:,}" + "}")
    if candidate:
        for key, name in names.items():
            percent = 100 * (1 - candidate[key] / lower[key])
            lines.append("\\newcommand{\\Candidate" + name + "ReductionPercent}{" + f"{percent:.2f}" + "}")
    (ROOT / "comparison" / "macros.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, default=ROOT / "checker.py")
    parser.add_argument("--require-strict-improvement", action="store_true")
    args = parser.parse_args()
    manifest_path = ROOT / "comparison" / "manifest.json"
    manifest_data = manifest_path.read_bytes()
    manifest = json.loads(manifest_data)
    rows = []
    seen = set()
    for source in manifest["sources"]:
        row = measure(ROOT / source["vendored_path"])
        if row["sha256"] != source["sha256"] or row["raw_bytes"] != source["source_bytes"]:
            raise ValueError("Frozen source hash or size mismatch: " + row["path"])
        if row["sha256"] in seen:
            raise ValueError("Duplicate manifest source: " + row["sha256"])
        seen.add(row["sha256"])
        highlighted = [origin for origin in source["origins"]
                       if origin["role"] in {"main", "core", "frontier_control", "public_alias_companion"}]
        representative = min(source["origins"], key=lambda origin: (
            ROLE_ORDER[origin["role"]], origin["archive"], origin["member_path"]))
        rows.append({**row, "roles": source["roles"],
                     "occurrence_count": len(source["origins"]),
                     "representative_origin": representative,
                     "highlighted_origins": highlighted})
    if len(rows) != manifest["unique_source_count"]:
        raise ValueError("Incorrect unique-source count in manifest")
    lower = envelope(rows)
    candidate = measure(args.candidate.resolve()) if args.candidate.exists() else None
    primary = [row for row in rows if "main" in row["roles"]]
    result = {
        "python_version": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "repository": manifest["repository"],
        "commit": manifest["commit"],
        "manifest_sha256": hashlib.sha256(manifest_data).hexdigest(),
        "archive_count": manifest["archive_count"],
        "unique_source_count": len(rows),
        "source_occurrence_count": sum(row["occurrence_count"] for row in rows),
        "definitions": {
            "source_tokens": "Significant tokens in the original source, excluding layout, comments, docstrings, encoding and end markers; original parentheses remain.",
            "normalized_tokens": "The same tokenization applied to ast.unparse of the docstring-stripped AST, plus its final newline.",
            "ast_nodes": "Every ast.walk node after removing module, class and function docstrings; context and operator nodes are included.",
            "normalized_bytes": "UTF-8 byte length of ast.unparse of the docstring-stripped AST, plus one newline.",
            "raw_bytes": "The complete original UTF-8 source, including comments, docstrings and formatting.",
            "trusted_scope": "The whole standalone acceptance file, including schema construction, validation, imports and CLI; Python and its JSON library are common runtime infrastructure.",
            "normalization_caveat": "AST shape and ast.unparse formatting may depend on the recorded Python version.",
            "execution_policy": "No compared program is imported, evaluated or executed by this script.",
            "lower_envelope": "Coordinatewise minima over the frozen finite source census; different coordinates may have different minimizers.",
            "qualification": "A finite implementation comparison, not an absolute complexity lower bound, a global minimality proof or a correctness certification of every bundled historical/control source.",
        },
        "six_main_lower_envelope": envelope(primary),
        "all_source_lower_envelope": lower,
        "minimizers": {field: [row["sha256"] for row in rows if row[field] == lower[field]]
                       for field in FIELDS},
        "candidate": candidate,
        "candidate_at_or_below_envelope": {field: candidate[field] <= lower[field] for field in FIELDS}
                                          if candidate else None,
        "candidate_strictly_below_envelope": {field: candidate[field] < lower[field] for field in FIELDS}
                                             if candidate else None,
        "candidate_reduction_percent": {field: 100 * (1 - candidate[field] / lower[field]) for field in FIELDS}
                                       if candidate else None,
        "sources": rows,
    }
    destination = ROOT / "comparison" / "metrics.json"
    destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    write_tex(result)
    print("Python", result["python_version"], result["python_implementation"])
    print("Frozen sources:", len(rows), "from", result["source_occurrence_count"], "member occurrences")
    print("Finite lower envelope:", lower)
    if candidate:
        print("Candidate:", {key: candidate[key] for key in FIELDS})
        print("Strict improvement:", result["candidate_strictly_below_envelope"])
    else:
        print("Candidate checker.py is not present yet; baseline-only results written.")
    print("Wrote comparison/metrics.json, comparison/table.tex and comparison/macros.tex")
    if args.require_strict_improvement and (
        candidate is None or not all(result["candidate_strictly_below_envelope"].values())
    ):
        raise SystemExit("Strict improvement over every finite-envelope coordinate was not established.")


if __name__ == "__main__":
    main()
