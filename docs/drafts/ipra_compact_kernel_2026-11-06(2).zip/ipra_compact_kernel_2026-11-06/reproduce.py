"""Reproduce the complete finite comparison and implementation audit offline."""

from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    commands = [
        [sys.executable, "measure.py", "--require-strict-improvement"],
        [sys.executable, "validation/run_tests.py"],
    ]
    for command in commands:
        subprocess.run(command, cwd=ROOT, check=True)
    print("Comparison and verification completed successfully.")


if __name__ == "__main__":
    main()
