Named certificates
==================

Each JSON file is [context, conclusion, proof] and can be checked with:

    python3 checker.py examples/reflexivity.json

reflexivity, successor_injective, coverage, forall_exists_successor,
zero_plus_n, direct_zero_plus_n, direct_successor_plus_n, and the other
arithmetic files are proof translations of current-format examples in the
frozen sorted-certificates draft. Their original bytes and precise provenance
are retained under validation/reference and validation/reference_manifest.json.
The independent runner regenerates these new-format examples.

literal_pi_hypothesis and literal_ex_hypothesis are small new identity
certificates. Their conclusions are actual context formulas. They must remain
literal hypothesis leaves, distinct from lam and pack introduction records.

The remaining arithmetic examples cover iterated predecessor, successor
cancellation, the residual identity and the numerical equality detector used
in the paper. These proofs support concrete instances of the constructions;
they are not a formalized proof of the general bi-interpretability theorem.
