"""Rerun the finite validation suites and exact whole-source comparison."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
COMMANDS = (
    "test.py",
    "test_kernel_boundaries.py",
    "test_compiler_scopes.py",
    "test_context_normalization.py",
    "test_comparators.py",
    "measure.py",
)


def main():
    evidence = ROOT / "evidence"
    logs = evidence / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    environment = dict(os.environ)
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    receipt = {
        "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "python": platform.python_version(),
        "commands": [],
        "scope": "Finite implementation validation and reproducible measurements, not a proof-assistant formalization.",
    }
    for script in COMMANDS:
        path = ROOT / "code" / script
        process = subprocess.run([sys.executable, str(path)], cwd=ROOT,
                                 env=environment, text=True, capture_output=True)
        output = process.stdout + process.stderr
        logfile = logs / (Path(script).stem + ".txt")
        logfile.write_text(output)
        entry = {"script": "code/" + script, "exit_code": process.returncode,
                 "log": str(logfile.relative_to(ROOT)),
                 "script_sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
        receipt["commands"].append(entry)
        print(("PASS " if process.returncode == 0 else "FAIL ") + script)
        if process.returncode:
            (evidence / "reproduction.json").write_text(json.dumps(receipt, indent=2) + "\n")
            raise SystemExit("Validation failed; see " + str(logfile))
    receipt["all_passed"] = True
    (evidence / "reproduction.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print("All supplied finite checks and measurements completed.")


if __name__ == "__main__":
    main()
