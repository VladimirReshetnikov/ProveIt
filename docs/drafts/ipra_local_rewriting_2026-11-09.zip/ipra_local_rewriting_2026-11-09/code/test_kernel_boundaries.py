"""Independent boundary tests for syntax, scopes, declarations, and local rules."""

import copy
import io
import json
from pathlib import Path
import subprocess
import sys
import unittest

import local_checker as kernel


Z = ["0"]


def V(name):
    return ["$", name]


def S(term):
    return ["S", term]


def E(left, right):
    return ["=", left, right]


def comp(left, right):
    return {"rule": "comp", "conclusion": E(left, right)}


def H():
    return comp(["id", Z], Z)


def refl(term):
    source = comp(["id", term], term)
    return {"rule": "rw", "conclusion": E(term, term), "before": source,
            "source": source, "orientation": 0, "side": 0, "path": []}


def packet(proof, declarations=None):
    return {"declarations": declarations or [], "goal": proof["conclusion"],
            "proof": proof}


def induction_packet():
    declarations = [
        {"name": "keep", "kind": "proj", "arity": 2, "index": 1},
        {"name": "constant", "kind": "rec", "arity": 1,
         "base": "0", "step": "keep"},
    ]
    n = V("n")
    value = ["constant", n]
    next_value = ["constant", S(n)]
    update = ["keep", n, value]
    first = {"rule": "rw", "conclusion": E(next_value, value),
             "before": comp(next_value, update), "source": comp(update, value),
             "orientation": 0, "side": 1, "path": []}
    induction = {"rule": "use", "conclusion": E(value, Z), "clause": 1,
                 "term": Z, "premise": H()}
    step = {"rule": "rw", "conclusion": E(next_value, Z), "before": first,
            "source": induction, "orientation": 0, "side": 1, "path": []}
    major = {"rule": "di", "conclusion": ["D", "x", "y", E(["constant", V("y")], Z)],
             "witness": Z, "eigen": "n", "premise": step}
    target = E(["constant", S(S(Z))], Z)
    use = {"rule": "use", "conclusion": target, "clause": 0,
           "term": S(S(Z)), "premise": comp(["constant", Z], Z)}
    proof = {"rule": "de", "conclusion": target, "major": major,
             "eigen": "a", "premise": use}
    return packet(proof, declarations)


class KernelBoundaries(unittest.TestCase):
    def rejects(self, item, mode="local"):
        with self.assertRaises(kernel.ProofError):
            kernel.check_packet(item, mode)

    def test_actual_induction_and_opening(self):
        result = kernel.check_packet(induction_packet())
        self.assertEqual(result["rule_counts"]["di"], 1)
        self.assertEqual(result["rule_counts"]["de"], 1)
        self.assertEqual(result["rule_counts"]["rw"], 2)

    def test_one_occurrence_only(self):
        source = comp(["id", Z], Z)
        old = comp(["id", ["id", Z]], ["id", Z])
        proof = {"rule": "rw", "conclusion": E(["id", Z], ["id", Z]),
                 "before": old, "source": source, "orientation": 0,
                 "side": 0, "path": [0]}
        kernel.check_packet(packet(proof))
        damaged = copy.deepcopy(proof)
        damaged["conclusion"] = E(Z, Z)
        self.rejects(packet(damaged))
        for path in ([1], [-1], [True], [0, 0], [0.0]):
            damaged = copy.deepcopy(proof)
            damaged["path"] = path
            self.rejects(packet(damaged))

    def test_neutral_source_restriction(self):
        proof = refl(Z)
        proof["source"] = refl(Z)
        self.rejects(packet(proof))

    def test_reference_mode_is_explicit(self):
        equality = comp(["id", Z], Z)
        motive = E(V("v"), Z)
        transport = {"rule": "tr", "conclusion": E(Z, Z), "equality": equality,
                     "before": equality, "variable": "v", "motive": motive}
        item = packet(transport)
        self.rejects(item)
        kernel.check_packet(item, "general")
        kernel.check_packet(item, "atomic")
        extra = copy.deepcopy(item)
        extra["mode"] = "general"
        self.rejects(extra)

    def test_basic_recursive_definitions(self):
        declarations = [
            {"name": "previous", "kind": "proj", "arity": 3, "index": 1},
            {"name": "increment", "kind": "comp", "arity": 3,
             "outer": "S", "inners": ["previous"]},
            {"name": "add", "kind": "rec", "arity": 2,
             "base": "id", "step": "increment"},
            {"name": "zero_two", "kind": "comp", "arity": 2,
             "outer": "0", "inners": []},
        ]
        examples = [
            comp(["add", Z, S(Z)], ["id", S(Z)]),
            comp(["add", S(Z), S(Z)], ["increment", Z, ["add", Z, S(Z)], S(Z)]),
            comp(["increment", Z, Z, Z], ["S", ["previous", Z, Z, Z]]),
            comp(["zero_two", S(Z), Z], Z),
        ]
        for proof in examples:
            kernel.check_packet(packet(proof, declarations))
        self.rejects(packet(comp(["add", Z, S(Z)], S(Z)), declarations))

    def test_invalid_declarations(self):
        invalid = [
            {"name": "id", "kind": "proj", "arity": 1, "index": 0},
            {"name": "p", "kind": "proj", "arity": 0, "index": 0},
            {"name": "p", "kind": "proj", "arity": 1, "index": True},
            {"name": "p", "kind": "proj", "arity": True, "index": 0},
            {"name": "f", "kind": "comp", "arity": 1, "outer": "f", "inners": ["id"]},
            {"name": "f", "kind": "comp", "arity": 0, "outer": "S", "inners": ["id"]},
            {"name": "r", "kind": "rec", "arity": 1, "base": "id", "step": "id"},
            {"name": "r", "kind": "rec", "arity": 1, "base": "0", "step": "r"},
        ]
        for declaration in invalid:
            self.rejects(packet(H(), [declaration]))

    def test_capture_avoiding_substitution(self):
        motive = ["D", "x", "y", E(V("v"), V("x"))]
        result = kernel.subst_formula(motive, {"v": V("x")})
        expected = ["D", "a", "b", E(V("x"), V("a"))]
        captured = ["D", "x", "y", E(V("x"), V("x"))]
        self.assertTrue(kernel.alpha_equal(result, expected))
        self.assertFalse(kernel.alpha_equal(result, captured))
        self.assertEqual(kernel.fv_formula(result), {"x"})
        simultaneous = kernel.subst_formula(E(V("x"), V("y")), {"x": V("y"), "y": Z})
        self.assertEqual(simultaneous, E(V("y"), Z))
        witness_collision = kernel.subst_formula(E(V("x"), V("y")),
                                                {"x": V("y"), "y": S(V("z"))})
        self.assertEqual(witness_collision, E(V("y"), S(V("z"))))

    def test_nested_shadowing_alpha_equivalence(self):
        first = ["D", "x", "y", ["D", "x", "z", E(V("x"), V("y"))]]
        same = ["D", "a", "b", ["D", "c", "d", E(V("c"), V("b"))]]
        different = ["D", "a", "b", ["D", "c", "d", E(V("a"), V("b"))]]
        self.assertTrue(kernel.alpha_equal(first, same))
        self.assertFalse(kernel.alpha_equal(first, different))

    def test_scope_and_schema_rejections(self):
        item = induction_packet()
        damaged = copy.deepcopy(item)
        damaged["goal"] = E(V("outside"), Z)
        self.rejects(damaged)
        damaged = copy.deepcopy(item)
        damaged["proof"]["major"]["witness"] = V("n")
        self.rejects(damaged)
        damaged = copy.deepcopy(item)
        damaged["proof"]["premise"]["term"] = V("future")
        self.rejects(damaged)
        damaged = copy.deepcopy(item)
        damaged["proof"]["premise"]["clause"] = True
        self.rejects(damaged)
        damaged = packet(comp(Z, Z))
        self.rejects(damaged)
        damaged = packet(H())
        damaged["proof"]["extra"] = 0
        self.rejects(damaged)

    def test_eigenvariable_freshness(self):
        body = E(V("y"), V("y"))
        proof = {"rule": "di", "conclusion": ["D", "x", "y", body],
                 "witness": Z, "eigen": "n", "premise": refl(S(V("n")))}
        kernel.Checker([]).check(proof)
        with self.assertRaises(kernel.ProofError):
            kernel.Checker([]).check(proof, scope={"n"})

    def test_no_compound_induction_hypothesis(self):
        inner = ["D", "a", "b", E(Z, Z)]
        bad_use = {"rule": "use", "conclusion": inner,
                   "clause": 1, "term": Z, "premise": H()}
        proof = {"rule": "di", "conclusion": ["D", "x", "y", inner],
                 "witness": Z, "eigen": "n", "premise": bad_use}
        self.rejects(packet(proof))

    def test_retained_false_base_does_not_leak(self):
        false = E(Z, S(Z))
        use = {"rule": "use", "conclusion": false,
               "clause": 0, "term": Z, "premise": H()}
        major = {"rule": "di", "conclusion": ["D", "x", "y", false],
                 "witness": Z, "eigen": "n", "premise": use}
        kernel.check_packet(packet(major))
        leak = {"rule": "de", "conclusion": false, "major": major,
                "eigen": "a", "premise": use}
        self.rejects(packet(leak))

    def test_json_boundary(self):
        for text in ('{"x":0,"x":1}', '{"x":NaN}', '{"x":Infinity}', '{"x":-Infinity}'):
            with self.assertRaises(kernel.ProofError):
                kernel.load_packet(io.StringIO(text))
        for value in (None, [], 0, True, "packet"):
            self.rejects(value)

    def test_public_cli_in_normal_and_optimized_python(self):
        script = Path(kernel.__file__).resolve()
        good = json.dumps(induction_packet())
        bad = json.dumps(packet(comp(Z, S(Z))))
        for optimization in ([], ["-O"]):
            for text, code, verdict in ((good, 0, "ACCEPT"), (bad, 1, "REJECT")):
                result = subprocess.run([sys.executable, *optimization, str(script)],
                                        input=text, text=True, capture_output=True, check=False)
                self.assertEqual((result.returncode, result.stdout.strip()), (code, verdict))


if __name__ == "__main__":
    unittest.main(verbosity=2)
