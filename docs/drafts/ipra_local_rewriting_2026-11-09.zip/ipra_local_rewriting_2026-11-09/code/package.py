"""Create a manifest-verified, fixed-timestamp archive of this research package."""
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED_SUFFIXES = {".aux", ".log", ".out", ".toc", ".pyc", ".synctex.gz"}


def included(path):
    relative = path.relative_to(ROOT)
    return (path.is_file() and "__pycache__" not in relative.parts
            and path.suffix not in EXCLUDED_SUFFIXES
            and path.name != "MANIFEST.json")


def main():
    files = sorted(path for path in ROOT.rglob("*") if included(path))
    manifest = {"format": 1, "root": ROOT.name,
                "files": [{"path": str(path.relative_to(ROOT)),
                           "bytes": path.stat().st_size,
                           "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
                          for path in files]}
    manifest_path = ROOT / "MANIFEST.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    files.append(manifest_path)
    destination = ROOT.parent / "deliverables"
    destination.mkdir(exist_ok=True)
    archive = destination / (ROOT.name + ".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as stream:
        for path in sorted(files):
            info = zipfile.ZipInfo(str(Path(ROOT.name) / path.relative_to(ROOT)),
                                   date_time=(2026, 11, 9, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            stream.writestr(info, path.read_bytes())
    with zipfile.ZipFile(archive) as stream:
        if stream.testzip() is not None:
            raise RuntimeError("Archive CRC failure")
        loaded = json.loads(stream.read(str(Path(ROOT.name) / "MANIFEST.json")))
        for entry in loaded["files"]:
            data = stream.read(str(Path(ROOT.name) / entry["path"]))
            if len(data) != entry["bytes"] or hashlib.sha256(data).hexdigest() != entry["sha256"]:
                raise RuntimeError("Archived payload does not match manifest")
    pdf = destination / (ROOT.name + ".pdf")
    tex = destination / (ROOT.name + ".tex")
    shutil.copyfile(ROOT / "report.pdf", pdf)
    shutil.copyfile(ROOT / "ipra_local_rewriting_standalone.tex", tex)
    print(json.dumps({"archive": str(archive), "archive_bytes": archive.stat().st_size,
                      "archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
                      "payload_files": len(files), "crc_and_hashes_verified": True,
                      "pdf": str(pdf), "standalone_tex": str(tex)}, indent=2))


if __name__ == "__main__":
    main()
