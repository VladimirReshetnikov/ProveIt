"""Adversarial valid scope examples for the untrusted normalizer.

These exercise alpha-renaming obligations independently of the producer's
ordinary example generator.  Every source, intermediate, and output proof
is checked by the standalone kernel.
"""

import json

import local_checker as L
import producer as P


Z = ["0"]


def V(name):
    return ["$", name]


def E(left, right):
    return ["=", left, right]


def refl(term):
    proof = P.comp(["id", term], term)
    return {"rule": "rw", "conclusion": E(term, term), "source": proof,
            "before": proof, "orientation": 0, "side": 0, "path": []}


def packet(proof):
    return {"declarations": [], "goal": proof["conclusion"], "proof": proof}


def endpoint_binder_collision():
    endpoint = ["S", V("y")]
    old = ["id", endpoint]
    motive = ["D", "y", "b", E(V("v"), V("y"))]
    before = {"rule": "di", "conclusion": L.subst_formula(motive, {"v": old}),
              "witness": old, "eigen": "z", "premise": refl(old)}
    step = P.tr(P.comp(old, endpoint), before, "v", motive)
    goal = ["D", "u", "w", ["D", "a", "b", E(V("w"), V("a"))]]
    return packet({"rule": "di", "conclusion": goal,
                   "witness": Z, "eigen": "y", "premise": step})


def witness_counter_collision():
    inner = ["D", "x", "y", E(V("x"), V("x"))]
    step = {"rule": "di", "conclusion": inner,
            "witness": V("y"), "eigen": "z", "premise": refl(V("y"))}
    return packet({"rule": "di", "conclusion": ["D", "u", "w", inner],
                   "witness": Z, "eigen": "y", "premise": step})


def sibling_eigen_reuse():
    equation = E(["id", Z], Z)
    paired = {"rule": "di", "conclusion": ["D", "x", "y", equation],
              "witness": Z, "eigen": "z", "premise": P.h_proof()}
    equality = {
        "rule": "de", "conclusion": equation, "major": paired, "eigen": "a",
        "premise": {"rule": "use", "conclusion": equation, "clause": 0,
                    "term": Z, "premise": P.h_proof()},
    }
    motive = ["D", "c", "d", E(V("v"), V("v"))]
    old = ["id", Z]
    before = {"rule": "di", "conclusion": L.subst_formula(motive, {"v": old}),
              "witness": Z, "eigen": "z", "premise": refl(old)}
    return packet(P.tr(equality, before, "v", motive))


def main():
    results = []
    for label, build in (
            ("endpoint collides with motive binder", endpoint_binder_collision),
            ("witness collides with bound counter", witness_counter_collision),
            ("sibling eigenvariable spelling reused", sibling_eigen_reuse)):
        item = build()
        local, atomic, stats = P.normalize_packet(item)
        if not L.alpha_equal(local["goal"], item["goal"]):
            raise ValueError("scope test changed the concluding theorem")
        results.append({"case": label, **stats})
    print(json.dumps({"scope_cases": results, "passed": len(results)}, indent=2))


if __name__ == "__main__":
    main()
