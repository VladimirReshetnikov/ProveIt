"""Generate and independently check complete proof-normalization examples.

These are finite implementation checks of the full native proof grammar.
The general normalization theorem is proved in the accompanying manuscript.
"""
from __future__ import annotations

import copy
import json
import subprocess
import sys
from pathlib import Path

import local_checker as L
import producer as P


ROOT = Path(__file__).resolve().parents[1]


def packet(proof, declarations=None):
    return {"declarations": declarations or [], "goal": proof["conclusion"], "proof": proof}


def constant_paired_formula(endpoint, depth):
    result = P.eq(["id", endpoint], endpoint)
    for index in range(depth):
        result = ["D", f"cx{index}", f"cy{index}", result]
    return result


def computation_under_binders(formula, context, normalizer):
    if formula[0] == "=":
        return P.comp(formula[1], formula[2])
    z = normalizer.fresh.name("_cz")
    proof = {"rule": "di", "conclusion": formula, "witness": P.ZERO, "eigen": z}
    _, x, y, body = formula
    step = P.sub(body, {x: P.ZERO, y: P.succ(P.var(z))})
    proof["premise"] = computation_under_binders(step, P.di_context(proof, context), normalizer)
    return proof


DECLARATIONS = [
    {"name": "state", "kind": "proj", "arity": 2, "index": 1},
    {"name": "orbit", "kind": "rec", "arity": 1, "base": "0", "step": "state"},
]


def stationary_equality(counter, context, normalizer):
    """Prove orbit(counter)=0 through real DI/DE equation induction."""
    f = normalizer.fresh
    x, y, z, a = (f.name(prefix) for prefix in ("_ix", "_iy", "_iz", "_ia"))
    matrix = P.eq(["orbit", P.var(y)], P.ZERO)
    paired = ["D", x, y, matrix]
    major = {"rule": "di", "conclusion": paired, "witness": P.ZERO, "eigen": z}
    inside = P.di_context(major, context)
    rz = ["orbit", P.var(z)]
    rsz = ["orbit", P.succ(P.var(z))]
    unroll = P.comp(rsz, ["state", P.var(z), rz])
    project = P.comp(["state", P.var(z), rz], rz)
    v = f.name("_v")
    step = P.tr(project, unroll, v, P.eq(rsz, P.var(v)))
    induction = P.ordinary(inside, len(context) + 1)
    v = f.name("_v")
    major["premise"] = P.tr(induction, step, v, P.eq(rsz, P.var(v)))
    extended = list(context) + [P.opened(paired, a)]
    base = P.comp(["orbit", P.ZERO], P.ZERO)
    minor = P.use(extended, len(context), counter, base)
    return {"rule": "de", "conclusion": minor["conclusion"],
            "major": major, "eigen": a, "premise": minor}


def sources():
    examples = {}
    n = P.Normalizer("fixture")
    zero = P.ZERO
    idzero = ["id", zero]
    equality = P.comp(idzero, zero)

    examples["reflexivity"] = packet(n.reflexivity(zero))

    v = n.fresh.name("_v")
    motive = P.eq(["id", P.var(v)], ["id", P.var(v)])
    before = n.reflexivity(["id", idzero])
    examples["repeated_occurrences"] = packet(P.tr(equality, before, v, motive))

    v = n.fresh.name("_v")
    inner = P.tr(equality, P.comp(["id", idzero], idzero), v,
                 P.eq(["id", P.var(v)], P.var(v)))
    v = n.fresh.name("_v")
    examples["derived_atomic_source"] = packet(
        P.tr(inner, equality, v, P.eq(P.var(v), zero)))

    for depth in (1, 2, 3):
        v = n.fresh.name("_v")
        motive = constant_paired_formula(P.var(v), depth)
        before = computation_under_binders(P.sub(motive, {v: idzero}), [], n)
        examples[f"compound_depth_{depth}"] = packet(P.tr(equality, before, v, motive))

    x, y, z = (n.fresh.name(prefix) for prefix in ("_ox", "_oy", "_oz"))
    body = P.eq(["id", ["orbit", P.var(y)]], zero)
    goal = ["D", x, y, body]
    proof = {"rule": "di", "conclusion": goal, "witness": zero, "eigen": z}
    inside = P.di_context(proof, [])
    counter = P.succ(P.var(z))
    induction_equation = stationary_equality(counter, inside, n)
    before = P.comp(["id", ["orbit", counter]], ["orbit", counter])
    v = n.fresh.name("_v")
    proof["premise"] = P.tr(induction_equation, before, v,
                             P.eq(["id", ["orbit", counter]], P.var(v)))
    examples["induction_continuation"] = packet(proof, DECLARATIONS)

    induction_equation = stationary_equality(P.succ(zero), [], n)
    v = n.fresh.name("_v")
    motive = constant_paired_formula(P.var(v), 2)
    before = computation_under_binders(
        P.sub(motive, {v: ["orbit", P.succ(zero)]}), [], n)
    examples["compound_induction_source"] = packet(
        P.tr(induction_equation, before, v, motive), DECLARATIONS)

    # Input with primitive RW is expanded to atomic transport and normalized
    # back; this exercises every constructor in the admitted source calculus.
    examples["local_input_roundtrip"] = packet({
        "rule": "rw", "conclusion": P.eq(zero, zero),
        "before": equality, "source": equality,
        "orientation": 0, "side": 0, "path": [],
    })
    return examples


def walk(proof):
    yield proof
    for key in ("premise", "major", "equality", "before", "source"):
        if key in proof:
            yield from walk(proof[key])


def must_reject(item, mode="local"):
    try:
        L.check_packet(item, mode=mode)
    except L.ProofError:
        return
    raise RuntimeError("Negative control was accepted")


def run():
    reference_dir = ROOT / "examples" / "reference"
    atomic_dir = ROOT / "examples" / "atomic"
    local_dir = ROOT / "examples" / "local"
    for directory in (reference_dir, atomic_dir, local_dir, ROOT / "evidence"):
        directory.mkdir(parents=True, exist_ok=True)
    receipts = {}
    outputs = {}
    for title, source in sources().items():
        local, atomic, stats = P.normalize_packet(source)
        if any(node["rule"] == "tr" for node in walk(local["proof"])):
            raise RuntimeError("General transport survived in local output")
        if any(node["rule"] == "tr" and node["motive"][0] != "="
               for node in walk(atomic["proof"])):
            raise RuntimeError("Compound transport survived atomic normalization")
        for directory, item in ((reference_dir, source), (atomic_dir, atomic), (local_dir, local)):
            (directory / (title + ".json")).write_text(json.dumps(item, indent=2) + "\n")
        receipts[title] = stats
        outputs[title] = local

    controls = 0
    source = sources()["compound_depth_2"]
    must_reject(source)
    controls += 1
    must_reject(source, mode="atomic")
    controls += 1

    for field, replacement in (("orientation", 1), ("path", [999]), ("side", 1)):
        changed = copy.deepcopy(outputs["reflexivity"])
        node = next(node for node in walk(changed["proof"]) if node["rule"] == "rw")
        node[field] = replacement
        must_reject(changed)
        controls += 1

    changed = copy.deepcopy(outputs["induction_continuation"])
    node = next(node for node in walk(changed["proof"]) if node["rule"] == "use")
    node["clause"] = 999999
    must_reject(changed)
    controls += 1

    # A local source must be neutral even if the supplied nonneutral proof
    # independently proves exactly the same equation.
    changed = copy.deepcopy(outputs["reflexivity"])
    rewrite = next(node for node in walk(changed["proof"]) if node["rule"] == "rw")
    simple = copy.deepcopy(rewrite["source"])
    e = simple["conclusion"]
    paired = ["D", "source_x", "source_y", e]
    derived = {
        "rule": "de", "conclusion": e, "eigen": "source_a",
        "major": {"rule": "di", "conclusion": paired, "witness": P.ZERO,
                  "eigen": "source_z", "premise": copy.deepcopy(simple)},
        "premise": copy.deepcopy(simple),
    }
    L.check_packet(packet(derived))
    rewrite["source"] = derived
    must_reject(changed)
    controls += 1

    cli_runs = 0
    checker = str(ROOT / "code" / "local_checker.py")
    for title in ("compound_depth_3", "compound_induction_source"):
        encoded = json.dumps(outputs[title])
        for optimized in (False, True):
            command = [sys.executable, *(["-O"] if optimized else []), checker]
            result = subprocess.run(command, input=encoded, text=True, capture_output=True, check=False)
            if result.returncode != 0 or result.stdout.strip() != "ACCEPT":
                raise RuntimeError(f"Public local checker failed: {title}, optimized={optimized}")
            cli_runs += 1

    result = {"examples": receipts, "negative_controls": controls,
              "public_cli_runs": cli_runs, "python": sys.version,
              "scope": "Full native proof examples; not a machine proof of the general metatheorem."}
    (ROOT / "evidence" / "normalization_results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return result


if __name__ == "__main__":
    run()
