"""Targeted arbitrary-context and weakening test for the full normalizer."""
import copy
import json
from pathlib import Path

import local_checker as L
import producer as P
from test import computation_under_binders, constant_paired_formula


def run():
    antecedent = ["D", "a", "b", P.eq(P.ZERO, P.ZERO)]
    context = [(antecedent, "k", P.eq(["id", P.var("k")], P.var("k")))]
    # The clause source has a compound antecedent. Its proof actually uses
    # a local DI assumption at index len(context), so weakening must shift
    # that index while preserving the outer clause's index zero.
    a_proof = {"rule": "di", "conclusion": antecedent,
               "witness": P.ZERO, "eigen": "inner"}
    inside = P.di_context(a_proof, context)
    a_proof["premise"] = P.ordinary(inside, len(context))
    equality = P.use(context, 0, P.ZERO, a_proof)
    n = P.Normalizer(context, equality)
    v = n.fresh.name("_v")
    motive = constant_paired_formula(P.var(v), 2)
    before = computation_under_binders(
        P.sub(motive, {v: ["id", P.ZERO]}), context, n)
    source = P.tr(equality, before, v, motive)

    source_stats = L.Checker([], "general").check(source, context)
    n = P.Normalizer(context, source)
    atomic = n.atomic(n.freshen(source), context)
    atomic_stats = L.Checker([], "atomic").check(atomic, context, expected=source["conclusion"])
    local = n.local(atomic, context)
    local_stats = L.Checker([], "local").check(local, context, expected=source["conclusion"])

    # Exercise the public producer's weakening primitive at a nonzero
    # boundary, adding unrelated retained clauses and checking the result.
    additional = [L.hypothesis(P.eq(P.ZERO, P.ZERO)), L.hypothesis(antecedent)]
    weakened = n.weaken(local, len(context), len(additional))
    weakened_stats = L.Checker([], "local").check(
        weakened, context + additional, expected=source["conclusion"])

    # A wrong global index must not silently select the first new local
    # assumption when the old outer clause index should stay unchanged.
    damaged = copy.deepcopy(weakened)

    def mutate(node):
        if node["rule"] == "use" and node["clause"] == 0:
            node["clause"] = 1
            return True
        for key in ("premise", "major", "before", "source"):
            if key in node and mutate(node[key]):
                return True
        return False

    if not mutate(damaged):
        raise RuntimeError("Context test did not exercise the retained source clause")
    try:
        L.Checker([], "local").check(damaged, context + additional,
                                    expected=source["conclusion"])
    except L.ProofError:
        pass
    else:
        raise RuntimeError("Incorrectly shifted outer clause index was accepted")

    receipt = {"source": source_stats, "atomic": atomic_stats,
               "local": local_stats, "weakened": weakened_stats,
               "negative_controls": 1,
               "scope": "Arbitrary retained mixed-shape clause, checked antecedent, nonzero weakening boundary."}
    root = Path(__file__).resolve().parents[1]
    (root / "evidence").mkdir(exist_ok=True)
    (root / "evidence" / "context_normalization_results.json").write_text(
        json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))
    return receipt


if __name__ == "__main__":
    run()
