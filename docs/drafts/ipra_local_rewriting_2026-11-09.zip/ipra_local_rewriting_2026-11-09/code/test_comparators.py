"""Small common-language regression check of five frozen native comparators.

The cases use the documented inherited array/integer syntax.  They are not
the new tagged local-calculus packets and are not a translation of its
mathematical theorem.  The checks establish these finite public verdicts,
not full checker equivalence or a new metatheorem about the old calculus.
"""

import ast
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
H = [[0, 0, 0], 0]
CASES = [
    ("initialized zero-counter computation", [[0, 0], [[0, [0], 0], [0]]], True),
    ("successor-counter identity-update computation",
     [[0, 0], [[[0], [0], 1], [0, [0], 1]]], True),
    ("zero reflexivity derived by equality transport",
     [[0, 0], [0, 0], [H, [1, 0]], [0, 0]], True),
    ("false zero-successor equation", [[0, 0], [0, [0]]], False),
    ("false initialized computation", [[0, 0], [[0, 0, 0], [0]]], False),
    ("documented arity-four false-equation exploit",
     [[0, [0]], [[0, 0, [], [0]], 0], [[], [0]]], False),
    ("out-of-scope negative parameter", [[0, 0], [-1, 0]], False),
    ("string in formula position", [[0, 0], "not_a_formula"], False),
]


def main():
    manifest = json.loads((ROOT / "reference" / "checker_manifest.json").read_text())
    runs = []
    assertions = {}
    for entry in manifest:
        script = ROOT / "reference" / "checkers" / entry["filename"]
        raw = script.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        if digest != entry["sha256"]:
            raise ValueError("Changed comparator: " + entry["filename"])
        assertions[entry["filename"]] = sum(isinstance(node, ast.Assert)
                                            for node in ast.walk(ast.parse(raw)))
        for optimized in (False, True):
            command = [sys.executable, *(["-O"] if optimized else []), str(script)]
            for label, packet, expected in CASES:
                result = subprocess.run(command, input=json.dumps(packet), text=True,
                                        capture_output=True, timeout=20, check=False)
                actual = (result.returncode, result.stdout.strip())
                wanted = (0, "ACCEPT") if expected else (1, "REJECT")
                if actual != wanted:
                    raise ValueError(f"{entry['filename']}: {label}: {actual!r}, wanted {wanted!r}")
                runs.append({"checker": entry["filename"], "optimized": optimized,
                             "case": label, "expected_acceptance": expected,
                             "returncode": result.returncode, "verdict": result.stdout.strip()})
    output = {
        "python": platform.python_version(),
        "scope": "Finite canonical array/integer public verdicts only; no full equivalence claim.",
        "source_assertion_counts": assertions,
        "assertion_note": "The frozen sources contain no assert statements; all paired normal/-O verdicts agree.",
        "checkers": len(manifest), "cases_per_mode": len(CASES),
        "public_runs_passed": len(runs), "runs": runs,
    }
    destination = ROOT / "evidence" / "comparator_execution.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({key: value for key, value in output.items() if key != "runs"}, indent=2))


if __name__ == "__main__":
    main()
