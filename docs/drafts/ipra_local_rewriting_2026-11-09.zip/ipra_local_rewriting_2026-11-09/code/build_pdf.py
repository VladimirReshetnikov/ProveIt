"""Build the report and emit a self-contained TeX source (requires pdflatex)."""
import json
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def expanded(path, ancestors=()):
    path = path.resolve()
    if path in ancestors:
        raise RuntimeError("Recursive TeX input: " + str(path))
    content = path.read_text()
    def replace(match):
        child = ROOT / match.group(1)
        if child.suffix != ".tex":
            child = child.with_suffix(".tex")
        return ("\n% BEGIN retained input: " + match.group(1) + "\n"
                + expanded(child, (*ancestors, path))
                + "\n% END retained input: " + match.group(1) + "\n")
    return re.sub(r"\\input\{([^}]+)\}", replace, content)


def main():
    if not shutil.which("pdflatex"):
        raise SystemExit("Install a LaTeX distribution providing pdflatex before building.")
    if not (ROOT / "evidence" / "metrics_table.tex").exists():
        raise SystemExit("Run python3 code/reproduce.py first.")
    standalone = ROOT / "ipra_local_rewriting_standalone.tex"
    standalone.write_text(expanded(ROOT / "report.tex"))
    logs = ROOT / "evidence" / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    command = ["pdflatex", "-no-shell-escape", "-interaction=nonstopmode",
               "-halt-on-error", "report.tex"]
    receipt = {"command": command, "passes": []}
    for number in range(1, 4):
        process = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
        log = logs / ("pdflatex-pass-" + str(number) + ".txt")
        log.write_text(process.stdout + process.stderr)
        receipt["passes"].append({"pass": number, "exit_code": process.returncode,
                                  "log": str(log.relative_to(ROOT))})
        if process.returncode:
            raise SystemExit("LaTeX failed; see " + str(log))
    text = (ROOT / "report.log").read_text()
    receipt["warnings"] = [line for line in text.splitlines()
                           if "Warning" in line or "Overfull" in line]
    receipt["output"] = "report.pdf"
    (ROOT / "evidence" / "pdf_build.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print("Built report.pdf and ipra_local_rewriting_standalone.tex")
    for warning in receipt["warnings"]:
        print(warning)


if __name__ == "__main__":
    main()
