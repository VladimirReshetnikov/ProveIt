LOCAL EQUALITY FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
Research package prepared for Vladimir Reshetnikov, 9 November 2026
================================================================

STATUS: A PRECISE PARTIAL RESULT, NOT A NEW MINIMUM
------------------------------------------------
The requested strictly smaller complete checker and significant breakthrough
have NOT been established. The inspected repository already contains a
complete checker measuring 309 normalized Python tokens, 344 AST nodes,
and 864 normalized bytes. The readable checker supplied here measures
3287 / 3650 / 16192 under the same whole-source normalizer on CPython 3.12.14.
The corpus minimum is an empirical minimum, not a universal lower-bound
theorem. A uniform identifier renaming already gives an older comparator
816 bytes without improving its token or AST count.

The positive result is an exact simultaneous normal form: equality transport
may be restricted to literal equations, one numerical occurrence at a time,
using only a computation equation or a direct atomic local-clause use as
its source. The whole native consequence relation is preserved. The report
proves this by a two-stage, continuation-strengthened proof transformation.
The complete transformation is implemented, including the native induction
and paired-binder rules, and its outputs are checked.

The report gives an explicit complete local calculus over the full staged
primitive-recursive description language. It reconstructs every ordinary
intuitionistic logical rule and both formula/context round trips. Its
faithful ordinary realization is bi-interpretable and equiconsistent with
full iPRA on the entire numerical domain, with actual equality. The ordinary
realization explicitly includes the bridge (0=S0)->bottom; the native
calculus designates 0=S0 as its contradiction. The positive-equation
singleton model is not silently claimed to be excluded.

The arithmetic completion uses an attributed, unchanged proof from the
supplied rotation draft. The new claims are separated from that inherited
work. Additional results include one-premise folding of successor uniqueness
and full-domain parity reconstruction. A further theorem proves signed
rotation for every fixed standard seed with an arbitrary counter, and for
every fixed standard counter with an arbitrary seed. A possible classical
counterexample must therefore have both parameters nonstandard. These
per-numeral theorems do not settle the uniform rotation principle or improve
the complete checker frontier.

START HERE
----------
report.pdf                             Complete research report.
report.tex                             Modular main LaTeX source.
ipra_local_rewriting_standalone.tex     Complete single-file TeX source.
sections/                              Source sections for the modular report.
code/FORMAT.txt                        Exact certificate and rule grammar.
code/local_checker.py                  Standalone acceptance algorithm.
code/producer.py                       Untrusted two-stage proof normalizer.
examples/reference/                    General-transport source certificates.
examples/atomic/                       Checked intermediate certificates.
examples/local/                        Checked final local certificates.
evidence/                              Executed results and measured costs.
reviews/                               Separate mathematical/code review notes.
reference/                             Unchanged comparison sources and proof.
ATTRIBUTION.txt                        Provenance and contribution boundaries.
MANIFEST.json                          SHA-256 identities of packaged payloads.

The PDF contains the full mathematical argument, including the retained
arithmetic appendix. No internet access is required to read the package,
run the checker, replay the examples, or reproduce the source measurements.

RUN THE COMPLETE LOCAL CHECKER
------------------------------
Use Python 3.12 (the tested version is CPython 3.12.14) and its standard
library. Run commands from this package's root directory:

  python3 code/local_checker.py < examples/local/compound_depth_3.json

Expected output: ACCEPT, exit status 0.
An invalid public packet prints REJECT and exits 1. The public interface
is fixed to the local calculus. Certificate data cannot enable a general
transport mode. The public root goal must be closed and its context empty.
The Python API separately accepts explicit open contexts/scopes and exposes
the general/atomic reference modes needed for compiler validation.

The checker imports only json. It does not import the producer, tests,
examples, another checker, theorem database, dynamic interpreter, or
compressed payload. Its whole source, including the reference branches,
parser and rejection interface, is included in the measured cost.

The recursive algorithm implements the full stated syntax and inference
inventory. Finite machine resources and Python's recursion limit can reject
valid very large certificates; "complete" is not a claim to unlimited
execution resources. No arbitrary primitive-recursive numerical evaluation
is performed: a computation proof node unfolds exactly one defining equation.

NORMALIZE A GENERAL PROOF
------------------------
  python3 code/producer.py examples/reference/compound_depth_3.json \
    /tmp/ipra-local.json --atomic-output /tmp/ipra-atomic.json
  python3 code/local_checker.py < /tmp/ipra-local.json

The producer validates the source, atomic intermediate, and local output.
It has no role in accepting a previously supplied local certificate.
The source and target formats share syntax helpers, so the replay is not
an independent second implementation of capture avoidance.

REPRODUCE THE FINITE CHECKS AND WHOLE-SOURCE METRICS
-------------------------------------------------
  python3 code/reproduce.py

This runs six scripts:
  test.py                    Nine complete native examples; seven rejection
                             controls; four public normal/optimized runs.
  test_kernel_boundaries.py  Fourteen boundary-test groups, including actual
                             induction, scope, capture and parser behavior.
  test_compiler_scopes.py    Three independently designed name-collision cases.
  test_context_normalization.py
                             An open-context proof and nonzero-boundary
                             weakening with a deliberately wrong-index control.
  test_comparators.py        Eight valid/false/malformed cases for all five
                             inherited checkers, normal and optimized: 80 runs.
  measure.py                 Frozen-source integrity checks and whole-file
                             metrics, plus the inherited short-name control.

The scripts write exact receipts and logs under evidence/. They exercise
the full native proof grammar, not merely a free-algebra fragment. They
are finite validation, not a proof of universal soundness/completeness.
The metatheory is proved in the manuscript, not formalized in Lean or Rocq.

Representative proof-node counts (general -> atomic -> local):
  compound_depth_3:          6 -> 103 -> 167
  induction_continuation:   13 ->  13 ->  13
  compound_induction_source:14 ->  78 -> 146
  additional open context:  8 ->  54 ->  90
No global polynomial normalization-size bound is claimed.

BUILD THE PDF AND STANDALONE TEX
-------------------------------
Install a LaTeX distribution with pdflatex and the packages listed in
report.tex, then run:

  python3 code/build_pdf.py

The script expands all input files into ipra_local_rewriting_standalone.tex
and compiles report.tex three times with shell escape disabled. The already
built PDF is included. Code reproduction does not require LaTeX.

SOURCE SNAPSHOT AND MEANING OF THE COMPARISON
-------------------------------------------
The eleven archives at docs/drafts were pinned to this repository commit:
  e707d8bd1bcbc036631663e7538efd8b42b1e130
  https://github.com/VladimirReshetnikov/ProveIt/tree/e707d8bd1bcbc036631663e7538efd8b42b1e130/docs/drafts

Each retrieved archive was checked against its listed byte length and Git
blob SHA-1, then recorded with SHA-256 and an immutable URL. The snapshot
record is evidence/source_snapshot.json. All five complete comparator files
and the inherited source normalizer are retained unchanged and hash checked.
The new checker uses a transparent full PR numerical grammar; the inherited
small checkers use their native scalar grammar. They are not claimed to
accept identical raw JSON inputs. The proof theorem compares two precisely
specified calculi over the SAME full PR signature.

DO NOT READ MORE INTO THE RESULT
-------------------------------
This package does not prove an absolute simplest axiomatization, establish
literature-wide priority, beat the 309-token checker, supply a proofassistant
formalization, or settle whether successor uniqueness alone removes signed
rotation. It gives an exact presentation theorem, an executable realization,
and a carefully delimited partial advance toward the requested goal.
