#!/usr/bin/env python3
"""Bounded natural-number diagnostics, not proofs of the axiomatization.

Small cases evaluate the displayed iterators directly.  Pair decoding and
scalar-state tests use exact arithmetic acceleration of the half/parity
operations and the fixed/affine tails of u and w.  Those accelerations are
compared with literal iteration on bounded inputs.  No numerical test here
establishes induction, consistency, or adequacy on nonstandard models.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter
from functools import lru_cache
from pathlib import Path
from typing import Callable

Unary = Callable[[int], int]


def iterate(body: Unary, count: int, seed: int) -> int:
    if count < 0 or seed < 0:
        raise ValueError("The diagnostic domain is the natural numbers.")
    if count > 100_000:
        raise ValueError("Literal iteration exceeds the diagnostic limit.")
    value = seed
    for _ in range(count):
        value = body(value)
    return value


def successor(value: int) -> int:
    return value + 1


def predecessor(value: int) -> int:
    return max(value - 1, 0)


def delayed(body: Unary, count: int, seed: int) -> int:
    return iterate(body, predecessor(count), seed)


def ordinary(body: Unary, count: int, seed: int) -> int:
    return delayed(body, successor(count), seed)


def q(count: int, seed: int) -> int:
    return delayed(lambda _: 1, count, seed)


# Closed arithmetic forms, checked against literal source iterations below.
def difference(left: int, right: int) -> int:
    return max(left - right, 0)


def zero_selector(test: int, value: int) -> int:
    return value if test == 0 else 0


def selector(test: int, when_zero: int, when_positive: int) -> int:
    return zero_selector(test, when_zero) + zero_selector(
        zero_selector(test, 1), when_positive
    )


def cycle_body(value: int) -> int:
    return selector(predecessor(value), successor(value), 0)


@lru_cache(maxsize=None)
def cycle_literal(count: int) -> int:
    return ordinary(cycle_body, count, 0)


def bump(value: int) -> int:
    return zero_selector(predecessor(value), value)


def growth_body_literal(value: int) -> int:
    return successor(value) + bump(cycle_literal(value))


@lru_cache(maxsize=None)
def growth_literal(count: int) -> int:
    return ordinary(growth_body_literal, count, 0)


def parity_literal(value: int) -> int:
    return cycle_literal(growth_literal(value))


def half_literal(value: int) -> int:
    return difference(growth_literal(value), value)


def half(value: int) -> int:
    return value // 2


def parity(value: int) -> int:
    return value % 2


def strip_body(value: int) -> int:
    return selector(parity(value), half(value), value)


def count_body(value: int) -> int:
    return selector(parity(value), half(value), value + 2)


def accelerated_tail(value: int, count: int, add_on_odd: bool) -> int:
    """Exact u/w iteration: strip even factors, then collapse the odd tail."""
    while count and value and parity(value) == 0:
        value = half(value)
        count -= 1
    if value and add_on_odd:
        return value + 2 * count
    return value


def U(value: int) -> int:
    return accelerated_tail(value, value, False)


def W(value: int) -> int:
    return accelerated_tail(value, value, True)


def J(left: int, right: int) -> int:
    # E(left, S(V(right))) = repeated doubling of the odd seed.
    return (2 * right + 1) << left


def L(value: int) -> int:
    return difference(value, half(difference(W(value), U(value))))


def R(value: int) -> int:
    return half(U(value))


def encode(parameters: tuple[int, ...]) -> int:
    code = 0
    for value in reversed(parameters):
        code = J(value, code)
    return code


def decode(code: int, arity: int) -> tuple[int, ...]:
    result = []
    for _ in range(arity):
        result.append(L(code))
        code = R(code)
    return tuple(result)


def compiler_run(count, parameters, base, step, check):
    """Evaluate the report's scalar-state translation of one PR description.

    The update reads counter/parameter code/value from its sole state input.
    The Python closure retains only the fixed arity and earlier step function,
    not the numerical parameter values supplied to this run.
    """
    arity = len(parameters)
    parameter_code = encode(parameters)
    state = J(0, J(parameter_code, base(parameters)))

    def update(encoded_state):
        counter = L(encoded_state)
        inner = R(encoded_state)
        frozen_code = L(inner)
        old_value = R(inner)
        old_parameters = decode(frozen_code, arity)
        new_value = step(counter, old_parameters, old_value)
        return J(counter + 1, J(frozen_code, new_value))

    largest_bits = state.bit_length()
    for counter in range(count + 1):
        check("compiler_counter", L(state) == counter)
        check("compiler_parameter_code", L(R(state)) == parameter_code)
        check("compiler_parameter_tuple", decode(L(R(state)), arity) == parameters)
        if counter < count:
            state = update(state)
            largest_bits = max(largest_bits, state.bit_length())
    return R(R(state)), largest_bits


def run_checks(bound: int = 6) -> dict:
    if not 1 <= bound <= 10:
        raise ValueError("Choose a bound from 1 to 10.")
    counts = Counter()

    def check(category, condition):
        if not condition:
            raise AssertionError(f"Diagnostic failed in {category}")
        counts[category] += 1

    bodies = {
        "zero": lambda _: 0,
        "one": lambda _: 1,
        "identity": lambda value: value,
        "successor": successor,
        "predecessor": predecessor,
        "toggle": lambda value: zero_selector(value, 1),
        "double": lambda value: 2 * value,
    }
    for body in bodies.values():
        for seed in range(bound + 1):
            check("delayed_zero_seed", delayed(body, 0, seed) == seed)
            check("delayed_one_seed", delayed(body, 1, seed) == seed)
            for count in range(bound + 1):
                check("reset", delayed(body, q(count, 0), seed) == seed)
                check("tail", delayed(body, count + 2, seed)
                      == body(delayed(body, count + 1, seed)))
                check("ordinary_bridge", ordinary(body, count, seed)
                      == iterate(body, count, seed))

    for x in range(bound + 1):
        check("predecessor_definition", delayed(successor, x, 0) == predecessor(x))
        for y in range(bound + 1):
            check("addition_definition", ordinary(successor, y, x) == x + y)
            check("difference_definition", ordinary(predecessor, y, x) == difference(x, y))
            check("zero_selector_definition", ordinary(lambda _: 0, x, y)
                  == zero_selector(x, y))
            check("residual", selector(difference(y, x), y, x + difference(y, x)) == y)
            check("unit_difference", (difference(x + 1, y) == 1) == (x == y))
            for z in range(bound + 1):
                check("selector_cases", selector(x, y, z) == (y if x == 0 else z))

    half_bound = 4 * bound + 3
    for n in range(half_bound + 1):
        check("three_cycle", cycle_literal(n) == n % 3)
        check("growth_closed_form", growth_literal(n) == 3 * (n // 2) + n % 2)
        check("halving", half_literal(n) == half(n))
        check("parity", parity_literal(n) == parity(n))
        check("half_reconstruction", 2 * half_literal(n) + parity_literal(n) == n)
        check("half_two_step", half_literal(n + 2) == half_literal(n) + 1)
        check("parity_two_step", parity_literal(n + 2) == parity_literal(n))
        for k in range(bound + 1):
            check("accelerated_u", accelerated_tail(n, k, False)
                  == iterate(strip_body, k, n))
            check("accelerated_w", accelerated_tail(n, k, True)
                  == iterate(count_body, k, n))

    max_pair_code = 0
    for x in range(bound + 1):
        for y in range(bound + 1):
            code = J(x, y)
            max_pair_code = max(max_pair_code, code)
            check("pair_definition", code == ordinary(lambda value: 2 * value, x, 2 * y + 1))
            check("pair_u_literal", U(code) == iterate(strip_body, code, code))
            check("pair_w_literal", W(code) == iterate(count_body, code, code))
            check("pair_left", L(code) == x)
            check("pair_right", R(code) == y)

    examples = [
        ("addition", lambda p: p[0], lambda _n, _p, value: value + 1,
         lambda n, p: n + p[0]),
        ("multiplication", lambda _p: 0, lambda _n, p, value: value + p[0],
         lambda n, p: n * p[0]),
        ("counter_and_parameter_sum", lambda _p: 0,
         lambda n, p, value: value + n + p[0],
         lambda n, p: n * p[0] + n * (n - 1) // 2),
    ]
    max_state_bits = 0
    compiler_cases = 0
    for name, base, step, expected in examples:
        for parameter in range(3):
            for n in range(bound + 1):
                parameters = (parameter,)
                actual, bits = compiler_run(n, parameters, base, step, check)
                check("compiler_output_" + name, actual == expected(n, parameters))
                max_state_bits = max(max_state_bits, bits)
                compiler_cases += 1

    # A genuine two-parameter run checks repeated parameter decoding.
    for a in range(3):
        for b in range(3):
            for n in range(bound + 1):
                actual, bits = compiler_run(
                    n, (a, b), lambda p: p[1], lambda _n, p, value: value + p[0], check
                )
                check("compiler_output_two_parameters", actual == b + n * a)
                max_state_bits = max(max_state_bits, bits)
                compiler_cases += 1

    # The empty tuple exercises the zero-parameter branch of the construction.
    for n in range(bound + 1):
        actual, bits = compiler_run(
            n, (), lambda _p: 0, lambda counter, _p, value: value + counter, check
        )
        check("compiler_output_no_parameters", actual == n * (n - 1) // 2)
        max_state_bits = max(max_state_bits, bits)
        compiler_cases += 1

    return {
        "status": "passed",
        "scope": "bounded standard-natural-number diagnostics only; not a proof",
        "bound": bound,
        "halving_parity_bound": half_bound,
        "representative_delayed_bodies": list(bodies),
        "counts": dict(sorted(counts.items())),
        "total_assertions": sum(counts.values()),
        "pair_cases": (bound + 1) ** 2,
        "largest_pair_code_compared_with_literal_iteration": max_pair_code,
        "compiler_cases": compiler_cases,
        "largest_compiler_state_bit_length": max_state_bits,
        "acceleration": [
            "closed addition/monus/zero-selection compared with literal primitive iterations",
            "half/parity closed arithmetic forms compared with displayed three-cycle construction",
            "u/w even stripping followed by fixed or affine odd tail, compared with literal loops",
            "large scalar states use accelerated decoders; no huge state-sized loop is executed",
        ],
        "not_verified": [
            "the axiom schema on all inputs", "induction strength", "nonstandard models",
            "consistency", "arbitrary PR-description syntax", "bi-interpretability",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bound", type=int, default=6, help="finite range bound, 1 to 10")
    parser.add_argument("--output", type=Path, help="optional JSON receipt")
    args = parser.parse_args()
    result = json.dumps(run_checks(args.bound), indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(result, encoding="utf-8")
    print(result, end="")


if __name__ == "__main__":
    main()
