#!/usr/bin/env python3
"""Reproduce syntax counts for two proposed PRA presentation changes.

This checks finite syntax and substitution, not arithmetic, consistency,
nonstandard models, or bi-interpretability. It uses Python's standard library.
Count one node per variable, constant, active application, equality,
connective, or quantifier. Negation and biconditional are expanded.
Stored descriptor bodies are frozen syntax, not active arguments.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Node:
    tag: str
    args: tuple["Node", ...] = ()
    name: str = ""


def var(name):
    return Node("var", name=name)


ZERO = Node("zero")
BOTTOM = Node("bottom")


def app(name, *args):
    return Node("app", tuple(args), name)


def succ(term):
    return app("S", term)


ONE = succ(ZERO)


def eq(left, right):
    return Node("eq", (left, right))


def connective(tag, left, right):
    return Node(tag, (left, right))


def forall(name, body):
    return Node("forall", (body,), name)


def iff(left, right):
    return connective("and", connective("imp", left, right),
                      connective("imp", right, left))


def size(node):
    return 1 + sum(map(size, node.args))


def free_vars(node):
    if node.tag == "var":
        return {node.name}
    result = set().union(*(free_vars(arg) for arg in node.args))
    if node.tag == "forall":
        result.discard(node.name)
    return result


def individual_names(node):
    result = set().union(*(individual_names(arg) for arg in node.args))
    if node.tag in {"var", "forall"}:
        result.add(node.name)
    return result


def quantifier_free(node):
    return node.tag != "forall" and all(map(quantifier_free, node.args))


def subst(node, name, replacement):
    """Free substitution; reject capture rather than silently rename binders."""
    if node.tag == "var":
        return replacement if node.name == name else node
    if node.tag == "forall":
        if node.name == name:
            return node
        if node.name in free_vars(replacement) and name in free_vars(node):
            raise ValueError("substitution would capture a variable")
    return Node(node.tag, tuple(subst(x, name, replacement) for x in node.args),
                node.name)


class Language:
    def __init__(self):
        self.descriptors = {}

    def check_term(self, term):
        if term.tag in {"zero", "var"}:
            if term.args:
                raise ValueError("leaf has children")
            return
        if term.tag != "app":
            raise ValueError("formula supplied as a term")
        arity = 1 if term.name == "S" else 2
        if term.name != "S" and term.name not in self.descriptors:
            raise ValueError("unknown, forward, or self-referential descriptor")
        if len(term.args) != arity:
            raise ValueError("wrong arity")
        for arg in term.args:
            self.check_term(arg)

    def declare(self, name, body):
        if name == "S" or name in self.descriptors:
            raise ValueError("duplicate symbol")
        if not free_vars(body) <= {"v"}:
            raise ValueError("descriptor has an external free parameter")
        self.check_term(body)  # Only earlier descriptors are visible here.
        self.descriptors[name] = body

    def check_matrix_term(self, term):
        self.check_term(term)
        if not free_vars(term) <= {"n", "a"}:
            raise ValueError("dynamic term has an extra free variable")

    def check_formula(self, formula):
        if formula.tag == "eq" and len(formula.args) == 2:
            for term in formula.args:
                self.check_term(term)
        elif formula.tag in {"and", "or", "imp"} and len(formula.args) == 2:
            for part in formula.args:
                self.check_formula(part)
        elif formula.tag == "forall" and len(formula.args) == 1:
            self.check_formula(formula.args[0])
        elif formula.tag == "bottom" and not formula.args:
            return
        else:
            raise ValueError("malformed formula")


N, A, V = map(var, ("n", "a", "v"))


def root(equation):
    return connective("or", eq(N, ZERO), equation)


def envelope(first, second):
    return forall("a", connective("imp",
        forall("n", connective("imp", first, second)), forall("n", first)))


def old_dynamic(left, right):
    matrix = root(eq(left, right))
    return envelope(matrix, subst(matrix, "n", succ(N)))


def new_dynamic(left, right):
    equation = eq(left, right)
    return envelope(root(equation), subst(equation, "n", succ(N)))


def computation_parts(language, name):
    separation = connective("imp", eq(ZERO, ONE), BOTTOM)
    reset = eq(app(name, app("D_one", N, ZERO), A), A)
    next_value = app(name, succ(N), A)
    tail = eq(app(name, succ(succ(N)), A),
              subst(language.descriptors[name], "v", next_value))
    return separation, reset, tail


def old_stationary(language, name):
    separation, reset, tail = computation_parts(language, name)
    return connective("and", separation,
                       forall("n", connective("and", reset, tail)))


def new_computation(language, name):
    separation, reset, tail = computation_parts(language, name)
    return connective("and", separation, connective("and", reset, tail))


def terms_up_to(language, maximum):
    by_size = {1: [ZERO, N, A]}
    for count in range(2, maximum + 1):
        result = [succ(t) for t in by_size[count - 1]]
        for left_size in range(1, count - 1):
            right_size = count - 1 - left_size
            for name in language.descriptors:
                result.extend(app(name, x, y) for x in by_size[left_size]
                              for y in by_size[right_size])
        by_size[count] = result
    return [term for count in by_size for term in by_size[count]]


def must_reject(action):
    try:
        action()
    except ValueError:
        return
    raise AssertionError("malformed input was accepted")


def check():
    language = Language()
    language.declare("D_id", V)
    language.declare("D_S", succ(V))
    language.declare("D_one", ONE)
    language.declare("D_p", app("D_S", V, ZERO))
    language.declare("D_repeat", app("D_S", V, V))
    language.declare("D_nested", app("D_p", app("D_one", V, ZERO), V))

    negative_controls = [
        lambda: language.declare("bad_free", app("D_S", V, A)),
        lambda: language.declare("bad_self", app("bad_self", V, ZERO)),
        lambda: language.declare("bad_forward", app("not_declared", V, ZERO)),
        lambda: language.declare("bad_arity", app("D_S", V)),
        lambda: language.declare("bad_formula", eq(V, ZERO)),
        lambda: language.check_matrix_term(app("D_S", N, var("b"))),
        lambda: subst(forall("a", eq(N, A)), "n", A),
    ]
    for action in negative_controls:
        must_reject(action)

    # An active occurrence of v changes, while the descriptor's stored v does not.
    before = dict(language.descriptors)
    original = app("D_S", V, ZERO)
    assert subst(original, "v", succ(V)) == app("D_S", succ(V), ZERO)
    assert before == language.descriptors
    assert language.descriptors["D_S"] == succ(V)

    terms = terms_up_to(language, 3)
    cases = 0
    for left in terms:
        language.check_matrix_term(left)
        for right in terms:
            language.check_matrix_term(right)
            old = old_dynamic(left, right)
            new = new_dynamic(left, right)
            plus_left = subst(left, "n", succ(N))
            plus_right = subst(right, "n", succ(N))
            common = 2 * size(left) + 2 * size(right)
            common += size(plus_left) + size(plus_right)
            assert size(old) == 21 + common
            assert size(new) == 16 + common
            assert size(old) - size(new) == 5
            assert not free_vars(old) and not free_vars(new)
            first = root(eq(left, right))
            second = eq(plus_left, plus_right)
            language.check_formula(first)
            language.check_formula(second)
            assert quantifier_free(first) and second.tag == "eq"
            assert individual_names(new) <= {"n", "a"}
            cases += 1

    computation_results = {}
    for name in language.descriptors:
        old_matrix = old_stationary(language, name)
        # Shadowing belongs to the old baseline only.
        assert free_vars(old_matrix) <= {"a"}
        assert subst(old_matrix, "n", succ(N)) == old_matrix
        old_sentence = envelope(old_matrix, old_matrix)

        first = new_computation(language, name)
        second = eq(ZERO, ZERO)
        language.check_formula(first)
        language.check_formula(second)
        assert quantifier_free(first) and second.tag == "eq"
        assert free_vars(first) == {"n", "a"}
        assert subst(first, "n", succ(N)) != first
        new_sentence = envelope(first, second)
        assert not free_vars(new_sentence)
        assert individual_names(new_sentence) <= {"n", "a"}
        count = size(first)
        assert size(old_matrix) == count + 1
        assert size(old_sentence) == 3 * count + 8
        assert size(new_sentence) == 2 * count + 8
        assert size(old_sentence) - size(new_sentence) == count
        computation_results[name] = {
            "K_nodes": count,
            "old_stationary_envelope_nodes": size(old_sentence),
            "new_QF_pair_envelope_nodes": size(new_sentence),
            "nodes_saved": count,
        }

    # d(x,y) = I_p(y,x) = D_p(S(y),x). Thus d(S(n),a)=D_p(S(a),S(n)).
    left_bridge = eq(app("D_p", succ(A), succ(N)), ONE)
    right_bridge = eq(N, A)
    bridge = forall("n", forall("a", iff(left_bridge, right_bridge)))
    assert size(left_bridge) == 8
    assert size(right_bridge) == 3
    assert size(bridge) == 27
    assert not free_vars(bridge)

    # Translation E(s,t) -> d(S(s),t)=1. Its larger terms are charged explicitly.
    for left in terms:
        for right in terms:
            unit_term = app("D_p", succ(right), succ(left))
            assert size(new_dynamic(unit_term, ONE)) == size(new_dynamic(left, right)) + 15

    return {
        "status": "passed",
        "scope": "finite syntax, exact active-AST counts, binding, and staging only",
        "node_convention": "one per variable/constant/application/equality/connective/quantifier; expanded iff and negation",
        "descriptor_convention": "stored bodies frozen and excluded from active AST; listed separately below",
        "staged_descriptor_body_nodes": {
            key: size(value) for key, value in language.descriptors.items()},
        "term_count": len(terms),
        "ordered_equation_cases": cases,
        "negative_controls": len(negative_controls),
        "old_dynamic_count": "21+2|s|+2|t|+|s+|+|t+|",
        "new_dynamic_count": "16+2|s|+2|t|+|s+|+|t+|",
        "uniform_dynamic_saving": 5,
        "computation_count_formulas": {
            "K": "sep and (Reset_h and Tail_h)",
            "old": "3|K|+8",
            "new": "2|K|+8",
            "saving": "|K|",
        },
        "computation_counts": computation_results,
        "new_matrix_pair_properties": {
            "first_matrix_quantifier_free": True,
            "second_matrix_atomic_equation": True,
            "only_individual_names_n_and_a": True,
            "emitted_sentences_closed": True,
            "computation_pair_requires_no_shadowing": True,
        },
        "fixed_unit_bridge": {
            "formula": "forall n forall a ((D_p(S(a),S(n))=S(0)) iff n=a)",
            "left_atom_nodes": size(left_bridge),
            "right_atom_nodes": size(right_bridge),
            "expanded_iff_matrix_nodes": size(iff(left_bridge, right_bridge)),
            "closed_sentence_nodes": size(bridge),
            "if_iff_is_a_primitive_node": 14,
        },
        "one_term_unit_dynamic_count": "22+2|u|+|u+|",
        "translated_unit_instance_extra_nodes": 15,
        "examples": {
            "E_is_n_equals_a": {"old": size(old_dynamic(N, A)),
                                "new": size(new_dynamic(N, A))},
            "E_is_0_equals_0": {"old": size(old_dynamic(ZERO, ZERO)),
                                "new": size(new_dynamic(ZERO, ZERO))},
        },
        "not_verified": ["arithmetic truth", "consistency", "induction strength",
                         "nonstandard-model adequacy", "bi-interpretability"],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="optional JSON receipt")
    args = parser.parse_args()
    result = json.dumps(check(), indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(result, encoding="utf-8")
    print(result, end="")


if __name__ == "__main__":
    main()
