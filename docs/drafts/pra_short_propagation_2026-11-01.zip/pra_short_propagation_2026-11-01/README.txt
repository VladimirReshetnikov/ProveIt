A SHORTER PROPAGATION AXIOM FOR PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov, 1 November 2026

START HERE

report.pdf is the full mathematical report. report.tex and sections/*.tex
contain all its editable LaTeX sources. AXIOMS.txt is the exact extractable
specification. No input archive is required to read or rebuild the report.

MAIN PROVED IMPROVEMENT

The five current ProveIt drafts already use n=0 OR s(n,a)=t(n,a).
The recommended theory deletes the successor-zero disjunct from the step:

  [forall n ((n=0 OR E(n,a)) -> E(S(n),a))]
      -> forall n (n=0 OR E(n,a)).

Here E is an equation, not an arbitrary formula. With the SAME delayed
iteration language, separation, and two computation schemes, this is
deductively equivalent to the current common core. Each corresponding
dynamic axiom is exactly five active syntax nodes shorter.

The asymmetric pair generator also replaces the old quantified stationary
computation matrix by the quantifier-free pair (K_h(n,a), 0=0). This yields
the computational laws by reflexivity, removes all internal binders and
shadowing, and saves k_h nodes in the corresponding computational sentence.
For h(v)=S(v), the count drops from 86 to 60.

Both generated matrices are now quantifier-free. Every right matrix is an
equation. Two effective pair constructors suffice. The changed pair interface
is disclosed; no universal minimality theorem is claimed.

CLASSICAL AND INTUITIONISTIC RESULTS

Exactly the same nonlogical specification works in either matching logic.
The report proves common conservative definitional extensions, full-domain
bi-interpretations preserving native equality, identity round trips, and
equiconsistency with the respective first-order version of PRA.

ONE-TERM ALTERNATIVE

A second completed theory accepts only u(n,a) in the dynamic equation u=1.
It adds the fixed law d(Sn,a)=1 iff n=a, where d is already a term.
This is an honest input-grammar tradeoff: the extra law costs syntax, and a
compiled dynamic instance is longer. It is not the recommendation for
minimum expanded axiom length.

The further proposal t(n,a)=n without a fixed bridge yields several proved
lemmas, including zero-equation induction, but its equivalence to PRA remains
UNPROVED. It is clearly separated from the completed axiomatizations.

PROVENANCE

All five docs/drafts archives were read at ProveIt commit:
104a876e91f8b4d091a3acb4bc79f5dc9942a418

The exact five names, Git blob hashes, and SHA-256 hashes are in
audit/source_manifest.json. The scalar arithmetic, numerical pairing, and
primitive-recursion compiler are inherited from those drafts and reproduced
with attribution. The shorter generator, its verification, the cost ledger,
and the explicit one-term tradeoff are this report's contribution.

REBUILD

  python3 build.py
  python3 build.py --lean /absolute/path/to/lean

Python uses only the standard library for the supplied diagnostics. The report
requires pdfLaTeX and standard TeX packages. The checked Lean version is
leanprover/lean4:v4.19.0; the kernels require no Mathlib.

VERIFICATION SCOPE

formal/ShortPropagation.lean checks the local constructive logical kernel and
partial fixed-target lemmas. formal/EqualityReflectionKernel.lean reproduces
and checks the earlier arithmetic residual/equality-bit kernel. Each uses
explicit hypotheses for the source induction instances and algebraic laws.

Neither Lean file formalizes the entire generated language, numerical pairing,
or full bi-interpretation. Those claims are proved in the report. Python tests
check syntax bookkeeping and bounded examples; they do not prove consistency
or validity in nonstandard models. See formal/SCOPE.txt and audit/ receipts.

CONTENTS

  report.pdf, report.tex, sections/*.tex  Complete report and source
  AXIOMS.txt                            Exact formal specification
  build.py                              Rebuild and check script
  checks/check_schema.py                 Effective syntax and node counts
  checks/check_arithmetic.py             Bounded arithmetic diagnostics
  formal/*.lean, formal/lean-toolchain   Scoped proof kernels
  audit/*                               Provenance and verification receipts
  SHA256SUMS.txt                        Package integrity hashes
