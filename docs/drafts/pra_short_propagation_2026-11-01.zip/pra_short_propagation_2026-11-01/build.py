#!/usr/bin/env python3
"""Rebuild the report and diagnostics; optionally check both Lean kernels."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Path to Lean 4.19.0 executable")
    parser.add_argument("--checks-only", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    audit = root / "audit"
    audit.mkdir(exist_ok=True)
    receipts: list[dict] = []

    def run(command: list[str], name: str) -> str:
        result = subprocess.run(
            command, cwd=root, text=True, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, check=False,
        )
        (audit / name).write_text(result.stdout)
        receipts.append({"command": command, "exit_code": result.returncode,
                         "log": "audit/" + name})
        if result.returncode:
            (audit / "build_results.json").write_text(
                json.dumps(receipts, indent=2) + "\n")
            raise SystemExit(f"Failed; see audit/{name}")
        return result.stdout

    run([sys.executable, "checks/check_schema.py",
         "--output", "audit/schema_counts.json"], "syntax_check.log")
    run([sys.executable, "checks/check_arithmetic.py",
         "--output", "audit/arithmetic_check.json"], "arithmetic_check.log")
    if args.lean:
        run([args.lean, "--version"], "lean_version.log")
        for name in ("ShortPropagation", "EqualityReflectionKernel"):
            run([args.lean, f"formal/{name}.lean"], f"{name}.lean.log")
    else:
        receipts.append({"operation": "Lean verification", "status": "not rerun",
                         "reason": "Pass --lean to check the kernels."})
    if not args.checks_only:
        latex = shutil.which("pdflatex")
        if not latex:
            raise SystemExit("pdfLaTeX is required to rebuild report.pdf")
        for number in range(1, 4):
            run([latex, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
                f"latex_pass_{number}.log")
        log = (root / "report.log").read_text(errors="replace")
        blockers = [line for line in log.splitlines()
                    if "Overfull" in line or "undefined" in line.lower()
                    or "multiply defined" in line.lower()]
        if blockers:
            raise SystemExit("Inspect report.log: " + " | ".join(blockers))
        for suffix in ("aux", "out", "toc", "log"):
            path = root / f"report.{suffix}"
            if suffix == "log":
                shutil.copyfile(path, audit / "latex_final.log")
            path.unlink(missing_ok=True)
        receipts.append({"file": "report.pdf",
                         "sha256": hashlib.sha256((root / "report.pdf").read_bytes())
                         .hexdigest()})
    (audit / "build_results.json").write_text(json.dumps(receipts, indent=2) + "\n")
    print(json.dumps({"status": "passed", "operations": len(receipts)}, indent=2))


if __name__ == "__main__":
    main()
