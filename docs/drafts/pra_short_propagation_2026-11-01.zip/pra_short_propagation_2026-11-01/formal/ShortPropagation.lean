import Init

/-!
Constructive kernels for shortened rooted-equation propagation.

All objects below are semantic parameters on an arbitrary carrier.  A hypothesis
`ShortAt z s E` or `OldAt z s E` denotes ONE fixed source-schema instance, with
its one frozen parameter.  No theorem assumes a schema for every predicate.
The source syntax, numerical pairing, full primitive-recursive compiler, and
bi-interpretation are not formalized by this file.

There are no added axioms, `sorry`, classical logic, or choice.  The final
`#print axioms` commands report the dependencies of the principal results.
-/

universe u
namespace ShortPropagation
variable {A : Type u}

/-- One equation-induction instance, usable under arbitrary hypotheses. -/
def EqIndAt (z : A) (s : A → A) (f g : A → A) : Prop :=
  f z = g z → (∀ n, f n = g n → f (s n) = g (s n)) → ∀ n, f n = g n

/-- The former propagation instance for one fixed matrix equation. -/
def OldAt (z : A) (s : A → A) (E : A → A → Prop) : Prop :=
  ∀ a, (∀ n, (n = z ∨ E n a) → (s n = z ∨ E (s n) a)) →
    ∀ n, n = z ∨ E n a

/-- The shortened propagation instance for that same equation. -/
def ShortAt (z : A) (s : A → A) (E : A → A → Prop) : Prop :=
  ∀ a, (∀ n, (n = z ∨ E n a) → E (s n) a) → ∀ n, n = z ∨ E n a

/-- One directly generated pair of matrices; this is not a predicate axiom. -/
def PairAt (F G : A → A → Prop) : Prop :=
  ∀ a, (∀ n, F n a → G n a) → ∀ n, F n a

/-- Computation matrices need neither stationarity nor an inner binder. -/
theorem reflexive_pair_extract (z : A) (F : A → A → Prop)
    (schemaInstance : PairAt F (fun _ _ => z = z)) : ∀ a n, F n a := by
  intro a n
  exact schemaInstance a (fun _ _ => rfl) n

theorem reflexive_pair_of_truth (z : A) (F : A → A → Prop)
    (truth : ∀ a n, F n a) : PairAt F (fun _ _ => z = z) := by
  intro a _ n
  exact truth a n

theorem stationary_pair_extract (z : A) (R : A → Prop)
    (schemaInstance : PairAt (fun _ a => R a) (fun _ a => R a)) :
    ∀ a, R a := by
  intro a
  exact schemaInstance a (fun _ h => h) z

theorem stationary_pair_of_truth (R : A → Prop) (truth : ∀ a, R a) :
    PairAt (fun _ a => R a) (fun _ a => R a) := by
  intro a _ _
  exact truth a

theorem short_pair_form (z : A) (s : A → A) (E : A → A → Prop) :
    ShortAt z s E ↔
      PairAt (fun n a => n = z ∨ E n a) (fun n a => E (s n) a) := by
  constructor <;> intro h <;> exact h

/-- The old instance implies the shortened one without arithmetic assumptions. -/
theorem short_of_old (z : A) (s : A → A) (E : A → A → Prop)
    (schemaInstance : OldAt z s E) : ShortAt z s E := by
  intro a progress
  exact schemaInstance a (fun n hn => Or.inr (progress n hn))

/-- The reverse implication uses successor nonzeroness, explicitly. -/
theorem old_of_short (z : A) (s : A → A) (E : A → A → Prop)
    (succNonzero : ∀ n, s n ≠ z) (schemaInstance : ShortAt z s E) :
    OldAt z s E := by
  intro a progress
  apply schemaInstance a
  intro n hn
  cases progress n hn with
  | inl impossible => exact False.elim (succNonzero n impossible)
  | inr next => exact next

theorem short_iff_old (z : A) (s : A → A) (E : A → A → Prop)
    (succNonzero : ∀ n, s n ≠ z) : ShortAt z s E ↔ OldAt z s E :=
  ⟨old_of_short z s E succNonzero, short_of_old z s E⟩

/-- This transfers assumptions, so it proves the induction axiom, not just a rule. -/
theorem equation_induction (z : A) (s : A → A) (f g : A → A → A)
    (schemaInstance : ShortAt z s (fun n a => f n a = g n a)) :
    ∀ a, EqIndAt z s (fun n => f n a) (fun n => g n a) := by
  intro a base step
  have progress : ∀ n, (n = z ∨ f n a = g n a) → f (s n) a = g (s n) a := by
    intro n hn
    cases hn with
    | inl hz => exact step n (hz ▸ base)
    | inr he => exact step n he
  intro n
  cases schemaInstance a progress n with
  | inl hz => exact hz ▸ base
  | inr he => exact he

/-- The converse uses just the matching rooted QF induction instance. -/
theorem short_of_root_induction (z : A) (s : A → A) (E : A → A → Prop)
    (inductionInstance : ∀ a,
      (z = z ∨ E z a) →
      (∀ n, (n = z ∨ E n a) → (s n = z ∨ E (s n) a)) →
      ∀ n, n = z ∨ E n a) : ShortAt z s E := by
  intro a progress
  exact inductionInstance a (Or.inl rfl) (fun n hn => Or.inr (progress n hn))

/-- Coverage still follows: the successor equation holds unconditionally. -/
theorem coverage (z : A) (s p : A → A) (predSucc : ∀ n, p (s n) = n)
    (schemaInstance : ShortAt z s (fun n _ => n = s (p n))) :
    ∀ n, n = z ∨ n = s (p n) := by
  apply schemaInstance z
  intro n _
  exact (congrArg s (predSucc n)).symm

/-- The predecessor bridge requires exactly the displayed equation instance. -/
theorem predecessor_succ (z : A) (s : A → A) (d : A → A → A)
    (seed : d (s z) z = z)
    (tail : ∀ n, d (s (s n)) z = s (d (s n) z))
    (schemaInstance : ShortAt z s (fun n _ => d (s n) z = n)) :
    ∀ n, d (s n) z = n := by
  have inductionInstance := equation_induction z s
    (fun n _ => d (s n) z) (fun n _ => n) schemaInstance z
  apply inductionInstance
  · exact seed
  · intro n ih
    exact (tail n).trans (congrArg s ih)

theorem successor_injective (s p : A → A) (predSucc : ∀ n, p (s n) = n)
    {x y : A} (h : s x = s y) : x = y := by
  have hp := congrArg p h
  exact (predSucc x).symm.trans (hp.trans (predSucc y))

theorem successor_nonzero (z : A) (s p : A → A)
    (predZero : p z = z) (predSucc : ∀ n, p (s n) = n)
    (separation : z ≠ s z) (n : A) : s n ≠ z := by
  intro h
  have hn : n = z := (predSucc n).symm.trans ((congrArg p h).trans predZero)
  exact separation ((congrArg s hn).symm.trans h).symm

/-- One unit-equation instance transfers to one arbitrary equation instance. -/
theorem unit_bridge_transfer (z one : A) (s : A → A) (d : A → A → A)
    (bridge : ∀ x y, d (s x) y = one ↔ x = y)
    (f g : A → A → A)
    (schemaInstance : ShortAt z s (fun n a => d (s (f n a)) (g n a) = one)) :
    ShortAt z s (fun n a => f n a = g n a) := by
  intro a progress
  have unitProgress : ∀ n,
      (n = z ∨ d (s (f n a)) (g n a) = one) →
        d (s (f (s n) a)) (g (s n) a) = one := by
    intro n hn
    apply (bridge (f (s n) a) (g (s n) a)).2
    apply progress n
    cases hn with
    | inl hz => exact Or.inl hz
    | inr hu => exact Or.inr ((bridge (f n a) (g n a)).1 hu)
  intro n
  cases schemaInstance a unitProgress n with
  | inl hz => exact Or.inl hz
  | inr hu => exact Or.inr ((bridge (f n a) (g n a)).1 hu)

/-- The reverse passage to a unit equation is literal specialization. -/
theorem unit_is_equation_instance (z one : A) (s : A → A) (t : A → A → A)
    (schemaInstance : ShortAt z s (fun n a => t n a = (fun _ _ => one) n a)) :
    ShortAt z s (fun n a => t n a = one) := schemaInstance

/-- Extracting the fixed bridge from its stationary matrix pair. -/
theorem stationary_bridge_extract (z one : A) (s : A → A) (d : A → A → A)
    (schemaInstance : PairAt
      (fun _ a => ∀ n, d (s n) a = one ↔ n = a)
      (fun _ a => ∀ n, d (s n) a = one ↔ n = a)) :
    ∀ n a, d (s n) a = one ↔ n = a := by
  have all := stationary_pair_extract z
    (fun a => ∀ n, d (s n) a = one ↔ n = a) schemaInstance
  exact fun n a => all a n

/-! Partial fixed-target experiment.  These lemmas do not assert that the
    fixed-target restriction recovers all of PRA.  All exact ingredients and
    induction instances are explicit hypotheses. -/

/-- A fixed point of successor would create a fixed point of an iterated toggle. -/
theorem no_succ_fixedpoint (s h J : A → A)
    (noFixed : ∀ v, h v ≠ v) (step : ∀ n, J (s n) = h (J n)) :
    ∀ n, s n ≠ n := by
  intro n hs
  exact noFixed (J n) ((step n).symm.trans (congrArg J hs))

/-- Coverage makes the zero-selector toggle fixed-point free. -/
theorem toggle_no_fixedpoint (z : A) (s p : A → A) (Z : A → A → A)
    (cov : ∀ v, v = z ∨ v = s (p v))
    (atZero : ∀ b, Z z b = b) (atSucc : ∀ v b, Z (s v) b = z)
    (succNonzero : ∀ v, s v ≠ z) : ∀ v, Z v (s z) ≠ v := by
  intro v fixed
  cases cov v with
  | inl hv =>
    have val : Z v (s z) = s z :=
      (congrArg (fun x => Z x (s z)) hv).trans (atZero (s z))
    exact succNonzero z (val.symm.trans (fixed.trans hv))
  | inr hv =>
    have val : Z v (s z) = z :=
      (congrArg (fun x => Z x (s z)) hv).trans (atSucc (p v) (s z))
    exact succNonzero (p v) (hv.symm.trans (fixed.symm.trans val))

/-- A selector turns a zero test into equality with the induction variable. -/
theorem selector_fixedpoint_reflects_zero (z : A) (s p : A → A)
    (C : A → A → A → A) (cov : ∀ v, v = z ∨ v = s (p v))
    (atZero : ∀ b c, C z b c = b)
    (atSucc : ∀ v b c, C (s v) b c = c)
    (noFixed : ∀ n, s n ≠ n) (v n : A) :
    C v n (s n) = n ↔ v = z := by
  constructor
  · intro hc
    cases cov v with
    | inl hv => exact hv
    | inr hv =>
      have val : C v n (s n) = s n :=
        (congrArg (fun x => C x n (s n)) hv).trans (atSucc (p v) n (s n))
      exact False.elim (noFixed n (val.symm.trans hc))
  · intro hv
    exact (congrArg (fun x => C x n (s n)) hv).trans (atZero n (s n))

/-- One fixed-target instance transfers to the corresponding zero-equation one. -/
theorem zero_induction_of_fixed_target (z : A) (s : A → A)
    (C : A → A → A → A)
    (reflectsZero : ∀ v n, C v n (s n) = n ↔ v = z) (t : A → A)
    (fixedInstance : EqIndAt z s (fun n => C (t n) n (s n)) (fun n => n)) :
    EqIndAt z s t (fun _ => z) := by
  intro base step
  have fixedBase : C (t z) z (s z) = z := (reflectsZero (t z) z).2 base
  have fixedStep : ∀ n, C (t n) n (s n) = n →
      C (t (s n)) (s n) (s (s n)) = s n := by
    intro n ih
    exact (reflectsZero (t (s n)) (s n)).2
      (step n ((reflectsZero (t n) n).1 ih))
  intro n
  exact (reflectsZero (t n) n).1 (fixedInstance fixedBase fixedStep n)

#print axioms reflexive_pair_extract
#print axioms stationary_pair_extract
#print axioms short_iff_old
#print axioms equation_induction
#print axioms coverage
#print axioms predecessor_succ
#print axioms successor_nonzero
#print axioms unit_bridge_transfer
#print axioms stationary_bridge_extract

#print axioms no_succ_fixedpoint
#print axioms toggle_no_fixedpoint
#print axioms selector_fixedpoint_reflects_zero
#print axioms zero_induction_of_fixed_target

end ShortPropagation
