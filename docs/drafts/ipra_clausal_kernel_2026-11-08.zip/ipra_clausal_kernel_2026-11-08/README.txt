CLAUSE CONTEXTS FOR iPRA
One logical binder, four inference patterns, and a smaller certificate kernel
Prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific date)
===========================================================================

START WITH report.pdf. Its complete editable source is report.tex together
with sections/, appendices/, and results/current_table.tex.

RESULT AND LIMITS

The new mathematical presentation has equations and one paired binder as
formulas. Contexts contain reusable one-premise clauses. It has four inference
patterns (Use, DI, DE, transport) and two scalar-iteration computation schemas.
Full intuitionistic logic, quantifier-free induction, and every fixed
primitive-recursive operation are reconstructed. Both arithmetic interpretations
use the whole domain; their composites have the identity isomorphism x=y.

The standalone checker verifies a conservative derived-rule certificate
language with auxiliary unary closure notation. It is not a direct parser of
four-rule clausal derivation trees. The untrusted producer compiles valid closed
clausal proofs to that certificate language. No compiler or logical library is
imported by the checker.

Pinned repository commit: ce3371c9025b5c0ba12543acc2e6475d13ff7a3c
Current directory: https://github.com/VladimirReshetnikov/ProveIt/tree/ce3371c9025b5c0ba12543acc2e6475d13ff7a3c/docs/drafts
Five current archives; ten complete root checker programs.

                                        tokens   AST nodes   normalized bytes
Current delivered coordinate minima:       328         356                957
Common names and identical driver:          328         356                941
New complete checker.py:                    326         351                938

These are the inherited whole-program normalized metrics on CPython 3.12.14.
Comments, genuine docstrings, layout, helper-name advantages, and public-driver
advantages do not explain the controlled win. All project-specific validation,
inference, input, output, and rejection code is counted.

The improvement is small: two tokens, five AST nodes, and three bytes against
the controlled envelope. It is not a global minimum theorem or the major
foundational breakthrough sought by the research program. The new clause
presentation and the kernel reduction are distinct contributions. Richer
contexts must be counted; fewer primitive rules do not prove a smaller direct
checker. The arithmetic basis and its bootstrap are inherited and attributed.

RUN THE CHECKED CLAUSAL EXAMPLE

  python3 examples/produce_clausal.py --checker checker.py --output examples
  python3 checker.py < examples/clausal_identity_packet.json
  python3 checker.py < examples/clausal_false_packet.json

The first target is D_{w,y}(I(y,0;u.Su)=y), with w unused; its ordinary meaning
is equivalent to forall y I(y,0;u.Su)=y. Its six-instruction packet ACCEPTs.
The second packet changes the target to D_{w,y}(I(y,0;u.Su)=0) and REJECTs.
The source derivation uses all four new rules. See examples/README.txt for the
general closed-proof compiler's syntax, alpha-renaming convention, and scope.

REPRODUCE

  python3 comparison/measure.py
  python3 validation/validate.py
  python3 examples/check_compiler.py --checker checker.py --output examples
  python3 reproduce.py

The last command reruns measurements, validation, both producer checks, and
the PDF build. Python 3.10+ and its standard library run the kernel and tests;
use CPython 3.12.14 for exactly the recorded normalized metrics. A normal
pdfLaTeX installation and the packages listed in report.tex rebuild the PDF.
latexmk is used if available. No network access is needed.

VALIDATION STATUS

All tests passed: 1,009 packet comparisons, 1,088 focused opening comparisons,
52 actual kernel CLI runs, and five positive source-compiler examples plus
the false-target negative control. The frozen baseline and independently
structured oracle agree on acceptance, final fresh-label floor, and remaining
packet cells. All five auxiliary patterns and both computation schemas occur
in accepted traces. Finite tests do not prove the universal metatheorems.

Soundness, completeness, and bi-interpretability are written proofs, not a
Lean/Rocq formalization. Completeness assumes sufficient finite resources;
fixed Python recursion/memory limits can reject sufficiently large proofs.

CONTENTS

  report.pdf, report.tex       Complete paper and main source
  sections/, appendices/       All included mathematical source
  checker.py                  Entire trusted certificate checker
  examples/                   Untrusted compiler, source proofs, raw packets,
                              traces, executable checks, and worked derivation
  comparison/baselines/        Ten unchanged current root checkers
  comparison/manifest.json     Pinned archive/source identities and hashes
  comparison/source_measure.py Unchanged inherited metric implementation
  comparison/measure.py        Complete-program and controlled comparisons
  validation/                 Independent oracle, fixtures, focused tests,
                              and exact refinement argument
  results/                    Measured and validation receipts
  build.py, reproduce.py       Offline reproduction tools
  package.py                  Clean ZIP and checksum-manifest builder
  ATTRIBUTION.txt, LICENSE.txt New/inherited contribution boundaries and license
  SHA256SUMS.txt               Digests of all package files except this manifest

FURTHER RESEARCH

The report includes explicit research questions: a smaller direct four-rule
clause checker; a direct-recursion kernel below the scalar envelope; formal
verification of decoding and the compiler; and less language-dependent
complexity benchmarks. It also records why two tempting deletions are not
justified: the retained atomic base and scalar iteration's initializer.
