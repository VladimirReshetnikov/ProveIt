"""Whole-program measurements with reproducible common-driver/name controls."""
import ast
import hashlib
import json
from pathlib import Path
import platform
import tempfile

from source_measure import metrics

ROOT = Path(__file__).resolve().parent.parent
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
DRIVER = '''try:
    take = json.load(sys.stdin).pop
    1 / test(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
'''


class CommonNames(ast.NodeTransformer):
    names = {'inst': 'sub', 'check': 'test'}

    def visit_Name(self, node):
        node.id = self.names.get(node.id, node.id)
        return node

    def visit_FunctionDef(self, node):
        node.name = self.names.get(node.name, node.name)
        return self.generic_visit(node)


def controlled(path, common_driver):
    tree = CommonNames().visit(ast.parse(path.read_text()))
    if common_driver:
        boundary = next(i for i, item in enumerate(tree.body)
                        if isinstance(item, ast.Try))
        tree.body = tree.body[:boundary] + ast.parse(DRIVER).body
    return ast.unparse(ast.fix_missing_locations(tree)) + '\n'


def profiles(path, temporary):
    answer = {'as_delivered': metrics(path)}
    for name, driver in [('common_names', False), ('common_names_and_driver', True)]:
        temporary.write_text(controlled(path, driver))
        answer[name] = metrics(temporary)
    return answer


def main():
    manifest = json.loads((ROOT / 'comparison' / 'manifest.json').read_text())
    metric_hash = hashlib.sha256((ROOT / 'comparison/source_measure.py').read_bytes()).hexdigest()
    if metric_hash != manifest['measurement_normalizer']['sha256']:
        raise ValueError('Changed inherited measurement normalizer')
    with tempfile.TemporaryDirectory() as scratch:
        temporary = Path(scratch) / 'controlled.py'
        baselines = []
        for entry in manifest['programs']:
            path = ROOT / entry['file']
            if hashlib.sha256(path.read_bytes()).hexdigest() != entry['sha256']:
                raise ValueError('Changed comparator: ' + entry['file'])
            baselines.append({**entry, 'label': entry['member'], 'measurements': profiles(path, temporary)})
        candidates = [{'file': name, 'measurements': profiles(ROOT / name, temporary)}
                      for name in ('checker.py',)]
    envelopes = {}
    for profile in ('as_delivered', 'common_names', 'common_names_and_driver'):
        envelope = {field: min(row['measurements'][profile][field] for row in baselines)
                    for field in FIELDS}
        envelopes[profile] = {
            'minimum': envelope,
            'attainers': {field: [row['label'] for row in baselines
                                  if row['measurements'][profile][field] == envelope[field]]
                          for field in FIELDS}}
    result = {'status': 'PASS', 'python': platform.python_version(),
              'implementation': platform.python_implementation(),
              'commit': manifest['commit'], 'program_count': len(baselines),
              'coordinates': list(FIELDS), 'envelopes': envelopes,
              'baselines': baselines, 'candidates': candidates,
              'comparison': {row['file']: {
                  profile: {field: row['measurements'][profile][field] <
                            envelopes[profile]['minimum'][field] for field in FIELDS}
                  for profile in envelopes} for row in candidates},
              'metric_source_sha256': hashlib.sha256((ROOT/'comparison'/'source_measure.py').read_bytes()).hexdigest(),
              'control_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'note': 'Controls consistently rename only inst/check to sub/test, and optionally install the identical complete driver. No rule, validation, import, parser, or rejection code is omitted.'}
    if not all(value for candidate in result['comparison'].values()
               for profile in candidate.values() for value in profile.values()):
        result['status'] = 'NO STRICT DOMINANCE'
    (ROOT / 'results' / 'measurements.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'envelopes': envelopes,
                      'candidates': candidates, 'comparison': result['comparison']}, indent=2))


if __name__ == '__main__':
    main()
