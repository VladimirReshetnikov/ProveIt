#!/usr/bin/env python3
"""Untrusted compiler and demonstration for closed clausal proofs.

The input proof has D and equations as its only formula constructors.
Compilation uses the auxiliary-Q certificate backend.  This producer is
not imported by, and is not part of, the trusted checker.

The supported local contexts are exactly those generated from an empty
context by DI and DE: constant assumptions and canonical closure clauses.
These cover every closed proof in the four-rule calculus. Eigenparameter
names must be globally distinct and disjoint from formula/term binder names;
active clause identifiers must be distinct. These are input normal-form
conventions, achievable by alpha-renaming every finite proof. This program
is a proof producer, not a validator of all these proof-theoretic conditions.
No claim is made to compile arbitrary externally supplied clause contexts.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def zero():
    return ["0"]


def var(name):
    return ["v", name]


def succ(term):
    return ["s", term]


def iterate(n):
    return ["i", n, zero(), "u", succ(var("u"))]


def eq(left, right):
    return ["=", left, right]


def identity(n):
    return eq(iterate(n), n)


H = eq(["i", zero(), zero(), "u", zero()], zero())
GOAL = ["D", "w", "y", identity(var("y"))]


def substitute(expr, name, image):
    """Capture-avoiding on this demonstration's globally fresh names."""
    tag = expr[0]
    if tag == "0":
        return expr
    if tag == "v":
        return image if expr[1] == name else expr
    if tag == "s":
        return [tag, substitute(expr[1], name, image)]
    if tag == "i":
        _, n, a, u, body = expr
        return [tag, substitute(n, name, image),
                substitute(a, name, image), u,
                body if u == name else substitute(body, name, image)]
    if tag == "=":
        return [tag, substitute(expr[1], name, image),
                substitute(expr[2], name, image)]
    if tag == "D":
        _, x, y, body = expr
        return [tag, x, y, body if name in (x, y)
                else substitute(body, name, image)]
    if tag == "Q":
        _, y, body = expr
        return [tag, y, body if name == y
                else substitute(body, name, image)]
    raise ValueError("unknown expression constructor")


def computation():
    return {"rule": "Computation"}


def use(name, at, premise):
    return {"rule": "Use", "clause": name, "at": at,
            "premise": premise}


def build_proof():
    # First prove the defined Q formula D_{w,y} B(y) by equation induction.
    j = var("j")
    induction_step = {
        "rule": "Tr",
        "equation": identity(j),
        "motive": eq(iterate(succ(j)), succ(var("$"))),
        "major": use("induction", zero(), computation()),
        "source": computation(),
    }
    induction = {
        "rule": "DI", "witness": zero(), "eigen": "j",
        "base": "first_base", "induction": "induction",
        "step": induction_step,
    }

    # Open that D formula as the reusable clause B(0) => B(t), then
    # introduce D again. The successor premise is now a generic Use.
    reintroduction = {
        "rule": "DI", "witness": zero(), "eigen": "n",
        "base": "second_base", "induction": "unused_induction",
        "step": use("closure", succ(var("n")),
                    use("second_base", zero(), computation())),
    }
    return {
        "rule": "DE", "major_formula": GOAL, "major": induction,
        "eigen": "a", "clause": "closure", "minor": reintroduction,
    }


def bound_names(value):
    result = set()
    if isinstance(value, dict):
        for child in value.values():
            result.update(bound_names(child))
    elif isinstance(value, list):
        if value and value[0] == "i":
            result.add(value[3])
        elif value and value[0] == "D":
            result.update(value[1:3])
        elif value and value[0] == "Q":
            result.add(value[1])
        for child in value:
            result.update(bound_names(child))
    return result


class Producer:
    def __init__(self, forbidden_names=()):
        self.floor = 0
        self.parameters = {}
        self.read_order = []
        self.events = []
        self.forbidden_names = (set(forbidden_names) | bound_names(H)
                                | {"$", "unused"})

    def fresh(self, name):
        if name in self.parameters or name in self.forbidden_names:
            raise ValueError("eigenparameter name reused or not alpha-fresh")
        self.floor -= 1
        self.parameters[name] = self.floor
        self.events.append({"event": "fresh", "name": name,
                            "label": self.floor})

    def encode(self, expr, env=()):
        """Canonical encoding for the 0,2,1,4 scope-increment backend."""
        tag = expr[0]
        if tag == "0":
            return 0
        if tag == "v":
            name = expr[1]
            if name in env:
                return 2 * env.index(name) + 1
            if name == "$":
                return 2 * len(env) + 1
            return self.parameters[name]
        if tag == "s":
            return [self.encode(expr[1], (None,) + env)]
        if tag == "i":
            _, n, a, u, body = expr
            return [self.encode(n, (None, None) + env),
                    self.encode(a, (None, None) + env),
                    self.encode(body, (u, u) + env)]
        if tag == "=":
            return [self.encode(expr[1], env), self.encode(expr[2], env)]
        if tag == "D":
            _, x, y, body = expr
            return [0, 0, self.encode(body, (y, x) + env)]
        if tag == "Q":
            _, y, body = expr
            return [self.encode(body, (y,) + env)]
        raise ValueError("unknown expression constructor")

    def compile(self, goal, context, proof):
        rule = proof["rule"]
        self.events.append({"event": "compile", "rule": rule,
                            "goal": goal})
        # The backend tests hypotheses before reading an instruction. We
        # must mirror that demand-driven behavior: an arbitrary valid source
        # proof of an already available ordinary formula is replaced by Use
        # of its constant clause, and its whole certificate subtree is erased.
        encoded_goal = self.encode(goal)
        for entry in context.values():
            auxiliary = (entry["body"] if entry["kind"] == "constant"
                         else ["Q", entry["binder"], entry["body"]])
            if self.encode(auxiliary) == encoded_goal:
                self.events.append({"event": "hypothesis_short_circuit"})
                return
        if rule == "Computation":
            self.read_order.append([])
            return
        if rule == "Use":
            entry = context[proof["clause"]]
            at = proof["at"]
            expected = substitute(entry["body"], entry["binder"], at)
            if expected != goal:
                raise ValueError("Use conclusion does not match its clause")
            if entry["kind"] == "constant":
                # H is a fixed computation theorem; this native Use node
                # compiles to the ordinary assumption already in context.
                # The backend checks it before reading any instruction.
                if entry["antecedent"] != H:
                    raise ValueError("constant Use needs antecedent H")
                return
            self.read_order.append([
                self.encode(["Q", entry["binder"], entry["body"]]),
                self.encode(at),
            ])
            self.compile(entry["antecedent"], context, proof["premise"])
            return
        if rule == "Tr":
            equation = proof["equation"]
            if equation[0] != "=":
                raise ValueError("transport needs an equation")
            motive = proof["motive"]
            if substitute(motive, "$", equation[2]) != goal:
                raise ValueError("transport target mismatch")
            self.read_order.append([self.encode(equation), self.encode(motive)])
            self.compile(equation, context, proof["major"])
            self.compile(substitute(motive, "$", equation[1]), context,
                         proof["source"])
            return
        if rule == "DI":
            if goal[0] != "D":
                raise ValueError("DI needs a D goal")
            _, x, y, matrix = goal
            witness = proof["witness"]
            body = substitute(matrix, x, witness)
            self.read_order.append(self.encode(witness))
            self.fresh(proof["eigen"])
            z = var(proof["eigen"])
            local = dict(context)
            base = substitute(body, y, zero())
            if proof["base"] in local:
                raise ValueError("active clause identifier reused")
            local[proof["base"]] = {
                "kind": "constant", "antecedent": H,
                "binder": "unused", "body": base,
            }
            if body[0] == "=":
                if proof["induction"] in local:
                    raise ValueError("active clause identifier reused")
                local[proof["induction"]] = {
                    "kind": "constant", "antecedent": H,
                    "binder": "unused", "body": substitute(body, y, z),
                }
            self.compile(substitute(body, y, succ(z)), local, proof["step"])
            return
        if rule == "DE":
            major = proof["major_formula"]
            if major[0] != "D":
                raise ValueError("DE needs a D major premise")
            self.read_order.append([self.encode(major), 0])
            self.compile(major, context, proof["major"])
            self.fresh(proof["eigen"])
            _, x, y, matrix = major
            body = substitute(matrix, x, var(proof["eigen"]))
            local = dict(context)
            if proof["clause"] in local:
                raise ValueError("active clause identifier reused")
            local[proof["clause"]] = {
                "kind": "closure", "binder": y, "body": body,
                "antecedent": substitute(body, y, zero()),
            }
            self.compile(goal, local, proof["minor"])
            return
        raise ValueError("unknown proof rule")


def run_checker(checker, packet):
    completed = subprocess.run(
        [sys.executable, str(checker)], input=json.dumps(packet),
        text=True, capture_output=True, check=False,
    )
    return {"returncode": completed.returncode,
            "stdout": completed.stdout.strip(),
            "stderr": completed.stderr.strip()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checker", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path(__file__).parent)
    parser.add_argument("--proof", type=Path,
                        help="JSON object with a closed goal and tagged proof")
    parser.add_argument("--prefix", default="clausal_identity")
    args = parser.parse_args()
    source = (json.loads(args.proof.read_text()) if args.proof
              else {"goal": GOAL, "proof": build_proof()})
    goal, proof = source["goal"], source["proof"]
    producer = Producer(bound_names(source))
    producer.compile(goal, {}, proof)
    packet = list(reversed(producer.read_order)) + [producer.encode(goal)]
    results = {
        "checker_sha256": hashlib.sha256(args.checker.read_bytes()).hexdigest(),
        "positive": run_checker(args.checker.resolve(), packet),
        "instruction_count": len(producer.read_order),
        "final_allocation_floor": producer.floor,
        "producer_status": "untrusted compiler for alpha-fresh closed proofs",
        "coverage": "all four rules; DI/DE-generated local clauses",
    }
    if results["positive"]["stdout"] != "ACCEPT" or results["positive"]["returncode"] != 0:
        raise RuntimeError(results)
    args.output.mkdir(parents=True, exist_ok=True)
    outputs = {
        args.prefix + "_proof.json": source,
        args.prefix + "_packet.json": packet,
        args.prefix + "_trace.json": producer.events,
    }
    if not args.proof:
        negative_goal = ["D", "w", "y", eq(iterate(var("y")), zero())]
        negative = packet[:-1] + [producer.encode(negative_goal)]
        results["negative"] = run_checker(args.checker.resolve(), negative)
        if results["negative"]["stdout"] != "REJECT" or results["negative"]["returncode"] == 0:
            raise RuntimeError(results)
        outputs["clausal_false_packet.json"] = negative
    outputs[args.prefix + "_results.json"] = results
    for name, value in outputs.items():
        (args.output / name).write_text(json.dumps(value, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
