#!/usr/bin/env python3
"""Focused executable checks of closed-proof compilation, not a formal proof."""
import argparse
import hashlib
import json
from pathlib import Path

from produce_clausal import (GOAL, H, Producer, bound_names, build_proof,
                            computation, eq, run_checker, substitute, succ,
                            use, var, zero)


def introduction(eigen, base, ih, step, witness=None):
    return {"rule": "DI", "eigen": eigen, "base": base,
            "induction": ih, "step": step,
            "witness": zero() if witness is None else witness}


def cases():
    yield "clausal_identity", GOAL, build_proof(), 6

    # A valid computation subtree is redundant because H is already a base
    # assumption. The compiler must erase it before emitting instructions.
    redundant_goal = ["D", "w", "y", H]
    redundant = {
        "rule": "DE", "major_formula": redundant_goal,
        "major": introduction("j", "b0", "ih0", computation()),
        "eigen": "a", "clause": "c",
        "minor": introduction("n", "b1", "ih1", computation()),
    }
    yield "clausal_short_circuit", redundant_goal, redundant, 3

    # The outer DI matrix is non-atomic, so it supplies a base assumption
    # but no equation induction hypothesis. Its theorem is A -> A.
    inner = ["D", "r", "s", eq(zero(), var("s"))]
    nonatomic_goal = ["D", "p", "q", inner]
    nonatomic = introduction("j", "b", "not_available",
                            use("b", zero(), computation()))
    yield "clausal_nonatomic_identity", nonatomic_goal, nonatomic, 1

    # The existential witness is used inside the opened closure, so this
    # checks both slots of D and a nonconstant DI witness in the minor.
    c = ["i", var("y"), zero(), "u", var("x")]
    witness_goal = ["D", "x", "y", eq(c, zero())]
    witness = {
        "rule": "DE", "major_formula": witness_goal,
        "major": introduction("j", "b0", "ih0", computation()),
        "eigen": "a", "clause": "closure",
        "minor": introduction(
            "n", "b1", "ih1",
            use("closure", succ(var("n")),
                use("b1", zero(), computation())), witness=var("a")),
    }
    yield "clausal_witness", witness_goal, witness, 5

    # Transport under a D binder inserts a numerical image with its own
    # iterator binder. Its internal state coordinate must not be captured.
    r = ["i", zero(), zero(), "u", succ(var("u"))]
    motive = ["D", "x", "y",
              eq(["i", var("y"), zero(), "u", var("$")], var("$"))]
    transport_goal = substitute(motive, "$", zero())
    transport = {
        "rule": "Tr", "equation": eq(r, zero()), "motive": motive,
        "major": computation(),
        "source": introduction("j", "b", "ih", computation()),
    }
    yield "clausal_bound_transport", transport_goal, transport, 4


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checker", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path(__file__).parent)
    args = parser.parse_args()
    rows = []
    args.output.mkdir(parents=True, exist_ok=True)
    for name, goal, proof, instructions in cases():
        source = {"goal": goal, "proof": proof}
        producer = Producer(bound_names(source))
        producer.compile(goal, {}, proof)
        packet = list(reversed(producer.read_order)) + [producer.encode(goal)]
        result = run_checker(args.checker.resolve(), packet)
        if result["stdout"] != "ACCEPT" or result["returncode"] != 0:
            raise RuntimeError({"case": name, "result": result})
        if len(producer.read_order) != instructions:
            raise RuntimeError({"case": name, "wrong_instruction_count":
                                len(producer.read_order)})
        rows.append({"case": name, **result, "instructions": instructions,
                     "allocation_floor": producer.floor})
        for suffix, data in (("proof", source), ("packet", packet)):
            (args.output / (name + "_" + suffix + ".json")).write_text(
                json.dumps(data, indent=2) + "\n")
    result = {"status": "PASS", "checks": rows,
              "checker_sha256": hashlib.sha256(args.checker.read_bytes()).hexdigest(),
              "scope": "five focused compiler checks against the actual CLI"}
    (args.output / "compiler_checks.json").write_text(
        json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
