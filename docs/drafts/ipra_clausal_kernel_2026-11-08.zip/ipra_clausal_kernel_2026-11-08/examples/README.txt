CLAUSAL PROOFS AND AN UNTRUSTED CERTIFICATE PRODUCER
=================================================

The source formulas have exactly two constructors: equations and D.
There is no primitive Q in the source theorem or its proof. Context
clauses retain their origin: either a constant formula assumption from
DI, or the canonical closure clause opened by DE. The compiler emits
certificates for the auxiliary-Q backend checker.

RUN FROM THE PACKAGE ROOT
-------------------------
  python3 examples/produce_clausal.py --checker checker.py --output examples
  python3 checker.py < examples/clausal_identity_packet.json
  python3 checker.py < examples/clausal_false_packet.json
  python3 examples/check_compiler.py --checker checker.py --output examples

The first packet must print ACCEPT and return 0. The second must print
REJECT and return a nonzero exit status.

To compile another supplied closed source proof:
  python3 examples/produce_clausal.py --checker checker.py \
    --proof examples/clausal_identity_proof.json \
    --prefix recompiled --output examples

Only Python's standard library is needed. The compiler is not imported
by the checker and is not part of the trusted acceptance program.

THE CLOSED THEOREM
------------------
Let
  B(y) := I(y,0;u.Su)=y,
  Q_y B(y) := D_{w,y}B(y), with w absent from B.

The delivered theorem is the D-only formula
  D_{w,y}(I(y,0;u.Su)=y).

Its ordinary meaning is B(0) -> forall y B(y), since w is vacuous.
B(0) is a computation theorem, so this is equivalent to the ordinary
universal identity forall y I(y,0;u.Su)=y. It is a quantified logical
theorem, not merely one closed numerical computation.

THE SOURCE DERIVATION
---------------------
1. Introduce D with witness 0. DI supplies ordinary assumptions B(0)
   and B(j), where j is a fresh induction parameter.

2. Apply Use to the constant clause for B(j), using the fixed computation
   theorem H as its premise. This yields I(j,0;u.Su)=j.

3. The successor computation schema gives
      I(Sj,0;u.Su)=S I(j,0;u.Su).
   Transport using the equation in step 2 and the motive
      I(Sj,0;u.Su)=S x
   gives B(Sj). DI therefore proves D_{w,y} B(y).

4. Eliminate this D formula. Because w is absent, the new clause is
      < B(0) ; y.B(y) >.
   Its fresh existential parameter a does not occur in that clause.

5. Reintroduce the same D formula with witness 0 and fresh parameter n.
   The ordinary base assumption B(0) is available. Apply Use to the
   closure clause at S n, with that base assumption as its premise.
   This supplies B(Sn), so the introduction and the elimination close.

This source tree exercises all four inference patterns: Use, DI, DE,
and transport. The delivered packet has six instructions. The backend's
fresh labels are j=-1, a=-2, and n=-3. An auxiliary unary Q formula
appears in the certificate annotation that implements the closure Use;
it is not a source-language primitive.

THE NEGATIVE CONTROL
--------------------
The second packet retains all six instructions but changes the target to
  D_{w,y}(I(y,0;u.Su)=0).
Its base is true, but its instance at y=1 is false. The backend rejects
it because the supplied closure cannot be specialized to that target.
The negative control is a finite executable check, not a substitute for
the general soundness proof.

The compiler check script also verifies four targeted variants: automatic
hypothesis short-circuiting of a redundant computation subtree, a
non-atomic DI matrix, a nonvacuous existential witness, and transport
under a D binder of an image containing its own iterator binder. The
last case checks the producer's capture-avoiding raw encoding.

COMPILER SCOPE AND FORMAT
------------------------
The compiler implements all four rules and both computation schemas for
closed proofs whose starting context is empty. Every local clause in
such a proof is introduced by DI or DE, so its provenance is available.
Arbitrary externally supplied initial clause contexts are not supported.

The input is an object with "goal" and "proof". The formula constructors
are ["=",s,t] and ["D",x,y,B]. Terms are ["0"], ["v",name],
["s",t], and ["i",n,a,u,h]. The latter binds u only in h. All source
proof variables are named. Proof eigenparameter names must be globally
distinct and disjoint from term/formula binder names. Active clause
identifiers must be distinct. The reserved transport placeholder is "$";
"unused" is reserved for the binder of a constant context clause.
These are explicit alpha-renaming conventions, not extra logical axioms.

Rule objects are illustrated completely in clausal_identity_proof.json:
  Computation: no additional fields.
  Use: clause, at, premise.
  DI: witness, eigen, base, induction, step.
  DE: major_formula, major, eigen, clause, minor.
  Tr: equation, motive, major, source.

The induction field of DI names its optional ordinary equation hypothesis;
that entry is added only if the opened matrix is literally an equation.
The compiler performs useful consistency checks but is not a complete
validator of source proof trees. Its contract is to compile well-scoped
valid source proofs. Every emitted packet is checked by the standalone
backend; an invalid input cannot make that backend accept a false theorem.

COMPILATION INVARIANT
--------------------
An ordinary context clause <H;y.F> is represented by auxiliary assumption
F. A canonical clause <B(0);y.B(y)> opened by DE is represented by auxiliary
assumption Q_y B(y). Clause origins are kept as tagged context entries,
even when two clauses happen to have the same displayed expressions.

Use of an ordinary clause compiles to the backend's hypothesis case. Its
proof of H can be erased because H has a fixed computation proof. Use of
a canonical closure clause compiles to QE, whose major premise is the
auxiliary Q hypothesis and whose minor premise is the compiled base proof.
DI, DE, computation and transport compile directly.

The backend tries hypotheses before consuming an instruction. Accordingly,
the compiler first checks whether the current target is already an ordinary
auxiliary assumption. If it is, it erases the entire proposed proof subtree
and emits no instruction. Failing to implement this short circuit can leave
an instruction unconsumed and corrupt the rest of a packet. Allocation of
fresh labels follows exactly the backend's actual traversal, including
these erasures.

An induction on the source proof establishes the rule translation; an
induction on the emitted trace establishes the raw encoding invariant.
This compiler and its examples are executable demonstrations. No machine-
checked proof of the compiler metatheorem is claimed.

ATTRIBUTION
-----------
The scalar iteration basis, five-rule auxiliary calculus, and canonical
raw scope encoding come from the supplied ProveIt drafts. The D-only
clausal presentation and this compiler are new work for the present
report. No inherited fixture or producer source was copied into this
directory. The iterator identity is a standard induction example; no
novelty claim is made for the arithmetic theorem itself.
