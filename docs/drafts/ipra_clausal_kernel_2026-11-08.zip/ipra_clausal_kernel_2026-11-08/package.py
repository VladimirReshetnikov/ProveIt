"""Create a clean ZIP with a content checksum manifest; omit build intermediates."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent


def included(path):
    relative = path.relative_to(ROOT)
    return (path.is_file() and not any(part.startswith('.') or part == '__pycache__'
                                      for part in relative.parts)
            and path.suffix not in {'.pyc', '.aux', '.log', '.toc', '.out', '.fdb_latexmk', '.fls'})


def main():
    files = sorted(path for path in ROOT.rglob('*') if included(path)
                   and path.name != 'SHA256SUMS.txt')
    manifest = ROOT / 'SHA256SUMS.txt'
    manifest.write_text(''.join(hashlib.sha256(path.read_bytes()).hexdigest()
                                + '  ' + path.relative_to(ROOT).as_posix() + '\n'
                                for path in files))
    target = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in sorted(files + [manifest]):
            info = zipfile.ZipInfo((Path(ROOT.name) / path.relative_to(ROOT)).as_posix(),
                                   date_time=(2026, 11, 8, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED,
                             compresslevel=9)
    print(target)


if __name__ == '__main__':
    main()
