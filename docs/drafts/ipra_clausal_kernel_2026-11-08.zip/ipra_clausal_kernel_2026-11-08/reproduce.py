"""Recompute the comparison, run validation and the example, then build the PDF."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    commands = [
        ['comparison/measure.py'],
        ['validation/validate.py'],
        ['examples/produce_clausal.py', '--checker', 'checker.py', '--output', 'examples'],
        ['examples/check_compiler.py', '--checker', 'checker.py', '--output', 'examples'],
        ['build.py'],
    ]
    for arguments in commands:
        subprocess.run([sys.executable, *arguments], cwd=ROOT, check=True)
    print('Reproduction passed: metrics, finite validation, clausal example, PDF.')


if __name__ == '__main__':
    main()
