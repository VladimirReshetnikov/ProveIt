VALIDATION AND CONTRIBUTION BOUNDARIES
====================================

Run from any working directory:
  python3 /absolute/path/to/package/comparison/measure.py
  python3 /absolute/path/to/package/validation/validate.py

The first command checks the hashes of the ten pinned baseline checkers and
recomputes all whole-program measurements. It reports the delivered comparison,
the common-name comparison (inst/check -> sub/test), and the comparison with
both common names and an identical complete stdin/verdict driver.

The second command checks the delivered checker.py against two independent
comparators: the frozen compact retained-label checker and a named-rule oracle
with separate term/formula visitors. Only the oracle's formula-leaf behavior
is specialized here to the inherited retained-label profile. The oracle does
not import the production checker.

The current run covers 147 inherited positive certificates; 18 focused packet
cases; 1,088 opening cases across sort, scope, image and scalar aliases; 588
mutations of the positive certificates; and 256 small random malformed packets.
All five native inference patterns and both computation schemas are exercised.
Two focused accepted cases exercise failed-major fallthrough, including a
case in which the failed major already consumed instructions and allocated
fresh parameters. Their final allocation floors are -1 and -3 respectively.
Fifty-two actual subprocess invocations check normal and python -O operation,
stdout, rejection exit status and JSON/parser failures. The results are in
results/validation.json and results/measurements.json.

No tests, compiler, oracle or measurement code is imported by checker.py.
Finite tests are not a universal soundness proof or a formal verification in
Lean/Rocq. The universal reduction argument is in equivalence.txt and the report.
Python recursion/memory limits may reject sufficiently large valid proofs.

PROVENANCE

positive_certificates.json, oracle_erasure.py, provenance.json and
LICENSE-inherited.txt are copied unchanged from the pinned current archive
ipra_compact_kernel_2026-11-07.zip, validation/validation_sources/. That archive
retains the earlier origins of both the oracle and the 147-certificate corpus.
The fixed fixture hashes are recorded in the validation result.

validate.py, focused_cases.json and this explanatory note are newly prepared
for this package. The oracle specialization RetainedOracle is explicitly
visible in validate.py; it is the same profile specialization already used by
the compact-kernel archive's validation/validate_profiles.py. No claim is made
that this specialization or the inherited positive proofs are new mathematics.
