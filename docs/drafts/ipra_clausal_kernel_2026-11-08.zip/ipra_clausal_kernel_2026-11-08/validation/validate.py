"""Finite independent-oracle and public-boundary checks of the delivered files.

The oracle uses separate term/formula visitors and named rules. It imports no
production checker. Passing this suite is evidence, not a soundness theorem.
"""
import ast
from collections import Counter
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import random
import subprocess
import sys

import oracle_erasure

ROOT = Path(__file__).resolve().parent.parent
HERE = ROOT / 'validation'
BASELINE = ROOT / 'comparison' / 'baselines' / 'ipra_compact_kernel_2026-11-07__checker_retained.py'
RULES = {'hypothesis', 'paired_introduction', 'paired_elimination',
         'closure_elimination', 'equality_transport',
         'computation_zero', 'computation_successor'}


class RetainedOracle(oracle_erasure.Oracle):
    def formula(self, value, image=None, protected=0):
        if type(value) is not list:
            return value if self.lower <= value < 2 * protected else 0
        return super().formula(value, image, protected)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def definitions(path):
    tree = ast.parse(path.read_text())
    boundary = next(i for i, node in enumerate(tree.body) if isinstance(node, ast.Try))
    tree.body = tree.body[:boundary]
    namespace = {}
    exec(compile(tree, str(path), 'exec'), namespace)
    return namespace


def trace(namespace, packet):
    stack = deepcopy(packet)
    namespace['k'] = 0
    function = namespace.get('test', namespace.get('check'))
    try:
        namespace['take'] = stack.pop
        accepted = bool(function(stack.pop(), []))
    except Exception:
        accepted = False
    return accepted, namespace['k'], len(stack) if type(stack) is list else None


def opening(namespace, value, image, depth, floor):
    namespace['k'] = floor
    function = namespace.get('sub', namespace.get('inst'))
    try:
        return True, function(value, image, depth)
    except Exception:
        return False, None


def oracle_opening(oracle, value, image, depth, floor):
    oracle.lower = floor
    try:
        function = oracle.term if depth % 2 else oracle.formula
        return True, function(value, image, depth // 2)
    except Exception:
        return False, None


def focused_cases():
    false_major = [[[0], 0, [0]], 0]
    paired_truth = [[0, 0], [0, 0], [0, 0]]
    return [
        ('zero_computation', [[], [[0, 0, 0], 0]], True),
        ('successor_computation', [[], [[[0], 0, [0]], [0]]], True),
        ('false_successor_computation', [[], false_major], False),
        ('null_formula_annotation', [[], [[0, 0, [None, None]], 0]], False),
        ('string_formula_annotation', [[], [[0, 0, ['x', '']], 0]], False),
        ('object_formula_annotation', [[], [[0, 0, [{}, {'': 7}]], 0]], False),
        ('numeric_formula_annotation', [[], [[0, 0, [1, 3]], 0]], True),
        ('out_of_scope_formula_annotation', [[], [[0, 0, [-50, 50]], 0]], True),
        ('empty_constructor_alias', [[], [[[], [], []], []]], True),
        ('false_equation_introduction', [0, [[0], 0]], False),
        ('empty_packet', [], False),
        ('null_goal', [0, None], False),
        ('string_goal', [0, 'abc'], False),
        ('future_parameter_in_goal', [[], [[0, -1, 0], -1]], False),
        ('excessive_constructor_arity', [[], [[0, [0, 0, 0, 0], 0], [0, 0, 0, 0]]], False),
        ('unused_prefix_is_inert', [{'unread': None}, [], [[0, 0, 0], 0]], True),
        ('failed_major_falls_through', [[], [false_major, 0], paired_truth], True),
        ('failed_major_keeps_allocations', [[], 0, [paired_truth, 0], [false_major, 0], paired_truth], True),
    ]


def cli(path, payload, expected, optimized):
    command = [sys.executable, *(['-O'] if optimized else []), str(path)]
    run = subprocess.run(command, input=payload, text=True, capture_output=True, timeout=15)
    observed = run.stdout, run.returncode, run.stderr
    wanted = ('ACCEPT\n', 0, '') if expected else ('REJECT\n', 1, '')
    if observed != wanted:
        raise AssertionError(('public CLI', path.name, optimized, observed, wanted))


def main():
    primary = ROOT / 'checker.py'
    start_hash = sha(primary)
    candidate, baseline = definitions(primary), definitions(BASELINE)
    oracle = RetainedOracle(1)
    fixture = HERE / 'positive_certificates.json'
    records = json.loads(fixture.read_text())['records']
    focused = focused_cases()
    (HERE / 'focused_cases.json').write_text(json.dumps(
        [{'name': n, 'packet': p, 'expected': e} for n, p, e in focused], indent=2) + '\n')
    rule_counts = Counter()
    covered = set()
    cli_fixtures = []
    counts = Counter()
    observations = []

    def compare(packet, expected=None):
        actual = trace(candidate, packet)
        before = trace(baseline, packet)
        independent = oracle.run(packet)
        wanted = independent['accepted'], independent['final_k'], independent['remaining']
        if actual != before or actual != wanted:
            raise AssertionError(('differential/oracle', actual, before, wanted, packet))
        if expected is not None and actual[0] != expected:
            raise AssertionError(('expected verdict', actual, expected, packet))
        if actual[0]:
            rule_counts.update(independent['rules'])
        return actual, independent

    for record in records:
        actual, independent = compare(record['packet'], True)
        useful = RULES.intersection(independent['rules']) - covered
        if useful:
            cli_fixtures.append(record)
            covered.update(useful)
        counts['canonical_positive_packets'] += 1
    for name, packet, expected in focused:
        actual, independent = compare(packet, expected)
        observations.append({'name': name, 'trace': list(actual), 'rules': independent['rules']})
        counts['focused_packets'] += 1

    values = [None, False, True, -3, -2, -1, -.25, 0, .25, 1, 1.9, 2, 3, 4,
              5, 7, 50, '', 'x', {}, {'': 0}, [], [0], [None], [None, None],
              [1, 3], [[None]], [3, 3, 3], [0, [0]], [[1, 3], 0, 1],
              [0, 0, 0, 0], float('inf'), float('-inf'), float('nan')]
    for value in values:
        for image in (None, 0, [0], [0, 0]):
            for depth, floor in ((0, 0), (0, -2), (1, 0), (1, -2),
                                 (2, 0), (3, -2), (4, -2), (5, 0)):
                actual = opening(candidate, value, image, depth, floor)
                before = opening(baseline, value, image, depth, floor)
                wanted = oracle_opening(oracle, value, image, depth, floor)
                if actual != before or actual != wanted:
                    raise AssertionError(('opening', value, image, depth, floor, actual, before, wanted))
                counts['focused_openings'] += 1

    generator = random.Random(20261108)
    leaves = [-3, -1, 0, 1, 4, 50, None, False, 'x', {}, -.25]

    def tree(depth=2):
        if not depth or generator.randrange(3) == 0:
            return deepcopy(generator.choice(leaves))
        return [tree(depth - 1) for _ in range(generator.randrange(6))]

    for record in records:
        for _ in range(4):
            changed = deepcopy(record['packet'])
            changed[generator.randrange(len(changed))] = tree(3)
            compare(changed)
            counts['mutated_fixture_packets'] += 1
    for _ in range(256):
        compare([tree() for _ in range(generator.randrange(8))])
        counts['random_malformed_packets'] += 1
    if not RULES.issubset(rule_counts) or not rule_counts['failed_major_fallthrough']:
        raise AssertionError(('missing inference coverage', dict(rule_counts)))

    for _, packet, expected in focused:
        for optimized in (False, True):
            cli(primary, json.dumps(packet), expected, optimized)
            counts['primary_cli_runs'] += 1
    for record in cli_fixtures:
        for optimized in (False, True):
            cli(primary, json.dumps(record['packet']), True, optimized)
            counts['primary_cli_runs'] += 1
    for payload in ('{', 'null', '{}', '0', 'true', '[]', '"x"'):
        for optimized in (False, True):
            cli(primary, payload, False, optimized)
            counts['malformed_cli_runs'] += 1

    if sha(primary) != start_hash:
        raise ValueError('Checker changed during validation')

    result = {'status': 'PASS', 'python': sys.version.split()[0],
              'candidate_sha256': start_hash,
              'baseline_sha256': sha(BASELINE), 'oracle_sha256': sha(HERE/'oracle_erasure.py'),
              'fixture_sha256': sha(fixture), 'runner_sha256': sha(Path(__file__)),
              'counts': dict(counts), 'accepted_rule_counts': dict(rule_counts),
              'focused_observations': observations,
              'cli_fixture_names': [record['name'] for record in cli_fixtures],
              'seed': 20261108,
              'compared_trace': ['acceptance', 'final_parameter_floor', 'remaining_packet_cells'],
              'limitations': 'Finite validation, not a universal soundness proof or a Lean/Rocq formalization. Expression refactoring adds no Python call frame; finite recursion/memory limits can still reject sufficiently large valid certificates.'}
    (ROOT/'results'/'validation.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
