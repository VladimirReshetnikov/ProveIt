"""Build the complete PDF from the included mathematical sources."""
from pathlib import Path
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def write_table():
    report = json.loads((ROOT / 'results/measurements.json').read_text())
    labels = {
        'ipra_arithmetic_scopes_2026-11-07.zip': 'Arithmetic scopes',
        'ipra_arity_scopes_2026-11-07.zip': 'Arity scopes',
        'ipra_compact_kernel_2026-11-07.zip': 'Compact kernel',
        'ipra_permanent_zero_2026-11-07.zip': 'Permanent zero',
        'ipra_validated_erasure_2026-11-07.zip': 'Validated erasure',
    }
    variants = {'checker.py': 'Main', 'checker_scalar.py': 'Scalar',
                'checker_direct.py': 'Direct', 'checker_compact.py': 'Compact',
                'checker_retained.py': 'Retained'}
    rows = [r'\begin{center}', r'\begin{tabular}{@{}llrrr@{}}', r'\toprule',
            r'Current archive & Variant & Tokens & AST nodes & Bytes\\', r'\midrule']
    for entry in report['baselines']:
        value = entry['measurements']['as_delivered']
        rows.append('{} & {} & {} & {} & {}\\\\'.format(
            labels[entry['archive']], variants[entry['member'].split('/')[-1]],
            value['normalized_tokens'], value['ast_nodes'], value['normalized_bytes']))
    rows.extend([r'\midrule', r'New certificate kernel & Primary &326&351&938\\',
                 r'\bottomrule', r'\end{tabular}', r'\end{center}'])
    (ROOT / 'results/current_table.tex').write_text('\n'.join(rows) + '\n')


def main():
    write_table()
    destination = ROOT / '.build'
    destination.mkdir(exist_ok=True)
    if shutil.which('latexmk'):
        command = ['latexmk', '-pdf', '-interaction=nonstopmode',
                   '-halt-on-error', '-file-line-error', '-outdir=.build', 'report.tex']
        subprocess.run(command, cwd=ROOT, check=True)
    else:
        command = ['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
                   '-file-line-error', '-output-directory=.build', 'report.tex']
        for _ in range(3):
            subprocess.run(command, cwd=ROOT, check=True)
    shutil.copy2(destination / 'report.pdf', ROOT / 'report.pdf')
    print(ROOT / 'report.pdf')


if __name__ == '__main__':
    main()
