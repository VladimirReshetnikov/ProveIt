#!/usr/bin/env python3
"""Finite syntax, rewrite, metric and numerical checks; not a PRA proof assistant."""
import json,hashlib,pathlib

def V(s):return ('v',s)
Z=('zero',)
def S(x):return ('S',x)
O=S(Z);T=S(O)
def P(x,a):return ('P',x,a)
def B(x,a):return ('B',x,a)
def M(x,a):return ('M',x,a)
def R(x,a):return ('R',x,a)
def p(x):return P(x,Z)
def C(z,u,v):return P(B(z,S(u)),v)
def rh(n,a,v):return C(a,Z,S(C(n,S(p(p(a))),v)))
def size(t):return 1 if t[0] in ('v','zero','bottom') else 1+sum(size(x) for x in t[1:])
def check(c,m):
 if not c:raise ValueError(m)
def root(t):
 if t[0] not in ('P','B','M','R'):return None
 tag,n,a=t
 if n==Z:return a
 if n[0]!='S':return None
 k=n[1]
 if tag=='P':return k
 if tag=='B':return Z
 if tag=='M':return M(k,p(a))
 return rh(k,a,R(k,p(a)))
def norm(t,fuel=10000):
 if fuel<0:raise ValueError('rewrite limit')
 r=root(t)
 if r is not None:return norm(r,fuel-1)
 if t[0] in ('v','zero','bottom'):return t
 u=(t[0],*(norm(x,fuel-1) for x in t[1:]))
 r=root(u)
 return norm(r,fuel-1) if r is not None else u

def evaluate(t,e):
 if t[0]=='v':return e[t[1]]
 if t==Z:return 0
 if t[0]=='S':return evaluate(t[1],e)+1
 tag=t[0];n=evaluate(t[1],e);a=evaluate(t[2],e)
 if tag=='P':return a if n==0 else n-1
 if tag=='B':return a if n==0 else 0
 if tag=='M':
  # Actual initialized substituted recursion, not left-iteration assumption.
  for _ in range(n):a=max(a-1,0)
  return a
 if tag=='R':
  # Descend parameters, then fold h upward; implements the literal recurrence.
  trace=[];c=n;y=a
  while c:
   c-=1;trace.append((c,y));y=max(y-1,0)
  v=y
  for k,b in reversed(trace):
   v=evaluate(rh(V('counter'),V('parameter'),V('state')),{'counter':k,'parameter':b,'state':v})
  return v
 raise ValueError(tag)

n,a,x,y,v=[V(s) for s in ['n','a','x','y','v']]
results={}
equalities={
 'selector_zero':(C(Z,x,y),x),
 'selector_successor':(C(S(n),x,y),y),
 'R11':(R(O,O),T),
 'R21':(R(T,O),O),
 'R_positive_diagonal_step':(R(S(S(n)),S(S(n))),S(R(S(n),S(n)))),
 'M_shift':(M(S(x),S(y)),M(x,y)),
 'q_stationarity':(M(S(n),S(n)),M(n,n)),
 'd_stationarity':(M(S(S(n)),R(S(S(n)),S(S(n)))),M(S(n),R(S(n),S(n)))),
 'd_zero':(M(O,R(O,O)),O)}
for name,(l,r) in equalities.items():check(norm(l)==norm(r),name)
results['symbolic_computation_equalities']=list(equalities)
results['descriptor_nodes']={'P_h':1,'P_k':1,'B_h':1,'B_k':1,'M_h':1,'M_k':size(p(a)),'R_h':size(rh(n,a,v)),'R_k':size(p(a))}
check(results['descriptor_nodes']['R_h']==17,'bump descriptor')
check(sum(results['descriptor_nodes'].values())==28,'selected bodies')
# Formula trees: bound-variable names are labels, not additional term nodes.
def F(tag,*args):return (tag,*args)
eq=lambda l,r:F('eq',l,r)
all_=lambda t:F('all',t)
imp=lambda l,r:F('imp',l,r)
orr=lambda l,r:F('or',l,r)
fn=lambda k:F('f',k,a)
I=lambda k,b:F('I',k,b)
g=lambda b:F('g',b)
k=lambda b:F('k',b)
h=lambda c,b,w:F('h',c,b,w)
d0new=all_(eq(I(Z,a),a));d0old=all_(eq(I(Z,a),g(a)))
ds=all_(all_(eq(I(S(n),a),h(n,a,I(n,k(a))))))
fixed=all_(all_(orr(eq(R(x,y),y),eq(x,y))))
ss=all_(imp(all_(eq(fn(S(n)),fn(n))),all_(imp(eq(S(fn(n)),fn(Z)),F('bottom')))))
results['formula_nodes']={'D0_new':size(d0new),'D0_old':size(d0old),'DS':size(ds),'O_star':size(fixed),'SS':size(ss)}
check(results['formula_nodes']=={'D0_new':6,'D0_old':7,'DS':14,'O_star':11,'SS':22},'formula metric')
results['totals']={'new':size(d0new)+size(ds)+size(fixed)+size(ss),'old':size(d0old)+size(ds)+size(fixed)+size(ss)}
check(results['totals']=={'new':53,'old':54},'totals')
count=0
for i in range(33):
 for j in range(33):
  val=evaluate(R(x,y),{'x':i,'y':j})
  expected=j+1 if i==j and i>0 else j
  check(val==expected,'bump semantics')
  err=B(M(S(y),R(S(x),S(y))),O)
  check(evaluate(err,{'x':i,'y':j})==(0 if i==j else 1),'error bit')
  count+=1
results['finite_diagnostics']={'pairs':count,'range':'0 through 32','claims':'standard values only, not a universal proof'}
# Negative control: omitting one successor from the special first-step bump
# destroys R(1,1)=2. This is a literal recurrence sanity check.
bad_first=1+max(1-2,0)
check(bad_first!=2,'negative control')
results['negative_control']='single-S first-step bump rejected'
base=pathlib.Path(__file__).resolve().parents[1]
manifest=json.loads((base/'source_manifest.json').read_text())
results['source_git_blobs']={}
for item in manifest:
 data=(base/'prior'/item['file']).read_bytes()
 sha=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 check(sha==item['git_blob_sha1'],'source Git hash')
 check(hashlib.sha256(data).hexdigest()==item['sha256'],'source SHA256')
 results['source_git_blobs'][item['file']]=sha
print(json.dumps(results,indent=2))
