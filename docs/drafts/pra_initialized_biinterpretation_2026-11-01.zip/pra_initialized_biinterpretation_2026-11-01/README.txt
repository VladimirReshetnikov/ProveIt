A smaller initialized basis for primitive recursive arithmetic
1 November 2026

RESULT
A common nonlogical basis for classical and intuitionistic first-order PRA,
with explicit matching-logic bi-interpretations and both provable round trips.
The initialized substitution grammar removes the arbitrary base descriptor.
Its fixed relative-value law uses a specified bump program, not an equality
oracle or an unspecified operation.

MEASURED IMPROVEMENT AND COST
At one displayed parameter, computation plus arithmetic templates cost
53 formula-tree nodes versus 54 for the smallest display among six current drafts.
Selected stored descriptor bodies grow from 19 to 28 nodes. Summing those
ledgers gives 81 versus 73: this is not a win under every measure, and no
absolute shortestness or historical-priority claim is made.

ADDITIONAL RESULTS
- A presentation with native equality and one quaternary relation, with
  constructive decoding and identity round trips; not a shorter total encoding.
- No genuinely finite first-order axiom set is bi-interpretable with PRA,
  classically or intuitionistically. This does not rule out finite schemata.

CONTENTS
report.tex / report.pdf                 Main article
roundtrips.tex                         Compilation, uniqueness, converse proofs
alternate_signature.tex                One-relation bi-interpretation
finite_axioms.tex                      Finite-axiomatization obstruction
axioms.txt                            Exact recommended specification
source_manifest.json                  Six source archives and exact hashes
prior/*.zip                           Unchanged compared source archives
artifacts/check.py                    Executable finite checks
artifacts/check-results.json          Reproduced output
build.sh                              Normal TeX Live build command
VALIDATION.txt                        Verification scope
SHA256SUMS                            Final payload hashes

REPRODUCE
Run from this directory with Python 3 and a normal TeX Live installation:
  python3 artifacts/check.py
  sh build.sh
The report uses the packages listed in report.tex. No shell escape is needed.
The checker never executes downloaded source code.

VERIFICATION LIMITS
Symbolic rewriting, syntax metrics, source hashes and bounded numerical
checks are executable. The universal mathematical statements and proof
translations are written proofs with independent mathematical review, not
newly checked Lean/Rocq certificates. Formal logs in prior archives belong
to those original papers and were not rerun. No upstream edits were made.
