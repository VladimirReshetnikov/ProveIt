"""Recount pinned complete proof-checker sources without importing or running them.

The lexical convention is the original-source convention used by the supplied
universal-kernel measure.py. Every local dependency and adapter is charged.
This script and the census are untrusted comparison tools, not proof-checker code.
"""

import argparse
import ast
import csv
import hashlib
import io
import json
from pathlib import Path
import sys
import tokenize

ROOT = Path(__file__).resolve().parent
DOCOWNERS = (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
SUM_FIELDS = ("raw_bytes", "physical_lines", "significant_tokens",
              "token_characters", "ast_nodes", "normalized_bytes")
FRONTIER_FIELDS = ("raw_bytes", "normalized_bytes", "significant_tokens", "ast_nodes")


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def source_metrics(path):
    """Count original lexical tokens; AST unparse is used only for byte counts."""
    raw = path.read_bytes()
    source = raw.decode("utf-8")
    tree = ast.parse(source)
    spans = []
    for node in list(ast.walk(tree)):
        if isinstance(node, DOCOWNERS):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                doc = node.body.pop(0)
                spans.append(((doc.lineno, doc.col_offset),
                              (doc.end_lineno, doc.end_col_offset)))
    tokens = [token for token in tokenize.generate_tokens(io.StringIO(source).readline)
              if token.type not in IGNORED
              and not any(a <= token.start and token.end <= b for a, b in spans)]
    return {
        "raw_bytes": len(raw),
        "physical_lines": len(source.splitlines()),
        "significant_tokens": len(tokens),
        "token_characters": sum(len(token.string) for token in tokens),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "normalized_bytes": len((ast.unparse(tree) + "\n").encode("utf-8")),
        "sha256": digest(raw),
    }


def imported_modules(path):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                yield alias.name, 0
        elif isinstance(node, ast.ImportFrom):
            yield node.module or "", node.level


def dynamic_operations(path):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        f = node.func
        if ((isinstance(f, ast.Name) and f.id in {"__import__", "eval", "exec", "compile"})
                or (isinstance(f, ast.Attribute)
                    and f.attr in {"import_module", "spec_from_file_location"})):
            yield ast.unparse(node)


def local_path(name):
    path = (ROOT / name).resolve()
    if not path.is_relative_to(ROOT) or not path.is_file():
        raise ValueError("Missing or out-of-root source: " + name)
    return path


def dependency_closure(variant):
    """Audit static imports and explicitly configured inherited module selection."""
    declared = set(variant["files"])
    pending = [*variant["entrypoints"], *variant["manual_dependencies"]]
    seen, runtime, edges = set(), set(), []
    configured = {(item["source"], item["expression"]): item
                  for item in variant["dynamic_imports"]}
    encountered_dynamic = set()
    while pending:
        name = pending.pop()
        if name in seen:
            continue
        if name not in declared:
            raise ValueError((variant["id"], "undeclared trusted dependency", name))
        path = local_path(name)
        seen.add(name)
        for module, level in imported_modules(path):
            selected = variant["module_bindings"].get(module)
            target = selected
            if target is None:
                base = path.parent
                for _ in range(max(level - 1, 0)):
                    base = base.parent
                relative = Path(*module.split(".")) if module else Path()
                choices = [base / relative.with_suffix(".py"),
                           base / relative / "__init__.py"]
                candidate = next((p for p in choices if p.is_file()), None)
                if candidate is not None:
                    target = candidate.resolve().relative_to(ROOT).as_posix()
            if target is not None:
                pending.append(target)
                edges.append({"from": name, "module": module, "to": target,
                              "selection_alias": selected is not None})
            elif module.split(".")[0] in sys.stdlib_module_names or module == "__future__":
                runtime.add(module)
            else:
                raise ValueError((variant["id"], "unresolved nonstandard import", name, module))
        for expression in dynamic_operations(path):
            key = (name, expression)
            if key not in configured:
                raise ValueError((variant["id"], "unconfigured dynamic operation", key))
            item = configured[key]
            encountered_dynamic.add(key)
            pending.append(item["target"])
            edges.append({"from": name, "expression": expression, "to": item["target"],
                          "configuration": item["configuration"]})
    if seen != declared:
        raise ValueError((variant["id"], "dependency closure mismatch", sorted(seen), sorted(declared)))
    if encountered_dynamic != set(configured):
        raise ValueError((variant["id"], "unused dynamic-import configuration"))
    return {"files": sorted(seen), "standard_library_modules": sorted(runtime),
            "local_import_edges": edges, "closure_verified": True}


def totals(items):
    return {key: sum(item[key] for item in items) for key in SUM_FIELDS}


def frontier(rows):
    return {
        key: {
            "value": min(row[key] for row in rows),
            "variants": [row["id"] for row in rows
                         if row[key] == min(r[key] for r in rows)],
        }
        for key in FRONTIER_FIELDS
    }


def candidate_metrics(names):
    """Optional complete candidate source list; no unlisted local import is allowed."""
    paths = [Path(name).resolve() for name in names]
    if len(set(paths)) != len(paths):
        raise ValueError("A candidate source was supplied more than once")
    runtime = set()
    for path in paths:
        for module, level in imported_modules(path):
            base = path.parent
            for _ in range(max(level - 1, 0)):
                base = base.parent
            relative = Path(*module.split(".")) if module else Path()
            choices = [base / relative.with_suffix(".py"), base / relative / "__init__.py"]
            local = next((p.resolve() for p in choices if p.is_file()), None)
            if local is not None:
                if local not in paths:
                    raise ValueError("Unlisted candidate dependency: " + str(local))
            elif module.split(".")[0] in sys.stdlib_module_names or module == "__future__":
                runtime.add(module)
            else:
                raise ValueError("Unresolved candidate import: " + module)
        if list(dynamic_operations(path)):
            raise ValueError("Optional candidate comparison does not accept dynamic imports or execution")
    parts = [{"file": path.name, **source_metrics(path)} for path in paths]
    return {"files": parts, "standard_library_modules": sorted(runtime),
            "all_supplied_dependencies_charged": True, **totals(parts)}


def run(candidate=None, output=None):
    output = ROOT if output is None else Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((ROOT / "census.json").read_text(encoding="utf-8"))
    inherited = manifest["historical_manifest"]
    if digest(local_path(inherited["path"]).read_bytes()) != inherited["sha256"]:
        raise ValueError("Inherited provenance manifest hash mismatch")
    measured = {}
    for name, expected in sorted(manifest["files"].items()):
        actual = source_metrics(local_path(name))
        if actual["sha256"] != expected["sha256"] or actual["raw_bytes"] != expected["raw_bytes"]:
            raise ValueError("Pinned source hash or length mismatch: " + name)
        measured[name] = actual
    rows = []
    for variant in manifest["variants"]:
        dependency_audit = dependency_closure(variant)
        count = totals([measured[name] for name in variant["files"]])
        for key, expected in variant.get("historical_reference_totals", {}).items():
            if count[key] != expected:
                raise ValueError((variant["id"], "historical count mismatch", key, count[key], expected))
        signature = digest("\n".join(sorted(measured[name]["sha256"] for name in variant["files"])).encode())
        if signature != variant["content_signature"]:
            raise ValueError((variant["id"], "whole-source signature mismatch"))
        rows.append({"id": variant["id"], "label": variant["label"], "group": variant["group"],
                     "primary_recommendation": variant["primary_recommendation"],
                     "boundary": variant["boundary"], "semantics": variant["semantics"],
                     "duplicate_of": variant.get("duplicate_of"), "content_signature": signature,
                     "dependency_audit": dependency_audit, **count})
    unique = [row for row in rows if row["duplicate_of"] is None]
    scopes = {
        "current_primary": [row for row in unique if row["group"] == "current" and row["primary_recommendation"]],
        "current_including_controls": [row for row in unique if row["group"] == "current"],
        "historical_complete": [row for row in unique if row["group"] == "historical" and row["boundary"] == "complete_cli"],
        "all_complete": [row for row in unique if row["boundary"] == "complete_cli"],
        "all_including_favorable_api_only": unique,
    }
    result = {
        "repository": manifest["repository"], "current_snapshot": manifest["current_snapshot"],
        "historical_snapshot": manifest["historical_snapshot"], "python_version": sys.version,
        "counting": manifest["counting"], "boundary": manifest["boundary"],
        "scope": manifest["scope"], "limitations": manifest["limitations"],
        "observations": len(rows), "distinct_program_groups": len(unique),
        "source_paths": len(measured), "distinct_source_contents": len({x['sha256'] for x in measured.values()}),
        "all_source_hashes_verified": True, "all_dependency_closures_verified": True,
        "historical_original_counts_reproduced": True,
        "frontiers": {name: {"variant_count": len(items), "minima": frontier(items)}
                      for name, items in scopes.items()},
        "variants": rows, "source_measurements": measured,
    }
    if candidate:
        result["candidate"] = candidate_metrics(candidate)
        result["candidate_comparison"] = {
            name: {
                key: {
                    "candidate": result["candidate"][key], "minimum": values["minima"][key]["value"],
                    "at_or_below": result["candidate"][key] <= values["minima"][key]["value"],
                    "strictly_below": result["candidate"][key] < values["minima"][key]["value"],
                    "absolute_saving": values["minima"][key]["value"] - result["candidate"][key],
                    "percent_saving": round(100 * (values["minima"][key]["value"] - result["candidate"][key])
                                            / values["minima"][key]["value"], 6),
                }
                for key in FRONTIER_FIELDS
            }
            for name, values in result["frontiers"].items()
        }
    (output / "metrics.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    columns = ["id", "group", "primary_recommendation", "boundary", "duplicate_of",
               "raw_bytes", "normalized_bytes", "significant_tokens", "ast_nodes", "label"]
    with (output / "summary.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    lines = ["COMPLETE SOURCE COMPARISON", "", "Snapshot: " + manifest["current_snapshot"],
             "Python: " + sys.version.split()[0],
             "73 observations = 18 current + 55 inherited; 68 distinct whole-source groups.",
             "65 distinct complete CLI implementations; 3 additional favorable API-only groups.",
             "All 85 source paths hash-verified; all declared dependency closures verified.", "",
             "CURRENT PRIMARY IMPLEMENTATIONS", "",
             "ID | raw bytes | normalized bytes | original significant tokens | AST nodes"]
    for row in scopes["current_primary"]:
        lines.append(" | ".join(str(row[key]) for key in
                                ("id", "raw_bytes", "normalized_bytes", "significant_tokens", "ast_nodes")))
    lines += ["", "COORDINATEWISE MINIMA", "",
              "These minima need not be attained by one program."]
    for key, item in result["frontiers"]["all_including_favorable_api_only"]["minima"].items():
        lines.append(key + ": " + str(item["value"]) + " (" + ", ".join(item["variants"]) + ")")
    if candidate:
        lines += ["", "OPTIONAL CANDIDATE", json.dumps(result["candidate"], indent=2)]
    lines += ["", "ALL DISTINCT SOURCE GROUPS", "",
              "ID | boundary | raw bytes | normalized bytes | original significant tokens | AST nodes"]
    for row in unique:
        lines.append(" | ".join(str(row[key]) for key in
                                ("id", "boundary", "raw_bytes", "normalized_bytes", "significant_tokens", "ast_nodes")))
    lines += ["", "BYTE-IDENTICAL WHOLE-SOURCE ALIASES"]
    lines += [row["id"] + " = " + row["duplicate_of"] for row in rows if row["duplicate_of"] is not None]
    lines += ["", manifest["counting"], "", manifest["limitations"]]
    (output / "SUMMARY.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    brief = {"observations": result["observations"], "distinct_program_groups": len(unique),
             "complete_cli_variants": len(scopes["all_complete"]), "source_paths": len(measured),
             "all_hashes_and_dependency_closures_verified": True,
             "coordinatewise_minima": result["frontiers"]["all_including_favorable_api_only"]["minima"]}
    if candidate:
        brief["candidate"] = result["candidate"]
        brief["candidate_comparison"] = result["candidate_comparison"]["all_including_favorable_api_only"]
    print(json.dumps(brief, indent=2))
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", action="append", help="Optional candidate source; repeat to charge every trusted local dependency")
    parser.add_argument("--output", type=Path, help="Output directory; defaults to this comparison directory")
    args = parser.parse_args()
    run(args.candidate, args.output)
