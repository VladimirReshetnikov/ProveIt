PORTABLE iPRA CHECKER SOURCE COMPARISON
6 November 2026
====================================

PURPOSE

This directory preserves and recounts the complete trusted source of the
current six ProveIt draft recommendations, twelve meaningful nonduplicate
current controls, and the 55 source groups catalogued in their inherited
comparison corpus. It is an offline comparison artifact, not a proof checker.
Measurement parses sources but NEVER imports or executes benchmark programs.

The current source snapshot is:
  https://github.com/VladimirReshetnikov/ProveIt/tree/39c2b3c738e4cacbc0b2cb31f093c1eb4f976e75/docs/drafts

The historical corpus is attributed to snapshot:
  b079e5787b1d708049ff0643ce1b534c1a225198

All six current ZIPs were checked against their Git blob SHA-1 identifiers.
Each copied Python file was taken from those exact ZIP bytes. Historical
sources were recovered from the current shared-eliminator ZIP and checked
against its declared original source SHA-256 values; this package does not
claim a fresh independent download of the historical ZIPs. census.json gives
the complete chain: current ZIP identity, member path, historical attribution
where applicable, final local path, and exact source hash. Original source
bytes, including comments and docstrings, are retained without modification.

CONTENTS

  measure.py                   Reproducible, standard-library-only measurement
  census.json                  Source groups, provenance, selected dependencies
  source_files.sha256           Hash list of every copied Python source
  sources/current/              Six main kernels and twelve additional controls
  sources/inherited/            Exact sources of the 55 inherited source groups
  provenance/inherited_manifest.json
                               Verbatim inherited 55-group metadata
  metrics.json                 Full counts, per-file data, dependency audit
  summary.csv                  One row per source-group observation
  SUMMARY.txt                  Main table, complete inventory, and minima

REPRODUCE

Python 3.10 or later is sufficient; ast.unparse output can depend on Python
version, so metrics.json records the version actually used. Run from any
working directory:

  python3 /path/to/comparison/measure.py

To include a new standalone candidate:

  python3 /path/to/comparison/measure.py --candidate /path/to/checker.py

Repeat --candidate for each trusted local dependency if the candidate has
multiple files. Every supplied file is charged. Unlisted local imports,
unresolved nonstandard imports, and candidate dynamic execution are rejected.
The candidate is parsed and measured but never executed. Use --output DIR
to keep generated metrics separate from this directory.

The script rechecks every source hash and exactly follows the declared local
dependency closure before counting. All 55 inherited original token/AST/raw
counts are independently recomputed and compared to their preserved records.

INVENTORY AND DEDUPLICATION

There are 73 observations: 18 current implementations and 55 historical source
groups. Five historical observations are byte-identical whole-source aliases;
the census labels them with duplicate_of rather than count them twice in
frontier scope sizes. This leaves 68 distinct whole-source groups: 65 complete
CLI implementations and three favorable API-only comparators. The 85 source
paths represent 80 distinct byte sequences. Duplicate path copies preserve
the original directory/module namespaces; a source is charged only once per
implementation.

The main checked-presentation program's embedded new_schema copy is recorded
as an additional byte-identical observation and is not measured twice. Exact
old baseline copies in the current archives are already represented by the
historical corpus. They are not artificial additional implementations.

For several historical alternatives, an unchanged adapter imports a selected
implementation under module name kernel. The census explicitly records that
selection and charges both adapter and chosen implementation in full. These
source pairs are measured as the declared installed configuration; the script
does not silently follow the unrelated default kernel in the source tree.
One historical shared driver selects a module through its --kernel option.
Each allowed selected target and the dynamic-import expression are explicitly
listed and audited. API-only variants remain labeled and are excluded from
the complete-CLI scope, while retained in an additional conservative scope.

COUNTING CONVENTION

Significant tokens are tokenized from the ORIGINAL source. Comments, layout,
encoding/endmarker tokens, and genuine module/class/function first-statement
docstrings are excluded. Parentheses and every other executable lexical token
are included. This follows the supplied universal-kernel measurement method.

The corresponding docstrings are removed from the parsed AST, and every node
returned by ast.walk is counted. Normalized bytes count UTF-8 bytes of
ast.unparse of that same AST, followed by one newline. The normalized text is
used only for the byte metric; its token count is NOT substituted for the
original significant-token count. Raw bytes count the full original files.

Every selected trusted source file is charged, including validation, binding
operations, fixed schema data, encoders, error handling, imports, and JSON/CLI
adapters. Python and standard-library implementations are common external
dependencies. Proof-producing adapters, tests, reports, and this measurement
tool are not imported by the checked programs and are not counted as kernels.

RESULT

Across all 65 distinct complete implementations, and also when the three
favorable API-only groups are included, the observed coordinate minima are:

  Raw bytes:                    3817   current.witness.main
  Normalized executable bytes:  3486   current.witness.main
  Original significant tokens:  1089   current.checked.main
  AST nodes:                    1154   current.checked.main

These coordinates are attained by TWO programs. There is no fictitious single
reference checker that simultaneously has all four minimum values.

SCOPE AND SEMANTIC QUALIFICATIONS

This establishes a finite reproducible implementation comparison, not a
programming-language-independent shortest-checker theorem. Syntax and
dependency audits do not establish universal soundness of the historical
programs. Several positive or encoded presentations obtain ordinary
bi-interpretability only through their stated genuine-falsity realization;
the bare positive first-order reduct admits singleton models. These status
differences are retained in the census instead of silently treating all raw
positive calculi as ordinarily bi-interpretable theories.

Attribution: all reference implementations originate in the named ProveIt
archives and retain their exact source text. This new comparison artifact
combines their current and inherited inventories, verifies the complete
dependency closures, and applies a single original-source metric convention.
