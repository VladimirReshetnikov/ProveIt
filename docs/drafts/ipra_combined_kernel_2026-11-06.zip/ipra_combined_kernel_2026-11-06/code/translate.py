"""Untrusted proof translation from the pinned genuine-falsity K kernel.

Both input and output are checked separately. The production checker never
imports this translator. Lifting protects numerical proof binders and every
term/formula binder. Hypotheses are looked up by their actual formulas.
"""

import importlib.util
import json
from pathlib import Path
import sys

import checker as new

ROOT = Path(__file__).resolve().parent
BASELINE = ROOT.parent / 'comparison/baseline.py'
spec = importlib.util.spec_from_file_location('old_kernel', BASELINE)
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)


def syntax(a):
    if type(a) in (list, tuple):
        return new.ZERO if tuple(a) == old.ZERO else [syntax(b) for b in a]
    return a


def insert_number(a, protected=0):
    return new.walk(a, lambda i, d: i + d + 1, protected)


def lift(p, g, protected=0):
    """Insert a number between ambient variables and local proof binders."""
    def tree(a, extra=0):
        return insert_number(a, protected + extra)
    def sub(q, context=g, extra=0):
        return lift(q, context, protected + extra)
    match p:
        case ['hyp', a]:
            return ['hyp', tree(a)]
        case ['pi', a, q]:
            return ['pi', tree(a, 1), sub(q, [*map(new.shift, g), a], 1)]
        case ['use', p, a, q]:
            e = new.infer(p, g)
            tag = e[0]
            if tag == 'sig':
                return ['use', sub(p), tree(a), sub(q, [*map(new.shift, g), *e[1:]], 1)]
            return ['use', sub(p), tree(a, int(tag == '=')), sub(q)]
        case ['pair', t, p, q]:
            h = [*map(new.shift, g), ['=', 0, new.shift(t)]]
            return ['pair', tree(t), sub(p, h, 1), sub(q, h, 1)]
        case ['bridge', q]:
            return ['bridge', sub(q)]
        case ['rec', r]:
            return ['rec', tree(r)]
        case ['nat', a]:
            return ['nat', tree(a, 1)]
        case _:
            raise ValueError('unknown proof constructor')


def refl(t):
    p = ['rec', ['r', new.ZERO, t, new.ZERO]]
    return ['use', p, ['=', 0, new.shift(t)], p]


def symmetry(p, left):
    return ['use', p, ['=', 0, new.shift(left)], refl(left)]


def sigma_intro(a, t, p, q, g):
    """Translate ordinary Sigma introduction using a discharged y=t."""
    witness_equation = ['=', 0, new.shift(t)]
    backwards = symmetry(['hyp', witness_equation], 0)
    def branch(matrix, proof):
        return ['use', backwards, insert_number(matrix, 1), lift(proof, g)]
    return ['pair', t, branch(a[1], p), branch(a[2], q)]


def translate(p, g):
    ng = [syntax(a) for a in g]
    def sub(q, context=g):
        return translate(q, context)
    match p:
        case ('hyp', i):
            return ['hyp', ng[i]]
        case ('pi', a, q):
            return ['pi', syntax(a), sub(q, (*map(old.shift, g), a))]
        case ('app', p, t, q):
            return ['use', sub(p), syntax(t), sub(q)]
        case ('eq', p, a, q):
            return ['use', sub(p), syntax(a), sub(q)]
        case ('let', p, c, q):
            e = old.infer(p, g)
            return ['use', sub(p), syntax(c), sub(q, (*map(old.shift, g), *e[1:]))]
        case ('pair', a, t, p, q):
            return sigma_intro(syntax(a), syntax(t), sub(p), sub(q), ng)
        case ('bridge', q):
            return ['bridge', sub(q)]
        case ('rec', r):
            return ['rec', syntax(r)]
        case ('nat', a, t, p, q):
            na = syntax(a)
            base = new.inst(na, new.ZERO)
            h = na if na[0] == '=' else new.shift(base)
            extra = (a,) if a[0] == '=' else ()
            step = ['pi', h, sub(q, (*map(old.shift, g), *extra))]
            # Both proofs ignore the newly introduced witness equation.
            pair = ['pair', new.ZERO, lift(sub(p), ng), lift(step, ng)]
            return ['use', ['nat', na], syntax(t), pair]
        case _:
            raise ValueError('unknown old proof constructor')


def certificate(d):
    old.check(d)
    g = tuple(map(old.freeze, d['assumptions']))
    out = {'assumptions': [syntax(a) for a in g],
           'goal': syntax(old.freeze(d['goal'])),
           'proof': translate(old.freeze(d['proof']), g)}
    new.check(out)
    return out


if __name__ == '__main__':
    d = json.loads(Path(sys.argv[1]).read_text())
    out = certificate(d)
    Path(sys.argv[2]).write_text(json.dumps(out, separators=(',', ':')) + '\n')
