"""Focused acceptance/rejection checks, independent of the proof compiler."""
import copy
import json
from pathlib import Path
import checker

Z = -1
F = ['false']
D = ['=', Z, ['s', Z]]
T = ['=', Z, Z]


def document(g, a, p):
    return {'assumptions': g, 'goal': a, 'proof': p}


def cases():
    yield 'bridge_false_to_clash', True, document([F], D, ['bridge', ['hyp', F]])
    yield 'bridge_clash_to_false', True, document([D], F, ['bridge', ['hyp', D]])
    yield 'clash_not_assumed', False, document([], D, ['hyp', D])
    yield 'bridge_requires_exact_clash', False, document([T], F, ['bridge', ['hyp', T]])
    yield 'falsity_is_not_erased', False, document([F], D, ['hyp', F])
    yield 'no_refl_leaf', False, document([], T, ['refl', Z])
    r = ['r', Z, 4, ['s', 0]]
    yield 'rec_zero_parameter', True, document([], ['=', r, 4], ['rec', r])
    r = ['r', ['s', 4], 6, ['r', 1, 0, ['s', 2]]]
    expected = ['r', 4, ['r', 4, 6, ['r', 1, 0, ['s', 2]]], ['s', ['r', 6, 8, ['r', 1, 0, ['s', 2]]]]]
    yield 'rec_successor_nested_outer_state', True, document([], ['=', r, expected], ['rec', r])
    badr = ['r', 4, Z, 0]
    yield 'rec_unreduced_counter', False, document([], ['=', badr, Z], ['rec', badr])
    a = ['=', 0, 0]
    base = ['=', Z, Z]
    step = ['pi', a, ['=', ['s', 0], ['s', 0]]]
    expected = ['pi', ['sig', base, step], a]
    yield 'nat_equation_schema', True, document([], expected, ['nat', a])
    a = ['pi', ['=', 1, 1], F]
    base = ['pi', T, F]
    step = ['pi', base, ['pi', ['=', ['s', 1], ['s', 1]], F]]
    expected = ['pi', ['sig', base, step], a]
    yield 'nat_non_equation_has_base_guard', True, document([], expected, ['nat', a])
    wrong_step = ['pi', ['pi', ['=', 1, 1], F], ['pi', ['=', ['s', 1], ['s', 1]], F]]
    yield 'nat_rejects_quantified_induction', False, document([], ['pi', ['sig', base, wrong_step], a], ['nat', a])
    witness_eq = ['=', 0, 8]
    pair = ['pair', 7, ['hyp', witness_eq], ['hyp', witness_eq]]
    yield 'witness_equation_binds_number', True, document([], ['sig', witness_eq, witness_eq], pair)
    wrong_eq = ['=', 0, 7]
    yield 'witness_parameter_must_shift', False, document([], ['sig', wrong_eq, wrong_eq], ['pair', 7, ['hyp', wrong_eq], ['hyp', wrong_eq]])
    e = ['=', 0, Z]
    principal = ['sig', e, e]
    yield 'sigma_eigenvariable_cannot_escape', False, document([principal], e, ['use', ['hyp', principal], e, ['hyp', e]])
    yield 'pi_context_must_lift', False, document([e], ['pi', T, e], ['pi', T, ['hyp', e]])
    yield 'pi_correct_context_lifting', True, document([e], ['pi', T, ['=', 1, Z]], ['pi', T, ['hyp', ['=', 1, Z]]])
    yield 'boolean_query_returns_stored_formula', True, document([['=', 0, 0]], ['=', 0, 0], ['hyp', ['=', False, False]])
    yield 'boolean_cannot_be_formula_term', False, document([['=', False, False]], ['=', 0, 0], ['hyp', ['=', 0, 0]])
    yield 'boolean_cannot_be_goal_term', False, document([['=', 0, 0]], ['=', False, False], ['hyp', ['=', 0, 0]])
    yield 'shared_eliminator_rejects_falsity', False, document([F], F, ['use', ['hyp', F], F, ['hyp', F]])
    yield 'shared_eliminator_rejects_bad_equality_predicate', False, document([T], T, ['use', ['hyp', T], ['=', 0, False], ['hyp', T]])
    pi = ['pi', T, T]
    yield 'shared_eliminator_pi_bad_witness', False, document([pi, T], T, ['use', ['hyp', pi], F, ['hyp', T]])
    for tag in ('hyp', 'pi', 'use', 'pair', 'bridge', 'rec', 'nat'):
        yield 'malformed_record_' + tag, False, document([], T, [tag])
    for bad in (-2, True, False, None, {}, [], ['unknown'], ['s'], ['r',Z,Z], ['=',Z,Z]):
        yield 'bad_witness_' + repr(bad), False, document([], ['sig',T,T], ['pair',bad,['hyp',T],['hyp',T]])
    for bad in (-1, 0, True, False, None, {}, [], ['false',Z], ['=',Z], ['pi',T], ['s',Z]):
        yield 'bad_nat_template_' + repr(bad), False, document([], T, ['nat',bad])


def main():
    results=[]
    for name, expected, data in cases():
        try:
            actual=checker.check(data)
        except (ValueError,TypeError,IndexError,KeyError,RecursionError):
            actual=False
        if actual != expected:
            raise AssertionError((name,expected,actual,data))
        results.append({'name':name,'accepted':actual})
    p=Path(__file__).resolve().parents[1]/'verification/implementation_audit.json'
    p.write_text(json.dumps({'tests':results,'count':len(results)},indent=2)+'\n')
    print('Focused independent cases passed:',len(results))


if __name__ == '__main__':
    main()
