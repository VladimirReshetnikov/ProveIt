A COMBINED SMALL iPRA KERNEL
===========================

The complete report is report.pdf; its rebuildable source is report.tex.
The calculus retains genuine falsity, native numerical recursion, and the
two guarded binders Pi and Sigma. The report proves its ordinary
whole-domain bi-interpretability and equiconsistency with full first-order
iPRA with quantifier-free induction.

The standalone acceptance program is code/checker.py. Its seven record
tags are hyp, pi, use, pair, bridge, rec, and nat. FORMAT.txt specifies
all term, formula, proof, binding, and input conventions.

From this directory, using Python 3.10 or later:

  python3 reproduce.py
  python3 code/checker.py certificates/reflexivity.json
  python3 code/checker.py certificates/induction_addition.json
  python3 code/checker.py certificates/quantified_explosion.json
  python3 code/implementation_audit.py
  python3 comparison/measure.py --candidate code/checker.py

All Python dependencies are in the standard library. A checker invocation
prints ACCEPT or REJECT. The exact full checker measures 1002 significant
Python tokens, 1057 AST nodes, and 3309 normalized executable bytes. The
report gives the counting boundary, current-source audit, and matched
comparisons. This is a finite implementation comparison, not a proof of
absolute shortest-program minimality.

FILES
-----

code/checker.py
  Entire trusted mathematical checker, syntax validation and JSON CLI.

code/translate.py
  Untrusted, syntax-directed compiler from the inherited genuine-falsity
  K kernel into the candidate. It checks the input with the exact original
  comparison/baseline.py and checks its output with code/checker.py.
  Neither acceptance program trusts the compiler.

certificates/source/ and certificates/translated/
  Fifty-three original K certificates and their checked translations.
  Six representative translated certificates also have short names in
  certificates/, for the commands above and other convenient examples.

verification/independent_audit.py
  Separately written audit with 294 focused checks, including a named-variable
  oracle for binding, substitution, and the numerical schema.

reproduce.py
  Reruns the proof translation corpus, both audit suites, reference-source
  hash/dependency validation, complete source counts, and generated report tables.

code/implementation_audit.py
  Fifty-one focused positive/negative cases for binding, schema strength,
  syntactic sorts, shared elimination, and the genuine-falsity bridge.
  Its output is verification/implementation_audit.json.

controls/
  Full standalone checkers restoring one reduction at a time. These are
  comparison programs, not dependencies of the candidate checker.

comparison/ and provenance/
  Exact original comparison sources, size counter, source identities,
  dependency lists, and the current six-archive audit.

TRANSLATE A SOURCE CERTIFICATE
-----------------------------

  python3 code/translate.py certificates/source/legacy_reflexivity_derived.json translated.json
  python3 code/checker.py translated.json

The generated proof may be longer than the source. Short acceptance code,
not certificate length or proof-search convenience, is the objective.

REBUILD THE REPORT
------------------

  pdflatex -halt-on-error report.tex
  pdflatex -halt-on-error report.tex

The main contribution is a checked combination of complementary reductions
already present in the six proposals at ProveIt commit
39c2b3c738e4cacbc0b2cb31f093c1eb4f976e75. The report credits each source and
supplies the complete mathematical specification and equivalence proofs.
