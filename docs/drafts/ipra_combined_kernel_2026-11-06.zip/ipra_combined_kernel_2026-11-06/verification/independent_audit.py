"""Independent focused audit of the iPRA checker.

Run: python3 verification/independent_audit.py [CHECKER.py] [OUTPUT.json]
The default checker is ../code/checker.py relative to this script.

The substitution oracle names bound variables explicitly.  It does not use
the candidate's walk, shift, inst, subst, or inference routines to calculate
expected expressions.  This is a finite regression audit, not a formal proof
of the checker or of the metatheorems in the accompanying paper.
"""

import copy
import importlib.util
import itertools
import json
import sys
from pathlib import Path


ZERO = -1
FALSE = ["false"]
TRUE = ["=", ZERO, ZERO]
CLASH = ["=", ZERO, ["s", ZERO]]


def named(a, bound=(), serial=None, prefix="b"):
    """Decode to explicit, globally distinct names for all local binders."""
    serial = itertools.count() if serial is None else serial
    if type(a) is int:
        if a == ZERO:
            return ("zero",)
        return ("v", bound[a]) if a < len(bound) else ("f", a - len(bound))
    tag = a[0]
    if tag == "r":
        u, v = prefix + str(next(serial)), prefix + str(next(serial))
        return (tag, u, v, named(a[1], bound, serial, prefix),
                named(a[2], bound, serial, prefix),
                named(a[3], (u, v) + bound, serial, prefix))
    if tag in ("pi", "sig"):
        x = prefix + str(next(serial))
        return (tag, x, named(a[1], (x,) + bound, serial, prefix),
                named(a[2], (x,) + bound, serial, prefix))
    return (tag, *(named(b, bound, serial, prefix) for b in a[1:]))


def indexed(a, bound=()):
    tag = a[0]
    if tag == "zero":
        return ZERO
    if tag == "f":
        return a[1] + len(bound)
    if tag == "v":
        return bound.index(a[1])
    if tag == "r":
        _, u, v, n, initial, body = a
        return [tag, indexed(n, bound), indexed(initial, bound),
                indexed(body, (u, v) + bound)]
    if tag in ("pi", "sig"):
        return [tag, indexed(a[2], (a[1],) + bound),
                indexed(a[3], (a[1],) + bound)]
    return [tag, *(indexed(b, bound) for b in a[1:])]


def replace_free(a, env):
    tag = a[0]
    if tag == "f":
        return env(a[1])
    if tag in ("v", "zero"):
        return a
    if tag == "r":
        return (*a[:3], *(replace_free(b, env) for b in a[3:]))
    if tag in ("pi", "sig"):
        return (*a[:2], *(replace_free(b, env) for b in a[2:]))
    return (tag, *(replace_free(b, env) for b in a[1:]))


def expected_substitution(a, env):
    return indexed(replace_free(named(a), lambda i: named(env(i), prefix="e%d_" % i)))


def expected_nat(a, full_induction=False):
    """Build the schema in named notation, then encode its binders."""
    pattern = named(a)
    x, z, y = "schema_x", "schema_dummy", "schema_y"

    def at(term):
        return replace_free(pattern, lambda i: term if i == 0 else ("f", i - 1))

    base = at(("zero",))
    guard = at(("v", y)) if full_induction or a[0] == "=" else base
    step = ("pi", y, guard, at(("s", ("v", y))))
    premise = ("sig", z, base, step)
    return indexed(("pi", x, premise, at(("v", x))))


def document(assumptions, goal, proof):
    return {"assumptions": assumptions, "goal": goal, "proof": proof}


def proof_cases():
    e = ["=", 0, ZERO]
    p = ["sig", e, TRUE]
    closed = ["pi", TRUE, TRUE]
    escaped = ["pi", TRUE, ["=", 1, ZERO]]
    yield "sigma_closed_conclusion", True, document([p], closed,
        ["use", ["hyp", p], closed, ["pi", TRUE, ["hyp", TRUE]]])
    yield "sigma_escape_inside_pi_rejected", False, document([p], escaped,
        ["use", ["hyp", p], escaped, ["pi", TRUE, ["hyp", ["=", 1, ZERO]]]])
    yield "sigma_retains_shifted_ambient_parameter", True, document([p, e], escaped,
        ["use", ["hyp", p], escaped, ["pi", TRUE, ["hyp", ["=", 2, ZERO]]]])

    equality = ["=", 0, 1]
    template = ["pi", ["=", 1, ZERO], TRUE]
    source = ["pi", ["=", 1, ZERO], TRUE]
    target = ["pi", ["=", 2, ZERO], TRUE]
    proof = ["use", ["hyp", equality], template, ["hyp", source]]
    yield "equality_transport_under_binder", True, document([equality, source], target, proof)
    yield "equality_transport_capture_rejected", False, document([equality, source],
        ["pi", ["=", 0, ZERO], TRUE], proof)

    witness = ["r", ["s", 0], 1, ["r", 1, 0, ["s", 2]]]
    witness_guard = ["=", 0, expected_substitution(witness, lambda i: i + 1)]
    yield "sigma_compound_witness_with_bound_recursors", True, document([], 
        ["sig", witness_guard, witness_guard],
        ["pair", witness, ["hyp", witness_guard], ["hyp", witness_guard]])

    for label, key in (("boolean", ["=", False, False]),
                       ("float", ["=", 0.0, 0.0])):
        actual = ["=", 0, 0]
        yield label + "_hypothesis_alias_returns_validated_entry", True, \
            document([actual], actual, ["hyp", key])
    yield "float_zero_sentinel_is_not_a_term", False, document([], TRUE,
        ["rec", ["r", -1.0, ZERO, 0]])
    yield "negative_index_below_zero_sentinel_rejected", False, document([], TRUE,
        ["pi", ["=", -2, -2], ["hyp", ["=", -2, -2]]])
    yield "formula_in_recursive_body_rejected", False, document([], TRUE,
        ["rec", ["r", ZERO, ZERO, FALSE]])
    yield "falsity_is_not_general_use_principal", False, document([FALSE], TRUE,
        ["use", ["hyp", FALSE], TRUE, ["hyp", FALSE]])
    yield "bridge_does_not_convert_successor_reflexivity", False, document(
        [["=", ["s", ZERO], ["s", ZERO]]], FALSE,
        ["bridge", ["hyp", ["=", ["s", ZERO], ["s", ZERO]]]])
    yield "bridge_direction_is_exact", True, document([CLASH], FALSE,
        ["bridge", ["hyp", CLASH]])
    yield "false_and_clash_are_distinct_formulas", False, document([CLASH], FALSE,
        ["hyp", CLASH])

    eq = ["=", ZERO, ZERO]
    pi = ["pi", TRUE, TRUE]
    for label, bad in (("bool", True), ("float", 0.0), ("below_sentinel", -2),
                       ("empty_map", {}), ("null", None), ("formula", FALSE)):
        yield "pair_witness_" + label, False, document([], TRUE,
            ["pair", bad, ["hyp", TRUE], ["hyp", TRUE]])
        yield "pi_witness_" + label, False, document([pi, TRUE], TRUE,
            ["use", ["hyp", pi], bad, ["hyp", TRUE]])
        yield "equality_template_term_" + label, False, document([eq], TRUE,
            ["use", ["hyp", eq], ["=", 0, bad], ["hyp", eq]])

    missing = document([], TRUE, ["hyp", TRUE])
    del missing["assumptions"]
    yield "missing_top_level_key", False, missing
    extra = document([TRUE], TRUE, ["hyp", TRUE])
    extra["trusted"] = True
    yield "extra_top_level_key", False, extra


def main():
    if len(sys.argv) not in (1, 2, 3):
        raise SystemExit("usage: independent_audit.py [CHECKER.py] [OUTPUT.json]")
    archive_root = Path(__file__).resolve().parent.parent
    source_path = (Path(sys.argv[1]).resolve() if len(sys.argv) >= 2
                   else archive_root / "code" / "checker.py")
    spec = importlib.util.spec_from_file_location("audited_ipra", source_path)
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    results = []

    def record(name, actual, expected=True):
        if actual != expected:
            raise AssertionError((name, expected, actual))
        results.append({"name": name, "passed": True})

    corpus = [
        ZERO, 0, 5, ["s", ZERO], ["s", 0],
        ["r", 0, 1, 0], ["r", ["s", 0], ZERO, ["s", 2]],
        ["r", 2, 1, ["r", 1, 0, ["s", 2]]],
        ["r", 0, ["r", 1, 2, 3], ["r", 2, 3, ["r", 0, 4, 6]]],
        FALSE, TRUE, ["=", 0, ["s", 1]],
        ["=", ["r", 0, 1, ["s", 2]], 2],
        ["pi", ["=", 0, 1], ["=", 2, ZERO]],
        ["sig", ["pi", ["=", 0, 1], ["=", 2, 3]],
            ["=", ["r", 0, 1, ["r", 1, 2, 4]], 2]],
        ["pi", ["sig", ["=", 2, ZERO], ["=", 0, 1]],
            ["pi", FALSE, ["=", ["r", 1, 2, ["s", 3]], 0]]],
    ]
    for i, expression in enumerate(corpus):
        formula = type(expression) is list and expression[0] in ("=", "false", "pi", "sig")
        record("corpus_well_formed_%02d" % i, checker.wf(expression, formula))
        record("named_round_trip_%02d" % i, indexed(named(expression)) == expression)
        for n in (0, 1, 2, 5):
            expected = expected_substitution(expression, lambda j: j + n)
            record("named_shift_%02d_%d" % (i, n), checker.shift(expression, n) == expected)
        for j, term in enumerate((ZERO, 3, ["s", 0],
                                  ["r", 2, 0, ["r", 1, 0, ["s", 3]]])):
            env = lambda k, term=term: term if k == 0 else k - 1
            expected = expected_substitution(expression, env)
            actual = checker.inst(expression, term)
            record("named_inst_%02d_%d" % (i, j), actual == expected)
            record("inst_preserves_sort_%02d_%d" % (i, j), checker.wf(actual, formula))
        env = lambda k: ["r", ["s", k + 1], ZERO, ["s", 2]] if k % 2 == 0 else k + 2
        record("named_simultaneous_substitution_%02d" % i,
               checker.subst(expression, env) == expected_substitution(expression, env))

    templates = [FALSE, ["=", 0, 1],
                 ["=", ["r", 0, 2, ["r", 1, 0, ["s", 3]]], 1],
                 ["pi", ["=", 1, ["s", 2]], ["=", 0, 1]],
                 ["sig", ["=", 1, 2], ["pi", TRUE, ["=", 2, 3]]]]
    for i, template in enumerate(templates):
        expected = expected_nat(template)
        doc = document([], expected, ["nat", template])
        record("named_nat_schema_%d" % i, checker.check(doc))
        record("nat_schema_preserves_sort_%d" % i, checker.wf(expected, True))
        if template[0] in ("pi", "sig"):
            full = expected_nat(template, full_induction=True)
            try:
                accepted = checker.check(document([], full, ["nat", template]))
            except (ValueError, TypeError, IndexError, KeyError, RecursionError):
                accepted = False
            record("compound_full_induction_schema_rejected_%d" % i, accepted, False)

    for name, expected, data in proof_cases():
        try:
            actual = checker.check(copy.deepcopy(data))
        except (ValueError, TypeError, IndexError, KeyError, RecursionError):
            actual = False
        record(name, actual, expected)
        if expected:
            inferred = checker.infer(data["proof"], data["assumptions"])
            record(name + "_preserves_formula_sort", checker.wf(inferred, True))

    try:
        source_label = str(source_path.relative_to(archive_root))
    except ValueError:
        source_label = str(source_path)
    report = {"checker": source_label, "count": len(results),
              "scope": "Focused finite regression audit with an independent named-variable oracle; not a formal metatheorem verification.",
              "results": results}
    output = Path(sys.argv[2]) if len(sys.argv) == 3 else Path(__file__).with_name("independent_audit_results.json")
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print("Independent audit passed: %d checks" % len(results))


if __name__ == "__main__":
    main()
