"""Create a deterministic source/PDF/certificate archive from this directory."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED = {'.aux','.log','.toc','.out','.pyc','.fmt','.fls','.fdb_latexmk'}


def files():
    return [p for p in sorted(ROOT.rglob('*')) if p.is_file()
            and '__pycache__' not in p.parts and p.suffix not in EXCLUDED
            and not any(part.startswith('.') for part in p.relative_to(ROOT).parts)]


def main():
    manifest = ROOT/'verification/file_manifest.json'
    rows = [{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,
             'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in files() if p != manifest]
    manifest.write_text(json.dumps({'files':rows,'excludes_itself':True},indent=2)+'\n')
    archive = ROOT.with_suffix('.zip')
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in files():
            info = zipfile.ZipInfo(ROOT.name+'/'+str(p.relative_to(ROOT)), (2026,11,6,12,0,0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise RuntimeError('ZIP integrity check failed')
    print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,
                      'files':len(files()),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},indent=2))


if __name__ == '__main__':
    main()
