"""Reproduce the complete-source comparison without executing comparators."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import tempfile

ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('source_measure', ROOT / 'comparison/source_measure.py')
METRIC = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(METRIC)
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
DRIVERS = {
    'common_filename': '''try:
    take = json.load(open(sys.argv[1])).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
''',
    'common_stdin': '''try:
    take = json.load(sys.stdin).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
''',
    'common_conventional': '''try:
    take = json.load(open(sys.argv[1])).pop
    accepted = check(take(), [])
except:
    accepted = False
print('ACCEPT' if accepted else 'REJECT')
sys.exit(not accepted)
'''
}


def normalized_driver(source, driver):
    tree = ast.parse(source)
    starts = [i for i, node in enumerate(tree.body) if isinstance(node, ast.Try)]
    if len(starts) != 1:
        raise ValueError('Expected one top-level public driver')
    tree.body = tree.body[:starts[0]] + ast.parse(driver).body
    return ast.unparse(tree) + '\n'


def record(path):
    result = {'delivered': METRIC.metrics(path)}
    source = path.read_text()
    with tempfile.TemporaryDirectory() as directory:
        temporary = Path(directory) / 'driver_control.py'
        for key, driver in DRIVERS.items():
            temporary.write_text(normalized_driver(source, driver))
            result[key] = METRIC.metrics(temporary)
    return result


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    current = []
    for entry in manifest['programs']:
        path = ROOT / 'comparison' / entry['local_file']
        if hashlib.sha256(path.read_bytes()).hexdigest() != entry['sha256']:
            raise ValueError('Comparator changed: ' + entry['label'])
        current.append({**entry, **record(path)})
    expanded = []
    for entry in manifest['expanded']:
        path = ROOT / 'comparison' / entry['local_file']
        measured = METRIC.metrics(path)
        if measured['sha256'] != entry['sha256']:
            raise ValueError('Expanded comparator changed: ' + entry['local_file'])
        expanded.append({**entry, **measured})
    minima = {
        boundary: {key: min(row[boundary][key] for row in current) for key in KEYS}
        for boundary in ('delivered', *DRIVERS)
    }
    candidates = [
        {'file': name, **record(ROOT / name)}
        for name in ('checker.py', 'checker_direct.py')
    ]
    for row in candidates:
        row['strict_improvement'] = {
            boundary: all(row[boundary][key] < minima[boundary][key] for key in KEYS)
            for boundary in minima
        }
        if not all(row['strict_improvement'].values()):
            raise AssertionError(row['file'] + ': dominance failed')
    result = {
        'status': 'PASS', 'python': platform.python_version(),
        'implementation': platform.python_implementation(),
        'repository': manifest['repository'], 'commit': manifest['commit'],
        'normalizer_sha256': hashlib.sha256((ROOT / 'comparison/source_measure.py').read_bytes()).hexdigest(),
        'archive_count': len(manifest['archives']), 'root_paths': len(current),
        'root_source_hashes': len({row['sha256'] for row in current}),
        'expanded_source_hashes': len(expanded), 'minima': minima,
        'expanded_minima': {key: min(row[key] for row in expanded) for key in KEYS},
        'candidates': candidates, 'current': current, 'expanded': expanded,
        'boundary': 'Complete source including imports, parser, validation, inference, output, exception handling, exit status. No project library omitted. Comparators are parsed, never executed.',
        'normalization': 'Inherited source_measure.py unchanged: strip genuine docstrings, ast.unparse, count significant tokens, all AST nodes, UTF-8 bytes. Comments and formatting do not reduce normalized measures.'
    }
    results = ROOT / 'results'
    results.mkdir(exist_ok=True)
    (results / 'measurements.json').write_text(json.dumps(result, indent=2) + '\n')
    table = [r'\begin{table}[htbp]', r'\centering', r'\begin{tabular}{@{}lrrr@{}}',
             r'\toprule Complete current program & Tokens & Nodes & Bytes\\',
             r'\midrule']
    for row in current:
        archive, member = row['label'].split('/')
        short = archive.removeprefix('ipra_').removesuffix('_2026-11-07')
        label = (short + '/' + member).replace('_', r'\_')
        values = ' & '.join(str(row['delivered'][key]) for key in KEYS)
        table.append(r'\texttt{' + label + '} & ' + values + r'\\')
    table.extend([r'\bottomrule', r'\end{tabular}',
                  r'\caption{All eleven current root checker programs; complete source.}',
                  r'\end{table}'])
    (results / 'current_table.tex').write_text('\n'.join(table) + '\n')
    summary = {key: result[key] for key in ('status', 'python', 'root_paths', 'root_source_hashes', 'expanded_source_hashes', 'minima', 'expanded_minima')}
    summary['candidates'] = [
        {'file': row['file'], **{b: {k: row[b][k] for k in KEYS} for b in minima},
         'strict_improvement': row['strict_improvement']}
        for row in candidates
    ]
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
