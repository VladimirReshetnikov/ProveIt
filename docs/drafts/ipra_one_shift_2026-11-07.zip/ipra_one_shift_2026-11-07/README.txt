ONE SHIFT PER CONSTRUCTOR
Smaller complete presentations of intuitionistic primitive recursive arithmetic
Prepared for Vladimir Reshetnikov, 7 November 2026 (Pacific date).

START HERE
==========

Read report.pdf. The editable LaTeX is report.tex with sections/ and appendices/.
The main mathematical development uses direct primitive recursion. The scalar
appendices provide the longer strength proof needed for the smallest checker.
The archive is self-contained and reproduces its evidence without a network.

VERIFIED RESULT
===============

Complete programs, measured by the supplied unchanged source metric:

                                     Tokens     AST nodes     Normalized bytes
Current 11-root corpus minimum          356           378                1038
checker.py: scalar iteration            348           370                 998
checker_direct.py: full recursion       355           376                1010

Both delivered programs keep the filename input interface. Strict improvement
also holds after replacing EVERY compared public driver by the same filename,
stdin, or conventional Boolean driver. The evidence is results/measurements.json.
The recorded platform is CPython 3.12.14. Counts include the entire source:
imports, input, shape/scope checking, inference, exceptions, output, exit status.

The reference snapshot is VladimirReshetnikov/ProveIt commit
df8beb801d9f3e3eb3a8141722953fb58e63009e, all six current docs/drafts archives.
Their eleven root programs are preserved in comparison/current/. An expanded
inventory preserves 198 distinct complete-checker-like sources with the same
minimum. This inventory is not a soundness certification of every experiment.

THE NEW IDEA
============

Every child of a constructor in the existing padded syntax already receives
the same scope increment. A scalar increment per constructor therefore
replaces the vector of child increments, zip, and its extra loop variable.
Empty arrays are interpreted as zero numerically and truth propositionally.
This combines the existing uniform-scope and empty-completion ideas to eliminate
the per-child traversal. Numerical binary exclusion and third-child formula
introduction remain essential; concrete false-proof mutants demonstrate why.

The new direct-recursion checker is below the previous scalar benchmark, while
its mathematical strength proof avoids the scalar comparator and pairing
bootstrap. The scalar version remains smaller as a complete implementation.

WHAT IS AND IS NOT PROVED
========================

The paper supplies every native axiom/schema/rule, derives full intuitionistic
logic, proves quantifier-free reflection, gives ordinary first-order realizations,
and proves both whole-domain interpretation composites internally equal to the
identity. The latter includes nonstandard arguments; standard-model expressivity
alone would be insufficient. These written proofs establish the claimed relation
to iPRA subject to ordinary mathematical review.

The finite executable checks are implementation evidence, not a proof of
consistency, universal soundness, completeness, or bi-interpretability. The
metatheory has not been formalized in Lean or Rocq. The result is a modest
structural improvement relative to the stated corpus and source metric. It is
not an absolute shortestness theorem, a worldwide novelty claim, or the large
foundational breakthrough requested. The common arithmetic/logical basis and
the scalar bootstrap are explicitly credited to the supplied drafts.

USAGE
=====

Requires Python 3.10 or later for the checkers.

  python3 checker.py examples/addition_two_three.json
  python3 checker_direct.py examples/direct_counter_step.json

ACCEPT with exit status 0 denotes successful verification. REJECT has status 1.
The packet's final cell is its closed goal. Other cells are consumed from the
end. Unused prefix cells are inert; no initial user context is accepted.

Reproduce the complete-source comparison and finite evidence:

  python3 measure.py
  python3 validation/run.py

Or run both:

  python3 reproduce.py

Rebuild the PDF using pdflatex and the ordinary packages in report.tex:

  python3 build.py

Run all three steps:

  python3 reproduce.py --pdf

The two checkers import no local helper. The comparison and validation modules
are outside the acceptance boundary. Comparison sources are parsed, not executed.
No public deployment, repository write, or remote proof oracle is needed.

EVIDENCE
========

results/validation.json records PASS:
  Scalar: 19,351 packet comparisons and 308 public CLI executions.
  Direct: 15,080 packet comparisons and 124 public CLI executions.
  Each: 6,008 opening comparisons and 3,000 decoded substitution checks.
  Direct: all 3,000 staged raw substitutions agree; 2,999 decoded evaluations
          complete and one explicitly exceeds the test evaluator's budget.
  Direct generated computations: 2,051 accepted/evaluated; 949 scope rejections.
  No reported failures. The source manifest checks 40 files before and after.

See validation/README.txt for details and limits. Exact fixture and source hashes
are included. The tests are deterministic and use Python's standard library.

CONTENTS
========

report.tex, sections/, appendices/    Complete mathematical paper sources
report.pdf                          Compiled paper
checker.py                          Smallest delivered scalar acceptance program
checker_direct.py                   Full primitive-recursion acceptance program
examples/                           Positive packets and explicit attack witnesses
validation/                         Separate oracle, evaluator, fixtures, runner
comparison/                         Pinned comparators, original metric, manifest
results/                            Measured source sizes and validation receipts
measure.py, reproduce.py, build.py   Offline reproduction commands
package.py, MANIFEST.sha256          Packaging and integrity information

ATTRIBUTION
===========

Current archive sources are preserved as retrieved from the user's ProveIt
repository. The native five-rule basis, scalar/direct recursion, logic
reconstruction, interval labels, truth completion, padded scopes, and scalar
bootstrap are inherited and credited throughout the report. The supplied
validation attribution and license notice are in validation/.

Primary literature references in the paper are Salehi (2002), for the iPRA
atomic-induction convention, and Severin (2008), for restricted iteration bases.
Neither is used to substitute a standard-model expressivity result for an
internal interpretation proof.
