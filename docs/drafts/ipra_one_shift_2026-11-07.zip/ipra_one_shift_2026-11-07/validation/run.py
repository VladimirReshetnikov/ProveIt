#!/usr/bin/env python3
"""Offline finite verification of the two complete, delivered proof checkers.

The named-rule oracle uses separate formula and numerical traversals; it does
not import the production inst/check definitions. All fixtures and reference
code are bundled. Source hashes are checked before and after the run.
"""
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import ast
import json
import platform
import random
import subprocess
import sys
import tempfile
import types

import validate as v
import direct_validate as dv

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SNAPSHOT = 'df8beb801d9f3e3eb3a8141722953fb58e63009e'


def frozen_sources():
    manifest = json.loads((HERE / 'source_manifest.json').read_text())
    for relative, expected in manifest['sha256'].items():
        actual = sha256((ROOT / relative).read_bytes()).hexdigest()
        if actual != expected:
            raise ValueError('Source or fixture changed: ' + relative)
    return {'status': 'PASS', 'checked_files': len(manifest['sha256']),
            'manifest_sha256': sha256((HERE / 'source_manifest.json').read_bytes()).hexdigest()}


def empty_zeros(value, rng):
    """Vary raw zero spellings; no claim that every whole packet is preserved."""
    if isinstance(value, list):
        return [empty_zeros(child, rng) for child in value]
    if type(value) is int and value == 0 and rng.random() < 0.4:
        return []
    return value


def completed_syntax(audit, records):
    rng = random.Random(112358 + audit.width)
    for record in records:
        for _ in range(5):
            audit.packet(empty_zeros(record['packet'], rng), 'empty_alias_mutation')
    for seed in [[], 0, [[]], [[[]]], [[[]], [], [3]], [[], [], 1]]:
        for counter in [[], 0, False, -0.0]:
            audit.packet([[], [[counter, seed, []], seed]],
                         'empty_zero_computation', True)
    audit.packet([0, [[], [], []]], 'empty_truth_introduction', True)
    for goal in [[[], [[]]], [[[]], []], [[[[]]], []]]:
        for proof in [[[]], [0], [[[], []]]]:
            audit.packet(deepcopy(proof + [goal]), 'empty_false_equation', False)


def structural_guards(audit):
    """Explicit false-theorem witnesses for essential representation guards."""
    source = audit.checker.read_text()
    controls = [
        ('numerical_binary_exclusion', '(1, None)[d % 2]', '1',
         'binary_gate_counterexample.json'),
        ('third_child_introduction', 'a = inst(a[2], t, 2)',
         'a = inst(a[0], t, 2)', 'third_child_counterexample.json'),
    ]
    result = []
    for name, before, after, filename in controls:
        if source.count(before) != 1:
            raise ValueError('Mutation location changed: ' + name)
        tree = ast.parse(source.replace(before, after))
        prefix = []
        for node in tree.body:
            if isinstance(node, ast.Try):
                break
            prefix.append(node)
        module = types.ModuleType(name + '_unsafe_control')
        exec(compile(ast.Module(body=prefix, type_ignores=[]),
                     '<deliberately unsafe control>', 'exec'), module.__dict__)
        packet = json.loads((ROOT / 'examples' / filename).read_text())
        correct = audit.packet(packet, 'structural_guard_probe', False)
        incorrect = v.trace(module, packet)[0]
        left, right = packet[-1]
        values = [v.numerical_value(left, width=audit.width),
                  v.numerical_value(right, width=audit.width)]
        if correct or not incorrect or values[0] == values[1]:
            audit.failure('structural guard control',
                          (name, correct, incorrect, values))
        result.append({'name': name, 'example': filename,
                       'correct_accepts': correct, 'mutant_accepts': incorrect,
                       'false_equation_values': values})
    for packet in [[0, [0, 0, [], []]], [[], [[0, [], [], []], 0]]]:
        audit.packet(packet, 'structural_guard_probe', False)
    return {'false_theorem_controls': result,
            'additional_nonempty_arity_above_three_rejections': 2}


def public_cli(audit, records):
    """Check the actual file/JSON interface, including verdict and exit code."""
    counts = {'positive': 0, 'malformed': 0}
    with tempfile.TemporaryDirectory(prefix='ipra_one_shift_') as directory:
        packet = Path(directory) / 'packet.json'

        def check(expected, category, optimized):
            process = subprocess.run(
                [sys.executable, *(['-O'] if optimized else []),
                 str(audit.checker), str(packet)],
                text=True, capture_output=True, timeout=10)
            wanted = (0, 'ACCEPT', '') if expected else (1, 'REJECT', '')
            actual = (process.returncode, process.stdout.strip(), process.stderr)
            counts[category] += 1
            if actual != wanted:
                audit.failure('public CLI', (category, optimized, actual, wanted))

        for record in records:
            packet.write_text(json.dumps(record['packet']))
            for optimized in (False, True):
                check(True, 'positive', optimized)
        for contents in ['{', 'null', '7', '{}', '[]', '[0] trailing',
                         '[[], [[0, NaN, 0], 0]]']:
            packet.write_text(contents)
            for optimized in (False, True):
                check(False, 'malformed', optimized)
    return {'runs': sum(counts.values()), 'counts': counts,
            'normal_and_optimized': True,
            'checks_exit_status_stdout_stderr': True}


def verify_kernel(width, name, fixture, example_index):
    audit = v.Audit(ROOT / name, width)
    records = json.loads((HERE / fixture).read_text())['records']
    examples = json.loads((ROOT / 'examples' / example_index).read_text())
    audit.packets(records, examples)
    opening = audit.openings()
    semantic = audit.semantic_openings()
    computation = audit.computations()
    false = audit.false_conclusions(records)
    stages = dv.stage_checks(audit) if width == 2 else None
    controls = dv.mutation_controls(audit) if width == 2 else None
    completed_syntax(audit, records)
    structure = structural_guards(audit)
    cli = public_cli(audit, records)
    result = {
        'checker': name, 'checker_sha256': v.digest(ROOT / name),
        'recursion_width': width,
        'status': 'PASS' if not audit.failures else 'FAIL',
        'fixture': fixture, 'fixture_sha256': v.digest(HERE / fixture),
        'positive_certificates': len(records),
        'packet_counts': dict(audit.counts),
        'packet_comparisons': sum(audit.counts.values()),
        'accepted_packets': audit.accepted,
        'accepted_rule_counts': dict(audit.rules),
        'opening_agreement': opening,
        'decoded_numerical_substitution': semantic,
        'numerical_computations': computation,
        'false_conclusion_probes': false,
        'staged_opening': stages,
        'mutation_controls': controls,
        'structural_guards': structure,
        'public_cli': cli, 'failures': audit.failures,
    }
    print(name + ': ' + result['status'] + ', '
          + str(result['packet_comparisons']) + ' packet comparisons, '
          + str(cli['runs']) + ' public CLI checks, '
          + str(len(audit.failures)) + ' failures.', flush=True)
    return result


def main():
    before = frozen_sources()
    kernels = [verify_kernel(1, 'checker.py', 'positive_certificates.json', 'index.json'),
               verify_kernel(2, 'checker_direct.py', 'direct_positive_certificates.json',
                             'direct_index.json')]
    after = frozen_sources()
    result = {
        'status': 'PASS' if all(k['status'] == 'PASS' for k in kernels) else 'FAIL',
        'python_version': platform.python_version(),
        'python_implementation': platform.python_implementation(),
        'reference_snapshot': SNAPSHOT,
        'source_integrity_before': before,
        'source_integrity_after': after,
        'oracle_sha256': v.digest(HERE / 'oracle_uniform.py'),
        'runner_sha256': v.digest(Path(__file__)),
        'kernels': kernels,
        'scope': ('Finite reproducible implementation evidence. No machine-checked '
                  'metatheory, soundness, completeness, consistency, or '
                  'bi-interpretability proof is claimed.'),
    }
    destination = ROOT / 'results' / 'validation.json'
    destination.parent.mkdir(exist_ok=True)
    destination.write_text(json.dumps(result, indent=2) + '\n')
    print('Validation: ' + result['status'] + '.', flush=True)
    raise SystemExit(result['status'] != 'PASS')


if __name__ == '__main__':
    main()
