OFFLINE VALIDATION OF THE DELIVERED CHECKERS
==========================================

From the extracted package directory, run:

    python3 validation/run.py

An absolute path to that file also works from another working directory. The
entry point needs only Python 3.10 or later and the standard library. It reads
bundled files only, writes results/validation.json, and exits zero exactly when
all checks pass. There are two public proof-checking programs:

    python3 checker.py proof.json
    python3 checker_direct.py proof.json

The first uses scalar iteration; the second uses full primitive recursion.
Neither checker imports a validation module, example, comparison program, or
project-specific helper. Acceptance prints ACCEPT and exits zero; rejection
prints REJECT and exits one. The JSON packet's last item is the proposed closed
goal. Earlier items are proof instructions consumed from the end; an unused
initial prefix is inert.

SOURCE INTEGRITY

source_manifest.json records SHA-256 hashes of both complete checkers, all
validation source, both certificate bundles, and all example JSON files. The
runner checks every hash before and after validation. A changed source or
fixture is reported as an error, rather than reusing an old PASS receipt. Hashes
identify the actual finite test run; they do not establish mathematical
correctness. If you intentionally edit a hashed file, the frozen validation
receipt no longer applies to that revision.

WHAT IS COMPARED

oracle_uniform.py is a separately structured named-rule interpreter. It uses
explicit numerical and formula recursion, named binding counts, and ordinary
conditionals. It does not import inst/check, use the production scope table, or
share structural-match dispatch. Its numeric and formula empty-array cases are
zero and truth respectively. Both modes compare acceptance, consumed proof
instructions, and the fresh-name allocation floor against the actual checker.

The bundles contain 147 scalar and 55 direct positive certificates. Their
provenance and packet hashes are included in the records. The tests check these
already translated packets directly; no network retrieval or unbundled
translator is needed. Published examples retain their explicit expected
verdicts. Mutated packets, malformed inputs, false conclusions, and empty-array
aliases are compared with the oracle. Alias mutation need not preserve a whole
packet's verdict: a new hypothesis match can change instruction consumption.

Numerical opening is also evaluated independently, across five protected
binding depths and negative rigid parameters. The direct checker is compared
with an explicit simultaneous substitution of separate state and counter
variables. Mutant controls demonstrate that losing this distinction, failing
to protect the state, removing the numerical-binary exclusion, or using the
first child as the introduction matrix can accept an explicitly false equation.
The correct checkers reject those witnesses. Nonempty arities above three are
also tested for rejection.

The public JSON/file interface is executed for every positive certificate,
normally and with Python -O, and for seven malformed input families. These
subprocess checks assert the exit status, complete stripped stdout verdict, and
empty stderr. They total 308 scalar and 124 direct subprocess runs.

FINITE SCOPE AND BUDGETS

The original finite suite contains 19,347 scalar and 15,076 direct packet
comparisons, before the four additional fixed structural-guard probes in each
mode. It also contains 6,008 opening comparisons per checker and 3,000 decoded
substitution checks per checker. All 3,000 generated scalar computation
instances were accepted and independently evaluated. Of 3,000 generated direct
instances, 2,051 were accepted and evaluated; 949 were rejected because the
staged opening required unavailable coordinates. Those are schema rejections,
not skipped successful proofs.

All 3,000 direct staged-versus-simultaneous raw substitutions agreed. In their
separate numerical evaluation, 2,999 were evaluated and one exceeded the test
interpreter's finite budget (maximum recursor count 30 or value 100,000). This
single budget skip is explicitly recorded in results/validation.json. These
budgets bound only validation work; the proof checkers contain no numerical
evaluation budget.

The results are finite reproducible implementation evidence. They are not a
machine-checked proof of soundness, completeness, consistency, or
bi-interpretability. The paper supplies the mathematical argument separately.
