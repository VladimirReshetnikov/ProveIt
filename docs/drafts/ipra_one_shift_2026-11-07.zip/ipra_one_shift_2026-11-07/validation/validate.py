#!/usr/bin/env python3
"""Reproduce finite implementation checks using only the Python standard library.

Run validation/run.py from any working directory. The production checker imports none
of this module, its oracle, its fixture data, or its numerical evaluator.
The checks support implementation confidence, not a formal metatheory proof.
"""
import ast
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import json
import math
from pathlib import Path
import platform
import random
import subprocess
import sys
import tempfile
import types

from oracle_uniform import Oracle

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SEED = 19481108


def canonical(value):
    return json.dumps(value, ensure_ascii=True, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('ascii')


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def require(condition, detail):
    if not condition:
        raise AssertionError(detail)


def load_checker(path):
    """Load the actual definitions; public subprocess tests exercise the driver."""
    tree = ast.parse(Path(path).read_text())
    body = []
    for node in tree.body:
        if isinstance(node, ast.Try):
            break
        body.append(node)
    module = types.ModuleType('actual_checker_definitions')
    exec(compile(ast.Module(body=body, type_ignores=[]), str(path), 'exec'),
         module.__dict__)
    return module


def trace(module, packet):
    module.k = 0
    stack = deepcopy(packet)
    try:
        module.take = stack.pop
        accepted = bool(module.check(stack.pop(), []))
    except Exception:
        accepted = False
    return accepted, module.k, len(stack) if isinstance(stack, list) else None


def paths(value, path=()):
    result = [path]
    if isinstance(value, list):
        for i, child in enumerate(value):
            result.extend(paths(child, path + (i,)))
    return result


def replace(value, path, new):
    if not path:
        return new
    parent = value
    for i in path[:-1]:
        parent = parent[i]
    parent[path[-1]] = new
    return value


ATOMS = [None, False, True, -4, -1, 0, 1, 2, 3, 4, 0.25, 0.75,
         1.5, 2.75, -0.25, -1.5, 10**100, float('inf'),
         float('-inf'), float('nan'), 'x', {}, []]


def random_tree(rng, depth=3):
    if depth <= 0 or rng.random() < 0.65:
        return deepcopy(rng.choice(ATOMS))
    return [random_tree(rng, depth - 1) for _ in range(rng.randrange(5))]


def numerical_value(term, scope=(), rigid=None, width=1):
    """Independent denotation; budgets bound testing work, never acceptance."""
    rigid = {} if rigid is None else rigid
    if isinstance(term, (int, float)):
        if isinstance(term, float) and not math.isfinite(term):
            raise ValueError('nonfinite numerical syntax')
        if term < 0:
            return rigid[math.floor(term)]
        if term < 1:
            return 0
        return scope[math.floor((term - 1) / 2)]
    if not isinstance(term, list):
        raise ValueError('numerical type')
    if not term:
        return 0
    if len(term) == 1:
        result = numerical_value(term[0], (0,) + scope, rigid, width) + 1
    elif len(term) == 3:
        count = numerical_value(term[0], (0, 0) + scope, rigid, width)
        if count > 30:
            raise OverflowError('evaluation iteration budget')
        result = numerical_value(term[1], (0, 0) + scope, rigid, width)
        for counter in range(count):
            locals_ = (result, result if width == 1 else counter)
            result = numerical_value(term[2], locals_ + scope, rigid, width)
    else:
        raise ValueError('numerical arity')
    if result > 100000:
        raise OverflowError('evaluation value budget')
    return result


def numerical_tree(rng, depth, protected, rigid=False):
    if depth <= 0 or rng.random() < 0.5:
        atoms = [0] + list(range(1, 2 * protected + 1))
        if rigid:
            atoms += [-3, -2, -1]
        return rng.choice(atoms)
    if rng.random() < 0.5:
        return [numerical_tree(rng, depth - 1, protected + 1, rigid)]
    return [numerical_tree(rng, depth - 1, protected + 2, rigid)
            for _ in range(3)]


def finite_aliases(value, rng):
    """Change only the spelling of each integer coordinate's denotation."""
    if isinstance(value, list):
        return [finite_aliases(child, rng) for child in value]
    if value < 0:
        return value + rng.choice([0.0, 0.25, 0.75])
    if value == 0:
        return rng.choice([False, 0.0, 0.25, 0.75])
    nearest_odd = 2 * ((value - 1) // 2) + 1
    return nearest_odd + rng.choice([0.0, 0.25, 1.0, 1.75])


class Audit:
    def __init__(self, checker, width=1):
        self.checker = Path(checker)
        self.module = load_checker(checker)
        self.width = width
        self.counts = Counter()
        self.accepted = 0
        self.rules = Counter()
        self.failures = []

    def failure(self, category, detail):
        # A compact failure record keeps NaN diagnostics valid JSON too.
        self.failures.append({'category': category, 'detail': repr(detail)})

    def packet(self, packet, category, expected=None):
        actual = trace(self.module, packet)
        oracle = Oracle(self.width).run(packet)
        wanted = (oracle['accepted'], oracle['final_k'], oracle['remaining'])
        self.counts[category] += 1
        self.accepted += actual[0]
        if actual != wanted:
            self.failure('oracle agreement', (category, actual, wanted, packet))
        if expected is not None and actual[0] != expected:
            self.failure('expected verdict', (category, actual, expected, packet))
        if actual[0]:
            self.rules.update(oracle['rules'])
        return actual[0]

    def packets(self, records, examples):
        rng = random.Random(SEED + self.width)
        for record in records:
            packet = record['packet']
            require(sha256(canonical(packet)).hexdigest() == record['packet_sha256'],
                    ('bundled packet hash', record['id']))
            self.packet(packet, 'translated_positive', True)
            for j in range(30):
                changed = deepcopy(packet)
                path = rng.choice(paths(changed))
                atom = deepcopy(rng.choice(ATOMS))
                if j % 5 == 0:
                    atom = [atom]
                if j % 7 == 0:
                    atom = [atom, atom, atom]
                self.packet(replace(changed, path, atom), 'mutated_positive')
        for example in examples:
            path = ROOT / 'examples' / example['file']
            require(digest(path) == example['sha256'], ('example hash', path.name))
            self.packet(json.loads(path.read_text()), 'fixed_example', example['expected'])
        for _ in range(5000):
            packet = [random_tree(rng) for _ in range(rng.randrange(1, 6))]
            self.packet(packet, 'random_packet')

    def openings(self):
        rng = random.Random(SEED + 110 + self.width)
        attempts = 0
        depths = set()
        formula_modes = set()

        def compare(value, image, protected, formula, lower):
            nonlocal attempts
            attempts += 1
            depths.add(protected)
            formula_modes.add(formula)
            self.module.k = lower
            reference = Oracle(self.width)
            reference.lower = lower
            try:
                actual = self.module.inst(value, image, 2 * protected + (not formula))
                actual_ok = True
            except Exception:
                actual = None
                actual_ok = False
            try:
                method = reference.formula if formula else reference.term
                expected = method(value, image, protected)
                expected_ok = True
            except Exception:
                expected = None
                expected_ok = False
            if actual_ok != expected_ok or actual_ok and actual != expected:
                self.failure('opening agreement',
                             (value, image, protected, formula, lower,
                              actual_ok, actual, expected_ok, expected))

        # Every boundary, both sorts, multiple fresh-name floors and six scopes.
        for protected in range(6):
            for formula in (False, True):
                ceiling = 2 * protected + (not formula)
                for lower in (-3, -1, 0):
                    values = ATOMS + [lower - 0.25, lower + 0.25,
                                      ceiling - 0.25, ceiling, ceiling + 0.25]
                    for value in values:
                        compare(value, [0], protected, formula, lower)
        for _ in range(5000):
            compare(random_tree(rng), random_tree(rng, 2), rng.randrange(6),
                    bool(rng.randrange(2)), -rng.randrange(5))
        return {'comparisons': attempts, 'protected_depths': sorted(depths),
                'sorts': ['numerical', 'formula'],
                'finite_and_nonfinite_atoms_tested': True,
                'random_seed': SEED + 110 + self.width}

    def semantic_openings(self):
        """Compare decoded substitution, with arbitrary local and rigid values."""
        rng = random.Random(SEED + 220 + self.width)
        count = 0
        skipped = 0
        rigid = {-3: 2, -2: 1, -1: 3}
        scope_counts = Counter()
        for index in range(3000):
            protected = index % 5
            aliases = 1 + index % 2
            scope = tuple(rng.randrange(4) for _ in range(protected))
            template = numerical_tree(rng, 3, protected + aliases, True)
            image = numerical_tree(rng, 2, 0, True)
            if index % 2:
                template = finite_aliases(template, rng)
                image = finite_aliases(image, rng)
            self.module.k = -3
            try:
                image_value = numerical_value(image, rigid=rigid, width=self.width)
                expected = numerical_value(template, scope + (image_value,) * aliases,
                                           rigid, self.width)
                opened = self.module.inst(template, image, 2 * protected + 1)
                actual = numerical_value(opened, scope, rigid, self.width)
            except OverflowError:
                skipped += 1
                continue
            except Exception as exc:
                self.failure('semantic opening exception',
                             (index, template, image, protected, type(exc).__name__))
                continue
            count += 1
            scope_counts[str(protected)] += 1
            if expected != actual:
                self.failure('decoded substitution',
                             (index, template, image, expected, actual))
        return {'attempts': 3000, 'evaluated': count,
                'budget_skips': skipped, 'by_protected_depth': dict(scope_counts),
                'floating_alias_attempts': 1500, 'rigid_parameters': rigid,
                'one_and_two_exposed_aliases': True,
                'random_seed': SEED + 220 + self.width}

    def computations(self):
        rng = random.Random(SEED + 330 + self.width)
        evaluated = 0
        unaccepted = 0
        skipped = 0
        for index in range(3000):
            seed = numerical_tree(rng, 2, 2)
            update = numerical_tree(rng, 3, 2)
            predecessor = numerical_tree(rng, 2, 2)
            if index % 2:
                seed = finite_aliases(seed, rng)
                update = finite_aliases(update, rng)
                predecessor = finite_aliases(predecessor, rng)
            left = [[predecessor], seed, update]
            self.module.k = 0
            try:
                smaller = [predecessor, seed, update]
                body = (update if self.width == 1
                        else self.module.inst(update, predecessor, 3))
                right = self.module.inst(body, smaller, 1)
                self.module.inst([left, right])
            except Exception:
                unaccepted += 1
                continue
            self.packet([[], [left, right]], 'generated_computation', True)
            try:
                left_value = numerical_value(left, width=self.width)
                right_value = numerical_value(right, width=self.width)
            except OverflowError:
                skipped += 1
                continue
            except Exception as exc:
                self.failure('computation denotation exception',
                             (index, left, right, type(exc).__name__))
                continue
            evaluated += 1
            if left_value != right_value:
                self.failure('computation denotation',
                             (index, left, right, left_value, right_value))
        return {'attempts': 3000, 'evaluated_equalities': evaluated,
                'schema_rejected': unaccepted, 'budget_skips': skipped,
                'floating_alias_attempts': 1500,
                'random_seed': SEED + 330 + self.width}

    def false_conclusions(self, records):
        rng = random.Random(SEED + 440 + self.width)
        # These equations and closure matrices are false in the standard naturals.
        goals = [[[0], 0], [0, [0]], [[[0]], 0], [[[0]], [0]],
                 [0, 0, [1, 0]], [0, 0, [0, 1]]]
        for index in range(6000):
            packet = deepcopy(rng.choice(records)['packet'])
            for _ in range(1 + rng.randrange(3)):
                if len(packet) > 1:
                    position = rng.randrange(len(packet) - 1)
                    old = packet[position]
                    path = rng.choice(paths(old))
                    packet[position] = replace(old, path, random_tree(rng, 2))
            packet[-1] = deepcopy(goals[index % len(goals)])
            self.packet(packet, 'fixed_false_conclusion', False)
        return {'targeted_packets': 6000, 'false_goal_families': len(goals),
                'random_seed': SEED + 440 + self.width,
                'scope': 'Finite search over false standard-natural conclusions; not a soundness proof.'}

