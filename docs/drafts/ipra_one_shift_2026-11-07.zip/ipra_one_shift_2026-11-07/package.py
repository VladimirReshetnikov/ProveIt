"""Package the complete report and reproduction artifacts with SHA-256 inventory."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED_PARTS = {'.build', '__pycache__', '.pytest_cache'}


def included(path):
    relative = path.relative_to(ROOT)
    return path.is_file() and not any(p in EXCLUDED_PARTS for p in relative.parts) and path.suffix != '.pyc'


def main():
    required = ['report.tex', 'report.pdf', 'checker.py', 'checker_direct.py',
                'results/validation.json', 'results/measurements.json', 'results/document_qa.json']
    for name in required:
        if not (ROOT / name).is_file():
            raise SystemExit('Missing required artifact: ' + name)
    files = sorted(p for p in ROOT.rglob('*') if included(p) and p.name != 'MANIFEST.sha256')
    lines = [hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + str(p.relative_to(ROOT)) for p in files]
    manifest = ROOT / 'MANIFEST.sha256'
    manifest.write_text('\n'.join(lines) + '\n')
    files.append(manifest)
    output = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(files):
            info = zipfile.ZipInfo(str(Path(ROOT.name) / path.relative_to(ROOT)), (2026, 11, 7, 21, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())
    with zipfile.ZipFile(output) as archive:
        failure = archive.testzip()
        if failure:
            raise SystemExit('Archive integrity failure: ' + failure)
    print(str(output))
    print('files:', len(files), 'bytes:', output.stat().st_size)
    print('sha256:', hashlib.sha256(output.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
