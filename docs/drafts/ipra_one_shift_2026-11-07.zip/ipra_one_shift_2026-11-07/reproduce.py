"""Run the finite evidence and complete-source measurement offline."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
for program in ('measure.py', 'validation/run.py'):
    subprocess.run([sys.executable, str(ROOT / program)], cwd=ROOT, check=True)
if '--pdf' in sys.argv:
    subprocess.run([sys.executable, str(ROOT / 'build.py')], cwd=ROOT, check=True)
print('PASS: requested reproduction steps completed.')
