"""Compile the complete LaTeX paper; requires pdflatex and standard TeX packages."""
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    executable = shutil.which('pdflatex')
    if not executable:
        raise SystemExit('pdflatex is required; the already compiled report.pdf is included.')
    build = ROOT / '.build'
    build.mkdir(exist_ok=True)
    for _ in range(3):
        process = subprocess.run(
            [executable, '-interaction=nonstopmode', '-halt-on-error',
             '-output-directory=' + str(build), 'report.tex'],
            cwd=ROOT, capture_output=True, text=True
        )
        (build / 'console.txt').write_text(process.stdout + process.stderr)
        if process.returncode:
            print(process.stdout[-7000:])
            raise SystemExit(process.returncode)
    log = (build / 'report.log').read_text(errors='replace')
    bad = [line for line in log.splitlines()
           if 'Overfull' in line or 'undefined' in line or 'multiply defined' in line]
    if bad:
        print('\n'.join(bad))
        raise SystemExit('Resolve the listed layout/reference warnings before delivery.')
    shutil.copy2(build / 'report.pdf', ROOT / 'report.pdf')
    (ROOT / 'results/build.json').write_text(json.dumps({
        'status': 'PASS', 'engine': Path(executable).name,
        'passes': 3, 'overfull_boxes': 0, 'unresolved_references': 0,
        'pdf_bytes': (ROOT / 'report.pdf').stat().st_size
    }, indent=2) + '\n')
    print('PASS: report.pdf compiled without overfull boxes or unresolved references.')


if __name__ == '__main__':
    main()
