/-
Constructive kernel for PRA from positive constancy and a transposition law.
Lean 4.19.0, core library only.

The carrier is arbitrary. The forward kernel assumes neither induction nor
decidable equality on it. Computation equations and the required positive-
constancy instance are explicit hypotheses. The formula datatype is a semantic
propositional kernel: its
atoms contain carrier values, not encoded first-order terms. This file does not
formalize the complete description language or the bi-interpretation metatheorem.
-/

namespace TranspositionKernel

universe u

variable {A : Type u}

theorem successor_injective
    (s p : A → A) (p_s : ∀ x, p (s x) = x) :
    ∀ x y, s x = s y → x = y := by
  intro x y h
  calc
    x = p (s x) := (p_s x).symm
    _ = p (s y) := congrArg p h
    _ = y := p_s y

theorem successor_ne_zero
    (z : A) (s p : A → A) (p_z : p z = z)
    (p_s : ∀ x, p (s x) = x) (separation : z ≠ s z) :
    ∀ x, s x ≠ z := by
  intro x h
  have hx : x = z := by
    calc
      x = p (s x) := (p_s x).symm
      _ = p z := congrArg p h
      _ = z := p_z
  have hs : s z = z := by simpa [hx] using h
  exact separation hs.symm

theorem transposition_diagonal
    (z : A) (r : A → A → A)
    (r_zero : ∀ y, r z y = y)
    (involution : ∀ x y, r (r x y) y = x) :
    ∀ y, r y y = z := by
  intro y
  simpa only [r_zero] using involution z y

theorem transposition_reflection
    (z : A) (r : A → A → A)
    (r_zero : ∀ y, r z y = y)
    (involution : ∀ x y, r (r x y) y = x) :
    ∀ x y, r x y = z ↔ x = y := by
  intro x y
  constructor
  · intro h
    calc
      x = r (r x y) y := (involution x y).symm
      _ = r z y := congrArg (fun a => r a y) h
      _ = y := r_zero y
  · intro h
    subst x
    exact transposition_diagonal z r r_zero involution y

theorem gate_alternative_of_pc
    (z : A) (s : A → A) (b : A → A → A)
    (b_s : ∀ n a, b (s n) a = z)
    (pc_b : ∀ a,
      (∀ n, b (s (s n)) a = b (s n) a) →
      ∀ n, n = z ∨ b n a = b (s z) a) :
    ∀ n a, n = z ∨ b n a = z := by
  intro n a
  have hp := pc_b a (fun k => (b_s (s k) a).trans (b_s k a).symm) n
  simpa only [b_s] using hp

theorem zero_decision
    (z one : A) (b : A → A → A) (separation : z ≠ one)
    (b_zero : ∀ a, b z a = a)
    (alternative : ∀ n a, n = z ∨ b n a = z) :
    ∀ n, n = z ∨ n ≠ z := by
  intro n
  cases alternative n one with
  | inl h => exact Or.inl h
  | inr h =>
      apply Or.inr
      intro hn
      have ho : one = z := by simpa only [hn, b_zero] using h
      exact separation ho.symm

theorem gate_nonzero
    (z : A) (b : A → A → A)
    (alternative : ∀ n a, n = z ∨ b n a = z) :
    ∀ n a, n ≠ z → b n a = z := by
  intro n a hn
  cases alternative n a with
  | inl h => exact False.elim (hn h)
  | inr h => exact h

theorem gate_zero_value
    (z : A) (b : A → A → A) (b_zero : ∀ a, b z a = a)
    (alternative : ∀ n a, n = z ∨ b n a = z) :
    ∀ n, b n z = z := by
  intro n
  cases alternative n z with
  | inl h => simpa only [h] using b_zero z
  | inr h => exact h

theorem equality_decision
    (z : A) (r : A → A → A)
    (zero_dec : ∀ n, n = z ∨ n ≠ z)
    (reflection : ∀ x y, r x y = z ↔ x = y) :
    ∀ x y : A, x = y ∨ x ≠ y := by
  intro x y
  cases zero_dec (r x y) with
  | inl h => exact Or.inl ((reflection x y).mp h)
  | inr h => exact Or.inr (fun hxy => h ((reflection x y).mpr hxy))

def selector
    (s : A → A) (b pInit : A → A → A) (test yes no : A) : A :=
  pInit (b test (s yes)) no

theorem selector_at_zero
    (z : A) (s : A → A) (b pInit : A → A → A)
    (b_zero : ∀ a, b z a = a)
    (pInit_s : ∀ n a, pInit (s n) a = n) :
    ∀ yes no, selector s b pInit z yes no = yes := by
  intro yes no
  simp only [selector, b_zero, pInit_s]

theorem selector_at_nonzero
    (z : A) (s : A → A) (b pInit : A → A → A)
    (b_nonzero : ∀ n a, n ≠ z → b n a = z)
    (pInit_zero : ∀ a, pInit z a = a) :
    ∀ test yes no, test ≠ z → selector s b pInit test yes no = no := by
  intro test yes no hn
  simp only [selector, b_nonzero test (s yes) hn, pInit_zero]

/- Only the particular latch q and its PC instance occur in this theorem. -/
theorem latch_induction
    (z : A) (s : A → A) (b : A → A → A)
    (separation : z ≠ s z)
    (s_nonzero : ∀ n, s n ≠ z)
    (zero_dec : ∀ n, n = z ∨ n ≠ z)
    (b_zero : ∀ a, b z a = a)
    (b_nonzero : ∀ n a, n ≠ z → b n a = z)
    (b_zero_value : ∀ n, b n z = z)
    (e q : A → A)
    (q_zero : q z = s z)
    (q_step : ∀ n, q (s n) = b (e n) (q n))
    (pc_q : (∀ n, q (s (s n)) = q (s n)) →
      ∀ n, n = z ∨ q n = q (s z))
    (base : e z = z)
    (progress : ∀ n, e n = z → e (s n) = z) :
    ∀ n, e n = z := by
  have q_one : q (s z) = s z := by
    calc
      q (s z) = b (e z) (q z) := q_step z
      _ = b z (s z) := by rw [base, q_zero]
      _ = s z := b_zero (s z)
  have stationary : ∀ n, q (s (s n)) = q (s n) := by
    intro n
    cases zero_dec (e n) with
    | inl hn =>
        calc
          q (s (s n)) = b (e (s n)) (q (s n)) := q_step (s n)
          _ = b z (q (s n)) := by rw [progress n hn]
          _ = q (s n) := b_zero (q (s n))
    | inr hn =>
        have hq : q (s n) = z :=
          (q_step n).trans (b_nonzero (e n) (q n) hn)
        calc
          q (s (s n)) = b (e (s n)) (q (s n)) := q_step (s n)
          _ = b (e (s n)) z := by rw [hq]
          _ = z := b_zero_value (e (s n))
          _ = q (s n) := hq.symm
  intro n
  have hq_one : q (s n) = s z := by
    cases pc_q stationary (s n) with
    | inl hn => exact False.elim (s_nonzero n hn)
    | inr hn => exact hn.trans q_one
  cases zero_dec (e n) with
  | inl hn => exact hn
  | inr hn =>
      have hq_zero : q (s n) = z :=
        (q_step n).trans (b_nonzero (e n) (q n) hn)
      exact False.elim (separation (hq_zero.symm.trans hq_one))

inductive Formula (A : Type u) where
  | atom : A → A → Formula A
  | falsum : Formula A
  | conj : Formula A → Formula A → Formula A
  | disj : Formula A → Formula A → Formula A
  | impl : Formula A → Formula A → Formula A

def Formula.truth : Formula A → Prop
  | .atom x y => x = y
  | .falsum => False
  | .conj a b => a.truth ∧ b.truth
  | .disj a b => a.truth ∨ b.truth
  | .impl a b => a.truth → b.truth

def Formula.error
    (z one : A) (r : A → A → A) (c : A → A → A → A) : Formula A → A
  | .atom x y => r x y
  | .falsum => one
  | .conj a b => c (a.error z one r c) (b.error z one r c) one
  | .disj a b => c (a.error z one r c) z (b.error z one r c)
  | .impl a b => c (a.error z one r c) (b.error z one r c) z

theorem formula_compiler_correct
    (z one : A) (r : A → A → A) (c : A → A → A → A)
    (separation : z ≠ one)
    (zero_dec : ∀ n, n = z ∨ n ≠ z)
    (reflection : ∀ x y, r x y = z ↔ x = y)
    (c_zero : ∀ yes no, c z yes no = yes)
    (c_nonzero : ∀ test yes no, test ≠ z → c test yes no = no) :
    ∀ f : Formula A, f.error z one r c = z ↔ f.truth := by
  intro f
  induction f with
  | atom x y => exact reflection x y
  | falsum =>
      constructor
      · intro h
        exact separation h.symm
      · intro h
        exact False.elim h
  | conj a b ia ib =>
      change c (a.error z one r c) (b.error z one r c) one = z ↔
        (a.truth ∧ b.truth)
      cases zero_dec (a.error z one r c) with
      | inl ha =>
          rw [ha, c_zero]
          exact ⟨fun hb => ⟨ia.mp ha, ib.mp hb⟩, fun h => ib.mpr h.2⟩
      | inr ha =>
          rw [c_nonzero _ _ _ ha]
          constructor
          · intro h
            exact False.elim (separation h.symm)
          · intro h
            exact False.elim (ha (ia.mpr h.1))
  | disj a b ia ib =>
      change c (a.error z one r c) z (b.error z one r c) = z ↔
        (a.truth ∨ b.truth)
      cases zero_dec (a.error z one r c) with
      | inl ha =>
          rw [ha, c_zero]
          exact ⟨fun _ => Or.inl (ia.mp ha), fun _ => rfl⟩
      | inr ha =>
          rw [c_nonzero _ _ _ ha]
          constructor
          · intro h
            exact Or.inr (ib.mp h)
          · intro h
            cases h with
            | inl ht => exact False.elim (ha (ia.mpr ht))
            | inr ht => exact ib.mpr ht
  | impl a b ia ib =>
      change c (a.error z one r c) (b.error z one r c) z = z ↔
        (a.truth → b.truth)
      cases zero_dec (a.error z one r c) with
      | inl ha =>
          rw [ha, c_zero]
          exact ⟨fun hb _ => ib.mp hb, fun h => ib.mpr (h (ia.mp ha))⟩
      | inr ha =>
          rw [c_nonzero _ _ _ ha]
          constructor
          · intro _ ht
            exact False.elim (ha (ia.mpr ht))
          · intro _
            rfl

theorem formula_induction_from_error_instance
    (z : A) (s : A → A) (error : Formula A → A)
    (correct : ∀ f, error f = z ↔ f.truth)
    (f : A → Formula A)
    (error_induction : error (f z) = z →
      (∀ n, error (f n) = z → error (f (s n)) = z) →
      ∀ n, error (f n) = z)
    (base : (f z).truth)
    (progress : ∀ n, (f n).truth → (f (s n)).truth) :
    ∀ n, (f n).truth := by
  have hz := error_induction ((correct (f z)).mpr base)
    (fun n hn => (correct (f (s n))).mpr (progress n ((correct (f n)).mp hn)))
  exact fun n => (correct (f n)).mp (hz n)

/- Converse kernel: a genuine transposition satisfies the involution law. -/
theorem involution_from_swap_cases
    (z : A) (r : A → A → A)
    (zero_dec : ∀ n, n = z ∨ n ≠ z)
    (eq_dec : ∀ x y : A, x = y ∨ x ≠ y)
    (r_zero : ∀ y, r z y = y)
    (r_equal : ∀ x, x ≠ z → r x x = z)
    (r_other : ∀ x y, x ≠ z → x ≠ y → r x y = x) :
    ∀ x y, r (r x y) y = x := by
  have diagonal : ∀ y, r y y = z := by
    intro y
    cases zero_dec y with
    | inl hy => simpa only [hy] using r_zero z
    | inr hy => exact r_equal y hy
  intro x y
  cases zero_dec x with
  | inl hx => simpa only [hx, r_zero] using diagonal y
  | inr hx =>
      cases eq_dec x y with
      | inl hxy =>
          subst y
          rw [diagonal, r_zero]
      | inr hxy =>
          rw [r_other x y hx hxy, r_other x y hx hxy]

/- The converse PC proof uses just its indicated equation-induction instance. -/
theorem positive_constancy_from_induction
    (z : A) (s p : A → A)
    (coverage : ∀ n, n = z ∨ n = s (p n))
    (f : A → A)
    (induction_instance :
      f (s z) = f (s z) →
      (∀ n, f (s n) = f (s z) → f (s (s n)) = f (s z)) →
      ∀ n, f (s n) = f (s z))
    (stationary : ∀ n, f (s (s n)) = f (s n)) :
    ∀ n, n = z ∨ f n = f (s z) := by
  have hs := induction_instance rfl (fun n hn => (stationary n).trans hn)
  intro n
  cases coverage n with
  | inl hn => exact Or.inl hn
  | inr hn => exact Or.inr ((congrArg f hn).trans (hs (p n)))

#print axioms successor_ne_zero
#print axioms transposition_reflection
#print axioms gate_alternative_of_pc
#print axioms zero_decision
#print axioms latch_induction
#print axioms formula_compiler_correct
#print axioms formula_induction_from_error_instance
#print axioms involution_from_swap_cases
#print axioms positive_constancy_from_induction

end TranspositionKernel
