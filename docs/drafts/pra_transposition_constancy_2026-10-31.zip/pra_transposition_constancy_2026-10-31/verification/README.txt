CONSTRUCTIVE LEAN CERTIFICATE

Run with Lean 4.19.0:

    lean TranspositionKernel.lean

No Mathlib or additional package is needed. The recorded compilation exits
successfully. Nine explicitly printed axiom audits report no global axioms.

WHAT IS CHECKED

The carrier A is arbitrary. The certificate derives successor separation,
native equality reflection from the involution law, zero decisions from the
gate instances of positive constancy, selector laws, and the latch argument
for induction on t(n)=0. It also checks the formula-error compiler for equality,
falsehood, conjunction, disjunction, and intuitionistic implication, and its
use to transfer an indicated error-induction instance to formula induction.
Two converse interfaces check the involution from actual transposition cases
and positive constancy from coverage and the indicated equation induction.

WHAT THE AXIOM AUDITS MEAN

The computation equations, nontriviality, involution, positive-constancy
instances, and auxiliary interfaces appear as explicit theorem hypotheses.
An empty global-axiom audit does not erase these assumptions. The forward
kernel assumes neither an induction principle nor decidable equality on A.
Derived interfaces accept these facts explicitly where they are used; the
converse PC lemma accepts its particular equation-induction instance, and
the converse transposition lemma accepts zero and equality decisions. The
only induction used in the compiler theorem is on its finite Formula datatype.

PRECISE LIMITS

Formula is a semantic propositional kernel: an atomic formula contains two
values of A. It is not an encoding of first-order terms, valuations, bound
variables, or proofs. The complete primitive-recursive description grammar,
the ordinary PRA proof of the monus equality bit, and the metatheorem of
bi-interpretability are established in the article, not in this certificate.

FILES

TranspositionKernel.lean   The certificate.
lean_compile.log          Successful compiler output and nine axiom audits.
validation.json           Exact scope, source hash, and declaration inventory.
