#!/usr/bin/env python3
"""Finite diagnostics for the transposition/constancy presentation of PRA.

The interpreter below accepts only a finite, acyclic sequence of ordinary
primitive-recursion descriptions. Its natural-number computations check the
article's concrete programs, their parameter discipline, and its formula-error
compiler. These computations are NOT a formal proof of an axiom schema,
intuitionistic validity, bi-interpretability, or consistency.

Run with Python 3.10 or newer; no third-party packages are required:
    python3 artifacts/check_constructions.py

Descriptions use De Bruijn-style integer variable slots. A recursion with m
frozen parameters has base context (a_1,...,a_m), step context
(n, previous_value, a_1,...,a_m), and arity m+1. Calls can refer only to
earlier descriptions. Composition is literal finite term substitution.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from functools import lru_cache
import json
from pathlib import Path
import sys
from typing import Sequence


@dataclass(frozen=True)
class Term:
    op: str
    value: int | str | None = None
    args: tuple["Term", ...] = ()


def zero() -> Term:
    return Term("zero")


def var(index: int) -> Term:
    return Term("var", index)


def succ(t: Term) -> Term:
    return Term("succ", args=(t,))


def call(name: str, *args: Term) -> Term:
    return Term("call", name, args)


ONE = succ(zero())


def substitute(t: Term, replacements: Sequence[Term]) -> Term:
    """Simultaneous, capture-free term substitution; terms have no binders."""
    if t.op == "var":
        assert isinstance(t.value, int)
        return replacements[t.value]
    return Term(t.op, t.value, tuple(substitute(a, replacements) for a in t.args))


def zero_indicator(t: Term) -> Term:
    """Z(t)=B(t,1); a macro, not an additional primitive symbol."""
    return call("B", t, ONE)


def equality_bit(x: Term, y: Term) -> Term:
    """E(x,y)=B(M(x,y),B(M(y,x),1)); fully expanded in descriptors."""
    return call("B", call("M", x, y), call("B", call("M", y, x), ONE))


def selector(z: Term, u: Term, v: Term) -> Term:
    """C(z,u,v)=P(B(z,S(u)),v); needs no extra recursion symbol."""
    return call("P", call("B", z, succ(u)), v)


@dataclass(frozen=True)
class Recursion:
    name: str
    parameters: tuple[str, ...]
    base: Term
    step: Term

    @property
    def arity(self) -> int:
        return len(self.parameters) + 1


class ProgramError(ValueError):
    pass


def validate_term(t: Term, context_size: int, known: dict[str, Recursion]) -> None:
    if t.op == "zero":
        if t.value is not None or t.args:
            raise ProgramError("Malformed zero term")
    elif t.op == "var":
        if not isinstance(t.value, int) or not 0 <= t.value < context_size or t.args:
            raise ProgramError("Variable is outside its description's context")
    elif t.op == "succ":
        if t.value is not None or len(t.args) != 1:
            raise ProgramError("Malformed successor term")
    elif t.op == "call":
        if t.value not in known:
            raise ProgramError("Calls must refer to an earlier description")
        if len(t.args) != known[t.value].arity:
            raise ProgramError("Call has the wrong numerical arity")
    else:
        raise ProgramError("Unknown term operation")
    for a in t.args:
        validate_term(a, context_size, known)


class Interpreter:
    def __init__(self, descriptions: Sequence[Recursion]):
        self.programs: dict[str, Recursion] = {}
        for d in descriptions:
            if d.name in self.programs:
                raise ProgramError("Description names must be fresh")
            validate_term(d.base, len(d.parameters), self.programs)
            validate_term(d.step, len(d.parameters) + 2, self.programs)
            self.programs[d.name] = d

    def term(self, t: Term, context: Sequence[int]) -> int:
        if t.op == "zero":
            return 0
        if t.op == "var":
            assert isinstance(t.value, int)
            return context[t.value]
        if t.op == "succ":
            return self.term(t.args[0], context) + 1
        if t.op == "call":
            assert isinstance(t.value, str)
            return self.function(t.value, tuple(self.term(a, context) for a in t.args))
        raise ProgramError("Interpreter encountered an unknown term")

    @lru_cache(maxsize=None)
    def function(self, name: str, arguments: tuple[int, ...]) -> int:
        d = self.programs[name]
        if len(arguments) != d.arity:
            raise ProgramError("Runtime call has the wrong arity")
        if any(type(a) is not int or a < 0 for a in arguments):
            raise ProgramError("The diagnostic interpreter accepts natural numbers only")
        counter, *parameters = arguments
        value = self.term(d.base, parameters)
        for n in range(counter):
            value = self.term(d.step, (n, value, *parameters))
        return value


def base_descriptions() -> tuple[Recursion, ...]:
    n, previous, a = var(0), var(1), var(2)
    sn = succ(n)
    return (
        Recursion("P", ("a",), var(0), n),
        Recursion("B", ("a",), var(0), zero()),
        Recursion("M", ("a",), var(0), call("P", previous, zero())),
        Recursion("R", ("y",), var(0), call("B", equality_bit(sn, a), sn)),
    )


@dataclass(frozen=True)
class Formula:
    op: str
    terms: tuple[Term, ...] = ()
    parts: tuple["Formula", ...] = ()


def eq(s: Term, t: Term) -> Formula:
    return Formula("eq", (s, t))


def connective(op: str, *parts: Formula) -> Formula:
    return Formula(op, parts=parts)


def error_term(a: Formula) -> Term:
    """Compile finite quantifier-free formulas into zero-valued errors.

    The implication clause is constructively justified in the article by the
    already-derived decision e_A=0 or e_A!=0. It does not assume excluded middle
    for arbitrary formulas. The executable truth-table check below is only a
    standard-natural-number diagnostic of this construction.
    """
    if a.op == "eq":
        s, t = a.terms
        return call("R", s, t)
    if a.op == "false":
        return ONE
    if a.op == "true":
        return zero()
    if a.op == "not":
        return selector(error_term(a.parts[0]), ONE, zero())
    left, right = (error_term(p) for p in a.parts)
    if a.op == "and":
        return selector(left, right, ONE)
    if a.op == "or":
        return selector(left, zero(), right)
    if a.op == "implies":
        return selector(left, right, zero())
    raise ProgramError("Unsupported formula connective")


def formula_value(a: Formula, context: Sequence[int], machine: Interpreter) -> bool:
    if a.op == "eq":
        return machine.term(a.terms[0], context) == machine.term(a.terms[1], context)
    if a.op == "false":
        return False
    if a.op == "true":
        return True
    if a.op == "not":
        return not formula_value(a.parts[0], context, machine)
    left, right = (formula_value(p, context, machine) for p in a.parts)
    if a.op == "and":
        return left and right
    if a.op == "or":
        return left or right
    if a.op == "implies":
        return not left or right
    raise ProgramError("Unsupported formula connective")


def make_latch(name: str, formula: Formula, parameters: tuple[str, ...]) -> Recursion:
    """Input formula slots are (n,a_1,...); recursion adds previous_value at 1."""
    replacements = (var(0), *(var(i + 2) for i in range(len(parameters))))
    step_error = substitute(error_term(formula), replacements)
    return Recursion(name, parameters, ONE, call("B", step_error, var(1)))


def encode_term(t: Term) -> dict:
    result = {"op": t.op}
    if t.value is not None:
        result["value"] = t.value
    if t.args:
        result["args"] = [encode_term(a) for a in t.args]
    return result


def pretty_term(t: Term, context: Sequence[str]) -> str:
    if t.op == "zero":
        return "0"
    if t.op == "var":
        assert isinstance(t.value, int)
        return context[t.value]
    if t.op == "succ":
        return "S(" + pretty_term(t.args[0], context) + ")"
    return str(t.value) + "(" + ", ".join(pretty_term(a, context) for a in t.args) + ")"


def term_calls(t: Term) -> set[str]:
    own = {str(t.value)} if t.op == "call" else set()
    return own.union(*(term_calls(a) for a in t.args))


def free_variables(t: Term) -> set[int]:
    own = {int(t.value)} if t.op == "var" else set()
    return own.union(*(free_variables(a) for a in t.args))


def term_size(t: Term) -> int:
    return 1 + sum(term_size(a) for a in t.args)


def encode_description(d: Recursion) -> dict:
    step_context = ("n", "previous_value", *d.parameters)
    return {
        "name": d.name,
        "arity": d.arity,
        "base_context": list(d.parameters),
        "step_context": list(step_context),
        "base": encode_term(d.base),
        "step": encode_term(d.step),
        "base_readable": pretty_term(d.base, d.parameters),
        "step_readable": pretty_term(d.step, step_context),
        "base_free_variables": sorted(free_variables(d.base)),
        "step_free_variables": sorted(free_variables(d.step)),
        "earlier_dependencies": sorted(term_calls(d.base) | term_calls(d.step)),
        "base_term_nodes": term_size(d.base),
        "step_term_nodes": term_size(d.step),
    }


def run(bound: int) -> tuple[dict, dict]:
    descriptions = base_descriptions()
    n, a, b = var(0), var(1), var(2)
    gate_formula = connective("or", eq(call("B", n, a), zero()), eq(n, zero()))
    crossing_formula = eq(n, a)
    two_parameter_formula = connective("implies", eq(a, b), eq(a, b))
    latches = (
        make_latch("LatchGate", gate_formula, ("a",)),
        make_latch("LatchCrossing", crossing_formula, ("a",)),
        make_latch("LatchTwoParameters", two_parameter_formula, ("a", "b")),
    )
    machine = Interpreter((*descriptions, *latches))
    counts: dict[str, int] = {}

    def check(group: str, statement: bool) -> None:
        counts[group] = counts.get(group, 0) + 1
        if not statement:
            raise AssertionError("Diagnostic failed in " + group)

    for x in range(bound + 1):
        check("zero_indicator", machine.term(zero_indicator(var(0)), (x,)) == int(x == 0))
        for y in range(bound + 1):
            p = machine.function("P", (x, y))
            check("initialized_predecessor", p == (y if x == 0 else x - 1))
            check("zero_gate", machine.function("B", (x, y)) == (y if x == 0 else 0))
            check("monus", machine.function("M", (x, y)) == max(y - x, 0))
            check("equality_bit", machine.term(equality_bit(var(0), var(1)), (x, y)) == int(x == y))
            r = machine.function("R", (x, y))
            expected = y if x == 0 else (0 if x == y else x)
            check("transposition", r == expected)
            check("involution", machine.function("R", (r, y)) == x)
            check("native_equality_error", (r == 0) == (x == y))
            check("latch_true_formula", machine.function("LatchGate", (x, y)) == 1)
            expected_crossing = int(x == 0 or (x == 1 and y == 0))
            check("latch_first_failure", machine.function("LatchCrossing", (x, y)) == expected_crossing)

    atom_left = eq(var(0), var(1))
    atom_right = eq(call("M", var(0), var(1)), zero())
    formulas = [
        atom_left,
        atom_right,
        connective("false"),
        connective("true"),
        connective("not", atom_left),
    ]
    for op in ("and", "or", "implies"):
        formulas.append(connective(op, atom_left, atom_right))
        formulas.append(connective(op, connective("not", atom_left), atom_right))
    formulas.extend([
        connective("implies", connective("and", atom_left, atom_right), atom_left),
        connective("or", atom_left, connective("not", atom_left)),
        connective("not", connective("implies", atom_left, atom_right)),
    ])
    for formula in formulas:
        compiled = error_term(formula)
        validate_term(compiled, 2, machine.programs)
        for x in range(bound + 1):
            for y in range(bound + 1):
                check(
                    "formula_error_compiler",
                    (machine.term(compiled, (x, y)) == 0)
                    == formula_value(formula, (x, y), machine),
                )

    # Nonzero errors need not be Boolean. Check all branch combinations using
    # small, arbitrary natural errors and the exact selector formula.
    for x in range(5):
        for y in range(5):
            for z in range(5):
                check(
                    "selector_arbitrary_values",
                    machine.term(selector(var(0), var(1), var(2)), (x, y, z))
                    == (y if x == 0 else z),
                )

    for x in range(min(bound, 10) + 1):
        for y in range(min(bound, 8) + 1):
            for z in range(min(bound, 8) + 1):
                check("two_frozen_parameters", machine.function("LatchTwoParameters", (x, y, z)) == 1)

    invalid = (
        (Recursion("Bad", (), zero(), var(2)),),
        (Recursion("Bad", (), zero(), call("Bad", var(0))),),
        (*descriptions, Recursion("Bad", (), zero(), call("P", var(0)))),
        (*descriptions, descriptions[0]),
    )
    for programs in invalid:
        try:
            Interpreter(programs)
        except ProgramError:
            check("malformed_descriptions_rejected", True)
        else:
            check("malformed_descriptions_rejected", False)

    # A concrete witness in the coordinatewise product N x N. The article
    # proves the infinite-model claims about this product abstractly; these
    # lines check only the displayed values and failed PC/coverage instance.
    pair_zero, pair_one = (0, 0), (1, 1)
    witness = (0, 1)

    def pair_function(name: str, *arguments: tuple[int, int]) -> tuple[int, int]:
        return tuple(
            machine.function(name, tuple(a[i] for a in arguments)) for i in range(2)
        )

    def pair_successor(value: tuple[int, int]) -> tuple[int, int]:
        return value[0] + 1, value[1] + 1

    predecessor = pair_function("P", witness, pair_zero)
    restored = pair_successor(predecessor)
    gate_value = pair_function("B", witness, pair_one)
    gate_at_one = pair_function("B", pair_one, pair_one)
    coverage_value = witness == pair_zero or witness == restored
    pc_conclusion_value = witness == pair_zero or gate_value == gate_at_one
    check("product_counterexample_witness", predecessor == (0, 0))
    check("product_counterexample_witness", restored == (1, 1))
    check("product_counterexample_witness", gate_value == (1, 0))
    check("product_counterexample_witness", gate_at_one == (0, 0))
    check("product_counterexample_witness", not coverage_value)
    check("product_counterexample_witness", not pc_conclusion_value)

    scope = (
        "Finite computations in the standard natural numbers and structural "
        "checks of finite syntax. These are not a proof of any infinite axiom "
        "schema, intuitionistic validity, consistency, or bi-interpretability."
    )
    results = {
        "status": "PASS",
        "scope": scope,
        "python_version": sys.version.split()[0],
        "bound_inclusive": bound,
        "checks": counts,
        "total_checks": sum(counts.values()),
        "formula_count": len(formulas),
        "descriptions_validated": len(machine.programs),
        "product_counterexample": {
            "carrier": "N x N; every described operation acts coordinatewise",
            "witness_n": list(witness),
            "zero": list(pair_zero),
            "one_and_gate_parameter": list(pair_one),
            "p_n": list(predecessor),
            "S_p_n": list(restored),
            "B_n_one": list(gate_value),
            "B_one_one": list(gate_at_one),
            "coverage_conclusion": coverage_value,
            "positive_constancy_conclusion_for_B": pc_conclusion_value,
            "PC_premise_reason": (
                "For every pair n, both B(S(S(n)),one) and B(S(n),one) "
                "are (0,0), since each successor coordinate is positive."
            ),
            "abstract_model_claims": (
                "The article proves that the whole product satisfies D, "
                "separation, involution, ordinary constancy, and every "
                "equation-induction instance. This diagnostic verifies only "
                "the displayed counterexample values, not those infinite claims."
            ),
        },
        "intuitionistic_compiler_qualification": (
            "The article proves the implication clause from derived zero "
            "decidability. This program checks its natural-number truth table "
            "only; it does not implement an intuitionistic proof checker."
        ),
    }
    certificate = {
        "format": "pra-transposition-pr-descriptions-v1",
        "scope": scope,
        "grammar": {
            "terms": ["zero", "var(slot)", "succ(term)", "call(earlier_name,args)"],
            "recursion": "F(0,params)=base(params); F(S(n),params)=step(n,F(n,params),params)",
            "variable_convention": "Zero-based slots in the listed contexts",
            "acyclicity": "Every call names a strictly earlier description",
        },
        "macros": {
            "Z": "B(x,S(0))",
            "E": "B(M(x,y),B(M(y,x),S(0)))",
            "C": "P(B(z,S(u)),v)",
        },
        "descriptions": [encode_description(d) for d in (*descriptions, *latches)],
        "latch_formulas": {
            "LatchGate": "B(n,a)=0 or n=0",
            "LatchCrossing": "n=a",
            "LatchTwoParameters": "(a=b) implies (a=b)",
        },
        "sample_latch_values": {
            str(a): [machine.function("LatchCrossing", (n, a)) for n in range(7)]
            for a in range(4)
        },
    }
    return results, certificate


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bound", type=int, default=24)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    if args.bound < 0:
        parser.error("--bound must be nonnegative")
    results, certificate = run(args.bound)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for filename, payload in (
        ("construction_checks.json", results),
        ("program_descriptions.json", certificate),
    ):
        (args.output_dir / filename).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
