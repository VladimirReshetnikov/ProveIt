#!/usr/bin/env python3
"""Reproduce the disclosed formula-tree metrics for the transposition basis.

Run with Python 3.10 or later; no third-party dependencies are needed:
    python3 artifacts/schema_metrics.py

The default output is schema_metrics.json beside this script.  These are
syntactic display counts, not bit-length bounds or mathematical proof checks.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class Node:
    kind: str
    label: str
    children: tuple["Node", ...] = ()

    def count(self) -> int:
        return 1 + sum(child.count() for child in self.children)

    def occurrences(self, kind: str) -> int:
        return int(self.kind == kind) + sum(
            child.occurrences(kind) for child in self.children
        )

    def sexpr(self) -> str:
        if not self.children:
            return self.label
        head = f"forall {self.label}" if self.kind == "forall" else self.label
        return "(" + head + " " + " ".join(c.sexpr() for c in self.children) + ")"


def variable(name: str) -> Node:
    return Node("variable", name)


def application(name: str, *arguments: Node) -> Node:
    return Node("application", name, arguments)


def equality(left: Node, right: Node) -> Node:
    return Node("equality", "=", (left, right))


def connective(name: str, *arguments: Node) -> Node:
    return Node("connective", name, arguments)


def forall(names: Iterable[str], body: Node) -> Node:
    for name in reversed(tuple(names)):
        body = Node("forall", name, (body,))
    return body


ZERO = Node("constant", "0")
BOTTOM = Node("bottom", "bottom")


def successor(argument: Node) -> Node:
    return application("S", argument)


def separation() -> Node:
    return connective("implies", equality(ZERO, successor(ZERO)), BOTTOM)


def involution() -> Node:
    x, y = variable("x"), variable("y")
    return forall(("x", "y"), equality(application("R", application("R", x, y), y), x))


def retraction() -> Node:
    n, a = variable("n"), variable("a")
    return forall(("n", "a"), equality(application("M", n, application("A", n, a)), a))


def minimum_symmetry() -> Node:
    x, y = variable("x"), variable("y")
    left = application("M", application("M", x, y), y)
    right = application("M", application("M", y, x), x)
    return forall(("x", "y"), equality(left, right))


def parameters(count: int) -> tuple[tuple[str, ...], tuple[Node, ...]]:
    names = tuple(f"a{i + 1}" for i in range(count))
    return names, tuple(variable(name) for name in names)


def positive_constancy(count: int) -> Node:
    names, args = parameters(count)
    n = variable("n")

    def f(argument: Node) -> Node:
        return application("f", argument, *args)

    premise = forall(("n",), equality(f(successor(successor(n))), f(successor(n))))
    conclusion = forall(
        ("n",), connective("or", equality(n, ZERO), equality(f(n), f(successor(ZERO))))
    )
    return forall(names, connective("implies", premise, conclusion))


def positive_equation_induction(count: int) -> Node:
    names, args = parameters(count)
    n = variable("n")

    def equation(argument: Node) -> Node:
        return equality(application("s", argument, *args), application("t", argument, *args))

    guarded = connective("or", equality(n, ZERO), equation(n))
    premise = forall(("n",), connective("implies", guarded, equation(successor(n))))
    return forall(names, connective("implies", premise, forall(("n",), guarded)))


def positive_successor(
    count: int, *, packed: bool, predecessor: str = "inherited", delayed: bool = False
) -> Node:
    names, args = parameters(count)
    n = variable("n")

    def f(argument: Node) -> Node:
        return application("f", argument, *args)

    premise = forall(("n",), equality(f(successor(n)), successor(f(n))))
    if delayed:
        comparison = successor(application("D_S", n, f(ZERO)))
    else:
        pred = application("P", n, ZERO) if predecessor == "inherited" else application("p", n)
        comparison = successor(application("A", pred, f(ZERO)))
    conclusion = forall(
        ("n",), connective("or", equality(n, ZERO), equality(f(n), comparison))
    )
    if packed:
        conclusion = connective("and", separation(), conclusion)
    return forall(names, connective("implies", premise, conclusion))


def full_computation(count: int) -> tuple[Node, Node]:
    names, args = parameters(count)
    n = variable("n")
    base = forall(names, equality(application("F_g_h", ZERO, *args), application("g", *args)))
    step = forall(
        ("n", *names),
        equality(
            application("F_g_h", successor(n), *args),
            application("h", n, application("F_g_h", n, *args), *args),
        ),
    )
    return base, step


def binary_computation() -> tuple[Node, Node]:
    n, a = variable("n"), variable("a")
    base = forall(("a",), equality(application("I_h", ZERO, a), a))
    step = forall(
        ("n", "a"),
        equality(
            application("I_h", successor(n), a),
            application("h", n, application("I_h", n, a)),
        ),
    )
    return base, step


def stationary_separation(count: int) -> Node:
    names, args = parameters(count)
    n = variable("n")

    def f(argument: Node) -> Node:
        return application("f", argument, *args)

    premise = forall(("n",), equality(f(successor(n)), f(n)))
    conclusion = forall(
        ("n",), connective("implies", equality(successor(f(n)), f(ZERO)), BOTTOM)
    )
    return forall(names, connective("implies", premise, conclusion))


def flat_meet() -> Node:
    x, y = variable("x"), variable("y")
    return forall(
        ("x", "y"),
        connective(
            "and", equality(application("m", x, x), x),
            connective("or", equality(application("m", x, y), ZERO), equality(x, y)),
        ),
    )


def describe(node: Node) -> dict:
    return {
        "nodes": node.count(),
        "equalities": node.occurrences("equality"),
        "quantifiers": node.occurrences("forall"),
        "tree": node.sexpr(),
    }


def compute_metrics() -> dict:
    sep, inv, ret, minimum = separation(), involution(), retraction(), minimum_symmetry()
    assert (sep.count(), inv.count(), ret.count(), minimum.count()) == (6, 9, 9, 13)
    rows = []
    computation_rows = []
    for count in range(6):
        pc, pi = positive_constancy(count), positive_equation_induction(count)
        assert pc.count() == 21 + 5 * count
        assert pi.count() == 29 + 7 * count
        variants = {}
        for pred in ("inherited", "unary"):
            for packed in (True, False):
                schema = positive_successor(count, packed=packed, predecessor=pred)
                total = schema.count() + ret.count() + (0 if packed else sep.count())
                expected = 40 + 5 * count - int(pred == "unary") - int(not packed)
                assert total == expected
                key = f"{pred}_p_{'packed' if packed else 'separated'}"
                variants[key] = {"schema": describe(schema), "arithmetic_total": total}
        for packed in (True, False):
            schema = positive_successor(count, packed=packed, delayed=True)
            total = schema.count() + ret.count() + (0 if packed else sep.count())
            assert total == 38 + 5 * count - int(not packed)
            key = f"delayed_{'packed' if packed else 'separated'}"
            variants[key] = {"schema": describe(schema), "arithmetic_total": total}
        rows.append({
            "passive_parameter_count": count,
            "PC": describe(pc),
            "PI": describe(pi),
            "new_PC_Sep_Inv_arithmetic_total": pc.count() + sep.count() + inv.count(),
            "PI_Sep_arithmetic_total": pi.count() + sep.count(),
            "full_language_PC_Sep_Min_arithmetic_total": pc.count() + sep.count() + minimum.count(),
            "PS_Ret_variants": variants,
        })
        base, step = full_computation(count)
        assert (base.count(), step.count()) == (4 + 3 * count, 9 + 4 * count)
        computation_rows.append({
            "descriptor_parameter_count": count,
            "base": describe(base), "step": describe(step),
            "sum": base.count() + step.count(),
        })

    k, y, v = variable("k"), variable("y"), variable("v")
    sk = successor(k)
    equality_indicator = application(
        "B", application("M", sk, y),
        application("B", application("M", y, sk), successor(ZERO)),
    )
    transposition_step = application("B", equality_indicator, sk)
    delayed_step = application("P", application("B", k, successor(v)), successor(v))
    assert equality_indicator.count() == 12
    assert transposition_step.count() == 15
    assert y.count() + transposition_step.count() == 16
    assert delayed_step.count() == 7

    binary_base, binary_step = binary_computation()
    ss, flat = stationary_separation(1), flat_meet()
    assert (binary_base.count(), binary_step.count(), ss.count(), flat.count()) == (6, 12, 22, 17)
    return {
        "metric": {
            "charge": "One node per variable occurrence, constant, application, equality, "
                      "connective, falsity, and single-variable quantifier.",
            "expansions": ["1 = S(0)", "not A = (A implies bottom)"],
            "parameter_quantifiers": "Counted separately for every passive variable.",
            "schematic_calls": "Charge the displayed application and arguments of f, s, t, "
                               "g, h; do not expand the arbitrary substituted program body.",
            "stored_descriptions": "Not numerical arguments; disclosed separately from formula trees.",
            "predecessor_conventions": "The old retraction table expands p(n) as P(n,0). "
                                       "Both that convention and designated unary p are reported.",
            "packing": "Separated totals sum separately closed sentences, without an extra "
                       "conjunction. Packed PS puts Sep in its conclusion.",
            "scope": "Syntactic accounting only; no proof of absolute minimality or bi-interpretability.",
        },
        "fixed_axioms": {"Sep": describe(sep), "Inv": describe(inv),
                         "Ret": describe(ret), "Min": describe(minimum)},
        "arithmetic_rows": rows,
        "full_computation_templates": {
            "warning": "The grammar admits all finite descriptor parameter counts. These "
                       "counts are separate from the passive-parameter count of an arithmetic "
                       "instance and are not replaced by the binary grammar's 18-node sum.",
            "rows": computation_rows,
        },
        "designated_transposition_description": {
            "base": describe(y), "step": describe(transposition_step),
            "base_plus_step_nodes": y.count() + transposition_step.count(),
            "unused_recursion_state": "v",
            "step_description": "R(S(k),y)=B(B(M(S(k),y),B(M(y,S(k)),S(0))),S(k))",
            "meaning": "The full PR grammar permits the frozen parameter y directly.",
        },
        "old_delayed_successor_descriptor": {
            "step": describe(delayed_step),
            "note": "The seven-node stored wrapper is disclosed separately from its shorter formula.",
        },
        "strict_binary_benchmark": {
            "source": "pra_stationary_separation_2026-10-31, flat-meet variant",
            "D_base": describe(binary_base), "D_step": describe(binary_step),
            "SS_one_parameter": describe(ss), "Flat": describe(flat),
            "total": binary_base.count() + binary_step.count() + ss.count() + flat.count(),
            "comparison_limit": "This 57-node total uses a different restricted binary grammar "
                                "and a primitive flat-meet symbol. No claim that the present "
                                "full-language result beats this total is made.",
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_suffix(".json"))
    args = parser.parse_args()
    result = compute_metrics()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "output": str(args.output.resolve()),
        "parameter_counts_checked": list(range(6)),
        "one_parameter_new_arithmetic": result["arithmetic_rows"][1]["new_PC_Sep_Inv_arithmetic_total"],
        "one_parameter_PI_arithmetic": result["arithmetic_rows"][1]["PI_Sep_arithmetic_total"],
        "R_description_nodes": result["designated_transposition_description"]["base_plus_step_nodes"],
        "strict_binary_benchmark": result["strict_binary_benchmark"]["total"],
        "all_internal_consistency_checks": "passed",
    }, indent=2))


if __name__ == "__main__":
    main()
