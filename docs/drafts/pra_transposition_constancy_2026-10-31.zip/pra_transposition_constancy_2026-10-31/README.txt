PRA FROM TRANSPOSITION AND POSITIVE CONSTANCY
Research package prepared for Vladimir Reshetnikov
31 October 2026 (America/Los_Angeles)

MAIN RESULT

In the ordinary effective language of all finite primitive-recursion
descriptions, retain their defining equations D. Add 0 != S0, the fixed
involution law R(R(x,y),y)=x, and positive constancy:

  [for every n, f(SSn,a)=f(Sn,a)] implies
  [for every n, n=0 or f(n,a)=f(S0,a)].

Here a denotes an arbitrary finite tuple of frozen parameters and f is
a finite term, not a quantified function variable. R is the particular
primitive-recursive transposition given in the article, not an arbitrary
new operation. The same nonlogical axioms yield classical PRA in classical
logic and intuitionistic PRA in intuitionistic logic. In the common
description language the theories are deductively equal. Both
interpretations and both round trips are literal identities.

THE NEW PART AND ITS LIMIT

This completes the involution direction explicitly suggested in the
minimum-symmetry draft, with an elementary finite program and a full
constructive equivalence proof. The fixed involution equation has 9 AST
nodes; its selected program has a separately disclosed 16-node description.
The one-parameter arithmetic subtotal is 41 versus 42 for positive equation
induction in the same full recursion grammar. The parameter-free comparison
goes the other way. No absolute shortest-presentation claim is made.

The strict binary-iterator presentation's 57-node benchmark uses a different
computation grammar. The 41-node figure here is an arithmetic subtotal and
must not be compared directly to that total.

FILES

  pra_transposition_constancy.tex
      Complete article source, including the exact axioms, both proofs,
      bi-interpretations, comparison, and a product countermodel.

  pra_transposition_constancy.pdf
      Compiled article.

  artifacts/check_constructions.py
  artifacts/construction_checks.json
  artifacts/program_descriptions.json
      Finite PR syntax, arity/dependency validation, explicit transposition
      program, formula compiler, sample latches, and numerical diagnostics.

  artifacts/schema_metrics.py
  artifacts/schema_metrics.json
  artifacts/comparison.json
      Reproducible AST counts, parameter/packing alternatives, comparison
      scope, and attribution.

  verification/TranspositionKernel.lean
  verification/lean_compile.log
  verification/validation.json
  verification/README.txt
      Constructive Lean 4.19.0 proof kernel. Sixteen checked theorems;
      nine explicit global-axiom audits report no axioms. Computation,
      arithmetic, and particular schema-instance hypotheses are explicit.

  audit/SOURCES.json
      Exact GitHub snapshot, immutable input URLs, Git blob hashes,
      SHA-256 checks, and the earlier involution suggestion's location.

  build.py
      Rebuild the PDF, run the Python checks, and optionally replay Lean.

  validation_summary.json
  CHECKSUMS.sha256
      Package validation scope and file integrity.

VERIFICATION SCOPE

The Lean certificate checks the abstract forward arithmetic kernel,
the semantic propositional compiler including implication, and two
converse interfaces. It does not formalize the full first-order language,
proof calculus, source-level compiler, or complete bi-interpretability
metatheorem. Those are proved in the article. Explicit theorem hypotheses
are not additional global Lean axioms.

The 15,426 Python checks are finite diagnostics in standard natural numbers
and checks of finite syntax. They are not proofs of infinite schemas,
intuitionistic validity, equiconsistency, or bi-interpretability.

REPRODUCTION

Requirements:
  Python 3.10 or later, standard library only.
  A TeX installation with pdflatex, amsmath, amsthm, mathtools, lmodern,
  microtype, geometry, booktabs, tabularx, enumitem, xcolor, fancyhdr,
  needspace, xurl, and hyperref.
  Lean 4.19.0 for the optional formal replay; no Mathlib dependency.

From this directory:

  python3 build.py

To include formal replay:

  python3 build.py --lean /absolute/path/to/lean

Individual checks:

  python3 artifacts/check_constructions.py
  python3 artifacts/schema_metrics.py
  lean verification/TranspositionKernel.lean

Rebuilding may change PDF bytes because of TeX metadata, and intentionally
changes the locally generated check records. CHECKSUMS.sha256 describes the
delivered files; it is not automatically rewritten by build.py.

SOURCE SNAPSHOT

Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 7bbc3e9bd2f3c154d27195edd1af2be179bca563
Compared: all six archives then present in docs/drafts; incoming inventory
and complete README. Unrelated incoming machine-search ZIPs were not unpacked.
The original input ZIPs are not redistributed in this package.
