#!/usr/bin/env python3
"""Rebuild the report and its finite checks; optionally replay the Lean kernel."""

from __future__ import annotations

import argparse
from pathlib import Path
import shutil
import subprocess
import sys


def run(args: list[str], root: Path, log: Path | None = None) -> None:
    print("Running:", " ".join(args), flush=True)
    result = subprocess.run(args, cwd=root, text=True, capture_output=True)
    if log is not None:
        log.write_text(result.stdout + result.stderr, encoding="utf-8")
    if result.returncode:
        print(result.stdout)
        print(result.stderr, file=sys.stderr)
        raise SystemExit(result.returncode)
    if log is None and result.stdout.strip():
        print(result.stdout.rstrip())


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Lean 4.19.0 executable for formal replay")
    options = parser.parse_args()
    root = Path(__file__).resolve().parent
    build = root / "build"
    build.mkdir(exist_ok=True)
    for script in ("check_constructions.py", "schema_metrics.py"):
        run([sys.executable, str(root / "artifacts" / script)], root)

    tex = shutil.which("pdflatex")
    if tex is None:
        raise SystemExit("pdflatex is required to rebuild the article.")
    command = [tex, "-interaction=nonstopmode", "-halt-on-error",
               "-output-directory", str(build), "pra_transposition_constancy.tex"]
    for index in range(3):
        run(command, root, build / f"pdflatex_pass_{index + 1}.log")
    log = (build / "pra_transposition_constancy.log").read_text()
    problems = [line for line in log.splitlines()
                if "Overfull" in line or "undefined references" in line]
    if problems:
        raise SystemExit("PDF build requires review:\n" + "\n".join(problems))
    shutil.copy2(build / "pra_transposition_constancy.pdf",
                 root / "pra_transposition_constancy.pdf")
    print("PDF rebuilt; visual review is separate from compilation.")

    if options.lean:
        run([options.lean, "verification/TranspositionKernel.lean"], root,
            build / "lean_replay.log")
        print("Lean certificate replayed successfully.")
    else:
        print("Lean replay not requested; supply --lean to run it.")


if __name__ == "__main__":
    main()
