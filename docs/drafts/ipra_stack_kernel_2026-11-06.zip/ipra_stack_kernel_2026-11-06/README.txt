iPRA WITH A SMALLER PROOF KERNEL
Stack certificates with grouped elimination annotations
Prepared for Vladimir Reshetnikov -- 6 November 2026

RESULT

This package gives a complete proof presentation of the full first-order
intuitionistic primitive recursive arithmetic used in the supplied drafts.
The native calculus is equiconsistent and bi-interpretable with iPRA; the
ordinary bi-interpretations use the entire number domain and have internally
definable identity isomorphisms for both composites. The report includes every
primitive logical and nonlogical rule and the derivations of ordinary logic
and quantifier-free induction.

The primary checker is strictly below the coordinatewise minimum of every
declared source-size measure across all 13 complete current top-level
checkers in the six current ProveIt draft archives.

                             AST  Source  Normalized  Normalized  Raw
                           nodes  tokens      tokens       bytes  bytes
Current 13-program minimum   562     541         543        1688   1777
New primary checker          539     522         526        1653   1698
New strict prefix checker    551     532         536        1698   1740
New strict exact checker     572     546         550        1734   1784

Uniformly extracted cores, with imports and CLI removed:

                             AST  Source  Normalized  Normalized
                           nodes  tokens      tokens       bytes
Current coordinate minimum   483     470         474        1376
New primary core             468     460         464        1345

The primary reduction survives the removal of I/O. The primary is an
open-sequent checker and validates every supplied assumption. The strict
prefix companion beats all whole-file strict-open reference minima. The
strict exact companion is included for stack exhaustion, not as an
all-coordinate improvement claim. Read results/metrics.json for full cohorts.

This is a finite-corpus improvement, not an absolute smallest-possible
axiomatization theorem. The native arithmetic basis is inherited and credited;
the new reduction is in the complete executable proof presentation. The
mathematical metatheory is not yet formalized in Lean or Rocq.

WHAT CHANGED

The checker no longer receives nested child-proof fields. Each recursive
rule check removes one instruction from a shared list. In conceptual order,
the rule instruction comes first, followed by premise instructions in order.
The file stores this order reversed, so Python list.pop() is sufficient.

Elimination instructions group their major formula M and auxiliary t in
one cell [M,t]. The recursion already knows whether there are one or two
premises and reconstructs their goals. No parser for subproof boundaries,
proof search, universal PR evaluator, external theorem database, or imported
support library is hidden outside the measured checker.

SOURCE SNAPSHOT

Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: fa581763b2bb75e8ba055da8e56280c9fd5dd890
Directory: docs/drafts

The comparison includes the actual six current archives and all 13 current
top-level checkers, not the older nine-program totals printed in some reports.
All baseline sources are included unchanged, with exact archive membership,
Git blob identities, SHA-256 hashes, and licenses. No repository write or
publication is part of this deliverable.

QUICK START

Python 3.10 or later and only its standard library are required. Exact
recorded source normalization uses CPython 3.12.14.

    python3 checker.py examples/reflexivity.json
    python3 checker_exact.py examples/forall_exists_successor.json
    python3 reproduce.py

The CLI accepts JSON [goal, stack, H0, H1, ...]. External assumptions are
optional. Acceptance prints ACCEPT and exits 0; rejection prints REJECT
and exits 1. Free numerical variables are parameters. See FORMAT.txt.

The primary checker uses demand validation: a universal witness unused in
both guard and consequent may be arbitrary data. Replacing it by zero gives
a strict proof. All used witnesses and equality motives are validated.

checker_strict.py additionally validates unused active universal witnesses.
checker_exact.py does that and rejects unread stack cells. Prefix checkers
permit an unused initial list segment; canonical certificates need none.
All three programs recognize exactly the same derivable well-formed sequents.
A failed major attempt can be discarded during canonical reconstruction if
the enclosing goal succeeds as a hypothesis. Exhaustion is not a claim that
every inspected instruction lies in the extracted successful derivation.

The in-process check(goal, stack, *context) API consumes the stack. Inputs
must be finite JSON-shaped trees and stack storage must not alias formula or
context storage. Normal JSON parsing gives this separation. Pass fresh copies
when comparing checker variants. Interpreter resource exhaustion rejects;
completeness concerns ideal unbounded finite execution.

EXECUTED EVIDENCE

- All 13 unchanged baseline-source hashes verified during measurement.
- All 19 inherited source theorem certificates translated to canonical stacks
  and accepted by all three variants with exhausted stacks.
- Every accepted checked execution reconstructed independently into a strict
  old proof tree and checked with both the unchanged old checker and a
  separate named-variable proof oracle.
- 40 focused acceptance-boundary cases across all three variants.
- 10 independent named-variable substitution cases across all three variants.
- Five targeted semantic faults detected by the tests, including unrestricted
  formula induction, missing equation induction, and escaping eigenvariables.
- 12 real isolated command-line checks for critical boundary distinctions.

The finite tests overlap and do not replace the mathematical proofs.
The report includes a Further research questions section.

BUILD AND PACKAGE

    python3 comparison/measure.py --require-recorded --require-reduction --require-core-reduction
    python3 validation/validate.py
    python3 build.py
    python3 package.py

reproduce.py runs measurement and validation. The --require-recorded option
additionally requires exact historical normalization metrics; use the recorded
Python version for that check. build.py requires pdfLaTeX and the TeX packages
listed in report.tex; it recompiles the complete article and checks references.
package.py rebuilds file checksums and a deterministic ZIP. Nothing uses the
network during reproduction. Temporary build products are not packaged.

CONTENTS

report.pdf                       Complete article
report.tex, sections/             Complete LaTeX sources
checker.py                        Smallest complete checker
checker_strict.py, checker_exact.py  Stronger annotation/serialization policies
FORMAT.txt                        Complete syntax and operational contract
examples/                         Nineteen ready-to-run theorem certificates
validation/                       Independent reconstruction and focused audits
comparison/                       Frozen baseline sources and measurement tools
results/                          Executed metrics and verification records
reproduce.py, build.py, package.py Reproduction, PDF generation, and packaging
LICENSE_SOURCE.txt                License for inherited source and documentation
MANIFEST.sha256                   SHA-256 hashes of all other delivered files

AUTHORSHIP / ATTRIBUTION

The arithmetic basis, automatic-introduction calculus and collision repair,
formula selector, characteristic-equation construction, and full-domain
bi-interpretations are inherited from the pinned ProveIt drafts. The report
restates their proofs with attribution. The proof-stack layout, grouped
annotations, successful-execution extraction proof, current comparison, and
validation of the changed representation are the contributions of this package.
