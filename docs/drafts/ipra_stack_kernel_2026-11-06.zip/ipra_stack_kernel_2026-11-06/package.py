"""Write a checksum manifest and the reproducible deliverable archive."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent
ARCHIVE = ROOT.parent / 'ipra_stack_kernel_2026-11-06.zip'


def main():
    files = sorted(path for path in ROOT.rglob('*')
                   if path.is_file()
                   and not any(part.startswith('.') or part == '__pycache__'
                               for part in path.relative_to(ROOT).parts)
                   and path.suffix not in ('.pyc', '.aux', '.log', '.out', '.toc')
                   and path.name != 'MANIFEST.sha256')
    manifest = ROOT / 'MANIFEST.sha256'
    manifest.write_text(''.join(hashlib.sha256(path.read_bytes()).hexdigest()
                                + '  ' + path.relative_to(ROOT).as_posix() + '\n'
                                for path in files))
    with zipfile.ZipFile(ARCHIVE, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted([*files, manifest]):
            info = zipfile.ZipInfo('ipra_stack_kernel_2026-11-06/'
                                  + path.relative_to(ROOT).as_posix(),
                                  date_time=(2026, 11, 6, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, path.read_bytes())
    with zipfile.ZipFile(ARCHIVE) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('Archive integrity failure')
    print(ARCHIVE)
    print('files:', len(files) + 1)
    print('bytes:', ARCHIVE.stat().st_size)
    print('sha256:', hashlib.sha256(ARCHIVE.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
