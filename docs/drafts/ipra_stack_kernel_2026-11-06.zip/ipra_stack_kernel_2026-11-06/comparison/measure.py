"""Reproduce the pinned 13-program comparison without executing any checker.

The metric functions are copied unchanged from the pinned arity-calculus
archive, as identified in manifest.json. Everything needed to remeasure the
baselines is local. Candidate metadata lives in candidates.json. Missing
candidates are allowed unless --require-candidates or a reduction gate is used.
"""
from pathlib import Path
import argparse
import ast
import csv
import hashlib
import io
import json
import platform
import sys
import tokenize

HERE = Path(__file__).resolve().parent
FIELDS = ('source_tokens', 'normalized_tokens', 'ast_nodes',
          'normalized_bytes', 'raw_bytes')
CORE_FIELDS = FIELDS[:-1]
IGNORED = {
    tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
    tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER,
}


def is_main_guard(node):
    """Recognize only the conventional top-level command-line guard."""
    return (
        isinstance(node, ast.If)
        and isinstance(node.test, ast.Compare)
        and isinstance(node.test.left, ast.Name)
        and node.test.left.id == '__name__'
        and len(node.test.ops) == len(node.test.comparators) == 1
        and isinstance(node.test.ops[0], ast.Eq)
        and isinstance(node.test.comparators[0], ast.Constant)
        and node.test.comparators[0].value == '__main__'
    )


def source_span(node):
    """Include any decorators when retaining a top-level definition."""
    first = min([node.lineno]
                + [d.lineno for d in getattr(node, 'decorator_list', [])])
    return ((first, 0), (node.end_lineno, node.end_col_offset))


def measure(path):
    """Return exact whole-file metrics and the uniformly extracted core."""
    raw = Path(path).read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    doc_spans = []
    for node in ast.walk(tree):
        if (isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef,
                              ast.AsyncFunctionDef))
                and node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            doc = node.body.pop(0)
            doc_spans.append(((doc.lineno, doc.col_offset),
                              (doc.end_lineno, doc.end_col_offset)))

    def contains(span, token):
        start, end = span
        return start <= token.start and token.end <= end

    def count(text, omitted=(), retained=None):
        return sum(
            token.type not in IGNORED
            and not any(contains(span, token) for span in omitted)
            and (retained is None
                 or any(contains(span, token) for span in retained))
            for token in tokenize.generate_tokens(io.StringIO(text).readline)
        )

    normalized = ast.unparse(tree) + '\n'
    # Keep every other top-level item, not only a selected list of functions.
    # Thus all syntax tables, definitions, helpers, and checks remain counted.
    core_body = [node for node in tree.body
                 if not isinstance(node, (ast.Import, ast.ImportFrom))
                 and not is_main_guard(node)]
    core = ast.Module(body=core_body, type_ignores=[])
    core_normalized = ast.unparse(core) + '\n'
    retained = [source_span(node) for node in core_body]
    return {
        'sha256': hashlib.sha256(raw).hexdigest(),
        'source_tokens': count(source, doc_spans),
        'normalized_tokens': count(normalized),
        'ast_nodes': sum(1 for _ in ast.walk(tree)),
        'normalized_bytes': len(normalized.encode('utf-8')),
        'raw_bytes': len(raw),
        'core': {
            'source_tokens': count(source, doc_spans, retained),
            'normalized_tokens': count(core_normalized),
            'ast_nodes': sum(1 for _ in ast.walk(core)),
            'normalized_bytes': len(core_normalized.encode('utf-8')),
        },
    }


def envelope(rows, fields=FIELDS):
    if not rows:
        raise ValueError('Cannot form the envelope of an empty comparison class')
    return {key: min(row[key] for row in rows) for key in fields}


def both_envelopes(rows):
    return {
        'program_count': len(rows),
        'whole': envelope(rows),
        'core': envelope([row['core'] for row in rows], CORE_FIELDS),
    }


def below(row, target):
    return {key: row[key] < value for key, value in target.items()}


def compare(row, targets):
    whole = below(row, targets['whole'])
    core = below(row['core'], targets['core'])
    return {
        'baseline_program_count': targets['program_count'],
        'whole': whole,
        'core': core,
        'whole_primary_strictly_below': all(whole[key] for key in CORE_FIELDS),
        'whole_including_raw_strictly_below': all(whole.values()),
        'core_strictly_below': all(core.values()),
    }


def emit_csv(result, destination):
    columns = ['kind', 'id', 'label', 'scope', 'interface',
               'witness_validation', 'certificate_boundary', 'source', 'sha256', *FIELDS]
    with (destination / 'metrics.csv').open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction='ignore')
        writer.writeheader()
        for kind, rows in [('baseline', result['baselines']),
                           ('candidate', result['candidates'].values())]:
            for row in rows:
                writer.writerow(dict(row, kind=kind, scope='whole'))
                metadata = {key: row[key] for key in columns
                            if key in row and key not in FIELDS}
                writer.writerow(dict(metadata, **row['core'], kind=kind, scope='core'))


def emit_tex(result, destination):
    """Emit compact numeric macros and the complete measured-program table."""
    suffixes = {
        'ast_nodes': 'AST', 'source_tokens': 'SourceTokens',
        'normalized_tokens': 'NormTokens', 'normalized_bytes': 'Bytes',
        'raw_bytes': 'RawBytes',
    }
    lines = ['% Generated by comparison/measure.py from the actual source files.',
             '% Values are integers unless a macro name ends with Percent.']

    def number(name, value):
        lines.append('\\newcommand{\\' + name + '}{' + str(value) + '}')

    def group(prefix, row):
        for key, suffix in suffixes.items():
            if key in row:
                number(prefix + suffix, row[key])

    number('BaselineArchiveCount', result['baseline_archive_count'])
    number('BaselineProgramCount', result['baseline_program_count'])
    group('Baseline', result['envelope'])
    group('BaselineCore', result['core_envelope'])
    for pair, prefix in [('open-sequent:strict', 'StrictOpenBaseline'),
                         ('open-sequent:demand', 'DemandOpenBaseline')]:
        group(prefix, result['matched_envelopes'][pair]['whole'])
        group(prefix + 'Core', result['matched_envelopes'][pair]['core'])
    prefixes = {'demand_prefix': 'Demand', 'strict_prefix': 'Strict',
                'strict_exact': 'Exact'}
    for identity, prefix in prefixes.items():
        if identity not in result['candidates']:
            continue
        row = result['candidates'][identity]
        group(prefix, row)
        group(prefix + 'Core', row['core'])
    if 'demand_prefix' in result['candidates']:
        row = result['candidates']['demand_prefix']
        for key in CORE_FIELDS:
            target = result['envelope'][key]
            number('Demand' + suffixes[key] + 'SavingPercent',
                   f'{100 * (target - row[key]) / target:.2f}\\%')
    (destination / 'numbers.tex').write_text('\n'.join(lines) + '\n', encoding='utf-8')

    short_names = {
        'ipra_arity_calculus_2026-11-06': 'Arity',
        'ipra_automatic_goal_kernel_2026-11-06': 'Automatic goal',
        'ipra_goal_only_2026-11-06': 'Goal-only',
        'ipra_implicit_certificates_2026-11-06': 'Implicit certificates',
        'ipra_shared_introduction_2026-11-06': 'Shared introduction',
        'ipra_structural_kernel_2026-11-06': 'Structural kernel',
    }
    fields = ('ast_nodes', 'source_tokens', 'normalized_tokens',
              'normalized_bytes', 'raw_bytes')
    table = [
        '% Generated by comparison/measure.py; requires booktabs.',
        '% Designed for a 160 mm text block; scales to the current linewidth.',
        '\\begin{table}[htbp]', '\\centering', '\\small',
        '\\setlength{\\tabcolsep}{2.5pt}',
        '\\begin{tabular*}{\\linewidth}{@{}l@{\\extracolsep{\\fill}}rrrrr@{}}',
        '\\toprule',
        'Program and public boundary & AST & Source & Norm. & Norm. & Raw\\\\',
        '& nodes & tokens & tokens & bytes & bytes\\\\',
        '\\midrule',
    ]

    def row(label, values, bold=False):
        cells = [label, *(str(values[key]) for key in fields)]
        if bold:
            cells = ['\\textbf{' + item + '}' for item in cells]
        table.append(' & '.join(cells) + '\\\\')

    previous = None
    for item in result['baselines']:
        if previous is not None and item['draft'] != previous:
            table.append('\\addlinespace[2pt]')
        interface = 'open' if item['interface'] == 'open-sequent' else 'theorem'
        label = short_names[item['draft']] + ': ' + item['witness_validation'] + ' ' + interface
        row(label, item)
        previous = item['draft']
    table.append('\\midrule')
    row('Current coordinatewise minimum', result['envelope'], bold=True)
    table.append('\\midrule')
    labels = {'demand_prefix': 'New demand prefix (primary)',
              'strict_prefix': 'New strict prefix',
              'strict_exact': 'New strict, with exhaustion'}
    for identity in prefixes:
        if identity in result['candidates']:
            row(labels[identity], result['candidates'][identity],
                bold=identity == 'demand_prefix')
    table += [
        '\\bottomrule', '\\end{tabular*}',
        '\\caption{Complete standalone acceptance programs at the pinned snapshot.',
        'All thirteen current programs and every supplied new variant are counted.',
        'The first four numeric columns use the declared primary convention;',
        'raw bytes also include comments and docstrings and are supplementary.',
        'All new variants accept open sequents. Prefix acceptance and exhaustion',
        'are separate certificate boundaries. Exact source paths and hashes are',
        'recorded in \\texttt{comparison/manifest.json}.}',
        '\\label{tab:complete-comparison}', '\\end{table}',
    ]
    (destination / 'comparison_table.tex').write_text('\n'.join(table) + '\n', encoding='utf-8')


def run(candidate_root=None, output_dir=None, *, baseline_only=False,
        candidate_config=None):
    """Measure sources, verify frozen identities, and write JSON/CSV results.

    This routine reports comparison booleans without requiring that any
    reduction claim hold. The command-line --require-* flags add explicit gates.
    No candidate or baseline checker is imported or executed.
    """
    root = Path(candidate_root or HERE.parent).resolve()
    destination = Path(output_dir).resolve() if output_dir else root / 'results'
    manifest = json.loads((HERE / 'manifest.json').read_text(encoding='utf-8'))
    baselines = []
    for entry in manifest['programs']:
        measured = measure(HERE / entry['source'])
        if measured['sha256'] != entry['source_sha256']:
            raise ValueError('Modified baseline source: ' + entry['source'])
        recorded = entry['reference_metrics']
        matches = {key: measured[key] == value for key, value in recorded.items()}
        row = {key: value for key, value in entry.items() if key != 'reference_metrics'}
        row.update(measured)
        row.update(id=entry['draft'] + '/' + entry['file'],
                   source='comparison/' + entry['source'],
                   reference_metric_match=all(matches.values()))
        baselines.append(row)

    license_checks = []
    for archive in manifest['archives']:
        item = archive['license']
        digest = hashlib.sha256((HERE / item['frozen_source']).read_bytes()).hexdigest()
        if digest != item['sha256']:
            raise ValueError('Modified source license: ' + item['frozen_source'])
        license_checks.append({'source': item['frozen_source'], 'sha256': digest})

    all_targets = both_envelopes(baselines)
    interfaces = {name: both_envelopes([row for row in baselines
                                      if row['interface'] == name])
                  for name in sorted({row['interface'] for row in baselines})}
    matched = {
        interface + ':' + policy:
        both_envelopes([row for row in baselines
                        if row['interface'] == interface
                        and row['witness_validation'] == policy])
        for interface, policy in sorted({(row['interface'], row['witness_validation'])
                                         for row in baselines})
    }
    config_path = Path(candidate_config).resolve() if candidate_config else HERE / 'candidates.json'
    config = json.loads(config_path.read_text(encoding='utf-8'))
    candidates = {}
    missing = []
    if not baseline_only:
        for entry in config['candidates']:
            path = root / entry['file']
            if not path.is_file():
                missing.append(dict(entry))
                continue
            identity = entry['id']
            if identity in candidates:
                raise ValueError('Duplicate candidate id: ' + identity)
            pair = entry['interface'] + ':' + entry['witness_validation']
            if pair not in matched:
                raise ValueError('No matched baseline class for candidate: ' + identity)
            candidates[identity] = dict(entry, source=entry['file'], **measure(path))

    comparisons = {}
    for name, row in candidates.items():
        pair = row['interface'] + ':' + row['witness_validation']
        exact_boundary = [reference for reference in baselines
                          if reference['interface'] == row['interface']
                          and reference['witness_validation'] == row['witness_validation']
                          and reference['certificate_boundary'] == row['certificate_boundary']]
        comparisons[name] = {
            'all_complete_programs': compare(row, all_targets),
            'same_interface': compare(row, interfaces[row['interface']]),
            'same_interface_and_witness_policy': compare(row, matched[pair]),
            'same_certificate_boundary': (
                compare(row, both_envelopes(exact_boundary)) if exact_boundary else None),
            'certificate_boundary_note': (
                'No current program has the same certificate boundary.' if not exact_boundary
                else 'Matching also includes the declared certificate boundary.'),
        }

    result = {
        'schema_version': 1,
        'status': 'baselines_only' if baseline_only or not candidates else 'measured',
        'repository': manifest['repository'],
        'commit': manifest['commit'],
        'python': sys.version,
        'python_version': platform.python_version(),
        'reference_python_version': manifest['reference_python_version'],
        'recorded_metric_match': all(row['reference_metric_match'] for row in baselines),
        'baseline_archive_count': len(manifest['archives']),
        'baseline_program_count': len(baselines),
        'boundaries': {
            'whole': 'Entire standalone acceptance program, including imports, syntax tables, binding, substitution, arithmetic and logical rules, JSON/CLI, and rejection. Comments and leading docstrings are omitted from primary measures. Raw bytes include all source text.',
            'core': 'Supplemental only: remove top-level imports and the conventional __name__ == __main__ block uniformly; retain every other top-level item. The same comment/docstring convention applies. No raw-byte metric is assigned to an extracted core.',
            'runtime': 'Python and standard-library implementations are shared and excluded identically. Source imports are counted in whole-program metrics. These measures are not a language-independent minimum.',
            'policy': 'strict validates active inference annotations, including vacuous universal witnesses; demand may erase unused witnesses without changing derivable sequents. Interface and witness labels are inspected or declared metadata, not properties proved by measurement.',
            'certificate': manifest['certificate_boundary_note'],
            'corpus': manifest['selection'],
        },
        'baselines': baselines,
        'license_checks': license_checks,
        'envelope': all_targets['whole'],
        'core_envelope': all_targets['core'],
        'primary_envelope': both_envelopes([row for row in baselines if row['role'] == 'primary']),
        'interface_envelopes': interfaces,
        'matched_envelopes': matched,
        'candidates': candidates,
        'missing_candidates': missing,
        'comparisons': comparisons,
        'strictly_below': {name: item['all_complete_programs']['whole']
                           for name, item in comparisons.items()},
        'core_strictly_below': {name: item['all_complete_programs']['core']
                                for name, item in comparisons.items()},
        'matched_strictly_below': {
            name: item['same_interface_and_witness_policy']['whole']
            for name, item in comparisons.items()
        },
    }
    destination.mkdir(parents=True, exist_ok=True)
    (destination / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    emit_csv(result, destination)
    emit_tex(result, destination)
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate-root', type=Path, default=HERE.parent,
                        help='directory containing candidate files named in candidates.json')
    parser.add_argument('--candidate-config', type=Path,
                        help='comparison metadata JSON; defaults to comparison/candidates.json')
    parser.add_argument('--output-dir', type=Path,
                        help='defaults to candidate-root/results')
    parser.add_argument('--baseline-only', action='store_true',
                        help='remeasure only the 13 frozen programs')
    parser.add_argument('--require-candidates', action='store_true',
                        help='fail if any required candidate is missing; optional variants may be absent')
    parser.add_argument('--require-recorded', action='store_true',
                        help='require the reference Python metric values to reproduce exactly')
    parser.add_argument('--require-reduction', action='store_true',
                        help='require candidates marked mixed_envelope_claim to beat every whole-program coordinate, including raw bytes, of the mixed envelope')
    parser.add_argument('--require-core-reduction', action='store_true',
                        help='require the cores of candidates marked mixed_envelope_claim to beat every core-envelope coordinate')
    parser.add_argument('--require-matched-reduction', action='store_true',
                        help='require every present variant to beat every whole-program coordinate of its interface-and-witness-policy cohort')
    args = parser.parse_args(argv)
    gated = (args.require_reduction or args.require_core_reduction
             or args.require_matched_reduction or args.require_candidates)
    if args.baseline_only and gated:
        parser.error('--baseline-only cannot be combined with candidate gates')
    result = run(args.candidate_root, args.output_dir,
                 baseline_only=args.baseline_only,
                 candidate_config=args.candidate_config)
    failed = []
    if args.require_recorded and not result['recorded_metric_match']:
        failed.append('Reference metrics differ on this Python version')
    missing_required = [row for row in result['missing_candidates']
                        if row.get('required', True)]
    if gated and (missing_required or not result['candidates']):
        failed.append('One or more required candidates are missing')
    mixed_claims = {name for name, row in result['candidates'].items()
                    if row.get('mixed_envelope_claim', True)}
    if (args.require_reduction or args.require_core_reduction) and not mixed_claims:
        failed.append('No present candidate is designated for a mixed-envelope claim')
    for name, groups in result['comparisons'].items():
        all_programs = groups['all_complete_programs']
        if (args.require_reduction and name in mixed_claims
                and not all_programs['whole_including_raw_strictly_below']):
            failed.append(name + ': whole-program envelope not beaten in every coordinate')
        if (args.require_core_reduction and name in mixed_claims
                and not all_programs['core_strictly_below']):
            failed.append(name + ': core envelope not beaten in every coordinate')
        if (args.require_matched_reduction
                and not groups['same_interface_and_witness_policy']['whole_including_raw_strictly_below']):
            failed.append(name + ': matched interface/policy envelope not beaten in every coordinate')
    summary = {
        'status': 'failed_gate' if failed else result['status'],
        'baseline_program_count': result['baseline_program_count'],
        'recorded_metric_match': result['recorded_metric_match'],
        'envelope': result['envelope'],
        'core_envelope': result['core_envelope'],
        'candidates': {name: {key: row[key] for key in (*FIELDS, 'core')}
                       for name, row in result['candidates'].items()},
        'missing_candidates': [row['file'] for row in result['missing_candidates']],
        'failed_gates': failed,
    }
    print(json.dumps(summary, indent=2))
    if failed:
        raise SystemExit(1)
    return result


if __name__ == '__main__':
    main()


