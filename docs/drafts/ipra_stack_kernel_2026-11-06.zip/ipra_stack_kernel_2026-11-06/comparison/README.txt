PINNED CURRENT-DRAFT COMPARISON
==============================

Repository: VladimirReshetnikov/ProveIt
Commit: fa581763b2bb75e8ba055da8e56280c9fd5dd890
Directory: docs/drafts

This folder is a self-contained, offline comparison corpus. It contains the
13 unchanged top-level complete acceptance programs from all six ZIP files
in the directory at the pinned commit. Several reports inside those ZIPs
compare against an older nine-program corpus. Their earlier envelope is not
used here.

CONTENTS

  manifest.json          Exact archive and program provenance; hashes;
                         inspected interface/witness classifications;
                         reference metrics under CPython 3.12.14.
  sources/<draft>/       Thirteen byte-for-byte original checker sources.
  licenses/<draft>.txt   Each source archive's original license text.
  LICENSE_SOURCE.txt    The common supplied MIT No Attribution license.
  candidates.json       Metadata for ../checker.py, ../checker_strict.py,
                        and the optional ../checker_exact.py.
  measure.py            Standalone source-measurement and comparison driver.

The original archive ZIP files are not duplicated in this folder. Their
immutable URLs, byte sizes, SHA-256 digests, and Git blob SHA-1 identities
are recorded in manifest.json. The frozen Python sources are sufficient for
every offline size measurement. Each source was compared byte for byte with
its archive member, and every downloaded ZIP's Git blob hash was checked
against the GitHub directory response before freezing this corpus.

Every path in manifest.json's source and license fields is relative to this
comparison folder. archive_member is a path inside the named original ZIP.
Paths in results/metrics.json are relative to the delivered package root.

RUN FROM THE DELIVERED PACKAGE ROOT

  python3 comparison/measure.py

This writes results/metrics.json, results/metrics.csv, results/numbers.tex,
and results/comparison_table.tex. The TeX files are generated from the same
measurements and contain numeric macros plus the full comparison table.
The driver parses but never imports or executes any checker. Missing
candidates are recorded and skipped, so it also works before new checker
files have been supplied.

To verify only the frozen corpus and the original reference measurements:

  python3 comparison/measure.py --baseline-only --require-recorded

To require all mandatory candidates to exist and require the primary demand
candidate to beat every whole-program coordinate of the current mixed
envelope, including the supplementary raw-byte metric:

  python3 comparison/measure.py --require-reduction

To additionally require the primary candidate's uniformly extracted core to
beat every core coordinate, use:

  python3 comparison/measure.py --require-reduction --require-core-reduction

The primary mixed-envelope claim is marked explicitly by mixed_envelope_claim
in candidates.json. The stricter companion variants need not beat the smaller
demand checkers in the mixed class. To require every present variant to beat
its interface-and-witness-policy class, add --require-matched-reduction.

The --require-* flags are explicit reproducibility gates, not soundness
tests. Without them the driver reports true/false comparison results without
asserting that a reduction holds. --require-candidates only checks the
presence of mandatory candidates; the optional exact variant may be absent.
--candidate-root and --output-dir support another local directory; see --help.

CANDIDATE METADATA

The default candidates all have an open-sequent mathematical interface:

  checker.py          demand witness validation, stream-prefix acceptance;
                      this is the primary mixed-envelope candidate.
  checker_strict.py   strict witness validation, stream-prefix acceptance.
  checker_exact.py    strict witness validation plus stream exhaustion;
                      this companion is optional.

This is comparison metadata rather than an inference made from filenames.
Keep candidates.json synchronized with the final programs if an interface,
witness policy, or exhaustion requirement changes. An alternative
configuration can be supplied with --candidate-config.

The driver compares each present candidate against three classes:

  1. All 13 complete current programs, irrespective of interface or policy.
  2. Every current program with the same external interface.
  3. Programs with both the same interface and the same witness policy.

Each class has separate whole-program and core envelopes. Primary checkers
and companion variants are also distinguished in the source metadata. Every
coordinate of an envelope is minimized independently; an envelope need not
be the metric vector of any single program.

Certificate boundaries are reported separately. The baselines receive rooted
proof trees and may ignore annotations on a successful hypothesis fallback.
The stream candidates either accept after consuming a sufficient prefix in
their reading order or additionally require exhaustion. No baseline has the
same declared stream boundary, so same_certificate_boundary is null rather
than an invented matched cohort. Matching mathematical interface and witness
policy does not claim equality of proof encodings or raw accepted JSON sets.

METRIC CONVENTION

The is_main_guard, source_span, and measure functions are copied unchanged
from the pinned arity-calculus archive's comparison/measure.py. Its archive
member and SHA-256 digest are recorded in manifest.json. The orchestration,
corpus manifest, candidate configuration, and comparison reporting are new.

Whole-program scope includes the entire standalone acceptance source:
imports, syntax tables, formation, binding and substitution, all logical and
arithmetic rules, JSON input, command-line verdicts, and rejection handling.
All inherited checkers import only standard-library json and sys. No
project-specific support program or theorem library is omitted from their
acceptance boundary.

  source_tokens       Significant Python tokens in the actual source after
                      excluding comments and leading docstrings.
  normalized_tokens   Significant tokens after the same docstring removal
                      and ast.unparse normalization.
  ast_nodes           Number of nodes visited by ast.walk after docstring
                      removal, including the module node and operator nodes.
  normalized_bytes    UTF-8 bytes of ast.unparse(tree) plus one final newline.
  raw_bytes           All original bytes, including comments and docstrings;
                      this is supplementary rather than a primary measure.

Significant tokens exclude encoding, comments, line endings, indentation,
dedentation, and end-marker tokens. Tokens within removed docstrings are
excluded by their exact source spans.

The supplemental core measurement applies the SAME source transformation
to every baseline and candidate: remove only top-level import statements and
the conventional `if __name__ == '__main__':` block; retain every other
top-level item, including all syntax tables and helper functions. Measure
that result by the same convention. No raw-byte figure is assigned to this
extracted representation. If an implementation puts acceptance-specific
work in its command-line block, that work still counts in the primary
whole-program comparison; the core result must not be read as a separate
claim about its complete trust boundary.

The common Python runtime and standard-library implementations are excluded
identically, while the source import statements remain counted in the whole
programs. These metrics compare implementations within one declared runtime;
they do not prove absolute or language-independent minimality.

CPython 3.12.14 gives the recorded numbers. Python 3.10+ can run the driver,
but ast.unparse conventions and AST layouts can vary by version. Every run
remeasures the baselines and candidates on the same current interpreter.
recorded_metric_match reports whether the reference numbers reproduced;
--require-recorded makes a mismatch fatal. Frozen-source hash mismatches are
always fatal on every Python version.

REFERENCE ENVELOPES

All 13 complete programs, coordinatewise minima:

  Source tokens       541   Goal-only, demand open
  Normalized tokens   543   Goal-only, demand open
  AST nodes           562   Goal-only, demand open
  Normalized bytes   1688   Shared introduction, demand theorem
  Raw bytes          1777   Automatic goal kernel, demand theorem

Uniformly extracted cores, coordinatewise minima:

  Source tokens       470   Implicit certificates, strict open
  Normalized tokens   474   Implicit certificates, strict open
  AST nodes           483   Implicit certificates, strict open
  Normalized bytes   1376   Shared introduction, demand theorem

In particular, the compact goal_only/checker_demand.py is OPEN-SEQUENT
capable: its public entry point accepts and validates external assumptions.
It must not be classified as theorem-only. The source classification was
checked against each actual program rather than copied from older tables.

SOURCE LICENSE AND ATTRIBUTION

The supplied source license is headed "MIT No Attribution License" and
"Copyright 2026 ProveIt Contributors". Each archive's supplied license is
preserved byte for byte in licenses/. Five are byte-identical; the goal-only
copy differs only by a final blank line. LICENSE_SOURCE.txt is the common
text. The metric functions retain their explicit provenance above.

The frozen programs and their mathematical construction are inherited work.
The new candidate's contribution must be identified separately in the main
report. No current or historical source has been silently relabeled as a
new checker. The archive and program hashes make that distinction auditable.
