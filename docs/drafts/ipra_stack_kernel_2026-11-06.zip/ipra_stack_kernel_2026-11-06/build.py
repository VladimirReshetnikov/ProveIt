"""Build the complete article with pdfLaTeX; no network is required."""
from pathlib import Path
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    build = ROOT / '.build'
    build.mkdir(exist_ok=True)
    format_flag = []
    probe = subprocess.run(['kpsewhich', 'pdflatex.fmt'], cwd=ROOT,
                           text=True, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE)
    if probe.returncode or not probe.stdout.strip():
        # Some minimal TeX installations contain the packages but no formats.
        # Build a local format from their installed sources; do not download.
        setup = subprocess.run([
            'pdftex', '-ini', '-etex', '-jobname=pdflatex', '-progname=pdflatex',
            '-interaction=nonstopmode', '-halt-on-error',
            '-output-directory=' + str(build), 'pdflatex.ini'],
            cwd=ROOT, text=True, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT)
        (build / 'format_setup.txt').write_text(setup.stdout)
        if setup.returncode:
            raise RuntimeError(setup.stdout[-6000:])
        format_flag = ['-fmt=' + str(build / 'pdflatex.fmt')]
    command = ['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
               '-file-line-error', *format_flag, '-output-directory=' + str(build),
               'report.tex']
    for number in range(1, 4):
        result = subprocess.run(command, cwd=ROOT, text=True,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT)
        (build / ('pass' + str(number) + '.txt')).write_text(result.stdout)
        if result.returncode:
            raise RuntimeError(result.stdout[-6000:])
    log = (build / 'report.log').read_text()
    forbidden = ('There were undefined references', 'LaTeX Warning: Reference',
                 'LaTeX Warning: Citation', 'Rerun to get cross-references right')
    if any(message in log for message in forbidden):
        raise RuntimeError('Unresolved reference; inspect .build/report.log')
    shutil.copyfile(build / 'report.pdf', ROOT / 'report.pdf')
    warnings = [line for line in log.splitlines()
                if 'Overfull' in line or 'Underfull' in line]
    record = {'status': 'built', 'passes': 3,
              'layout_warnings': warnings,
              'pdf_bytes': (ROOT / 'report.pdf').stat().st_size}
    (ROOT / 'results' / 'build.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
