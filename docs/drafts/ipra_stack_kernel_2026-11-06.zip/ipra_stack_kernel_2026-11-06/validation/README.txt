INDEPENDENT VALIDATION
======================

From the package directory:

    python3 validation/validate.py

The script uses only Python's standard library. It does not use the network.
It rebuilds examples/*.json from the pinned old tree certificates and writes
results/validation.json, results/validation_summary.tex, and validation/cases.json.
The 19 source certificates include full arithmetic identities, numerical
coverage, successor injectivity, quantified existence, and automatic-guard
collision cases.

TRUST SEPARATION

None of these files is imported by the three production checkers.

reconstruct.py independently interprets the proof stack using named variables,
fresh binder identities, ordinary capture-avoiding substitution, and
alpha-equivalence. It never imports the production checker or its substitution
function. It reconstructs every successful result into the old tree syntax.
Ignored universal witnesses are replaced by zero, irrelevant existential
annotations by null, and successful hypothesis fallbacks by canonical null
leaves. Unconsumed initial cells and failed-major detours disappear.

Each reconstructed tree is checked by both:

1. The unchanged strict arity-calculus checker_open.py under comparison/sources/.
2. The unchanged named-variable proof oracle under validation/frozen/.

The canonical new stack obtained from that reconstruction must also pass the
strict exact checker, leaving no cells. Every accepting result in the source
corpus and the boundary suite undergoes these checks.

compile_old_document, also in reconstruct.py, independently converts a strictly
verified old tree certificate to the new reversed-preorder stack. It uses the
frozen named-variable oracle, not the new checker's term or proof operations.
The source corpus uses zero = -1 and variables >= 0; only integer syntax codes
are shifted by one at the new-format boundary. Booleans are never integers.

FROZEN SUPPORT

frozen/proof_oracle.py and frozen/substitution_oracle.py are unchanged copies
from the pinned ProveIt draft archives, with source paths and SHA-256 digests in
PROVENANCE.json. The inherited license is in frozen/LICENSE_SOURCE.txt. The
separate substitution oracle resolves de Bruijn indices to named binders,
performs named replacement, then reconstructs indices. The candidate is called
only to obtain the actual value that is compared against this independent
expected result.

BOUNDARY RISKS COVERED

The focused cases distinguish:

- Zero and successor computation, including a variable-counter rejection.
- Nested recursor capture avoidance and transport under a quantifier.
- Retained parameters versus fresh Pi and existential eigenvariables.
- Equation induction versus the compound-formula cases branch.
- Demand versus strict validation of unused universal witnesses.
- Failed-major fallback, persistent stack consumption, and malformed-major
  rejection without fallback.
- Malformed but unused external assumptions, booleans, wrong sorts, wrong
  arities, and negative term codes.
- Execution order, every proper truncation of a small canonical proof, unused
  initial cells, and a consumed null token versus actual stack exhaustion.

Five deliberately faulty checker variants are run against individually chosen
counterexamples. No mutation is included unless its intended fault is detected.
Twelve actual CLI calls verify output text and exit codes, including exact
exhaustion and the demand/strict boundary.

These tests are finite regression evidence. They are not a formal proof of the
checker implementation, proof extraction, or the mathematical bi-interpretation.
Those claims are established by the explicit arguments in report.pdf; the report
does not claim Lean or Rocq verification for this iteration.
