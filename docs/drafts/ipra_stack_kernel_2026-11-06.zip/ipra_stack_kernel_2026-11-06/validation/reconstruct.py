"""Untrusted, independent reconstruction of stack certificates.

The production checker is never imported here.  Arithmetic expressions are
parsed into fresh named binders by frozen/proof_oracle.py, an unchanged oracle
from the pinned arity-calculus draft.  Every successful run produces a canonical
old tree certificate, which can be checked by the unchanged strict old checker.

External stack syntax uses zero = 0 and variables = 1, 2, ... .  The frozen
oracle and reconstructed trees use zero = -1 and variables = 0, 1, ... .
Only this elementary change of integer codes is performed at the boundary.
"""

from dataclasses import dataclass

from frozen import proof_oracle as N


def recode(value, delta):
    """Change numerical syntax codes without treating booleans as integers."""
    if type(value) is int:
        return value + delta
    if type(value) is list:
        return [recode(item, delta) for item in value]
    return value


@dataclass
class Derivation:
    tree: object
    preorder: list


def opened_introduction(oracle, goal):
    """Return the fresh parameter, local assumption and introduction target."""
    eigen = oracle.fresh()
    current = N.Var(eigen)
    zero_body = N.substitute(goal.body, {goal.variable: N.ZERO})
    if N.same(goal.guard, zero_body):
        local = (N.substitute(goal.body, {goal.variable: current})
                 if isinstance(goal.body, N.Eq) else zero_body)
        target = N.substitute(goal.body, {goal.variable: N.Succ(current)})
    else:
        local = N.substitute(goal.guard, {goal.variable: current})
        target = N.substitute(goal.body, {goal.variable: current})
    return eigen, local, target


def computation(goal):
    """Independently compute a single recursor equation in named syntax."""
    recursor = goal.left
    if isinstance(recursor.counter, N.Zero):
        reduct = recursor.initial
    elif isinstance(recursor.counter, N.Succ):
        counter = recursor.counter.value
        previous = N.Rec(counter, recursor.initial, recursor.previous,
                         recursor.index, recursor.update)
        reduct = N.substitute(recursor.update,
                             {recursor.previous: previous,
                              recursor.index: counter})
    else:
        raise N.Invalid("recursor counter is neither zero nor successor")
    return N.same(goal.right, reduct)


def elimination(oracle, major, annotation, environment):
    """Return premise, conclusion, and a strict canonical annotation."""
    if isinstance(major, N.Eq):
        hole = oracle.fresh()
        motive = oracle.formula(annotation, (hole,) + environment)
        return (N.substitute(motive, {hole: major.left}),
                N.substitute(motive, {hole: major.right}), annotation)
    used = (major.variable in N.free_names(major.guard)
            or major.variable in N.free_names(major.body))
    if oracle.strict_witness or used:
        witness = oracle.term(annotation, environment)
    else:
        # Demand validation may ignore any raw annotation in this case.
        # Replacing it by zero gives a strictly valid old tree certificate.
        witness, annotation = N.ZERO, -1
    return (N.substitute(major.guard, {major.variable: witness}),
            N.substitute(major.body, {major.variable: witness}), annotation)


class StreamOracle(N.Oracle):
    def __init__(self, stack, strict_witness=True):
        super().__init__(strict_witness)
        if type(stack) is not list:
            raise N.Invalid("proof stack must be an array")
        self.stack = [recode(item, -1) for item in stack]
        self.total = len(self.stack)
        self.failed_major_fallbacks = 0

    def take(self):
        if not self.stack:
            raise N.Invalid("truncated proof stack")
        return self.stack.pop()

    def derive(self, goal, assumptions, environment=()):
        token = self.take()
        array = type(token) is list

        if isinstance(goal, N.Pi) and array and len(token) == 0:
            eigen, local, target = opened_introduction(self, goal)
            child = self.derive(target, assumptions + [local],
                                (eigen,) + environment)
            if child is None:
                return None
            return Derivation([child.tree], [[], *child.preorder])

        if isinstance(goal, N.Exists) and array and len(token) == 1:
            witness = self.term(token[0], environment)
            eigen = self.fresh()
            local = N.Eq(N.Var(eigen), witness)
            target = N.substitute(goal.body, {goal.variable: N.Var(eigen)})
            child = self.derive(target, assumptions + [local],
                                (eigen,) + environment)
            if child is None:
                return None
            return Derivation([token[0], child.tree],
                              [[token[0]], *child.preorder])

        # A valid-shaped elimination cell commits to parsing its major.
        # Failed major derivations may fall through to Hyp without rewinding;
        # malformed major syntax propagates an exception instead.
        if (array and len(token) == 2 and type(token[0]) is list
                and len(token[0]) >= 1):
            raw_major, annotation = token
            major = self.formula(raw_major, environment)
            first = self.derive(major, assumptions, environment)
            if first is not None:
                if isinstance(major, N.Exists):
                    eigen = self.fresh()
                    local = N.substitute(major.body,
                                         {major.variable: N.Var(eigen)})
                    second = self.derive(goal, assumptions + [local],
                                         (eigen,) + environment)
                    if second is None:
                        return None
                    return Derivation(
                        [raw_major, first.tree, second.tree],
                        [[raw_major, None], *first.preorder, *second.preorder])
                premise, conclusion, annotation = elimination(
                    self, major, annotation, environment)
                if not N.same(goal, conclusion):
                    return None
                second = self.derive(premise, assumptions, environment)
                if second is None:
                    return None
                return Derivation(
                    [raw_major, first.tree, annotation, second.tree],
                    [[raw_major, annotation], *first.preorder, *second.preorder])
            self.failed_major_fallbacks += 1

        if (isinstance(goal, N.Eq) and isinstance(goal.left, N.Rec)
                and array and len(token) == 0):
            return Derivation([], [[]]) if computation(goal) else None

        if any(N.same(goal, hypothesis) for hypothesis in assumptions):
            return Derivation(None, [None])
        return None


def reconstruct_document(document, strict_witness=True, exact=False):
    """Return a reconstruction record; rejects are ordinary records, not raises."""
    try:
        if type(document) is not list or len(document) < 2:
            raise N.Invalid("expected [goal, stack, *context]")
        raw_goal, stack, *raw_context = document
        oracle = StreamOracle(stack, strict_witness)
        old_goal, old_context = recode(raw_goal, -1), recode(raw_context, -1)
        goal = oracle.formula(old_goal)
        context = [oracle.formula(hypothesis) for hypothesis in old_context]
        result = oracle.derive(goal, context)
        accepted = result is not None and (not exact or not oracle.stack)
        record = {
            "accepted": accepted,
            "consumed": oracle.total - len(oracle.stack),
            "remaining": len(oracle.stack),
            "failed_major_fallbacks": oracle.failed_major_fallbacks,
        }
        if accepted:
            record["old_document"] = [old_goal, result.tree, *old_context]
            record["canonical_document"] = [
                raw_goal, list(reversed(recode(result.preorder, 1))), *raw_context]
        return record
    except Exception as exc:
        return {"accepted": False, "error": type(exc).__name__ + ": " + str(exc)}


class TreeCompiler(N.Oracle):
    """Flatten canonicalized old tree derivations without production code."""

    def compile(self, goal, proof, assumptions, environment=()):
        array = type(proof) is list
        if isinstance(goal, N.Pi) and array and len(proof) == 1:
            eigen, local, target = opened_introduction(self, goal)
            child = self.compile(target, proof[0], assumptions + [local],
                                 (eigen,) + environment)
            return None if child is None else [[], *child]
        if isinstance(goal, N.Exists) and array and len(proof) == 2:
            witness = self.term(proof[0], environment)
            eigen = self.fresh()
            local = N.Eq(N.Var(eigen), witness)
            target = N.substitute(goal.body, {goal.variable: N.Var(eigen)})
            child = self.compile(target, proof[1], assumptions + [local],
                                 (eigen,) + environment)
            return None if child is None else [[proof[0]], *child]
        if (array and len(proof) >= 2 and type(proof[0]) is list
                and len(proof[0]) >= 1):
            raw_major = proof[0]
            major = self.formula(raw_major, environment)
            first = self.compile(major, proof[1], assumptions, environment)
            if first is not None:
                if isinstance(major, N.Exists):
                    if len(proof) != 3:
                        raise N.Invalid("old existential elimination arity")
                    eigen = self.fresh()
                    local = N.substitute(major.body,
                                         {major.variable: N.Var(eigen)})
                    second = self.compile(goal, proof[2], assumptions + [local],
                                          (eigen,) + environment)
                    return (None if second is None else
                            [[raw_major, None], *first, *second])
                if len(proof) != 4:
                    raise N.Invalid("old binary elimination arity")
                premise, conclusion, annotation = elimination(
                    self, major, proof[2], environment)
                if not N.same(goal, conclusion):
                    return None
                second = self.compile(premise, proof[3], assumptions, environment)
                return (None if second is None else
                        [[raw_major, annotation], *first, *second])
        if (isinstance(goal, N.Eq) and isinstance(goal.left, N.Rec)
                and array and len(proof) == 0):
            return [[]] if computation(goal) else None
        return [None] if any(N.same(goal, h) for h in assumptions) else None


def compile_old_document(document):
    """Compile a strictly valid old certificate to an exact new stack."""
    if (type(document) is not list or len(document) < 2
            or not N.accept_document(document, open_context=True)):
        raise N.Invalid("source tree is not independently verified")
    old_goal, proof, *old_context = document
    oracle = TreeCompiler(strict_witness=True)
    goal = oracle.formula(old_goal)
    context = [oracle.formula(hypothesis) for hypothesis in old_context]
    preorder = oracle.compile(goal, proof, context)
    if preorder is None:
        raise N.Invalid("source compilation failed")
    return [recode(old_goal, 1), list(reversed(recode(preorder, 1))),
            *recode(old_context, 1)]
