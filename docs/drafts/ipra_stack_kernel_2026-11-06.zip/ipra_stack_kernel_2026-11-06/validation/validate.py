"""Deterministic differential validation for the new proof-stack boundary.

Run from any directory with Python 3.10+.  Expected logical decisions come from
named-variable reconstruction, never from the production substitution routine.
Accepted stacks are independently reconstructed and checked again by the
unchanged strict arity-calculus checker and its unchanged named-variable oracle.
This is regression evidence, not a machine-checked metatheorem.
"""

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import types

from frozen import proof_oracle as N
from frozen.substitution_oracle import oracle as named_substitution
from reconstruct import compile_old_document, recode, reconstruct_document


ROOT = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent
VARIANTS = {
    "demand_prefix": ("checker.py", False, False),
    "strict_prefix": ("checker_strict.py", True, False),
    "strict_exact": ("checker_exact.py", True, True),
}


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def run_candidate(module, document, exact=False):
    """Mirror only the public input boundary, with an independent input copy."""
    data = copy.deepcopy(document)
    try:
        goal, stack, *context = data
        accepted = module.check(goal, stack, *context) is True
        if exact:
            accepted = accepted and not stack
        return accepted, len(stack)
    except Exception:
        return False, None


def run_old(module, document):
    try:
        goal, proof, *context = document
        for hypothesis in context:
            module.subst(hypothesis)
        return module.check(goal, proof, context) is True
    except Exception:
        return False


def confirm_reconstruction(record, old, modules):
    assert record["accepted"]
    doc = record["old_document"]
    assert run_old(old, doc), "reconstructed tree rejected by strict old checker"
    assert N.accept_document(doc, open_context=True), "named old oracle disagrees"
    canonical = record["canonical_document"]
    assert run_candidate(modules["strict_exact"], canonical, True) == (True, 0)


def make_fixtures():
    """Small cases chosen for individual new or delicate semantic boundaries."""
    fixtures = []

    def add(name, goal, preorder, context=(), expected=(True, True, True), note=""):
        fixtures.append({
            "name": name,
            "document": [goal, list(reversed(preorder)), *context],
            "expected": dict(zip(VARIANTS, expected)),
            "note": note,
        })

    truth = ["=", 0, 0]
    falsehood = ["=", 0, ["s", 0]]
    rzero = ["=", ["r", 0, 0, 1], 0]
    add("hypothesis", truth, [None], [truth])
    add("zero_computation", rzero, [[]])
    add("false_computation", ["=", ["r", 0, 0, 1], ["s", 0]], [[]],
        expected=(False,) * 3)
    variable_counter = ["=", ["r", 1, 0, 1], 0]
    add("variable_counter_commits_and_rejects", variable_counter, [[]],
        [variable_counter], expected=(False,) * 3)

    # The inserted previous recursive value occurs underneath two further
    # recursor binders.  Its free parameters must be shifted by two.
    update = ["r", 2, 1, ["s", 3]]
    previous = ["r", 1, 2, update]
    shifted_previous = ["r", 3, 4, update]
    nested_left = ["r", ["s", 1], 2, update]
    nested_right = ["r", 1, previous, ["s", shifted_previous]]
    add("nested_recursion_capture_avoided", ["=", nested_left, nested_right], [[]])
    wrong_right = ["r", 1, previous, ["s", previous]]
    add("nested_recursion_capture_rejected", ["=", nested_left, wrong_right], [[]],
        expected=(False,) * 3)

    major = ["=", 1, 2]
    motive = ["pi", truth, ["=", 2, 1]]
    premise = ["pi", truth, ["=", 2, 1]]
    conclusion = ["pi", truth, ["=", 3, 1]]
    add("transport_beneath_quantifier", conclusion,
        [[major, motive], None, None], [major, premise])
    add("transport_capture_rejected", premise,
        [[major, motive], None, None], [major, premise], expected=(False,) * 3)

    parameter_zero = ["=", 1, 0]
    add("pi_retains_fixed_parameter", ["pi", falsehood, ["=", 2, 0]],
        [[], None], [parameter_zero])
    add("pi_eigenvariable_cannot_use_old_parameter", ["pi", falsehood, ["=", 1, 0]],
        [[], None], [parameter_zero], expected=(False,) * 3)
    existential = ["ex", ["=", 1, 0]]
    add("existential_eigenvariable_cannot_escape", parameter_zero,
        [[existential, None], None, None], [existential], expected=(False,) * 3)
    vacuous_exists = ["ex", truth]
    add("existential_elimination", truth,
        [[vacuous_exists, None], None, None], [vacuous_exists])
    add("existential_auxiliary_is_inactive", truth,
        [[vacuous_exists, {"inactive": True}], None, None], [vacuous_exists])
    add("fresh_witness_equation", ["ex", ["=", 1, 2]], [[1], None])

    # A direct equation-induction step: R(x,0;u,v.Su)=x.  Its step transports
    # a recursion computation along the literal induction equation.
    equation = ["=", ["r", 0, -1, ["s", 0]], 0]
    base = named_substitution(equation, [-1, 0])
    step_motive = ["=", ["r", ["s", 1], -1, ["s", 0]], ["s", 0]]
    add("literal_equation_induction", recode(["pi", base, equation], 1),
        recode([[], [equation, step_motive], None, []], 1))

    # Wrap the same equation in a vacuous existential.  Reusing the induction
    # hypothesis is now forbidden: the compound branch retains the base only.
    compound = ["ex", named_substitution(equation, (1,))]
    compound_base = named_substitution(compound, [-1, 0])
    lifted_equation = named_substitution(equation, (2,))
    lifted_motive = named_substitution(step_motive, (2,), depth=1)
    bad_step = [[], [compound, None], None, [-1],
                [lifted_equation, lifted_motive], None, []]
    add("compound_formula_cannot_use_induction_hypothesis",
        recode(["pi", compound_base, compound], 1), recode(bad_step, 1),
        expected=(False,) * 3,
        note="Accepts under the deliberately faulty full-formula-induction mutant.")
    simple_equation = ["=", ["r", 0, -1, -1], -1]
    simple_compound = ["ex", named_substitution(simple_equation, (1,))]
    simple_base = named_substitution(simple_compound, [-1, 0])
    add("compound_numerical_cases",
        recode(["pi", simple_base, simple_compound], 1),
        recode([[], [-1], []], 1))

    universal = ["pi", truth, truth]
    add("unused_malformed_universal_annotation", truth,
        [[universal, {"not": "a term"}], None, None], [universal, truth],
        expected=(True, False, False),
        note="Demand acceptance is reconstructed with the canonical witness zero.")
    dependent_universal = ["pi", truth, ["=", 1, 1]]
    add("used_malformed_universal_annotation", truth,
        [[dependent_universal, {"not": "a term"}], None, None],
        [dependent_universal, truth], expected=(False,) * 3)
    add("wrong_sort_equality_motive", truth,
        [[truth, 0], None, None], [truth], expected=(False,) * 3)

    add("failed_major_falls_back_to_hypothesis", truth,
        [[falsehood, {"unused": True}], None], [truth])
    add("failed_major_consumption_before_outer_minor", truth,
        [[universal, 0], [falsehood, None], None, None], [universal, truth])
    malformed_major = ["bogus", 0]
    add("malformed_major_does_not_fall_back", truth,
        [[malformed_major, None], None], [truth], expected=(False,) * 3)

    add("malformed_unused_context", truth, [None], [truth, ["bogus"]],
        expected=(False,) * 3)
    add("boolean_is_not_a_number", ["=", False, 0], [None],
        [["=", False, 0]], expected=(False,) * 3)
    add("negative_term_code", ["=", -1, 0], [None],
        [["=", -1, 0]], expected=(False,) * 3)
    add("term_wrong_arity", ["=", ["s", 0, 0], 0], [None],
        [["=", ["s", 0, 0], 0]], expected=(False,) * 3)
    add("formula_wrong_sort", ["s", 0], [None], [["s", 0]],
        expected=(False,) * 3)
    add("formula_inside_term", ["=", truth, 0], [None], [["=", truth, 0]],
        expected=(False,) * 3)

    prefix = [rzero, [None, []]]
    fixtures.append({"name": "unused_initial_null", "document": prefix,
                     "expected": dict(zip(VARIANTS, (True, True, False))),
                     "note": "Unused initial stack cell is permitted only by prefix checkers."})
    prefix_bad = [rzero, [{"unread": ["bogus"]}, []]]
    fixtures.append({"name": "unused_initial_malformed_payload", "document": prefix_bad,
                     "expected": dict(zip(VARIANTS, (True, True, False))), "note": ""})
    add("null_at_consumed_end_is_not_exhaustion", rzero, [None, []],
        expected=(False,) * 3)
    add("empty_stack", rzero, [], expected=(False,) * 3)
    return fixtures


def check_substitution(modules):
    """Targeted simultaneous-substitution and binder-depth cross-checks."""
    formula = ["pi", ["=", 1, 2],
               ["ex", ["=", ["r", 2, 3, ["r", 2, 1, ["s", 5]]], 3]]]
    term = ["r", 1, 2, ["r", 2, 1, ["s", 5]]]
    cases = [
        (0, (3,), 0, False),
        (1, (3,), 0, False),
        (2, (["s", 1], 0, -2), 0, False),
        (term, (2,), 0, False),
        (term, (["s", 1], 0, -2), 0, False),
        (formula, (1,), 0, True),
        (formula, (0, 0), 0, True),
        (formula, (["s", 1], 0), 0, True),
        (formula, (["r", 1, 2, ["s", 1]], -1), 0, True),
        (formula, (2,), 1, True),
    ]
    for expression, environment, depth, is_formula in cases:
        old_environment = [recode(t, -1) for t in environment[:-1]] + [environment[-1]]
        expected = recode(named_substitution(recode(expression, -1), old_environment,
                                             depth, is_formula), 1)
        for module in modules.values():
            actual = module.subst(expression, environment, depth, is_formula)
            assert actual == expected, "named substitution oracle disagrees"
    return len(cases)


def check_mutations(fixtures, source):
    """Each deliberate semantic fault has a specifically targeted witness."""
    by_name = {item["name"]: item for item in fixtures}
    mutations = [
        ("unrestricted_formula_induction",
         "h = b if b[0] == '=' else h", "h = b",
         "compound_formula_cannot_use_induction_hypothesis"),
        ("equation_induction_removed",
         "h = b if b[0] == '=' else h", "h = h",
         "literal_equation_induction"),
        ("existential_target_not_lifted",
         "b, h = subst(a), *parts", "b, h = a, *parts",
         "existential_eigenvariable_cannot_escape"),
        ("retained_context_not_lifted",
         "*map(subst, g), h", "*g, h",
         "pi_eigenvariable_cannot_use_old_parameter"),
        ("unused_context_not_validated",
         "for b in (a, *g):", "for b in (a,):",
         "malformed_unused_context"),
    ]
    records = []
    for name, before, after, witness in mutations:
        assert source.count(before) == 1, (name, "mutation point changed")
        module = types.ModuleType("fault_" + name)
        exec(compile(source.replace(before, after), name, "exec"), module.__dict__)
        fixture = by_name[witness]
        actual, _ = run_candidate(module, fixture["document"])
        expected = fixture["expected"]["demand_prefix"]
        assert actual != expected, (name, "targeted fault was not detected")
        records.append({"fault": name, "witness": witness, "detected": True,
                        "expected": expected, "mutant_accepted": actual})
    return records


def main():
    modules = {name: load_module("stack_" + name, ROOT / file)
               for name, (file, _, _) in VARIANTS.items()}
    old = load_module("strict_old_checker", ROOT / "comparison/sources"
                      / "ipra_arity_calculus_2026-11-06/checker_open.py")
    result = {"status": "PASS", "scope": "deterministic regression evidence",
              "corpus": [], "boundary_cases": [], "cli": []}
    for source in sorted((HERE / "source_corpus").glob("*.json")):
        original = json.loads(source.read_text())
        assert run_old(old, original), "source strict checker rejected its corpus"
        document = compile_old_document(original)
        (ROOT / "examples" / source.name).write_text(
            json.dumps(document, separators=(",", ":")) + "\n")
        for name, (_, strict, exact) in VARIANTS.items():
            assert run_candidate(modules[name], document, exact) == (True, 0)
            record = reconstruct_document(document, strict, exact)
            confirm_reconstruction(record, old, modules)
        result["corpus"].append({"name": source.name,
                                  "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
                                  "stack_cells": len(document[1]),
                                  "all_variants_accept_exactly": True,
                                  "strict_old_reconstruction": True})

    fixtures = make_fixtures()
    # Every proper execution-order prefix of a small canonical theorem fails.
    sample = json.loads((ROOT / "examples/reflexivity.json").read_text())
    for length in range(len(sample[1])):
        fixtures.append({"name": "truncated_reflexivity_" + str(length),
                         "document": [sample[0], sample[1][-length:] if length else []],
                         "expected": dict.fromkeys(VARIANTS, False), "note": ""})
    fixtures.append({"name": "reversed_execution_order",
                     "document": [sample[0], list(reversed(sample[1]))],
                     "expected": dict.fromkeys(VARIANTS, False), "note": ""})

    for fixture in fixtures:
        decisions = {}
        for name, (_, strict, exact) in VARIANTS.items():
            expected = fixture["expected"][name]
            actual, remaining = run_candidate(modules[name], fixture["document"], exact)
            independent = reconstruct_document(fixture["document"], strict, exact)
            assert independent["accepted"] == expected, (fixture["name"], name, independent)
            assert actual == expected, (fixture["name"], name, actual, expected)
            if actual:
                assert remaining == independent["remaining"]
                confirm_reconstruction(independent, old, modules)
            decisions[name] = {"accepted": actual, "expected": expected,
                               "remaining": remaining}
        result["boundary_cases"].append({"name": fixture["name"], "variants": decisions})
    (HERE / "cases.json").write_text(json.dumps(fixtures, indent=2) + "\n")
    result["substitution_oracle_cases"] = check_substitution(modules)
    result["mutation_sensitivity"] = check_mutations(fixtures, (ROOT / "checker.py").read_text())

    # Exercise the real JSON/CLI boundary, including exact exhaustion and null.
    selected = {"zero_computation", "unused_initial_null",
                "unused_malformed_universal_annotation", "malformed_unused_context"}
    with tempfile.TemporaryDirectory(prefix="ipra_stack_validation_") as temporary:
        for fixture in fixtures:
            if fixture["name"] not in selected:
                continue
            path = Path(temporary) / "certificate.json"
            path.write_text(json.dumps(fixture["document"]))
            for name, (file, _, _) in VARIANTS.items():
                process = subprocess.run([sys.executable, str(ROOT / file), str(path)],
                                         capture_output=True, text=True, timeout=15)
                expected = fixture["expected"][name]
                assert process.stdout.strip() == ("ACCEPT" if expected else "REJECT")
                assert process.returncode == (0 if expected else 1)
                result["cli"].append({"case": fixture["name"], "variant": name,
                                       "expected": expected, "passed": True})
    result["counts"] = {
        "source_theorems": len(result["corpus"]),
        "boundary_cases": len(fixtures),
        "checker_variants": len(VARIANTS),
        "substitution_cases": result["substitution_oracle_cases"],
        "targeted_faults": len(result["mutation_sensitivity"]),
        "cli_cases": len(result["cli"]),
    }
    (ROOT / "results/validation.json").write_text(json.dumps(result, indent=2) + "\n")
    counts = result["counts"]
    summary = (
        "The executed validation completed successfully. The "
        + str(counts["source_theorems"]) + " source theorem certificates were accepted "
        "by all three variants with no unused stack cells. Each accepted "
        "result was reconstructed into a strict reference proof tree.\n\n"
        "\\begin{center}\\small\n"
        "\\begin{tabular}{@{}lr@{}}\n\\toprule\n"
        "Executed checks & Count\\\\\n\\midrule\n"
        "Source-certificate runs across three variants & "
        + str(counts["source_theorems"] * counts["checker_variants"]) + "\\\\\n"
        "Boundary scenarios (each run on three variants) & "
        + str(counts["boundary_cases"]) + "\\\\\n"
        "Named-substitution cases (each run on three variants) & "
        + str(counts["substitution_cases"]) + "\\\\\n"
        "Deliberate semantic faults detected & "
        + str(counts["targeted_faults"]) + "\\\\\n"
        "Actual command-line invocations & "
        + str(counts["cli_cases"]) + "\\\\\n"
        "\\bottomrule\n\\end{tabular}\n\\end{center}\n\n"
        "The fault tests separately detect unrestricted compound-formula "
        "induction, removal of equation induction, an escaping existential "
        "eigenvariable, failure to lift retained assumptions, and omission "
        "of validation for an unused external assumption. Full per-case "
        "decisions are recorded in \\code{results/validation.json}.\n"
    )
    (ROOT / "results/validation_summary.tex").write_text(summary)
    print(json.dumps({"status": "PASS", **result["counts"]}, indent=2))


if __name__ == "__main__":
    main()
