"""Reproduce checker-size comparisons and independent certificate validation."""
from pathlib import Path
import json
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    steps = [
        ['comparison/measure.py', '--require-reduction', '--require-core-reduction'],
        ['validation/validate.py'],
    ]
    records = []
    for arguments in steps:
        result = subprocess.run([sys.executable, *arguments], cwd=ROOT,
                                text=True, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT)
        records.append({'command': ['python3', *arguments],
                        'returncode': result.returncode,
                        'output': result.stdout})
        if result.returncode:
            print(result.stdout)
            raise RuntimeError('Reproduction step failed: ' + arguments[0])
    metrics = json.loads((ROOT / 'results/metrics.json').read_text())
    validation = json.loads((ROOT / 'results/validation.json').read_text())
    record = {'status': 'PASS', 'python': platform.python_version(),
              'steps': records, 'validation_counts': validation['counts'],
              'recorded_baseline_metrics_match': metrics['recorded_metric_match']}
    (ROOT / 'results/reproduction.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({key: value for key, value in record.items() if key != 'steps'}, indent=2))


if __name__ == '__main__':
    main()
