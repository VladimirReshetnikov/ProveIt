"""Create checksums and a clean ZIP of the report, source, and evidence."""
import hashlib
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {'.aux', '.log', '.out', '.toc', '.pyc', '.synctex.gz'}


def files():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and '__pycache__' not in p.parts
                  and p.suffix not in EXCLUDED_SUFFIXES
                  and p.name != 'MANIFEST.sha256')


def main():
    if not (ROOT / 'report.pdf').is_file():
        raise SystemExit('Build report.pdf first')
    manifest = ROOT / 'MANIFEST.sha256'
    manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()
                               + '  ' + p.relative_to(ROOT).as_posix() + '\n'
                               for p in files()))
    archive = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as target:
        for path in [*files(), manifest]:
            target.write(path, ROOT.name + '/' + path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(archive) as target:
        if target.testzip() is not None:
            raise ValueError('ZIP integrity check failed')
    print(archive)


if __name__ == '__main__':
    main()
