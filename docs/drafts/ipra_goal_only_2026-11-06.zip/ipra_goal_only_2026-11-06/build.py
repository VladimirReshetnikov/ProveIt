"""Build the self-contained article with pdfLaTeX."""
import json
import subprocess
from pathlib import Path
from reproduce import write_numbers

ROOT = Path(__file__).resolve().parent


def main():
    write_numbers(json.loads((ROOT / 'results/metrics.json').read_text()))
    for _ in range(3):
        run = subprocess.run(
            ['pdflatex', '-interaction=nonstopmode', '-halt-on-error', 'report.tex'],
            cwd=ROOT, capture_output=True, text=True)
        if run.returncode:
            print(run.stdout[-12000:])
            raise SystemExit(run.returncode)
    log = (ROOT / 'report.log').read_text(errors='replace')
    findings = [line for line in log.splitlines()
                if 'Overfull' in line or 'undefined' in line.lower()
                or 'LaTeX Warning' in line]
    if findings:
        print('\n'.join(findings))
    print(ROOT / 'report.pdf')


if __name__ == '__main__':
    main()
