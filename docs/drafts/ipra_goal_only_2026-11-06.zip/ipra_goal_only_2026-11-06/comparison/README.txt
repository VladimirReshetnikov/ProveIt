CURRENT-DRAFT COMPARISON

This directory freezes exactly the nine top-level checker variants in the
five active ProveIt docs/drafts archives at commit
1d1b154fb3f071169b6a003b3f9d727166880006.

The Python sources are byte-for-byte archive members. manifest.json records
each original path, archive member, source SHA-256, archive SHA-256, archive
Git blob SHA-1, and pinned public source URL. The original archive hashes
were checked against the Git tree when this package was assembled. The
archive ZIPs themselves are not duplicated in this package.

Run:

    python3 comparison/measure.py

This verifies all nine frozen source hashes, counts all application-specific
acceptance code, measures each candidate checker present at the package root,
and writes results/metrics.json and results/metrics.csv. It works offline
with the Python standard library. CPython 3.12.14 reproduces the recorded
normalization exactly; AST/unparse details may change between Python versions.

The counting method is inherited from the current drafts: remove only actual
module, class, and function docstrings, then count significant source tokens,
normalized significant tokens, all remaining AST nodes, and normalized bytes.
The complete programs include syntax and binding tables, substitution, all
logical/arithmetic acceptance rules, JSON decoding, CLI, and error handling.
Raw bytes are reported only as a formatting-sensitive supplementary measure.

The coordinatewise envelope among these nine current complete programs is:

    Source tokens       569
    Normalized tokens   569
    AST nodes           582
    Normalized bytes   1762
    Raw bytes          1852

All these minima are attained by goal_reconstruction__checker.py. Its public
interface is an empty-context theorem checker with demand validation of
universal witnesses. The script also reports separate envelopes for open
sequents and theorem interfaces, with strict or demand witness policies.

The five supplied reports compared against an earlier six-draft snapshot.
Their stated historical envelope (603 tokens / 639 AST nodes / 1928 bytes)
is not used as the present comparison target.

This finite observed envelope is not a mathematical lower bound on every
possible iPRA proof checker. Library/runtime code common to all programs is
not counted. No candidate proof generator, translator, or validation suite
participates in checker acceptance.

Baseline sources retain the supplied MIT No Attribution license in
LICENSE_SOURCE.txt.
