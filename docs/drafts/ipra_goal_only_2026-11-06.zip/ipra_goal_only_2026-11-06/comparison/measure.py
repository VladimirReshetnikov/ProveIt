"""Remeasure complete current iPRA checkers and verify frozen sources.

The counting method is the one used in the supplied current drafts:
remove actual module/class/function docstrings from the AST; count
significant Python tokens; unparse with the same interpreter; count all
remaining AST nodes and UTF-8 bytes.  No executable code is excluded.

Run from any directory: python3 comparison/measure.py
"""

import ast
import csv
import hashlib
import io
import json
import platform
import sys
import tokenize
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FIELDS = (
    "source_tokens", "normalized_tokens", "ast_nodes",
    "normalized_bytes", "raw_bytes",
)
IGNORED = {
    tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
    tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER,
}


def measure(path):
    raw = path.read_bytes()
    source = raw.decode("utf-8")
    tree = ast.parse(source)
    docstring_spans = []
    for node in ast.walk(tree):
        if (isinstance(node, (ast.Module, ast.ClassDef,
                              ast.FunctionDef, ast.AsyncFunctionDef))
                and node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            doc = node.body.pop(0)
            docstring_spans.append(
                ((doc.lineno, doc.col_offset),
                 (doc.end_lineno, doc.end_col_offset)))
    normalized = ast.unparse(tree) + "\n"

    def token_count(text, omitted=()):
        return sum(
            token.type not in IGNORED
            and not any(start <= token.start and token.end <= end
                        for start, end in omitted)
            for token in tokenize.generate_tokens(io.StringIO(text).readline)
        )

    return {
        "source": path.relative_to(ROOT).as_posix(),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "source_tokens": token_count(source, docstring_spans),
        "normalized_tokens": token_count(normalized),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "normalized_bytes": len(normalized.encode("utf-8")),
        "raw_bytes": len(raw),
    }


def envelope(rows):
    return {field: min(row[field] for row in rows) for field in FIELDS}


def main():
    manifest = json.loads((ROOT / "comparison/manifest.json").read_text())
    baselines = []
    for entry in manifest["baselines"]:
        row = measure(ROOT / entry["source"])
        if row["sha256"] != entry["source_sha256"]:
            raise ValueError("Modified frozen source: " + entry["source"])
        row.update({key: entry[key]
                    for key in ("interface", "witness_policy")})
        baselines.append(row)

    candidates = []
    for source, profile in manifest["candidate_profiles"].items():
        path = ROOT / source
        if path.is_file():
            row = measure(path)
            row.update(profile)
            candidates.append(row)

    overall = envelope(baselines)
    categories = {}
    for interface in ("theorem", "open_sequent"):
        for policy in ("strict", "demand"):
            matching = [r for r in baselines
                        if r["interface"] == interface
                        and r["witness_policy"] == policy]
            if matching:
                categories[interface + "/" + policy] = envelope(matching)

    below = {
        row["source"]: {
            field: row[field] < overall[field] for field in FIELDS
        } for row in candidates
    }
    same_interface = {}
    for row in candidates:
        profile = row["interface"] + "/" + row["witness_policy"]
        boundary = categories.get(profile)
        if boundary is not None:
            same_interface[row["source"]] = {
                field: row[field] < boundary[field] for field in FIELDS
            }

    result = {
        "python": sys.version,
        "python_version": platform.python_version(),
        "repository": manifest["repository"],
        "commit": manifest["commit"],
        "boundary": manifest["measurement_boundary"],
        "baselines": baselines,
        "baseline_envelope": overall,
        "interface_envelopes": categories,
        "candidates": candidates,
        "strictly_below_all_variants": below,
        "strictly_below_same_interface_and_policy": same_interface,
        "caveat": (
            "This is a finite comparison with the pinned current programs, "
            "not a representation-independent or absolute minimality theorem. "
            "Theorem and open-sequent interfaces, and strict and demand "
            "witness policies, are reported separately. Raw bytes are "
            "formatting-sensitive and are not a primary complexity measure."
        ),
    }
    results = ROOT / "results"
    results.mkdir(exist_ok=True)
    (results / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    with (results / "metrics.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=["source", "sha256", "interface", "witness_policy",
                        *FIELDS],
        )
        writer.writeheader()
        writer.writerows([*baselines, *candidates])
    print(json.dumps({
        "verified_frozen_sources": len(baselines),
        "baseline_envelope": overall,
        "candidates": [
            {key: row[key] for key in ("source", *FIELDS)}
            for row in candidates
        ],
        "strictly_below_all_variants": below,
    }, indent=2))
    return result


if __name__ == "__main__":
    main()
