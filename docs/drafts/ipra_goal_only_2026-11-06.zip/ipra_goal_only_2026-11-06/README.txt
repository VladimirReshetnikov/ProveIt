A SMALLER COMPLETE CALCULUS FOR iPRA
Prepared for Vladimir Reshetnikov -- 6 November 2026

RESULT

This package gives a complete finite proof presentation of full first-order
intuitionistic primitive recursive arithmetic. The entire strict checker,
including syntax, all logical/arithmetic rules, substitution, open contexts,
JSON decoding and rejection handling, is smaller than every coordinate of
the current five-draft, nine-program comparison frontier.

                              AST   Source tokens   Norm. tokens   Norm. bytes
Current complete-program min  582          569             569          1762
New strict open checker       574          551             553          1750
New demand open checker       562          541             543          1705

The main checker.py validates every goal, every hypothesis, and every
numerical witness, even when unused. checker_demand.py also validates
every formula, existential witness, equality motive, and demanded universal
witness; it ignores an unused universal annotation, which can always be
replaced by zero. Both have the same well-formed consequence relation.

The arithmetic basis and automatic-introduction theorem are inherited from
and credited to the supplied drafts. The contribution is a smaller complete
proof representation and verifier: introduction certificates lose their
labels, assumptions lose their indices, and a uniform validating API removes
a separate public-context wrapper. This is a measured improvement over a
fixed corpus, not an absolute minimality theorem.

The report supplies all primitive rules, the guard-perturbation completeness
argument, reconstruction of full intuitionistic logic, equation reflection
for quantifier-free induction, and two full-domain interpretations whose
composite isomorphisms are defined by x=y. It distinguishes a faithful native
presentation from the ordinary first-order theory T_cov. The metatheory is
proved in mathematical prose; it is not Lean/Rocq verified.

START HERE

  report.pdf                 Complete article.
  report.tex, sections/      Complete LaTeX sources.
  checker.py                 Main strict open-sequent checker.
  checker_demand.py          Smaller companion with irrelevant-witness erasure.
  FORMAT.txt                 Exact JSON syntax and certificate conventions.
  examples/                  19 translated, accepted proof certificates.
  comparison/                Nine exact baseline sources, hashes and measurements.
  validation/                Independent oracle, proof translations and tests.
  results/                   Actual test verdicts and measurements.
  reproduce.py               Reproduce the evidence offline.
  build.py                   Rebuild the PDF using pdfLaTeX.
  package.py                 Refresh manifest and ZIP after intentional edits.
  MANIFEST.sha256            SHA-256 for every other delivered file.

RUN

Use Python 3.10 or newer. Exact normalized measurements use CPython 3.12.14.
All Python support uses only the standard library. From the package folder:

  python3 checker.py examples/reflexivity.json
  python3 reproduce.py
  python3 build.py
  python3 package.py

The checker prints ACCEPT with exit zero on success, or REJECT with a
nonzero exit on a false verdict or ordinary exception. The public input is
[goal, proof, *hypotheses]. Free number parameters are permitted.

EXECUTED EVIDENCE

- Nine frozen baseline sources remeasured and their hashes verified.
- 19 source proofs translated to the new checker and read back to accepted
  source proofs; all conclusions and external assumptions preserved.
- 38 actual example CLI runs, including optimized Python.
- 148 independent rule/formation fixtures: 28 accept and 120 reject.
- 2,304 independent named-variable substitution comparisons and 4 anchors.
- 186 strict public CLI checks, including malformed input and 30 optimized
  Python runs.
- 67 strict/demand policy cases, with 268 actual CLI executions covering
  both variants and ordinary/optimized Python.

All reported checks passed. The suites overlap; they are finite regression
evidence, not a formal universal verification. Python resource limits can
reject extremely large otherwise valid certificates.

SOURCE SNAPSHOT

Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 1d1b154fb3f071169b6a003b3f9d727166880006
Directory: docs/drafts

The previous 639-AST/603-token frontier is obsolete for this snapshot.
All current top-level variants, including the 582-AST theorem checker,
are included in the comparison. The original source licenses and exact
archive/member provenance are retained under comparison/ and validation/.
