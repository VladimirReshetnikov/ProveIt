"""Check the optional demand interface and zero repair of unused annotations.

This is untrusted validation. Neither checker imports it. The checks
contrast inert witness payloads with demanded witnesses and motives.
"""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


STRICT = load('strict_demand_reference', ROOT / 'checker.py')
DEMAND = load('demand_candidate', ROOT / 'checker_demand.py')


def accepts(checker, record):
    try:
        return checker.check(*record) is True
    except Exception:
        return False


def main():
    rows = []
    cli_count = 0
    with tempfile.TemporaryDirectory(prefix='ipra-demand-') as directory:
        filename = Path(directory) / 'certificate.json'

        def check(name, record, expected_strict, expected_demand):
            nonlocal cli_count
            results = [accepts(checker, record) for checker in (STRICT, DEMAND)]
            expected = [expected_strict, expected_demand]
            if results != expected:
                raise ValueError((name, results, expected))
            filename.write_text(json.dumps(record), encoding='utf-8')
            for source, expected_acceptance in zip(('checker.py', 'checker_demand.py'), expected):
                for flags in ([], ['-O']):
                    run = subprocess.run([sys.executable, *flags, str(ROOT / source), str(filename)],
                                         capture_output=True, text=True)
                    outcome = run.returncode == 0 and run.stdout.strip() == 'ACCEPT'
                    if outcome != expected_acceptance or (not outcome and run.stdout.strip() != 'REJECT'):
                        raise ValueError((name, source, flags, run.returncode, run.stdout))
                    cli_count += 1
            rows.append({'name': name, 'strict': results[0], 'demand': results[1],
                         'expected_strict': expected[0], 'expected_demand': expected[1]})

        examples = sorted((ROOT / 'examples').glob('*.json'))
        for source in examples:
            check('example/' + source.name, json.loads(source.read_text()), True, True)

        truth = ['=', 0, 0]
        inert = ['pi', truth, truth]
        demanded = ['pi', ['=', 1, 1], truth]
        invalids = [None, False, -1, 1.5, 'junk', [], ['s'], ['=', 0, 0], {'ignored': True}]
        for index, bad in enumerate(invalids):
            check(f'unused/{index}', [truth, [inert, None, bad, None], inert, truth], False, True)
            check(f'zero-repair/{index}', [truth, [inert, None, 0, None], inert, truth], True, True)
            check(f'demanded/{index}', [truth, [demanded, None, bad, None], demanded, truth], False, False)

        # Unlike universal witnesses, motives are traversed as formulas
        # even when they do not refer to the equality variable.
        malformed_motives = [None, False, -1, 0, 1.5, 'junk', [], ['s', 0], ['=', 0], {'ignored': True}]
        for index, bad in enumerate(malformed_motives):
            check(f'motive/{index}', [truth, [truth, None, bad, None], truth], False, False)
        check('constant-valid-motive', [truth, [truth, None, truth, None], truth], True, True)

        # Fresh existential assumptions are never manufactured from an
        # unchecked witness, including in the optional demand checker.
        for index, bad in enumerate(invalids):
            check(f'existential-witness/{index}', [['ex', ['=', 1, 1]], [bad, None]], False, False)
        check('existential-zero', [['ex', ['=', 1, 0]], [0, None]], True, True)

    result = {'examples': len(examples), 'cases': len(rows), 'actual_cli_runs': cli_count,
              'interfaces': ['strict', 'demand'], 'python_modes': ['ordinary', 'optimized'],
              'unused_invalid_annotations': len(invalids), 'zero_repairs': len(invalids),
              'records': rows}
    (ROOT / 'results' / 'demand_checks.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in
                      ('examples', 'cases', 'actual_cli_runs', 'unused_invalid_annotations', 'zero_repairs')}))
    return result


if __name__ == '__main__':
    main()
