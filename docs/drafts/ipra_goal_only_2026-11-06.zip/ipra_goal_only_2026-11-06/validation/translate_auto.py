"""Untrusted proof translations from the strict automatic checker.

Numerical syntax is shifted by one; internal syntax of proof fields is
changed only at logical proof-node positions. The target verifier is
independent of this compiler.
"""
from pathlib import Path
import importlib.util
import json

ROOT=Path(__file__).resolve().parents[1]
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    out=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(out)
    return out
old=module('auto_strict',ROOT/'comparison'/'automatic_introduction__checker.py')
new=module('singleton_strict',ROOT/'checker.py')

def syntax(a):
    if type(a) is int:return a+1
    tag,*args=a
    return [tag,*(syntax(v) for v in args)]

def translate(a,p,g):
    match a,p:
        case ['pi',h,b],['lam',q]:
            if h==old.subst(b,[-1,0]):
                h=b if b[0]=='=' else h
                b=old.subst(b,[['s',0],0])
            return [translate(b,q,[*map(old.subst,g),h])]
        case ['ex',b],['pack',t,q]:
            return [syntax(t),translate(b,q,[*map(old.subst,g),['=',0,old.subst(t,formula=False)]])]
        case _,[[tag,*parts] as m,r,*args]:
            out=[syntax(m),translate(m,r,g)]
            if tag=='ex':
                q,=args
                out.append(translate(old.subst(a),q,[*map(old.subst,g),*parts]))
            else:
                t,q=args
                b,c=(old.subst(t,[v,-1]) if tag=='=' else old.subst(v,[t,-1]) for v in parts)
                out.extend([syntax(t),translate(b,q,g)])
            return out
        case _, 'r':return []
        case _:return None

def data(record):
    a,p,*g=record
    for h in g:old.subst(h)
    if not old.check(a,p,g):raise ValueError('Unaccepted source record')
    return [syntax(a),translate(a,p,g),*map(syntax,g)]

def old_syntax(a):
    if type(a) is int:return a-1
    tag,*args=a
    return [tag,*(old_syntax(v) for v in args)]

def readback(a,p,g):
    """Construct an old strict proof for a valid candidate certificate."""
    match a,p:
        case ['pi',h,b],[q]:
            if h==new.subst(b,[0,0]):
                h=b if b[0]=='=' else h
                b=new.subst(b,[['s',1],0])
            return ['lam',readback(b,q,[*map(new.subst,g),h])]
        case ['ex',b],[t,q]:
            return ['pack',old_syntax(t),readback(b,q,[*map(new.subst,g),['=',1,new.subst(t,formula=False)]])]
        case _,[[tag,*parts] as m,r,*args] if new.check(m,r,*g):
            out=[old_syntax(m),readback(m,r,g)]
            if tag=='ex':
                q,=args
                out.append(readback(new.subst(a),q,[*map(new.subst,g),*parts]))
            else:
                t,q=args
                b,c=(new.subst(t,[v,-1]) if tag=='=' else new.subst(v,[t,-1]) for v in parts)
                out.extend([old_syntax(t),readback(b,q,g)])
            return out
        case ['=', ['r',n,t,h],b],[]:
            return 'r'
        case _:
            return g.index(a)

def data_back(record):
    a,p,*g=record
    if not new.check(a,p,*g):raise ValueError('Unaccepted candidate record')
    return [old_syntax(a),readback(a,p,g),*map(old_syntax,g)]

def main():
    import subprocess
    import sys
    results=[]
    for path in sorted((ROOT/'validation'/'automatic_examples').glob('*.json')):
        record=json.loads(path.read_text())
        target=data(record)
        if not new.check(*target):raise ValueError(path.name)
        back=data_back(target)
        a,p,*g=back
        if not old.check(a,p,g):raise ValueError('Readback failure: '+path.name)
        if back[0]!=record[0] or back[2:]!=record[2:]:
            raise ValueError('Changed sequent: '+path.name)
        output=ROOT/'examples'/path.name
        output.write_text(json.dumps(target,indent=2)+'\n')
        modes=[]
        for extra in ([],['-O']):
            run=subprocess.run([sys.executable,*extra,str(ROOT/'checker.py'),str(output)],capture_output=True,text=True)
            if run.returncode or run.stdout.strip()!='ACCEPT':raise ValueError('CLI: '+path.name)
            modes.append({'optimized':bool(extra),'exit':run.returncode,'stdout':run.stdout.strip()})
        results.append({'file':path.name,'source_accepted':True,'candidate_accepted':True,'readback_accepted':True,'sequent_preserved':True,'external_hypotheses':len(record)-2,'cli':modes})
    result={'examples':len(results),'cli_checks':2*len(results),'records':results}
    (ROOT/'results'/'translation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'translated':len(results),'readbacks':len(results),'CLI_checks':2*len(results)}))
    return result

if __name__=='__main__':main()
