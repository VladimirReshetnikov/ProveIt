"""Focused independent audit of the strict goal-only public checker.

Run from any directory: python3 validation/audit.py [path/to/checker.py]
All generated fixtures and random seeds are deterministic.  The independent
oracle calls no candidate helper.  Finite tests supplement the mathematical
soundness/completeness arguments; they are not a formal proof of them.
"""

import hashlib
import importlib.util
import json
import random
import subprocess
import sys
import tempfile
from collections import Counter
from pathlib import Path

import oracle

ROOT = Path(__file__).resolve().parents[1]
SEED = 20261106


def eq(s, t):
    return ["=", s, t]


def succ(t):
    return ["s", t]


def rec(n, a, h):
    return ["r", n, a, h]


def reflexivity(t):
    """Untrusted builder, using independent substitution only."""
    r = rec(0, t, 0)
    major = eq(r, t)
    motive = eq(1, oracle.subst(t, formula=False))
    return [major, [], motive, []]


def fixtures():
    result = []

    def add(name, expected, a, p, *g):
        result.append({"name": name, "expected": expected,
                       "data": [a, p, *g]})

    truth, falsehood = eq(0, 0), eq(0, succ(0))
    add("hypothesis-membership", True, truth, None, truth)
    add("unused-proof-object-is-a-hypothesis", True, truth, {"unused": []}, truth)
    add("unconditional-falsehood-rejected", False, falsehood, None)
    add("unproved-reflexivity-is-not-an-axiom", False, truth, None)
    add("derived-reflexivity", True, truth, reflexivity(0))
    add("reflexivity-with-sparse-parameter", True, eq(17, 17), reflexivity(17))
    for i, initial in enumerate((0, 1, succ(4), rec(3, 0, succ(1)))):
        term = rec(0, initial, rec(2, 1, succ(3)))
        add("computation-zero-%d" % i, True, eq(term, initial), [])
        add("computation-zero-wrong-rhs-%d" % i, False,
            eq(term, succ(initial)), [])
    updates = (1, 2, succ(1), rec(2, 1, succ(3)),
               rec(3, rec(2, 1, 4), rec(2, 3, succ(5))))
    for i, update in enumerate(updates):
        r = rec(succ(1), 2, update)
        rhs = oracle.subst(update, [rec(1, 2, update), 1, -2], formula=False)
        add("successor-update-binding-%d" % i, True, eq(r, rhs), [])
        add("successor-update-wrong-rhs-%d" % i, False, eq(r, succ(rhs)), [])
    add("counter-variable-cannot-compute", False, eq(rec(1, 0, 1), 0), [])
    add("counter-recursor-cannot-compute", False,
        eq(rec(rec(0, 0, 0), 0, 1), 0), [])
    add("computation-needs-empty-certificate", False,
        eq(rec(0, 0, 0), 0), None)

    identity = ["pi", eq(1, 1), eq(1, 1)]
    add("ordinary-guarded-introduction", True, identity, [None])
    add("guarded-introduction-empty-arity", False, identity, [])
    add("guarded-introduction-extra-arity", False, identity, [None, None])
    add("retained-parameter-is-shifted", True,
        ["pi", eq(1, 1), eq(2, 0)], [None], eq(1, 0))
    add("retained-parameter-cannot-be-captured", False,
        ["pi", eq(1, 1), eq(1, 0)], [None], eq(1, 0))
    for i, t in enumerate((0, 1, succ(3), rec(2, 0, succ(1)))):
        goal = ["ex", eq(1, oracle.subst(t, formula=False))]
        add("existential-witness-%d" % i, True, goal, [t, None])
    existence = ["ex", eq(1, 0)]
    add("existential-empty-arity", False, existence, [])
    add("existential-short-arity", False, existence, [0])
    add("existential-extra-arity", False, existence, [0, None, None])
    add("existential-witness-must-match", False, existence, [succ(0), None])
    add("existential-witness-is-lifted", False, ["ex", eq(1, 1)], [1, None])

    # A genuinely recursive equation induction step uses its induction equation.
    b = eq(rec(1, 0, succ(1)), 1)
    step_lhs = rec(succ(1), 0, succ(1))
    motive = eq(oracle.subst(step_lhs, formula=False), succ(1))
    child = [b, None, motive, []]
    induction = ["pi", oracle.subst(b, [0, 0]), b]
    add("equation-induction-uses-hypothesis", True, induction, [child])
    add("equation-induction-wrong-step", False, induction, [None])
    constant_compound = ["ex", eq(1, 1)]
    add("compound-automatic-collision", True,
        ["pi", constant_compound, constant_compound], [None])
    compound = ["ex", eq(1, 2)]
    compound_goal = ["pi", oracle.subst(compound, [0, 0]), compound]
    add("compound-numerical-cases", True, compound_goal, [[succ(1), None]])
    # This certificate would work if the compound branch supplied B(n).
    # Correct cases supplies only B(0), so its attempted B(n) major must fail.
    bad_compound_step = [compound, None, [succ(2), None]]
    add("compound-cases-does-not-give-induction-hypothesis", False,
        compound_goal, [bad_compound_step])
    add("automatic-numerical-branch-is-not-optional", False,
        ["pi", eq(0, 0), eq(1, 0)], [None])

    witness = rec(0, succ(0), 0)
    add("guarded-elimination", True, eq(witness, witness),
        [identity, [None], witness, reflexivity(witness)])
    vacuous = ["pi", truth, truth]
    add("vacuous-valid-witness", True, truth,
        [vacuous, [None], 0, None], truth)
    add("equality-transport", True, eq(succ(1), 0),
        [eq(1, succ(1)), None, eq(1, 0), None], eq(1, succ(1)), eq(1, 0))
    nested_motive = ["ex", eq(rec(2, 0, succ(1)), 2)]
    nested_source = oracle.subst(nested_motive, [1, -1])
    nested_target = oracle.subst(nested_motive, [succ(1), -1])
    add("equality-transport-nested-binder", True, nested_target,
        [eq(1, succ(1)), None, nested_motive, None],
        eq(1, succ(1)), nested_source)
    add("existential-elimination", True, truth,
        [existence, None, reflexivity(0)], existence)
    add("existential-eigenvariable-cannot-escape", False, eq(1, 0),
        [existence, None, None], existence)
    add("failed-major-hypothesis-fallback", True, truth,
        [falsehood, None, 0, None], truth)
    add("failed-major-does-not-prove-new-goal", False, truth,
        [falsehood, None, 0, None])
    add("malformed-major-does-not-fallback", False, truth,
        [["=", True, 0], None, 0, None], truth)

    for i, bad in enumerate((None, False, 0.0, -1, "junk", [], ["s"],
                              ["s", 0, 0], ["=", 0, 0], {},
                              rec(0, 0, ["bad"]))):
        add("strict-vacuous-universal-witness-%d" % i, False, truth,
            [vacuous, [None], bad, None], truth)
        add("strict-existential-witness-%d" % i, False,
            existence, [bad, None])

    for tag, major, major_proof, args, target, context in (
            ("pi", vacuous, [None], [0, None], truth, [truth]),
            ("eq", eq(0, 0), None, [truth, None], truth, [truth]),
            ("ex", existence, None, [reflexivity(0)], truth, [existence])):
        for count in range(5):
            if count == len(args):
                continue
            malformed_args = (args + [None] * 5)[:count]
            add("%s-elimination-arity-%d" % (tag, count), False,
                target, [major, major_proof, *malformed_args], *context)

    invalid_expressions = (
        None, True, False, 0, 1.0, -1, "=", {}, [], ["="], ["=", 0],
        ["=", 0, 0, 0], ["=", True, 0], ["=", 0.0, 0],
        ["=", -1, 0], ["=", ["s"], 0], ["=", ["s", 0, 1], 0],
        ["=", ["r", 0, 0], 0], ["=", ["r", 0, 0, 0, 0], 0],
        ["=", ["r", 0, 0, ["pi", truth, truth]], 0],
        ["pi", truth], ["pi", truth, truth, truth], ["pi", 0, truth],
        ["ex"], ["ex", truth, truth], ["ex", 0], ["unknown", truth],
        ["ex", ["=", False, 0]], ["pi", truth, ["=", 1.0, 0]],
    )
    for i, bad in enumerate(invalid_expressions):
        add("malformed-public-goal-%d" % i, False, bad, None, truth)
        add("malformed-unused-context-%d" % i, False,
            truth, reflexivity(0), bad)
    return result


def random_term(rng, height):
    if height == 0 or rng.randrange(3) == 0:
        return rng.randrange(10)
    if rng.randrange(2) == 0:
        return succ(random_term(rng, height - 1))
    return rec(*(random_term(rng, height - 1) for _ in range(3)))


def random_formula(rng, height):
    if height == 0 or rng.randrange(3) == 0:
        return eq(random_term(rng, 3), random_term(rng, 3))
    if rng.randrange(2) == 0:
        return ["pi", random_formula(rng, height - 1),
                random_formula(rng, height - 1)]
    return ["ex", random_formula(rng, height - 1)]


def main():
    candidate_path = (Path(sys.argv[1]).resolve() if len(sys.argv) > 1
                      else ROOT / "checker.py")
    spec = importlib.util.spec_from_file_location("strict_candidate", candidate_path)
    candidate = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(candidate)
    cases = fixtures()
    failures = []
    records = []
    coverage = Counter()

    def accepted(data):
        try:
            return bool(candidate.check(*data))
        except Exception:
            return False

    for case in cases:
        actual = accepted(case["data"])
        independent = oracle.accepted(case["data"])
        passed = actual == independent == case["expected"]
        records.append({"name": case["name"], "expected": case["expected"],
                        "candidate": actual, "independent": independent,
                        "passed": passed})
        if not passed:
            failures.append({"stage": "rule", **case,
                             "candidate": actual, "independent": independent})
        if independent:
            coverage.update(oracle.check(case["data"]))

    rng = random.Random(SEED)
    substitution_count = 0
    environments = ((1,), (3,), (0, 0), (succ(1), 0), (succ(0), -1),
                    (rec(1, 2, succ(1)), 3, -2))
    for is_formula in (False, True):
        for _ in range(64):
            expression = (random_formula(rng, 3) if is_formula
                          else random_term(rng, 4))
            for depth in (0, 1, 3):
                for env in environments:
                    expected = oracle.subst(expression, env, depth, is_formula)
                    actual = candidate.subst(expression, env, depth, is_formula)
                    substitution_count += 1
                    if actual != expected:
                        failures.append({"stage": "named-substitution",
                                         "expression": expression, "env": env,
                                         "depth": depth, "formula": is_formula,
                                         "expected": expected, "actual": actual})

    # Literal, independently checked examples prevent a shared convention error.
    anchors = (
        (eq(1, 2), [succ(0), -1], True, eq(succ(0), 1)),
        (["ex", eq(1, 2)], [succ(0), -1], True,
         ["ex", eq(1, succ(0))]),
        (rec(1, 2, rec(2, 1, succ(3))), [succ(0), -1], False,
         rec(succ(0), 1, rec(2, 1, succ(3)))),
        (rec(2, 1, succ(3)), [7, 8, -2], False, rec(8, 7, succ(9))),
    )
    for expression, env, is_formula, expected in anchors:
        actual = candidate.subst(expression, env, formula=is_formula)
        independent = oracle.subst(expression, env, formula=is_formula)
        if actual != expected or independent != expected:
            failures.append({"stage": "literal-substitution-anchor",
                             "expression": expression, "env": env,
                             "expected": expected, "actual": actual,
                             "independent": independent})

    cli_records = []
    # Run every labeled rule/formation fixture through the real public CLI.
    # Optimized Python is additionally checked on a representative subset.
    with tempfile.TemporaryDirectory(prefix="ipra_goal_only_audit_") as tmp:
        input_path = Path(tmp) / "input.json"

        def cli(name, text, expected, optimized=False, extra_args=()):
            input_path.write_text(text)
            command = [sys.executable, *(["-O"] if optimized else []),
                       str(candidate_path), str(input_path), *extra_args]
            run = subprocess.run(command, capture_output=True, text=True, timeout=15)
            correct = (run.returncode == (0 if expected else 1)
                       and run.stdout.strip() == ("ACCEPT" if expected else "REJECT"))
            entry = {"name": name, "optimized": optimized,
                     "expected": expected, "exit_code": run.returncode,
                     "stdout": run.stdout.strip(), "passed": correct}
            cli_records.append(entry)
            if not correct:
                failures.append({"stage": "public-cli", **entry,
                                 "stderr": run.stderr})

        for case in cases:
            cli(case["name"], json.dumps(case["data"]), case["expected"])
        selected = [c for c in cases if c["expected"]][:12]
        selected += [c for c in cases if not c["expected"]][:12]
        selected += [c for c in cases if c["name"] in (
            "equation-induction-uses-hypothesis", "compound-numerical-cases",
            "compound-cases-does-not-give-induction-hypothesis",
            "existential-eigenvariable-cannot-escape",
            "strict-vacuous-universal-witness-0", "malformed-unused-context-1")]
        for case in selected:
            cli(case["name"], json.dumps(case["data"]), case["expected"], True)
        for name, raw in (
                ("empty-json", ""), ("truncated-json", "["),
                ("trailing-json", "[] []"), ("object-root", "{}"),
                ("null-root", "null"), ("zero-input-fields", "[]"),
                ("one-input-field", '[ ["=",0,0] ]')):
            cli(name, raw, False)
        cli("unexpected-extra-command-argument", json.dumps(cases[0]["data"]),
            False, extra_args=("unexpected",))

    report = {
        "python": sys.version,
        "checker": candidate_path.name,
        "checker_sha256": hashlib.sha256(candidate_path.read_bytes()).hexdigest(),
        "oracle_sha256": hashlib.sha256((ROOT / "validation/oracle.py").read_bytes()).hexdigest(),
        "seed": SEED,
        "rule_and_formation_fixtures": len(cases),
        "expected_accepts": sum(c["expected"] for c in cases),
        "expected_rejects": sum(not c["expected"] for c in cases),
        "named_substitution_comparisons": substitution_count,
        "literal_substitution_anchors": len(anchors),
        "public_cli_runs": len(cli_records),
        "optimized_cli_runs": sum(c["optimized"] for c in cli_records),
        "accepted_fixture_rule_visits": dict(coverage),
        "rule_results": records,
        "cli_results": cli_records,
        "failures": failures,
        "passed": not failures,
        "limits": (
            "Finite deterministic tests, not a Lean/Rocq proof or exhaustive "
            "enumeration. The rule oracle is separately implemented; named "
            "substitution is adapted from an attributed independent draft "
            "oracle. Counts overlap: public CLI runs replay labeled fixtures. "
            "The candidate was tested with finite JSON values and available "
            "machine resources. The demand companion is audited separately."
        ),
    }
    results = ROOT / "results"
    results.mkdir(exist_ok=True)
    (results / "audit.json").write_text(json.dumps(report, indent=2) + "\n")
    (results / "audit_cases.json").write_text(json.dumps(cases, indent=2) + "\n")
    summary = {key: report[key] for key in (
        "passed", "rule_and_formation_fixtures", "expected_accepts",
        "expected_rejects", "named_substitution_comparisons",
        "literal_substitution_anchors", "public_cli_runs", "optimized_cli_runs")}
    print(json.dumps(summary, indent=2))
    if failures:
        print(json.dumps(failures[:10], indent=2))
        raise SystemExit(1)
    return report


if __name__ == "__main__":
    main()
