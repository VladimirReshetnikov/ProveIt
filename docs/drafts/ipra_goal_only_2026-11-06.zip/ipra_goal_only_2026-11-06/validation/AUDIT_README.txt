INDEPENDENT STRICT-CHECKER AUDIT

Run from any directory:

    python3 validation/audit.py

An optional argument selects another strict checker with the same public
signature. The default is ../checker.py. This test code is not imported by
either candidate and does not participate in accepting user proofs.

oracle.py has an explicit independent syntax validator and a direct rule
interpreter. Its substitution implementation converts de Bruijn indices to
unique named binders, substitutes named free variables, and reconstructs
indices. It calls no candidate helper and does not use the candidate's scope
table or cutoff-substitution algorithm. The named representation is adapted,
with attribution in the source, from the supplied goal-calculus draft.

The deterministic suite contains:

- 148 labeled rule and formation cases: 28 accepted and 120 rejected.
- 2304 substitution comparisons against the named-variable implementation,
  including logical binders, nested recursion, two-variable updates, sparse
  free parameters, and external cutoffs 0, 1, and 3.
- Four literal substitution anchors with hand-written expected outputs.
- 186 actual public CLI runs, including all labeled fixtures, malformed JSON,
  input and command-line arity, and 30 checks with optimized Python.

Cases cover all rule branches and their certificate arities, equation
induction versus compound numerical cases, retained-context lifting,
existential eigenvariable escape, malformed unused assumptions, strict
rejection of invalid vacuous universal witnesses, false-major hypothesis
fallback, and Boolean/floating-point syntax aliases.

The ordinary rule comparisons, actual CLI runs, and optimized runs overlap;
their counts are not counts of independent mathematical theorems.

results/audit.json records the candidate and oracle SHA-256 hashes, runtime,
deterministic seed, every labeled verdict, CLI verdicts, and failures.
results/audit_cases.json stores the generated fixtures. Re-running the suite
overwrites those evidence files with fresh results.

All checks passed for the recorded checker hash. These are finite tests, not
an exhaustive certificate search or a Lean/Rocq formalization. Universal
soundness, completeness, and bi-interpretability are addressed by the paper.
The optional demand companion has a separate demand_checks.py audit.
