"""Reproduce the complete offline evidence and update report measurements."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def write_numbers(metrics):
    rows = {row['source']: row for row in metrics['candidates']}
    names = [('ast_nodes', 'AST'), ('source_tokens', 'SourceTokens'),
             ('normalized_tokens', 'NormTokens'), ('normalized_bytes', 'NormBytes')]
    lines = []
    for filename, prefix in [('checker.py', 'New'), ('checker_demand.py', 'Demand')]:
        for field, name in names:
            lines.append('\\newcommand{\\' + prefix + name + '}{'
                         + format(rows[filename][field], ',') + '}')
    (ROOT / 'sections/numbers.tex').write_text('\n'.join(lines) + '\n')


def main():
    for script in ['comparison/measure.py', 'validation/translate_auto.py',
                   'validation/audit.py', 'validation/demand_checks.py']:
        subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)
    metrics = json.loads((ROOT / 'results/metrics.json').read_text())
    write_numbers(metrics)
    audit = json.loads((ROOT / 'results/audit.json').read_text())
    if not audit['passed']:
        raise ValueError('Independent audit failed')
    primary = ('source_tokens', 'normalized_tokens', 'ast_nodes', 'normalized_bytes')
    for row in metrics['candidates']:
        if not all(row[field] < metrics['baseline_envelope'][field] for field in primary):
            raise ValueError('Candidate no longer beats the recorded frontier')
    summary = {
        'passed': True,
        'python': sys.version,
        'baseline_sources': len(metrics['baselines']),
        'candidates': [{key: row[key] for key in ('source', *primary)}
                       for row in metrics['candidates']],
        'independent_audit': {key: audit[key] for key in (
            'rule_and_formation_fixtures', 'named_substitution_comparisons',
            'literal_substitution_anchors', 'public_cli_runs')},
        'limits': 'Finite tests supplement the written proof; no Lean/Rocq metatheory verification.',
    }
    (ROOT / 'results/reproduction.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
