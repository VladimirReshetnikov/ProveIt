"""Complete direct-recursion iPRA certificate checker.

The same node-level scope traversal is used as in checker.py. The two
update slots bind the previous counter and previous state separately;
computation therefore opens the counter before opening the state.
"""
import json, sys
k = 0


def inst(a, t=None, d=0):
    try:
        return [inst(b, t, d + (4, (1, [])[d % 2], 2)[-len(a)]) for b in a + []]
    except:
        return a if k <= a < d else inst(t, d=1)


def check(a, g):
    global k
    if inst(a) in g:
        return True
    match take():
        case [m, t] if check(m, g):
            if not m[2:]:
                if not m[1:]:
                    t, m = m[0], [0, t]
                return inst(t, m[1]) == a and check(inst(t, m[0]), g)
            h = [m[2:]]
        case []:
            (n, t, r), b = a
            if n:
                n, = n
                t = inst(inst(r, n, 3), [n, t, r], 1)
            return b == t
        case t:
            a = inst(a[2], t, 2)
            h = [a, inst(a, 0)][len(a) % 2:]
    k -= 1
    return check(inst(a, [k]), g + [inst(c, k) for c in h])


try:
    take = json.load(open(sys.argv[1])).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)