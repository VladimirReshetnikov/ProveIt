#!/usr/bin/env python3
"""Regenerate measurements, finite validation evidence, and the PDF."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
for relative in ['measure.py', 'validation/run.py', 'validation/check_low_ast.py', 'build.py']:
    subprocess.run([sys.executable, str(root / relative)], cwd=root, check=True)
