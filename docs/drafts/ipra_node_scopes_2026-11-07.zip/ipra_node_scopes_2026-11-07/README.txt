ONE SCOPE INCREMENT PER NODE: iPRA
================================
Prepared for Vladimir Reshetnikov, 7 November 2026.

RESULT
The primary complete scalar checker measures 348 normalized Python tokens,
373 AST nodes, and 978 normalized bytes. The actual current minimum among
the eleven root checkers in the six supplied drafts is 356/378/1038.
The improvement survives an identical filename-based public driver.

The new contribution removes repeated per-child scope descriptors and zip:
each constructor gives all children the same increment. Empty syntax is
conservatively interpreted as numerical zero or formula truth. The arithmetic
and logical foundation is inherited and explicitly attributed.

The theory is full first-order intuitionistic primitive recursive arithmetic
up to a faithful native presentation and ordinary whole-domain
bi-interpretation. Both internal composite isomorphisms use x=y.
This is not merely an equational-fragment consistency result.

START HERE
  report.pdf                 Complete mathematical paper.
  report.tex                 Main LaTeX source.
  foundation/                Included self-contained mathematical foundation.
  sections/                  New construction, proof, comparisons and evidence.
  checker.py                 Primary scalar proof checker: 348/373/978.
  checker_low_ast.py         Alternate scalar checker: 349/371/996.
  checker_direct.py          Full recursion companion: 355/379/990.
  FORMAT.txt                 Short packet-format reference.
  results/                   Exact measurements and finite validation receipts.
  comparison/current/        Eleven frozen, unmodified root baseline checkers.
  source_snapshot.json       Immutable Git commit and six archive identities.
  validation/                Independent oracle, fixtures and executable checks.
  package.py                 Clean deterministic ZIP and checksum-manifest builder.
  SHA256SUMS.txt              SHA-256 checksums of every other delivered file.
  ATTRIBUTION.txt            Inherited versus new contributions.

RUN
  python3 checker.py examples/zero_computation.json
  python3 checker.py examples/false_computation.json

An accepted packet prints ACCEPT and exits 0; rejection prints REJECT and
exits 1. Certificates are JSON data, never executable code. The checker
imports only the Python standard-library json and sys modules.

REPRODUCE
  python3 measure.py
  python3 validation/run.py
  python3 validation/check_low_ast.py
  python3 build.py
or:
  python3 reproduce.py

All numerical measurements include the entire program and use the unchanged
inherited normalization. Python 3.10+ is needed for match statements;
CPython 3.12.14 produced the supplied measurements and validation receipts.
The Python support uses only the standard library. PDF compilation requires
pdfLaTeX and the ordinary packages named in report.tex. No network is needed.

To check the delivered files, run from the extracted directory:
  sha256sum -c SHA256SUMS.txt
To regenerate a clean ZIP after any intentional changes:
  python3 package.py
The package script excludes Python caches and LaTeX build intermediates.

STATUS
Written mathematical proofs of soundness, canonical completeness, and both
interpretation composites; finite implementation checks with zero failures.
No Lean/Rocq mechanization of the full metatheory or Python implementation.
No absolute minimality theorem or worldwide-priority claim.

The direct companion improves every coordinate of the current full-recursion
subgroup minimum (363/384/1050). Relative to the current scalar frontier it
improves tokens and bytes but has one extra AST node; the paper states this.

Pinned baseline commit:
  df8beb801d9f3e3eb3a8141722953fb58e63009e
  https://github.com/VladimirReshetnikov/ProveIt/tree/df8beb801d9f3e3eb3a8141722953fb58e63009e/docs/drafts
