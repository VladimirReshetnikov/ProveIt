#!/usr/bin/env python3
"""Compile the self-contained mathematical report with pdfLaTeX."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
subprocess.run([sys.executable, str(root / 'measure.py')], cwd=root, check=True,
               stdout=subprocess.DEVNULL)
for _ in range(3):
    completed = subprocess.run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
                                '-file-line-error', 'report.tex'], cwd=root,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if completed.returncode:
        print(completed.stdout[-15000:])
        raise SystemExit(completed.returncode)
print(root / 'report.pdf')
