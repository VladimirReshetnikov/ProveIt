#!/usr/bin/env python3
"""Package the deliverable, excluding caches and LaTeX build intermediates."""
from pathlib import Path
import hashlib
import json
import zipfile


def main():
    root = Path(__file__).resolve().parent
    checksum_path = root / 'SHA256SUMS.txt'
    excluded_suffixes = {'.aux', '.log', '.out', '.toc', '.pyc', '.pyo', '.zip'}
    files = sorted(
        path for path in root.rglob('*')
        if path.is_file() and path != checksum_path
        and '__pycache__' not in path.parts
        and not any(part.startswith('.') for part in path.relative_to(root).parts)
        and path.suffix not in excluded_suffixes
    )
    checksum_path.write_text(''.join(
        hashlib.sha256(path.read_bytes()).hexdigest()
        + '  ' + path.relative_to(root).as_posix() + '\n'
        for path in files
    ), encoding='utf-8')
    files = sorted(files + [checksum_path])
    target = root.parent / (root.name + '.zip')
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in files:
            name = root.name + '/' + path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 7, 12, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(target) as archive:
        damaged = archive.testzip()
        if damaged is not None:
            raise RuntimeError('ZIP verification failed: ' + damaged)
    print(json.dumps({
        'archive': str(target),
        'files': len(files),
        'bytes': target.stat().st_size,
        'sha256': hashlib.sha256(target.read_bytes()).hexdigest()
    }, indent=2))


if __name__ == '__main__':
    main()
