#!/usr/bin/env python3
"""Reproduce complete-program sizes without executing any measured source."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import tempfile

ROOT = Path(__file__).resolve().parent
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
spec = importlib.util.spec_from_file_location('source_metric', ROOT / 'comparison/source_measure.py')
metric = importlib.util.module_from_spec(spec)
spec.loader.exec_module(metric)

DRIVER = '''try:
    take = json.load(open(sys.argv[1])).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
'''


def common_driver(path, directory):
    tree = ast.parse(path.read_text())
    if not isinstance(tree.body[-1], ast.Try):
        raise ValueError('Expected final public driver: ' + str(path))
    tree.body[-1:] = ast.parse(DRIVER).body
    result = directory / path.name
    result.write_text(ast.unparse(tree) + '\n')
    return metric.metrics(result)


def tex_row(label, row):
    return label + ' & ' + ' & '.join(format(row[x], ',') for x in FIELDS) + ' ' + chr(92) * 2 + '\n'


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    rows = []
    with tempfile.TemporaryDirectory() as directory:
        temporary = Path(directory)
        for entry in manifest['programs']:
            path = ROOT / 'comparison' / entry['local_file']
            measured = metric.metrics(path)
            if measured['sha256'] != entry['sha256']:
                raise ValueError('Frozen source changed: ' + str(path))
            rows.append({**entry, 'delivered': measured,
                         'common_filename_driver': common_driver(path, temporary)})
        candidates = []
        for name in ['checker.py', 'checker_low_ast.py', 'checker_direct.py']:
            path = ROOT / name
            candidates.append({'file': name, 'delivered': metric.metrics(path),
                               'common_filename_driver': common_driver(path, temporary)})
    minimum = {kind: {field: min(row[kind][field] for row in rows) for field in FIELDS}
               for kind in ['delivered', 'common_filename_driver']}
    direct = [r for r in rows if r['label'].endswith(('checker_full.py', 'checker_direct.py'))]
    direct_minimum = {field: min(row['delivered'][field] for row in direct) for field in FIELDS}
    result = {'commit': manifest['commit'], 'python': platform.python_version(),
              'implementation': platform.python_implementation(),
              'metric_sha256': hashlib.sha256((ROOT / 'comparison/source_measure.py').read_bytes()).hexdigest(),
              'boundary': 'Entire project-specific program, including imports and public driver.',
              'normalization': 'Remove genuine docstrings; ast.unparse plus final newline; significant tokens; all ast.walk nodes including contexts; UTF-8 bytes.',
              'archive_count': len(manifest['archives']), 'root_checker_count': len(rows),
              'minimum': minimum, 'full_recursion_subgroup_minimum': direct_minimum,
              'programs': rows, 'candidates': candidates}
    result['primary_strictly_below_current_envelope'] = {
        kind: {field: candidates[0][kind][field] < minimum[kind][field] for field in FIELDS}
        for kind in minimum}
    if not all(all(v.values()) for v in result['primary_strictly_below_current_envelope'].values()):
        raise AssertionError('The claimed strict comparison does not hold.')
    out = ROOT / 'results'
    out.mkdir(exist_ok=True)
    (out / 'measurements.json').write_text(json.dumps(result, indent=2) + '\n')
    lines = []
    names = {'checker.py':'Primary scalar', 'checker_low_ast.py':'Scalar with fewer AST nodes',
             'checker_direct.py':'Direct recursion companion'}
    for row in candidates:
        lines.append(tex_row(names[row['file']], row['delivered']))
    (out / 'candidate_rows.tex').write_text(''.join(lines))
    lines = []
    for row in rows:
        label = row['label'].replace('ipra_', '').replace('_2026-11-07', '').replace('_', r'\_')
        lines.append(tex_row(r'\texttt{' + label + '}', row['delivered']))
    (out / 'baseline_rows.tex').write_text(''.join(lines))
    macros = []
    for prefix, data in [('New', candidates[0]['delivered']), ('Old', minimum['delivered'])]:
        for suffix, field in [('Tokens','normalized_tokens'), ('Nodes','ast_nodes'), ('Bytes','normalized_bytes')]:
            macros.append('\\newcommand{\\' + prefix + suffix + '}{' + format(data[field], ',') + '}')
    (out / 'numbers.tex').write_text('\n'.join(macros) + '\n')
    bs = chr(92)
    def table(header, rows, small=False):
        return (bs + 'begin{center}' + (bs + 'small' if small else '') + '\n' +
                bs + 'begin{tabular}{@{}lrrr@{}}\n' + bs + 'toprule\n' +
                header + ' ' + bs*2 + '\n' + bs + 'midrule\n' + rows +
                bs + 'bottomrule\n' + bs + 'end{tabular}\n' + bs + 'end{center}\n')
    (out / 'candidate_table.tex').write_text(table(
        'Complete program & Tokens & AST nodes & Bytes',
        tex_row('Current coordinatewise minimum', minimum['delivered']) +
        (out / 'candidate_rows.tex').read_text()))
    (out / 'baseline_table.tex').write_text(table(
        'Root checker & Tokens & AST nodes & Bytes',
        (out / 'baseline_rows.tex').read_text(), small=True))

    print(json.dumps({k:v for k,v in result.items() if k not in ['programs']}, indent=2))


if __name__ == '__main__':
    main()
