#!/usr/bin/env python3
"""Validate the optional direct-recursion checker, including staged opening."""
import ast
from copy import deepcopy
import json
import math
from pathlib import Path
import random
import types

from run import (Audit, HERE, ROOT, SEED, digest, finite_aliases,
                      numerical_tree, numerical_value, save, trace)


def simultaneous(body, state, counter, protected=0):
    """Independent capture-avoiding opening of two distinguished outer slots."""
    if isinstance(body, (int, float)):
        if body < 1:
            return body
        index = math.floor((body - 1) / 2)
        if index < protected:
            return body
        if index == protected:
            return deepcopy(state)
        if index == protected + 1:
            return deepcopy(counter)
        raise ValueError('unbound coordinate in simultaneous opening')
    if not isinstance(body, list):
        raise ValueError('numerical type')
    if len(body) == 0:
        return []
    if len(body) == 1:
        return [simultaneous(body[0], state, counter, protected + 1)]
    if len(body) == 3:
        return [simultaneous(child, state, counter, protected + 2)
                for child in body]
    raise ValueError('numerical arity')


def stage_checks(audit):
    rng = random.Random(SEED + 550)
    rigid = {-3: 2, -2: 1, -1: 3}
    compared = 0
    evaluated = 0
    skips = 0
    for index in range(3000):
        predecessor = numerical_tree(rng, 2, 0, True)
        initial = numerical_tree(rng, 2, 2, True)
        update = numerical_tree(rng, 3, 2, True)
        if index % 2:
            predecessor = finite_aliases(predecessor, rng)
            initial = finite_aliases(initial, rng)
            update = finite_aliases(update, rng)
        state = [predecessor, initial, update]
        audit.module.k = -3
        try:
            audit.module.inst(predecessor, d=1)
            audit.module.inst(state, d=1)
            staged = audit.module.inst(audit.module.inst(update, predecessor, 3), state, 1)
            together = simultaneous(update, state, predecessor)
            audit.module.inst(staged, d=1)
        except Exception as exc:
            audit.failure('staged opening exception', (index, type(exc).__name__))
            continue
        compared += 1
        if staged != together:
            audit.failure('staged versus simultaneous opening',
                          (index, update, state, predecessor, staged, together))
        try:
            state_value = numerical_value(state, rigid=rigid, width=2)
            counter_value = numerical_value(predecessor, rigid=rigid, width=2)
            expected = numerical_value(update, (state_value, counter_value), rigid, 2)
            actual = numerical_value(staged, rigid=rigid, width=2)
        except OverflowError:
            skips += 1
            continue
        except Exception as exc:
            audit.failure('staged denotation exception', (index, type(exc).__name__))
            continue
        evaluated += 1
        if expected != actual:
            audit.failure('staged denotation', (index, expected, actual))
    return {'attempts': 3000, 'raw_simultaneous_comparisons': compared,
            'decoded_semantic_comparisons': evaluated, 'budget_skips': skips,
            'floating_alias_attempts': 1500, 'rigid_parameters': rigid,
            'random_seed': SEED + 550,
            'simultaneous_implementation': 'An explicit two-slot structural substitution, independent of inst.'}


def mutant(source, replacement):
    before = 't = inst(inst(r, n, 3), [n, t, r], 1)'
    if source.count(before) != 1:
        raise ValueError('mutation location')
    tree = ast.parse(source.replace(before, replacement))
    body = []
    for node in tree.body:
        if isinstance(node, ast.Try):
            break
        body.append(node)
    module = types.ModuleType('incorrect_opening_control')
    exec(compile(ast.Module(body=body, type_ignores=[]), '<mutation control>', 'exec'),
         module.__dict__)
    return module


def mutation_controls(audit):
    source = audit.checker.read_text()
    controls = [
        ('counter_opening_must_protect_state',
         't = inst(inst(r, n, 1), [n, t, r], 1)',
         [[], [[[0], [0], 1], 0]]),
        ('state_and_counter_are_distinct',
         't = inst(r, [n, t, r], 1)',
         [[], [[[0], [0], 3], [0, [0], 3]]]),
    ]
    result = []
    for name, replacement, packet in controls:
        correct = trace(audit.module, packet)[0]
        incorrect = trace(mutant(source, replacement), packet)[0]
        left, right = packet[-1]
        values = [numerical_value(left, width=2), numerical_value(right, width=2)]
        if correct or not incorrect or values[0] == values[1]:
            audit.failure('mutation control', (name, correct, incorrect, values))
        result.append({'name': name, 'correct_accepts': correct,
                       'mutant_accepts': incorrect, 'false_equation_values': values,
                       'packet': packet})
    return result

