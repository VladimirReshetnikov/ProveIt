#!/usr/bin/env python3
"""Targeted agreement and CLI checks for the optional scalar low-AST variant."""
import json
import platform
from pathlib import Path
from run import (Audit, HERE, ROOT, digest, nonfinite_hole_packets, save)


def main():
    fixture = HERE / 'positive_certificates.json'
    records = json.loads(fixture.read_text())['records']
    examples = json.loads((HERE / 'examples.json').read_text())
    cases = json.loads((HERE / 'new_cases.json').read_text())
    selected = [r for r in examples + cases if r.get('width', 1) == 1]
    audit = Audit(ROOT / 'checker_low_ast.py', width=1)
    audit.packets(records, selected)
    for name, packet in nonfinite_hole_packets():
        audit.packet(json.loads(packet), name, True)
    opening = audit.openings()
    cli = audit.public_cli(records[:5], [r for r in cases if r.get('width', 1) == 1])
    receipt = {
        'status': 'PASS' if not audit.failures else 'FAIL',
        'python_version': platform.python_version(),
        'checker': {'path': 'checker_low_ast.py', 'sha256': digest(audit.checker)},
        'runner_sha256': digest(Path(__file__)),
        'oracle_sha256': digest(HERE / 'oracle_empty.py'),
        'packet_counts': dict(audit.counts),
        'packet_comparisons': sum(audit.counts.values()),
        'accepted_packets': audit.accepted,
        'accepted_rule_counts': dict(audit.rules),
        'opening_agreement': opening,
        'public_cli': cli,
        'failures': audit.failures,
        'scope': 'Finite agreement checks for an alternate branch arrangement; not a metatheory proof.'
    }
    save(ROOT / 'results' / 'low_ast_validation.json', receipt)
    print(json.dumps({k: receipt[k] for k in ('status', 'packet_comparisons', 'public_cli', 'failures')}, indent=2))
    if audit.failures:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
