NODE-WISE KERNEL VALIDATION
==========================

Run from any working directory:
    python3 validation/run.py
    python3 validation/check_low_ast.py
Or give an explicit package root as the sole positional argument. The package
root must contain checker.py and checker_direct.py. Results are written to
results/scalar_validation.json, results/direct_validation.json, and
results/validation_summary.json. The optional low-AST check writes
results/low_ast_validation.json. Only the Python standard library is used.

Trust boundary
--------------
The production kernels import none of these files. The named-rule oracle
uses separate term/formula methods, explicit binders, and named inference
rules. It shares neither the packed depth arithmetic nor the short dispatch
implementation. It has been adapted explicitly for empty-array terms, empty
truth formulas, zero counts, and the harmless empty truth hypothesis. The
finite numerical evaluator independently interprets dummy binders and the
direct counter/state distinction. It uses explicit work limits; skipped
evaluations are counted. They do not affect proof acceptance.

Evidence
--------
The fixtures contain 147 scalar and 55 direct canonical positive certificates,
with hashes and preserved upstream provenance. Existing examples are bundled
as one JSON file. New cases exercise empty syntax, scope erasure, binary
numerical rejection, unused images, and a formula-hole transport attack.
The runner performs deterministic packet mutations, malformed/random trees,
opening comparison over fractional boundaries and fresh-name floors, decoded
substitution, numerical computation evaluation, and false-conclusion probes.
It invokes the actual CLI on positive, negative, malformed, and nonfinite
JSON cases under both ordinary Python and python -O.

NaN and infinities are tested as parser extensions, not as arithmetic values.
They cannot survive closed numerical validation. Out-of-scope nonfinite labels
may act as anonymous holes in templates when a valid replacement is supplied.

Direct recursion has additional independently defined simultaneous two-slot
substitution tests and two mutation controls. Those controls deliberately
certify false equations when counter/state protections are broken, and must
be rejected by the delivered checker.

Every reported count is finite implementation evidence. This suite does not
prove the metatheorems of soundness, completeness, consistency, or
bi-interpretability. Source attribution and exact inherited file hashes are
in ATTRIBUTION.txt and source_provenance.json; MIT-0 is preserved.
