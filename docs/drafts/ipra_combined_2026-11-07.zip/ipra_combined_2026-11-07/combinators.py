"""Optional, untrusted proof-level SK compiler.

An Atom is an opaque name for an arbitrary native arithmetic formula, including
one with quantifiers. Arrow is the *derived* implication of the report. None of
these proof objects is an arithmetic term, and this module adds no arithmetic
application function, axiom, or trusted checker instruction.

The output is a typed derived proof plan. It is NOT a native certificate stream
for checker.py. ``expand`` removes K and S again, producing an ordinary
implicational natural-deduction derivation. Such a derivation can be elaborated
using the report's proved implication macros; this module does not implement
that final native elaboration. The acceptance kernel never imports this file.

Run ``python3 combinators.py`` for reproducible demonstrations and self-checks.
Only the Python standard library is used.
"""
from dataclasses import dataclass
import json


@dataclass(frozen=True)
class Atom:
    label: str


@dataclass(frozen=True)
class Arrow:
    left: object
    right: object


@dataclass(frozen=True)
class Var:
    name: str
    formula: object


@dataclass(frozen=True)
class App:
    function: object
    argument: object


@dataclass(frozen=True)
class Lam:
    name: str
    formula: object
    body: object


@dataclass(frozen=True)
class K:
    a: object
    b: object


@dataclass(frozen=True)
class S:
    a: object
    b: object
    c: object


def formula_is_valid(a):
    if isinstance(a, Atom):
        return type(a.label) is str and bool(a.label)
    if isinstance(a, Arrow):
        return formula_is_valid(a.left) and formula_is_valid(a.right)
    return False


def merge_contexts(left, right):
    result = dict(left)
    for name, formula in right.items():
        if name in result and result[name] != formula:
            raise TypeError("One free assumption name has incompatible types")
        result[name] = formula
    return result


def infer(proof):
    """Return (formula, free assumptions); reject ill-typed source or SK plans."""
    if isinstance(proof, Var):
        if type(proof.name) is not str or not formula_is_valid(proof.formula):
            raise TypeError("Malformed assumption")
        return proof.formula, {proof.name: proof.formula}
    if isinstance(proof, K):
        if not all(map(formula_is_valid, (proof.a, proof.b))):
            raise TypeError("Malformed K instance")
        return Arrow(proof.a, Arrow(proof.b, proof.a)), {}
    if isinstance(proof, S):
        a, b, c = proof.a, proof.b, proof.c
        if not all(map(formula_is_valid, (a, b, c))):
            raise TypeError("Malformed S instance")
        return Arrow(Arrow(a, Arrow(b, c)),
                     Arrow(Arrow(a, b), Arrow(a, c))), {}
    if isinstance(proof, App):
        function_type, left_context = infer(proof.function)
        argument_type, right_context = infer(proof.argument)
        if not isinstance(function_type, Arrow):
            raise TypeError("Application requires an implication")
        if function_type.left != argument_type:
            raise TypeError("Application has a mismatched premise")
        return function_type.right, merge_contexts(left_context, right_context)
    if isinstance(proof, Lam):
        if type(proof.name) is not str or not formula_is_valid(proof.formula):
            raise TypeError("Malformed discharged assumption")
        conclusion, context = infer(proof.body)
        if proof.name in context and context[proof.name] != proof.formula:
            raise TypeError("Discharged assumption has the wrong type")
        return Arrow(proof.formula, conclusion), {
            name: a for name, a in context.items() if name != proof.name
        }
    raise TypeError("Unknown proof constructor")


def identity(a):
    """I_A = S_{A,A->A,A} K_{A,A->A} K_{A,A}; no primitive I."""
    aa = Arrow(a, a)
    return App(App(S(a, aa, a), K(a, aa)), K(a, a))


def is_sk(proof):
    if isinstance(proof, (Var, K, S)):
        return True
    return isinstance(proof, App) and is_sk(proof.function) and is_sk(proof.argument)


def abstract(name, a, proof):
    """Curry bracket abstraction [name:A]proof on a typed SK proof plan."""
    if not is_sk(proof):
        raise TypeError("Bracket abstraction expects an SK plan without lambdas")
    b, context = infer(proof)
    if name in context and context[name] != a:
        raise TypeError("Abstraction changes an assumption's type")
    if isinstance(proof, Var) and proof.name == name:
        return identity(a)
    if name not in context:
        return App(K(b, a), proof)
    if not isinstance(proof, App):
        raise TypeError("Unexpected open primitive combinator")
    c, _ = infer(proof.argument)
    return App(App(S(a, c, b), abstract(name, a, proof.function)),
               abstract(name, a, proof.argument))


def compile_sk(proof):
    """Eliminate all proof lambdas, including nested shadowing, by recursion."""
    source_type, source_context = infer(proof)
    if isinstance(proof, Lam):
        result = abstract(proof.name, proof.formula, compile_sk(proof.body))
    elif isinstance(proof, App):
        result = App(compile_sk(proof.function), compile_sk(proof.argument))
    else:
        result = proof
    if infer(result) != (source_type, source_context):
        raise AssertionError("Internal compiler error: type or context changed")
    return result


def expand(proof):
    """Expand derived K/S axioms to ordinary ->I/->E (Lam/App) proof trees.

    Bound names in each closed K/S definition are local. They cannot capture
    assumptions of an argument: App does not substitute into its function.
    """
    if isinstance(proof, K):
        return Lam("k.x", proof.a,
                   Lam("k.y", proof.b, Var("k.x", proof.a)))
    if isinstance(proof, S):
        a, b, c = proof.a, proof.b, proof.c
        f = Var("s.f", Arrow(a, Arrow(b, c)))
        g = Var("s.g", Arrow(a, b))
        x = Var("s.x", a)
        return Lam("s.f", f.formula,
                   Lam("s.g", g.formula,
                       Lam("s.x", a, App(App(f, x), App(g, x)))))
    if isinstance(proof, App):
        return App(expand(proof.function), expand(proof.argument))
    if isinstance(proof, Var):
        return proof
    raise TypeError("Expand expects an SK plan")


def node_count(proof):
    if isinstance(proof, App):
        return 1 + node_count(proof.function) + node_count(proof.argument)
    if isinstance(proof, Lam):
        return 1 + node_count(proof.body)
    return 1


def encode(value):
    """JSON-ready, fully annotated data (readable; no trust or size claim)."""
    if isinstance(value, Atom):
        return value.label
    if isinstance(value, Arrow):
        return ["implies", encode(value.left), encode(value.right)]
    if isinstance(value, Var):
        return ["assumption", value.name, encode(value.formula)]
    if isinstance(value, App):
        return ["apply", encode(value.function), encode(value.argument)]
    if isinstance(value, Lam):
        return ["discharge", value.name, encode(value.formula), encode(value.body)]
    if isinstance(value, K):
        return ["K", encode(value.a), encode(value.b)]
    if isinstance(value, S):
        return ["S", encode(value.a), encode(value.b), encode(value.c)]
    raise TypeError("Unknown object")


def demonstrations():
    a, b, c = map(Atom, ("A", "B", "C"))
    x, y = Var("x", a), Var("y", b)
    f, g = Var("f", Arrow(b, c)), Var("g", Arrow(a, b))
    h = Var("h", Arrow(a, Arrow(a, b)))
    examples = {
        "identity": Lam("x", a, x),
        "weakening": Lam("x", a, Lam("y", b, x)),
        "composition": Lam("f", f.formula,
                           Lam("g", g.formula,
                               Lam("x", a, App(f, App(g, x))))),
        "contraction": Lam("h", h.formula,
                           Lam("x", a, App(App(h, x), x))),
        "open_proof": Lam("x", a, App(g, x)),
        "shadowing": Lam("x", a, Lam("x", b, Var("x", b))),
    }
    report = []
    for name, source in examples.items():
        target = compile_sk(source)
        assert is_sk(target)
        assert infer(target) == infer(source) == infer(expand(target))
        formula, context = infer(target)
        report.append({
            "example": name,
            "formula": encode(formula),
            "free_assumptions": {k: encode(v) for k, v in context.items()},
            "source_nodes": node_count(source),
            "sk_nodes": node_count(target),
            "expanded_nodes": node_count(expand(target)),
            "typed_sk_plan": encode(target),
        })
    rejected = 0
    for malformed in (App(x, y), App(g, y), Lam("x", b, x),
                      App(Var("z", Arrow(a, a)), Var("z", a))):
        try:
            infer(malformed)
        except TypeError:
            rejected += 1
        else:
            raise AssertionError("An ill-typed proof was accepted")
    return {"role": "untrusted derived proof plans, not native certificates",
            "positive_examples": report, "negative_checks_passed": rejected}


if __name__ == "__main__":
    print(json.dumps(demonstrations(), indent=2))
