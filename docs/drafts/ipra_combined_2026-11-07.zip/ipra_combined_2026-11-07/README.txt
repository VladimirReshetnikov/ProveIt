COMBINING LOGICAL FUSION AND SUCCESSOR ABSORPTION IN iPRA
======================================================
7 November 2026

Start with report.pdf. Its editable sources are report.tex and sections/*.tex.

RESULT
------
One numerical recursor, with successor defined from it; two logical binders;
five inference patterns and two computation schemas. The report gives explicit
whole-domain bi-interpretations with intuitionistic primitive recursive
arithmetic, including internal term and formula round trips.

The complete checker has 415 normalized tokens, 431 AST nodes, and 1223
normalized bytes. The current supplied corpus has coordinatewise minima of
427, 436, and 1246. Diagnostic core counts also strictly improve: 356/368/973
against 367/373/979. Measurements use the unchanged upstream metric under
CPython 3.12.14, with all 10 root programs and 2 published alternatives frozen.

This is a strict improvement over a specified finite corpus, not a proof of
global minimality. Logical fusion and successor absorption are explicitly
credited to the supplied drafts. The contribution is their proven combination,
the smaller complete implementation, and its reproducible proof-transport audit.

QUICK START (OFFLINE)
--------------------
Use Python 3.12.14 to reproduce the exact reported source measurements.
The checker itself requires Python 3.10 or later; all Python uses the standard
library. From this directory:

  python3 reproduce.py

This checks the archive and frozen sources, measures the current corpus,
transports 45 closed proofs, runs the independent named rule oracle, verifies
31 boundary packets and 152 real command-line verdicts, compares 3726 opening
cases, exercises three targeted defect controls, and repeats 392 numerical
comparisons. It regenerates results/metrics.json, verification.json, and
numerical.json and the emitted examples.

For an individual proof packet:

  python3 checker.py examples/derived_reflexivity.json

Expected output: ACCEPT, exit status 0. An intentional negative control:

  python3 checker.py examples/false_equality.json

Expected output: REJECT, exit status 1.

To rebuild the PDF with LaTeX installed:

  python3 build.py

The LaTeX packages include amsmath, amssymb, amsthm, mathtools, lmodern,
microtype, geometry, booktabs, longtable, array, xcolor, listings, fancyhdr,
hyperref, and xurl. A private setup fallback handles unconfigured Debian TeX Live
installations without network access. A rebuilt PDF can have a different
hash because of build metadata; run the delivered integrity check before
rebuilding or modifying files. The original SHA256SUMS.txt intentionally
identifies the files as delivered rather than a later edited version.

CONTENTS
--------
report.pdf; report.tex; sections/   Paper and complete editable LaTeX sources.
checker.py                       Entire trusted project acceptance boundary.
FORMAT.txt                       Exact sorted JSON certificate contract.
measure.py                       Size comparison using the frozen routine.
comparison/                      12 unchanged programs, metric, source hashes.
validation/                      Untrusted proof compiler and independent audit.
examples/                        45 emitted proofs and 31 boundary packets.
results/                         Detailed metrics, verdicts, and numerical data.
reproduce.py                     Offline audit entry point.
build.py                         PDF build entry point.
ATTRIBUTION.txt                   Provenance and scope of the contribution.
LICENSE_SOURCE.txt               Original MIT-0 source/documentation license.
SHA256SUMS.txt                    Integrity hashes of delivered files.

MATHEMATICAL CONVENTIONS
------------------------
The successor-initialized recursor has A(0,a;h)=sigma(a), not a.
The decoder delta(n)=A(n,0;u,v.v) has delta(0)=1 and delta(sigma(n))=n.
The genuine truncated predecessor is a different derived term.
Equation induction is permitted only when the matrix itself is an equation;
an equation nested under a logical binder is a compound formula.
Canonical Q syntax is [B,B,B]; D syntax is [B]. Soundness covers all accepted
padding, but theorem-completeness is asserted for canonical encodings.

Finite testing is not a formal verification of Python or of the metatheory.
The report gives the mathematical proofs separately and states the limits
of the size and novelty claims. All supplied proof roots are already closed;
none is silently specialized to zero to pass the public interface.

SOURCE SNAPSHOT
---------------
https://github.com/VladimirReshetnikov/ProveIt/tree/5c4724e5550a1b19347ac62c9b02857a7e3fbd19/docs/drafts

Exact checker SHA-256:
4fd903803c4bd1aa057ecf68c03f4191b0412c50c07343d0394a52642e87075c
