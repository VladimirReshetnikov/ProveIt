A SMALLER COMPLETE PRESENTATION OF iPRA
Fixed-variable closure, arity syntax, and proof combinators
Prepared for Vladimir Reshetnikov, 7 November 2026 (Pacific time)

MAIN RESULT

The complete checker has 473 normalized significant Python tokens, 480 AST
nodes, and 1,443 normalized UTF-8 bytes. These are strictly below the respective
483 / 491 / 1,462 coordinatewise minima of all nine primary checkers in the six
current ProveIt draft archives at commit:

    c5f42a50d9213259760ee385977481c04dccab28

The uniformly isolated core is 413 / 415 / 1,182 versus 423 / 425 / 1,200.
Measurements use CPython 3.12.14 and an identical boundary for every program.
This is a modest strict finite-corpus improvement, not an absolute-minimality
theorem. The underlying arithmetic and logic and the component reductions are
inherited and credited. The new result integrates the compatible reductions
into one smaller complete standalone acceptance program.

MATHEMATICAL GUARANTEE

The report specifies all primitive syntax, logical rules, and arithmetic
schemas; proves the fixed-variable simulation; reconstructs full intuitionistic
first-order logic and quantifier-free induction; and establishes ordinary
whole-domain bi-interpretability with iPRA. Both composite isomorphisms are
defined by x=y, internally also at nonstandard recursion counters.

The target iPRA convention is stated explicitly. Bare atomic induction without
numerical coverage is not silently identified with it. The ordinary first-order
realization includes an explicit falsity bridge 0=S0 -> bottom.

The mathematical metatheorems are not formalized in Lean or Rocq. Executable
checks support the implementation correspondence; they are not replacements
for the mathematical proofs.

COMBINATORS

Typed proof-level K and S are derived constructors for the reconstructed
implication. combinators.py implements bracket abstraction; combinators_native.py
expands such plans through the attributed native logical proof builders.
K, S, and SK-derived I were compiled to actual accepted kernel certificates.
No new trusted axiom or number-level application operation is added.

A primitive-recursive total numerical evaluator representing every unary
primitive-recursive function is impossible by diagonalization. The report
states the exact scope of that obstruction, without ruling out partial,
typed, or other-domain combinatory approaches.

QUICK START

    python3 checker.py examples/reflexivity_zero.json
    python3 checker.py examples/combinator_k.json
    python3 checker.py examples/combinator_s.json
    python3 checker.py examples/combinator_i.json
    python3 reproduce.py
    python3 build.py

The checker prints ACCEPT or REJECT. It imports only json and sys. The complete
public format is in FORMAT.txt. Numerical coordinates are not numeral values:
1 is a variable coordinate, while arithmetic one is [0].

FILES

report.pdf, report.tex, sections/   Complete paper and LaTeX sources
checker.py                         Entire trusted acceptance program
FORMAT.txt                         Exact syntax and certificate contract
examples/                          Representative actual target certificates
measure.py, comparison/            All nine unchanged baselines and provenance
combinators.py                     Optional untrusted typed SK front end
combinators_native.py              Optional native logical elaboration bridge
combinator_sources/                Native source proof trees for K, S, SKK
validation/                        Independent named oracle, compiler, fixtures
results/                           Recomputed measurement and validation records
reproduce.py                       Offline executable reproduction
build.py                           Rebuild the PDF with pdfLaTeX
package.py                         Rebuild clean archive and file hashes
LICENSE_SOURCE.txt                 Preserved source license (MIT-0)
MANIFEST.sha256                    Final delivered file hashes

EVIDENCE

992 source derivations passed (989 inherited entries plus K/S/I), comprising
491 theorem checks with empty logical context and 501 explicit open-sequent
checks. Also passed: 134 focused fixtures, 456 named-substitution comparisons,
1,015 accepted-stack extractions rechecked as unrestricted source proofs, and
224 real CLI runs (112 normal, 112 under -O). Failures: zero.

The independent target interpreter retains existential padding in syntactic
equality. Padding is erased only after successful target checking, during
extraction to the reference calculus. This distinction is tested explicitly.
The validation source corpus and proof builders are inherited, attributed
support and are never imported by the acceptance program.

REPRODUCIBILITY

The checker needs Python 3.10+. Exact ast.unparse metrics should be compared
under the recorded Python version. Offline reproduction needs only the Python
standard library. Building report.pdf needs a normal pdfLaTeX installation.
Very large valid proofs can exceed implementation recursion or memory limits.
All source hashes and the precise checker hash are recorded in results.

Source repository: https://github.com/VladimirReshetnikov/ProveIt
Snapshot directory:
https://github.com/VladimirReshetnikov/ProveIt/tree/c5f42a50d9213259760ee385977481c04dccab28/docs/drafts
