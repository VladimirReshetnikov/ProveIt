"""Write final checksums and a deterministic clean ZIP archive."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent


def files():
    return sorted(path for path in ROOT.rglob('*')
                  if path.is_file() and not any(part in ('build', '__pycache__')
                                               for part in path.relative_to(ROOT).parts)
                  and path.suffix != '.pyc' and path.name != 'MANIFEST.sha256')


def main():
    manifest = ROOT / 'MANIFEST.sha256'
    manifest.write_text(''.join(hashlib.sha256(path.read_bytes()).hexdigest() + '  '
                                + path.relative_to(ROOT).as_posix() + '\n' for path in files()))
    destination = ROOT.parent / 'output'
    destination.mkdir(exist_ok=True)
    archive = destination / (ROOT.name + '.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for path in files() + [manifest]:
            info = zipfile.ZipInfo(ROOT.name + '/' + path.relative_to(ROOT).as_posix(),
                                   date_time=(2026, 11, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            output.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED,
                            compresslevel=9)
    print(str(archive))


if __name__ == '__main__':
    main()
