"""Reproduce the complete current-corpus comparison without importing a checker."""
import hashlib
import importlib.util
import json
from pathlib import Path
import platform

ROOT = Path(__file__).resolve().parent
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def main():
    spec = importlib.util.spec_from_file_location(
        'source_measure', ROOT / 'comparison' / 'sources' / 'measure.py')
    counter = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(counter)
    snapshot = json.loads((ROOT / 'comparison' / 'snapshot.json').read_text())
    rows = []
    for entry in snapshot['rows']:
        path = ROOT / entry['file']
        result = counter.metrics(path)
        if result['sha256'] != entry['sha256']:
            raise ValueError('Comparison source changed: ' + entry['file'])
        rows.append({**entry, **result})
    if len(rows) != 9 or len(snapshot['archives']) != 6:
        raise ValueError('The pinned corpus must contain six archives and nine programs')
    minimum = {key: min(row[key] for row in rows) for key in KEYS}
    core_minimum = {key: min(row['core'][key] for row in rows) for key in KEYS}
    candidate = counter.metrics(ROOT / 'checker.py')
    smaller = {key: candidate[key] < minimum[key] for key in KEYS}
    core_smaller = {key: candidate['core'][key] < core_minimum[key] for key in KEYS}
    if not all(smaller.values()) or not all(core_smaller.values()):
        raise ValueError('Candidate does not strictly beat the entire coordinatewise frontier')
    result = {'python': platform.python_version(), 'implementation': platform.python_implementation(),
              'commit': snapshot['commit'], 'archive_count': 6, 'program_count': 9,
              'minima': minimum, 'core_minima': core_minimum, 'candidate': candidate,
              'strict_improvement': smaller, 'core_strict_improvement': core_smaller,
              'minimum_attainers': {key: [row['archive_member'] for row in rows
                                          if row[key] == minimum[key]] for key in KEYS},
              'programs': rows}
    results = ROOT / 'results'
    results.mkdir(exist_ok=True)
    (results / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    macros = {
        'KernelTokens': candidate['normalized_tokens'], 'KernelAST': candidate['ast_nodes'],
        'KernelBytes': candidate['normalized_bytes'],
        'BaselineTokens': minimum['normalized_tokens'], 'BaselineAST': minimum['ast_nodes'],
        'BaselineBytes': minimum['normalized_bytes'],
        'CoreTokens': candidate['core']['normalized_tokens'], 'CoreAST': candidate['core']['ast_nodes'],
        'CoreBytes': candidate['core']['normalized_bytes'],
        'BaselineCoreTokens': core_minimum['normalized_tokens'],
        'BaselineCoreAST': core_minimum['ast_nodes'], 'BaselineCoreBytes': core_minimum['normalized_bytes'],
    }
    for name, key in zip(('TokenReduction', 'ASTReduction', 'ByteReduction'), KEYS):
        macros[name] = f'{100 * (minimum[key] - candidate[key]) / minimum[key]:.2f}'
    (results / 'numbers.tex').write_text(''.join(
        '\\newcommand{\\' + name + '}{' + str(value) + '}\n' for name, value in macros.items()))
    lines = [r'\begin{center}\small', r'\begin{tabular}{lrrrrrr}', r'\toprule',
             r'& \multicolumn{3}{c}{Complete program} & \multicolumn{3}{c}{Core}\\',
             r'Program & Tokens & AST & Bytes & Tokens & AST & Bytes\\', r'\midrule']
    for row in rows:
        label = row['archive'].removeprefix('ipra_').removesuffix('_2026-11-06.zip').replace('_', ' ')
        if 'checker_demand' in row['archive_member']:
            label += ' (demand)'
        elif label in ('arity', 'direct stream', 'fresh parameters'):
            label += ' (strict)'
        values = [row[key] for key in KEYS] + [row['core'][key] for key in KEYS]
        lines.append(label + ' & ' + ' & '.join(map(str, values)) + r'\\')
    lines += [r'\midrule', 'Coordinatewise minimum & ' + ' & '.join(map(str,
              [minimum[k] for k in KEYS] + [core_minimum[k] for k in KEYS])) + r'\\',
              'Proposed checker & ' + ' & '.join(map(str,
              [candidate[k] for k in KEYS] + [candidate['core'][k] for k in KEYS])) + r'\\',
              r'\bottomrule', r'\end{tabular}\end{center}']
    (results / 'comparison_table.tex').write_text('\n'.join(lines) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'programs'}, indent=2))


if __name__ == '__main__':
    main()
