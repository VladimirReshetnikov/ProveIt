"""Reproduce full-program and diagnostic-core sizes against the frozen corpus."""
from pathlib import Path
import hashlib
import importlib.util
import json
import platform

ROOT=Path(__file__).resolve().parent
METRIC=ROOT/'comparison/source_measure.py'
manifest=json.loads((ROOT/'comparison/manifest.json').read_text())
if hashlib.sha256(METRIC.read_bytes()).hexdigest() != manifest['measurement_sha256']:
    raise ValueError('The frozen measurement function changed')
spec=importlib.util.spec_from_file_location('frozen_measure',METRIC)
metric=importlib.util.module_from_spec(spec);spec.loader.exec_module(metric)
rows=[]
for row in manifest['programs']:
    measured=metric.metrics(ROOT/'comparison'/row['local_file'])
    if measured['sha256'] != row['sha256']:
        raise ValueError('Comparator changed: '+row['local_file'])
    rows.append({**row,**measured})
keys=('normalized_tokens','ast_nodes','normalized_bytes')
minimum={k:min(r[k] for r in rows) for k in keys}
core={k:min(r['core'][k] for r in rows) for k in keys}
candidate=metric.metrics(ROOT/'checker.py')
result={'status':'PASS','python':platform.python_version(),'commit':manifest['commit'],
        'root_count':sum(r['category']=='root' for r in rows),'alternative_count':sum(r['category']!='root' for r in rows),
        'whole_program_envelope':minimum,'core_envelope':core,'candidate':candidate,
        'strict_whole_program_improvements':{k:candidate[k]<minimum[k] for k in keys},
        'strict_core_improvements':{k:candidate['core'][k]<core[k] for k in keys},
        'programs':rows}
if not all(result['strict_whole_program_improvements'].values()):
    raise ValueError('Candidate no longer beats every complete-program coordinate')
if not all(result['strict_core_improvements'].values()):
    raise ValueError('Candidate no longer beats every diagnostic-core coordinate')
(ROOT/'results').mkdir(exist_ok=True)
(ROOT/'results/metrics.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='programs'},indent=2))
