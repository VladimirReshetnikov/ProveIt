"""Rebuild all executable evidence offline; does not require LaTeX."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(*args, capture=None):
    result = subprocess.run([sys.executable, *map(str, args)], cwd=ROOT,
                            text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if capture:
        (ROOT / capture).write_text(result.stdout)
    if result.returncode:
        print(result.stdout)
        raise SystemExit(result.returncode)
    print('PASS:', args[0])
    return result.stdout


def main():
    results = ROOT / 'results'
    results.mkdir(exist_ok=True)
    run('measure.py', capture='results/measurement_run.txt')
    builders = ROOT / 'validation' / 'logic_builders'
    manifest = json.loads((builders / 'manifest.json').read_text())
    for row in manifest['files']:
        if hashlib.sha256((builders / row['local_file']).read_bytes()).hexdigest() != row['sha256']:
            raise ValueError('Frozen logic builder changed: ' + row['local_file'])
    run('combinators.py', capture='results/combinators.json')
    run('combinators_native.py', '--builders', builders, '--output', 'combinator_sources',
        '--examples', 'k', 's', 'i', capture='results/combinator_generation_run.txt')
    arguments = ['validation/run_validation.py', '--checker', ROOT / 'checker.py',
                 '--output', results / 'validation']
    for name in ('k', 's', 'i'):
        arguments += ['--source', ROOT / 'combinator_sources' / f'combinator_{name}_source.json']
    run(*arguments, capture='results/validation_run.txt')
    summary = json.loads((results / 'validation' / 'summary.json').read_text())
    actual_hash = hashlib.sha256((ROOT / 'checker.py').read_bytes()).hexdigest()
    if summary['status'] != 'PASS' or summary['checker_sha256'] != actual_hash or summary['failures']:
        raise ValueError('Validation does not match the delivered checker')
    examples = ROOT / 'examples'
    examples.mkdir(exist_ok=True)
    for source in (results / 'validation' / 'examples').glob('*.json'):
        shutil.copy2(source, examples / source.name.replace('_source', ''))
    print(json.dumps({key: summary[key] for key in
                      ('status', 'source_proofs_checked', 'source_theorems', 'source_open_sequents',
                       'targeted_fixtures', 'substitution_cases', 'real_cli_executions', 'failures')}, indent=2))


if __name__ == '__main__':
    main()
