"""Replay the complete offline audit; no third-party Python modules required."""
from pathlib import Path
import hashlib
import json
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
CHECKER_SHA256 = '4fd903803c4bd1aa057ecf68c03f4191b0412c50c07343d0394a52642e87075c'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    if sys.version_info < (3, 10):
        raise SystemExit('Python 3.10 or later is required; measurements were made on 3.12.14.')
    if digest(ROOT / 'checker.py') != CHECKER_SHA256:
        raise SystemExit('The measured checker has changed.')
    provenance = json.loads((ROOT / 'validation/source_provenance.json').read_text())
    for entry in provenance['files']:
        if digest(ROOT / entry['file']) != entry['sha256']:
            raise SystemExit('Frozen source changed: ' + entry['file'])
    integrity = ROOT / 'SHA256SUMS.txt'
    if integrity.exists():
        checked = 0
        for line in integrity.read_text().splitlines():
            expected, relative = line.split('  ', 1)
            path = ROOT / relative
            if not path.is_file() or digest(path) != expected:
                raise SystemExit('Archive integrity mismatch: ' + relative)
            checked += 1
        print(f'Archive integrity: {checked} files verified.', flush=True)
    print('Runtime: CPython ' + platform.python_version(), flush=True)
    if platform.python_version() != '3.12.14':
        print('Exact AST/unparse counts are pinned to CPython 3.12.14; this run records your version.', flush=True)
    for script in ('measure.py', 'validation/verify.py', 'validation/numerical.py'):
        print('\nRunning ' + script, flush=True)
        subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)
    measured = json.loads((ROOT / 'results/metrics.json').read_text())
    verified = json.loads((ROOT / 'results/verification.json').read_text())
    if verified['candidate_sha256'] != CHECKER_SHA256:
        raise SystemExit('The audit did not check the pinned source.')
    if measured['candidate']['sha256'] != CHECKER_SHA256:
        raise SystemExit('The measurement did not check the pinned source.')
    print('\nPASS: source identities, size comparison, proof transport, independent rule audit,')
    print('command-line verdicts, protected opening, defect controls, and numerical checks.')


if __name__ == '__main__':
    main()
