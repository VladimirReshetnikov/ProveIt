"""Pure syntax measurement; importing candidate/baseline checker code is unnecessary."""
import ast
import hashlib
import io
import json
from pathlib import Path
import sys
import tokenize

IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}

class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node
    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean

def significant(source):
    return sum(t.type not in IGNORED
               for t in tokenize.generate_tokens(io.StringIO(source).readline))

def tree_metrics(tree):
    normalized = ast.unparse(tree) + '\n'
    return {'normalized_tokens': significant(normalized),
            'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'normalized_bytes': len(normalized.encode('utf-8'))}

def metrics(path):
    raw = Path(path).read_bytes()
    tree = ast.fix_missing_locations(StripDocstrings().visit(ast.parse(raw.decode())))
    result = {'sha256': hashlib.sha256(raw).hexdigest(), 'raw_bytes': len(raw),
              'raw_significant_tokens': significant(raw.decode()), **tree_metrics(tree)}
    tree.body = [n for n in tree.body
                 if not isinstance(n, (ast.Import, ast.ImportFrom))
                 and not (isinstance(n, ast.If) and '__name__' in ast.unparse(n.test))]
    result['core'] = tree_metrics(tree)
    return result

if __name__ == '__main__':
    print(json.dumps({p: metrics(p) for p in sys.argv[1:]}, indent=2))
