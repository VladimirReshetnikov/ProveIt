"""Independent named-variable oracle for arity certificates.

Adapted from ProveIt's independently written named syntax model (MIT-0).
The candidate uses de Bruijn substitution and pattern dispatch. This oracle
uses sorted dataclasses, globally fresh binder names, named substitution,
alpha comparison, and an explicit instruction cursor. Existential padding
is validated AND retained in syntactic comparison/substitution. Accepted
certificates are extracted to the preceding unrestricted tagged calculus.
This module is not part of the acceptance program.
"""
from collections import Counter
from dataclasses import dataclass
from itertools import count


class Invalid(ValueError):
    pass


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Var:
    name: tuple


@dataclass(frozen=True)
class Succ:
    value: object


@dataclass(frozen=True)
class Rec:
    index: object
    initial: object
    accumulator: tuple
    predecessor: tuple
    step: object


@dataclass(frozen=True)
class Eq:
    left: object
    right: object


@dataclass(frozen=True)
class Q:
    variable: tuple
    body: object


@dataclass(frozen=True)
class Ex:
    variable: tuple
    body: object
    first_padding: object
    second_padding: object


def alpha(value, bound=()):
    if isinstance(value, Zero):
        return ('zero',)
    if isinstance(value, Var):
        return ('bound', bound.index(value.name)) if value.name in bound else ('free', value.name)
    if isinstance(value, Succ):
        return ('succ', alpha(value.value, bound))
    if isinstance(value, Rec):
        inner = (value.accumulator, value.predecessor) + bound
        return ('rec', alpha(value.index, bound), alpha(value.initial, bound), alpha(value.step, inner))
    if isinstance(value, Eq):
        return ('eq', alpha(value.left, bound), alpha(value.right, bound))
    if isinstance(value, Q):
        return ('q', alpha(value.body, (value.variable,) + bound))
    if isinstance(value, Ex):
        inner = (value.variable,) + bound
        return ('ex', alpha(value.body, inner), alpha(value.first_padding, inner),
                alpha(value.second_padding, inner))
    raise Invalid('Unknown sorted expression')


def same(left, right):
    return alpha(left) == alpha(right)


def replace(value, mapping):
    """Simultaneous named substitution; globally fresh names prevent capture."""
    if isinstance(value, Zero):
        return value
    if isinstance(value, Var):
        return mapping.get(value.name, value)
    if isinstance(value, Succ):
        return Succ(replace(value.value, mapping))
    if isinstance(value, Rec):
        inner = {name: term for name, term in mapping.items()
                 if name not in (value.accumulator, value.predecessor)}
        return Rec(replace(value.index, mapping), replace(value.initial, mapping),
                   value.accumulator, value.predecessor, replace(value.step, inner))
    if isinstance(value, Eq):
        return Eq(replace(value.left, mapping), replace(value.right, mapping))
    if isinstance(value, (Q, Ex)):
        inner = {name: term for name, term in mapping.items() if name != value.variable}
        body = replace(value.body, inner)
        if isinstance(value, Q):
            return Q(value.variable, body)
        return Ex(value.variable, body, replace(value.first_padding, inner),
                  replace(value.second_padding, inner))
    raise Invalid('Unknown sorted expression')


def instantiate(binder, term):
    return replace(binder.body, {binder.variable: term})


def free_names(value):
    if isinstance(value, Var):
        return {value.name} if value.name[0] == 'free' else set()
    if isinstance(value, Zero):
        return set()
    if isinstance(value, Succ):
        return free_names(value.value)
    if isinstance(value, Rec):
        return free_names(value.index) | free_names(value.initial) | free_names(value.step)
    if isinstance(value, Eq):
        return free_names(value.left) | free_names(value.right)
    if isinstance(value, Q):
        return free_names(value.body)
    if isinstance(value, Ex):
        return free_names(value.body) | free_names(value.first_padding) | free_names(value.second_padding)
    raise Invalid('Unknown sorted expression')


def render(value, local=()):
    if isinstance(value, Zero):
        return 0
    if isinstance(value, Var):
        if value.name in local:
            return 1 + local.index(value.name)
        kind, index = value.name
        if kind == 'rigid':
            return index
        if kind == 'free' and index >= 0:
            return len(local) + index + 1
        raise Invalid('Escaped eigenvariable or invalid coordinate')
    if isinstance(value, Succ):
        return [render(value.value, local)]
    if isinstance(value, Rec):
        inner = (value.accumulator, value.predecessor) + local
        return [render(value.index, local), render(value.initial, local), render(value.step, inner)]
    if isinstance(value, Eq):
        return [render(value.left, local), render(value.right, local)]
    if isinstance(value, Q):
        return [render(value.body, (value.variable,) + local)]
    if isinstance(value, Ex):
        inner = (value.variable,) + local
        return [render(value.body, inner), render(value.first_padding, inner),
                render(value.second_padding, inner)]
    raise Invalid('Unknown sorted expression')


def source_term(data):
    if type(data) is int:
        return data
    if len(data) == 1:
        return ['s', source_term(data[0])]
    if len(data) == 3:
        return ['r', *(source_term(item) for item in data)]
    raise Invalid('Invalid source-erasure term')


def source_formula(data):
    if len(data) == 1:
        return ['q', source_formula(data[0])]
    if len(data) == 2:
        return ['=', source_term(data[0]), source_term(data[1])]
    if len(data) == 3:
        return ['ex', source_formula(data[0])]
    raise Invalid('Invalid source-erasure formula')


class Oracle:
    def __init__(self, stack=()):
        self.counter = count()
        self.stack = stack
        self.cursor = len(stack)
        self.events = Counter()
        self.discarded_major_attempts = 0

    def fresh(self, kind='bound'):
        return (kind, next(self.counter))

    def term(self, data, local=()):
        if type(data) is int:
            if data == 0:
                return Zero()
            if data < 0:
                return Var(('rigid', data))
            if data <= len(local):
                return Var(local[data - 1])
            return Var(('free', data - len(local) - 1))
        if type(data) is not list:
            raise Invalid('Expected a numerical term')
        if len(data) == 1:
            return Succ(self.term(data[0], local))
        if len(data) == 3:
            accumulator, predecessor = self.fresh(), self.fresh()
            return Rec(self.term(data[0], local), self.term(data[1], local),
                       accumulator, predecessor,
                       self.term(data[2], (accumulator, predecessor) + local))
        raise Invalid('Wrong numerical constructor arity')

    def formula(self, data, local=()):
        if type(data) is not list:
            raise Invalid('Expected a formula')
        if len(data) == 2:
            return Eq(self.term(data[0], local), self.term(data[1], local))
        if len(data) == 1:
            variable = self.fresh()
            return Q(variable, self.formula(data[0], (variable,) + local))
        if len(data) == 3:
            variable = self.fresh()
            inner = (variable,) + local
            return Ex(variable, *(self.formula(part, inner) for part in data))
        raise Invalid('Wrong formula constructor arity')

    def instruction(self):
        if type(self.stack) is not list or self.cursor == 0:
            raise Invalid('Missing instruction')
        self.cursor -= 1
        return self.stack[self.cursor]

    def derive(self, goal, context=(), local=()):
        cell = self.instruction()
        # This clause deliberately precedes the introduction clauses. The
        # candidate proves a displayed major before interpreting its annotation.
        if type(cell) is list and len(cell) == 2:
            raw_major, annotation = cell
            major = self.formula(raw_major, local)
            established, major_tree = self.derive(major, context, local)
            if established:
                if isinstance(major, Ex):
                    self.events['exists_E'] += 1
                    eigen = self.fresh('eigen')
                    success, child = self.derive(
                        goal, [*context, instantiate(major, Var(eigen))], (eigen,) + local)
                    return success, [source_formula(raw_major), major_tree, child]
                if isinstance(major, Q):
                    self.events['Q_E_fixed'] += 1
                    premise = instantiate(major, Zero())
                    conclusion = instantiate(major, self.term(1, local))
                    source_annotation = 1
                elif isinstance(major, Eq):
                    self.events['equality_E'] += 1
                    hole = self.fresh('template')
                    motive = self.formula(annotation, (hole,) + local)
                    premise = replace(motive, {hole: major.left})
                    conclusion = replace(motive, {hole: major.right})
                    source_annotation = source_formula(annotation)
                else:
                    raise Invalid('Unknown major formula')
                if not same(goal, conclusion):
                    return False, None
                success, child = self.derive(premise, context, local)
                return success, [source_formula(raw_major), major_tree, source_annotation, child]
            self.discarded_major_attempts += 1

        if isinstance(goal, Q) and cell == []:
            self.events['equation_QI' if isinstance(goal.body, Eq) else 'compound_QI'] += 1
            eigen = self.fresh('eigen')
            assumptions = [*context, instantiate(goal, Zero())]
            if isinstance(goal.body, Eq):
                assumptions.append(instantiate(goal, Var(eigen)))
            step = instantiate(goal, Succ(Var(eigen)))
            success, child = self.derive(step, assumptions, (eigen,) + local)
            return success, [child]

        if isinstance(goal, Ex) and type(cell) is list and len(cell) == 1:
            self.events['exists_I'] += 1
            witness = self.term(cell[0], local)
            eigen = self.fresh('eigen')
            success, child = self.derive(
                instantiate(goal, Var(eigen)), [*context, Eq(Var(eigen), witness)],
                (eigen,) + local)
            return success, [source_term(cell[0]), child]

        if isinstance(goal, Eq) and isinstance(goal.left, Rec) and cell == []:
            recursive = goal.left
            if isinstance(recursive.index, Zero):
                self.events['R0'] += 1
                result = recursive.initial
            elif isinstance(recursive.index, Succ):
                self.events['RS'] += 1
                predecessor = recursive.index.value
                previous = Rec(predecessor, recursive.initial, recursive.accumulator,
                               recursive.predecessor, recursive.step)
                result = replace(recursive.step, {recursive.accumulator: previous,
                                                   recursive.predecessor: predecessor})
            else:
                raise Invalid('Selected computation requires zero or successor')
            return same(goal.right, result), 'r'

        self.events['hypothesis'] += 1
        return any(same(goal, item) for item in context), None


def analyze(goal, stack, context=()):
    oracle = None
    try:
        if type(stack) is not list:
            raise Invalid('Certificate stack must be a list')
        oracle = Oracle(stack)
        parsed = oracle.formula(goal)
        assumptions = [oracle.formula(item) for item in context]
        accepted, tree = oracle.derive(parsed, assumptions)
        return {'accepted': accepted, 'tree': tree if accepted else None,
                'remaining': oracle.cursor, 'events': dict(oracle.events),
                'discarded_major_attempts': oracle.discarded_major_attempts, 'error': None}
    except Exception as error:
        return {'accepted': False, 'tree': None,
                'remaining': oracle.cursor if oracle is not None else None,
                'events': dict(oracle.events) if oracle is not None else {},
                'discarded_major_attempts': oracle.discarded_major_attempts if oracle else 0,
                'error': type(error).__name__ + ': ' + str(error)}


def accept_document(document):
    if type(document) is not list or not document:
        return False
    return analyze(document[-1], document[:-1])['accepted']


def substitution(data, env=(1,), depth=0, formula=True):
    """Offset-first substitution computed with names, not de Bruijn recursion."""
    oracle = Oracle()
    local = tuple(('protected', i) for i in range(depth))
    expression = (oracle.formula if formula else oracle.term)(data, local)
    images = [oracle.term(term) for term in env[1:]]
    offset = env[0]
    if type(offset) is not int or offset < -len(images):
        raise Invalid('Unsafe substitution tail')
    mapping = {name: images[name[1]] if name[1] < len(images)
               else Var(('free', name[1] + offset))
               for name in free_names(expression)}
    return render(replace(expression, mapping), local)
