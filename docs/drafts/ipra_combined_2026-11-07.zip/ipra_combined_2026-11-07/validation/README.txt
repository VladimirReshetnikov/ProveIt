INTEGRATED iPRA CHECKER — VALIDATION AND UNTRUSTED COMPILER

This directory is a self-contained validation package. The acceptance program
must not import any file from it. Its contents are intentionally larger and more
readable than the small kernel. They are outside the reported checker size.

FILES

compile_transport.py
    compile_source(goal, tree) returns the public arity-format certificate:
    end-popped proof instructions followed by the claimed formula. It accepts
    q-tagged or u-tagged source proof trees, performs the existing well-founded
    arbitrary-specialization simulation, and then changes representation.

    Command-line usage:
        python3 compile_transport.py source_proof.json certificate.json
    The source document is [goal, tree]. The emitted document has one stream.

named_arity.py
    Independent sorted named-variable interpreter for target certificates.
    Terms and formulas are dataclasses; binders receive fresh names; substitution
    is ordinary simultaneous named substitution. The oracle retains all three
    existential formula fields in parsing, substitution, and alpha comparison.
    It does not erase padding before checking the target proof. It extracts each
    accepted target stream to the preceding unrestricted source calculus, where
    the logically irrelevant padding is removed.

run_validation.py
    Rebuilds the inherited source corpus, transports all source proofs, compares
    candidate and named-oracle outcomes, verifies every accepted extraction in
    the source calculus, tests targeted malformed/capture/scope cases, compares
    substitution against named substitution, and exercises the real CLI both
    normally and under Python -O. All source and reference hashes are verified.

    Usage from any directory:
        python3 run_validation.py --checker /path/to/checker.py --output /path/to/results

    Additional q-tagged source proofs may be supplied repeatedly:
        python3 run_validation.py --checker /path/to/checker.py \
            --source /path/to/combinator_k_source.json \
            --source /path/to/combinator_s_source.json \
            --source /path/to/combinator_i_source.json

frozen/
    Unmodified files from the fixed-variable ProveIt archive. The manifest gives
    exact original members and SHA-256 hashes. They include the source compiler,
    syntax model, source proof checker, source example builders, and source data.

results/
    Reproducible JSON result tables and representative public certificates.
    summary.json records the exact candidate hash and Python version.

WHAT IS TESTED

The deterministic source corpus covers all native inference patterns, actual
equation induction, retained-base use, compound numerical cases, arbitrary-term
specialization, existential scopes, equality transport beneath binders, and
ordinary logic encodings. Scope wrappers and rigid-parameter transformations
exercise source-to-target compilation through nested binders. Optional K/S/I
examples demonstrate untrusted proof combinators compiled into ordinary proofs.

Targeted negative fixtures check malformed active syntax and padding, bool/float
confusion with integers, strict vacuous witnesses, fixed-coordinate elimination,
forbidden induction hypotheses for quantified matrices, eigenvariable escape,
wrong recursor accumulator/predecessor/parameter coordinates, and missing premises.

Additional fixtures verify the exact failed-major fallback behavior: a proved
major with an invalid motive fails; a malformed major fails; a well-formed major
whose proof returns false may fall back to an already available hypothesis after
consuming its attempted instructions. Successful fallback proofs are extracted
as hypotheses. Unused prefix instructions are permitted by the public format.

The substitution comparison protects zero, bound coordinates, and negative rigid
parameters, and checks all live environment forms with nested recursor updates,
formula binders, and both padding fields. The named implementation shares neither
the compact substitution routine nor the candidate's dispatch mechanism.

LIMITATIONS

These finite tests do not establish the universal soundness, completeness,
bi-interpretability, or minimality theorems. The written mathematical proof bears
those obligations. Compilation and reference interpretation are untrusted tools;
all delivered certificates must be passed to the standalone acceptance program.
CPython recursion, memory, and JSON-parser limits can reject very large valid
proofs. Open-sequent tests concern internal rule implementation; the public CLI
starts with an empty assumption context. Free numerical parameters in a public
theorem are schematic and do not count as logical assumptions.

ATTRIBUTION

Repository: https://github.com/VladimirReshetnikov/ProveIt
Snapshot: c5f42a50d9213259760ee385977481c04dccab28
Archive: docs/drafts/ipra_fixed_variable_2026-11-06.zip

The original fixed-variable compiler, source examples, named reference machinery,
and validation corpus are preserved under frozen/. The complete source license
is frozen/LICENSE_SOURCE.txt (MIT No Attribution License, 2026 ProveIt Contributors).
The new transport adapter, padded named oracle, fixtures, and runner are based on
that openly supplied work and are distributed under the same terms. Their use is
reported explicitly so inherited corpus volume is not misrepresented as newly
invented mathematical or verification content.
