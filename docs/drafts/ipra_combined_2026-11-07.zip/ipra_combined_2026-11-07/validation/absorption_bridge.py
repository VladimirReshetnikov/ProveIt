"""Untrusted proof compiler combining the supplied fusion and absorption proofs.

The imported source compiler creates named Q/D proof trees using ordinary
recursion. This module translates every numerical recursion to decoded
successor-initialized recursion, replacing each computation axiom by a
seven-node proof. The final serializer gives D unary syntax and Q ternary
syntax. The tiny acceptance program imports none of this code.
"""
from copy import deepcopy
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
SUPPORT = HERE / 'support'
sys.path.insert(0, str(SUPPORT))
import translate as tr


def p(t):
    u,v=tr.fresh(),tr.fresh()
    return tr.R(t,0,u,v,v)


def term(t):
    if t == 0 or isinstance(t,str):
        return t
    if t[0] == 's':
        return tr.S(term(t[1]))
    _,n,a,u,v,h=t
    update=tr.st(term(h),u,p(u))
    return p(tr.R(term(n),term(a),u,v,tr.S(update)))


def formula(a):
    if a[0] == '=':
        return tr.Eq(term(a[1]),term(a[2]))
    if a[0] == 'q':
        return tr.Q(a[1],formula(a[2]))
    if a[0] == 'd':
        return tr.D(a[1],a[2],formula(a[3]))
    raise ValueError('Unexpected uncompiled source formula')


def reflexivity(t):
    x=tr.fresh()
    c=tr.comp(p(tr.S(t)),t)
    return tr.eq_elim(c,x,tr.Eq(x,t),c)


def symmetry(e):
    x=tr.fresh()
    return tr.eq_elim(e,x,tr.Eq(x,e.goal[1]),reflexivity(e.goal[1]))


def compile_proof(proof):
    wanted=formula(proof.goal)
    rule=proof.rule
    if rule == 'hyp':
        return tr.hyp(wanted)
    if rule == 'compute':
        encoded,right=wanted[1:]
        inner=encoded[1]
        first=tr.comp(inner,tr.S(right))
        second=tr.comp(p(tr.S(right)),right)
        x=tr.fresh()
        result=tr.eq_elim(symmetry(first),x,tr.Eq(p(x),right),second)
    elif rule == 'eq_elim':
        x,matrix=proof.data
        result=tr.eq_elim(compile_proof(proof.children[0]),x,formula(matrix),
                          compile_proof(proof.children[1]))
    elif rule == 'q_elim':
        result=tr.q_elim(compile_proof(proof.children[0]),term(proof.data[0]),
                         compile_proof(proof.children[1]))
    elif rule == 'd_intro':
        witness,eigen=proof.data
        result=tr.d_intro(wanted,term(witness),eigen,compile_proof(proof.children[0]))
    elif rule == 'd_elim':
        result=tr.d_elim(compile_proof(proof.children[0]),proof.data[0],
                         compile_proof(proof.children[1]))
    else:
        raise ValueError('Unexpected proof rule ' + rule)
    tr.require(tr.same(result.goal,wanted),'Compiled conclusion mismatch')
    return result


def raw_formula(a,scope,bound=()):
    if a[0] == '=':
        return [tr.raw_term(a[1],scope,bound),tr.raw_term(a[2],scope,bound)]
    if a[0] == 'q':
        return [raw_formula(a[2],scope,(a[1],)+bound)]*3
    if a[0] == 'd':
        return [raw_formula(a[3],scope,(a[2],a[1])+bound)]
    raise ValueError('Unexpected formula')


def emit(proof):
    # The inherited emitter refers to raw_formula through its module globals;
    # substitute the declared target syntax only while serializing this proof.
    original=tr.raw_formula
    tr.raw_formula=raw_formula
    try:
        emitter=tr.Emitter()
        packet=emitter.packet(proof)
        return packet,{'cells':len(packet)-1,'eigenparameters':-emitter.k,
                       'rules':emitter.rule_counts,'pruned':emitter.pruned}
    finally:
        tr.raw_formula=original


def source_proof(packet,source_path=None):
    source=tr.load_kernel(source_path or SUPPORT/'source_checker.py','source_for_combination')
    direct=tr.run_kernel(source,packet)
    tr.require(direct['accepted'],'Original checker rejects source packet')
    record=tr.SourceRecorder(source,packet,[])
    tree=record.check(record.goal,[])
    tr.require(tree.accepted and len(record.stream)==direct['remaining']
               and source.k==direct['final_k'],'Source execution/recorder mismatch')
    return tr.compile_source(tree,{}),direct


def transport(packet,source_path=None):
    proof,direct=source_proof(packet,source_path)
    result,stats=emit(compile_proof(proof))
    stats['source']=direct
    return result,stats
