"""Untrusted source-tree compiler for the integrated arity/stream checker.

The frozen compiler (ProveIt, MIT-0) proves arbitrary closure specializations
using the fixed-coordinate calculus. This adapter only changes representation.
Neither this file nor any frozen source is imported by the acceptance kernel.
"""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    'frozen_fixed_variable_compiler', ROOT / 'frozen' / 'compiler.py')
source_compiler = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source_compiler)


def term(data):
    if type(data) is int:
        return data
    tag, *children = data
    if tag == 's' and len(children) == 1:
        return [term(children[0])]
    if tag == 'r' and len(children) == 3:
        return [term(child) for child in children]
    raise ValueError('Invalid source numerical term')


def formula(data):
    tag, *children = data
    if tag == '=' and len(children) == 2:
        return [term(child) for child in children]
    if tag in ('q', 'u') and len(children) == 1:
        return [formula(children[0])]
    if tag == 'ex' and len(children) == 1:
        return [formula(children[0]), [0, 0], [0, 0]]
    raise ValueError('Invalid source formula')


def instruction(cell):
    if cell is None or cell == []:
        return deepcopy(cell)
    if type(cell) is list and len(cell) == 1:
        return [term(cell[0])]
    if type(cell) is list and len(cell) == 2:
        major, annotation = cell
        return [formula(major), formula(annotation) if major[0] == '=' else deepcopy(annotation)]
    # Non-matching data are harmless hypothesis selectors in a target stream.
    return deepcopy(cell)


def transport_stack(goal, stack, context=()):
    """Transport a well-formed tagged fixed-coordinate internal sequent."""
    return {'goal': formula(goal), 'stack': [instruction(cell) for cell in stack],
            'context': [formula(item) for item in context]}


def compile_sequent(goal, tree, context=()):
    """Compile an unrestricted source proof with its declared assumptions."""
    goal, tree, context = source_compiler.native([goal, tree, list(context)])
    return transport_stack(goal, source_compiler.compile_tree(goal, tree), context)


def compile_source(goal, tree):
    """Return the public document: proof cells followed by the claimed formula."""
    row = compile_sequent(goal, tree)
    return row['stack'] + [row['goal']]


if __name__ == '__main__':
    source, destination = map(Path, sys.argv[1:])
    goal, tree = json.loads(source.read_text())
    destination.write_text(json.dumps(compile_source(goal, tree), indent=2) + '\n')
