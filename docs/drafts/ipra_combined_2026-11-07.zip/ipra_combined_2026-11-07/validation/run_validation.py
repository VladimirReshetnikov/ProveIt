"""Finite, independently structured validation of the integrated checker.

The frozen compiler/test builders are untrusted support. The candidate is
compared with a named-variable oracle, and accepted stacks are independently
checked again as extracted unrestricted source proofs. This is executable
evidence, not a machine-checked proof of the general metatheorems.
"""
import argparse
from collections import Counter
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def verify_frozen():
    data = json.loads((ROOT / 'frozen' / 'frozen_manifest.json').read_text())
    for row in data['files']:
        path = ROOT / 'frozen' / row['file']
        if hashlib.sha256(path.read_bytes()).hexdigest() != row['sha256']:
            raise ValueError('Changed frozen source: ' + row['file'])
    return data


def kernel_result(kernel, goal, stack, context=()):
    try:
        goal, stack, context = deepcopy([goal, stack, list(context)])
        kernel.take = stack.pop
        return kernel.check(goal, context) is True, len(stack), None
    except Exception as error:
        return False, None, type(error).__name__ + ': ' + str(error)


def fixtures(compiler, legacy):
    rows = []

    def add(name, goal, stack, context=(), expected=False):
        rows.append({'name': name, 'goal': goal, 'stack': stack,
                     'context': list(context), 'expected': expected})

    E = lambda a, b: [a, b]
    S = lambda a: [a]
    R = lambda n, a, h: [n, a, h]
    Q = lambda a: [a]
    truth, false = E(0, 0), E(0, S(0))
    X = lambda a: [a, truth, truth]
    truth_stack = compiler.compile_source(['=', 0, 0], legacy.legacy.reflexivity(0))[:-1]

    # Fixed coordinate is the current variable, and never the numeral one.
    major = Q(E(1, 0))
    payloads = [0, 1, 2, -1, S(1), None, False, 0.0, {'junk': True}, ['malformed']]
    for i, payload in enumerate(payloads):
        stream = truth_stack + [None, [major, payload]]
        add('fixed_coordinate_payload_%02d' % i, E(1, 0), stream, [major], True)
        add('payload_cannot_select_other_variable_%02d' % i, E(2, 0), stream, [major])
        add('payload_cannot_select_numeral_one_%02d' % i, E(S(0), 0), stream, [major])
    add('fixed_coordinate_missing_base', E(1, 0), [None, None, [major, 0]], [major])
    add('fixed_coordinate_unproved_major', E(1, 0), truth_stack + [None, [major, 0]])

    existential = X(E(1, 0))
    stream = [None, None, [0], [existential, 0]]
    add('existential_eigenvariable_escape', E(1, 0), stream)
    add('existential_preserves_outer_parameter', E(1, 0), stream, [E(1, 0)], True)
    add('existential_witness_capture', X(E(1, 1)), [None, [1]])
    add('existential_witness_parameter', X(E(1, 2)), [None, [1]], expected=True)
    add('existential_rigid_witness', X(E(1, -7)), [None, [-7]], expected=True)

    selected = {
        'forbidden_quantified_induction_hypothesis', 'equation_rule_uses_retained_base',
        'equation_induction', 'equality_transport_beneath_binder',
        'equality_transport_missing_minor', 'equality_transport_wrong_orientation',
        'recursion_wrong_accumulator_coordinate', 'recursion_wrong_predecessor_coordinate',
        'recursion_wrong_outer_parameter_shift', 'recursion_outer_parameter_correct',
        'recursion_non_successor_variable', 'recursion_non_successor_recursive_index',
    }
    for row in legacy.legacy.fixtures():
        if row['name'] in selected:
            encoded = compiler.compile_sequent(row['goal'], row['proof'], row['context'])
            add('source_' + row['name'], encoded['goal'], encoded['stack'],
                encoded['context'], row['accepted'])

    # Formation checks must reject malformed active syntax, even in ignored
    # existential padding, a vacuous witness or an equality motive.
    malformed_terms = [False, True, 0.0, None, '0', [], [0, 0], [0, 0, 0, 0],
                       [[0, 0]], [[0, 0], 0, 0], {}, [truth, truth, truth]]
    for i, term in enumerate(malformed_terms):
        add('malformed_witness_%02d' % i, X(E(1, 0)), [None, [term]])
        add('malformed_vacuous_witness_%02d' % i, X(truth), truth_stack + [[term]])
    malformed_formulas = [False, True, 0, None, 'q', [], [0], [0, 0, 0],
                          [truth, truth, truth, truth], E(False, 0), E(0.0, 0), {},
                          [[0, 0, 0, 0]], [truth, False, truth]]
    for i, formula in enumerate(malformed_formulas):
        add('malformed_goal_%02d' % i, formula, [None])
        add('malformed_motive_%02d' % i, truth,
            truth_stack + truth_stack + [[truth, formula]])
        add('malformed_padding_%02d' % i, [E(1, 0), formula, truth], [None, [0]])

    # Well-formed padding has no truth requirement, but remains syntactically
    # significant. Erasing it before comparison would miss the next regression.
    variant = [E(1, 0), E(1, 2), Q(X(E(3, -9)))]
    add('arbitrary_well_formed_padding', variant, [None, [0]], expected=True)
    add('padding_not_erased_in_hypothesis', variant, [None], [existential])
    add('identical_padding_hypothesis', variant, [None], [variant], True)
    equality = E(1, 0)
    motive = [truth, E(2, 3), Q(E(2, 3))]
    # Independent compiler substitution is used only to prepare a true fixture;
    # the named oracle will perform its own substitution when checking it.
    import named_arity
    left = named_arity.substitution(motive, [-1, 1])
    right = named_arity.substitution(motive, [-1, 0])
    add('padding_substitution_under_equality', right, [None, None, [equality, motive]],
        [equality, left], True)
    add('padding_substitution_wrong_target', left, [None, None, [equality, motive]],
        [equality, left])

    # The failed-major guard consumes instructions before falling back to Hyp.
    add('failed_major_hypothesis_fallback', truth, [None, [false, None]], [truth], True)
    add('failed_major_does_not_invent_hypothesis', truth, [None, [false, None]])
    add('unproved_major_does_not_parse_motive', truth,
        [None, [false, {'ignored': True}]], [truth], True)
    add('malformed_major_cannot_fallback', truth, [[False, None]], [truth])
    add('proved_major_malformed_motive_cannot_fallback', truth,
        [None, [truth, False]], [truth])
    wrong_computation = E(R(0, 0, 0), S(0))
    add('wrong_selected_computation_cannot_fallback', wrong_computation, [[]], [wrong_computation])
    add('same_computation_formula_as_hypothesis', wrong_computation, [None], [wrong_computation], True)
    variable_computation = E(R(1, 0, 1), 0)
    add('invalid_selected_computation_cannot_fallback', variable_computation, [[]], [variable_computation])
    add('invalid_boolean_computation', E(R(0, False, 0), False), [[]])
    add('false_theorem', false, [None])
    add('distinct_free_parameters', E(1, 2), [None], [E(1, 1)])
    add('distinct_rigid_parameters', E(-1, -2), [None], [E(-1, -1)])
    add('rigid_is_not_a_coordinate', E(-1, 1), [None], [E(-1, -1)])
    add('missing_instruction', truth, [])
    return rows


def substitutions():
    truth = [0, 0]
    terms = [0, -7, 1, 2, 17, [1], [[2]], [1, 2, 3],
             [[1], 2, [3]], [1, 2, [2, 1, [3]]],
             [1, [2, 1, 4], [2, 3, [5]]], [2, -4, [3, 2, [5]]]]
    formulas = [[1, 2], [terms[-1], 3], [[1, 2]],
                [[1, 2], truth, truth], [[[1, 3], truth, truth]],
                [[[1, 3]], [[2, 3]], [[1, -7], [3, 4], truth]],
                [[terms[-2], 3], [2, 4], [[3, 5]]]]
    environments = [[1], [0], [2], [-1, 0], [-1, 1], [0, [1]],
                    [-2, [1, 2, [1]], 2], [2, -7, [2]]]
    for formula, data_set in ((False, terms), (True, formulas)):
        for data in data_set:
            for depth in (0, 1, 3):
                for env in environments:
                    yield data, env, depth, formula


def run(checker, output, extra_sources):
    frozen = verify_frozen()
    sys.path.insert(0, str(ROOT / 'frozen'))
    sys.path.insert(0, str(ROOT))
    import compile_transport as compiler
    import named_arity as named
    legacy = load('frozen_validation_support', ROOT / 'frozen' / 'validation.py')
    kernel = load('integrated_candidate', checker)
    output.mkdir(parents=True, exist_ok=True)
    examples = output / 'examples'
    examples.mkdir(exist_ok=True)
    failures, corpus_results, fixture_results, substitution_results, cli_records = [], [], [], [], []
    events = Counter()
    extraction_count = 0
    fallback_count = 0
    closed_corpus = 0

    def inspect(row, expected, canonical=False):
        nonlocal extraction_count, fallback_count
        goal, stack, context = row['goal'], row['stack'], row.get('context', [])
        actual, remaining, error = kernel_result(kernel, goal, stack, context)
        oracle = named.analyze(goal, stack, context)
        if actual != expected or actual != oracle['accepted']:
            failures.append({'kind': 'acceptance', 'name': row['name'],
                             'expected': expected, 'actual': actual,
                             'kernel_error': error, 'oracle': oracle})
        if actual and remaining != oracle['remaining']:
            failures.append({'kind': 'instruction_consumption', 'name': row['name'],
                             'actual': remaining, 'oracle': oracle['remaining']})
        if canonical and actual and remaining != 0:
            failures.append({'kind': 'unused_canonical_instruction', 'name': row['name']})
        if actual and oracle['accepted']:
            events.update(oracle['events'])
            fallback_count += oracle['discarded_major_attempts']
            accepted_source = legacy.named_source_accept(
                named.source_formula(goal), oracle['tree'],
                [named.source_formula(item) for item in context])
            if not accepted_source:
                failures.append({'kind': 'extracted_source_rejected', 'name': row['name']})
            extraction_count += 1
        return actual, remaining

    source_rows = legacy.source_corpus()
    for path in extra_sources:
        goal, proof = json.loads(path.read_text())
        source_rows.append({'name': path.stem, 'goal': goal, 'proof': proof, 'context': [],
                            'provenance': 'explicit additional source: ' + path.name})
    representative_names = {
        'reflexivity_zero', 'reflexivity_parameter', 'reflexivity_nested_recursion',
        'equation_induction', 'equation_induction_at_compound_term',
        'equation_rule_uses_retained_base', 'compound_numerical_cases',
        'universal_reflexivity', 'implication_symmetry', 'q_elimination_existential',
        'transport_through_existential', 'macro_induction_7',
    }
    for row in source_rows:
        if not legacy.named_source_accept(row['goal'], row['proof'], row['context']):
            failures.append({'kind': 'invalid_source_proof', 'name': row['name']})
            continue
        record = {'name': row['name'], **compiler.compile_sequent(
            row['goal'], row['proof'], row['context'])}
        actual, remaining = inspect(record, True, True)
        corpus_results.append({'name': row['name'], 'provenance': row['provenance'],
                               'accepted': actual, 'instructions': len(record['stack']),
                               'remaining': remaining, 'theorem': not record['context']})
        if not record['context']:
            closed_corpus += 1
            if row['name'] in representative_names or row['name'].startswith('combinator_'):
                document = record['stack'] + [record['goal']]
                (examples / (row['name'] + '.json')).write_text(json.dumps(document) + '\n')
                cli_records.append({'name': row['name'], 'document': document, 'expected': True})

    fixed = fixtures(compiler, legacy)
    for row in fixed:
        actual, remaining = inspect(row, row['expected'])
        fixture_results.append({'name': row['name'], 'expected': row['expected'],
                                'accepted': actual, 'remaining': remaining})
        if not row['context']:
            cli_records.append({'name': row['name'],
                                'document': row['stack'] + [row['goal']],
                                'expected': row['expected']})

    for index, (data, env, depth, formula) in enumerate(substitutions()):
        actual = kernel.subst(deepcopy(data), deepcopy(env), depth, formula)
        expected = named.substitution(data, env, depth, formula)
        success = actual == expected
        substitution_results.append({'case': index, 'formula': formula, 'depth': depth,
                                     'environment': env, 'pass': success})
        if not success:
            failures.append({'kind': 'substitution', 'case': index, 'input': data,
                             'environment': env, 'depth': depth,
                             'candidate': actual, 'named': expected})

    example = cli_records[0]['document']
    cli_records.extend([
        {'name': 'unused_prefix_allowed', 'document': [{'unread': True}, False, *example], 'expected': True},
        {'name': 'empty_document', 'document': [], 'expected': False},
        {'name': 'null_document', 'document': None, 'expected': False},
        {'name': 'mapping_document', 'document': {'goal': [0, 0]}, 'expected': False},
        {'name': 'legacy_pair_is_not_the_interface', 'document': [example[-1], example[:-1]], 'expected': False},
        {'name': 'missing_final_goal', 'document': example[:-1], 'expected': False},
    ])
    cli_results = []
    with tempfile.TemporaryDirectory() as temporary:
        path = Path(temporary) / 'certificate.json'
        for row in cli_records:
            path.write_text(json.dumps(row['document']) + '\n')
            oracle = named.accept_document(row['document'])
            if oracle != row['expected']:
                failures.append({'kind': 'document_oracle', 'name': row['name']})
            for optimized in (False, True):
                command = [sys.executable, *(['-O'] if optimized else []), str(checker), str(path)]
                process = subprocess.run(command, capture_output=True, text=True, timeout=30)
                expected_output = 'ACCEPT' if row['expected'] else 'REJECT'
                success = (process.returncode == (0 if row['expected'] else 1)
                           and process.stdout.strip() == expected_output)
                cli_results.append({'name': row['name'], 'optimized': optimized, 'pass': success})
                if not success:
                    failures.append({'kind': 'public_cli', 'name': row['name'], 'optimized': optimized,
                                     'returncode': process.returncode, 'stdout': process.stdout,
                                     'stderr': process.stderr, 'expected': row['expected']})
        for text in ('{', 'null trailing', '[0,', ''):
            path.write_text(text)
            for optimized in (False, True):
                process = subprocess.run([sys.executable, *(['-O'] if optimized else []),
                                          str(checker), str(path)], capture_output=True,
                                         text=True, timeout=30)
                success = process.returncode == 1 and process.stdout.strip() == 'REJECT'
                cli_results.append({'name': 'invalid_json_' + repr(text), 'optimized': optimized, 'pass': success})
                if not success:
                    failures.append({'kind': 'invalid_json_cli', 'input': text, 'optimized': optimized})
        for name, arguments in (('missing_path_argument', []),
                                ('nonexistent_certificate_file', [str(Path(temporary) / 'absent.json')])):
            for optimized in (False, True):
                process = subprocess.run([sys.executable, *(['-O'] if optimized else []),
                                          str(checker), *arguments], capture_output=True,
                                         text=True, timeout=30)
                success = process.returncode == 1 and process.stdout.strip() == 'REJECT'
                cli_results.append({'name': name, 'optimized': optimized, 'pass': success})
                if not success:
                    failures.append({'kind': 'cli_failure_boundary', 'name': name,
                                     'optimized': optimized})

    result = {
        'status': 'PASS' if not failures else 'FAIL',
        'checker': str(checker), 'checker_sha256': hashlib.sha256(checker.read_bytes()).hexdigest(),
        'python': platform.python_version(), 'frozen_repository_commit': frozen['commit'],
        'frozen_files_verified': len(frozen['files']),
        'source_proofs_checked': len(corpus_results), 'source_theorems': closed_corpus,
        'source_open_sequents': len(corpus_results) - closed_corpus,
        'targeted_fixtures': len(fixture_results),
        'accepted_stacks_extracted_and_source_checked': extraction_count,
        'substitution_cases': len(substitution_results), 'real_cli_executions': len(cli_results),
        'normal_cli_executions': sum(not row['optimized'] for row in cli_results),
        'optimized_cli_executions': sum(row['optimized'] for row in cli_results),
        'accepted_failed_major_fallbacks': fallback_count, 'rule_events': dict(events),
        'failures': failures,
        'limitations': [
            'Finite executable evidence, not a formal proof of all checker soundness or completeness claims.',
            'The source corpus and compiler are inherited, attributed support; they are outside the trusted kernel.',
            'The independent oracle retains existential padding, and accepted proof extraction erases it only afterward.',
            'Public certificates are theorem requests; tests with contexts exercise the internal rule implementation.',
            'Runtime recursion, memory and JSON-parser limits can reject sufficiently large valid certificates.',
        ],
    }
    for name, value in [('summary.json', result), ('corpus.json', corpus_results),
                        ('fixtures.json', fixture_results), ('substitutions.json', substitution_results),
                        ('cli.json', cli_results)]:
        (output / name).write_text(json.dumps(value, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    return 0 if not failures else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--checker', type=Path, default=ROOT.parent / 'combined.py')
    parser.add_argument('--output', type=Path, default=ROOT / 'results')
    parser.add_argument('--source', type=Path, action='append', default=[])
    args = parser.parse_args()
    raise SystemExit(run(args.checker.resolve(), args.output.resolve(), args.source))
