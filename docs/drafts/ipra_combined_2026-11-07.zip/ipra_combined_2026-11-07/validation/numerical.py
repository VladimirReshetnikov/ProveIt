"""Independent bounded value audit of the named arithmetic compiler.

This evaluator is not a proof checker. It compares ordinary R semantics
with successor-initialized A semantics of every compiled test expression.
No case is skipped and any resource-bound excess fails the audit.
"""
import json
from pathlib import Path
from absorption_bridge import tr, term, p


def value(t, env, absorbed):
    if t == 0:return 0
    if isinstance(t,str):return env[t]
    if t[0] == 's':return value(t[1],env,absorbed)+1
    _,n,a,u,v,h=t
    n=value(n,env,absorbed)
    if n > 10000:raise ValueError('Numeric audit counter bound exceeded')
    result=value(a,env,absorbed)+int(absorbed)
    for counter in range(n):
        result=value(h,{**env,u:result,v:counter},absorbed)
    return result


def main():
    x,y,u,v,a,b=(tr.fresh() for _ in range(6))
    R,S=tr.R,tr.S
    terms=[
      ('zero',0),('first_projection',x),('second_projection',y),('successor',S(x)),
      ('constant_iteration',R(x,y,u,v,u)),
      ('predecessor',R(x,0,u,v,v)),
      ('addition',R(x,y,u,v,S(u))),
      ('counter_successor',R(x,0,u,v,S(v))),
      ('iterated_addition',R(x,y,u,v,R(y,u,a,b,S(a)))),
      ('fixed_counter_parameter',R(x,x,u,v,R(v,u,a,b,S(a)))),
      ('nested_constant_update',R(S(x),y,u,v,S(R(v,u,a,b,a)))),
      ('accumulator_used_as_counter',R(x,y,u,v,R(u,y,a,b,S(a)))),
      ('outer_counter_as_initializer',R(x,0,u,v,R(y,v,a,b,a))),
      ('outer_accumulator_under_inner_binders',R(x,0,u,v,R(y,v,a,b,S(u)))),
    ]
    rows=[]
    for name,source in terms:
        target=term(source)
        for xv in range(5):
            for yv in range(5):
                original=value(source,{x:xv,y:yv},False)
                compiled=value(target,{x:xv,y:yv},True)
                if original != compiled:raise AssertionError((name,xv,yv,original,compiled))
                rows.append({'term':name,'x':xv,'y':yv,'value':compiled})
    decoder=[]
    for n in range(21):
        actual=value(p(x),{x:n},True)
        expected=n-1 if n else 1
        if actual != expected:raise AssertionError(('decoder',n,actual,expected))
        predecessor=value(term(R(x,0,u,v,v)),{x:n},True)
        if predecessor != max(n-1,0):raise AssertionError(('predecessor',n,predecessor))
        decoder.append({'n':n,'decoder':actual,'truncated_predecessor':predecessor})
    result={'status':'PASS','source_terms':len(terms),'parameter_assignments':25,
            'value_comparisons':len(rows),'decoder_and_predecessor_comparisons':42,
            'cases_skipped':0,'rows':rows,'decoder':decoder}
    (Path(__file__).resolve().parents[1]/'results/numerical.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('rows','decoder')},indent=2))


if __name__ == '__main__':main()
