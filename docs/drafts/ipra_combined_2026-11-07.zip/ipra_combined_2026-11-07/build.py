"""Compile the complete report with pdfLaTeX; generated TeX data must exist."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    build = ROOT / 'build'
    build.mkdir(exist_ok=True)
    command = ['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
               '-file-line-error', '-output-directory=' + str(build), 'report.tex']
    for iteration in range(3):
        result = subprocess.run(command, cwd=ROOT, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (build / f'pass_{iteration + 1}.txt').write_text(result.stdout)
        if result.returncode:
            print(result.stdout[-10000:])
            raise SystemExit(result.returncode)
    shutil.copy2(build / 'report.pdf', ROOT / 'report.pdf')
    print('Built report.pdf')


if __name__ == '__main__':
    main()
