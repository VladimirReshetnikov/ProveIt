"""Elaborate proof-level SK plans to native unary-closure source proof trees.

This optional untrusted bridge uses the attributed logic reconstruction
builders in a frozen baseline. It adds no rules to the acceptance kernel.
Every emitted source tree still has to be transported and checked by the
candidate checker. See --help for the reproducible command line.
"""
import argparse
import importlib
import json
from pathlib import Path
import sys

import combinators as sk


def elaborate(plan, atoms, logic):
    """Return a q-tagged (goal, native proof tree) for a typed SK/Lam plan.

    ``atoms`` maps each opaque formula label to a native formula. The free
    native assumptions are the images of the free assumptions returned by
    combinators.infer. Quantifiers inside an atom are preserved unchanged;
    no numerical variable is abstracted by the SK compiler.
    """
    sk.infer(plan)
    cache = {}

    def formula(a):
        if a not in cache:
            if isinstance(a, sk.Atom):
                cache[a] = atoms[a.label]
            elif isinstance(a, sk.Arrow):
                cache[a] = logic.implication(formula(a.left), formula(a.right))
            else:
                raise TypeError("Unknown proof type")
        return cache[a]

    def visit(proof):
        if isinstance(proof, sk.Var):
            return logic.b.hyp(formula(proof.formula))
        if isinstance(proof, (sk.K, sk.S)):
            return visit(sk.expand(proof))
        if isinstance(proof, sk.Lam):
            result = visit(proof.body)
            return logic.implication_intro(formula(proof.formula), result[0], result)
        if isinstance(proof, sk.App):
            function_type, _ = sk.infer(proof.function)
            return logic.implication_elim(formula(function_type.left),
                                          formula(function_type.right),
                                          visit(proof.function),
                                          visit(proof.argument))
        raise TypeError("Unknown proof plan")

    result = visit(plan)
    expected, _ = sk.infer(plan)
    if result[0] != formula(expected):
        raise AssertionError("Native elaboration changed the conclusion")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--builders", type=Path, required=True,
                        help="directory containing logic_certificates.py and its companions")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--examples", nargs="+", default=["k", "i"],
                        choices=["k", "i", "s"])
    args = parser.parse_args()
    sys.setrecursionlimit(max(10000, sys.getrecursionlimit()))
    sys.path.insert(0, str(args.builders.resolve()))
    logic = importlib.import_module("logic_certificates")
    if Path(logic.__file__).resolve().parent != args.builders.resolve():
        raise RuntimeError("The imported builders do not match --builders")
    a, b, c = map(sk.Atom, ("A", "B", "C"))
    atoms = {"A": ["=", 1, 2], "B": ["=", 2, 1],
             "C": ["=", ["s", 1], ["s", 2]]}
    plans = {"k": sk.K(a, b), "i": sk.identity(a), "s": sk.S(a, b, c)}
    args.output.mkdir(parents=True, exist_ok=True)
    records = []
    for name in args.examples:
        plan = plans[name]
        proof = elaborate(plan, atoms, logic)
        target = args.output / ("combinator_" + name + "_source.json")
        text = json.dumps(proof, separators=(",", ":")) + "\n"
        target.write_text(text)
        formula, context = sk.infer(plan)
        records.append({"example": name, "source_file": target.name,
                        "bytes": len(text.encode()), "formula": sk.encode(formula),
                        "free_proof_assumptions": len(context),
                        "sk_nodes": sk.node_count(plan),
                        "status": "native tree generated; kernel verification is separate"})
        print(json.dumps(records[-1]), flush=True)
    (args.output / "combinator_generation.json").write_text(
        json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
