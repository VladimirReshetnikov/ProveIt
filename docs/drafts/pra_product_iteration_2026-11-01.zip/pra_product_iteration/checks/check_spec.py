#!/usr/bin/env python3
"""Finite diagnostics for the literal product-state PRA specification.

This program checks typed syntax, the exact four literal admission cases,
declared AST ledgers, and finitely many values of selected pure iterators.
It is not a proof kernel, a general arithmetic evaluator used by admission,
or a certificate of the bi-interpretability theorem.  Admission does not
invoke the numerical evaluator and does not normalize product equations.
Only the Python standard library is required.  Checks remain active with -O.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
import math
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class Type:
    left: Type | None = None
    right: Type | None = None

    def __str__(self) -> str:
        if self.left is None:
            return "N"
        return f"({self.left}*{self.right})"


N = Type()


def Prod(left: Type, right: Type) -> Type:
    return Type(left, right)


@dataclass(frozen=True)
class Node:
    op: str
    args: tuple[Node, ...] = ()
    label: str = ""


def Var(name: str) -> Node:
    return Node("var", label=name)


ZERO = Node("zero")
BOT = Node("bottom")


def S(term: Node) -> Node:
    return Node("succ", (term,))


def Pair(left: Node, right: Node) -> Node:
    return Node("pair", (left, right))


def Fst(term: Node) -> Node:
    return Node("fst", (term,))


def Snd(term: Node) -> Node:
    return Node("snd", (term,))


def Iter(name: str, counter: Node, seed: Node) -> Node:
    # The stored description is metadata, not an extra term argument.
    return Node("iter", (counter, seed), name)


def Eq(left: Node, right: Node) -> Node:
    return Node("eq", (left, right))


def Imp(left: Node, right: Node) -> Node:
    return Node("imp", (left, right))


def And(left: Node, right: Node) -> Node:
    return Node("and", (left, right))


def Or(left: Node, right: Node) -> Node:
    return Node("or", (left, right))


SEP = Imp(Eq(ZERO, S(ZERO)), BOT)


def substitute(tree: Node, variable: str, replacement: Node) -> Node:
    """QF substitution; never enters a stored iterator description."""
    if tree.op == "var" and tree.label == variable:
        return replacement
    return Node(tree.op, tuple(substitute(x, variable, replacement)
                               for x in tree.args), tree.label)


class SpecificationError(ValueError):
    pass


def arity(tree: Node, expected: int) -> None:
    if len(tree.args) != expected:
        raise SpecificationError(f"bad arity for {tree.op}")


@dataclass(frozen=True)
class Description:
    state: Type
    update: Node


class Registry:
    def __init__(self) -> None:
        self.descriptions: dict[str, Description] = {}

    def term_type(self, term: Node, environment: dict[str, Type]) -> Type:
        if term.op == "var":
            arity(term, 0)
            if term.label not in environment:
                raise SpecificationError(f"unbound variable {term.label}")
            return environment[term.label]
        if term.op == "zero":
            arity(term, 0)
            return N
        if term.op == "succ":
            arity(term, 1)
            if self.term_type(term.args[0], environment) != N:
                raise SpecificationError("successor input must have type N")
            return N
        if term.op == "pair":
            arity(term, 2)
            return Prod(*(self.term_type(x, environment) for x in term.args))
        if term.op in ("fst", "snd"):
            arity(term, 1)
            source = self.term_type(term.args[0], environment)
            if source.left is None or source.right is None:
                raise SpecificationError("projection input must be a product")
            return source.left if term.op == "fst" else source.right
        if term.op == "iter":
            arity(term, 2)
            if term.label not in self.descriptions:
                raise SpecificationError(f"non-earlier iterator {term.label}")
            definition = self.descriptions[term.label]
            if self.term_type(term.args[0], environment) != N:
                raise SpecificationError("iteration counter must have type N")
            if self.term_type(term.args[1], environment) != definition.state:
                raise SpecificationError("iterator seed has the wrong type")
            return definition.state
        raise SpecificationError(f"unsupported term operation {term.op}")

    def formula_typecheck(self, formula: Node,
                          environment: dict[str, Type]) -> None:
        if formula.op == "bottom":
            arity(formula, 0)
            return
        if formula.op == "eq":
            arity(formula, 2)
            if (self.term_type(formula.args[0], environment)
                    != self.term_type(formula.args[1], environment)):
                raise SpecificationError("equality compares different sorts")
            return
        if formula.op in ("and", "or", "imp"):
            arity(formula, 2)
            for part in formula.args:
                self.formula_typecheck(part, environment)
            return
        raise SpecificationError(f"unsupported QF formula operation {formula.op}")

    def register(self, name: str, state: Type, update: Node) -> None:
        if name in self.descriptions:
            raise SpecificationError("description name is not fresh")
        # Validation before insertion excludes circular or future dependencies.
        if self.term_type(update, {"v": state}) != state:
            raise SpecificationError("stored update is not an endomorphism")
        self.descriptions[name] = Description(state, update)

    def admit(self, formula: Node, state: Type) -> str | None:
        """Return the literal admission case, or None for a well-typed failure."""
        self.formula_typecheck(formula, {"n": N, "a": Prod(N, state)})
        base = substitute(formula, "n", ZERO)
        if base.op == "imp" and base.args[0] == base.args[1]:
            return "reflexive_implication"
        if base == SEP:
            return "separation"
        target, seed = Fst(Var("a")), Snd(Var("a"))
        for name, definition in self.descriptions.items():
            if definition.state != state:
                continue
            if base == Eq(Iter(name, ZERO, seed), seed):
                return f"initialization:{name}"
            expected = substitute(definition.update, "v", Iter(name, target, seed))
            if base == Eq(Iter(name, S(target), seed), expected):
                return f"successor:{name}"
        return None

    def evaluate(self, term: Node, environment: dict[str, Any]) -> Any:
        """Diagnostic interpreter only; admit() never calls this method."""
        if term.op == "var":
            return environment[term.label]
        if term.op == "zero":
            return 0
        if term.op == "succ":
            return self.evaluate(term.args[0], environment) + 1
        if term.op == "pair":
            return tuple(self.evaluate(x, environment) for x in term.args)
        if term.op in ("fst", "snd"):
            return self.evaluate(term.args[0], environment)[term.op == "snd"]
        if term.op == "iter":
            count = self.evaluate(term.args[0], environment)
            value = self.evaluate(term.args[1], environment)
            if not isinstance(count, int) or count < 0:
                raise SpecificationError("diagnostic counter is not natural")
            definition = self.descriptions[term.label]
            for _ in range(count):
                value = self.evaluate(definition.update, {"v": value})
            return value
        raise SpecificationError(f"cannot evaluate {term.op}")


def ast_size(tree: Node) -> int:
    """Every application and leaf counts; binder/description labels do not."""
    return 1 + sum(ast_size(x) for x in tree.args)


def Forall(variable: str, body: Node) -> Node:
    # Only for the displayed-skeleton ledger, never an admissible QF input.
    return Node("forall", (body,), variable)


def schematic(name: str, *arguments: Node) -> Node:
    return Node("schematic", arguments, name)


def ledgers() -> dict[str, Any]:
    n, a, x, y, z = map(Var, ("n", "a", "x", "y", "z"))
    fn = schematic("F", n, a)
    fs = schematic("F", S(n), a)
    fe = schematic("F", Fst(a), a)
    endpoint = Forall("a", Imp(Forall("n", Imp(fn, fs)), fe))
    beta1 = Forall("x", Forall("y", Eq(Fst(Pair(x, y)), x)))
    beta2 = Forall("x", Forall("y", Eq(Snd(Pair(x, y)), y)))
    eta = Forall("z", Eq(Pair(Fst(z), Snd(z)), z))
    seed, target = Snd(a), Fst(a)
    gates = (
        Imp(schematic("B", a), schematic("B", a)),
        Eq(Iter("h", ZERO, seed), seed),
        Eq(Iter("h", S(target), seed),
           schematic("h", Iter("h", target, seed))),
        SEP,
    )
    return {
        "outer_components": [ast_size(fn), ast_size(fs), ast_size(fe), 2, 2],
        "outer_total": ast_size(endpoint),
        "product_law_templates": [ast_size(t) for t in (beta1, beta2, eta)],
        "product_law_template_sum": sum(ast_size(t) for t in (beta1, beta2, eta)),
        "admission_pattern_templates": [ast_size(t) for t in gates],
        "admission_pattern_template_sum": sum(ast_size(t) for t in gates),
        "ledger_scope": "Partial AST templates; types, bodies and generator code excluded",
    }


def diagnostics() -> dict[str, Any]:
    outcomes: list[dict[str, str]] = []

    def require(name: str, condition: bool, detail: str = "") -> None:
        if not condition:
            raise AssertionError(f"{name}: {detail}")
        outcomes.append({"case": name, "status": "pass"})

    def rejected(name: str, action: Any) -> None:
        try:
            result = action()
        except SpecificationError:
            require(name, True)
        else:
            require(name, result is None, f"unexpectedly admitted {result}")

    def registration_error(name: str, action: Any) -> None:
        before = dict(registry.descriptions)
        try:
            action()
        except SpecificationError:
            require(name, registry.descriptions == before,
                    "failed registration changed the registry")
        else:
            raise AssertionError(f"{name}: invalid description was registered")

    registry = Registry()
    v, n, a = Var("v"), Var("n"), Var("a")
    NN = Prod(N, N)
    registry.register("increment", N, S(v))
    registry.register("previous_pair", NN, Pair(S(Fst(v)), Fst(v)))
    registry.register("multiply_state", NN,
                      Pair(Fst(v), Iter("increment", Fst(v), Snd(v))))

    def multiplication(left: Node, right: Node) -> Node:
        return Snd(Iter("multiply_state", left, Pair(right, ZERO)))

    registry.register("factorial_state", NN,
                      Pair(S(Fst(v)), multiplication(S(Fst(v)), Snd(v))))

    # Every registered description is genuinely unary in its whole state.
    for name, definition in registry.descriptions.items():
        seed, target = Snd(a), Fst(a)
        init = Eq(Iter(name, ZERO, seed), seed)
        step = Eq(Iter(name, S(target), seed),
                  substitute(definition.update, "v", Iter(name, target, seed)))
        require(f"initializer_{name}",
                registry.admit(init, definition.state) == f"initialization:{name}")
        require(f"successor_{name}",
                registry.admit(step, definition.state) == f"successor:{name}")

    for state, label in ((N, "N"), (NN, "NxN")):
        require(f"separation_{label}", registry.admit(SEP, state) == "separation")
        if state == N:
            g = Eq(Iter("increment", n, Snd(a)), n)
        else:
            g = Eq(Pair(n, ZERO), Snd(a))
        induction = Imp(substitute(g, "n", ZERO), g)
        require(f"reflexive_induction_{label}",
                registry.admit(induction, state) == "reflexive_implication")
        composite = Or(g, And(SEP, g))
        require(f"QF_connectives_{label}",
                registry.admit(Imp(substitute(composite, "n", ZERO), composite), state)
                == "reflexive_implication")

    seed = Snd(a)
    rejected("reversed_initializer", lambda: registry.admit(
        Eq(seed, Iter("increment", ZERO, seed)), N))
    rejected("initializer_under_context", lambda: registry.admit(
        Eq(S(Iter("increment", ZERO, seed)), S(seed)), N))
    rejected("beta_equivalent_initializer", lambda: registry.admit(
        Eq(Iter("increment", ZERO, seed), Snd(Pair(Fst(a), seed))), N))
    rejected("eta_equivalent_initializer", lambda: registry.admit(
        Eq(Iter("previous_pair", ZERO, seed), Pair(Fst(seed), Snd(seed))), NN))
    rejected("beta_equivalent_implication_branches", lambda: registry.admit(
        Imp(Eq(ZERO, ZERO), Eq(Fst(Pair(ZERO, ZERO)), ZERO)), N))
    rejected("nonidentical_implication_branches", lambda: registry.admit(
        Imp(Eq(ZERO, ZERO), Eq(S(ZERO), ZERO)), N))
    rejected("free_variable_leak", lambda: registry.admit(
        Imp(Eq(Var("x"), Var("x")), Eq(Var("x"), Var("x"))), N))
    rejected("quantified_matrix", lambda: registry.admit(
        Forall("x", Imp(Eq(Var("x"), Var("x")), Eq(Var("x"), Var("x")))), N))
    rejected("equality_sort_mismatch", lambda: registry.admit(Eq(n, a), N))
    rejected("product_counter", lambda: registry.admit(
        Eq(Iter("increment", Pair(ZERO, ZERO), seed), seed), N))
    rejected("iterator_seed_type", lambda: registry.admit(
        Eq(Iter("increment", ZERO, seed), seed), NN))
    rejected("scalar_projection", lambda: registry.admit(Eq(Fst(n), ZERO), N))
    registration_error("circular_update", lambda: registry.register(
        "circular", N, Iter("circular", ZERO, v)))
    registration_error("future_update_dependency", lambda: registry.register(
        "future_user", N, Iter("not_yet_registered", ZERO, v)))
    registration_error("update_free_variable_leak", lambda: registry.register(
        "leaky", N, S(Var("counter"))))
    registration_error("update_not_endomorphism", lambda: registry.register(
        "wrong_type", N, Pair(v, v)))
    registration_error("duplicate_description_name", lambda: registry.register(
        "increment", N, v))

    counts = ledgers()
    require("outer15", counts["outer_components"] == [3, 4, 4, 2, 2]
            and counts["outer_total"] == 15)
    require("product_laws24", counts["product_law_templates"] == [8, 8, 8]
            and counts["product_law_template_sum"] == 24)
    require("literal_patterns31", counts["admission_pattern_templates"] == [5, 7, 13, 6]
            and counts["admission_pattern_template_sum"] == 31)

    # These examples test the claimed product-state construction on finite inputs.
    predecessor_state = Iter("previous_pair", n, Pair(ZERO, ZERO))
    registry.term_type(predecessor_state, {"n": N})
    predecessor_values = []
    for number in range(51):
        value = registry.evaluate(predecessor_state, {"n": number})
        require(f"predecessor_state_{number}", value == (number, max(number - 1, 0)))
        predecessor_values.append(value[1])

    add_term = Iter("increment", Var("x"), Var("y"))
    mul_term = multiplication(Var("x"), Var("y"))
    registry.term_type(add_term, {"x": N, "y": N})
    registry.term_type(mul_term, {"x": N, "y": N})
    for left in range(9):
        for right in range(9):
            env = {"x": left, "y": right}
            require(f"addition_{left}_{right}",
                    registry.evaluate(add_term, env) == left + right)
            require(f"multiplication_{left}_{right}",
                    registry.evaluate(mul_term, env) == left * right)

    fact_term = Iter("factorial_state", n, Pair(ZERO, S(ZERO)))
    registry.term_type(fact_term, {"n": N})
    factorial_values = []
    for number in range(8):
        value = registry.evaluate(fact_term, {"n": number})
        require(f"factorial_state_{number}", value == (number, math.factorial(number)))
        factorial_values.append(value[1])

    return {
        "status": "pass",
        "scope": "Finite syntax, admission-boundary, AST and numerical diagnostics; not a proof kernel",
        "registered_pure_updates": {k: str(d.state) for k, d in registry.descriptions.items()},
        "checks_passed": len(outcomes),
        "checks": outcomes,
        "ledgers": counts,
        "numerical_ranges": {"predecessor": [0, 50], "addition_inputs": [0, 8],
                             "multiplication_inputs": [0, 8], "factorial": [0, 7]},
        "factorial_values": factorial_values,
        "predecessor_values_first_11": predecessor_values[:11],
        "not_established_by_this_program": [
            "all-model equivalence with PRA",
            "validity of arbitrary induction instances",
            "the internal interpretation round trips",
            "global or full-encoding minimality",
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("results.json"))
    args = parser.parse_args()
    result = diagnostics()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "checks_passed": result["checks_passed"],
                      "outer_nodes": result["ledgers"]["outer_total"],
                      "product_law_nodes": result["ledgers"]["product_law_template_sum"],
                      "literal_pattern_nodes": result["ledgers"]["admission_pattern_template_sum"],
                      "output": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
