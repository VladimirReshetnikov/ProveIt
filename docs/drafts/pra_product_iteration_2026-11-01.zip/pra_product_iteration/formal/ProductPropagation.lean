import Init

/-!
# Constructive logical kernel for packed endpoint propagation

This file works over arbitrary carriers, a distinguished zero, and a successor.
It checks the logical equivalence between normalized packed propagation and
parameterized induction, extraction of the stationary computation laws,
soundness from base validity and induction, and two state-iteration arguments.

All induction principles and computation laws are explicit hypotheses.  This
file does not formalize first-order syntax, the literal admission parser, the
well-founded language of update descriptions, or the complete bi-interpretation.
In particular, its Prop-valued matrices are semantic parameters, not a claim
that the proposed arithmetic has induction for all quantified formulas.
-/

universe u v w

namespace ProductPropagation

variable {N : Type u} {A : Type v}

def ParameterInduction (z : N) (s : N → N) (G : N → A → Prop) : Prop :=
  ∀ b, G z b → (∀ n, G n b → G (s n) b) → ∀ n, G n b

def PackedPropagation (s : N → N) (F : N → N × A → Prop) : Prop :=
  ∀ a, (∀ n, F n a → F (s n) a) → F a.1 a

def Normalize (z : N) (G : N → A → Prop) : N → N × A → Prop :=
  fun n a => G z a.2 → G n a.2

theorem normalized_base (z : N) (G : N → A → Prop) (a : N × A) :
    Normalize z G z a := by
  intro h
  exact h

theorem packed_to_induction (z : N) (s : N → N) (G : N → A → Prop)
    (hp : PackedPropagation s (Normalize z G)) :
    ParameterInduction z s G := by
  intro b hzero hstep n
  apply hp (n, b)
  · intro k ih hz
    exact hstep k (ih hz)
  · exact hzero

theorem induction_to_normalized_packed (z : N) (s : N → N)
    (G : N → A → Prop) (hi : ParameterInduction z s G) :
    PackedPropagation s (Normalize z G) := by
  intro a hp hz
  apply hi a.2 hz
  · intro n hn
    exact hp n (fun _ => hn) hz

theorem normalized_packed_iff_induction (z : N) (s : N → N)
    (G : N → A → Prop) :
    PackedPropagation s (Normalize z G) ↔ ParameterInduction z s G := by
  constructor
  · exact packed_to_induction z s G
  · exact induction_to_normalized_packed z s G

def Stationary (P : N × A → Prop) : N → N × A → Prop :=
  fun _ a => P a

theorem stationary_iff (s : N → N) (P : N × A → Prop) :
    PackedPropagation s (Stationary P) ↔ ∀ a, P a := by
  constructor
  · intro hp a
    exact hp a (fun _ h => h)
  · intro h a _
    exact h a

def InitialMatrix (z : N) (it : N → A → A) : N → N × A → Prop :=
  Stationary (fun a => it z a.2 = a.2)

def SuccessorMatrix (s : N → N) (it : N → A → A) (h : A → A) :
    N → N × A → Prop :=
  Stationary (fun a => it (s a.1) a.2 = h (it a.1 a.2))

def SeparationMatrix (z : N) (s : N → N) : N → N × A → Prop :=
  Stationary (fun _ => z ≠ s z)

theorem extract_initialization (z : N) (s : N → N) (it : N → A → A)
    (hp : PackedPropagation s (InitialMatrix z it)) : ∀ b, it z b = b := by
  intro b
  exact (stationary_iff s (fun a : N × A => it z a.2 = a.2)).mp hp (z, b)

theorem extract_successor (s : N → N) (it : N → A → A) (h : A → A)
    (hp : PackedPropagation s (SuccessorMatrix s it h)) :
    ∀ n b, it (s n) b = h (it n b) := by
  intro n b
  exact (stationary_iff s
    (fun a : N × A => it (s a.1) a.2 = h (it a.1 a.2))).mp hp (n, b)

theorem extract_separation (z : N) (s : N → N)
    (hp : PackedPropagation s (SeparationMatrix (A := N) z s)) : z ≠ s z := by
  exact (stationary_iff s (fun _ : N × N => z ≠ s z)).mp hp (z, z)

theorem induction_and_base_to_packed (z : N) (s : N → N)
    (F : N → N × A → Prop) (hb : ∀ a, F z a)
    (hi : ParameterInduction z s F) : PackedPropagation s F := by
  intro a hp
  exact hi a (hb a) hp a.1

/- A semantic representation of the four possible zero-instance shapes.
   The equalities below are evidence supplied by literal syntactic identity;
   they are not computed by a parser in this file.  No propositional
   extensionality is used to construct them. -/
inductive BaseShape (z : N) (s : N → N) (it : N → A → A)
    (h : A → A) (F : N → N × A → Prop) : Prop where
  | reflexive (B : N × A → Prop)
      (same : ∀ a, F z a = (B a → B a)) : BaseShape z s it h F
  | initial (same : ∀ a, F z a = (it z a.2 = a.2)) : BaseShape z s it h F
  | successor
      (same : ∀ a, F z a = (it (s a.1) a.2 = h (it a.1 a.2))) :
      BaseShape z s it h F
  | separation (same : ∀ a, F z a = (z ≠ s z)) : BaseShape z s it h F

theorem base_shape_sound (z : N) (s : N → N) (it : N → A → A)
    (h : A → A) (F : N → N × A → Prop)
    (hzero : ∀ b, it z b = b)
    (hstep : ∀ n b, it (s n) b = h (it n b)) (hsep : z ≠ s z)
    (cert : BaseShape z s it h F) : ∀ a, F z a := by
  intro a
  cases cert with
  | reflexive B same =>
    rw [same a]
    exact fun hb => hb
  | initial same =>
    rw [same a]
    exact hzero a.2
  | successor same =>
    rw [same a]
    exact hstep a.1 a.2
  | separation same =>
    rw [same a]
    exact hsep

theorem four_shape_converse (z : N) (s : N → N) (it : N → A → A)
    (h : A → A) (F : N → N × A → Prop)
    (hzero : ∀ b, it z b = b)
    (hstep : ∀ n b, it (s n) b = h (it n b)) (hsep : z ≠ s z)
    (cert : BaseShape z s it h F) (hi : ParameterInduction z s F) :
    PackedPropagation s F := by
  exact induction_and_base_to_packed z s F
    (base_shape_sound z s it h F hzero hstep hsep cert) hi

/-! ## A pure endomorphism iterator supplies predecessor -/

def CounterStep (s : N → N) (v : N × N) : N × N := (s v.1, v.1)

def CounterState (z : N) (it : N → (N × N) → N × N) (n : N) : N × N :=
  it n (z, z)

def CounterInvariant (z : N) (it : N → (N × N) → N × N)
    (n : N) (_ : N) : Prop := (CounterState z it n).1 = n

theorem counter_invariant (z : N) (s : N → N)
    (it : N → (N × N) → N × N)
    (hzero : ∀ v, it z v = v)
    (hstep : ∀ n v, it (s n) v = CounterStep s (it n v))
    (hi : ParameterInduction z s (CounterInvariant z it)) :
    ∀ n, (CounterState z it n).1 = n := by
  apply hi z
  · show (it z (z, z)).1 = z
    rw [hzero]
  · intro n ih
    change (it (s n) (z, z)).1 = s n
    rw [hstep]
    exact congrArg s ih

def Predecessor (z : N) (it : N → (N × N) → N × N) (n : N) : N :=
  (CounterState z it n).2

theorem predecessor_equations (z : N) (s : N → N)
    (it : N → (N × N) → N × N)
    (hzero : ∀ v, it z v = v)
    (hstep : ∀ n v, it (s n) v = CounterStep s (it n v))
    (hi : ParameterInduction z s (CounterInvariant z it)) :
    Predecessor z it z = z ∧ ∀ n, Predecessor z it (s n) = n := by
  constructor
  · change (it z (z, z)).2 = z
    rw [hzero]
  · intro n
    change (it (s n) (z, z)).2 = n
    rw [hstep]
    exact counter_invariant z s it hzero hstep hi n

theorem successor_injective_of_predecessor (s : N → N) (p : N → N)
    (hp : ∀ n, p (s n) = n) : ∀ x y, s x = s y → x = y := by
  intro x y hxy
  have h := congrArg p hxy
  rw [hp x, hp y] at h
  exact h

theorem successor_nonzero_of_predecessor (z : N) (s : N → N)
    (p : N → N) (hpzero : p z = z) (hp : ∀ n, p (s n) = n)
    (hsep : z ≠ s z) : ∀ x, s x ≠ z := by
  intro x hx
  have heq := congrArg p hx
  rw [hp x, hpzero] at heq
  apply hsep
  rw [heq] at hx
  exact hx.symm

def Coverage (z : N) (s : N → N) (p : N → N) (n : N) (_ : N) : Prop :=
  n = z ∨ n = s (p n)

theorem constructor_coverage (z : N) (s : N → N) (p : N → N)
    (hp : ∀ n, p (s n) = n)
    (hi : ParameterInduction z s (Coverage z s p)) :
    ∀ n, n = z ∨ n = s (p n) := by
  apply hi z
  · exact Or.inl rfl
  · intro n _
    apply Or.inr
    exact (congrArg s (hp n)).symm

/-! ## One stage of the ordinary primitive-recursion compiler -/

variable {P : Type v} {V : Type w}

def SimulationStep (s : N → N) (k : N → P → V → V)
    (v : N × (P × V)) : N × (P × V) :=
  (s v.1, (v.2.1, k v.1 v.2.1 v.2.2))

def SimulationState (z : N) (it : N → (N × (P × V)) → N × (P × V))
    (g : P → V) (n : N) (b : P) : N × (P × V) :=
  it n (z, (b, g b))

def SimulationInvariant (z : N)
    (it : N → (N × (P × V)) → N × (P × V))
    (g : P → V) (n : N) (b : P) : Prop :=
  (SimulationState z it g n b).1 = n ∧
  (SimulationState z it g n b).2.1 = b

theorem simulation_invariant (z : N) (s : N → N)
    (it : N → (N × (P × V)) → N × (P × V))
    (g : P → V) (k : N → P → V → V)
    (hzero : ∀ v, it z v = v)
    (hstep : ∀ n v, it (s n) v = SimulationStep s k (it n v))
    (hi : ParameterInduction z s (SimulationInvariant z it g)) :
    ∀ n b, SimulationInvariant z it g n b := by
  intro n b
  apply hi b
  · change (it z (z, (b, g b))).1 = z ∧
      (it z (z, (b, g b))).2.1 = b
    rw [hzero]
    exact ⟨rfl, rfl⟩
  · intro m ih
    change (it (s m) (z, (b, g b))).1 = s m ∧
      (it (s m) (z, (b, g b))).2.1 = b
    rw [hstep]
    exact ⟨congrArg s ih.1, ih.2⟩

def SimulationValue (z : N)
    (it : N → (N × (P × V)) → N × (P × V))
    (g : P → V) (n : N) (b : P) : V :=
  (SimulationState z it g n b).2.2

theorem simulated_recursion (z : N) (s : N → N)
    (it : N → (N × (P × V)) → N × (P × V))
    (g : P → V) (k : N → P → V → V)
    (hzero : ∀ v, it z v = v)
    (hstep : ∀ n v, it (s n) v = SimulationStep s k (it n v))
    (hi : ParameterInduction z s (SimulationInvariant z it g)) :
    (∀ b, SimulationValue z it g z b = g b) ∧
    (∀ n b, SimulationValue z it g (s n) b =
      k n b (SimulationValue z it g n b)) := by
  constructor
  · intro b
    change (it z (z, (b, g b))).2.2 = g b
    rw [hzero]
  · intro n b
    have hinv := simulation_invariant z s it g k hzero hstep hi n b
    change (it (s n) (z, (b, g b))).2.2 =
      k n b (SimulationValue z it g n b)
    rw [hstep]
    change k (SimulationState z it g n b).1
      (SimulationState z it g n b).2.1 (SimulationValue z it g n b) =
      k n b (SimulationValue z it g n b)
    rw [hinv.1, hinv.2]

end ProductPropagation

#print axioms ProductPropagation.normalized_base
#print axioms ProductPropagation.packed_to_induction
#print axioms ProductPropagation.induction_to_normalized_packed
#print axioms ProductPropagation.normalized_packed_iff_induction
#print axioms ProductPropagation.stationary_iff
#print axioms ProductPropagation.extract_initialization
#print axioms ProductPropagation.extract_successor
#print axioms ProductPropagation.extract_separation
#print axioms ProductPropagation.induction_and_base_to_packed
#print axioms ProductPropagation.base_shape_sound
#print axioms ProductPropagation.four_shape_converse
#print axioms ProductPropagation.counter_invariant
#print axioms ProductPropagation.predecessor_equations
#print axioms ProductPropagation.successor_injective_of_predecessor
#print axioms ProductPropagation.successor_nonzero_of_predecessor
#print axioms ProductPropagation.constructor_coverage
#print axioms ProductPropagation.simulation_invariant
#print axioms ProductPropagation.simulated_recursion
