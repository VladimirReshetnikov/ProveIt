PRA BY PURE ITERATION ON FINITE PRODUCTS
Research prepared for Vladimir Reshetnikov
Client date: 1 November 2026

MAIN RESULT

The same effective arithmetic schema, interpreted in matching classical or
intuitionistic equality logic with finite product sorts, is bi-interpretable
with first-order PRA in that logic. Every generated program is a unary state
update. There is no exceptional counter-reading program.

The arithmetic schema is:

  forall a:N x tau (
    [forall n:N (F(n,a) -> F(S(n),a))]
      -> F(pi_1(a),a)
  ).

F is quantifier-free and is admitted only when its literal zero instance is
one of four explicitly specified shapes. See AXIOMS.txt for the complete
syntax and report.pdf for the proof.

This is a proved change of representation, not an absolute minimum.
Finite products and their beta/eta structural schemes are real added
infrastructure. Two typed variable names can contain more than two scalar
coordinates. The partial outer count of 15 excludes this infrastructure,
matrix bodies, and the admission generator.

The report also defines a one-sorted flattened companion that is ordinarily
term-bi-interpretable with PRA, with identity on the number carrier and both
identity round trips. Its expanded scalar formulas do not inherit the
15-node/two-variable bounds.

CONTENTS

report.tex, report.pdf
  Complete article and compiled PDF.

sections/interpretations.tex
  Included proof supplement: induction, predecessor, primitive-recursion
  compiler, reverse interpretation, both internal round trips, one-dimensional
  product coding, and ordinary one-sorted companion.

AXIOMS.txt
  Extractable exact specification.

checks/check_spec.py, checks/results.json
  Executable typed finite syntax and literal admission, scope regression
  diagnostics, partial AST ledgers, and finite state-program evaluations.
  These are diagnostics, not a mathematical proof kernel.

formal/ProductPropagation.lean
  Constructive Lean 4.19 logical and state-simulation kernel.
formal/SCOPE.txt, lean-check.log, verification.json, lean-toolchain
  Exact certification scope, actual compiler output, and source hash.
  The full first-order metasyntax and bi-interpretation are not formalized.

audit/independent_review.txt
  Independent proof and source-comparison review.
audit/validation.json
  Final build, checksums, and PDF quality checks.

sources/source_manifest.json
  Immutable GitHub snapshot, input archive Git/SHA-256 hashes, and source
  member fingerprints. Original input archives are not duplicated here.

build.py
  Rebuilds the Python results and PDF without installing dependencies.

SHA256SUMS.txt
  Manifest of the delivered files, excluding itself.

REPRODUCTION

  python3 build.py
  lean formal/ProductPropagation.lean

The second command is optional and requires leanprover/lean4:v4.19.0.
The first requires Python 3, latexmk, and a standard TeX Live installation
with the packages named in report.tex. No external Python package is needed.

SOURCE BASELINE

VladimirReshetnikov/ProveIt commit:
0e1088217e60a865ee39f86a5563cadbbbc5875f

Seven current draft archives were compared. Earlier eight-archive inventories
inside those drafts belong to older commits.

No GitHub commit, push, issue, comment, or pull request was created.

