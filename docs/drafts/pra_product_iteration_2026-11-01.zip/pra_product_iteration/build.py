#!/usr/bin/env python3
"""Reproduce the local diagnostics and compiled research PDF."""
from pathlib import Path
import json
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(args, log_name):
    result = subprocess.run(args, cwd=ROOT, capture_output=True, text=True)
    (ROOT / "audit").mkdir(exist_ok=True)
    (ROOT / "audit" / log_name).write_text(
        result.stdout + result.stderr, encoding="utf-8"
    )
    if result.returncode:
        print(result.stdout[-8000:])
        print(result.stderr[-2000:], file=sys.stderr)
        raise SystemExit(result.returncode)
    return result


def main():
    run([sys.executable, "checks/check_spec.py"], "python-check.log")
    if not shutil.which("latexmk"):
        raise SystemExit("latexmk is required; no dependency will be installed.")
    run(
        ["latexmk", "-pdf", "-interaction=nonstopmode", "-halt-on-error",
         "-file-line-error", "report.tex"],
        "latex-build.log",
    )
    if not (ROOT / "report.pdf").is_file():
        raise SystemExit("The compiler returned without report.pdf.")
    print(json.dumps({
        "python_checks": "passed",
        "pdf": "report.pdf",
        "pdf_bytes": (ROOT / "report.pdf").stat().st_size,
        "formal_check": "run lean formal/ProductPropagation.lean separately",
    }, indent=2))


if __name__ == "__main__":
    main()

