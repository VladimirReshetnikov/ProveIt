"""Untrusted certificate transport from the frozen declared-supply checker.

Record each reference allocation and rename its negative parameter to minus
one minus the unread proof-stream length. Negative literals never allocated
by the reference can occur only in inert data of an accepted certificate;
they are replaced by zero. No inference is added. The resulting certificate
must still be accepted independently by checker.py.

Usage: python3 transport.py SOURCE.json DESTINATION.json
"""

from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "comparison/sources/paired_coordinates__checker_declared.py"
SOURCE_SHA256 = "420a06adab84682aaa2c76e22094f62cf9409a2ceda9041de742c20d1f418c29"


def translate(packet):
    """Return a transported packet and its auditable allocation trace."""
    frozen = SOURCE.read_bytes()
    if sha256(frozen).hexdigest() != SOURCE_SHA256:
        raise ValueError("frozen reference checker checksum mismatch")
    source = frozen.decode("utf-8")
    allocation = "    k -= 1\n"
    if source.count(allocation) != 1:
        raise ValueError("unique reference allocation point not found")
    source = source.replace(
        allocation, allocation + "    events.append((k, len(stream)))\n"
    )
    namespace = {"__name__": "transport_reference"}
    exec(compile(source, str(SOURCE), "exec"), namespace)
    stream = deepcopy(packet)
    namespace.update(stream=stream, take=stream.pop, events=[], k=0)
    if not namespace["check"](stream.pop(), []):
        raise ValueError("reference checker rejected certificate")
    events = namespace["events"]
    names = {old: -remaining - 1 for old, remaining in events}
    if len(set(names.values())) != len(names):
        raise ValueError("nonunique proof-clock allocation")

    def rename(node):
        if type(node) is int and node < 0:
            return names.get(node, 0)
        if type(node) is list:
            return [rename(child) for child in node]
        return node

    trace = [
        {"old": old, "unread": remaining, "new": -remaining - 1}
        for old, remaining in events
    ]
    return rename(packet), trace


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: python3 transport.py SOURCE.json DESTINATION.json")
    translated, events = translate(json.loads(Path(sys.argv[1]).read_text()))
    Path(sys.argv[2]).write_text(
        json.dumps(translated, separators=(",", ":")) + "\n", encoding="utf-8"
    )
    print(json.dumps({"allocations": events, "cells": len(translated)}, indent=2))


if __name__ == "__main__":
    main()
