PROOF CLOCKS FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
7 November 2026

Start with report.pdf. Its complete source is report.tex and sections/*.tex.

RESULT

The proof-clock certificate representation removes separate mutable
fresh-name state: the number of unread proof cells supplies the next
eigenparameter. The report proves soundness and closed-sentence completeness
for the inherited native calculus and gives its ordinary whole-domain
bi-interpretation with iPRA through the faithful ordinary theory T_cov.
It also proves a fixed-seed recursion obstruction.

Measured with the unchanged metric from the supplied drafts, on CPython
3.12.14, the complete programs have the following sizes:

                                    Tokens    AST nodes    Normalized bytes
Current 13-program envelope             444          457                1313
checker.py (new proof clock)             442          452                1257
checker_combined.py (earlier reductions) 434          441                1262

Both programs beat every separate minimum of the inspected corpus. The
envelope is empirical, not a proven lower bound for all possible theories
or checkers. The clock is new relative to the inspected drafts; worldwide
priority is not claimed. The arithmetic axiom basis itself is inherited.
The metatheory is a written mathematical proof, not a Lean/Rocq artifact.

QUICK START

Requires Python 3.10 or later for structural pattern matching. Exact metric
reproduction uses CPython 3.12.14. No third-party Python packages or network
access are needed for the checker, comparison, translation, or tests.

    python3 checker.py examples/reflexivity_zero.json
    python3 reproduce.py

The first command prints ACCEPT. The second checks frozen comparator
identities, recomputes the whole-program metrics, transports the source
fixtures, verifies actual normal and optimized CLI executions, and runs
the independent named-syntax and soundness-defect audits. A failed check
causes a nonzero process exit. Run the harness without -O; it runs the
delivered checker with -O itself.

If desired, check the delivered files before regenerating outputs:

    sha256sum -c MANIFEST.sha256

Reproduction rewrites results, some examples, and timestamps. Consequently
their new hashes need not match the original delivery manifest. The frozen
comparator and source-fixture hashes are checked separately by the scripts.

To rebuild the already supplied PDF:

    python3 build.py

This requires pdfLaTeX and the packages named in report.tex; it does not
download them. To produce a fresh manifest and ZIP after deliberate changes:

    python3 package.py

READING GUIDE

report.pdf / report.tex / sections/
    Complete mathematical construction, comparison, written proofs,
    limitations, bibliography, and listings of both measured programs.

checker.py
    Complete proof-clock acceptance boundary: JSON parsing, sorted syntax,
    capture-free opening, all primitive rules, scope discipline, verdicts,
    and failure exit status. Imports only json and sys.

checker_combined.py
    Complete companion implementation combining compatible reductions
    already present in the drafts. It retains a global name frontier.

FORMAT.txt
    Human-readable guide to JSON syntax, proof order, and clock labels.

transport.py
    Untrusted translator from the exact frozen paired-coordinate declared-
    supply checker. Its output is verified separately by checker.py.

comparison/
    Thirteen unmodified current checker sources, the upstream metric, and
    source provenance including pinned commit, archive hashes, and paths.

validation/
    Transport tests, scope boundaries, source fixtures with provenance,
    independent named-syntax oracle, parser tests, and defective controls.
    INDEPENDENT_REVIEW.txt explains the separate oracle's audit boundary.

examples/
    Small public examples, 52 indexed transported positive instances, and
    independently designed positive and negative cases.

results/
    Machine-readable metrics, individual validation outcomes, source and
    output hashes, allocation traces, build log, and PDF inspection record.

ATTRIBUTION.txt / LICENSE_SOURCE.txt
    The inherited material and the new contributions are distinguished
    explicitly; copied upstream material retains its source license.

REFERENCE SNAPSHOT

https://github.com/VladimirReshetnikov/ProveIt/tree/18e3b9b4071c76fb9e817a2eb50d7b12f7246d18/docs/drafts

All six current ZIP archives were inspected. Their older embedded tables
refer to ten programs; this package compares all thirteen current top-level
checker*.py files. Local comparison and validation do not fetch the repository.

SCOPE OF THE CLAIM

The new primary mechanism is a simplification of the proof presentation,
under the disclosed complete-checker metric. It does not prove an absolute
smallest axiomatization, nor a reduction of the numerical axiom basis.
The fixed-seed obstruction concerns direct term definitions on the same
numerical domain; it does not exclude every possible graph or domain
interpretation. The scalar iterator route remains conditional and unsolved.

The mathematical algorithm is considered with unbounded resources. A real
Python process has parser, recursion, memory, and integer-conversion limits.
Open root goals are allowed only with parameter labels below the initial
clock threshold. The exact completeness theorem concerns syntactically
closed goals; any ordinary theorem can be represented by its universal
closure. Negative JSON integers are variable names, never negative numbers.
