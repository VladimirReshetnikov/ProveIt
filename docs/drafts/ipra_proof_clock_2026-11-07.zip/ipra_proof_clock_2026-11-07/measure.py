"""Reproduce the disclosed whole-program comparison using the frozen metric."""
import csv
import hashlib
import importlib.util
import json
import platform
from pathlib import Path
import tempfile

ROOT = Path(__file__).resolve().parent
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def run():
    path = ROOT / 'comparison/source_measure.py'
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    if hashlib.sha256(path.read_bytes()).hexdigest() != manifest['measurement_source']['sha256']:
        raise ValueError('Modified frozen measurement source')
    spec = importlib.util.spec_from_file_location('frozen_source_measure', path)
    metric = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(metric)
    rows = []
    for entry in manifest['programs']:
        measured = metric.metrics(ROOT / 'comparison' / entry['local_file'])
        if measured['sha256'] != entry['sha256']:
            raise ValueError('Modified frozen comparator: ' + entry['label'])
        rows.append({**entry, **measured})
    envelope = {key: min(row[key] for row in rows) for key in FIELDS}
    clock = metric.metrics(ROOT / 'checker.py')
    combined = metric.metrics(ROOT / 'checker_combined.py')
    with tempfile.TemporaryDirectory() as directory:
        p = Path(directory) / 'clock_exception.py'
        p.write_text((ROOT / 'checker.py').read_text().replace('    except:\n', '    except Exception:\n'))
        exception = metric.metrics(p)
    for label, candidate in [('clock', clock), ('combined', combined), ('clock_except_Exception', exception)]:
        if not all(candidate[key] < envelope[key] for key in FIELDS):
            raise ValueError('Candidate does not beat every coordinate: ' + label)
    result = {'python': platform.python_version(), 'implementation': platform.python_implementation(),
              'commit': manifest['commit'], 'archive_count': len(manifest['archives']),
              'program_count': len(rows), 'envelope': envelope, 'programs': rows,
              'clock': clock, 'combined': combined, 'clock_except_Exception': exception,
              'strict_improvement': True,
              'metric_source_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    results = ROOT / 'results'
    results.mkdir(exist_ok=True)
    (results / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    with (results / 'comparison.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, ('label', *FIELDS, 'sha256'), extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows + [{'label': 'proof_clock', **clock}, {'label': 'combined', **combined}])
    macros = []
    for prefix, data in [('Base', envelope), ('Clock', clock), ('Combined', combined), ('StrictException', exception)]:
        for suffix, field in [('Tokens', 'normalized_tokens'), ('AST', 'ast_nodes'), ('Bytes', 'normalized_bytes')]:
            macros.append('\\newcommand{\\' + prefix + suffix + '}{' + str(data[field]) + '}')
    (results / 'summary.tex').write_text('\n'.join(macros) + '\n')
    table = ['\\begin{center}\\small', '\\begin{tabular}{llrrr}', '\\toprule',
             'Archive & Top-level checker & Tokens & AST & Bytes\\\\', '\\midrule']
    for row in rows:
        package, file = row['label'].split('__', 1)
        package = package.replace('_', r'\_')
        file = file.replace('_', r'\_')
        table.append(f"{package} & \\texttt{{{file}}} & {row[FIELDS[0]]} & {row[FIELDS[1]]} & {row[FIELDS[2]]}\\\\")
    table += ['\\bottomrule', '\\end{tabular}', '\\end{center}']
    (results / 'comparison_table.tex').write_text('\n'.join(table) + '\n')
    return result


if __name__ == '__main__':
    data = run()
    print(json.dumps({key: data[key] for key in ('python', 'archive_count', 'program_count', 'envelope',
                                               'clock', 'combined', 'clock_except_Exception', 'strict_improvement')}, indent=2))
