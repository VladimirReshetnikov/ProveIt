"""Small utilities shared by the untrusted validation programs."""

from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
RESULTS = ROOT / "results"


def canonical_bytes(packet):
    return json.dumps(packet, separators=(",", ":"), sort_keys=True).encode("utf-8")


def digest(data):
    return sha256(data).hexdigest()


def module(source, name="validation_kernel"):
    namespace = {"__name__": name}
    exec(compile(source, name, "exec"), namespace)
    return namespace


def verdict(namespace, packet):
    try:
        namespace["p"] = deepcopy(packet)
        return bool(namespace["check"](namespace["p"].pop(), []))
    except BaseException:
        # Match the kernel CLI's complete exception-to-REJECT behavior.
        return False


def declared_verdict(source, packet):
    """Run a declared-supply checker in a fresh namespace for one packet."""
    namespace = module(source, "declared_supply_validation")
    try:
        stream = deepcopy(packet)
        namespace["take"] = stream.pop
        return bool(namespace["check"](stream.pop(), []))
    except BaseException:
        return False


def write_result(name, data):
    RESULTS.mkdir(exist_ok=True)
    (RESULTS / name).write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
