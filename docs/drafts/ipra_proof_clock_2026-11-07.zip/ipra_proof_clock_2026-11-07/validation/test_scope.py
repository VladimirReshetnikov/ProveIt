"""Independent scope boundaries and a mutation-sensitive freshness attack."""

import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from validation.common import module, verdict, write_result


class ScopeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = (ROOT / "checker.py").read_text()
        cls.summary = {"leaf_scope_checks": 0, "capture_attack": {}}

    @classmethod
    def tearDownClass(cls):
        write_result("scope.json", cls.summary)

    def test_atom_boundaries(self):
        kernel = module(self.source)
        for remaining in range(12):
            for atom in range(-16, 17):
                for depth in range(8):
                    kernel["p"] = [None] * remaining
                    encoded_depth = 2 * depth + 1
                    expected = (atom < -remaining or atom >= 0) and atom < encoded_depth
                    try:
                        actual = kernel["inst"](atom, d=encoded_depth) == atom
                    except BaseException:
                        actual = False
                    self.assertEqual(actual, expected, (remaining, atom, depth))
                    self.summary["leaf_scope_checks"] += 1
        self.assertEqual(self.summary["leaf_scope_checks"], 3168)

    def test_capture_attack_and_mutant(self):
        # False open formula: Q_x exists z (pred(x) = a), where a is -3.
        # At a=0 its base holds but x=2 fails. Under the inner E binder,
        # coordinate 3 denotes x; in the recursor update it denotes v.
        # Three instructions reserve -3 at the root. The defective order
        # permits -3 and then captures it as the Q-introduction parameter.
        name = -3
        predecessor = [3, 0, 3]
        goal = [[[predecessor, name], [0, 0], [0, 0]]]
        attack = [[], [0], [], goal]
        self.assertEqual(
            json.loads((ROOT / "examples/scope_capture_attack.json").read_text()), attack
        )
        self.assertFalse(verdict(module(self.source), attack))
        fragment = "    match (inst(a), p.pop()):"
        self.assertEqual(self.source.count(fragment), 1)
        mutant_source = self.source.replace(
            fragment, "    instruction = p.pop()\n    match (inst(a), instruction):"
        )
        self.assertTrue(verdict(module(mutant_source, "deliberately_unsound_mutant"), attack))
        self.summary["capture_attack"] = {
            "honest_rejects": True,
            "consume_before_validate_mutant_accepts": True,
            "packet": "examples/scope_capture_attack.json",
        }


if __name__ == "__main__":
    unittest.main()
