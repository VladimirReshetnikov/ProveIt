"""Run every package-local validation suite and write results/validation.json.

Usage from any working directory: python3 /path/to/package/validation/run.py
The harness runs normally; test_clock also executes the measured checker with
python -O on every positive frozen-fixture instance.
"""

import json
from pathlib import Path
import platform
import sys
import time
import unittest

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))

from validation.common import write_result


def main():
    if sys.flags.optimize:
        raise SystemExit("Run this test harness without -O; it tests checker.py with -O itself.")
    from validation import test_clock, test_scope, test_named

    suite = unittest.TestSuite()
    loader = unittest.defaultTestLoader
    suite.addTests(loader.loadTestsFromModule(test_clock))
    suite.addTests(loader.loadTestsFromModule(test_scope))
    suite.addTest(unittest.FunctionTestCase(
        test_named.main, description="Independent named-syntax oracle audit"
    ))
    start = time.monotonic()
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    summary = {
        "successful": result.wasSuccessful(),
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "unittest_cases": result.testsRun,
        "failures": len(result.failures),
        "errors": len(result.errors),
        "skipped": len(result.skipped),
        "elapsed_seconds": round(time.monotonic() - start, 3),
        "artifacts": ["results/transport.json", "results/combined.json", "results/direct_rejections.json",
                      "results/scope.json", "results/independent.json"],
    }
    write_result("validation.json", summary)
    print(json.dumps(summary, indent=2))
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
