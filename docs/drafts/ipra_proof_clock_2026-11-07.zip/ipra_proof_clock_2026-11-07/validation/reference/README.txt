Frozen reference certificates

These fixtures are copied byte-for-byte from the archive and commit identified
in index.json. Every row has a unique indexed local filename, including the
two repeated source paths. Exact-byte SHA-256 hashes are verified by the tests.

There are 57 fixture instances: 52 positive and 5 negative. The 52 positives
represent 50 distinct original source paths and 49 distinct JSON packets. The
translated corpus preserves all 52 instances and likewise has 49 distinct
packets. Do not describe these as 52 independent theorems.

The negative reference rows are expected to be rejected before transport;
reserved names in the source format have a different meaning from proof-clock
name thresholds, so blindly feeding these rows to checker.py would not be a
valid comparison.

All runtime tests are offline and use only files inside this package.
The source archive itself is not needed. See ../../LICENSE_SOURCE.txt for
the applicable source license (at the package root).
