"""Untrusted, offline validation tools; none is part of the measured kernel."""
