"""Create a source/data/PDF ZIP and SHA-256 manifest with stable ZIP metadata."""
from hashlib import sha256
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "MANIFEST.sha256"
IGNORED_SUFFIXES = {".aux", ".log", ".out", ".toc", ".synctex", ".pyc", ".zip"}


def included(path):
    relative = path.relative_to(ROOT)
    return (path.is_file() and path != MANIFEST
            and not any(part.startswith(".") or part == "__pycache__" for part in relative.parts)
            and path.suffix not in IGNORED_SUFFIXES)


def main():
    paths = sorted(p for p in ROOT.rglob("*") if included(p))
    for required in ("report.pdf", "report.tex", "checker.py", "results/validation.json"):
        if ROOT / required not in paths:
            raise SystemExit("Required deliverable missing: " + required)
    MANIFEST.write_text("".join(
        sha256(p.read_bytes()).hexdigest() + "  " + p.relative_to(ROOT).as_posix() + "\n"
        for p in paths
    ), encoding="utf-8")
    target = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(paths + [MANIFEST]):
            entry = zipfile.ZipInfo(ROOT.name + "/" + path.relative_to(ROOT).as_posix(),
                                    date_time=(2026, 11, 7, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.create_system = 3
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED,
                             compresslevel=9)
    with zipfile.ZipFile(target) as archive:
        corrupt = archive.testzip()
        if corrupt is not None:
            raise SystemExit("Archive CRC failure: " + corrupt)
    print(target)
    print("Files:", len(paths) + 1)
    print("Bytes:", target.stat().st_size)
    print("SHA-256:", sha256(target.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
