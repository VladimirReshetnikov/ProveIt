"""Recompute the comparison and all validation evidence without a network."""
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    if sys.flags.optimize:
        raise SystemExit("Run reproduce.py without -O; the harness tests -O itself.")
    if sys.version_info < (3, 10):
        raise SystemExit("Python 3.10 or newer is required.")
    print("Reproducing with", platform.python_implementation(), platform.python_version(), flush=True)
    if platform.python_implementation() != "CPython" or platform.python_version() != "3.12.14":
        print("The reported exact normalization counts used CPython 3.12.14.", flush=True)
    for script in ("measure.py", "validation/run.py"):
        subprocess.run([sys.executable, "-B", str(ROOT / script)], cwd=ROOT, check=True)
    print("PASS: frozen identities, complete-program comparison, and all validation suites.")
    print("See results/metrics.json and results/validation.json for the summary.")


if __name__ == "__main__":
    main()
