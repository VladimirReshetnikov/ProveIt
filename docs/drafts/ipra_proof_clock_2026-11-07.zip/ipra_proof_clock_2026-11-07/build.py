"""Compile the complete LaTeX report; no network is used."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    if not shutil.which('pdflatex'):
        raise SystemExit('pdfLaTeX is required to rebuild the already supplied PDF.')
    logs = []
    for _ in range(3):
        result = subprocess.run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error', 'report.tex'],
                                cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        logs.append(result.stdout)
        if result.returncode:
            (ROOT / 'results/build_log.txt').write_text('\n'.join(logs))
            raise SystemExit(result.stdout[-6000:])
    (ROOT / 'results/build_log.txt').write_text('\n'.join(logs))
    print('Built report.pdf')


if __name__ == '__main__':
    main()
