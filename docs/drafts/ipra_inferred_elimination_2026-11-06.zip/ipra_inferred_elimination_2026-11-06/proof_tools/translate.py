"""Untrusted, sequent-preserving translators between explicit and inferred E elimination.

No checker imports this file. Both output certificates are rechecked. The old
module must be the supplied sorted canonical checker; the new module is the
packaged candidate checker. All expressions and all rules besides existential
elimination and the internal successor check are unchanged.
"""


def to_inferred(data, old, new):
    old.check(data)

    def proof(p, g):
        match p:
            case ["lam", a, q]:
                return ["lam", a, proof(q, [*map(old.subst, g), a])]
            case ["pack", a, q]:
                h = ["=", 0, old.subst(a, formula=False)]
                return ["pack", a, proof(q, [*map(old.subst, g), h])]
            case ["use", p, a, q]:
                e = old.infer(p, g)
                major = proof(p, g)
                if e[0] == "ex":
                    return ["use", major, proof(q, [*map(old.subst, g), e[1]])]
                return ["use", major, a, proof(q, g)]
            case ["nat", a, p]:
                return ["nat", a, proof(p, g)]
            case _:
                return p

    g, a, p = data
    result = [g, a, proof(p, g)]
    new.check(result)
    return result


def to_explicit(data, new, old):
    new.check(data)

    def proof(p, g):
        match p:
            case ["lam", a, q]:
                return ["lam", a, proof(q, [*map(new.subst, g), a])]
            case ["pack", a, q]:
                h = ["=", 0, new.subst(a, formula=False)]
                return ["pack", a, proof(q, [*map(new.subst, g), h])]
            case ["use", p, *args]:
                e = new.infer(p, g)
                major = proof(p, g)
                if e[0] == "ex":
                    q, = args
                    local = [*map(new.subst, g), e[1]]
                    a = new.subst(new.infer(q, local), [None, -1])
                    return ["use", major, a, proof(q, local)]
                a, q = args
                return ["use", major, a, proof(q, g)]
            case ["nat", a, p]:
                return ["nat", a, proof(p, g)]
            case _:
                return p

    g, a, p = data
    result = [g, a, proof(p, g)]
    old.check(result)
    return result
