A SMALLER COMPLETE PRESENTATION OF INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov, 6 November 2026

START HERE

  report.pdf                 Complete mathematical paper.
  report.tex and sections/   Complete LaTeX source.
  checker.py                 Entire trusted acceptance program.
  FORMAT.txt                 Numerical binding and certificate syntax.

RESULT

The selected complete checker has 712 executable AST nodes, 664 significant
tokens, and 2,150 normalized UTF-8 source bytes. It has 2,501 original bytes.
The coordinatewise minima across 151 distinct archived checker sources are
750 AST nodes, 703 tokens, 2,265 normalized bytes, and 2,574 original bytes.

The comparison includes all six archives currently in ProveIt/docs/drafts at
commit 473749742630b5a7779e7c3a36cd23ebd9cb53b5, their optional cores, and
all nested Python sources with top-level check and infer definitions.
All frozen source hashes and archive provenance are included.

The theory uses finite initialized recursion; equality; a guarded universal
binder; unary existence; equation induction; and zero/successor cases for
other formulas. The paper lists every primitive logical rule, computation
schema, numerical rule, and side condition. It derives full intuitionistic
logic and every source quantifier-free induction instance.

The ordinary first-order realization explicitly includes numerical coverage
and a bridge from 0=S0 to genuine falsity. It is bi-interpretable with full
first-order intuitionistic primitive recursive arithmetic with quantifier-free
induction. Both interpretation domains are the whole numerical sort and both
internally definable round-trip isomorphisms are equality. The native calculus
is a faithful certificate presentation of that ordinary theory.

The new checker combines the sorted-certificate syntax with inferred
existential conclusions and recognition of successor by validated arity.
Deleting the fresh numerical variable through partial substitution both
infers the existential conclusion and enforces its eigenvariable condition.
The final file also simplifies a once-used guard and the CLI wrapper.

The explicit-error control retains a named numerical guard and the longer
error interface. At 737 AST nodes, 688 tokens, and 2,245 normalized bytes, it
already beats all three archived syntax minima. The substantive result
therefore does not depend on the final interface simplifications.

This is a finite, reproducible implementation comparison. It is not a proof
of absolute minimality. The mathematical basis is inherited with attribution
from the supplied draft series. No Lean or Rocq formalization is claimed.

RUN

Python 3.10+ and its standard library suffice.
The frozen measurement files record the exact Python version used.

  python3 checker.py examples/direct_zero_plus_n.json
  python3 reproduce.py
  python3 reproduce.py --pdf

The first command prints ACCEPT. The second reruns all computational checks
without network access. The third also builds the PDF and ZIP using pdfLaTeX.

VALIDATION

  26,245 independent finite implementation checks, no failures.
  149 frozen positive certificates, checked old -> new -> old.
  All 149 round trips reconstruct the exact source certificate.
  A separate rule interpreter validates all 149 new certificates,
    covering 5,621 proof nodes, without importing the candidate checker.
  Normal and optimized (-O) CLI behavior are both exercised.

The independent substitution oracle uses fresh named binders, not the
candidate's de Bruijn substitution implementation. Tests include escaping
witness variables, nested binders, malformed syntax, incorrect rule arity,
quantified-induction rejection, and harmless hypothesis lookup aliases.
These are finite implementation tests, not a foundational proof of Python.

CONTENTS

  comparison/census/         151 frozen complete source versions.
  comparison/provenance.json Archive/member hashes and pinned source links.
  comparison/controls/       Explicit-error 737-node control.
  comparison/sorted_core.py  Frozen reference checker for proof translations.
  validation/audit.py        Independent grammar/binding/certificate audit.
  validation/certificate_oracle.py  Independent explicit-rule interpreter.
  validation/reference_corpus/     149 frozen old certificates.
  validation/corpus/               Their 149 translated certificates.
  validation/corpus_provenance.json Certificate hashes and source paths.
  proof_tools/translate.py   Untrusted bidirectional proof translations.
  examples/                 Representative arithmetic/logical certificates.
  results/                  Reproducible measurements and audit outcomes.
  measure.py                Static whole-program measurement.
  replay.py                 Frozen bidirectional proof rechecking.
  reproduce.py              Offline reproduction driver.
  build.py                  PDF, hash manifest, and ZIP builder.
  MANIFEST.sha256            Hashes of all other packaged files.

TRUST

Only checker.py, Python, and its standard JSON parser participate in native
acceptance. Proof generators, translators, measurement tools, and independent
oracles are not imported by checker.py. Contexts are explicit: a certificate
with assumptions proves a conditional sequent. Empty contexts give theorems;
unbound numerical indices are free parameters.
