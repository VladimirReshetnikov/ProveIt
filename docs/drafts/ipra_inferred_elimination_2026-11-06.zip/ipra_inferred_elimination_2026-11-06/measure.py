"""Measure complete standalone checker sources without importing them.

All executable syntax is counted, including syntax checking, axiom/rule
construction, the constructor tables, imports, JSON input and CLI behavior.
Comments and docstrings are excluded from syntax metrics. The Python runtime
and standard JSON library are common platform assumptions for all rows.
"""

import ast
import copy
import hashlib
import io
import json
import platform
import tokenize
from pathlib import Path


ROOT = Path(__file__).resolve().parent
FIELDS = ("ast_nodes", "tokens", "normalized_bytes", "source_bytes")
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}


def docstrings(tree):
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef,
                             ast.AsyncFunctionDef, ast.ClassDef)) and node.body:
            first = node.body[0]
            if (isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant)
                    and isinstance(first.value.value, str)):
                yield first


def measure(path):
    data = path.read_bytes()
    source = data.decode("utf-8")
    original = ast.parse(source, filename=str(path))
    parsed = copy.deepcopy(original)
    removed = {id(node) for node in docstrings(parsed)}
    for node in ast.walk(parsed):
        if hasattr(node, "body") and isinstance(node.body, list):
            node.body = [child for child in node.body if id(child) not in removed]
    ranges = [((node.lineno, node.col_offset), (node.end_lineno, node.end_col_offset))
              for node in docstrings(original)]
    tokens = [token for token in tokenize.generate_tokens(io.StringIO(source).readline)
              if token.type not in IGNORED and not any(
                  start <= token.start and token.end <= end for start, end in ranges)]
    normalized = (ast.unparse(parsed) + "\n").encode("utf-8")
    return {"path": str(path.relative_to(ROOT)),
            "sha256": hashlib.sha256(data).hexdigest(),
            "ast_nodes": sum(1 for _ in ast.walk(parsed)),
            "tokens": len(tokens), "normalized_bytes": len(normalized),
            "source_bytes": len(data)}


def envelope(rows):
    return {field: min(row[field] for row in rows) for field in FIELDS}


def main():
    provenance = json.loads((ROOT / "comparison/provenance.json").read_text())
    census = []
    for source in provenance["source_files"]:
        row = measure(ROOT / source["path"])
        if row["sha256"] != source["sha256"]:
            raise ValueError("Frozen comparator was changed: " + row["path"])
        census.append(row)
    by_hash = {row["sha256"]: row for row in census}
    root_checkers = [{**entry, **by_hash[entry["sha256"]]}
                     for entry in provenance["root_checkers"]]
    candidate = measure(ROOT / "checker.py")
    controls = [measure(path) for path in sorted((ROOT / "comparison/controls").glob("*.py"))]
    all_envelope = envelope(census)
    result = {"python_version": platform.python_version(),
              "source_commit": provenance["commit"],
              "metric_definitions": {
                  "ast_nodes": "All AST nodes after removing docstrings, including context nodes.",
                  "tokens": "Original-source tokens excluding comments, docstrings and layout.",
                  "normalized_bytes": "UTF-8 ast.unparse(docstring-stripped AST), plus one newline.",
                  "source_bytes": "All original source bytes, including documentation and layout.",
                  "scope": "Entire executable checker; standard Python and JSON are common infrastructure.",
                  "limitation": "Finite source comparison, not a global complexity lower bound."},
              "candidate": candidate,
              "primary_six_lower_envelope": envelope([r for r in root_checkers if r["role"] == "primary"]),
              "root_checkers_lower_envelope": envelope(root_checkers),
              "all_sources_lower_envelope": all_envelope,
              "candidate_strictly_below_all_sources": {
                  field: candidate[field] < all_envelope[field] for field in FIELDS},
              "root_checkers": root_checkers, "census": census, "controls": controls}
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results/metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"candidate": candidate, "all_sources_lower_envelope": all_envelope,
                      "strict_improvement": result["candidate_strictly_below_all_sources"],
                      "distinct_sources": len(census)}, indent=2))
    if not all(result["candidate_strictly_below_all_sources"][f] for f in FIELDS[:3]):
        raise SystemExit("Candidate does not beat the declared syntax envelope")


if __name__ == "__main__":
    main()
