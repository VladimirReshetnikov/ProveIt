"""Build the PDF and a complete ZIP, excluding transient TeX/Python files."""

import hashlib
import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {".aux", ".log", ".out", ".toc", ".fls", ".fdb_latexmk", ".synctex.gz", ".pyc"}


def deliverables():
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts:
            continue
        if path.suffix in EXCLUDED_SUFFIXES or path.name == "MANIFEST.sha256":
            continue
        yield path


def package():
    files = list(deliverables())
    manifest = ROOT / "MANIFEST.sha256"
    manifest.write_text("".join(hashlib.sha256(p.read_bytes()).hexdigest() +
                                "  " + str(p.relative_to(ROOT)) + "\n" for p in files))
    target = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in [*files, manifest]:
            archive.write(path, arcname=str(Path(ROOT.name) / path.relative_to(ROOT)))
    print("Archive:", target)
    print("Archive SHA-256:", hashlib.sha256(target.read_bytes()).hexdigest())


def main():
    for _ in range(3):
        subprocess.run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                        "-file-line-error", "report.tex"], cwd=ROOT, check=True,
                       stdout=subprocess.DEVNULL)
    package()


if __name__ == "__main__":
    main()
