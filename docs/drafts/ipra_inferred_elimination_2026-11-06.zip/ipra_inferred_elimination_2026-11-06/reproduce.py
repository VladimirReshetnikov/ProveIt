"""Offline reproduction of every supplied computational claim."""

import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run(*arguments):
    subprocess.run([sys.executable, *arguments], cwd=ROOT, check=True)


def report_numbers():
    metrics = json.loads((ROOT / "results/metrics.json").read_text())
    audit = json.loads((ROOT / "results/audit.json").read_text())
    replay = json.loads((ROOT / "results/replay.json").read_text())
    oracle = json.loads((ROOT / "results/corpus_oracle.json").read_text())
    candidate = metrics["candidate"]
    if candidate["sha256"] != audit["sha256"] or candidate["sha256"] != replay["checker_sha256"]:
        raise ValueError("Results refer to different checker versions")
    if audit["failures"] or replay["status"] != "passed" or oracle["status"] != "passed":
        raise ValueError("Validation is not successful")
    values = {"CandidateAST": candidate["ast_nodes"],
              "CandidateTokens": candidate["tokens"],
              "CandidateNormalized": f'{candidate["normalized_bytes"]:,}',
              "CandidateSource": f'{candidate["source_bytes"]:,}',
              "CensusCount": len(metrics["census"]),
              "AuditTotal": f'{audit["total"]:,}',
              "ReplayCount": replay["unique_positive_certificates"],
              "OracleNodes": f'{oracle["proof_nodes"]:,}',
              "PythonVersion": metrics["python_version"]}
    (ROOT / "results/report_numbers.tex").write_text(
        "".join("\\newcommand{\\" + key + "}{" + str(value) + "}\n"
                for key, value in values.items()))
    labels = {"canonical_leaf": "Canonical leaf",
              "factored_checker": "Factored checker",
              "indexed_kernel": "Indexed kernel",
              "shared_rules": "Shared rules",
              "small_kernel": "Small kernel",
              "sorted_certificates": "Sorted certificates, public"}
    lines = [r"\begin{tabular}{@{}lrrr@{}}", r"\toprule",
             r"Complete acceptance program & AST & Tokens & Norm.\ bytes\\", r"\midrule"]

    def row(label, data, bold=False):
        values = [f'{data[k]:,}' for k in ("ast_nodes", "tokens", "normalized_bytes")]
        if bold:
            label = r"\textbf{" + label + "}"
            values = [r"\textbf{" + value + "}" for value in values]
        lines.append(" & ".join([label, *values]) + r"\\")

    for entry in metrics["root_checkers"]:
        if entry["role"] == "primary":
            label = next(v for k, v in labels.items() if k in entry["archive"])
            row(label, entry)
    core = next(r for r in metrics["root_checkers"] if r["member"].endswith("/checker_core.py"))
    row("Sorted certificates, canonical", core)
    minimum_norm = min(metrics["census"], key=lambda r: r["normalized_bytes"])
    row("Smallest normalized-byte control", minimum_norm)
    lines.append(r"\midrule")
    row("All 151 sources: lower envelope", metrics["all_sources_lower_envelope"])
    row("New explicit-error control", metrics["controls"][0])
    row("Selected new checker", candidate, True)
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    (ROOT / "results/comparison_table.tex").write_text("\n".join(lines) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pdf", action="store_true")
    parser.add_argument("--report-numbers-only", action="store_true")
    options = parser.parse_args()
    if not options.report_numbers_only:
        run("measure.py")
        run("validation/audit.py", "checker.py", "--out", "results/audit.json")
        run("replay.py")
        run("validation/certificate_oracle.py", "validation/corpus", "results/corpus_oracle.json")
    report_numbers()
    if options.pdf:
        run("build.py")
    print("All requested reproduction steps completed.")


if __name__ == "__main__":
    main()
