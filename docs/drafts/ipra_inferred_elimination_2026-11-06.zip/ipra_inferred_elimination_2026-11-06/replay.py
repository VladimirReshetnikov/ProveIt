"""Recheck the frozen bidirectional proof-translation corpus offline."""

import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    old = load("sorted_baseline", ROOT / "comparison/sorted_core.py")
    new = load("inferred_checker", ROOT / "checker.py")
    trans = load("proof_translation", ROOT / "proof_tools/translate.py")
    provenance = json.loads((ROOT / "validation/corpus_provenance.json").read_text())
    records = []
    for entry in provenance["records"]:
        source = ROOT / entry["reference_file"]
        target = ROOT / entry["translated_file"]
        if hashlib.sha256(source.read_bytes()).hexdigest() != entry["sha256"]:
            raise ValueError("Reference certificate was modified: " + entry["reference_file"])
        if hashlib.sha256(target.read_bytes()).hexdigest() != entry["translated_sha256"]:
            raise ValueError("Translated certificate was modified: " + entry["translated_file"])
        original = json.loads(source.read_text())
        translated = json.loads(target.read_text())
        forward = trans.to_inferred(original, old, new)
        reverse = trans.to_explicit(translated, new, old)
        if forward != translated or reverse != original or original[:2] != translated[:2]:
            raise ValueError("Proof round trip changed: " + entry["file"])
        records.append({"file": entry["file"], "roundtrip_exact": True})
    report = {"status": "passed",
              "checker_sha256": hashlib.sha256((ROOT / "checker.py").read_bytes()).hexdigest(),
              "unique_positive_certificates": len(records), "records": records,
              "meaning": "Each frozen source is checked by the sorted core; each translated proof is checked by the candidate; reverse translation is exactly the frozen source."}
    (ROOT / "results/replay.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "records"}, indent=2))


if __name__ == "__main__":
    main()
