iPRA with a declared parameter bound
====================================
Prepared for Vladimir Reshetnikov, 7 November 2026.

Result
------
The complete open-root checker uses 455 normalized significant Python tokens,
468 AST nodes, and 1332 normalized UTF-8 bytes under CPython 3.12.14. It is
strictly below the coordinatewise minima 457 / 469 / 1352 of the ten current
top-level checker programs in the six supplied archives, even including the
closed-root comparator. An expanded 50-program inventory has the same minima.

The smaller closed-sentence companion has 449 tokens / 461 AST nodes /
1313 normalized bytes. It presents the same ordinary theory through closed
sentences and universal closures, but rejects raw free-parameter roots.
The arbitrary-open interface remains the main new declared-bound result.

The new idea is an untrusted initial parameter-bound header. Every used name
is checked against the current floor, and each local numerical scope lowers
that floor before allocating its eigenparameter. This removes minimum-name
collection while keeping arbitrary free-parameter roots and serializable
references to local variables. It does not remove syntax traversal.

The arithmetic/logical calculus and bi-interpretation are inherited and
credited. This is a small complete-checker improvement, not a global minimality
theorem or a new combinator foundation. See ATTRIBUTION.txt and report.pdf.

Contents
--------
report.tex + sections/         Complete paper source, including all primitive
                              rules and schemas, logic reconstruction,
                              quantifier-free reflection, internal round-trip
                              isomorphisms, and further research questions.
report.pdf                    Compiled paper.
checker.py                    Entire open-root acceptance program; imports only
                              Python standard-library json and sys.
checker_closed.py             Smaller complete sentence-only program; no header,
                              initial floor zero, first local name -1.
FORMAT.txt                    Exact public certificate and numerical syntax.
examples/                     Four accepted examples and one rejected attack.
comparison/                   Unchanged current sources, hashes, archive
                              provenance, normalization, expanded inventory.
results/                      Reproduced complete-program measurements.
validation/                   Two independent finite validation tracks, a
                              scope-aware certificate compiler, named oracle,
                              45 public source theorems, 21 internal sequents,
                              focused cases, and complete outcomes.
reproduce.py                  Repeat measurement and both main validation
                              tracks plus the closed-companion validation.
build.py                      Remeasure and compile the paper twice.
package.py                    Create the ZIP and standalone PDF, with archive
                              CRC and per-file SHA256 verification.
SHA256SUMS                    Hashes of every packaged file except this list.
LICENSE_SOURCE.txt            License of the inherited ProveIt sources.

Quick start
-----------
Use Python 3.10 or later to execute the checker (structural pattern matching
is required). Use CPython 3.12.14 to reproduce the exact reported normalization
counts. No third-party Python packages are required for checking or testing.

    python3 checker.py examples/zero_reflexivity.json
    python3 checker.py examples/closure_reflexivity.json
    python3 checker.py examples/equation_induction.json
    python3 checker.py examples/free_parameter.json

Each command prints ACCEPT and exits with status zero.

    python3 checker.py examples/capture_rejected.json

This prints REJECT and exits with status one. It is deliberately invalid.

    python3 reproduce.py

This recomputes hashes and metrics and reruns the finite implementation checks.
The original comparison files are never modified by these scripts.

    python3 build.py

This additionally requires pdflatex and the standard TeX packages listed in
report.tex. The compiled paper is report.pdf. Normal Python execution and
python -O have the same checker behavior: acceptance does not use assert.

    python3 package.py

This writes an archive and a standalone copy of the PDF beside this folder.
LaTeX auxiliary files and Python caches are excluded from the archive.

Pinned baseline
---------------
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 8b00e6ea50c664476e3a3289a78287946e5e0a34
Directory: docs/drafts

The two identically dated integrated archives are distinguished as Integrated
A (unsuffixed filename) and Integrated B (filename ending " (1).zip") in the
paper table. All archive SHA256 hashes are in comparison/manifest.json.

Interpretation and verification status
--------------------------------------
The native kernel faithfully presents the ordinary first-order theory T_cov.
The paper supplies ordinary term interpretations T_cov <-> iPRA, preserving
all ordinary logical symbols, with whole numerical domains and identity
graphs for both composite isomorphisms. A nonhomomorphic encoding of native
connectives is kept separate from that conventional bi-interpretation.

Mathematical soundness/completeness arguments are supported by independent
finite tests. They have not been formalized in Lean or Rocq. The Python host
and its standard libraries are the same common trust boundary as in the
compared drafts. Finite resource exhaustion may reject a large valid proof.

The internal-sequent fixtures have external assumptions. They are explicitly
not public theorem certificates and are not passed to the public CLI as such.
