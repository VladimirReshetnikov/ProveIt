"""Measure the complete kernel against the exact current frozen sources."""
import csv
import json
import platform
from pathlib import Path
from comparison.source_measure import metrics

ROOT = Path(__file__).resolve().parent
KEYS = ("normalized_tokens", "ast_nodes", "normalized_bytes")


def main():
    manifest = json.loads((ROOT / "comparison/manifest.json").read_text())
    rows = []
    for item in manifest["programs"]:
        result = metrics(ROOT / "comparison" / item["local_file"])
        if result["sha256"] != item["sha256"]:
            raise ValueError("Changed comparison source: " + item["label"])
        rows.append({**item, **result})
    expanded = json.loads((ROOT / "comparison/expanded_manifest.json").read_text())
    distinct = {}
    for item in expanded:
        if item["sha256"] not in distinct:
            result = metrics(ROOT / "comparison" / item["local_file"])
            if result["sha256"] != item["sha256"]:
                raise ValueError("Changed expanded source: " + item["local_file"])
            distinct[item["sha256"]] = result
    candidate = metrics(ROOT / "checker.py")
    closed = metrics(ROOT / "checker_closed.py")
    minimum = {key: min(row[key] for row in rows) for key in KEYS}
    open_minimum = {key: min(row[key] for row in rows if row["interface"] == "open") for key in KEYS}
    expanded_minimum = {key: min(row[key] for row in distinct.values()) for key in KEYS}
    result = {
        "python": platform.python_version(), "implementation": platform.python_implementation(),
        "commit": manifest["commit"], "archive_count": len(manifest["archives"]),
        "top_level_program_count": len(rows), "expanded_source_paths": len(expanded),
        "expanded_distinct_programs": len(distinct), "coordinatewise_minimum": minimum,
        "open_root_minimum": open_minimum, "expanded_minimum": expanded_minimum,
        "candidate": candidate, "closed_companion": closed,
        "strict_improvement": {k: candidate[k] < minimum[k] for k in KEYS},
        "closed_strict_improvement": {k: closed[k] < minimum[k] for k in KEYS},
        "programs": rows,
    }
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results/metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    with (ROOT / "results/metrics.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, ["label", "interface", *KEYS, "sha256"], extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
        writer.writerow({"label": "declared_bound/checker.py", "interface": "open", **candidate})
        writer.writerow({"label": "declared_bound/checker_closed.py", "interface": "closed", **closed})
    values = {"NewTokens": candidate[KEYS[0]], "NewAST": candidate[KEYS[1]], "NewBytes": candidate[KEYS[2]],
              "BaseTokens": minimum[KEYS[0]], "BaseAST": minimum[KEYS[1]], "BaseBytes": minimum[KEYS[2]],
              "ClosedTokens": closed[KEYS[0]], "ClosedAST": closed[KEYS[1]], "ClosedBytes": closed[KEYS[2]]}
    (ROOT / "results/numbers.tex").write_text("".join("\\newcommand{\\" + key + "}{" + str(value) + "}\n" for key, value in values.items()))
    labels = {
        "ipra_arity_parameters_2026-11-07": "Arity parameters",
        "ipra_combined_2026-11-07": "Combined",
        "ipra_fresh_arity_2026-11-07": "Fresh arity",
        "ipra_integrated_2026-11-07": "Integrated A",
        "ipra_integrated_2026-11-07_1": "Integrated B",
        "ipra_scope_2026-11-07": "Scope",
    }
    variants = {"checker.py": "main", "checker_strict.py": "strict", "checker_closed.py": "closed", "checker_separate.py": "separate"}
    table = [r"\begin{tabular}{@{}llrrr@{}}", r"\toprule",
             r"Archive / program & Root & Tokens & AST nodes & Bytes\\", r"\midrule"]
    for row in rows:
        archive, name = row["label"].split("/")
        table.append(labels[archive] + " / " + variants[name] + " & " + row["interface"] + " & " + " & ".join(str(row[k]) for k in KEYS) + r"\\")
    table += [r"\midrule", "Coordinatewise minima & all & " + " & ".join(str(minimum[k]) for k in KEYS) + r"\\",
              r"\textbf{Declared bound} & open & " + " & ".join(r"\textbf{" + str(candidate[k]) + "}" for k in KEYS) + r"\\",
              r"\textbf{Closed companion} & closed & " + " & ".join(r"\textbf{" + str(closed[k]) + "}" for k in KEYS) + r"\\",
              r"\bottomrule", r"\end{tabular}"]
    (ROOT / "results/comparison_table.tex").write_text("\n".join(table) + "\n")
    if minimum != expanded_minimum or not all(result["strict_improvement"].values()) or not all(result["closed_strict_improvement"].values()):
        raise AssertionError("The stated strict whole-program comparison failed")
    print(json.dumps({k: v for k, v in result.items() if k != "programs"}, indent=2))


if __name__ == "__main__":
    main()
