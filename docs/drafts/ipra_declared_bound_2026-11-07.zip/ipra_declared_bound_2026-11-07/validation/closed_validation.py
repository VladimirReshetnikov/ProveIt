"""Validate the smaller closed-sentence companion without changing main results.

Run: python3 validation/closed_validation.py --checker checker_closed.py
The untrusted compiler uses floor zero, substitutes zero for auxiliary rigid
parameters, and alpha-renames locally bound proof parameters. Source statements
already closed are preserved; other source statements are clearly labeled as
their closed zero instances.
"""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys

from translate import Extractor, Compiler, integer_names, rename
from reference.named_reference import encode_tagged
from validate import DeclaredOracle, require, verify_reference, write, digest, reflexivity, exists


HERE = Path(__file__).resolve().parent


def translate_closed(source):
    source = encode_tagged(deepcopy(source))
    if len(source) != 2:
        raise ValueError('External-assumption sequents are not public theorems.')
    goal, stack = source
    extractor = Extractor()
    extractor.stack = deepcopy(stack)
    derivation = extractor.check(goal, [])
    if derivation is None:
        raise ValueError('The reference does not accept the source derivation.')
    mapping = {n: 0 for n in integer_names(source)}
    compiler = Compiler(0)
    compiler.k = 0
    proof = compiler.compile(derivation, mapping)
    closed_goal = rename(goal, mapping)
    require(not integer_names(closed_goal), 'compiler emitted an open root')
    return {
        'goal': closed_goal, 'stack': proof, 'document': [*proof, closed_goal],
        'source_goal_unchanged': not integer_names(goal),
        'source_goal': goal,
        'parameter_substitution': [{'parameter': n, 'image': 0} for n in sorted(integer_names(goal))],
        'allocations': compiler.allocations, 'final_floor': compiler.k,
    }


def verdict(module, goal, proof):
    try:
        module.k = 0
        stack = deepcopy(proof)
        module.take = stack.pop
        accepted = bool(module.check(deepcopy(goal), []))
        return accepted, module.k, len(stack)
    except Exception:
        return False, None, None


def reference_verdict(goal, proof):
    try:
        oracle = DeclaredOracle(0)
        oracle.k = 0
        oracle.stack = deepcopy(proof)
        accepted = bool(oracle.check(deepcopy(goal), []))
        return accepted, oracle.k, len(oracle.stack)
    except Exception:
        return False, None, None


def focused_cases():
    y, sy = -1, [-1]
    true, false = [0, 0], [0, [0]]
    ey = exists([1, 1])
    cases = []

    def add(name, goal, proof, expected):
        cases.append({'name': name, 'goal': goal, 'stack': proof, 'expected': expected})

    add('closed_reflexivity', true, reflexivity(0), True)
    add('native_Q_reflexivity', [[1, 1]], reflexivity(sy) + [[]], True)
    add('native_Q_existence_at_generated_parameter', [exists([1, 2])],
        reflexivity(sy) + [[sy], []], True)

    def rec(n):
        return [n, 0, [1]]

    matrix = [rec(1), 1]
    induction = [[], None, [[rec(y), y], [rec(sy), [1]]], []]
    add('equation_induction_recursion_identity', [matrix], induction, True)
    witness = [[0]]
    add('equation_induction_at_closed_compound_term', [rec(witness), witness],
        [[]] + induction + [[[matrix], witness]], True)
    add('root_parameter_is_not_declared', [-1, -1], reflexivity(-1), False)
    add('distant_root_parameter_is_not_declared', [-1000000, -1000000],
        reflexivity(-1000000), False)
    add('root_parameter_in_ghost_is_not_declared', [[0, 0], [-1, -1], [0, 0]],
        reflexivity(0) + [[0]], False)
    add('future_parameter_in_used_witness', ey, reflexivity(-1) + [[-1]], False)
    add('unused_future_witness_is_inert', exists(true), reflexivity(0) + [[-999]], True)
    add('closed_contradiction', false, [None], False)
    add('boolean_zero_alias_is_rejected', [False, 0], reflexivity(0), False)
    add('unbound_positive_coordinate', [1, 1], reflexivity(1), False)
    add('invalid_term_arity', [[0, [0, 0], 0], [0, 0]], [[]], False)
    add('malformed_annotation', [[0, 0], True, [0, 0]], reflexivity(0) + [[0]], False)
    add('unread_prefix_is_inert', true, [{'ignored': -999}] + reflexivity(0), True)

    def scoped(witness, constrained=False):
        major = exists([1, 0] if constrained else [1, 1])
        return reflexivity(0) + reflexivity(witness) + [[witness], [major, None]]

    earlier = scoped(0)
    add('generated_name_reused_by_later_sibling', true,
        scoped(-1) + earlier + [[true, true]], True)
    add('future_name_in_later_sibling', true,
        scoped(-2) + earlier + [[true, true]], False)
    leaking_goal = exists([1, 0])
    add('discharged_assumption_does_not_escape', leaking_goal,
        [None, [-1]] + scoped(0, constrained=True) + [[true, leaking_goal]], False)
    add('failed_major_reserves_only_names', [true], [None, [], [[[1, 0]], 0], []], True)

    inherited = json.loads((HERE / 'reference/source_audit_cases.json').read_text())
    for name in ('capture_by_illegal_positive_witness',
                 'freshness_collision_with_goal_parameter',
                 'freshness_collision_with_major_only_parameter'):
        source = next(c for c in inherited if c['name'] == name)
        add(name, encode_tagged(source['goal']), encode_tagged(source['proof']), False)
    body = exists([2, 2])
    major = exists([y, y])
    step = reflexivity(sy) + [[0], None, [major, None]]
    add('compound_induction_hypothesis_is_unavailable', [body], step + [[]], False)
    return cases


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', type=Path, default=HERE.parent / 'checker_closed.py')
    args = parser.parse_args()
    path = args.checker.resolve()
    spec = importlib.util.spec_from_file_location('closed_kernel', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    verify_reference()
    rows = json.loads((HERE / 'reference/source_corpus.json').read_text())
    records, public = [], []
    for index, row in enumerate(rows):
        if len(row['certificate']) != 2:
            continue
        result = translate_closed(row['certificate'])
        actual = verdict(module, result['goal'], result['stack'])
        expected = reference_verdict(result['goal'], result['stack'])
        require(actual[0] and actual == expected and actual[2] == 0,
                ('closed translated theorem', index, actual, expected))
        label = Path(min(row['source_aliases'], key=lambda x: (len(x), x))).stem
        folder = 'unchanged' if result['source_goal_unchanged'] else 'zero_instances'
        target = HERE / 'certificates' / 'closed' / folder / f'{index:03d}_{label}.json'
        write(target, result['document'])
        public.append((target, True, 'corpus/' + str(index)))
        records.append({k: result[k] for k in ('source_goal_unchanged', 'parameter_substitution',
                                              'allocations', 'final_floor')}
                       | {'source_id': index, 'source_aliases': row['source_aliases'],
                          'target': str(target.relative_to(HERE)), 'target_sha256': digest(target),
                          'accepted': True})
    focused = []
    for index, case in enumerate(focused_cases()):
        actual = verdict(module, case['goal'], case['stack'])
        expected = reference_verdict(case['goal'], case['stack'])
        require(actual[0] == expected[0] == case['expected'],
                ('closed focused example', case['name'], actual, expected))
        target = HERE / 'certificates' / 'closed' / 'focused' / f'{index:03d}.json'
        write(target, [*case['stack'], case['goal']])
        public.append((target, case['expected'], 'focused/' + case['name']))
        focused.append(case | {'target': str(target.relative_to(HERE)),
                               'target_sha256': digest(target), 'accepted': actual[0]})

    def run(job):
        document, expected, label, optimized = job
        result = subprocess.run([sys.executable, *(['-O'] if optimized else []),
                                 str(path), str(document)],
                                text=True, capture_output=True, timeout=20)
        require(result.returncode == (0 if expected else 1)
                and result.stdout.strip() == ('ACCEPT' if expected else 'REJECT'),
                ('closed public CLI', label, optimized, result.returncode,
                 result.stdout, result.stderr))
        return {'case': label, 'optimized': optimized, 'accepted': expected,
                'exit_code': result.returncode}

    jobs = [(*item, optimized) for item in public for optimized in (False, True)]
    with ThreadPoolExecutor(max_workers=6) as pool:
        cli = list(pool.map(run, jobs))
    report = {
        'status': 'all expected outcomes matched', 'python': platform.python_version(),
        'checker_sha256': digest(path), 'public_source_derived_certificates': len(records),
        'source_closed_goals_preserved': sum(r['source_goal_unchanged'] for r in records),
        'source_open_goals_replaced_by_closed_zero_instances':
            sum(not r['source_goal_unchanged'] for r in records),
        'focused_cases': len(focused),
        'focused_expected_accepts': sum(r['expected'] for r in focused),
        'focused_expected_rejects': sum(not r['expected'] for r in focused),
        'public_subprocess_executions': len(cli),
        'optimized_subprocess_executions': sum(r['optimized'] for r in cli),
        'source_commit': '8b00e6ea50c664476e3a3289a78287946e5e0a34',
        'corpus': records, 'focused': focused, 'public_cli': cli,
        'scope': 'Closed-sentence companion validation; no claim that the interface accepts arbitrary open roots.',
    }
    output = HERE / 'results' / 'closed_validation_results.json'
    write(output, report)
    summary = {k: v for k, v in report.items() if k not in ('corpus', 'focused', 'public_cli')}
    write(HERE / 'results' / 'closed_summary.json', summary)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
