"""Independent finite audit of the certificate-declared namespace floor.

This untrusted support script never participates in acceptance.  It reads,
but does not modify, the proposed checker and the frozen baseline checker.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import types

ROOT = Path(__file__).resolve().parents[1]
CANDIDATE = ROOT / "checker.py"
SOURCE = ROOT / "comparison/sources/ipra_scope_2026-11-07/checker.py"
OUT = Path(__file__).resolve().parent / "integerfloor_audit"


def load_source(text, name):
    module = types.ModuleType(name)
    exec(compile(text, name, "exec"), module.__dict__)
    return module


def run(module, document, source=False):
    stream = deepcopy(document)
    module.k = 0
    try:
        module.take = stream.pop
        module.k = ~abs(module.take())
        result = bool(module.check(module.take(), []))
        return result, module.k, len(stream)
    except Exception:
        return False, getattr(module, "k", None), len(stream)


def document(goal, execution, header):
    return list(reversed(execution)) + [goal, header]


def refl(term):
    computation = [[0, term, 0], term]
    return [[computation, [1, term]], [], []]


def existential(body, first=None, second=None):
    return [body, [0, 0] if first is None else first,
            [0, 0] if second is None else second]


def induction(header, parameter=None):
    rec = lambda x: [x, 0, [1]]
    matrix = [rec(1), 1]
    closure = [matrix]
    fresh = ~abs(header) - 1
    major = [rec(fresh), fresh]
    motive = [rec([fresh]), [1]]
    step = [[], [major, motive], None, []]
    if parameter is None:
        return document(closure, step, header)
    return document([rec(parameter), parameter],
                    [[closure, parameter]] + step + [[]], header)


def main():
    OUT.mkdir(exist_ok=True)
    source = CANDIDATE.read_text()
    candidate = load_source(source, "candidate")
    baseline = load_source(SOURCE.read_text(), "baseline")
    cases = []

    def add(name, data, expected):
        cases.append((name, data, expected))

    for header in [0, 1, 7, -7, True, False, 10**40]:
        add(f"integer_header_{header}", document([0, 0], refl(0), header), True)
        fresh = ~abs(header) - 1
        add(f"universal_reflexivity_{header}",
            document([[1, 1]], [[]] + refl([fresh]), header), True)
        add(f"genuine_induction_{header}", induction(header), True)
    for header in [None, [], {}, "1", 0.0, 1.0, -2.5, float("nan"), float("inf")]:
        add(f"invalid_header_{repr(header)}", document([0, 0], refl(0), header), False)

    for parameter in [-1, -2, -17, -10**40]:
        header = -parameter - 1
        add(f"boundary_parameter_{parameter}",
            document([parameter, parameter], refl(parameter), header), True)
        add(f"induction_specialization_{parameter}", induction(header, parameter), True)
        if header:
            add(f"too_shallow_floor_{parameter}",
                document([parameter, parameter], refl(parameter), header - 1), False)

    for bad in [True, False, 0.0, -1.0, "-1", None, {}, [], [0, 0]]:
        add(f"invalid_term_{repr(bad)}", document([bad, bad], refl(bad), 99), False)
    add("unbound_positive", document([1, 1], refl(1), 99), False)
    add("contradiction", document([0, [0]], refl(0), 99), False)
    add("used_unallocated_witness", document(existential([1, 1]),
        [[-7]] + refl(-7), 0), False)
    add("allocated_free_witness", document(existential([1, 1]),
        [[-7]] + refl(-7), 6), True)
    add("unused_unallocated_witness", document(existential([0, 0]),
        [[-7]] + refl(0), 0), True)
    add("unallocated_ghost_name", document(existential([0, 0], [-2, -2]),
        [[0]] + refl(0), 0), False)
    add("declared_ghost_name", document(existential([0, 0], [-2, -2]),
        [[0]] + refl(0), 1), True)
    add("positive_capture_attempt", document(existential([[1, 2]]),
        [[1], []] + refl([-2]), 0), False)
    add("bad_recursion_update", document([[0, 0, 3], 0], [[]], 0), False)
    add("good_recursion_update", document([[0, 0, [1, 2, 4]], 0], [[]], 0), True)
    add("unused_prefix", [dict(unused=-10**80)] + document([0, 0], refl(0), 0), True)

    # With the floor guard removed, a future eigenname can already occur
    # in the major matrix, and the subsequent opening captures it.
    major = existential([1, [-2]])
    major_proof = [[[-2]]] + refl([-2])
    escape = document([-2, [-2]], [[major, None]] + major_proof + [None], 0)
    false_existence = document(existential([1, [1]]),
        [[major, None]] + major_proof + [[-2], None], 0)
    add("future_name_captures_root", escape, False)
    add("future_name_captures_major", false_existence, False)

    results = []
    for index, (name, data, expected) in enumerate(cases):
        actual = run(candidate, data)
        if actual[0] != expected:
            raise AssertionError((name, expected, actual))
        comparison = None
        if expected:
            comparison = run(baseline, data)
            if comparison != actual:
                raise AssertionError(("accepted simulation", name, actual, comparison))
        path = OUT / f"case_{index:03}.json"
        path.write_text(json.dumps(data, separators=(",", ":")) + "\n")
        for options in [[], ["-O"]]:
            proc = subprocess.run([sys.executable, *options, str(CANDIDATE), str(path)],
                                  capture_output=True, text=True)
            if (proc.returncode == 0) != expected:
                raise AssertionError(("CLI", name, options, proc.returncode, proc.stdout, proc.stderr))
            if proc.stdout.strip() != ("ACCEPT" if expected else "REJECT"):
                raise AssertionError(("verdict", name, proc.stdout))
        results.append(dict(name=name, expected=expected, accepted=actual[0],
                            final_floor=actual[1], unread=actual[2],
                            baseline_simulation=comparison))

    defective = load_source(source.replace(" and a >= k", ""), "defective")
    controls = []
    for name, data in [("root_capture", escape), ("major_capture", false_existence)]:
        actual = run(defective, data)
        if not actual[0]:
            raise AssertionError(("defect control insensitive", name, actual))
        controls.append(dict(name=name, defective_accepts=True, actual_rejects=True))

    report = dict(checker_sha256=hashlib.sha256(source.encode()).hexdigest(),
                  case_count=len(cases), real_cli_runs=2*len(cases),
                  accepted_source_simulations=sum(x[2] for x in cases),
                  cases=results, deliberate_defect_controls=controls,
                  note="Finite independently constructed checks; no mechanized metatheory claim.")
    (OUT / "results.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k not in ("cases",)}, indent=2))


if __name__ == "__main__":
    main()
