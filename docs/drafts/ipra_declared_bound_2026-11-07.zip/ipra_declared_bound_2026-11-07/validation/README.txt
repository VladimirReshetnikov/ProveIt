Validation and certificate compilation
=====================================

Run from the package root:

    python3 validation/validate.py --checker checker.py

The acceptance kernel imports none of these support files. The validation
program, reference interpreter, producer, certificates, and results are
untrusted support. They provide finite implementation evidence, not a
machine-checked proof of general soundness, completeness, or bi-interpretability.

What is tested
--------------

1. All 66 distinct certificates in the pinned reference corpus are replayed
   with an independent named-binder interpreter. A successful derivation tree
   is extracted and recompiled with the new declared-namespace policy.
   There are 45 empty-context public theorem certificates and 21 internal
   sequents with explicitly supplied assumptions. The latter are stored in
   a separate directory and are never submitted as public theorem documents.

2. The compiler does not merely offset all negative integers. Each successful
   local-variable rule introduces a fresh binding in the extracted derivation;
   compilation maps that binding to the next target name. The mapping has
   lexical scope. A source name reused outside its old scope remains a rigid
   parameter. The initial header reserves every original negative name, so
   all such free parameters are available. Failed speculative major-premise
   attempts are discarded only where hypothesis membership independently
   justifies the successful source leaf.

3. The 47 focused cases cover arbitrary open-root parameters, recursive
   computation and equation induction, explicit references to generated
   parameters, sibling scopes, discharged assumptions, failed guarded major
   attempts, malformed syntax, illegal positive-coordinate witnesses,
   namespace violations, inert unused witness fields, and header handling.

4. Four positive controls run the relevant attacks against three deliberately
   unsound, in-memory mutants: removal of declared-name checking, removal of
   used-image validation, and admission of compound induction hypotheses.
   Each attack is accepted by its intended mutant and rejected by the real
   kernel. The false freshness and capture examples therefore exercise
   essential checks rather than only incidental parsing failures.

5. There are 384 distinct seeded randomized opening problems, spanning terms
   and formulas with zero, one, or two external holes. The packed-depth
   implementation agrees with the independent named-binder reference, returns
   locally closed syntax, and never mutates the declared namespace floor.

6. Every public corpus and focused example runs in a separate normal Python
   process and in a separate optimized Python process (-O). In the recorded
   run there are 184 subprocess executions, including 92 optimized runs.

The finite result counts and complete per-case outcomes are recorded in
results/summary.json and results/validation_results.json. Both files record
the exact tested checker SHA256. Rerunning against changed source refreshes
that identity and all outcomes.

Provenance
----------

The current comparison snapshot is ProveIt commit
8b00e6ea50c664476e3a3289a78287946e5e0a34.

The named-reference support definitions were extracted unchanged from
docs/drafts/ipra_scope_2026-11-07.zip, validation/run.py. Exact source identity
and retained definition names appear in reference/source_manifest.json.
The source corpus and source attack cases are copied from that archive's
validation/reference directory. Their inherited provenance identifies the
older c5f42a50d9213259760ee385977481c04dccab28 snapshot and the earlier
ipra_fresh_parameters_2026-11-06 archive. This distinction is intentional:
the current archive itself contains and attributes the older fixtures.

reference/named_reference.py supplies explicit named syntax and substitution;
the new DeclaredOracle changes only the name policy to checked lower bounds.
translate.py supplies the new successful-derivation extraction and scoped
alpha-compilation. Neither imports or calls the candidate acceptance kernel.

Certificate format
------------------

A public certificate is a JSON list:

    [ ... proof stream cells ..., goal, namespace_header ]

The kernel consumes from right to left. The last header is canonically an
integer h, establishing initial floor k = -abs(h)-1. Used rigid parameter
names must be at least k; every new scope decrements k before using it as
its fresh name. Negative integers are rigid names, zero is numerical zero,
and positive integers are locally bound de Bruijn coordinates. The header
declares names, never mathematical assumptions.

The source translator CLI accepts the older [goal, proof_stack] document:

    python3 validation/translate.py old.json new.json

Use --arity when the old document already has arity syntax instead of tags.
The translator rejects attempts to export an external-assumption sequent as
a public theorem certificate.

Closed-sentence companion
-------------------------

The optional checker_closed.py has a smaller interface: its document ends in
the closed goal and has no namespace header. Its initial namespace floor is
zero, so no negative parameter is available at the root; its first generated
local parameter is -1. It decides the same theory of closed sentences.

Run its separate validation without overwriting the main results:

    python3 validation/closed_validation.py --checker checker_closed.py

The companion compiler starts from a successful source derivation, replaces
all free auxiliary rigid parameters by numerical zero, and alpha-renames
every locally bound proof parameter. It preserves each originally closed
goal. For additional testing it also specializes source statements with
free numerical parameters to their closed zero instances. The resulting
certificates are separated into certificates/closed/unchanged and
certificates/closed/zero_instances; the latter are not presented as proofs
of the original open statements.

The recorded companion run passes 45 source-derived certificates: 10 retain
their original closed goals and 35 prove explicitly identified closed zero
instances. Its 24 additional focused cases include generated-name witnesses,
equation induction, open-root rejection, future-name and capture rejection,
sibling scopes, and discharged assumptions. All 138 subprocess executions
match their expected outcomes, including 69 under Python -O.

The companion results are results/closed_summary.json and
results/closed_validation_results.json. They record the separate checker
SHA256 and do not replace the main kernel's validation_results.json.
