"""Finite implementation checks for the declared-namespace iPRA kernel.

Run: python3 validation/validate.py --checker checker.py
No support module is imported by the acceptance kernel. These finite tests
are implementation evidence, not a machine formalization of the metatheory.
"""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import random
import subprocess
import sys
import types

from reference.named_reference import (
    NamedOracle, NamedSyntax, negative_names, substitute_names, used_holes,
    encode_tagged,
)
from translate import translate, integer_names, rename


HERE = Path(__file__).resolve().parent
SEED = 20261107


def require(ok, detail):
    if not ok:
        raise AssertionError(detail)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_reference():
    provenance = json.loads((HERE / 'reference/provenance.json').read_text())
    for name, expected in provenance['reference_files'].items():
        require(digest(HERE / 'reference' / name) == expected,
                ('frozen reference file changed', name))
    manifest = json.loads((HERE / 'reference/source_manifest.json').read_text())
    require(digest(HERE / 'reference/named_reference.py') == manifest['extracted_file_sha256'],
            'extracted named reference changed')


class DeclaredOracle(NamedOracle):
    """Named substitution plus an independently stated declared-name policy."""
    def __init__(self, header):
        super().__init__('demand')
        self.k = ~abs(header)

    def opening(self, a, images=(), formula=True):
        syntax = NamedSyntax()
        tree = (syntax.formula if formula else syntax.term)(a, holes=len(images))
        if any(n < self.k for n in negative_names(tree)):
            raise ValueError('an undeclared parameter occurs in a matrix')
        replacements = {}
        for i in sorted(used_holes(tree)):
            replacement = syntax.term(images[i])
            if any(n < self.k for n in negative_names(replacement)):
                raise ValueError('an undeclared parameter occurs in a used image')
            replacements[i] = replacement
        result = substitute_names(tree, replacements)
        return (syntax.formula_data if formula else syntax.term_data)(result)


def kernel_verdict(module, goal, stack, header=0, context=()):
    try:
        module.k = ~abs(header)
        stack = deepcopy(stack)
        module.take = stack.pop
        context = deepcopy(list(context))
        for a in context:
            module.inst(a)
        result = bool(module.check(deepcopy(goal), context))
        return result, module.k, len(stack)
    except Exception:
        return False, None, None


def oracle_verdict(goal, stack, header=0, context=()):
    try:
        oracle = DeclaredOracle(header)
        context = deepcopy(list(context))
        for a in context:
            oracle.opening(a)
        oracle.stack = deepcopy(stack)
        result = bool(oracle.check(deepcopy(goal), context))
        return result, oracle.k, len(oracle.stack)
    except Exception:
        return False, None, None


def reflexivity(t):
    axiom = [[0, t, 0], t]
    return [[], [], [axiom, [1, t]]]


def exists(body):
    return [body, [0, 0], [0, 0]]


def examples_and_attacks():
    y = -2                         # First eigenparameter with header zero.
    one = [0]
    sy = [y]
    ey = exists([1, 1])
    true = [0, 0]
    false = [0, one]
    cases = []

    def add(name, goal, stack, expected, header=0, purpose=''):
        cases.append(dict(name=name, goal=goal, stack=stack, expected=expected,
                          header=header, purpose=purpose))

    add('reflexivity_zero', true, reflexivity(0), True)
    add('root_reserved_parameter', [-1, -1], reflexivity(-1), True)
    distant = -1000000000123
    add('root_arbitrarily_distant_parameter', [distant, distant],
        reflexivity(distant), True, abs(distant))
    add('native_Q_reflexivity', [[1, 1]], reflexivity(sy) + [[]], True,
        purpose='The Q introduction uses a numerical eigenparameter.')
    add('native_Q_exists_own_successor', [exists([1, 2])],
        reflexivity(sy) + [[sy], []], True,
        purpose='A serialized witness explicitly refers to a generated eigenparameter.')

    def identity_rec(n):
        return [n, 0, [1]]

    matrix = [identity_rec(1), 1]
    major = [matrix]
    induction_hypothesis = [identity_rec(y), y]
    motive = [identity_rec(sy), [1]]
    induction = [[], None, [induction_hypothesis, motive], []]
    add('equation_induction_recursion_identity', major, induction, True)
    add('equation_induction_instantiated_at_parameter',
        [identity_rec(-1), -1], [[]] + induction + [[major, -1]], True)

    add('zero_successor_contradiction', false, [None], False)
    add('future_parameter_in_root', [-2, -2], reflexivity(-2), False,
        purpose='The declared initial namespace is actually enforced.')
    add('future_parameter_in_used_witness', ey,
        reflexivity(-2) + [[-2]], False)
    add('unused_future_witness_is_inert', exists(true),
        reflexivity(0) + [[-999]], True,
        purpose='Demand validation ignores a witness when its hole never occurs.')
    add('positive_free_coordinate_in_root', [1, 1], reflexivity(1), False)
    add('positive_free_coordinate_as_witness', ey,
        reflexivity(1) + [[1]], False)
    add('boolean_zero_alias_in_goal', [False, 0], reflexivity(0), False)
    add('float_zero_alias_in_goal', [0.0, 0], reflexivity(0), False)
    add('invalid_term_arity_two', [[0, [0, 0], 0], [0, 0]], [[]], False)
    add('invalid_recursor_update_hole', [[0, 0, 3], 0], [[]], False)
    add('malformed_existential_annotation', [[0, 0], True, [0, 0]],
        reflexivity(0) + [[0]], False)
    add('empty_proof_stream', true, [], False)
    add('unread_prefix_is_inert', true, [{'ignored': -999999}] + reflexivity(0), True)

    for witness in (False, True, 1.5, [], [0, 0], {'x': 0}):
        tag = json.dumps(witness, separators=(',', ':'))
        add('used_bad_witness_' + tag, ey, reflexivity(0) + [[witness]], False)
        add('unused_bad_witness_' + tag, exists(true),
            reflexivity(0) + [[witness]], True)

    # A scope in the major premise is followed by an independent sibling.
    def scoped_reflexivity(witness, constrained=False):
        matrix = [1, 0] if constrained else [1, 1]
        m = exists(matrix)
        return reflexivity(0) + reflexivity(witness) + [[witness], [m, None]]

    earlier = scoped_reflexivity(0)
    later = scoped_reflexivity(-2)
    future = scoped_reflexivity(-3)
    add('declared_parameter_reused_in_sibling', true,
        later + earlier + [[true, true]], True)
    add('undeclared_parameter_used_in_sibling', true,
        future + earlier + [[true, true]], False)
    leaking_goal = exists([1, 0])
    leaked = [None, [-2]] + scoped_reflexivity(0, constrained=True) + [[true, leaking_goal]]
    add('discharged_assumption_cannot_escape', leaking_goal, leaked, False)
    speculative = [None, [], [[[1, 0]], 0], []]
    add('failed_major_reserves_names_without_exporting_assumptions', [true],
        speculative, True)

    inherited = json.loads((HERE / 'reference/source_audit_cases.json').read_text())
    for name in ('capture_by_illegal_positive_witness',
                 'freshness_collision_with_goal_parameter',
                 'freshness_collision_with_major_only_parameter'):
        source = next(c for c in inherited if c['name'] == name)
        # These are deliberately invalid attacks, with the old first-local
        # name -1 changed to the new first-local name -2. They are not
        # presented as general proof translations.
        goal = rename(encode_tagged(source['goal']), {-1: -2})
        proof = rename(encode_tagged(source['proof']), {-1: -2})
        add(name, goal, proof, False,
            purpose='Pinned attack adapted to the first local name under header zero.')

    body = exists([2, 2])
    m = exists([y, y])
    step = reflexivity(sy) + [[0], None, [m, None]]
    add('compound_induction_hypothesis_is_unavailable', [body], step + [[]], False)

    add('negative_header_is_normalized', true, reflexivity(0), True, -17)
    add('boolean_header_is_harmless', true, reflexivity(0), True, True)
    for header in (1.0, None, '0', [], {}):
        add('invalid_header_' + json.dumps(header, separators=(',', ':')),
            true, reflexivity(0), False, header)
    return cases


def positive_control_mutants(source, cases):
    mutations = {
        'declared_name_check_removed': (' and a >= k', ''),
        'used_image_validation_removed':
            ('else inst(env[a - d // 2 - 1], d=1)', 'else env[a - d // 2 - 1]'),
        'compound_induction_enabled': ('[:2 - len(b) % 2]', ''),
    }
    choices = {
        'declared_name_check_removed': [
            'freshness_collision_with_goal_parameter',
            'freshness_collision_with_major_only_parameter'],
        'used_image_validation_removed': ['capture_by_illegal_positive_witness'],
        'compound_induction_enabled': ['compound_induction_hypothesis_is_unavailable'],
    }
    by_name = {c['name']: c for c in cases}
    results = []
    for name, (old, new) in mutations.items():
        require(source.count(old) == 1, ('mutant replacement changed', name))
        module = types.ModuleType('deliberately_invalid_' + name)
        exec(compile(source.replace(old, new, 1), name, 'exec'), module.__dict__)
        for case_name in choices[name]:
            c = by_name[case_name]
            verdict = kernel_verdict(module, c['goal'], c['stack'], c['header'])
            require(verdict[0], ('positive-control mutant did not admit attack', name, case_name))
            results.append({'mutant': name, 'case': case_name, 'mutant_accepts': True,
                            'real_kernel_rejects': True})
    return results


def randomized_openings(module):
    rng = random.Random(SEED)

    def term(size, depth=0, holes=0):
        atoms = [0, -1, -7, -1001, *range(1, depth + holes + 1)]
        if not size or rng.randrange(3) == 0:
            return rng.choice(atoms)
        if rng.randrange(2):
            return [term(size - 1, depth, holes)]
        return [term(size - 1, depth, holes), term(size - 1, depth, holes),
                term(size - 1, depth + 2, holes)]

    def formula(size, depth=0, holes=0):
        if not size or rng.randrange(3) == 0:
            return [term(2, depth, holes), term(2, depth, holes)]
        if rng.randrange(2):
            return [formula(size - 1, depth + 1, holes)]
        return [formula(size - 1, depth + 1, holes),
                formula(max(0, size - 2), depth + 1, holes),
                formula(max(0, size - 2), depth + 1, holes)]

    identities = set()
    for holes in (0, 1, 2):
        for is_formula in (False, True):
            selected = set()
            while len(selected) < 64:
                images = [term(3) for _ in range(holes)]
                matrix = (formula if is_formula else term)(4, holes=holes)
                key = json.dumps([matrix, images, is_formula], separators=(',', ':'))
                if key in selected:
                    continue
                selected.add(key)
                identities.add(key)
                header = 1001 + rng.randrange(20)
                oracle = DeclaredOracle(header)
                expected = oracle.opening(matrix, images, formula=is_formula)
                module.k = ~abs(header)
                floor = module.k
                actual = module.inst(matrix, images, d=0 if is_formula else 1)
                require(actual == expected, ('named-opening differential', key))
                require(module.k == floor == oracle.k, 'opening mutated the namespace floor')
                require(module.inst(actual, d=0 if is_formula else 1) == actual,
                        ('opening result is not locally closed', key))
    return {'seed': SEED, 'distinct_cases': len(identities),
            'all_named_substitutions_agree': True, 'all_outputs_locally_closed': True,
            'all_openings_preserve_floor': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', type=Path, default=HERE.parent / 'checker.py')
    parser.add_argument('--output', type=Path, default=HERE / 'results')
    args = parser.parse_args()
    checker = args.checker.resolve()
    args.output.mkdir(parents=True, exist_ok=True)
    module = load(checker, 'declared_kernel')
    source = checker.read_text()
    verify_reference()
    corpus = json.loads((HERE / 'reference/source_corpus.json').read_text())
    records, public = [], []
    for index, row in enumerate(corpus):
        canonical = json.dumps(row['certificate'], sort_keys=True, separators=(',', ':'))
        require(hashlib.sha256(canonical.encode()).hexdigest() == row['sha256_canonical'],
                ('source certificate identity changed', index))
        translated = translate(row['certificate'])
        goal, stack = translated['goal'], translated['stack']
        header, context = translated['header'], translated['context']
        actual = kernel_verdict(module, goal, stack, header, context)
        reference = oracle_verdict(goal, stack, header, context)
        require(actual[0] and actual == reference and actual[2] == 0,
                ('translated corpus mismatch', index, actual, reference))
        label = Path(min(row['source_aliases'], key=lambda x: (len(x), x))).stem
        filename = f'{index:03d}_{label}.json'
        if not context:
            path = HERE / 'certificates' / 'theorems' / filename
            write(path, translated['document'])
            public.append((path, True, 'corpus/' + filename))
        else:
            path = HERE / 'certificates' / 'internal_sequents' / filename
            write(path, {k: translated[k] for k in ('goal', 'stack', 'context', 'header')})
        records.append({'source_id': index, 'source_aliases': row['source_aliases'],
                        'source_sha256_canonical': row['sha256_canonical'],
                        'target': str(path.relative_to(HERE)), 'target_sha256': digest(path),
                        'external_assumptions': len(context), 'header': header,
                        'allocations': translated['allocations'],
                        'final_floor': actual[1], 'accepted': True})

    cases = examples_and_attacks()
    focused = []
    for index, case in enumerate(cases):
        actual = kernel_verdict(module, case['goal'], case['stack'], case['header'])
        reference = oracle_verdict(case['goal'], case['stack'], case['header'])
        require(actual[0] == reference[0] == case['expected'],
                ('focused case', case['name'], actual, reference, case['expected']))
        path = HERE / 'certificates' / 'focused' / f'{index:03d}.json'
        write(path, [*case['stack'], case['goal'], case['header']])
        public.append((path, case['expected'], 'focused/' + case['name']))
        focused.append({**case, 'target': str(path.relative_to(HERE)),
                        'target_sha256': digest(path), 'actual': actual[0]})

    controls = positive_control_mutants(source, cases)
    openings = randomized_openings(module)

    def run(job):
        path, expected, label, optimized = job
        process = subprocess.run([sys.executable, *(['-O'] if optimized else []),
                                  str(checker), str(path)],
                                 text=True, capture_output=True, timeout=20)
        require(process.returncode == (0 if expected else 1)
                and process.stdout.strip() == ('ACCEPT' if expected else 'REJECT'),
                ('public CLI verdict', label, optimized, process.returncode,
                 process.stdout, process.stderr))
        return {'case': label, 'optimized': optimized, 'accepted': expected,
                'exit_code': process.returncode}

    jobs = [(*item, optimized) for item in public for optimized in (False, True)]
    with ThreadPoolExecutor(max_workers=6) as pool:
        cli = list(pool.map(run, jobs))
    result = {
        'status': 'all expected outcomes matched', 'python': platform.python_version(),
        'checker_sha256': digest(checker), 'source_commit':
            '8b00e6ea50c664476e3a3289a78287946e5e0a34',
        'corpus_certificates': len(records), 'corpus_public_theorems':
            sum(not r['external_assumptions'] for r in records),
        'corpus_internal_sequents': sum(bool(r['external_assumptions']) for r in records),
        'focused_cases': len(focused), 'focused_expected_accepts':
            sum(r['expected'] for r in focused), 'focused_expected_rejects':
            sum(not r['expected'] for r in focused),
        'positive_control_mutants': controls, 'randomized_openings': openings,
        'public_subprocess_executions': len(cli),
        'optimized_subprocess_executions': sum(r['optimized'] for r in cli),
        'corpus': records, 'focused': focused, 'public_cli': cli,
        'scope': 'Finite implementation validation; no claim of a formalized general metatheorem.',
    }
    write(args.output / 'validation_results.json', result)
    summary = {k: v for k, v in result.items()
               if k not in ('corpus', 'focused', 'public_cli')}
    write(args.output / 'summary.json', summary)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
