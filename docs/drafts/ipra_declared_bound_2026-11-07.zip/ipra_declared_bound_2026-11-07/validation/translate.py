"""Untrusted, binding-aware compiler from the frozen scanner-name certificates.

The producer extracts a successful native derivation using an independent
named-substitution reference, discards failed speculative attempts, and then
alpha-renames each local eigenparameter while compiling the new certificate.
It is not imported by the acceptance kernel.
"""
from copy import deepcopy
from dataclasses import dataclass
import json
from pathlib import Path

from reference.named_reference import NamedOracle, encode_tagged


@dataclass
class Derivation:
    rule: str
    goal: object
    children: tuple = ()
    annotation: object = None
    eigen: int | None = None


class Extractor(NamedOracle):
    """Reference replay with an explicit successful derivation as its result."""
    def __init__(self):
        super().__init__('demand')

    def check(self, a, g):
        self.opening(a)
        instruction = self.stack.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            first = self.check(major, g)
            if first:
                if len(major) == 3:
                    eigen = self.allocate([a, *g, major])
                    local = self.opening(major[0], [eigen])
                    second = self.check(a, [*g, local])
                    return (Derivation('EE', a, (first, second), None, eigen)
                            if second else None)
                if len(major) == 1:
                    motive, images = major[0], (0, annotation)
                    rule = 'QE'
                else:
                    motive, images = annotation, major
                    rule = 'EqE'
                before, after = (self.opening(motive, [v]) for v in images)
                if after != a:
                    return None
                second = self.check(before, g)
                return (Derivation(rule, a, (first, second), annotation)
                        if second else None)
            # A failed guarded major can be ignored only when membership
            # independently justifies the successful leaf.
            return Derivation('Hyp', a) if a in g else None
        if len(a) == 1 and instruction == []:
            body = a[0]
            local = [self.opening(body, [0])]
            if len(body) == 2:
                local.append(body)
            eigen = self.allocate([a, *g])
            goal = self.opening(body, [[eigen]])
            assumptions = [self.opening(b, [eigen]) for b in local]
            child = self.check(goal, [*g, *assumptions])
            return Derivation('QI', a, (child,), None, eigen) if child else None
        if len(a) == 3 and type(instruction) is list and len(instruction) == 1:
            child = self.check(self.opening(a[0], [instruction[0]]), g)
            return Derivation('EI', a, (child,), instruction[0]) if child else None
        if (len(a) == 2 and type(a[0]) is list and len(a[0]) == 3
                and instruction == []):
            n, initial, update = a[0]
            expected = initial
            if n != 0:
                if type(n) is not list or len(n) != 1:
                    raise ValueError('computation counter is not zero or successor')
                n = n[0]
                expected = self.opening(update, [[n, initial, update], n],
                                        formula=False)
            return Derivation('Comp', a) if a[1] == expected else None
        return Derivation('Hyp', a) if a in g else None


def rename(value, mapping):
    if type(value) is int:
        return mapping.get(value, value) if value < 0 else value
    if type(value) is list:
        return [rename(x, mapping) for x in value]
    # This can only be inert certificate metadata in a valid source proof.
    return deepcopy(value)


def integer_names(value):
    if type(value) is int:
        return {value} if value < 0 else set()
    if type(value) is list:
        return set().union(*(integer_names(x) for x in value))
    if type(value) is dict:
        return set().union(*(integer_names(x) for x in value.values()))
    return set()


class Compiler:
    def __init__(self, header):
        self.k = ~abs(header)
        self.allocations = []

    def enter(self, old, mapping):
        self.k -= 1
        self.allocations.append({'source_name': old, 'target_name': self.k})
        return {**mapping, old: self.k}

    def compile(self, node, mapping=None):
        mapping = {} if mapping is None else mapping
        if node.rule == 'Hyp':
            return [None]
        if node.rule == 'Comp':
            return [[]]
        if node.rule == 'QI':
            local = self.enter(node.eigen, mapping)
            return self.compile(node.children[0], local) + [[]]
        if node.rule == 'EI':
            return self.compile(node.children[0], mapping) + [[rename(node.annotation, mapping)]]
        major, minor = node.children
        first = self.compile(major, mapping)
        local = self.enter(node.eigen, mapping) if node.rule == 'EE' else mapping
        second = self.compile(minor, local)
        instruction = [rename(major.goal, mapping), rename(node.annotation, mapping)]
        return second + first + [instruction]


def translate(source, tagged=True):
    source = encode_tagged(source) if tagged else deepcopy(source)
    goal, proof, *context = source
    oracle = Extractor()
    for a in context:
        oracle.opening(a)
    oracle.stack = deepcopy(proof)
    derivation = oracle.check(goal, context)
    if derivation is None:
        raise ValueError('source certificate is not a reference derivation')
    # This reserves every source name, including any older local name later
    # used as an unrelated rigid parameter outside its defining scope.
    header = max([0, *(-n for n in integer_names(source))])
    compiler = Compiler(header)
    stack = compiler.compile(derivation)
    result = {
        'goal': goal,
        'stack': stack,
        'context': context,
        'header': header,
        'document': [*stack, goal, header],
        'allocations': compiler.allocations,
        'source_unused_prefix': len(oracle.stack),
        'target_final_floor': compiler.k,
    }
    return result


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('target', type=Path)
    parser.add_argument('--arity', action='store_true')
    args = parser.parse_args()
    translated = translate(json.loads(args.source.read_text()), tagged=not args.arity)
    if translated['context']:
        raise ValueError('An external-assumption sequent is not a public theorem certificate.')
    args.target.write_text(json.dumps(translated['document'], separators=(',', ':')) + '\n')
