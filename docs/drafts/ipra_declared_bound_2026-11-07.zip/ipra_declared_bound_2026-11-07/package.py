"""Create the self-contained archive and an identical standalone paper."""
from hashlib import sha256
from pathlib import Path
from shutil import copyfile
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo
import json

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {".aux", ".out", ".toc", ".fls", ".fdb_latexmk", ".pyc"}


def include(path):
    relative = path.relative_to(ROOT)
    return (
        path.is_file()
        and not any(part.startswith(".") or part == "__pycache__" for part in relative.parts)
        and path.suffix not in EXCLUDED_SUFFIXES
        and not path.name.endswith(".synctex.gz")
        and (path.suffix != ".log" or relative.as_posix() == "results/reproduction.log")
        and path.name != "SHA256SUMS"
    )


def main():
    paths = sorted(path for path in ROOT.rglob("*") if include(path))
    sums = ROOT / "SHA256SUMS"
    sums.write_text("".join(
        f"{sha256(path.read_bytes()).hexdigest()}  {path.relative_to(ROOT).as_posix()}\n"
        for path in paths
    ), encoding="utf-8")
    paths.append(sums)
    archive = ROOT.with_suffix(".zip")
    with ZipFile(archive, "w", compression=ZIP_DEFLATED, compresslevel=9) as output:
        for path in sorted(paths):
            member = ZipInfo(f"{ROOT.name}/{path.relative_to(ROOT).as_posix()}",
                             date_time=(2026, 11, 7, 0, 0, 0))
            member.create_system = 3
            member.external_attr = 0o100644 << 16
            output.writestr(member, path.read_bytes(), compress_type=ZIP_DEFLATED,
                            compresslevel=9)
    with ZipFile(archive) as check:
        if check.testzip() is not None:
            raise RuntimeError("Archive CRC validation failed")
        for line in sums.read_text(encoding="utf-8").splitlines():
            digest, relative = line.split("  ", 1)
            if sha256(check.read(f"{ROOT.name}/{relative}")).hexdigest() != digest:
                raise RuntimeError(f"Archive content mismatch: {relative}")
        required = {"report.tex", "report.pdf", "checker.py", "checker_closed.py"}
        if not required <= {path.name for path in paths}:
            raise RuntimeError("A required deliverable is missing")
    paper = ROOT.with_suffix(".pdf")
    copyfile(ROOT / "report.pdf", paper)
    print(json.dumps({
        "archive": str(archive),
        "archive_files": len(paths),
        "archive_bytes": archive.stat().st_size,
        "archive_sha256": sha256(archive.read_bytes()).hexdigest(),
        "paper": str(paper),
        "paper_bytes": paper.stat().st_size,
        "paper_sha256": sha256(paper.read_bytes()).hexdigest(),
        "validation": "ZIP CRC and every recorded SHA256 matched",
    }, indent=2))


if __name__ == "__main__":
    main()
