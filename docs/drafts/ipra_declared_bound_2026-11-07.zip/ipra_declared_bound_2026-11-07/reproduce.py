"""Run the frozen measurement and both independent validation tracks."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
for relative in ("measure.py", "validation/audit_bound.py", "validation/validate.py", "validation/closed_validation.py"):
    subprocess.run([sys.executable, str(ROOT / relative)], cwd=ROOT, check=True)
