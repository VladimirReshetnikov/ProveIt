"""Reproduce standalone benchmark controls from three verbatim prior sources.

This script is not trusted by any proof checker. It performs explicit text
edits, then checks that outer-arity plumbing is gone while the binding-depth
parameter of walk is still present. The resulting checkers run independently.
"""

import ast
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
ORIGINALS = {
    "previous_k.py": "95c2f790f51a31b86a994aecb09fdc56688e6ca75e12f2c96112a31fadb598e0",
    "nd_sc_original.py": "0de10215b0701e638128a5c2d8ece6f8ef9647c1e7908bfea20416c7166b464a",
    "nd_sc_reduced_original.py": "2996c0b9ef75a39eb041917d1482bfc4b0f42f08fdfccbcd34c0ca15a96f4af2",
}


def header(source, description):
    tree = ast.parse(source)
    doc = tree.body[0]
    if not (isinstance(doc, ast.Expr) and isinstance(doc.value, ast.Constant)
            and isinstance(doc.value.value, str)):
        raise ValueError("expected original module docstring")
    rest = "\n".join(source.splitlines()[doc.end_lineno:])
    return '"""' + description + '\n"""\n' + rest + '\n'


def open_scopes(source, description):
    binding = source[source.index("\ndef walk("):source.index("\ndef infer(")]
    changes = (
        ("def wf(a, d, formula=False):", "def wf(a, formula=False):"),
        ("return not formula and 0 <= a < d", "return not formula and a >= 0"),
        (", d + 1, True", ", True"),
        (", d + 2)", ")"),
        (", d, True", ", True"),
        (", d)", ")"),
        ("def infer(p, d, g):", "def infer(p, g):"),
        (", d + 1, ", ", "),
        (", d, ", ", "),
        ('{"arity", "assumptions", "goal", "proof"}',
         '{"assumptions", "goal", "proof"}'),
        ('    d = data["arity"]\n', ""),
        ('require(type(d) is int and d >= 0 and type(data["assumptions"]) is list)',
         'require(type(data["assumptions"]) is list)'),
    )
    for old, new in changes:
        if old not in source:
            raise ValueError("source drift at " + old)
        source = source.replace(old, new)
    # d inside these routines is local binding depth, not outer arity.
    source = (source[:source.index("\ndef walk(")] + binding
              + source[source.index("\ndef infer("):])
    source = header(source, description)
    tree = ast.parse(source)
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in ("wf", "infer", "check"):
            if any(isinstance(x, ast.Name) and x.id == "d" for x in ast.walk(node)):
                raise ValueError("outer arity remains in " + node.name)
    if "def walk(a, f, d=0):" not in source:
        raise ValueError("binding depth was removed")
    return source


def case_block(source, first, after):
    start = source.index('        case ' + first)
    end = source.index('        case ' + after, start)
    return source[start:end]


def replace_case(source, first, after, replacement):
    old = case_block(source, first, after)
    if source.count(old) != 1:
        raise ValueError("ambiguous proof case")
    return source.replace(old, replacement)


def rec_pattern(source):
    old = ('        case ("rec", r):\n'
           '            require(wf(r) and type(r) is tuple and r[0] == "r")\n'
           '            _, n, a, h = r\n')
    new = ('        case ("rec", ("r", n, a, h) as r):\n'
           '            require(wf(r))\n')
    if source.count(old) != 1:
        raise ValueError("recursion parser source drift")
    return source.replace(old, new)


def run():
    inputs = {}
    for name, expected in ORIGINALS.items():
        data = (ROOT / name).read_bytes()
        if hashlib.sha256(data).hexdigest() != expected:
            raise ValueError("original source changed: " + name)
        inputs[name] = data.decode("utf-8")

    k = open_scopes(inputs["previous_k.py"],
        "Prior K with only its explicit outer arity removed.\n\n"
        "JSON input has assumptions, goal, proof. Every nonnegative integer is\n"
        "a legal variable; binder shifts and substitution retain their original\n"
        "meaning. The original fixed bridge axiom and every proof rule remain.")
    nd = open_scopes(inputs["nd_sc_original.py"],
        "Conventional natural deduction for the six drafts' common raw core.\n\n"
        "The explicit outer arity is removed from the prior comparator.\n"
        "The shared recursion-pattern parser is also used.\n"
        "Native recursion, genuine falsity, ordinary connectives, reflexivity,\n"
        "explosion, separation, and the equation-indexed SC rule are retained.")
    reduced = open_scopes(inputs["nd_sc_reduced_original.py"],
        "Reduced conventional natural deduction with open numerical scopes.\n\n"
        "This retains the prior comparator's SC arithmetic rule, derived\n"
        "reflexivity, and merged falsity/contradiction elimination. Its outer\n"
        "arity is removed and the shared recursion-pattern parser is used.")
    nat = case_block(k, '("nat", a, t, p, q):', '_:')
    nd_nat = replace_case(nd, '("sc", e, t, p):', '_:', nat)
    nd_nat = header(nd_nat,
        "Ordinary connectives with open scopes and the shared N arithmetic rule.\n\n"
        "N performs equation induction or arbitrary-formula numerical cases.\n"
        "The conventional reflexivity, separation, and explosion rules remain.")
    reduced_nat = replace_case(reduced, '("sc", e, t, p):', '_:', nat)
    reduced_nat = header(reduced_nat,
        "Reduced ordinary-connective checker with open scopes and rule N.\n\n"
        "Reflexivity is derived; contradiction and falsity both license abort.\n"
        "Every other syntax and input-validation convention matches the controls.")
    bridge = ('        case ("bridge", p):\n'
              '            return {FALSE: CONTRADICTION, CONTRADICTION: FALSE}[infer(p, g)]\n')
    matched = replace_case(reduced_nat, '("abort", p, a):', '("eq", p, a, q):', bridge)
    matched = header(matched,
        "Ordinary-connective control matched to the new arithmetic kernel.\n\n"
        "Open scopes, native recursion, substitution, equality elimination,\n"
        "rule N, and the closed falsity bridge match the new kernel. Only the\n"
        "logical formula constructors and their introduction/elimination rules\n"
        "differ. Equality reflexivity and general explosion are derived.")
    outputs = {
        "previous_k_open.py": k,
        "previous_k_open_pattern.py": header(rec_pattern(k),
            "Prior K with open scopes and the shared recursion-parser refactor.\n\n"
            "The original bridge axiom and every inference rule are unchanged.\n"
            "Structural pattern matching validates the outer recursion shape;\n"
            "wf validates its children. There is no extra trusted operation."),
        "nd_sc_open.py": rec_pattern(nd),
        "nd_sc_reduced_open.py": rec_pattern(reduced),
        "nd_nat_open.py": rec_pattern(nd_nat),
        "nd_nat_reduced_open.py": rec_pattern(reduced_nat),
        "nd_nat_bridge_open.py": rec_pattern(matched),
    }
    for name, source in outputs.items():
        compile(source, name, "exec")
        (ROOT / name).write_text(source, encoding="utf-8")
    manifest = {
        "source_archive": "ipra_small_checker_2026-11-03.zip",
        "originals_sha256": ORIGINALS,
        "generated_sha256": {name: hashlib.sha256(source.encode()).hexdigest()
                             for name, source in outputs.items()},
        "note": "The generation script is not part of any trusted checker. All outputs are standalone. previous_k_open.py changes only outer arity. Every other generated control also uses the shared recursion-pattern refactor.",
    }
    (ROOT / "generation.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps(manifest, indent=2))
    return manifest


if __name__ == "__main__":
    run()
