"""Measure complete standalone checkers under one reproducible convention.

All executable source, fixed data, validation, binding operations, inference
rules, and the command-line wrapper count. Only comments, docstrings, and
formatting are excluded from token/AST counts. No generator, test, or proof
builder is trusted by a checker. The shared Python runtime and standard
library are outside every count.
"""

import ast
import csv
import hashlib
import io
import json
from pathlib import Path
import tokenize


ROOT = Path(__file__).resolve().parent
VARIANTS = (
    ("previous_k.py", "Previous K, verbatim"),
    ("previous_k_open.py", "Previous K, open scopes"),
    ("previous_k_open_pattern.py", "Previous K, open scopes + parser"),
    ("nd_sc_original.py", "Ordinary ND + SC, verbatim"),
    ("nd_sc_reduced_original.py", "Reduced ND + SC, verbatim"),
    ("nd_sc_open.py", "Ordinary ND + SC, open scopes"),
    ("nd_sc_reduced_open.py", "Reduced ND + SC, open scopes"),
    ("nd_nat_open.py", "Ordinary ND + N, open scopes"),
    ("nd_nat_reduced_open.py", "Reduced ND + N, open scopes"),
    ("nd_nat_bridge_open.py", "Ordinary logic, matched arithmetic"),
    ("../code/checker.py", "New kernel"),
)


def measure(path):
    data = path.read_bytes()
    source = data.decode("utf-8")
    tree = ast.parse(source)
    docstrings = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                doc = node.body.pop(0)
                docstrings.append(((doc.lineno, doc.col_offset), (doc.end_lineno, doc.end_col_offset)))
    ignored = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
               tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
    tokens = [token for token in tokenize.generate_tokens(io.StringIO(source).readline)
              if token.type not in ignored
              and not any(start <= token.start and token.end <= end for start, end in docstrings)]
    return {
        "bytes": len(data),
        "physical_lines": len(source.splitlines()),
        "meaningful_python_tokens": len(tokens),
        "token_characters": sum(len(t.string) for t in tokens),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "sha256": hashlib.sha256(data).hexdigest(),
    }


def run():
    rows = [dict(file=filename, label=label, **measure(ROOT / filename))
            for filename, label in VARIANTS]
    final = rows[-1]
    for row in rows:
        row["new_kernel_token_saving"] = row["meaningful_python_tokens"] - final["meaningful_python_tokens"]
        row["new_kernel_token_reduction_percent"] = round(
            100 * (1 - final["meaningful_python_tokens"] / row["meaningful_python_tokens"]), 3)
        row["new_kernel_ast_reduction_percent"] = round(
            100 * (1 - final["ast_nodes"] / row["ast_nodes"]), 3)
    index = {row["file"]: row for row in rows}
    previous = index["previous_k.py"]["meaningful_python_tokens"]
    opened = index["previous_k_open.py"]["meaningful_python_tokens"]
    pattern = index["previous_k_open_pattern.py"]["meaningful_python_tokens"]
    matched = index["nd_nat_bridge_open.py"]["meaningful_python_tokens"]
    result = {
        "method": __doc__.strip(),
        "variants": rows,
        "isolated_token_differences": {
            "remove_explicit_outer_arity_from_previous_K": previous - opened,
            "shared_recursion_parser_refactor": opened - pattern,
            "closed_bridge_after_scope_and_parser_changes": pattern - final["meaningful_python_tokens"],
            "logical_kernel_only_against_matched_arithmetic": matched - final["meaningful_python_tokens"],
        },
        "caveat": "Finite source comparisons are measured upper bounds, not a universal minimality theorem. Native recursion syntax and Python runtime are common conventions. Physical lines and bytes include docstrings and formatting, unlike the principal token and AST metrics.",
    }
    (ROOT / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    with (ROOT / "metrics.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    macros = {
        "MeasuredKernelTokens": final["meaningful_python_tokens"],
        "MeasuredKernelAST": final["ast_nodes"],
        "MeasuredKernelLines": final["physical_lines"],
        "MeasuredKernelBytes": final["bytes"],
        "MeasuredPreviousKTokens": previous,
        "MeasuredPreviousOpenTokens": opened,
        "MeasuredPreviousPatternTokens": pattern,
        "MeasuredMatchedNDTokens": matched,
    }
    (ROOT / "metrics.tex").write_text("".join(
        "\\newcommand{\\" + key + "}{" + str(value) + "}\n" for key, value in macros.items()))
    table = [r"\begin{center}\small", r"\begin{tabular}{@{}lrrrr@{}}",
             r"\toprule", r"Complete implementation & Bytes & Lines & Tokens & AST nodes\\", r"\midrule"]
    for row in rows:
        table.append(row["label"] + " & " + " & ".join(
            str(row[key]) for key in ("bytes", "physical_lines", "meaningful_python_tokens", "ast_nodes")) + r"\\")
    table += [r"\bottomrule", r"\end{tabular}", r"\end{center}"]
    (ROOT / "comparison_table.tex").write_text("\n".join(table) + "\n")
    print(json.dumps(result, indent=2))
    return result


if __name__ == "__main__":
    run()
