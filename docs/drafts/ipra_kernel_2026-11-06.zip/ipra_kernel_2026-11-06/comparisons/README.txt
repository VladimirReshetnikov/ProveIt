COMPLETE-CHECKER COMPARISONS
6 November 2026

The principal measure is meaningful Python lexical tokens. Every checker
is standalone: all executable source, fixed data, input validation, binding
operations, proof-rule checks, and the command-line wrapper are counted.
Comments, docstrings, and formatting are excluded from token and AST counts.
The shared Python runtime and standard library are excluded equally.
Bytes and physical lines include documentation and formatting and are only
supplementary measurements. Tests and generators are not trusted code.

VERBATIM INPUTS

The following files are byte-for-byte copies from
ipra_small_checker_2026-11-03.zip:

  previous_k.py               <- checker.py
  nd_sc_original.py           <- baseline_nd.py
  nd_sc_reduced_original.py   <- baseline_nd_optimized.py

Their SHA-256 hashes are checked by generate.py and recorded in
generation.json. The 31 original positive certificates are preserved in
previous_certificates/. The finite scope parameter is named arity in these
original files and is part of their input envelope.

CONTROLLED MODIFICATIONS

previous_k_open.py changes only outer-scope handling and its documentation.
It removes arity from the input envelope, wf, and infer, and allows every
nonnegative integer variable. Context lifting and substitution are unchanged.
In particular, the complete walk/shift/subst/inst source block is preserved
byte-for-byte. Its local parameter d is binding depth and is NOT removed.
The original bridge axiom and all arithmetic and logical rules remain.

previous_k_open_pattern.py additionally uses structural pattern matching for
the recursion proof tag. The pattern ('rec', ('r', n, a, h) as r) supplies the
shape check and unpacking that were previously repeated after matching r.
The well-formedness check remains. Every generated ordinary-connective
control uses this same parser refactor, so it cannot explain their remaining
size difference from the new kernel.

nd_sc_open.py implements ordinary intuitionistic natural deduction and the
six current drafts' common raw arithmetic core: separation, initialized
recursion, and the equation-indexed successor rule SC. It uses the common
native recursion representation, open scopes, and the parser refactor.
The drafts themselves contain no complete proof checker; this is a benchmark
implementation of their common theory, not a claim about an unavailable
original implementation. Trusted pruning and optimization machinery is absent.

nd_sc_reduced_open.py retains the older comparator's two elementary reductions:
reflexivity is derived, and contradiction and falsity share one elimination
rule. This prevents the comparison from relying on redundant baseline cases.

nd_nat_open.py and nd_nat_reduced_open.py replace SC by exactly the new kernel's
N rule: an equation template receives an induction hypothesis; every other
formula template receives no such hypothesis and performs numerical cases.
All ordinary connective constructors and logical rules remain.

nd_nat_bridge_open.py is the closest matched conventional-logic control.
Open scopes, recursive terms, substitution, equality elimination, N, the
closed falsity bridge, derived reflexivity, and derived general explosion
all match the new kernel. Only the ordinary logical constructors and their
introduction/elimination rules differ. Each generated file remains a complete
standalone checker, without importing a common uncounted kernel.

CORRECTED, VALIDATED TOKEN COUNTS

  Previous K, verbatim                              1289
  Previous K, outer arity removed                   1184
  Previous K, also shared recursion parser          1171
  New kernel                                       1167

The 122-token improvement over the delivered previous K decomposes as:

  105 tokens: removing explicit outer-arity plumbing;
   13 tokens: the shared recursion shape-parser refactor;
    4 tokens: the closed bridge, after both common changes.

The closed bridge is only a small source reduction. The previous K with
both common implementation changes has 1248 AST nodes; the new kernel has
1252. Thus the new source is four tokens shorter but four AST nodes larger.
It does not dominate that matched control on every secondary measure.

Ordinary-connective controls under the common open-scope/parser conventions:

  Ordinary ND + SC                                  1441
  Reduced ordinary ND + SC                          1409
  Ordinary ND + N                                   1442
  Reduced ordinary ND + N                           1410
  Ordinary logic, fully matched arithmetic/bridge   1402
  New kernel                                       1167

Against the closest matched ordinary-logic control the new kernel saves
235 tokens (16.762 percent) and 260 AST nodes (1512 -> 1252).
Against the verbatim previous K it saves 122 tokens (9.465 percent).
The same-scope/parser comparison with previous K is just 1171 -> 1167.
These are measured finite implementation upper bounds, not an absolute
minimality theorem or a claim about every possible programming language.

REPRODUCING THE RESULTS

From the package directory, with Python 3.10 or later:

  python3 comparisons/generate.py
  python3 comparisons/test_controls.py
  python3 comparisons/measure.py

Generation reads only the three preserved original source files, verifies
their hashes, and emits the listed controls. It does not edit code/checker.py.
The measurements are written as JSON, CSV, and LaTeX. The table and scalar
macros are conveniences, not components of any checker.

VALIDATION

The control suite passes 216 positive and 84 negative checks, plus 28
command-line runs. The positive count includes all 31 inherited certificates
replayed in each of the original, open-scope, and open-scope/parser K controls.
The other checks exercise ordinary logical rules, recursive computation,
equation induction or SC, non-equational cases, and bridge/falsity behavior.
Negative cases include capture of a universal eigenvariable, an escaping
existential witness, an illicit non-equational induction hypothesis,
malformed syntax, boolean and negative indices, and incorrect input envelopes.
The CLI checks run both normal and optimized Python on accepting and rejecting
inputs. The exact per-control results are in tests.json.

These finite checks establish neither universal checker soundness nor the
full bi-interpretability theorem. Those require the mathematical argument in
the report. The new kernel's own certificate suite and translation checks are
separate from this benchmark-control validation.
