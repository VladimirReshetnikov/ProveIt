"""Replay benchmark certificates and check the controls' binding interfaces.

These finite tests validate the executable controls and their transformations;
they are not a proof of universal soundness. The inherited 31 K certificates
are replayed unchanged except for deleting the arity field in open controls.
"""

import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parent
Z = ("z",)
F = ("false",)
CLASH = ("=", Z, ("s", Z))


def load(name):
    spec = importlib.util.spec_from_file_location(name.removesuffix(".py"), ROOT / name)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def eq(a, b):
    return ("=", a, b)


def lift(t, bound=0):
    if type(t) is int:
        return t + 1 if t >= bound else t
    if t[0] == "r":
        return ("r", lift(t[1], bound), lift(t[2], bound), lift(t[3], bound + 2))
    return (t[0], *(lift(x, bound) for x in t[1:]))


def refl(t):
    r = ("r", Z, t, 0)
    p = ("rec", r)
    return ("eq", p, eq(0, lift(t)), p)


def cert(goal, proof, assumptions=(), original=False):
    data = {"assumptions": list(assumptions), "goal": goal, "proof": proof}
    if original:
        data["arity"] = 1001
    return json.loads(json.dumps(data))


def run_check(module, data):
    try:
        return module.check(data) is True
    except (ValueError, TypeError, IndexError, KeyError, RecursionError):
        return False


def expect(module, name, data, accepted, rows):
    actual = run_check(module, data)
    if actual != accepted:
        raise RuntimeError(f"{module.__name__}: {name}: expected {accepted}, got {actual}")
    rows.append({"case": name, "expected_accept": accepted})


def nd_certificates(name):
    original = name.endswith("_original.py")
    numerical = "nat" in name
    closed_bridge = name == "nd_nat_bridge_open.py"
    cases = []

    def add(label, goal, proof, assumptions=()):
        cases.append((label, cert(goal, proof, assumptions, original)))

    add("open_parameter_hypothesis", eq(1000, Z), ("hyp", 0), [eq(1000, Z)])
    r0 = ("r", Z, 1000, 2)
    add("recursion_base_with_outer_parameter", eq(r0, 1000), ("rec", r0))
    rs = ("r", ("s", 0), 1, ("s", 0))
    add("recursion_step_with_parameters",
        eq(rs, ("s", ("r", 0, 1, ("s", 0)))), ("rec", rs))
    add("derived_reflexivity", eq(1000, 1000), refl(1000))
    both = ("&", eq(5, 5), eq(6, 6))
    pair = ("and", refl(5), refl(6))
    add("conjunction_introduction", both, pair)
    add("conjunction_projection", eq(5, 5), ("proj", 0, pair))
    choice = ("|", eq(9, 9), F)
    choose = ("in", choice, 0, refl(9))
    add("disjunction_introduction", choice, choose)
    add("disjunction_elimination", eq(5, 5), ("case", choose, refl(5), refl(5)))
    identity = ("imp", eq(9, 9), ("hyp", 0))
    add("implication_introduction", ("->", eq(9, 9), eq(9, 9)), identity)
    add("implication_elimination", eq(9, 9), ("app", identity, refl(9)))
    universal = ("all", refl(0))
    add("universal_introduction", ("all", eq(0, 0)), universal)
    add("universal_elimination", eq(1000, 1000), ("spec", universal, 1000))
    existential = ("exists", ("ex", eq(0, 0)), 99, refl(99))
    add("existential_introduction", ("ex", eq(0, 0)), existential)
    add("existential_elimination", eq(3, 3), ("let", existential, eq(3, 3), refl(4)))
    add("shift_retains_ambient_parameter", ("all", eq(1, Z)),
        ("all", ("hyp", 0)), [eq(0, Z)])
    if numerical:
        add("equation_induction", eq(5, 5),
            ("nat", eq(0, 0), 5, refl(Z), refl(("s", 0))))
        a = ("|", eq(0, 0), F)
        az = ("|", eq(Z, Z), F)
        ass = ("|", eq(("s", 0), ("s", 0)), F)
        add("nonequational_numerical_cases", ("|", eq(5, 5), F),
            ("nat", a, 5, ("in", az, 0, refl(Z)), ("in", ass, 0, refl(("s", 0)))))
    else:
        add("rooted_equation_successor_rule", ("|", eq(5, Z), eq(5, 5)),
            ("sc", eq(0, 0), 5, refl(("s", 0))))
    if closed_bridge:
        add("closed_bridge_to_clash", CLASH, ("bridge", ("hyp", 0)), [F])
        add("closed_bridge_to_falsity", F, ("bridge", ("hyp", 0)), [CLASH])
    else:
        add("falsity_elimination", eq(1000, Z), ("abort", ("hyp", 0), eq(1000, Z)), [F])
    return cases


def nd_rejections(name):
    original = name.endswith("_original.py")
    numerical = "nat" in name
    cases = []

    def add(label, goal, proof, assumptions=()):
        cases.append((label, cert(goal, proof, assumptions, original)))

    add("negative_variable", eq(-1, Z), ("hyp", 0), [eq(-1, Z)])
    add("boolean_variable", eq(True, Z), ("hyp", 0), [eq(True, Z)])
    add("boolean_hypothesis_index", eq(0, Z), ("hyp", False), [eq(0, Z)])
    add("negative_hypothesis_index", eq(0, Z), ("hyp", -1), [eq(0, Z)])
    add("out_of_range_hypothesis", eq(0, Z), ("hyp", 1), [eq(0, Z)])
    add("unknown_proof_rule", eq(Z, Z), ("magic",))
    add("malformed_formula_shape", ("=", Z), ("hyp", 0), [("=", Z)])
    add("universal_eigenvariable_capture", ("all", eq(0, Z)),
        ("all", ("hyp", 0)), [eq(0, Z)])
    add("escaping_existential_witness", eq(0, Z),
        ("let", ("hyp", 0), eq(0, Z), ("hyp", 1)), [("ex", eq(0, Z))])
    bad = ("r", 0, Z, 0)
    add("recursion_without_zero_or_successor", eq(bad, Z), ("rec", bad))
    if numerical:
        a = ("|", eq(0, 0), F)
        az = ("|", eq(Z, Z), F)
        add("forbidden_nonequational_induction_hypothesis", ("|", eq(5, 5), F),
            ("nat", a, 5, ("in", az, 0, refl(Z)), ("hyp", 0)))
    else:
        add("forbidden_nonequational_SC_template", F, ("sc", F, 0, ("hyp", 0)))
    schema = cert(eq(Z, Z), refl(Z), original=original)
    if original:
        del schema["arity"]
    else:
        schema["arity"] = 1
    cases.append(("wrong_envelope_schema", schema))
    return cases


def cli_checks(name, good):
    bad = dict(good, goal=["false"])
    rows = []
    with tempfile.TemporaryDirectory(prefix="ipra-control-") as directory:
        path = Path(directory) / "certificate.json"
        for optimized in (False, True):
            for data, accepted in ((good, True), (bad, False)):
                path.write_text(json.dumps(data))
                command = [sys.executable, *(("-O",) if optimized else ()), str(ROOT / name), str(path)]
                result = subprocess.run(command, capture_output=True, text=True)
                expected = (0, "ACCEPT") if accepted else (1, "REJECT")
                actual = (result.returncode, result.stdout.strip())
                if actual != expected:
                    raise RuntimeError(f"CLI {name}: expected {expected}, got {actual}")
                rows.append({"optimized_python": optimized, "expected_accept": accepted})
    return rows


def run():
    report = {}
    prior_files = sorted((ROOT / "previous_certificates").glob("*.json"))
    if len(prior_files) != 31:
        raise RuntimeError("expected the original 31 prior-K certificates")
    for name in ("previous_k.py", "previous_k_open.py", "previous_k_open_pattern.py"):
        module, rows = load(name), []
        for path in prior_files:
            data = json.loads(path.read_text())
            if name != "previous_k.py":
                del data["arity"]
            expect(module, "inherited/" + path.stem, data, True, rows)
        report[name] = {"accepted": len(rows), "rejected": 0, "cases": rows}
    for name in ("nd_sc_original.py", "nd_sc_reduced_original.py", "nd_sc_open.py",
                 "nd_sc_reduced_open.py", "nd_nat_open.py", "nd_nat_reduced_open.py",
                 "nd_nat_bridge_open.py"):
        module, rows = load(name), []
        positives = nd_certificates(name)
        negatives = nd_rejections(name)
        for label, data in positives:
            expect(module, label, data, True, rows)
        for label, data in negatives:
            expect(module, label, data, False, rows)
        report[name] = {"accepted": len(positives), "rejected": len(negatives),
                        "cases": rows, "cli_checks": cli_checks(name, positives[0][1])}
    result = {
        "description": __doc__.strip(),
        "accepted_count": sum(r["accepted"] for r in report.values()),
        "rejected_count": sum(r["rejected"] for r in report.values()),
        "cli_checks": sum(len(r.get("cli_checks", [])) for r in report.values()),
        "all_passed": True,
        "controls": report,
    }
    (ROOT / "tests.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "controls"}, indent=2))
    return result


if __name__ == "__main__":
    run()
