A SMALLER COMPLETE KERNEL FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
6 November 2026

Main result
-----------
The supplied calculus K is bi-interpretable and syntactically equiconsistent
with full first-order iPRA (quantifier-free induction, all fixed primitive-
recursive descriptions, genuine intuitionistic logic). The report specifies
every primitive logical and nonlogical rule and proves both round trips.

The complete trusted checker has 1,167 significant Python tokens and
1,252 Python AST nodes. It contains syntax validation, capture-avoiding
substitution, all primitive inference checks, fixed data, and the CLI.
No external proof builder, compiler, normalizer, or theorem prover is
required to validate a native certificate.

The term language uses initialized primitive recursion. The formula language
uses equality, genuine falsity, Pi=forall(implication), and
Sigma=exists(conjunction). A closed bridge exchanges falsity and 0=S0.
The numerical rule is equation induction for equations and number cases
otherwise. All nonnegative variable indices are legal ambient variables;
local binders still enforce freshness by shifting the complete context.

Exact comparison
----------------
Previous delivered compact checker:                1,289 tokens / 1,393 AST
Previous, matched open scopes and recursion parser: 1,171 tokens / 1,248 AST
New kernel:                                        1,167 tokens / 1,252 AST
Ordinary logic, exactly matched arithmetic:         1,402 tokens / 1,512 AST
Reduced implementation of current draft SC core:    1,409 tokens / 1,515 AST

The 122-token saving over the previous delivered checker decomposes as
105 (outer arity), 13 (shared recursion parser), and 4 (closed bridge).
The final four-token improvement increases the AST count by four nodes.
No encoding-independent minimum or proof-length/runtime improvement is claimed.

The six current GitHub drafts contain diagnostics, not complete proof
checkers. The comparison therefore supplies explicit implementations of
their common core. Their original diagnostic-program lengths are not used
as proof-checker measurements. Exact provenance and specifications are included.

Files
-----
ipra_kernel_2026-11-06.pdf  Complete report, proofs, comparisons, full checker.
report.tex, sections/      All LaTeX sources.
SPECIFICATION.txt         Standalone exact calculus and certificate format.
code/checker.py           Entire trusted production verifier.
code/derived.py           Untrusted proof-producing logical/arithmetic macros.
code/to_previous.py       Untrusted expansion to the earlier complete verifier.
code/test_kernel.py       Certificate and rejection suite.
code/adversarial.py       Independent capture/scope/adversarial fixtures.
certificates/             53 accepted, replayable native certificates.
verification.json         Main suite results and test names.
comparisons/              All complete benchmark checkers, generators, tests,
                         measured JSON/CSV/TeX, and independent kernel review.
provenance/               Pinned repository sources, verified hashes, six specs.
quality_checks.json       Final PDF and archive review information.
build.py                  Offline PDF/archive build.
SHA256SUMS.txt            Checksums for all other delivered files.

Reproduction
------------
Python 3.10+; no third-party Python packages for the kernel or its tests.
Run commands from this extracted directory:

  python3 comparisons/generate.py
  python3 comparisons/test_controls.py
  python3 comparisons/measure.py
  python3 code/test_kernel.py
  python3 code/checker.py certificates/new_or_elimination_2.json
  python3 build.py

The final command additionally needs a normal pdflatex installation with
the packages listed in report.tex. It creates the PDF here and a ZIP in
the parent directory. --package-only refreshes the archive without recompiling.

Validation
----------
Main suite: 53 accepted certificates, 24 rejected invalid inputs, and 53
cross-checks by translation into the previous complete verifier. All 31
previous certificate fixtures are replayed in both implementations.
Comparator suite: 216 positive checks, 84 negative checks, 28 CLI runs.
Normal and optimized Python retain all inference validation.

The universal soundness and interpretation results have written mathematical
proofs and separate reviews, not a completed Lean/Rocq formalization.
Resource limits can reject valid excessively deep inputs; they never license
additional inferences. The report includes further research questions.
