"""Reproduce certificate checks, old-kernel replay, and rejection tests.

These are finite regression checks of executable proofs, not a formal
verification of the universal soundness or interpretation theorems.
"""

import importlib.util
import json
from pathlib import Path
import subprocess
import sys

import checker as k
import derived as d
import to_previous
from adversarial import cases

ROOT = Path(__file__).resolve().parents[1]


def load_previous():
    spec = importlib.util.spec_from_file_location("previous", ROOT / "comparisons/previous_k.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run():
    previous = load_previous()
    accepted = {}
    for path in sorted((ROOT / "comparisons/previous_certificates").glob("*.json")):
        old = json.loads(path.read_text())
        previous.check(old)
        g = tuple(map(k.freeze, old["assumptions"]))
        p = d.translate_previous(k.freeze(old["proof"]), g)
        accepted["legacy_" + path.stem] = d.certificate(k.freeze(old["goal"]), p, g)

    accepted["closed_bridge_forward"] = d.certificate(k.CLASH, ("bridge", ("hyp", 0)), [k.FALSE])
    accepted["closed_bridge_backward"] = d.certificate(k.FALSE, ("bridge", ("hyp", 0)), [k.CLASH])
    accepted["arbitrary_equation_from_clash"] = d.certificate(
        d.eq(0, 1), d.collapse(("hyp", 0), 0, 1), [k.CLASH])
    term = d.rec(0, 1, d.suc(2))
    accepted["collapse_beneath_recursion"] = d.certificate(
        d.eq(term, 2), d.collapse(("hyp", 0), term, 2), [k.CLASH])
    compound = ("pi", d.eq(0, 1), ("sig", d.eq(2, 1), ("pi", k.FALSE, d.eq(1, 3))))
    accepted["structural_explosion"] = d.certificate(
        compound, d.explode(("hyp", 0), compound, 1), [k.FALSE])
    accepted["general_successor_separation"] = d.certificate(
        k.FALSE, d.separate(0, ("hyp", 0)), [d.eq(d.Z, d.suc(0))])
    accepted["large_variable_reflexivity"] = d.certificate(d.eq(10**50, 10**50), d.refl(10**50))
    formulas = [
        (d.TRUE, k.FALSE, d.TRUE),
        (d.eq(0, d.Z), d.eq(1, d.ONE), d.eq(2, 0)),
        (("pi", d.eq(0, 1), d.eq(2, 0)), ("sig", d.eq(0, 1), k.FALSE),
         ("sig", ("pi", d.eq(0, 2), d.eq(1, 3)), d.TRUE)),
    ]
    for i, (a, b, c) in enumerate(formulas):
        accepted[f"new_or_left_{i}"] = d.certificate(d.disjunction(a, b), d.or_left(a, b), [a])
        accepted[f"new_or_right_{i}"] = d.certificate(d.disjunction(a, b), d.or_right(a, b), [b])
        accepted[f"new_or_elimination_{i}"] = d.certificate(
            c, d.or_eliminate(a, b, c), [d.disjunction(a, b), d.implies(a, c), d.implies(b, c)])

    rejected = {}
    for name, document, expected in cases:
        if expected:
            accepted[name] = document
        else:
            rejected[name] = document
    rejected.update({
        "no_bridge_axiom_leaf": {"assumptions": [], "goal": k.FALSE, "proof": ["bridge"]},
        "primitive_reflexivity_absent": {"assumptions": [], "goal": d.TRUE, "proof": ["refl", d.Z]},
        "primitive_explosion_absent": {"assumptions": [k.FALSE], "goal": d.TRUE,
                                      "proof": ["abort", ["hyp", 0], d.TRUE]},
        "rec_term_is_variable": {"assumptions": [], "goal": d.TRUE, "proof": ["rec", 0]},
        "rec_wrong_arity": {"assumptions": [], "goal": d.TRUE, "proof": ["rec", ["r", d.Z, d.Z]]},
        "rec_false_body": {"assumptions": [], "goal": d.TRUE,
                           "proof": ["rec", ["r", d.Z, d.Z, k.FALSE]]},
        "boolean_goal": {"assumptions": [d.eq(1, d.Z)], "goal": d.eq(True, d.Z), "proof": ["hyp", 0]},
        "extra_root_field": {"assumptions": [d.TRUE], "goal": d.TRUE, "proof": ["hyp", 0], "arity": 0},
        "boolean_nat_target": {"assumptions": [k.FALSE], "goal": k.FALSE,
                               "proof": ["nat", k.FALSE, True, ["hyp", 0], ["hyp", 0]]},
        "negative_hypothesis_index": {"assumptions": [d.TRUE], "goal": d.TRUE, "proof": ["hyp", -1]},
        "unproved_false": {"assumptions": [], "goal": k.FALSE, "proof": ["hyp", 0]},
        "malformed_equation_template": {"assumptions": [d.TRUE], "goal": d.TRUE,
                                        "proof": ["eq", ["hyp", 0], ["=", 0], ["hyp", 0]]},
    })

    output = ROOT / "certificates"
    output.mkdir(exist_ok=True)
    for name, document in accepted.items():
        decoded = json.loads(json.dumps(document))
        if k.check(decoded) is not True:
            raise AssertionError(name)
        # Different bridge and explicit finite arity in the earlier verifier.
        previous.check(to_previous.certificate(decoded))
        (output / (name + ".json")).write_text(json.dumps(document, separators=(",", ":")) + "\n")
    for name, document in rejected.items():
        try:
            k.check(json.loads(json.dumps(document)))
        except (ValueError, TypeError, IndexError, KeyError, RecursionError):
            continue
        raise AssertionError("accepted invalid certificate: " + name)

    invalid = ROOT / "invalid_example.json"
    invalid.write_text(json.dumps(rejected["non_equation_induction"]))
    cli = []
    for optimize in (False, True):
        command = [sys.executable, *(["-O"] if optimize else []), str(ROOT / "code/checker.py")]
        for path, expected in ((output / "new_or_elimination_2.json", 0), (invalid, 1)):
            result = subprocess.run([*command, str(path)], text=True, capture_output=True)
            if result.returncode != expected:
                raise AssertionError((optimize, path.name, result.stdout, result.stderr))
            cli.append({"optimized": optimize, "file": path.name, "exit": result.returncode,
                        "output": result.stdout.strip()})
    invalid.unlink()
    results = {
        "accepted_count": len(accepted), "rejected_count": len(rejected),
        "previous_kernel_cross_checks": len(accepted), "legacy_fixtures_replayed": 31,
        "accepted": list(accepted), "rejected": list(rejected), "cli": cli,
        "scope": "Finite executable-certificate tests; no machine-checked universal metatheorem.",
    }
    (ROOT / "verification.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps({key: results[key] for key in ("accepted_count", "rejected_count",
          "previous_kernel_cross_checks", "legacy_fixtures_replayed")}, indent=2))
    return results


if __name__ == "__main__":
    run()
