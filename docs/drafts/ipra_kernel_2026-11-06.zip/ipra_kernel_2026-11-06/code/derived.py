"""Untrusted proof builders. The kernel never imports this module."""

import checker as k

Z, FALSE = k.ZERO, k.FALSE
ONE = ("s", Z)
TRUE = ("=", Z, Z)


def eq(s, t):
    return ("=", s, t)


def suc(t):
    return ("s", t)


def rec(n, a, h):
    return ("r", n, a, h)


def implies(a, b):
    return ("pi", k.shift(a), k.shift(b))


def conjunction(a, b):
    return ("sig", k.shift(a), k.shift(b))


def disjunction(a, b):
    # Outer b, inner y: b is index 1 and y is index 0.
    return ("sig", ("pi", eq(1, Z), k.shift(a, 2)),
            ("pi", eq(1, suc(0)), k.shift(b, 2)))


def refl(t):
    p = ("rec", rec(Z, t, Z))
    return ("eq", p, eq(0, k.shift(t)), p)


def sym(p, left):
    return ("eq", p, eq(0, k.shift(left)), refl(left))


def trans(p, q, left):
    return ("eq", q, eq(k.shift(left), 0), p)


def collapse(clash_proof, s, t):
    """From 0=S0 derive s=t using one constant-update selector."""
    h = k.shift(t, 2)
    r1 = rec(ONE, s, h)
    template = eq(rec(0, k.shift(s), k.shift(t, 3)), k.shift(s))
    moved = ("eq", clash_proof, template, ("rec", rec(Z, s, h)))
    return trans(sym(moved, r1), ("rec", r1), s)


def separate(n, zero_successor_proof):
    """From 0=S(n) derive genuine FALSE without induction."""
    r1 = rec(suc(n), Z, ONE)
    moved = ("eq", zero_successor_proof, eq(rec(0, Z, ONE), Z),
             ("rec", rec(Z, Z, ONE)))
    clash = trans(sym(moved, r1), ("rec", r1), Z)
    return ("bridge", clash)


def lift(p, context_size, bound=0):
    """Insert a fresh outer number and one hypothesis; protect local binders."""
    def term(a, extra=0):
        return k.walk(a, lambda i, d: i + d + 1, bound + extra)

    def proof(q, extra=0):
        return lift(q, context_size, bound + extra)

    match p:
        case ("hyp", i):
            return ("hyp", i + (i >= context_size))
        case ("pi", a, q):
            return ("pi", term(a, 1), proof(q, 1))
        case ("app", p, t, q):
            return ("app", proof(p), term(t), proof(q))
        case ("pair", a, t, p, q):
            return ("pair", term(a), term(t), proof(p), proof(q))
        case ("let", p, a, q):
            return ("let", proof(p), term(a), proof(q, 1))
        case ("eq", p, a, q):
            return ("eq", proof(p), term(a, 1), proof(q))
        case ("rec", r):
            return ("rec", term(r))
        case ("nat", a, t, p, q):
            return ("nat", term(a, 1), term(t), proof(p), proof(q, 1))
        case ("bridge", p):
            return ("bridge", proof(p))
        case _:
            raise ValueError("unknown proof in untrusted lifting procedure")


def explode(false_proof, formula, context_size):
    """Emit ordinary kernel rules deriving formula from an actual FALSE proof."""
    match formula:
        case ("false",):
            return false_proof
        case ("=", s, t):
            return collapse(("bridge", false_proof), s, t)
        case ("pi", a, b):
            return ("pi", a, explode(lift(false_proof, context_size), b, context_size + 1))
        case ("sig", a, b):
            return ("pair", formula, Z,
                    explode(false_proof, k.inst(a, Z), context_size),
                    explode(false_proof, k.inst(b, Z), context_size))
        case _:
            raise ValueError("unknown formula")


SEPARATION = ("pi", eq(Z, suc(0)), FALSE)
COLLAPSE = ("pi", FALSE, eq(0, Z))
OLD_BRIDGE = ("sig", SEPARATION, COLLAPSE)


def old_bridge(context_size):
    separation = ("pi", eq(Z, suc(0)), separate(0, ("hyp", context_size)))
    collapsing = ("pi", FALSE, collapse(("bridge", ("hyp", context_size)), 0, Z))
    return ("pair", OLD_BRIDGE, Z, separation, collapsing)


def translate_previous(p, g):
    """Replace the previous fixed bridge by its explicit derivation here."""
    def proof(q):
        return translate_previous(q, g)

    match p:
        case ("hyp", _) | ("rec", _):
            return p
        case ("bridge",):
            return old_bridge(len(g))
        case ("pi", a, q):
            return ("pi", a, translate_previous(q, (*map(k.shift, g), a)))
        case ("app", p, t, q):
            return ("app", proof(p), t, proof(q))
        case ("pair", a, t, p, q):
            return ("pair", a, t, proof(p), proof(q))
        case ("let", p, c, q):
            translated = proof(p)
            a = k.infer(translated, g)
            return ("let", translated, c,
                    translate_previous(q, (*map(k.shift, g), a[1], a[2])))
        case ("eq", p, a, q):
            return ("eq", proof(p), a, proof(q))
        case ("nat", a, t, p, q):
            h = (a,) if a[0] == "=" else ()
            return ("nat", a, t, proof(p), translate_previous(q, (*map(k.shift, g), *h)))
        case _:
            raise ValueError("unknown previous proof")


def or_left(a, b, assumption=0, context_size=1):
    first = ("pi", TRUE, ("hyp", assumption))
    second = ("pi", eq(Z, suc(0)),
              explode(separate(0, ("hyp", context_size)), k.shift(b), context_size + 1))
    return ("pair", disjunction(a, b), Z, first, second)


def or_right(a, b, assumption=0, context_size=1):
    first = ("pi", eq(ONE, Z),
             explode(("bridge", sym(("hyp", context_size), ONE)),
                     k.shift(a), context_size + 1))
    second = ("pi", eq(ONE, suc(0)), ("hyp", assumption))
    return ("pair", disjunction(a, b), ONE, first, second)


def or_eliminate(a, b, c):
    """Under [a OR b, a->c, b->c], emit c, preserving all parameters."""
    # Opening the Sigma witness adds tag b at number slot 0 and U,V at
    # hypothesis slots 3,4. Cases on (b=x -> c) keep U,V fixed.
    predicate = implies(eq(1, 0), k.shift(c, 2))
    base = ("pi", eq(1, Z),
            ("app", ("hyp", 1), Z,
             ("app", ("hyp", 3), Z, ("hyp", 5))))
    step = ("pi", eq(2, suc(1)),
            ("app", ("hyp", 2), Z,
             ("app", ("hyp", 4), 1, ("hyp", 5))))
    cases = ("nat", predicate, 0, base, step)
    return ("let", ("hyp", 0), c, ("app", cases, Z, refl(0)))


def certificate(goal, proof, assumptions=()):
    result = {"assumptions": list(assumptions), "goal": goal, "proof": proof}
    k.check(result)
    return result
