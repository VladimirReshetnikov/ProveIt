"""Untrusted expansion of the new bridge back to the previous full checker."""

import checker as k
from derived import Z, ONE, FALSE, SEPARATION, COLLAPSE, sym


def translate(p, g):
    def proof(q):
        return translate(q, g)

    match p:
        case ("hyp", _) | ("rec", _):
            return p
        case ("pi", a, q):
            return ("pi", a, translate(q, (*map(k.shift, g), a)))
        case ("app", p, t, q):
            return ("app", proof(p), t, proof(q))
        case ("pair", a, t, p, q):
            return ("pair", a, t, proof(p), proof(q))
        case ("let", p, c, q):
            a = k.infer(p, g)
            return ("let", proof(p), c, translate(q, (*map(k.shift, g), a[1], a[2])))
        case ("eq", p, a, q):
            return ("eq", proof(p), a, proof(q))
        case ("nat", a, t, p, q):
            h = (a,) if a[0] == "=" else ()
            return ("nat", a, t, proof(p), translate(q, (*map(k.shift, g), *h)))
        case ("bridge", p):
            premise = k.infer(p, g)
            if premise == FALSE:
                collapse = ("let", ("bridge",), COLLAPSE, ("hyp", len(g) + 1))
                return sym(("app", collapse, ONE, proof(p)), ONE)
            if premise == k.CLASH:
                separate = ("let", ("bridge",), SEPARATION, ("hyp", len(g)))
                return ("app", separate, Z, proof(p))
            raise ValueError("invalid bridge premise")
        case _:
            raise ValueError("unknown proof tag")


def index_bound(value):
    if type(value) is int:
        return max(0, value + 1)
    if type(value) in (list, tuple):
        return max((index_bound(x) for x in value), default=0)
    if type(value) is dict:
        return max((index_bound(x) for x in value.values()), default=0)
    return 0


def certificate(document):
    k.check(document)
    g = tuple(map(k.freeze, document["assumptions"]))
    result = dict(document)
    result["proof"] = translate(k.freeze(document["proof"]), g)
    result["arity"] = index_bound(result)
    return result
