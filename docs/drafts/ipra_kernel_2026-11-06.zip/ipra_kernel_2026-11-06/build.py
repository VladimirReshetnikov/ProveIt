"""Build the report and reproducible source archive; no network access needed."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
NAME = "ipra_kernel_2026-11-06"


def metric_table():
    subprocess.run([sys.executable, str(ROOT / "comparisons/measure.py")], check=True,
                   stdout=subprocess.DEVNULL)
    data = json.loads((ROOT / "comparisons/metrics.json").read_text())
    choices = [
        ("previous_k.py", "Earlier compact checker, verbatim"),
        ("previous_k_open_pattern.py", "Earlier compact checker, matched scope/parser"),
        ("nd_sc_open.py", "Ordinary logic with draft (SC) core"),
        ("nd_sc_reduced_open.py", "Reduced ordinary logic with draft (SC) core"),
        ("nd_nat_bridge_open.py", "Ordinary logic, exactly matched arithmetic"),
        ("../code/checker.py", "Proposed complete kernel"),
    ]
    rows = [r"\begin{center}\small", r"\begin{tabularx}{\textwidth}{@{}Xrr@{}}",
            r"\toprule", r"Complete implementation & Tokens & AST nodes\\", r"\midrule"]
    for name, label in choices:
        row = next(x for x in data["variants"] if x["file"] == name)
        rows.append(label + " & " + str(row["meaningful_python_tokens"]) + " & "
                    + str(row["ast_nodes"]) + r"\\")
    rows += [r"\bottomrule", r"\end{tabularx}", r"\end{center}"]
    (ROOT / "metrics_table.tex").write_text("\n".join(rows) + "\n")


def pdf():
    metric_table()
    directory = ROOT / "build"
    directory.mkdir(exist_ok=True)
    env = os.environ.copy()
    # Some minimal environments supply a locally generated LaTeX format.
    # A normal TeX installation uses its standard installed format instead.
    if (directory / "pdflatex.fmt").is_file():
        env["TEXFORMATS"] = str(directory) + os.pathsep + env.get("TEXFORMATS", "")
    command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
               "-jobname=" + NAME, "-output-directory=" + str(directory), "report.tex"]
    for number in range(1, 4):
        with (directory / f"latex_pass_{number}.txt").open("w") as stream:
            subprocess.run(command, cwd=ROOT, env=env, stdout=stream,
                           stderr=subprocess.STDOUT, check=True)
    log = (directory / (NAME + ".log")).read_text()
    if "Overfull" in log or "undefined references" in log or "undefined citations" in log:
        raise RuntimeError("Inspect final LaTeX log before packaging")
    shutil.copyfile(directory / (NAME + ".pdf"), ROOT / (NAME + ".pdf"))
    print("Compiled", NAME + ".pdf")


def files():
    excluded = {"build", "qa", "__pycache__", ".git"}
    return sorted(p for p in ROOT.rglob("*") if p.is_file()
                  and not any(part in excluded for part in p.relative_to(ROOT).parts)
                  and p.suffix not in {".pyc", ".zip"}
                  and p.name != "SHA256SUMS.txt")


def package():
    if not (ROOT / (NAME + ".pdf")).is_file():
        raise FileNotFoundError("Compile the PDF before packaging")
    selected = files()
    checksums = "".join(hashlib.sha256(p.read_bytes()).hexdigest() + "  "
                        + p.relative_to(ROOT).as_posix() + "\n" for p in selected)
    manifest = ROOT / "SHA256SUMS.txt"
    manifest.write_text(checksums)
    archive = ROOT.parent / (NAME + ".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in [*selected, manifest]:
            info = zipfile.ZipInfo(NAME + "/" + path.relative_to(ROOT).as_posix(),
                                   date_time=(2026, 11, 6, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, path.read_bytes())
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise RuntimeError("ZIP integrity failure")
        for line in checksums.splitlines():
            digest, name = line.split("  ", 1)
            if hashlib.sha256(z.read(NAME + "/" + name)).hexdigest() != digest:
                raise RuntimeError("ZIP checksum failure: " + name)
    print("Packaged", archive.name, "with", len(selected) + 1, "files")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-only", action="store_true")
    args = parser.parse_args()
    if not args.package_only:
        pdf()
    package()
