#!/bin/sh
set -eu
PRA_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$PRA_DIR"
mkdir -p audit build
python3 artifacts/check_schemas.py --json audit/schema_checks.json --tsv comparison.tsv > audit/python_checks.log
PRA_LEAN=lean
if [ "$#" -gt 0 ]; then
    PRA_LEAN="$1"
fi
if command -v "$PRA_LEAN" >/dev/null 2>&1; then
    "$PRA_LEAN" formal/ShiftedUniqueness.lean > formal/verification.log
else
    printf '%s\n' 'Lean was not found. Install Lean 4.19.0 or pass its executable as the first argument.'
    printf '%s\n' 'The packaged Lean verification log is retained; no new Lean run is claimed.'
fi
pdflatex -halt-on-error -interaction=nonstopmode -output-directory=build pra_shifted_uniqueness.tex > build/pass1.log
pdflatex -halt-on-error -interaction=nonstopmode -output-directory=build pra_shifted_uniqueness.tex > build/pass2.log
pdflatex -halt-on-error -interaction=nonstopmode -output-directory=build pra_shifted_uniqueness.tex > build/pass3.log
cp build/pra_shifted_uniqueness.pdf pra_shifted_uniqueness.pdf
printf '%s\n' 'Built pra_shifted_uniqueness.pdf and regenerated schema checks.'
