SIMPLER AXIOMATIZATIONS OF PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov -- 31 October 2026
====================================================

Read pra_shifted_uniqueness.pdf for the complete self-contained report.
The main LaTeX source is pra_shifted_uniqueness.tex, with supporting
sections in sections/.

RESULT

The same nonlogical bases work in classical and intuitionistic equality
logic. Ordinary zero-based recurrence premises suffice in place of the
current drafts' positive-tail recurrence premises.

1. USU: ordinary full primitive-recursive description language, unary
   arithmetic update, arbitrary finite fixed parameter tuples. Its
   one-parameter arithmetic display has 36 nodes instead of 38.

2. SU: restricted binary initialized iterators, counter/state update,
   one fixed numerical parameter. Its arithmetic display has 37 nodes
   instead of 39; its two computation templates add 18 nodes, so the
   total template metric falls from 57 to 55.

Both displays have four equality occurrences and three axiom templates
including computation. These are infinitely instantiated templates in
effective infinite languages, not three individual first-order axioms.

The binary conclusion uses I_(h+) where h+(k,v)=h(Sk,v). This descriptor
shift is explicit; its cost is not included in the existing index-opaque
formula-tree metric. Unary updates have h+=h. No absolute shortestness
or historical-priority claim is made.

The report proves:
  - SU implies ordinary term recursion uniqueness, before coverage.
  - One fixed instance supplies separation and positive coverage.
  - SU is equivalent to separation + coverage + ordinary uniqueness.
  - SU and the previous positive-uniqueness family are equivalent.
  - Both complete presentations recover exactly the corresponding PRA.

Classical and intuitionistic first-order equivalence are separate
statements. Only the native quantifier-free calculi are identified.

FILES

pra_shifted_uniqueness.pdf       Compiled research report.
pra_shifted_uniqueness.tex       Main source.
sections/                       Complete proof and reference sources.
specification.txt               Exact plain-text axioms and side conditions.
formal/ShiftedUniqueness.lean    Checked finite-syntax constructive kernel.
formal/verification.log         Successful Lean dependency audit.
formal/README.txt               Exact formal verification scope.
artifacts/check_schemas.py      AST counts, syntax checks, explicit witnesses.
audit/schema_checks.json        Counted formula trees and check results.
audit/source_audit.json         Immutable source paths and cryptographic hashes.
audit/python_checks.log         Python verification summary.
audit/verification_summary.txt  Build and verification summary.
comparison.tsv                  Machine-readable comparison table.
build.sh                        Reproduction script.
SHA256SUMS.txt                   Hashes of the packaged files.

BUILD

Requirements:
  - Python 3.10 or later; standard library only.
  - Lean 4.19.0 for the formal kernel; no imports or external packages.
  - pdfLaTeX with the packages named at the top of the main source.
    A standard TeX Live installation is sufficient.

From this directory:
  sh build.sh

If Lean is not on PATH:
  sh build.sh /absolute/path/to/lean

The script regenerates the Python results and the PDF. It runs Lean if
the selected executable is available; otherwise it retains the packaged
verification log and explicitly says that no new Lean run occurred.
Intermediate TeX files go into build/.

To run just the certificates:
  python3 artifacts/check_schemas.py --json audit/schema_checks.json --tsv comparison.tsv
  lean formal/ShiftedUniqueness.lean

VERIFICATION SCOPE

The Lean kernel was checked with Lean 4.19.0. All 22 printed dependency
reports are empty. The arithmetic hypotheses are explicit theorem
arguments. The carrier is arbitrary and the schema ranges over finite
terms; no induction or decidable equality on that carrier is assumed
in the forward reduction.

The entire first-order calculus, both arithmetic completions, and full
PRA conservativity are proved in the manuscript but are not all
machine-formalized. The Python checks are finite-syntax and accounting
checks, not numerical experiments offered as proofs of arithmetic
equivalence.

PROVENANCE

Comparison snapshot:
  VladimirReshetnikov/ProveIt
  b0350fd1c96d8273ca9c3b5ce025782b748cded7

All six current PRA archives under docs/drafts were inspected, including
the subsidiary TeX proofs. The docs/incoming inventory and full index
contained no additional PRA-labelled item. Unrelated Busy Beaver
archives were not unpacked.

The new contribution is the ordinary-premise schema and equivalence
kernel. The ordinary-language descent/latch completion and the
restricted-language one-bit/diagonal/maximum completion are inherited
from the supplied positive-uniqueness drafts and explicitly attributed.
The seeded selector is also attributed. No prior archive is repackaged
as a new result.
