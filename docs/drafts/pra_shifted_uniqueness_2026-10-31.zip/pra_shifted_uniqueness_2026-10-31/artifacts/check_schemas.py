#!/usr/bin/env python3
"""Reproduce schematic AST counts and finite-syntax checks.

These checks are not a proof of PRA equivalence. The Lean certificate checks
the new logical kernel; the manuscript proves the arithmetic completion.
Python 3.10+; standard library only.
"""
from __future__ import annotations
import argparse
import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Node:
    tag: str
    label: str = ""
    children: tuple[Node, ...] = ()

    def size(self):
        return 1 + sum(c.size() for c in self.children)

    def equalities(self):
        return int(self.tag == "eq") + sum(c.equalities() for c in self.children)

    def tree(self):
        return {"tag": self.tag,
                **({"label": self.label} if self.label else {}),
                **({"children": [c.tree() for c in self.children]} if self.children else {})}


def var(name): return Node("var", name)
def app(name, *args): return Node("app", name, tuple(args))
def eq(a, b): return Node("eq", children=(a, b))
def imp(a, b): return Node("implies", children=(a, b))
def conj(a, b): return Node("and", children=(a, b))
def disj(a, b): return Node("or", children=(a, b))
def all_(name, body): return Node("forall", name, (body,))
def succ(t): return app("S", t)
ZERO = Node("constant", "0")
ONE = succ(ZERO)
BOTTOM = Node("bottom")
SEP = imp(eq(ZERO, ONE), BOTTOM)


def close(parameters, formula):
    for p in reversed(parameters):
        formula = all_(p.label, formula)
    return formula


def uniqueness_schema(m, update_arity, positive_premise, ternary_iterator=False):
    """Count displayed applications, with indices opaque."""
    assert update_arity in (1, 2, 3)
    assert not ternary_iterator or (m == 1 and update_arity == 3)
    n = var("n")
    pars = [var(f"a{i+1}") for i in range(m)]
    f = lambda x: app("f", x, *pars)
    if positive_premise:
        lhs, current = f(succ(succ(n))), f(succ(n))
    else:
        lhs, current = f(succ(n)), f(n)
    if update_arity == 1:
        rhs = app("h", current)
    elif update_arity == 2:
        rhs = app("h", n, current)
    else:
        rhs = app("h", n, current, pars[0])
    premise = all_("n", eq(lhs, rhs))
    if ternary_iterator:
        predecessor = app("R_counter", n, ZERO, ZERO)
        tail = app("R_h", predecessor, f(ONE), pars[0])
    else:
        predecessor = app("P", n, ZERO)
        index = "I_h" if positive_premise or update_arity == 1 else "I_h_plus"
        tail = app(index, predecessor, f(ONE))
    conclusion = conj(SEP, all_("n", disj(eq(n, ZERO), eq(f(n), tail))))
    return close(pars, imp(premise, conclusion))


def reflexive_base(m):
    n = var("n")
    pars = [var(f"a{i+1}") for i in range(m)]
    e = lambda t: eq(app("s", t, *pars), app("t", t, *pars))
    premise = all_("n", imp(e(n), e(succ(n))))
    conclusion = conj(SEP, all_("n", disj(eq(n, ZERO), e(n))))
    return close(pars, imp(premise, conclusion))


def binary_computation():
    n, a = var("n"), var("a")
    base = all_("a", eq(app("I_h", ZERO, a), a))
    step = all_("n", all_("a", eq(
        app("I_h", succ(n), a), app("h", n, app("I_h", n, a)))))
    return base, step


# A stored update has its own bound slots, so free substitution skips it.
@dataclass(frozen=True)
class Term:
    tag: str
    args: tuple[Term, ...] = ()


X, Y, Z = Term("first"), Term("second"), Term("zero")
def S(t): return Term("succ", (t,))
def I(h, n, a): return Term("iter", (h, n, a))


def substitute(t, x, y):
    if t.tag == "first": return x
    if t.tag == "second": return y
    if t.tag == "zero": return t
    if t.tag == "succ": return S(substitute(t.args[0], x, y))
    h, n, a = t.args
    return I(h, substitute(n, x, y), substitute(a, x, y))


def shift(h): return substitute(h, S(X), Y)


def free_counter_occurrences(t):
    if t.tag == "first": return 1
    if t.tag in ("second", "zero"): return 0
    children = t.args[1:] if t.tag == "iter" else t.args
    return sum(free_counter_occurrences(c) for c in children)


def descriptor_size(t):
    return 1 + sum(descriptor_size(c) for c in t.args)


def syntax_checks():
    samples = [X, Y, S(Y), S(X), I(X, Y, Z),
               I(S(X), X, I(Y, X, Y)),
               I(I(X, S(X), Y), I(X, X, Y), S(X))]
    checks = []
    for i, t in enumerate(samples):
        delta = descriptor_size(shift(t)) - descriptor_size(t)
        occurrences = free_counter_occurrences(t)
        assert delta == occurrences
        checks.append({"sample": i, "counter_occurrences": occurrences,
                       "descriptor_growth": delta})
    assert shift(S(Y)) == S(Y)
    assert shift(I(X, Y, Z)) == I(X, Y, Z)
    nested = I(S(X), X, I(Y, X, Y))
    shifted = shift(nested)
    assert shifted == I(S(X), S(X), I(Y, S(X), Y))
    assert shifted.args[0] == nested.args[0]
    assert shifted.args[2].args[0] == nested.args[2].args[0]
    return {"size_identity_samples": checks, "unary_update_fixed": True,
            "nested_indices_preserved": True}


def iterate(update, n, seed):
    state = seed
    for k in range(n):
        state = update(k, state)
    return state


def deletion_witnesses():
    h = lambda k, v: k + 1
    h_plus = lambda k, v: h(k + 1, v)
    unshifted, shifted = iterate(h, 1, 1), iterate(h_plus, 1, 1)
    assert unshifted == 1 and shifted == 2
    at_zero = iterate(lambda k, v: v + 1, 0, 1)
    assert at_zero == 1 and at_zero != 0
    pair = (0, 1)
    successor_pred = tuple(max(x - 1, 0) + 1 for x in pair)
    assert pair != (0, 0) and pair != successor_pred
    return {
        "drop_shift": {"f(2)": 2, "I_h(1,1)": unshifted,
                       "I_h_plus(1,1)": shifted},
        "drop_zero_guard": {"f(0)": 0, "positive_tail_at_zero": at_zero},
        "product_coverage_failure": {"x": pair, "zero": (0, 0),
                                     "successor_predecessor": successor_pred},
        "scope": "Explicit witnesses only; universal claims are proved in the paper.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", type=Path)
    parser.add_argument("--tsv", type=Path)
    args = parser.parse_args()
    schemas = {
        "RB_seeded_selector": reflexive_base(1),
        "single_replacement": reflexive_base(1),
        "syntactic_involution_endpoint_metric": reflexive_base(1),
        "PU_unary_full_language": uniqueness_schema(1, 1, True),
        "PU_binary_one_parameter": uniqueness_schema(1, 2, True),
        "PU_ternary": uniqueness_schema(1, 3, True, True),
        "USU_unary_full_language": uniqueness_schema(1, 1, False),
        "SU_binary_one_parameter": uniqueness_schema(1, 2, False),
    }
    expected = {
        "RB_seeded_selector": (39, 5), "single_replacement": (39, 5),
        "syntactic_involution_endpoint_metric": (39, 5),
        "PU_unary_full_language": (38, 4), "PU_binary_one_parameter": (39, 4),
        "PU_ternary": (42, 4), "USU_unary_full_language": (36, 4),
        "SU_binary_one_parameter": (37, 4),
    }
    results = {}
    for name, formula in schemas.items():
        result = formula.size(), formula.equalities()
        assert result == expected[name], (name, result, expected[name])
        results[name] = {"nodes": result[0], "equality_occurrences": result[1],
                         "tree": formula.tree()}
    family_counts = []
    for m in range(6):
        for arity, base in [(1, 31), (2, 32)]:
            new = uniqueness_schema(m, arity, False).size()
            old = uniqueness_schema(m, arity, True).size()
            assert new == base + 5 * m and old == new + 2
            family_counts.append({"parameters": m, "update_arity": arity,
                                  "old_nodes": old, "new_nodes": new})
    d0, ds = binary_computation()
    assert (d0.size(), ds.size()) == (6, 12)
    report = {
        "convention": {
            "numeral_one": "S(0)", "predecessor": "P(n,0)",
            "negation": "A -> bottom", "indices": "opaque symbol labels",
            "schematic_bodies": "not expanded",
            "quantifier_binders": "labels, not extra term nodes",
        },
        "schemas": results, "family_counts": family_counts,
        "binary_computation_nodes": [d0.size(), ds.size()],
        "binary_total_old": schemas["PU_binary_one_parameter"].size()+18,
        "binary_total_new": schemas["SU_binary_one_parameter"].size()+18,
        "syntax": syntax_checks(), "deletion_witnesses": deletion_witnesses(),
        "status": "all finite checks passed",
    }
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(report, indent=2)+"\n")
    rows = ["presentation\tnodes\tequality_occurrences"]
    rows += [f"{name}\t{r['nodes']}\t{r['equality_occurrences']}"
             for name, r in results.items()]
    if args.tsv:
        args.tsv.write_text("\n".join(rows)+"\n")
    print("\n".join(rows))
    print(f"Binary computation templates: {d0.size()} + {ds.size()} = 18")
    print("Binary total templates: 57 -> 55")
    print("Descriptor shift, index preservation, and deletion witnesses: PASS")


if __name__ == "__main__":
    main()
