SHIFTED-TAIL UNIQUENESS -- FORMAL KERNEL
======================================

File: ShiftedUniqueness.lean
Compiler: Lean 4.19.0, commit 6caaee842e94, x86_64 Linux release.
No imports or external packages are required.

Reproduce:
  lean ShiftedUniqueness.lean

The verification.log file records the compiler output from a successful
exit-zero run. All 22 printed theorem dependency checks report that the
theorem does not depend on any extra Lean axioms. In particular there are
no assumed theorems, unfinished proof placeholders, choice principles,
classical principles, propositional extensionality, or quotient axioms.
The hypotheses representing the arithmetic schemas are explicit arguments
of the relevant theorems, not undeclared Lean axioms.

PRECISE SCOPE

The arithmetic carrier A is arbitrary, with a distinguished zero, successor,
and interpretations of the finite binary initialized-iterator descriptions.
Only the two computation equations are placed in Model. No natural-number
induction on A and no decidable equality on A are built in.

Term is a finite inductive syntax with two free slots. The first slot is
the recursion counter; the second is either the candidate's sole fixed
parameter or an update's current state. An iterator node stores a finite
update description. Substitution never changes this stored description.
The syntactic counter shift is defined by substitution and its semantic
identity is proved by structural induction on finite syntax. This is
metatheoretic syntax induction, not induction on the arithmetic carrier.

The schema ShiftedSchema quantifies over finite terms, not all functions
on A. Thus it does not silently introduce second-order induction.

The certificate proves:
  1. SU implies ordinary initialized recursion uniqueness.
  2. SU implies 0 != 1, injectivity, nonzeroness of successors, positive
     constructor coverage, and decidability of the zero test.
  3. SU is equivalent to separation + coverage + ordinary uniqueness.
  4. SU is equivalent to the previous positive uniqueness schema PU.
  5. The ordinary term-equation induction schema, together with separation
     and coverage, implies SU.

The first implication uses the candidate and its canonical initialized
iterator. Their values at one agree by their common recurrence at zero;
their shifted tails consequently agree. Its proof does not use coverage,
separation, equality decision, or induction on A.

WHAT IS NOT FORMALIZED HERE

The certificate does not formalize the entire first-order proof calculus,
formula compilation, all parameter coding, the recovery of unrestricted
primitive recursion, or full PRA conservativity. The manuscript supplies
the written equivalence proof for those endpoints. It would be inaccurate
to describe this file as a complete machine formalization of PRA equivalence.

PROVENANCE

The Term/substitution/Model framework follows the finite-syntax style of
formal/PositiveUniqueness.lean in the inspected PRA draft archive.
The shifted schema, its canonical-solution reduction, and all equivalence
certificates in this file were written for the present construction.

SOURCE SHA-256

48deab1a62193ce61bdd4bba36d8056877190ac28af904bced3c83cfeb67bfb4
