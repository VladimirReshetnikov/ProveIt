/-
Shifted-tail uniqueness: finite-syntax constructive kernel.
Lean 4.19.0; no imports and no external packages.

The carrier A is arbitrary. No induction principle for A is assumed in
the forward direction. Every schema quantifies over finite Term syntax,
not over arbitrary functions A -> A. The two visible slots are the
counter and one fixed parameter for a candidate, or the counter and
current state for an update. An iterator's update index has its own
bound slots: substitution in an application never enters that index.

The Term/Model presentation follows the finite syntax in the inspected
draft PositiveUniqueness.lean. The shifted schema, its reduction to
ordinary uniqueness, and the equivalence certificates below are new.

Certified scope:
  * capture-free substitution and the counter shift h+(k,v)=h(Sk,v);
  * shifted-tail uniqueness SU -> ordinary term recursion uniqueness;
  * SU -> separation, successor laws, positive coverage, zero decision;
  * SU <-> separation + positive coverage + ordinary term uniqueness;
  * SU <-> the previous positive recursion uniqueness schema PU;
  * term-equation induction + separation + coverage -> SU.

This is an arbitrary-carrier semantic kernel with explicit finite syntax,
not a formalization of the full first-order proof calculus, all of PRA,
the later formula compiler, general pairing, or conservativity. The
standard-induction converse explicitly assumes only the term-equation
induction schema stated below. It does not use Lean's Nat arithmetic.

All theorem dependency reports must be empty: no choice, classical
logic, propositional extensionality, quotient axioms, or sorry axioms.
-/

namespace ShiftedUniqueness

universe u

inductive Term where
  | first
  | second
  | zero
  | succ (argument : Term)
  | iter (update counter seed : Term)
  deriving DecidableEq

def substitute : Term -> Term -> Term -> Term
  | .first, x, _ => x
  | .second, _, y => y
  | .zero, _, _ => .zero
  | .succ t, x, y => .succ (substitute t x y)
  | .iter h n a, x, y => .iter h (substitute n x y) (substitute a x y)

def evaluate {A : Type u} (zero : A) (succ : A -> A)
    (run : Term -> A -> A -> A) : Term -> A -> A -> A
  | .first, x, _ => x
  | .second, _, y => y
  | .zero, _, _ => zero
  | .succ t, x, y => succ (evaluate zero succ run t x y)
  | .iter h n a, x, y =>
      run h (evaluate zero succ run n x y) (evaluate zero succ run a x y)

structure Model (A : Type u) where
  zero : A
  succ : A -> A
  run : Term -> A -> A -> A
  run_zero : forall h a, run h zero a = a
  run_succ : forall h n a,
    run h (succ n) a = evaluate zero succ run h n (run h n a)

def value {A : Type u} (C : Model A) (t : Term) (x y : A) : A :=
  evaluate C.zero C.succ C.run t x y

variable {A : Type u} (C : Model A)

theorem value_substitute (t x y : Term) (n a : A) :
    value C (substitute t x y) n a =
      value C t (value C x n a) (value C y n a) := by
  induction t with
  | first => rfl
  | second => rfl
  | zero => rfl
  | succ t ih => exact congrArg C.succ ih
  | iter h n' a' _ ihn iha =>
      change C.run h (value C (substitute n' x y) n a)
          (value C (substitute a' x y) n a) =
        C.run h (value C n' (value C x n a) (value C y n a))
          (value C a' (value C x n a) (value C y n a))
      exact congr (congrArg (C.run h) ihn) iha

/-- Shift only the free counter slot; keep stored update descriptions fixed. -/
def shift (h : Term) : Term := substitute h (.succ .first) .second

theorem value_shift (h : Term) (n v : A) :
    value C (shift h) n v = value C h (C.succ n) v :=
  value_substitute C h (.succ .first) .second n v

theorem shift_successor : shift (.succ .second) = .succ .second := rfl

def oneTerm : Term := .succ .zero
def predTerm (t : Term) : Term := .iter .first t .zero
def one : A := C.succ C.zero
def pred (x : A) : A := C.run .first x C.zero

theorem pred_zero : pred C C.zero = C.zero := C.run_zero _ _
theorem pred_succ (x : A) : pred C (C.succ x) = x := C.run_succ _ _ _

/-- The new schema. Candidate and update range over finite terms only. -/
def ShiftedSchema : Prop :=
  forall t h : Term, forall a : A,
    (forall n, value C t (C.succ n) a = value C h n (value C t n a)) ->
    C.zero ≠ C.succ C.zero /\
      forall n, n = C.zero \/
        value C t n a = C.run (shift h) (pred C n) (value C t (one C) a)

/-- Ordinary initialized recursion uniqueness, restricted to the same syntax. -/
def OrdinaryUniqueness : Prop :=
  forall t h : Term, forall a : A,
    (forall n, value C t (C.succ n) a = value C h n (value C t n a)) ->
    forall n, value C t n a = C.run h n (value C t C.zero a)

def Coverage : Prop := forall n, n = C.zero \/ n = C.succ (pred C n)

/-- Canonical solution initialized at the candidate's value at zero. -/
def canonical (t h : Term) : Term :=
  .iter h .first (substitute t .zero .second)

theorem value_canonical (t h : Term) (n a : A) :
    value C (canonical t h) n a = C.run h n (value C t C.zero a) := by
  change C.run h n (value C (substitute t .zero .second) n a) = _
  rw [value_substitute C]
  rfl

theorem canonical_recurrence (t h : Term) (a n : A) :
    value C (canonical t h) (C.succ n) a =
      value C h n (value C (canonical t h) n a) := by
  rw [value_canonical C, value_canonical C]
  exact C.run_succ h n (value C t C.zero a)

theorem canonical_at_one (t h : Term) (a : A)
    (step : forall n, value C t (C.succ n) a = value C h n (value C t n a)) :
    value C (canonical t h) (one C) a = value C t (one C) a := by
  rw [value_canonical C]
  change C.run h (C.succ C.zero) (value C t C.zero a) = _
  rw [C.run_succ, C.run_zero]
  exact (step C.zero).symm

/-- No separation, coverage, or equality decidability is used in this proof. -/
theorem ordinary_of_shifted (SU : ShiftedSchema C) : OrdinaryUniqueness C := by
  intro t h a step
  have candidate := SU t h a step
  have standard := SU (canonical t h) h a (canonical_recurrence C t h a)
  have seed := canonical_at_one C t h a step
  intro n
  rcases candidate.2 n with hz | he
  · rw [hz, C.run_zero]
  · rcases standard.2 n with hz | hg
    · rw [hz, C.run_zero]
    · rw [seed] at hg
      exact he.trans (hg.symm.trans (value_canonical C t h n a))

theorem separation_of_shifted (SU : ShiftedSchema C) : C.zero ≠ C.succ C.zero :=
  (SU .zero .zero C.zero (fun _ => rfl)).1

theorem successor_injective {x y : A} (eq : C.succ x = C.succ y) : x = y := by
  have q := congrArg (pred C) eq
  rw [pred_succ C, pred_succ C] at q
  exact q

theorem successor_ne_zero (sep : C.zero ≠ C.succ C.zero) (x : A) :
    C.succ x ≠ C.zero := by
  intro bad
  have q := congrArg (pred C) bad
  rw [pred_succ C, pred_zero C] at q
  have bad' : C.succ C.zero = C.zero := (congrArg C.succ q).symm.trans bad
  exact sep bad'.symm

theorem successor_iterator (U : OrdinaryUniqueness C) (x : A) :
    C.run (.succ .second) x (one C) = C.succ x := by
  have q := U (.succ .first) (.succ .second) C.zero (fun _ => rfl) x
  exact q.symm

theorem coverage_of_shifted (SU : ShiftedSchema C) : Coverage C := by
  have q := SU .first (.succ .second) C.zero (fun _ => rfl)
  intro n
  rcases q.2 n with hz | he
  · exact Or.inl hz
  · change n = C.run (.succ .second) (pred C n) (one C) at he
    exact Or.inr (he.trans (successor_iterator C (ordinary_of_shifted C SU) (pred C n)))

theorem zero_decision_of_shifted (SU : ShiftedSchema C) (x : A) :
    x = C.zero \/ x ≠ C.zero := by
  rcases coverage_of_shifted C SU x with hz | hs
  · exact Or.inl hz
  · exact Or.inr (fun hz =>
      successor_ne_zero C (separation_of_shifted C SU) (pred C x) (hs.symm.trans hz))

/-- Converse from the three precisely stated constructive kernel components. -/
theorem shifted_of_kernel (sep : C.zero ≠ C.succ C.zero)
    (cov : Coverage C) (U : OrdinaryUniqueness C) : ShiftedSchema C := by
  intro t h a step
  have tailStep (n : A) :
      value C (shift t) (C.succ n) a =
        value C (shift h) n (value C (shift t) n a) := by
    rw [value_shift C, value_shift C, value_shift C]
    exact step (C.succ n)
  have tail := U (shift t) (shift h) a tailStep
  have tailEq (n : A) : value C t (C.succ n) a =
      C.run (shift h) n (value C t (one C) a) := by
    have q := tail n
    rw [value_shift C, value_shift C] at q
    exact q
  refine And.intro sep ?_
  intro n
  rcases cov n with hz | hs
  · exact Or.inl hz
  · exact Or.inr ((congrArg (fun x => value C t x a) hs).trans (tailEq (pred C n)))

theorem shifted_iff_kernel :
    ShiftedSchema C <->
      (C.zero ≠ C.succ C.zero /\ Coverage C /\ OrdinaryUniqueness C) := by
  constructor
  · intro SU
    exact And.intro (separation_of_shifted C SU)
      (And.intro (coverage_of_shifted C SU) (ordinary_of_shifted C SU))
  · intro kernel
    exact shifted_of_kernel C kernel.1 kernel.2.1 kernel.2.2

/-- The old positive recursion uniqueness schema, for exact comparison. -/
def PositiveSchema : Prop :=
  forall t h : Term, forall a : A,
    (forall n, value C t (C.succ (C.succ n)) a =
      value C h n (value C t (C.succ n) a)) ->
    C.zero ≠ C.succ C.zero /\
      forall n, n = C.zero \/
        value C t n a = C.run h (pred C n) (value C t (one C) a)

/-- Each new instance follows directly from an old instance at shifted update. -/
theorem shifted_of_positive (PU : PositiveSchema C) : ShiftedSchema C := by
  intro t h a step
  exact PU t (shift h) a (by
    intro n
    rw [value_shift C]
    exact step (C.succ n))

/-- Old positive uniqueness follows through the new constructive kernel. -/
theorem positive_of_shifted (SU : ShiftedSchema C) : PositiveSchema C := by
  intro t h a step
  have tailStep (n : A) :
      value C (shift t) (C.succ n) a =
        value C h n (value C (shift t) n a) := by
    rw [value_shift C, value_shift C]
    exact step n
  have tail := ordinary_of_shifted C SU (shift t) h a tailStep
  have tailEq (n : A) : value C t (C.succ n) a =
      C.run h n (value C t (one C) a) := by
    have q := tail n
    rw [value_shift C, value_shift C] at q
    exact q
  refine And.intro (separation_of_shifted C SU) ?_
  intro n
  rcases coverage_of_shifted C SU n with hz | hs
  · exact Or.inl hz
  · exact Or.inr ((congrArg (fun x => value C t x a) hs).trans (tailEq (pred C n)))

theorem shifted_iff_positive : ShiftedSchema C <-> PositiveSchema C :=
  Iff.intro (positive_of_shifted C) (shifted_of_positive C)

/-- Only equations between finite two-slot terms, with one fixed parameter. -/
def EquationInduction : Prop :=
  forall t r : Term, forall a : A,
    value C t C.zero a = value C r C.zero a ->
    (forall n, value C t n a = value C r n a ->
      value C t (C.succ n) a = value C r (C.succ n) a) ->
    forall n, value C t n a = value C r n a

theorem ordinary_of_equation_induction (EI : EquationInduction C) :
    OrdinaryUniqueness C := by
  intro t h a step
  have base : value C t C.zero a = value C (canonical t h) C.zero a := by
    rw [value_canonical C, C.run_zero]
  have inductiveStep (n : A)
      (ih : value C t n a = value C (canonical t h) n a) :
      value C t (C.succ n) a = value C (canonical t h) (C.succ n) a := by
    rw [step n, canonical_recurrence C, ih]
  intro n
  exact (EI t (canonical t h) a base inductiveStep n).trans
    (value_canonical C t h n a)

theorem shifted_of_equation_induction (sep : C.zero ≠ C.succ C.zero)
    (cov : Coverage C) (EI : EquationInduction C) : ShiftedSchema C :=
  shifted_of_kernel C sep cov (ordinary_of_equation_induction C EI)

#print axioms value_substitute
#print axioms value_shift
#print axioms shift_successor
#print axioms pred_zero
#print axioms pred_succ
#print axioms value_canonical
#print axioms canonical_recurrence
#print axioms canonical_at_one
#print axioms ordinary_of_shifted
#print axioms separation_of_shifted
#print axioms successor_injective
#print axioms successor_ne_zero
#print axioms successor_iterator
#print axioms coverage_of_shifted
#print axioms zero_decision_of_shifted
#print axioms shifted_of_kernel
#print axioms shifted_iff_kernel
#print axioms shifted_of_positive
#print axioms positive_of_shifted
#print axioms shifted_iff_positive
#print axioms ordinary_of_equation_induction
#print axioms shifted_of_equation_induction

end ShiftedUniqueness
