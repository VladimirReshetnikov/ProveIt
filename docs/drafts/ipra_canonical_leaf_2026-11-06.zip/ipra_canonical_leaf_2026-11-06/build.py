"""Compile the LaTeX paper and reject unresolved references or overfull boxes."""

from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess


ROOT = Path(__file__).resolve().parent


def main():
    build = ROOT / "build"
    build.mkdir(exist_ok=True)
    env = dict(os.environ)
    epoch = datetime.datetime(2026, 11, 6, 12, tzinfo=datetime.timezone.utc)
    env["SOURCE_DATE_EPOCH"] = str(int(epoch.timestamp()))
    command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
               "-file-line-error", f"-output-directory={build}", "report.tex"]
    for number in range(3):
        result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True)
        (build / f"pass_{number + 1}.txt").write_text(result.stdout + result.stderr)
        if result.returncode:
            raise RuntimeError(f"LaTeX pass {number + 1} failed; inspect build/pass_{number + 1}.txt")
    log = (build / "report.log").read_text(errors="replace")
    bad = [line for line in log.splitlines()
           if "Overfull" in line or "undefined" in line.lower()
           or "Rerun to get cross-references right" in line]
    if bad:
        raise RuntimeError("LaTeX validation failed:\n" + "\n".join(bad))
    destination = ROOT / "report.pdf"
    shutil.copyfile(build / "report.pdf", destination)
    record = {"status": "PASS", "passes": 3, "unresolved_references": 0,
              "overfull_boxes": 0, "size_bytes": destination.stat().st_size,
              "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
              "source_date_epoch": env["SOURCE_DATE_EPOCH"]}
    (ROOT / "results/latex.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
