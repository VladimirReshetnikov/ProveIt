# A smaller certificate presentation of iPRA

The complete paper is `report.pdf`; all its LaTeX sources are `report.tex`
and `sections/`. The complete acceptance program is `checker.py`.

The proposed mathematical theory is the ordinary first-order theory
T_cov specified in Section 5, with the compact native proof presentation K
specified in Section 2. T_cov is bi-interpretable with full first-order
intuitionistic primitive recursive arithmetic with quantifier-free induction.
Both interpretation domains are the whole number sort, and both internal
round-trip isomorphisms are equality. K faithfully presents T_cov on its
declared native syntax. All ordinary formulas have provably equivalent native
expansions. Genuine falsity is represented in native input by `0 = S0`.

## Improvement over the supplied drafts

The comparison is pinned to ProveIt commit
`046c84aa5e99f3a437e5bc6873af9f9a1cc797a5` (6 November 2026).

| Complete-program metric | Six primary minimum | Optional canonical core | This checker |
|---|---:|---:|---:|
| AST nodes | 855 | 839 | **796** |
| Significant tokens | 808 | 796 | **743** |
| Normalized bytes | 2,618 | 2,547 | **2,414** |
| Original source bytes | 2,865 | 2,848 | **2,668** |

All parsing, syntax validation, substitution, axiom construction, proof
inference, and CLI code is included. No project-local module is imported.
The canonical baseline and this checker both omit the optional `false`
token. Formula assumptions themselves are proof leaves; the universal
introduction proof tag is `intro` to avoid collision with formula syntax.

This is a measured improvement over a finite set of implementations. It is
not an absolute minimality theorem. An included same-language control with
separate introductions has 794 AST nodes and 2,413 normalized bytes but 750
tokens; the selected version has the lower token count. The report discloses
the tradeoff rather than treating the metrics as a single exact order.

## Mathematical correction

The ordinary realization explicitly includes numerical coverage:

    for every x, x = 0 or there exists y with x = Sy.

The native expansion of this statement is already a theorem of K, so no
extra checker command is needed. It must nevertheless be named in the
ordinary first-order specification. Merely reading the restricted native
axioms in ordinary logic does not identify ordinary disjunction with its
native expansion. Section 5 gives a three-node Kripke countermodel and a
corrected, connective-preserving standard bi-interpretation proof.

## Execute and reproduce

Use Python 3.10 or newer (recorded metrics use Python 3.12.14):

```bash
python3 checker.py examples/reflexivity.json
python3 reproduce.py
python3 reproduce.py --pdf
```

The first command prints `ACCEPT`. The second regenerates size measurements,
frozen regression results, and the independent audit. The last also compiles
the paper and requires pdfLaTeX and the packages listed in `report.tex`.

The independent audit passes 1,846 checks, including 1,536 named-binder
substitution comparisons, 22 numerical-axiom comparisons, 29 positive and
231 adversarial native certificates, 13 raw falsity-alias rejections, and
15 actual JSON/CLI cases. The frozen corpus separately contains 184 native
certificate entries with 122 expected acceptances and 62 rejections.

`REPRODUCE.md` specifies the native syntax and fixture transformation.
`comparison/` contains seven verbatim baseline programs, hashes, the larger
source inventory, and two matched controls. `validation/` contains the
independent audit, frozen certificates, their expected outcomes, and an
untrusted legacy-format conversion utility. `results/` records reproducible
measurements and verification outcomes. `MANIFEST.sha256` covers the packaged
files except itself.

## An explicit numerical-coverage proof

`examples/numerical_coverage.json` is an additional closed certificate for
`forall x ((x = 0) or* (S p(x) = x))`, where `or*` is the native selector
expansion. It has 51 proof nodes and maximum proof depth 10. Its expected
goal is an independently fixed JSON literal. The ordinary checker accepts
it with no additional inference rules or assumptions. The self-contained
untrusted generator is `validation/generate_coverage.py`; `results/coverage.json`
records the fixed goal and hashes. This new certificate is separate from the
184-entry frozen regression corpus.

## Trust and attribution

The native calculus and much of the mathematical derivation are inherited
from the supplied drafts and explicitly credited in the paper. The new
contribution is a smaller complete implementation and a corrected faithful
ordinary realization. Mathematical metatheorems are proved in the article;
the executable tests are finite implementation checks. No Lean or Rocq
formalization is claimed. Python and its standard JSON parser remain the
common runtime assumptions.
