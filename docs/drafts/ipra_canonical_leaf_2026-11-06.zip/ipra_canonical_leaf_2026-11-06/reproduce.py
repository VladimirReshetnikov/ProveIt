"""Reproduce whole-program metrics, fixed regressions, and the independent audit."""

import argparse
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf", action="store_true")
    args = parser.parse_args()
    commands = [["measure.py"], ["regression.py"],
                ["checker.py", "examples/numerical_coverage.json"],
                ["validation/audit.py", "--output", "results/independent_audit.json"]]
    if args.pdf:
        commands.append(["build.py"])
    results = []
    for arguments in commands:
        process = subprocess.run([sys.executable, *arguments], cwd=ROOT,
                                 capture_output=True, text=True)
        row = {"command": ["python3", *arguments], "returncode": process.returncode}
        results.append(row)
        if process.returncode:
            print(process.stdout, end="")
            print(process.stderr, end="", file=sys.stderr)
            raise SystemExit(process.returncode)
        print("PASS: " + " ".join(row["command"]))
    (ROOT / "results/reproduction.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
