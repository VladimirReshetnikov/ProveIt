"""Reproduce whole-program checker measurements offline with Python 3.11+.

No program being measured is imported or executed. Comments, whitespace, and
docstrings are excluded from the primary syntax metrics. Every executable part
of each file, including CLI, validation, and axiom construction, is counted.
"""

import ast
import copy
import hashlib
import io
import json
import platform
from pathlib import Path
import tokenize


ROOT = Path(__file__).resolve().parent
FIELDS = ("source_bytes", "ast_nodes", "tokens", "normalized_bytes")
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}


def docstrings(tree):
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef,
                             ast.AsyncFunctionDef, ast.ClassDef)) and node.body:
            first = node.body[0]
            if (isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant)
                    and isinstance(first.value.value, str)):
                yield first


def measure(path):
    data = path.read_bytes()
    source = data.decode("utf-8")
    parsed = ast.parse(source, filename=str(path))
    stripped = copy.deepcopy(parsed)
    identities = {id(node) for node in docstrings(stripped)}
    for node in ast.walk(stripped):
        if hasattr(node, "body") and isinstance(node.body, list):
            node.body = [child for child in node.body if id(child) not in identities]
    ranges = [((node.lineno, node.col_offset), (node.end_lineno, node.end_col_offset))
              for node in docstrings(parsed)]
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(source).readline)
              if t.type not in IGNORED and not any(
                  start <= t.start and t.end <= end for start, end in ranges)]
    normalized = (ast.unparse(stripped) + "\n").encode("utf-8")
    return {"path": str(path.relative_to(ROOT)),
            "sha256": hashlib.sha256(data).hexdigest(),
            "source_bytes": len(data),
            "ast_nodes": sum(1 for _ in ast.walk(stripped)),
            "tokens": len(tokens),
            "normalized_bytes": len(normalized),
            "normalized_sha256": hashlib.sha256(normalized).hexdigest()}


def envelope(rows):
    return {field: min(row[field] for row in rows) for field in FIELDS}


def main():
    provenance = json.loads((ROOT / "comparison/provenance.json").read_text())
    baselines = []
    for source in provenance["files"]:
        row = measure(ROOT / source["vendored_path"])
        if row["sha256"] != source["checker_sha256"]:
            raise ValueError("Baseline hash mismatch: " + row["path"])
        baselines.append({"role": source["role"], "archive": source["archive"],
                          "member": source["member"], **row})
    candidate = measure(ROOT / "checker.py")
    primary_envelope = envelope([r for r in baselines if r["role"] == "primary"])
    complete_envelope = envelope(baselines)
    controls = [measure(p) for p in sorted((ROOT / "comparison/controls").glob("*.py"))]
    result = {
        "python_version": platform.python_version(),
        "definitions": {
            "source_bytes": "Complete UTF-8 source, including comments and docstrings.",
            "ast_nodes": "All ast.walk nodes, including contexts, after removing docstrings.",
            "tokens": "Python tokens excluding whitespace, comments, docstrings and end marker.",
            "normalized_bytes": "UTF-8 size of ast.unparse(docstring-stripped AST) plus newline.",
            "trusted_scope": "Entire standalone checker program; standard Python runtime and JSON library are common infrastructure.",
            "qualification": "Concrete implementation measurements, not an absolute lower bound on iPRA axiomatizations."
        },
        "candidate": candidate,
        "primary_six_lower_envelope": primary_envelope,
        "all_seven_lower_envelope": complete_envelope,
        "candidate_strictly_below_all_seven": {
            field: candidate[field] < complete_envelope[field] for field in FIELDS},
        "baselines": baselines,
        "optional_falsity_alias_frontend": measure(ROOT / "checker_with_falsity_alias.py"),
        "controls": controls,
        "control_deltas_over_candidate": {
            row["path"]: {field: row[field] - candidate[field] for field in FIELDS}
            for row in controls},
        "control_notes": {
            "explicit_leaf_dispatch.py": "Same input language; explicit formula-leaf dispatch with a separate rejection branch.",
            "split_introductions.py": "Same input language; separate intro and pack clauses. The sharing tradeoff differs between AST-node and token counts."
        }
    }
    destination = ROOT / "results/metrics.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    for row in [candidate, *baselines, *controls]:
        print(row["path"], *(f"{field}={row[field]}" for field in FIELDS))
    assert all(result["candidate_strictly_below_all_seven"].values())


if __name__ == "__main__":
    main()
