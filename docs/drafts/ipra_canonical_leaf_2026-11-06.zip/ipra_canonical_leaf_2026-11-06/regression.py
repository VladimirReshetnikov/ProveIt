"""Check the frozen native-format corpus and matched controls offline.

Expected results were frozen before the candidate was evaluated. Neither the
legacy converter nor any proof generator is used by this runner or the kernel.
Finite regression is evidence about these cases, not a soundness proof.
"""

import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def accepts(module, data):
    try:
        return module.check(data) is True
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        return False


def main():
    manifest = json.loads((ROOT / "validation/manifest.json").read_text())
    modules = {"checker.py": load(ROOT / "checker.py", "candidate")}
    for index, path in enumerate(sorted((ROOT / "comparison/controls").glob("*.py"))):
        modules[str(path.relative_to(ROOT))] = load(path, f"control_{index}")
    results = []
    for record in manifest["certificates"]:
        path = ROOT / record["file"]
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != record["sha256"]:
            raise ValueError("Fixture hash mismatch: " + record["file"])
        certificate = json.loads(data)
        actual = {name: accepts(module, certificate) for name, module in modules.items()}
        results.append({"name": record["name"], "file": record["file"],
                        "expected": record["accepted"], "actual": actual})
    failures = [r for r in results if any(
        result != r["expected"] for result in r["actual"].values())]
    cli = []
    for name in ("example/reflexivity", "native_false_alias_rejected",
                 "reject_envelope_or_proof_11"):
        record = next(r for r in manifest["certificates"] if r["name"] == name)
        proc = subprocess.run([sys.executable, str(ROOT / "checker.py"),
                               str(ROOT / record["file"])], capture_output=True, text=True)
        expected_code = 0 if record["accepted"] else 1
        expected_output = "ACCEPT\n" if record["accepted"] else "REJECT\n"
        cli.append({"name": name, "returncode": proc.returncode, "stdout": proc.stdout,
                    "passed": proc.returncode == expected_code and proc.stdout == expected_output})
    result = {
        "candidate_sha256": hashlib.sha256((ROOT / "checker.py").read_bytes()).hexdigest(),
        "certificate_count": len(results),
        "positive_count": sum(r["expected"] for r in results),
        "negative_count": sum(not r["expected"] for r in results),
        "control_count": len(modules) - 1,
        "candidate_and_control_decisions": len(results) * len(modules),
        "failure_count": len(failures),
        "cli_checks": cli,
        "records": results,
        "qualification": "Frozen finite regressions; the mathematical proof supplies soundness and equivalence."
    }
    path = ROOT / "results/regression.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k != "records"}, indent=2))
    if failures or not all(r["passed"] for r in cli):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
