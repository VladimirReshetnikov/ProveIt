"""Independent finite audit of the canonical formula-leaf iPRA checker.

The oracle decodes de Bruijn expressions to fresh named binders, substitutes
free names simultaneously, and encodes them again. All positive certificates
are constructed directly in the candidate's native syntax. No baseline checker,
certificate converter, canonicalizer, or candidate syntax routine is used to
calculate an expected result. The candidate is loaded only to test its outputs.

Usage: python3 validation/audit.py --checker checker.py --output audit.json
Finite regression checks do not replace the mathematical soundness theorem.
"""

import argparse
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile

ZERO = -1
TRUTH = ["=", ZERO, ZERO]
FALSE = ["=", ZERO, ["s", ZERO]]
SERIAL = itertools.count()
ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError)


def fresh():
    return ("bound", next(SERIAL))


def formed(a, formula):
    """Independent grammar recognizer; no public aliases are admitted."""
    if type(a) is int:
        return not formula and a >= ZERO
    if type(a) is not list or not a:
        return False
    if a[0] == "s":
        return not formula and len(a) == 2 and formed(a[1], False)
    if a[0] == "r":
        return not formula and len(a) == 4 and all(formed(t, False) for t in a[1:])
    if a[0] == "=":
        return formula and len(a) == 3 and all(formed(t, False) for t in a[1:])
    if a[0] == "pi":
        return formula and len(a) == 3 and all(formed(t, True) for t in a[1:])
    if a[0] == "ex":
        return formula and len(a) == 2 and formed(a[1], True)
    return False


def decode(a, bound=()):
    if a == ZERO:
        return ("zero",)
    if type(a) is int:
        return ("var", bound[a] if a < len(bound) else ("free", a - len(bound)))
    tag = a[0]
    if tag in ("s", "="):
        return (tag, *(decode(b, bound) for b in a[1:]))
    if tag == "r":
        u, v = fresh(), fresh()
        return ("r", decode(a[1], bound), decode(a[2], bound), u, v,
                decode(a[3], (u, v) + bound))
    x = fresh()
    if tag == "pi":
        return ("pi", x, decode(a[1], (x,) + bound), decode(a[2], (x,) + bound))
    if tag == "ex":
        return ("ex", x, decode(a[1], (x,) + bound))
    raise ValueError("invalid oracle expression")


def encode(a, bound=()):
    tag = a[0]
    if tag == "zero":
        return ZERO
    if tag == "var":
        name = a[1]
        return len(bound) + name[1] if name[0] == "free" else bound.index(name)
    if tag in ("s", "="):
        return [tag, *(encode(b, bound) for b in a[1:])]
    if tag == "r":
        _, n, b, u, v, h = a
        return ["r", encode(n, bound), encode(b, bound), encode(h, (u, v) + bound)]
    if tag == "pi":
        _, x, p, q = a
        return ["pi", encode(p, (x,) + bound), encode(q, (x,) + bound)]
    _, x, p = a
    return ["ex", encode(p, (x,) + bound)]


def named_replace(a, replacements):
    """Replace only free-name leaves; never descend into an inserted tree."""
    if a[0] == "var":
        return replacements(a[1]) if a[1][0] == "free" else a
    if a[0] == "zero":
        return a
    if a[0] in ("s", "="):
        return (a[0], *(named_replace(b, replacements) for b in a[1:]))
    if a[0] == "r":
        _, n, b, u, v, h = a
        return ("r", named_replace(n, replacements), named_replace(b, replacements),
                u, v, named_replace(h, replacements))
    if a[0] == "pi":
        _, x, p, q = a
        return ("pi", x, named_replace(p, replacements), named_replace(q, replacements))
    _, x, p = a
    return ("ex", x, named_replace(p, replacements))


def oracle_subst(a, terms=(), delta=0, depth=0):
    protected = tuple(fresh() for _ in range(depth))
    tree = decode(a, protected)
    inserted = [decode(t) for t in terms]

    def replace(name):
        i = name[1]
        return inserted[i] if i < len(inserted) else ("var", ("free", i + delta))

    return encode(named_replace(tree, replace), protected)


def sh(a, n=1):
    return oracle_subst(a, delta=n)


def ins(a, t):
    return oracle_subst(a, [t], -1)


def expected_nat(matrix, force_induction=False):
    """Build the mathematical numerical axiom with named binders, then encode."""
    p = decode(matrix)
    x, y, dummy = fresh(), fresh(), fresh()

    def instance(value):
        return named_replace(p, lambda name: value if name[1] == 0 else
                             ("var", ("free", name[1] - 1)))

    base = instance(("zero",))
    hypothesis = instance(("var", y)) if matrix[0] == "=" or force_induction else base
    step = ("pi", y, hypothesis, instance(("s", ("var", y))))
    return encode(("pi", x, base, ("pi", dummy, step, instance(("var", x)))))


def load_checker(path):
    spec = importlib.util.spec_from_file_location("audited_checker", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def corpus():
    terms = [ZERO, 0, 1, 2, 5, ["s", 0], ["s", ZERO],
             ["r", 0, 1, ["s", 0]],
             ["r", 1, 0, ["r", 1, 0, ["s", 2]]],
             ["r", ["s", 2], 5, ["r", 3, 2, ["r", 1, 4, 6]]]]
    formulas = [TRUTH, FALSE, ["=", 0, 1],
                ["pi", ["=", 0, 1], ["ex", ["=", 0, 2]]],
                ["ex", ["pi", ["=", 0, 2], ["=", 1, 3]]],
                ["pi", FALSE, ["ex", ["=", ["r", 2, 0, ["s", 4]], 3]]]]
    rng = random.Random(20261106)

    def term(level):
        if level == 0:
            return rng.choice([ZERO, 0, 1, 2, 3, 7])
        if rng.randrange(3) == 0:
            return ["s", term(level - 1)]
        return ["r", term(level - 1), term(level - 1), term(level - 1)]

    def formula(level):
        if level == 0:
            return ["=", term(1), term(1)]
        if rng.randrange(2):
            return ["pi", formula(level - 1), formula(level - 1)]
        return ["ex", formula(level - 1)]

    terms += [term(2) for _ in range(16)]
    formulas += [formula(2) for _ in range(16)]
    return terms, formulas


def refl(t):
    rec = ["rec", ["r", ZERO, t, ZERO]]
    return ["use", rec, ["=", 0, sh(t)], rec]


def certificates():
    yes, no, aliases = [], [], []

    def add(name, g, a, p):
        yes.append((name, [g, a, p]))

    def reject(name, g, a, p):
        no.append((name, [g, a, p]))

    add("equational_assumption_leaf", [TRUTH], TRUTH, TRUTH)
    add("canonical_false_assumption_leaf", [FALSE], FALSE, FALSE)
    pi_leaf = ["pi", TRUTH, ["=", 0, 0]]
    ex_leaf = ["ex", ["=", 0, 1]]
    add("pi_assumption_leaf_not_introduction", [pi_leaf], pi_leaf, pi_leaf)
    add("existential_assumption_leaf", [ex_leaf], ex_leaf, ex_leaf)
    for i, t in enumerate([ZERO, 0, ["s", 1], ["r", 0, 1, ["s", 2]]]):
        add(f"derived_reflexivity_{i}", [], ["=", t, t], refl(t))
        r = ["r", ZERO, t, ["r", 1, 0, ["s", 2]]]
        add(f"recursion_zero_{i}", [], ["=", r, t], ["rec", r])
        n = ["s", t]
        r = ["r", n, 2, ["r", 1, 0, ["s", 2]]]
        rhs = oracle_subst(r[3], [["r", t, 2, r[3]], t], -2)
        add(f"recursion_successor_nested_scope_{i}", [], ["=", r, rhs], ["rec", r])

    a = ["=", 0, 1]
    add("pi_context_lift", [a], ["pi", TRUTH, sh(a)], ["intro", TRUTH, sh(a)])
    reject("pi_context_capture", [a], ["pi", TRUTH, a], ["intro", TRUTH, a])
    dependent = ["=", 0, 1]
    add("pi_dependent_guard", [], ["pi", dependent, dependent], ["intro", dependent, dependent])
    t = ["s", 1]
    add("pi_elimination_open_term", [pi_leaf], ["=", t, t],
        ["use", pi_leaf, t, refl(ZERO)])
    reject("pi_elimination_wrong_minor", [pi_leaf, FALSE], ["=", t, t],
           ["use", pi_leaf, t, FALSE])

    witness_eq = ["=", 0, sh(t)]
    add("witnessed_existential_intro", [], ["ex", witness_eq], ["pack", t, witness_eq])
    add("pack_context_lift", [a], ["ex", sh(a)], ["pack", ZERO, sh(a)])
    reject("pack_context_capture", [a], ["ex", a], ["pack", ZERO, a])
    reject("pack_witness_capture", [], ["ex", ["=", 0, t]], ["pack", t, ["=", 0, t]])
    add("existential_elimination", [ex_leaf], TRUTH, ["use", ex_leaf, TRUTH, refl(ZERO)])
    retained = ["pi", TRUTH, ["=", 1, 2]]
    add("existential_elimination_retained_quantified_context", [ex_leaf, retained], retained,
        ["use", ex_leaf, retained, sh(retained)])
    reject("existential_eigenvariable_escape", [ex_leaf], ["=", 0, 1],
           ["use", ex_leaf, ["=", 0, 1], ["=", 0, 1]])

    s, t = 0, ["s", 1]
    eq = ["=", s, t]
    motives = [["pi", ["=", 0, 1], ["ex", ["=", 0, 2]]],
               ["=", ["r", 1, 0, ["r", 1, 2, ["s", 4]]], 0]]
    for i, motive in enumerate(motives):
        fs, ft = ins(motive, s), ins(motive, t)
        add(f"equality_transport_mixed_scopes_{i}", [eq, fs], ft, ["use", eq, motive, fs])
        reject(f"equality_transport_wrong_orientation_{i}", [eq, ft], fs,
               ["use", eq, motive, ft])

    matrices = [["=", 0, 1], ["ex", ["=", 0, 1]],
                ["pi", ["=", 0, 0], ["=", 1, 0]], FALSE]
    for i, matrix in enumerate(matrices):
        add(f"numerical_axiom_{i}", [], expected_nat(matrix), ["nat", matrix])
        if matrix[0] != "=":
            reject(f"forbidden_quantified_induction_{i}", [], expected_nat(matrix, True), ["nat", matrix])

    bad_values = [True, False, 0.0, -1.0, None, "0", {}, [], -2,
                  ["unknown", 0], ["s"], ["s", 0, 1],
                  ["r", 0, ZERO], ["r", 0, ZERO, 0, 0],
                  ["r", 0, ZERO, ["=", 0, 0]], ["r", ZERO, ZERO, True],
                  ["=", 0], ["=", 0, 0, 0], ["=", True, 0],
                  ["=", -2, 0], ["pi", TRUTH], ["pi", TRUTH, 0],
                  ["ex"], ["ex", TRUTH, TRUTH], ["ex", 0],
                  [["s"], 0], [True, 0], ["intro", TRUTH, TRUTH]]
    for i, bad in enumerate(bad_values):
        if not formed(bad, True):
            reject(f"malformed_root_goal_{i}", [TRUTH], bad, TRUTH)
            reject(f"malformed_assumption_{i}", [bad, TRUTH], TRUTH, TRUTH)
            reject(f"malformed_pi_guard_{i}", [], TRUTH, ["intro", bad, refl(ZERO)])
            reject(f"malformed_nat_matrix_{i}", [], TRUTH, ["nat", bad])
            reject(f"malformed_equality_motive_{i}", [TRUTH], TRUTH, ["use", TRUTH, bad, TRUTH])
        if not formed(bad, False):
            reject(f"malformed_witness_{i}", [], ["ex", TRUTH], ["pack", bad, refl(ZERO)])
            reject(f"malformed_pi_argument_{i}", [["pi", TRUTH, TRUTH]], TRUTH,
                   ["use", ["pi", TRUTH, TRUTH], bad, refl(ZERO)])

    reject("boolean_alias_leaf", [["=", 1, 1]], ["=", 1, 1], ["=", True, True])
    reject("float_alias_leaf", [["=", 0, 0]], ["=", 0, 0], ["=", 0.0, 0.0])
    reject("invalid_unused_recursion_update", [], ["=", ["r", ZERO, ZERO, True], ZERO],
           ["rec", ["r", ZERO, ZERO, True]])
    for i, update in enumerate([True, 0.0, ["=", 0, 0], ["s"], ["unknown", 0]]):
        reject(f"hidden_malformed_recursion_update_{i}", [], TRUTH,
               ["use", ["rec", ["r", ZERO, ZERO, update]], TRUTH, refl(ZERO)])
    reject("unjustified_false", [], FALSE, FALSE)
    reject("recursion_at_variable", [], TRUTH, ["rec", ["r", 0, ZERO, 0]])
    reject("old_hyp_wrapper_rejected", [TRUTH], TRUTH, ["hyp", TRUTH])
    reject("pi_formula_not_proof_without_assumption", [], pi_leaf, pi_leaf)
    for i, p in enumerate([["intro"], ["intro", TRUTH], ["intro", TRUTH, TRUTH, TRUTH],
                           ["pack", ZERO], ["pack", ZERO, TRUTH, 0],
                           ["use", TRUTH, TRUTH], ["use", TRUTH, TRUTH, TRUTH, 0],
                           ["rec"], ["rec", ZERO], ["rec", ["r", ZERO, ZERO, ZERO], 0],
                           ["nat"], ["nat", TRUTH, TRUTH], ["hyp"], ["mystery", TRUTH]]):
        reject(f"command_arity_or_unknown_tag_{i}", [TRUTH], TRUTH, p)

    alias = ["false"]
    aliases += [
        ("alias_goal", [["=", ZERO, ["s", ZERO]]], alias, FALSE),
        ("alias_assumption", [alias, TRUTH], TRUTH, TRUTH),
        ("alias_leaf", [FALSE], FALSE, alias),
        ("alias_pi_guard", [], ["pi", FALSE, TRUTH], ["intro", alias, refl(ZERO)]),
        ("alias_pi_body_leaf", [], ["pi", FALSE, FALSE], ["intro", FALSE, alias]),
        ("alias_quantified_goal", [["ex", FALSE]], ["ex", alias], ["ex", FALSE]),
        ("alias_quantified_assumption", [["ex", alias], TRUTH], TRUTH, TRUTH),
        ("alias_equality_motive", [TRUTH, FALSE], FALSE, ["use", TRUTH, alias, FALSE]),
        ("alias_existential_goal_annotation", [["ex", FALSE]], FALSE,
         ["use", ["ex", FALSE], alias, FALSE]),
        ("alias_nat_matrix", [], expected_nat(FALSE), ["nat", alias]),
        ("alias_term_witness", [], ["ex", TRUTH], ["pack", alias, refl(ZERO)]),
        ("alias_unused_pi_argument", [["pi", TRUTH, TRUTH]], TRUTH,
         ["use", ["pi", TRUTH, TRUTH], alias, refl(ZERO)]),
        ("alias_unused_recursion_update", [], ["=", ["r", ZERO, ZERO, alias], ZERO],
         ["rec", ["r", ZERO, ZERO, alias]]),
    ]
    aliases = [(name, [g, a, p]) for name, g, a, p in aliases]
    return yes, no, aliases


def run(checker_path):
    checker = load_checker(checker_path)
    results = {"checker_sha256": hashlib.sha256(checker_path.read_bytes()).hexdigest(),
               "checker_file": checker_path.name, "checks": {}, "failures": []}
    terms, formulas = corpus()
    environments = [((), 0), ((), 1), ((), 3), ((ZERO,), -1), ((ZERO,), 0),
                    ((["s", 0],), 0), ((2,), -1), ((["r", 0, 1, ["s", 2]], 1), -2)]
    count = 0
    for formula, expressions in [(False, terms), (True, formulas)]:
        for j, a in enumerate(expressions):
            assert formed(a, formula), (formula, a)
            for depth in (0, 1, 2, 5):
                for inserted, delta in environments:
                    expected = oracle_subst(a, inserted, delta, depth)
                    actual = checker.subst(a, [*inserted, delta], depth, formula)
                    if actual != expected or not formed(actual, formula):
                        results["failures"].append({"test": "named_substitution_oracle", "formula": formula,
                            "index": j, "depth": depth, "terms": inserted, "delta": delta,
                            "expected": expected, "actual": actual})
                    count += 1
    results["checks"]["independent_named_substitution_comparisons"] = count

    for matrix in formulas:
        actual = checker.infer(["nat", matrix], [])
        expected = expected_nat(matrix)
        if actual != expected:
            results["failures"].append({"test": "named_numerical_axiom", "matrix": matrix,
                                        "expected": expected, "actual": actual})
    results["checks"]["independent_named_numerical_axioms"] = len(formulas)

    yes, no, aliases = certificates()
    for wanted, fixtures in [(True, yes), (False, no), (False, aliases)]:
        for name, certificate in fixtures:
            try:
                accepted = checker.check(certificate) is True
                error = None
            except ERRORS as exc:
                accepted, error = False, type(exc).__name__
            if accepted != wanted:
                results["failures"].append({"test": name, "expected_accept": wanted,
                                            "accepted": accepted, "exception": error})
    results["checks"]["native_positive_rule_certificates"] = len(yes)
    results["checks"]["native_adversarial_certificates"] = len(no)
    results["checks"]["raw_noncanonical_falsity_alias_rejections"] = len(aliases)

    cli_inputs = [("positive", json.dumps(yes[0][1]), True),
                  ("positive_pi_leaf", json.dumps(yes[2][1]), True),
                  ("positive_intro", json.dumps([[], ["pi", TRUTH, TRUTH], ["intro", TRUTH, TRUTH]]), True),
                  ("positive_axiom", json.dumps([[], expected_nat(["=", 0, 1]), ["nat", ["=", 0, 1]]]), True),
                  ("unproved_false", json.dumps([[], FALSE, FALSE]), False),
                  ("object_envelope", '{"g": [], "a": 0, "p": 0}', False),
                  ("extra_envelope", json.dumps([[], TRUTH, TRUTH, 0]), False),
                  ("invalid_json", '[', False),
                  ("float_nan", '[[], ["=",NaN,NaN], ["=",NaN,NaN]]', False),
                  ("float_infinity", '[[], ["=",Infinity,Infinity], ["=",Infinity,Infinity]]', False),
                  ("noncanonical_alias", json.dumps([[FALSE], FALSE, ["false"]]), False),
                  ("boolean_alias_leaf", '[[["=",1,1]], ["=",1,1], ["=",true,true]]', False),
                  ("float_alias_leaf", '[[["=",0,0]], ["=",0,0], ["=",0.0,0.0]]', False),
                  ("old_hyp_wrapper", json.dumps([[TRUTH], TRUTH, ["hyp", TRUTH]]), False),
                  ("pi_not_intro", json.dumps([[], ["pi", TRUTH, TRUTH], ["pi", TRUTH, TRUTH]]), False)]
    with tempfile.TemporaryDirectory() as temp:
        for name, content, wanted in cli_inputs:
            p = Path(temp) / (name + ".json")
            p.write_text(content, encoding="utf-8")
            proc = subprocess.run([sys.executable, str(checker_path), str(p)],
                                  capture_output=True, text=True, timeout=10)
            expected = (0, "ACCEPT") if wanted else (1, "REJECT")
            if (proc.returncode, proc.stdout.strip()) != expected or proc.stderr:
                results["failures"].append({"test": "cli_" + name, "returncode": proc.returncode,
                                            "stdout": proc.stdout, "stderr": proc.stderr})
    results["checks"]["json_cli_boundaries"] = len(cli_inputs)
    results["status"] = "PASS" if not results["failures"] else "FAIL"
    results["scope"] = ("Finite native-syntax tests of simultaneous substitution against an independent named-binder "
        "oracle, numerical axiom generation, every inference family, formula leaves, context lifting, equality "
        "transport under binders, forbidden quantified induction, malformed input, Boolean/float aliases, raw "
        "noncanonical falsity rejection, and actual JSON/CLI behavior. No surface alias is expanded by this test "
        "harness. These tests are not a machine-checked metatheorem or an exhaustive proof of soundness. "
        "Python and its JSON parser remain in the trusted runtime.")
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checker", type=Path, default=Path(__file__).resolve().parents[1] / "checker.py")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = run(args.checker.resolve())
    text = json.dumps(result, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
