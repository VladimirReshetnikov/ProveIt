"""Generate one explicit native certificate for numerical coverage.

This file is an UNTRUSTED proof generator. The final closed goal is a fixed
literal below; it is not inferred by the checker. Output is an ordinary JSON
certificate using only the five native proof records and formula leaves.

Named-syntax helpers are adapted from proof_tools/builder.py in
ipra_shared_traversal_2026-11-06.zip, ProveIt commit
046c84aa5e99f3a437e5bc6873af9f9a1cc797a5. No external helper is imported.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
from itertools import count
import json
from pathlib import Path
import subprocess
import sys

_ids = count()
Z = -1


@dataclass(frozen=True)
class Var:
    uid: int
    label: str

def fresh(label="x"):
    return Var(next(_ids), label)

def S(t):
    return ("s", t)

def Eq(s, t):
    return ("=", s, t)

def Pi(x, a, b):
    return ("pi", x, a, b)

def Ex(x, a):
    return ("ex", x, a)

def R(n, a, u, v, h):
    return ("r", n, a, u, v, h)

def selector(n, a, b):
    return R(n, a, fresh("u"), fresh("v"), b)

def Imp(a, b):
    return Pi(fresh("unused"), a, b)

T = Eq(Z, Z)

def free(a):
    if isinstance(a, Var):
        return {a}
    if type(a) is int:
        return set()
    if a[0] == "r":
        return free(a[1]) | free(a[2]) | (free(a[5]) - {a[3], a[4]})
    if a[0] in ("pi", "ex"):
        return set().union(*(free(b) for b in a[2:])) - {a[1]}
    return set().union(*(free(b) for b in a[1:]))

def sub(a, env):
    """Capture-avoiding simultaneous substitution in named syntax."""
    if isinstance(a, Var):
        return env.get(a, a)
    if type(a) is int:
        return a
    if a[0] == "r":
        n, init, u, v, body = a[1:]
        local = {k: t for k, t in env.items() if k not in (u, v)}
        capture = set().union(*(free(t) for t in local.values()))
        renaming = {x: fresh(x.label) for x in (u, v) if x in capture}
        body = sub(body, renaming)
        return R(sub(n, env), sub(init, env), renaming.get(u, u),
                 renaming.get(v, v), sub(body, local))
    if a[0] in ("pi", "ex"):
        x = a[1]
        local = {k: t for k, t in env.items() if k != x}
        capture = set().union(*(free(t) for t in local.values()))
        y = fresh(x.label) if x in capture else x
        children = [sub(sub(b, {x: y}) if y != x else b, local) for b in a[2:]]
        return (a[0], y, *children)
    return (a[0], *(sub(b, env) for b in a[1:]))

def encode(a, scope):
    if isinstance(a, Var):
        return scope.index(a)
    if type(a) is int:
        assert a == Z
        return a
    if a[0] == "r":
        return ["r", encode(a[1], scope), encode(a[2], scope),
                encode(a[5], [a[3], a[4], *scope])]
    if a[0] in ("pi", "ex"):
        return [a[0], *(encode(b, [a[1], *scope]) for b in a[2:])]
    return [a[0], *(encode(b, scope) for b in a[1:])]

def same(a, b):
    scope = sorted(free(a) | free(b), key=lambda v: v.uid)
    return encode(a, scope) == encode(b, scope)

@dataclass
class Proof:
    goal: object
    node: tuple

def as_goal(p, goal):
    assert same(p.goal, goal), ("macro conclusion mismatch", p.goal, goal)
    return Proof(goal, p.node)

def hyp(a):
    return Proof(a, ("hyp", a))

def pi_intro(x, guard, body):
    return Proof(Pi(x, guard, body.goal), ("pi", x, guard, body))

def pi_elim(principal, witness, minor):
    tag, x, a, b = principal.goal
    assert tag == "pi" and same(minor.goal, sub(a, {x: witness}))
    return Proof(sub(b, {x: witness}), ("app", principal, witness, minor))

def imp_elim(principal, minor):
    return pi_elim(principal, Z, minor)

def rewrite(equality, x, template, minor):
    _, s, t = equality.goal
    assert same(minor.goal, sub(template, {x: s})), (
        "transport source mismatch", minor.goal, sub(template, {x: s}))
    return Proof(sub(template, {x: t}), ("eq", equality, x, template, minor))

def compute(r):
    _, n, a, u, v, h = r
    if n == Z:
        b = a
    else:
        assert isinstance(n, tuple) and n[0] == "s"
        b = sub(h, {u: R(n[1], a, u, v, h), v: n[1]})
    return Proof(Eq(r, b), ("rec", r))

def refl(t):
    p = compute(R(Z, t, fresh("u"), fresh("v"), Z))
    x = fresh("transport")
    return rewrite(p, x, Eq(x, t), p)

def sym(p):
    _, s, _ = p.goal
    x = fresh("transport")
    return rewrite(p, x, Eq(x, s), refl(s))

def congr(p, x, context):
    s = sub(context, {x: p.goal[1]})
    return rewrite(p, x, Eq(s, context), refl(s))

def pack(witness, y, body):
    return Proof(Ex(y, body.goal), ("pack", witness, y, body))

def exists_intro(existential, witness, premise):
    _, x, body = existential
    assert same(premise.goal, sub(body, {x: witness}))
    y, z = fresh("witness"), fresh("transport")
    equation = Eq(y, witness)
    template = sub(body, {x: z})
    branch = rewrite(sym(hyp(equation)), z, template, premise)
    return as_goal(pack(witness, y, branch), existential)

def nat_axiom(x, a):
    base = sub(a, {x: Z})
    y = fresh("step")
    guard = sub(a, {x: y}) if a[0] == "=" else base
    step = Pi(y, guard, sub(a, {x: S(y)}))
    return Proof(Pi(x, base, Imp(step, a)), ("nat", x, a))

def numerical(x, a, target, base, successor):
    """Use equation induction, or cases for a non-equation matrix.

    successor(y, hypothesis) constructs the successor proof. For a compound
    matrix that hypothesis is its fixed base, not an induction hypothesis.
    """
    assert same(base.goal, sub(a, {x: Z}))
    y = fresh("step")
    guard = sub(a, {x: y}) if a[0] == "=" else sub(a, {x: Z})
    body = successor(y, hyp(guard))
    assert same(body.goal, sub(a, {x: S(y)}))
    step = pi_intro(y, guard, body)
    return imp_elim(pi_elim(nat_axiom(x, a), target, base), step)

def encode_proof(proof, scope):
    n = proof.node
    if n[0] == "hyp":
        return encode(n[1], scope)
    if n[0] == "pi":
        _, x, guard, body = n
        local = [x, *scope]
        return ["intro", encode(guard, local), encode_proof(body, local)]
    if n[0] == "app":
        return ["use", encode_proof(n[1], scope), encode(n[2], scope), encode_proof(n[3], scope)]
    if n[0] == "eq":
        _, p, x, template, q = n
        return ["use", encode_proof(p, scope), encode(template, [x, *scope]), encode_proof(q, scope)]
    if n[0] == "let":
        _, p, x, q = n
        return ["use", encode_proof(p, scope), encode(proof.goal, scope), encode_proof(q, [x, *scope])]
    if n[0] == "pack":
        _, t, x, p = n
        return ["pack", encode(t, scope), encode_proof(p, [x, *scope])]
    if n[0] == "rec":
        return ["rec", encode(n[1], scope)]
    if n[0] == "nat":
        return ["nat", encode(n[2], [n[1], *scope])]
    raise ValueError(n[0])

# This literal is the independently fixed target, with no free parameters:
# Pi_x[0=0 -> E_z(C(z,x,S p(x)) = C(z,0,x))].
# Within E_z, x is index 1; inside a selector body x is index 3.
# Inside p's own update body, index 1 is its previous counter.
EXPECTED_GOAL = [
    "pi", ["=", -1, -1],
    ["ex", ["=", ["r", 0, 1, ["s", ["r", 3, -1, 1]]],
                  ["r", 0, -1, 3]]]
]


def predecessor(t):
    u, v = fresh("previous_value"), fresh("previous_counter")
    return R(t, Z, u, v, v)


def coverage_formula(t):
    z = fresh("disjunction_witness")
    return Ex(z, Eq(selector(z, t, S(predecessor(t))), selector(z, Z, t)))


def selected_existential(existential, witness, premise):
    """Turn a selected disjunct into its existential encoding.

    Only equality transport, the two recursor equations, and native pack
    are used. Both selector endpoints are computed literally.
    """
    _, z, matrix = existential
    left, right = sub(matrix, {z: witness})[1:]
    lp, rp = compute(left), compute(right)
    assert same(premise.goal, Eq(lp.goal[2], rp.goal[2]))
    slot = fresh("transport")
    first = rewrite(sym(lp), slot, Eq(slot, rp.goal[2]), premise)
    second = rewrite(sym(rp), slot, Eq(left, slot), first)
    return exists_intro(existential, witness, second)


def build_certificate():
    x = fresh("number")
    matrix = coverage_formula(x)
    base = selected_existential(coverage_formula(Z), Z, refl(Z))

    def successor(y, unused_base):
        # R(Sy,0;u,v.v)=y is one recursor equation. Congruence gives
        # S p(Sy)=Sy, which is the right disjunct at the successor.
        pred_equation = compute(predecessor(S(y)))
        slot = fresh("successor_congruence")
        equality = congr(pred_equation, slot, S(slot))
        return selected_existential(coverage_formula(S(y)), S(Z), equality)

    # matrix is existential, so N supplies numerical cases and no induction
    # hypothesis. The redundant base guard in the successor branch is unused.
    pointwise = numerical(x, matrix, x, base, successor)
    closed = pi_intro(x, T, pointwise)
    assert not free(closed.goal)
    assert encode(closed.goal, []) == EXPECTED_GOAL
    return [[], EXPECTED_GOAL, encode_proof(closed, [])]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parents[1] / "examples/numerical_coverage.json")
    parser.add_argument("--checker", type=Path,
                        help="Optional explicit path to the independent native checker")
    args = parser.parse_args()
    certificate = build_certificate()
    args.output.write_text(json.dumps(certificate, indent=2) + "\n", encoding="utf-8")
    print("Fixed closed goal:", json.dumps(EXPECTED_GOAL))
    print("Certificate SHA-256:", hashlib.sha256(args.output.read_bytes()).hexdigest())
    if args.checker is not None:
        result = subprocess.run([sys.executable, str(args.checker), str(args.output)],
                                capture_output=True, text=True)
        print(result.stdout, end="")
        if result.returncode != 0 or result.stdout != "ACCEPT\n":
            raise RuntimeError("Independent checker rejected the coverage certificate")


if __name__ == "__main__":
    main()

