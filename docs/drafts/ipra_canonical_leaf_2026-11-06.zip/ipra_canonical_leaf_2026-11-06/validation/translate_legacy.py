"""Untrusted conversion from the predecessor certificate notation.

This is a convenience utility and provenance aid, not a checker dependency.
It preserves all mathematical content, changes proof constructors, and expands
the old falsity alias into the canonical equation 0 = S0.
"""

import json
import sys


def proof(p):
    match p:
        case ["hyp", a]:
            return a
        case ["pi", a, q]:
            return ["intro", a, proof(q)]
        case ["pack", a, q]:
            return ["pack", a, proof(q)]
        case ["use", p, a, q]:
            return ["use", proof(p), a, proof(q)]
        case _:
            return p


def canonicalize(a):
    if a == ["false"]:
        return ["=", -1, ["s", -1]]
    return list(map(canonicalize, a)) if type(a) is list else a


def certificate(c):
    if type(c) is list and len(c) == 3:
        c = [c[0], c[1], proof(c[2])]
    return canonicalize(c)


if __name__ == "__main__":
    json.dump(certificate(json.load(sys.stdin)), sys.stdout, indent=2)
    print()
