"""Reproduce the whole-program measurements and controlled comparisons.

No comparator file is rewritten. Normalize only docstrings and Python's own
AST unparse formatting; identifiers remain unchanged in the delivered mode.
"""
import ast
import csv
import difflib
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

ROOT = Path(__file__).resolve().parent
CORPUS = ROOT / "comparison"
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL,
           tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node
    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


class CommonNames(ast.NodeTransformer):
    def visit_FunctionDef(self, node):
        node.name = {"inst": "inst", "sub": "inst",
                     "check": "check", "test": "check"}.get(node.name, node.name)
        self.generic_visit(node)
        return node
    def visit_Name(self, node):
        node.id = {"inst": "inst", "sub": "inst",
                   "check": "check", "test": "check"}.get(node.id, node.id)
        return node


def measured(path, mode):
    raw = path.read_bytes()
    tree = StripDocstrings().visit(ast.parse(raw.decode()))
    entry = next(n.name for n in tree.body if isinstance(n, ast.FunctionDef)
                 and n.name in {"check", "test"})
    if "common_driver" in mode:
        core = [n for n in tree.body if isinstance(n, (ast.Assign, ast.FunctionDef))]
        driver = ast.parse(
            "import json, sys\ntry:\n"
            "    take = json.load(sys.stdin).pop\n"
            f"    1 / {entry}(take(), [])\n"
            "    print('ACCEPT')\nexcept:\n"
            "    print('REJECT')\n    sys.exit(1)\n")
        tree.body = driver.body[:1] + core + driver.body[1:]
    if "common_names" in mode:
        tree = CommonNames().visit(tree)
    tree = ast.fix_missing_locations(tree)
    normalized = ast.unparse(tree) + "\n"
    return {
        "normalized_tokens": sum(t.type not in IGNORED for t in
                                 tokenize.generate_tokens(io.StringIO(normalized).readline)),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "normalized_bytes": len(normalized.encode()),
        "source_sha256": hashlib.sha256(raw).hexdigest(),
    }


def main():
    manifest = json.loads((CORPUS / "manifest.json").read_text())
    comparators = [CORPUS / row["local_file"] for row in manifest["programs"]]
    for row, path in zip(manifest["programs"], comparators):
        if hashlib.sha256(path.read_bytes()).hexdigest() != row["sha256"]:
            raise ValueError("Changed comparator: " + row["local_file"])
    for row in manifest["preserved_files"]:
        if hashlib.sha256((ROOT / row["local_file"]).read_bytes()).hexdigest() != row["sha256"]:
            raise ValueError("Changed preserved source: " + row["local_file"])
    if len(comparators) != 10:
        raise ValueError(f"Expected all 10 root comparators, found {len(comparators)}")
    candidate = ROOT / "checker.py"
    modes = ["delivered", "common_driver", "common_names", "common_driver_common_names"]
    result = {"python": platform.python_version(),
              "commit": "ce3371c9025b5c0ba12543acc2e6475d13ff7a3c", "modes": {}}
    rows = []
    for mode in modes:
        measurements = []
        for path in comparators:
            row = {"file": str(path.relative_to(CORPUS)), "mode": mode,
                   **measured(path, mode)}
            measurements.append(row)
            rows.append(row)
        minimum = {k: min(r[k] for r in measurements)
                   for k in ("normalized_tokens", "ast_nodes", "normalized_bytes")}
        new = measured(candidate, mode)
        result["modes"][mode] = {
            "minimum": minimum, "candidate": new,
            "strict_improvement": {k: new[k] < minimum[k] for k in minimum},
            "programs": measurements,
        }
        rows.append({"file": "candidate", "mode": mode, **new})
    result["readable_companion"] = measured(ROOT / "checker_readable.py", "delivered")
    (ROOT / "results/measurements.json").write_text(json.dumps(result, indent=2) + "\n")
    with (ROOT / "results/measurements.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    predecessor = CORPUS / "baselines/ipra_compact_kernel_2026-11-07__checker_retained.py"
    diff = difflib.unified_diff(predecessor.read_text().splitlines(True),
                                candidate.read_text().splitlines(True),
                                "pinned/checker_retained.py", "checker.py")
    (CORPUS / "candidate.patch").write_text("".join(diff))
    print(json.dumps({"python": result["python"], "commit": result["commit"],
                      "readable_companion": result["readable_companion"],
                      "modes": {k: {n: v for n, v in mode.items() if n != "programs"}
                                for k, mode in result["modes"].items()}}, indent=2))


if __name__ == "__main__":
    main()
