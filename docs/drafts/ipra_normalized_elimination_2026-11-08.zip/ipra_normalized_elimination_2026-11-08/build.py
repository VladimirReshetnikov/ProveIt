"""Compile the supplied mathematical report with a local pdfLaTeX installation."""
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
for _ in range(4):
    result = subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error','report.tex'],
                            cwd=ROOT,capture_output=True,text=True)
    if result.returncode:
        print(result.stdout)
        print(result.stderr)
        raise SystemExit(result.returncode)
    log = (ROOT/'report.log').read_text(errors='replace')
    if 'Rerun to get cross-references right' not in log and 'undefined references' not in log:
        break
log = (ROOT/'report.log').read_text(errors='replace')
if any(x in log for x in ('undefined references', 'Citation `', 'Reference `',
                         'Rerun to get cross-references right', 'Overfull')):
    raise SystemExit('Unresolved references or overfull boxes; inspect report.log')
print('Built report.pdf')
