EXAMPLE CERTIFICATES
====================
Run from the package root, for example:

  python3 checker.py < examples/zero_computation.json

Expected ACCEPT:
  zero_computation.json
  successor_computation.json
  equation_induction.json
  implication_nested_identity.json
  existential_elimination.json
  q_elimination_existential.json

Expected REJECT:
  rejected_false_computation.json

Both delivered programs agree on these packets. The complete inherited
147-positive fixture population is preserved under validation/validation_sources.
index.json is the machine-readable verdict list.
