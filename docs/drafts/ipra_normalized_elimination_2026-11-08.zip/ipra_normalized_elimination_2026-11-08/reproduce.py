"""Reproduce the complete offline evidence and compile the paper."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
for script in ("measure.py", "validate.py", "build.py"):
    subprocess.run([sys.executable, str(root / script)], cwd=root, check=True)
print("Measurements, validation, and PDF build passed.")
