"""Validate the relation-triple checker against its exact predecessor and oracle.

Finite tests complement the local refinement argument. The independent oracle
is inherited from the pinned corpus and uses separate term/formula visitors.
All files written by this program stay in this experiment directory.
"""
import ast
from collections import Counter
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
BASE = ROOT
RUNNER = ROOT / "validation/inherited_profiles.py"
spec = importlib.util.spec_from_file_location("inherited_validation", RUNNER)
inherited = importlib.util.module_from_spec(spec)
spec.loader.exec_module(inherited)


def definitions(path):
    tree = ast.parse(path.read_text())
    tree.body = [node for node in tree.body if not isinstance(node, ast.Try)]
    ns = {}
    exec(compile(tree, str(path), "exec"), ns)
    return ns


def paths(value, prefix=()):
    yield prefix
    if type(value) is list:
        for i, child in enumerate(value):
            yield from paths(child, prefix + (i,))


def replaced(value, path, replacement):
    if not path:
        return deepcopy(replacement)
    result = deepcopy(value)
    at = result
    for i in path[:-1]:
        at = at[i]
    at[path[-1]] = deepcopy(replacement)
    return result


def main():
    candidate = ROOT / "checker.py"
    predecessor = ROOT / "comparison/baselines/ipra_compact_kernel_2026-11-07__checker_retained.py"
    new = definitions(candidate)
    readable = definitions(ROOT / "checker_readable.py")
    old = definitions(predecessor)
    oracle = inherited.RetainedOracle(1)
    fixture = BASE / "validation/validation_sources/positive_certificates.json"
    records = json.loads(fixture.read_text())["records"]
    counts = Counter()
    rules = Counter()
    randomizer = random.Random(20261108)

    def compare(packet, expected=None, use_oracle=False):
        actual = inherited.trace(new, packet)
        wanted = inherited.trace(old, packet)
        if actual != wanted:
            raise AssertionError(("trace mismatch", actual, wanted, packet))
        if expected is not None and actual[0] != expected:
            raise AssertionError(("wrong verdict", actual, expected, packet))
        if use_oracle:
            result = oracle.run(packet)
            independently = result["accepted"], result["final_k"], result["remaining"]
            if actual != independently:
                raise AssertionError(("oracle mismatch", actual, independently, packet))
            if result["accepted"]:
                rules.update(result["rules"])
        counts["accepted" if actual[0] else "rejected"] += 1

    for record in records:
        compare(record["packet"], True, True)
        if inherited.trace(readable, record["packet"]) != inherited.trace(new, record["packet"]):
            raise AssertionError("Readable companion differs on a canonical fixture")
        counts["readable_positive_packets"] += 1
        counts["positive_packets"] += 1
    for case in inherited.focused_packets():
        compare(case["packet"], case["expected"]["retained"], True)
        counts["focused_packets"] += 1

    mutations = [None, False, True, -100, -1, 0, 0.5, 1, 100, "x", {},
                 [], [0], [0, 0], [0, 0, 0], [0, 0, 0, 0]]
    for record in records:
        packet = record["packet"]
        locations = list(paths(packet))
        selected = locations if len(locations) <= 40 else randomizer.sample(locations, 40)
        for path in selected:
            for replacement in mutations:
                compare(replaced(packet, path, replacement))
                counts["mutated_packets"] += 1

    values = [None, False, True, -3, -2, -1, -0.25, 0, 0.25, 1, 1.9, 2, 3, 4,
              5, 7, 50, "", "x", {}, {"": 0}, [], [0], [None], [None, None],
              [1, 3], [[None]], [3, 3, 3], [0, [0]], [[1, 3], 0, 1],
              float("inf"), float("-inf"), float("nan")]
    for value in values:
        for image in (None, 0, [0], [0, 0], [0, 0, 0]):
            for depth in range(8):
                for floor in (0, -1, -3):
                    actual = inherited.opening(new, value, image, depth, floor)
                    wanted = inherited.opening(old, value, image, depth, floor)
                    independent = inherited.oracle_opening(oracle, value, image, depth, floor)
                    if actual != wanted or actual != independent:
                        raise AssertionError(("opening mismatch", actual, wanted,
                                              independent, value, image, depth, floor))
                    counts["opening_comparisons"] += 1

    for record in records:
        for flags in ([], ["-O"]):
            result = subprocess.run([sys.executable, *flags, str(candidate)],
                                    input=json.dumps(record["packet"]), capture_output=True,
                                    text=True, timeout=10)
            if (result.returncode, result.stdout, result.stderr) != (0, "ACCEPT\n", ""):
                raise AssertionError(("public boundary", record["name"], flags, result))
            counts["public_positive_runs"] += 1
    for case in inherited.focused_packets():
        if not case["expected"]["retained"]:
            for flags in ([], ["-O"]):
                result = subprocess.run([sys.executable, *flags, str(candidate)],
                                        input=json.dumps(case["packet"]), capture_output=True,
                                        text=True, timeout=10)
                if (result.returncode, result.stdout, result.stderr) != (1, "REJECT\n", ""):
                    raise AssertionError(("public rejection", case["name"], flags, result))
                counts["public_negative_runs"] += 1

    receipt = {"status": "PASS", "counts": dict(counts), "rule_coverage": dict(rules),
               "candidate_sha256": hashlib.sha256(candidate.read_bytes()).hexdigest(),
               "predecessor_sha256": hashlib.sha256(predecessor.read_bytes()).hexdigest(),
               "fixture_sha256": hashlib.sha256(fixture.read_bytes()).hexdigest(),
               "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               "readable_sha256": hashlib.sha256((ROOT / "checker_readable.py").read_bytes()).hexdigest(),
               "oracle_sha256": hashlib.sha256((ROOT / "validation/validation_sources/oracle_erasure.py").read_bytes()).hexdigest(),
               "scope": "Exact parsed-JSON trace comparison; finite evidence, not formal verification."}
    (ROOT / "results/validation.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
