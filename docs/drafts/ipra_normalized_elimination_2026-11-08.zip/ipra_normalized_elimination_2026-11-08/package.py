"""Build a self-contained ZIP and its per-file integrity manifest."""
from pathlib import Path
import hashlib
import zipfile

root = Path(__file__).resolve().parent
excluded_suffixes = {".aux", ".log", ".out", ".toc", ".fls", ".fdb_latexmk", ".pyc"}

def deliverable(path):
    return (path.is_file() and "__pycache__" not in path.parts
            and path.suffix not in excluded_suffixes
            and path.name != "SHA256SUMS.txt")

paths = sorted(path for path in root.rglob("*") if deliverable(path))
manifest = root / "SHA256SUMS.txt"
manifest.write_text("".join(
    hashlib.sha256(path.read_bytes()).hexdigest() + "  "
    + path.relative_to(root).as_posix() + "\n" for path in paths))
archive = root.parent / (root.name + ".zip")
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
    for path in paths + [manifest]:
        stream.write(path, (Path(root.name) / path.relative_to(root)).as_posix())
with zipfile.ZipFile(archive) as stream:
    if stream.testzip() is not None:
        raise SystemExit("ZIP integrity failed")
print(archive)
