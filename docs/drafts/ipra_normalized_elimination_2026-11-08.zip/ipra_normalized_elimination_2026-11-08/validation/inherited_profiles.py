"""Focused independent-oracle checks for the final exact and retained profiles.

The only new oracle rule is explicit retention of in-range formula scalars.
All numerical traversal and named inference rules come from the preserved
independent sort-erasure oracle. Tests are finite evidence, not metatheorems.
"""
import ast
from collections import Counter
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SOURCES = ROOT / 'validation_sources'
ORACLE_PATH = SOURCES / 'oracle_erasure.py'
SPEC = importlib.util.spec_from_file_location('sort_erasure_oracle', ORACLE_PATH)
ORACLE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ORACLE)


class RetainedOracle(ORACLE.Oracle):
    def formula(self, value, image=None, protected=0):
        if type(value) is not list:
            if self.lower <= value < 2 * protected:
                return value
            return 0
        return super().formula(value, image, protected)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def definitions(path):
    tree = ast.parse(path.read_text())
    if not isinstance(tree.body[-1], ast.Try):
        raise ValueError('Expected complete explicit public driver')
    tree.body = tree.body[:-1]
    ns = {}
    exec(compile(tree, str(path), 'exec'), ns)
    return ns


def trace(ns, packet):
    stack = deepcopy(packet)
    ns['k'] = 0
    try:
        ns['take'] = stack.pop
        accepted = bool(ns['check'](stack.pop(), []))
    except Exception:
        accepted = False
    return accepted, ns['k'], len(stack) if type(stack) is list else None


def opening(ns, value, image, depth, floor):
    ns['k'] = floor
    try:
        return True, ns['inst'](value, image, depth)
    except Exception:
        return False, None


def oracle_opening(oracle, value, image, depth, floor):
    oracle.lower = floor
    try:
        fn = oracle.term if depth % 2 else oracle.formula
        return True, fn(value, image, depth // 2)
    except Exception:
        return False, None


def focused_packets():
    return [
        {'name':'zero_computation','packet':[[], [[0,0,0],0]],'expected':{'exact':True,'retained':True}},
        {'name':'successor_computation','packet':[[], [[[0],0,[0]],[0]]],'expected':{'exact':True,'retained':True}},
        {'name':'false_successor_computation','packet':[[], [[[0],0,[0]],0]],'expected':{'exact':False,'retained':False}},
        {'name':'null_formula_annotation','packet':[[], [[0,0,[None,None]],0]],'expected':{'exact':True,'retained':False}},
        {'name':'string_formula_annotation','packet':[[], [[0,0,['x','']],0]],'expected':{'exact':True,'retained':False}},
        {'name':'object_formula_annotation','packet':[[], [[0,0,[{}, {'':7}]],0]],'expected':{'exact':True,'retained':False}},
        {'name':'numeric_formula_annotation','packet':[[], [[0,0,[1,3]],0]],'expected':{'exact':True,'retained':True}},
        {'name':'out_of_scope_formula_annotation','packet':[[], [[0,0,[-50,50]],0]],'expected':{'exact':True,'retained':True}},
        {'name':'empty_completion','packet':[[], [[[],[],[]],[]]],'expected':{'exact':True,'retained':True}},
        {'name':'false_equation_introduction','packet':[0,[[0],0]],'expected':{'exact':False,'retained':False}},
        {'name':'empty_packet','packet':[],'expected':{'exact':False,'retained':False}},
        {'name':'null_goal','packet':[0,None],'expected':{'exact':False,'retained':False}},
    ]


def main():
    files = {
        'exact':Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'checker.py',
        'retained':Path(sys.argv[2]).resolve() if len(sys.argv)>2 else ROOT.parent/'checker_retained.py',
    }
    fixture = SOURCES/'positive_certificates.json'
    records = json.loads(fixture.read_text())['records']
    focus = focused_packets()
    (SOURCES/'focused_star_packets.json').write_text(json.dumps(focus,indent=2)+'\n')
    values = [None,False,True,-3,-2,-1,-.25,0,.25,1,1.9,2,3,4,5,7,50,
              '', 'x', {}, {'':0}, [], [0], [None], [None,None], [1,3],
              [[None]], [3,3,3], [0,[0]], [[1,3],0,1],
              float('inf'),float('-inf'),float('nan')]
    profiles = []
    for name,path in files.items():
        # Preserve the exact tested source, independently of future root edits.
        frozen = SOURCES/('validated_star_'+name+'.py')
        frozen.write_bytes(path.read_bytes())
        ns = definitions(frozen)
        oracle = (ORACLE.Oracle if name=='exact' else RetainedOracle)(1)
        rules = Counter()
        counts = {'canonical_positive_packets':0,'focused_packets':0,'focused_openings':0,'public_cli_runs':0}
        observations = []
        def compare(packet, expected):
            actual = trace(ns,packet)
            read = oracle.run(packet)
            wanted = read['accepted'],read['final_k'],read['remaining']
            if actual != wanted or actual[0] != expected:
                raise AssertionError((name,actual,wanted,expected,packet))
            if read['accepted']:
                rules.update(read['rules'])
            return actual
        for record in records:
            compare(record['packet'],True)
            counts['canonical_positive_packets'] += 1
        for case in focus:
            observed = compare(case['packet'],case['expected'][name])
            observations.append({'name':case['name'],'trace':observed})
            counts['focused_packets'] += 1
        for value in values:
            for image in (None,0,[0]):
                for depth,floor in ((0,0),(0,-2),(1,0),(1,-2),(2,0),(3,-2),(4,-2),(5,0)):
                    actual = opening(ns,value,image,depth,floor)
                    wanted = oracle_opening(oracle,value,image,depth,floor)
                    if actual != wanted:
                        raise AssertionError((name,'opening',actual,wanted,value,image,depth,floor))
                    counts['focused_openings'] += 1
        for case in (focus[0],focus[3],focus[9]):
            expected = case['expected'][name]
            for optimization in ([],['-O']):
                result = subprocess.run([sys.executable,*optimization,str(frozen)],input=json.dumps(case['packet']),capture_output=True,text=True,timeout=10)
                wanted = ('ACCEPT\n',0,'') if expected else ('REJECT\n',1,'')
                if (result.stdout,result.returncode,result.stderr) != wanted:
                    raise AssertionError((name,'public CLI',case['name'],result.stdout,result.returncode,result.stderr))
                counts['public_cli_runs'] += 1
        if path.read_bytes()!=frozen.read_bytes():
            raise ValueError('Candidate changed during focused validation')
        profiles.append({'profile':name,'source':str(path),'frozen_source':str(frozen.relative_to(ROOT)),
                         'sha256':sha(path),'counts':counts,'accepted_rule_counts':dict(rules),
                         'focused_observations':observations})
    receipt = {'status':'PASS','profiles':profiles,'oracle_sha256':sha(ORACLE_PATH),
               'runner_sha256':sha(Path(__file__)),'fixture_sha256':sha(fixture),
               'focused_fixture_sha256':sha(SOURCES/'focused_star_packets.json'),
               'scope':'Finite focused evidence for the two complete JSON acceptance boundaries. The retained profile deliberately differs on formula scalar normalization and on nonnumeric formula annotations. The independently structured oracle imports no production checker and uses separate term/formula visitors and named rules.'}
    (ROOT/'star_profile_results.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))


if __name__=='__main__':
    main()
