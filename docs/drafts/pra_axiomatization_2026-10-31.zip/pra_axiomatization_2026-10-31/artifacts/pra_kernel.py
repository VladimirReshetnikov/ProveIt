#!/usr/bin/env python3
"""Small certificate checker for an equational presentation of PRA.

The trusted checking path has no function evaluator and no induction oracle.
It checks explicit computation equations, equality rules, and R-eta.
This is executable evidence for sample equational proofs, not a formalization
of the metatheorem identifying the calculus with primitive recursive arithmetic.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path
from typing import Union


class KernelError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise KernelError(message)


def natural(value: object, context: str) -> int:
    require(type(value) is int and value >= 0, context + ": expected a natural number")
    return value


def prior_index(value: object, bound: int, context: str) -> int:
    result = natural(value, context)
    require(result < bound, context + ": reference must point backwards")
    return result


@dataclass(frozen=True)
class Function:
    op: str
    arity: int
    refs: tuple[int, ...] = ()
    index: int = 0


@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class App:
    fn: int
    args: tuple["Term", ...]


Term = Union[Var, App]
Equation = tuple[Term, Term]


def free_variables(term: Term) -> set[str]:
    if isinstance(term, Var):
        return {term.name}
    result: set[str] = set()
    for arg in term.args:
        result.update(free_variables(arg))
    return result


def substitute(term: Term, mapping: dict[str, Term]) -> Term:
    """Simultaneous substitution; inserted terms are not substituted again."""
    if isinstance(term, Var):
        return mapping.get(term.name, term)
    return App(term.fn, tuple(substitute(arg, mapping) for arg in term.args))


def encode_term(term: Term) -> dict:
    if isinstance(term, Var):
        return {"v": term.name}
    return {"a": term.fn, "args": [encode_term(arg) for arg in term.args]}


class Kernel:
    def __init__(self, program_data: list[dict]):
        require(type(program_data) is list, "programs must be a list")
        self.functions: list[Function] = []
        for entry in program_data:
            require(type(entry) is dict, "program declaration must be an object")
            op = entry.get("op")
            if op == "zero":
                fn = Function(op, natural(entry.get("arity"), "zero arity"))
            elif op == "succ":
                fn = Function(op, 1)
            elif op == "proj":
                arity = natural(entry.get("arity"), "projection arity")
                index = natural(entry.get("index"), "projection index")
                require(index < arity, "projection index out of range")
                fn = Function(op, arity, index=index)
            elif op == "comp":
                arity = natural(entry.get("arity"), "composition arity")
                outer = prior_index(entry.get("outer"), len(self.functions), "outer")
                inners = entry.get("inners")
                require(type(inners) is list, "inners must be a list")
                inner_ids = tuple(prior_index(i, len(self.functions), "inner") for i in inners)
                require(len(inner_ids) == self.functions[outer].arity,
                        "composition has wrong number of inner functions")
                require(all(self.functions[i].arity == arity for i in inner_ids),
                        "composition inner arities disagree")
                fn = Function(op, arity, (outer,) + inner_ids)
            elif op == "rec":
                base = prior_index(entry.get("base"), len(self.functions), "recursion base")
                step = prior_index(entry.get("step"), len(self.functions), "recursion step")
                n = self.functions[base].arity
                require(self.functions[step].arity == n + 2,
                        "recursion step must have base arity plus two")
                fn = Function(op, n + 1, (base, step))
            else:
                raise KernelError("unknown program constructor: " + repr(op))
            require(fn not in self.functions, "duplicate program declaration")
            self.functions.append(fn)
        require(len(self.functions) >= 2, "program table must start with 0 and S")
        require(self.functions[0] == Function("zero", 0), "program 0 must be nullary zero")
        require(self.functions[1] == Function("succ", 1), "program 1 must be successor")
        self.equations: list[Equation] = []

    def app(self, fn: int, args: tuple[Term, ...]) -> App:
        prior_index(fn, len(self.functions), "function")
        require(len(args) == self.functions[fn].arity, "term has incorrect arity")
        return App(fn, args)

    def term(self, data: object) -> Term:
        require(type(data) is dict, "term must be an object")
        if set(data) == {"v"}:
            name = data["v"]
            require(type(name) is str and name.isidentifier(), "invalid variable name")
            return Var(name)
        require(set(data) == {"a", "args"}, "invalid term shape")
        fn = prior_index(data["a"], len(self.functions), "term function")
        require(type(data["args"]) is list, "term arguments must be a list")
        return self.app(fn, tuple(self.term(arg) for arg in data["args"]))

    def premise(self, index: object) -> Equation:
        return self.equations[prior_index(index, len(self.equations), "premise")]

    def check_node(self, node: dict) -> Equation:
        require(type(node) is dict, "proof node must be an object")
        rule = node.get("rule")
        zero = App(0, ())
        if rule == "refl":
            term = self.term(node.get("term"))
            result = (term, term)
        elif rule == "sym":
            a, b = self.premise(node.get("p"))
            result = (b, a)
        elif rule == "trans":
            a, b = self.premise(node.get("p"))
            c, d = self.premise(node.get("q"))
            require(b == c, "transitivity middle terms differ")
            result = (a, d)
        elif rule == "cong":
            fn = prior_index(node.get("fn"), len(self.functions), "congruence function")
            refs = node.get("premises")
            require(type(refs) is list, "congruence premises must be a list")
            premises = [self.premise(p) for p in refs]
            require(len(premises) == self.functions[fn].arity, "congruence arity mismatch")
            result = (App(fn, tuple(p[0] for p in premises)),
                      App(fn, tuple(p[1] for p in premises)))
        elif rule == "subst":
            a, b = self.premise(node.get("p"))
            mapping_data = node.get("mapping")
            require(type(mapping_data) is dict, "substitution mapping must be an object")
            require(all(type(k) is str and k.isidentifier() for k in mapping_data),
                    "invalid substitution variable")
            mapping = {name: self.term(term) for name, term in mapping_data.items()}
            result = (substitute(a, mapping), substitute(b, mapping))
        elif rule in {"zero", "proj", "comp", "rec0", "recS"}:
            term = self.term(node.get("term"))
            require(isinstance(term, App), "computation needs a function application")
            fn = self.functions[term.fn]
            if rule == "zero":
                require(fn.op == "zero", "zero rule for nonzero function")
                rhs = zero
            elif rule == "proj":
                require(fn.op == "proj", "projection rule for nonprojection")
                rhs = term.args[fn.index]
            elif rule == "comp":
                require(fn.op == "comp", "composition rule for noncomposition")
                rhs = App(fn.refs[0], tuple(App(i, term.args) for i in fn.refs[1:]))
            elif rule == "rec0":
                require(fn.op == "rec", "rec0 rule for nonrecursion")
                require(term.args[0] == zero, "rec0 first argument must be literal zero")
                rhs = App(fn.refs[0], term.args[1:])
            else:
                require(fn.op == "rec", "recS rule for nonrecursion")
                index = term.args[0]
                require(isinstance(index, App) and index.fn == 1,
                        "recS first argument must be a successor")
                predecessor = index.args[0]
                recursive_call = App(term.fn, (predecessor,) + term.args[1:])
                rhs = App(fn.refs[1], (predecessor, recursive_call) + term.args[1:])
            result = (term, rhs)
        elif rule == "eta":
            fn_id = prior_index(node.get("fn"), len(self.functions), "eta function")
            fn = self.functions[fn_id]
            require(fn.op == "rec", "eta conclusion must use a recursion symbol")
            name = node.get("variable")
            parameters = node.get("parameters")
            require(type(name) is str and name.isidentifier(), "invalid eta variable")
            require(type(parameters) is list and all(type(p) is str and p.isidentifier()
                    for p in parameters), "invalid eta parameters")
            require(len(parameters) == fn.arity - 1, "wrong number of eta parameters")
            require(len(set([name] + parameters)) == len(parameters) + 1,
                    "eta variable and parameters must be distinct")
            term = self.term(node.get("term"))
            require(free_variables(term) <= set([name] + parameters),
                    "eta term has an undeclared free variable")
            x = Var(name)
            ys = tuple(Var(p) for p in parameters)
            expected_base = (substitute(term, {name: zero}), App(fn.refs[0], ys))
            expected_step = (substitute(term, {name: App(1, (x,))}),
                             App(fn.refs[1], (x, term) + ys))
            require(self.premise(node.get("base")) == expected_base,
                    "eta base premise does not match")
            require(self.premise(node.get("step")) == expected_step,
                    "eta step premise does not match")
            result = (term, App(fn_id, (x,) + ys))
        else:
            raise KernelError("unknown proof rule: " + repr(rule))
        self.equations.append(result)
        return result

    def render(self, term: Term, names: dict[int, str] | None = None) -> str:
        if isinstance(term, Var):
            return term.name
        name = (names or {}).get(term.fn, "f" + str(term.fn))
        if not term.args:
            return name
        return name + "(" + ", ".join(self.render(a, names) for a in term.args) + ")"


def verify_certificate(data: dict) -> tuple[Kernel, list[tuple[str, Equation]]]:
    require(type(data) is dict and data.get("format") == "pra-equational-1",
            "unknown certificate format")
    kernel = Kernel(data.get("programs"))
    nodes = data.get("proof")
    require(type(nodes) is list, "proof must be a list")
    for number, node in enumerate(nodes):
        try:
            kernel.check_node(node)
        except KernelError as error:
            raise KernelError(f"proof node {number}: {error}") from error
    goals = data.get("theorems")
    require(type(goals) is list and len(goals) > 0, "missing theorem list")
    checked = []
    for goal in goals:
        require(type(goal) is dict and type(goal.get("name")) is str, "invalid theorem")
        actual = kernel.premise(goal.get("proof"))
        expected_data = goal.get("equation")
        require(type(expected_data) is list and len(expected_data) == 2,
                "theorem equation must have two terms")
        expected = tuple(kernel.term(t) for t in expected_data)
        require(actual == expected, "theorem does not match its claimed equation")
        checked.append((goal["name"], actual))
    return kernel, checked


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("certificate", nargs="?", type=Path,
                        default=Path(__file__).with_name("addition_certificates.json"))
    args = parser.parse_args()
    try:
        data = json.loads(args.certificate.read_text(encoding="utf-8"))
        kernel, theorems = verify_certificate(data)
        names = {int(k): str(v) for k, v in data.get("names", {}).items()}
        for name, (left, right) in theorems:
            print("VERIFIED " + name + ": " + kernel.render(left, names)
                  + " = " + kernel.render(right, names))
        eta_count = sum(node.get("rule") == "eta" for node in data["proof"])
        print(f"Checked {len(kernel.functions)} program declarations, "
              f"{len(kernel.equations)} proof nodes, {eta_count} R-eta inferences.")
    except (KernelError, OSError, json.JSONDecodeError) as error:
        parser.exit(1, "REJECTED: " + str(error) + "\n")


if __name__ == "__main__":
    main()
