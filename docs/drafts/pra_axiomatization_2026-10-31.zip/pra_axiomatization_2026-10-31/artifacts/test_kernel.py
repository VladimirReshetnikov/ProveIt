#!/usr/bin/env python3
"""Focused rejection checks for the certificate kernel's critical side conditions."""

from copy import deepcopy
import json
from pathlib import Path

from pra_kernel import KernelError, verify_certificate


def reject(data, mutation, name):
    altered = deepcopy(data)
    mutation(altered)
    if altered == data:
        raise RuntimeError("test mutation made no change: " + name)
    try:
        verify_certificate(altered)
    except KernelError:
        print("REJECTED as expected: " + name)
    else:
        raise RuntimeError("UNSOUND ACCEPTANCE: " + name)


def main():
    path = Path(__file__).with_name("addition_certificates.json")
    data = json.loads(path.read_text(encoding="utf-8"))
    verify_certificate(data)
    print("ACCEPTED: original certificate")

    def cyclic_program(d):
        i = next(i for i, p in enumerate(d["programs"]) if p["op"] == "rec")
        d["programs"][i]["base"] = i

    def bad_arity(d):
        i = next(i for i, p in enumerate(d["programs"]) if p["op"] == "rec")
        d["programs"][i]["step"] = 1

    def false_base(d):
        node = next(p for p in d["proof"] if p["rule"] == "eta")
        node["base"] = node["step"]

    def eigenvariable_collision(d):
        node = next(p for p in d["proof"] if p["rule"] == "eta" and p["parameters"])
        node["variable"] = node["parameters"][0]

    def negative_reference(d):
        node = next(p for p in d["proof"] if p["rule"] == "trans")
        node["p"] = -1

    def false_claim(d):
        d["theorems"][-1]["equation"][1] = {"a": 0, "args": []}

    for mutation, name in [
        (cyclic_program, "cyclic program declaration"),
        (bad_arity, "recursion arity mismatch"),
        (false_base, "R-eta base premise mismatch"),
        (eigenvariable_collision, "R-eta variable/parameter collision"),
        (negative_reference, "negative proof reference"),
        (false_claim, "false claimed theorem"),
    ]:
        reject(data, mutation, name)


if __name__ == "__main__":
    main()
