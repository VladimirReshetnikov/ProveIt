#!/usr/bin/env python3
"""Generate explicit certificates; every emitted inference is rechecked.

The normalizer is an untrusted proof-producing convenience. It emits ordinary
computation/equality nodes. The standalone checker never calls it.
"""

from __future__ import annotations

import json
from pathlib import Path

from pra_kernel import App, Kernel, Term, Var, encode_term, substitute


class Programs:
    def __init__(self):
        self.entries: list[dict] = []

    def add(self, entry: dict) -> int:
        if entry not in self.entries:
            self.entries.append(entry)
        return self.entries.index(entry)

    def proj(self, arity: int, index: int) -> int:
        return self.add({"op": "proj", "arity": arity, "index": index})

    def comp(self, outer: int, inners: list[int], arity: int) -> int:
        return self.add({"op": "comp", "outer": outer, "inners": inners, "arity": arity})

    def rec(self, base: int, step: int) -> int:
        return self.add({"op": "rec", "base": base, "step": step})


class Builder:
    def __init__(self, programs: Programs):
        self.kernel = Kernel(programs.entries)
        self.nodes: list[dict] = []
        self.cache: dict[str, int] = {}
        self.normalized: dict[Term, int] = {}

    def add(self, node: dict) -> int:
        key = json.dumps(node, sort_keys=True)
        if key in self.cache:
            return self.cache[key]
        self.kernel.check_node(node)
        index = len(self.nodes)
        self.nodes.append(node)
        self.cache[key] = index
        return index

    def eq(self, proof: int):
        return self.kernel.equations[proof]

    def refl(self, term: Term) -> int:
        return self.add({"rule": "refl", "term": encode_term(term)})

    def sym(self, p: int) -> int:
        if self.eq(p)[0] == self.eq(p)[1]:
            return p
        return self.add({"rule": "sym", "p": p})

    def trans(self, p: int, q: int) -> int:
        a, b = self.eq(p)
        c, d = self.eq(q)
        if b != c:
            raise ValueError("builder transitivity mismatch")
        if a == b:
            return q
        if c == d:
            return p
        return self.add({"rule": "trans", "p": p, "q": q})

    def subst(self, p: int, mapping: dict[str, Term]) -> int:
        return self.add({"rule": "subst", "p": p,
                         "mapping": {k: encode_term(v) for k, v in mapping.items()}})

    def normalize(self, term: Term) -> int:
        if term in self.normalized:
            return self.normalized[term]
        if isinstance(term, Var):
            proof = self.refl(term)
        else:
            arg_proofs = [self.normalize(arg) for arg in term.args]
            normal_args = tuple(self.eq(p)[1] for p in arg_proofs)
            if normal_args == term.args:
                proof = self.refl(term)
            else:
                proof = self.add({"rule": "cong", "fn": term.fn, "premises": arg_proofs})
            current = self.eq(proof)[1]
            fn = self.kernel.functions[term.fn]
            rule = None
            if fn.op == "zero" and current != App(0, ()):
                rule = "zero"
            elif fn.op in {"proj", "comp"}:
                rule = fn.op
            elif fn.op == "rec":
                first = current.args[0]
                if first == App(0, ()):
                    rule = "rec0"
                elif isinstance(first, App) and first.fn == 1:
                    rule = "recS"
            if rule is not None:
                computation = self.add({"rule": rule, "term": encode_term(current)})
                proof = self.trans(proof, computation)
                proof = self.trans(proof, self.normalize(self.eq(computation)[1]))
        self.normalized[term] = proof
        return proof

    def by_computation(self, left: Term, right: Term) -> int:
        a = self.normalize(left)
        b = self.normalize(right)
        if self.eq(a)[1] != self.eq(b)[1]:
            raise ValueError("requested equation is not a computation identity")
        return self.trans(a, self.sym(b))

    def via(self, left: Term, right: Term, lemma: int) -> int:
        a, b = self.eq(lemma)
        return self.trans(self.by_computation(left, a),
                          self.trans(lemma, self.by_computation(b, right)))

    def eta(self, term: Term, fn_id: int, variable: str, parameters: list[str],
            base: int | None = None, step: int | None = None) -> int:
        fn = self.kernel.functions[fn_id]
        x = Var(variable)
        ys = tuple(Var(p) for p in parameters)
        base_goal = (substitute(term, {variable: App(0, ())}), App(fn.refs[0], ys))
        step_goal = (substitute(term, {variable: App(1, (x,))}),
                     App(fn.refs[1], (x, term) + ys))
        base_proof = self.by_computation(*base_goal) if base is None else self.via(*base_goal, base)
        step_proof = self.by_computation(*step_goal) if step is None else self.via(*step_goal, step)
        return self.add({"rule": "eta", "fn": fn_id, "variable": variable,
                         "parameters": parameters, "term": encode_term(term),
                         "base": base_proof, "step": step_proof})


def build() -> dict:
    programs = Programs()
    programs.add({"op": "zero", "arity": 0})
    programs.add({"op": "succ"})
    identity = programs.proj(1, 0)
    add_step = programs.comp(1, [programs.proj(3, 1)], 3)
    addition = programs.rec(identity, add_step)
    count_step = programs.comp(1, [programs.proj(2, 1)], 2)
    count = programs.rec(0, count_step)
    shifted_addition = programs.rec(1, add_step)

    b = Builder(programs)
    x, y = Var("x"), Var("y")
    zero = App(0, ())

    def s(t):
        return App(1, (t,))

    def add(t, u):
        return App(addition, (t, u))

    # Both x and add(x,0) solve r(0)=0, r(Sx)=S(r(x)).
    id_count = b.eta(x, count, "x", [])
    add_zero_count = b.eta(add(x, zero), count, "x", [])
    right_identity = b.trans(add_zero_count, b.sym(id_count))

    # Both add(x,Sy) and S(add(x,y)) solve r(0,y)=Sy, r(Sx,y)=S(r(x,y)).
    shifted_left = b.eta(add(x, s(y)), shifted_addition, "x", ["y"])
    shifted_right = b.eta(s(add(x, y)), shifted_addition, "x", ["y"])
    successor_right = b.trans(shifted_left, b.sym(shifted_right))

    # add(y,x), as a function of x, obeys the defining recursion for add(x,y).
    comm_base = b.subst(right_identity, {"x": y})
    comm_step = b.subst(successor_right, {"x": y, "y": x})
    reversed_commutativity = b.eta(add(y, x), addition, "x", ["y"],
                                  base=comm_base, step=comm_step)
    commutativity = b.sym(reversed_commutativity)

    left_identity = b.by_computation(add(zero, y), y)
    goals = [
        ("counting recursor is identity", b.sym(id_count)),
        ("addition left identity", left_identity),
        ("addition right identity", right_identity),
        ("addition respects successor in second argument", successor_right),
        ("addition commutativity", commutativity),
    ]
    return {
        "format": "pra-equational-1",
        "description": "Explicit computation/equality/R-eta certificates; no evaluator oracle.",
        "programs": programs.entries,
        "names": {"0": "0", "1": "S", str(identity): "id", str(add_step): "add_step",
                  str(addition): "add", str(count_step): "count_step", str(count): "count",
                  str(shifted_addition): "shifted_add"},
        "proof": b.nodes,
        "theorems": [{"name": name, "proof": proof,
                       "equation": [encode_term(t) for t in b.eq(proof)]}
                      for name, proof in goals],
    }


if __name__ == "__main__":
    output = Path(__file__).with_name("addition_certificates.json")
    data = build()
    output.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    print(f"Generated {output.name}: {len(data['proof'])} explicit proof nodes.")
