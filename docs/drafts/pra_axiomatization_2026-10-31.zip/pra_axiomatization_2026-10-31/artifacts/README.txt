EQUATIONAL PRA: SMALL CERTIFICATE CHECKER
=======================================

Run with Python 3.10 or later, without external dependencies:

    python3 pra_kernel.py addition_certificates.json
    python3 test_kernel.py

To regenerate the certificate:

    python3 build_examples.py
    python3 pra_kernel.py addition_certificates.json

What is checked
---------------
The finite program table contains zero functions, successor, projections,
composition, and primitive recursion. Every reference in a program definition
points to an earlier declaration, so the syntax is well founded. All arities
are checked. The first recursion argument is the counter:

    R[g,h](0,ys)    = g(ys)
    R[g,h](Sx,ys)   = h(x,R[g,h](x,ys),ys).

The proof is a finite list of equations. Every premise refers to an earlier
proof node. Rules are reflexivity, symmetry, transitivity, congruence,
simultaneous variable substitution, the displayed computation equations
(plus zero/projection/composition equations), and the two-premise R-eta rule:

    t(0,ys) = g(ys)       t(Sx,ys) = h(x,t(x,ys),ys)
    ------------------------------------------------
              t(x,ys) = R[g,h](x,ys).

R-eta's counter variable and parameter variables must be distinct, and t has
no undeclared free variables. There are no undischarged assumptions in these
certificates. The checker computes each conclusion from its premises and
checks the final equations against explicit theorem claims.

The supplied certificate proves the identity of the counting recursor,
both addition identities, successor interaction in the second argument,
and addition commutativity. The generator's symbolic simplifier emits
ordinary checked inference nodes. The checker does not evaluate primitive
recursive functions to certify equations.

One-premise presentation
-----------------------
The paper may use the equivalent one-premise rule

    F(Sx,ys) = h(x,F(x,ys),ys)
    -----------------------------------------
    F(x,ys) = J_h(x,F(0,ys),ys),

where the parameterized iterator is defined by

    J_h(0,a,ys) = a
    J_h(Sx,a,ys) = h(x,J_h(x,a,ys),ys).

It is a derived rule of this kernel. Give the term F(0,ys) a primitive
recursive program code g; R-eta identifies F with R[g,h]. A second R-eta
application identifies J_h(x,g(ys),ys) with R[g,h], using computation
equations for both premises. Equality then gives the displayed conclusion.
The kernel keeps the two-premise version so each side condition is explicit.
There is no separate one-premise node type in the certificate format.

Scope and limits
----------------
This implements an equational proof calculus. It does not check the complete
metamathematical equivalence proof in the accompanying paper, and the Python
kernel itself has not been verified in Lean or Rocq. The rejection tests cover
important side conditions, not every possible implementation defect.

The equational calculus must not be confused with a full first-order theory
obtained merely by adding 0 != S0. Coordinatewise primitive recursive
operations on N x N satisfy the computation equations and recurrence
uniqueness but fail the first-order predecessor-cover sentence

    forall x, x=0 or x=S(pred(x)).

For example, (0,1) has neither form. Thus literal full first-order equivalence
requires the extra logical/model conditions discussed in the paper. Arithmetic
encoding of quantifier-free propositions in an equation-only calculus is a
different comparison from retaining their ordinary first-order connectives.

The code, generated certificate, and tests are supplied as transparent
companion artifacts. No claim of global minimality of the kernel is made.
