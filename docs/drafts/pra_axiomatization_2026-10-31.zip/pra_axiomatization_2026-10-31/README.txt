A SMALL AXIOMATIZATION OF PRIMITIVE RECURSIVE ARITHMETIC
=====================================================
Prepared for Vladimir Reshetnikov, 2026-10-31.

MAIN RESULT
-----------
In classical first-order logic with equality, take the usual defining
equations D for syntactically indexed primitive recursive programs.
Let e(x,y) = z((x monus y) + (y monus x)), where z(0)=1 and z(Sx)=0.
Add the one fixed sentence

    forall x,y: e(x,y)=0 iff x != y

and the schema, for every primitive recursive term t(x,parameters),

    [t(0,parameters)=0 and
     forall x: t(Sx,parameters)=S(t(x,parameters))]
        implies forall x: t(x,parameters)=x.

The paper proves that this theory has exactly the first-order theorems of
standard PRA in the common primitive recursive language. Numerical
separation and predecessor coverage are derived, not assumed. This is a
compact presentation; there is no claim of global minimality.

CONTENTS
--------
pra_axiomatization.tex     Complete LaTeX source, including bibliography.
pra_axiomatization.pdf     Compiled paper.
axioms.txt                Concise reusable specification of the main theory.
validation.txt            Recorded checks of the companion proof certificates.
artifacts/                Python equational checker, certificate generator,
                          certificates, focused rejection tests, and README.

REBUILD THE PAPER
----------------
With a standard TeX Live installation:

    pdflatex -interaction=nonstopmode -halt-on-error pra_axiomatization.tex
    pdflatex -interaction=nonstopmode -halt-on-error pra_axiomatization.tex

All references are embedded; no BibTeX run or external image files are needed.

RUN THE EQUATIONAL CERTIFICATES
------------------------------
Python 3.10 or later is sufficient. No external Python packages are used.
From the artifacts directory:

    python3 pra_kernel.py addition_certificates.json
    python3 test_kernel.py

SCOPE OF VERIFICATION
---------------------
The paper contains an ordinary mathematical proof of the complete
first-order equivalence. The executable artifact checks separate sample
proofs in the related equational calculus, including addition commutativity.
It does not machine-check the whole equivalence proof or verify the Python
kernel in Lean or Rocq. See artifacts/README.txt for the exact rules.

The two presentations must not be conflated: raw recursion uniqueness plus
0 != 1 does not give literal first-order PRA. The paper supplies a direct
product counterexample and explains how the fixed comparison axiom repairs
the issue.
