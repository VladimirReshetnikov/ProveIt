#!/usr/bin/env python3
"""Check, compile, hash, and optionally package the iPRA report."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile


ROOT = Path(__file__).resolve().parent
ARTIFACTS = ROOT / "artifacts"
BUILD = ROOT / ".build"
STEM = "ipra_explicit"


def run(command: list[str], log_name: str) -> str:
    result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
    output = result.stdout + result.stderr
    (ARTIFACTS / log_name).write_text(output, encoding="utf-8")
    if result.returncode:
        raise RuntimeError(f"Command failed: {command[0]}\n{output[-5000:]}")
    return output


def deliverables() -> list[Path]:
    allowed = {".tex", ".pdf", ".txt", ".py", ".json", ".csv"}
    return sorted(
        p for p in ROOT.rglob("*")
        if p.is_file() and p.suffix in allowed
        and ".build" not in p.relative_to(ROOT).parts
        and "__pycache__" not in p.relative_to(ROOT).parts
        and p.name != "SHA256SUMS.txt"
    )


def checksums() -> None:
    entries = []
    for path in deliverables():
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        entries.append(f"{digest}  {path.relative_to(ROOT).as_posix()}")
    (ROOT / "SHA256SUMS.txt").write_text("\n".join(entries) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checks-only", action="store_true")
    parser.add_argument("--archive", action="store_true")
    args = parser.parse_args()
    if args.checks_only and args.archive:
        parser.error("--archive requires a complete build")
    ARTIFACTS.mkdir(exist_ok=True)
    run([sys.executable, str(ARTIFACTS / "verify.py")], "verification_stdout.txt")
    result = json.loads((ARTIFACTS / "verification.json").read_text())
    if result["status"] != "passed":
        raise RuntimeError("Diagnostics did not pass.")
    if args.checks_only:
        print("All finite syntax and symbolic diagnostics passed.")
        return

    if shutil.which("pdflatex") is None:
        raise RuntimeError("pdflatex is required to compile the PDF.")
    BUILD.mkdir(exist_ok=True)
    command = [
        "pdflatex", "-interaction=nonstopmode", "-halt-on-error", "-file-line-error",
        f"-output-directory={BUILD}", f"{STEM}.tex",
    ]
    for index in range(1, 4):
        run(command, f"latex_pass_{index}.txt")
    log = (BUILD / f"{STEM}.log").read_text(errors="replace")
    forbidden = [
        "Overfull \\hbox", "Overfull \\vbox", "There were undefined references",
        "There were multiply-defined labels", "destination with the same identifier",
        "Rerun to get cross-references right",
    ]
    bad = [message for message in forbidden if message in log]
    if bad or re.search(r"(?:Reference|Citation) .+ undefined", log):
        raise RuntimeError(f"Unresolved LaTeX diagnostics: {bad}")
    shutil.copy2(BUILD / f"{STEM}.pdf", ROOT / f"{STEM}.pdf")
    page_match = re.search(r"Output written on .*?\((\d+) pages?", log, re.S)
    summary = {
        "finite_diagnostics": "passed",
        "latex_passes": 3,
        "undefined_references": False,
        "duplicate_pdf_destinations": False,
        "overfull_boxes": False,
        "pdf_pages": int(page_match.group(1)) if page_match else None,
        "pdf_file": f"{STEM}.pdf",
        "mathematical_status": "Written proofs; no complete Lean/Rocq formalization.",
        "diagnostic_scope": result["scope"],
    }
    (ARTIFACTS / "build_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    checksums()
    if args.archive:
        destination = ROOT.parent / f"{ROOT.name}.zip"
        with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as out:
            for path in deliverables() + [ROOT / "SHA256SUMS.txt"]:
                out.write(path, f"{ROOT.name}/{path.relative_to(ROOT).as_posix()}")
        with zipfile.ZipFile(destination) as archive:
            if archive.testzip() is not None:
                raise RuntimeError("Archive CRC check failed.")
        print(f"Created {destination.name}")
    print(f"Built {STEM}.pdf; all diagnostics passed.")


if __name__ == "__main__":
    main()
