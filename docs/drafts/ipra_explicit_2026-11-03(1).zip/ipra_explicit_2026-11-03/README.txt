AN EXPLICIT SMALL AXIOMATIZATION OF INTUITIONISTIC PRA
Prepared for Vladimir Reshetnikov, 3 November 2026
===================================================

Start with ipra_explicit.pdf. Its complete standalone LaTeX source is
ipra_explicit.tex. AXIOMS.txt is an independent exact specification.

RESULT
One fixed separation sentence, two computation-equation schemas (grouped
as initialized primitive recursion), and one equation-indexed inference
rule, together with a completely enumerated intuitionistic logical
calculus. All number parameters and eigenvariable conditions are explicit.

For an equation E(x,c), the arithmetic rule is:

  Gamma, x=0 OR E(x,c) |- E(Sx,c)
  ---------------------------------
  Gamma |- t=0 OR E(t,c)

Here x is fresh for Gamma, t, and the fixed parameter terms. The premise's
displayed zero-or-equation assumption is discharged. Formula contexts
are unrestricted; E itself must be an equation.

The report proves full first-order bi-interpretability with iPRA, with
whole-carrier domains and internally proved identity composites, and
syntactic equiconsistency. Its derivation includes coverage, equation
induction, a constructive equality bit, all quantifier-free induction,
and internal recursion uniqueness. It does not merely compare standard
numerical computations.

COMPARISON
The four actual source ZIPs were retrieved and hash-verified at commit
5753b3f955eb6681b6f89f5d778fda2b7ec8f87a of VladimirReshetnikov/ProveIt.
See provenance/source_manifest.json for exact URLs, Git blobs, and SHA-256.

1. Relative to equation closure, deleting the impossible successor-zero
   branch saves exactly five nodes per fully expanded schema instance:
   old Z: 3F+k+p+17; new Z_plus: 3F+k+p+12.
2. The primary signature avoids unused update parameters and literal
   identity recursors. A complete rank-recursive proof validates that
   convention. Parameter pruning was already suggested in the retraction
   draft; no novelty is claimed for that idea.
3. A separate fixed homomorphic quotient erases padded counter-projection
   functions Q_m in four explicitly selected complete instantiations of
   the delivered constructions (identified in the report). Every finite
   source formula or axiom-list image is no larger. Calls m+4 become 4;
   whole literal module images 16+3m become 16+m, retaining the old
   vacuous quantifiers. This comparison preserves each source's own
   interface and previously proved reductions. For other variants it
   erases only actually retained eligible symbols and is otherwise the
   identity; strict savings require an affected active occurrence.

The expanded closure formula is not uniformly shorter than all witnessed
boundary formulas. A single presentation is not claimed to attain every
minimum of their different macro interfaces. No encoding-independent
global optimum or universal proof-length reduction is asserted.

CONTENTS
ipra_explicit.pdf             Compiled mathematical report
ipra_explicit.tex             Complete, standalone LaTeX source
AXIOMS.txt                   Complete syntax, logic, axioms, and rules
artifacts/verify.py           Standard-library exact syntax diagnostics
artifacts/verification.json   Deterministic completed diagnostic results
artifacts/build_summary.json  Compilation and validation record
artifacts/latex_pass_*.txt    Successful LaTeX compilation output
provenance/source_manifest.json
provenance/comparison.csv    Audited source identities and comparisons
build.py                     Rebuild and package script
SHA256SUMS.txt                Delivered-file checksums

REBUILD
  python3 build.py --checks-only
  python3 build.py
  python3 build.py --archive

The Python code requires Python 3.10 or later and no third-party packages.
PDF generation needs pdflatex and the standard LaTeX packages named in
the source preamble. Intermediate files go to .build and are excluded
from the ZIP. The archive is created beside this directory. Recompilation
may change PDF metadata and checksums.

VERIFICATION STATUS
Complete written mathematical proofs, independent mathematical review,
and finite exact syntax/scope diagnostics with symbolic base/step checks.
No complete Lean/Rocq formalization is claimed. The diagnostics do not
replace the written proofs of induction or bi-interpretability.

The supplied source ZIPs are referenced rather than duplicated. No
repository write or externally published research claim is part of this
deliverable.
