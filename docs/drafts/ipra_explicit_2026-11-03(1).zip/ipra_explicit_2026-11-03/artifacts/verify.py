#!/usr/bin/env python3
"""Finite syntax diagnostics for the iPRA report; no proof-assistant claim.

Every recursor call pays for its entire frozen descriptor, recursively.
Substitution and the quotient act on actual arguments, never frozen labels.
Run with Python 3.10+; results are written beside this file as verification.json.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Union


@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class Const:
    name: str


@dataclass(frozen=True)
class App:
    name: str
    args: tuple[Term, ...]


@dataclass(frozen=True)
class Symbol:
    body: Term
    parameters: tuple[str, ...] = ()


@dataclass(frozen=True)
class Rec:
    symbol: Symbol
    args: tuple[Term, ...]

    def __post_init__(self) -> None:
        assert len(self.args) == len(self.symbol.parameters) + 2


Term = Union[Var, Const, App, Rec]


@dataclass(frozen=True)
class Eq:
    left: Term
    right: Term


@dataclass(frozen=True)
class Bottom:
    pass


@dataclass(frozen=True)
class Binary:
    op: str
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Quant:
    kind: str
    variable: str
    body: Formula


Formula = Union[Eq, Bottom, Binary, Quant]
Node = Union[Term, Formula]
ZERO = Const("0")
Q0 = Symbol(Var("w"))


def succ(t: Term) -> Term:
    return App("S", (t,))


def q_symbol(m: int) -> Symbol:
    return Symbol(Var("w"), tuple(f"c{i}" for i in range(1, m + 1)))


def cost(node: Node) -> int:
    """One per AST node, plus the full frozen body at every recursor call."""
    if isinstance(node, (Var, Const, Bottom)):
        return 1
    if isinstance(node, App):
        return 1 + sum(map(cost, node.args))
    if isinstance(node, Rec):
        return 1 + cost(node.symbol.body) + sum(map(cost, node.args))
    if isinstance(node, (Eq, Binary)):
        return 1 + cost(node.left) + cost(node.right)
    return 1 + cost(node.body)


def free(node: Node) -> set[str]:
    """Active free variables only: frozen descriptors have their own slots."""
    if isinstance(node, Var):
        return {node.name}
    if isinstance(node, (Const, Bottom)):
        return set()
    if isinstance(node, (App, Rec)):
        return set().union(*(free(a) for a in node.args))
    if isinstance(node, (Eq, Binary)):
        return free(node.left) | free(node.right)
    return free(node.body) - {node.variable}


def active_names(node: Node) -> set[str]:
    if isinstance(node, Quant):
        return active_names(node.body) | {node.variable}
    if isinstance(node, (Eq, Binary)):
        return active_names(node.left) | active_names(node.right)
    return free(node)


def occurrences(node: Node, variable: str) -> int:
    if isinstance(node, Var):
        return int(node.name == variable)
    if isinstance(node, (Const, Bottom)):
        return 0
    if isinstance(node, (App, Rec)):
        return sum(occurrences(a, variable) for a in node.args)
    if isinstance(node, (Eq, Binary)):
        return occurrences(node.left, variable) + occurrences(node.right, variable)
    return 0 if node.variable == variable else occurrences(node.body, variable)


def substitute(node: Node, environment: dict[str, Term]) -> Node:
    """Simultaneous capture-avoiding substitution; replacements are not revisited."""
    if isinstance(node, Var):
        return environment.get(node.name, node)
    if isinstance(node, (Const, Bottom)):
        return node
    if isinstance(node, App):
        return App(node.name, tuple(substitute(a, environment) for a in node.args))
    if isinstance(node, Rec):
        return Rec(node.symbol, tuple(substitute(a, environment) for a in node.args))
    if isinstance(node, Eq):
        return Eq(substitute(node.left, environment), substitute(node.right, environment))
    if isinstance(node, Binary):
        return Binary(node.op, substitute(node.left, environment),
                      substitute(node.right, environment))
    env = {k: v for k, v in environment.items() if k != node.variable}
    image_free = set().union(*(free(v) for v in env.values()))
    variable, body = node.variable, node.body
    if variable in image_free:
        avoid = active_names(body) | image_free | set(env) | {variable}
        index = 0
        while f"{variable}_{index}" in avoid:
            index += 1
        fresh = f"{variable}_{index}"
        body = substitute(body, {variable: Var(fresh)})
        variable = fresh
    return Quant(node.kind, variable, substitute(body, env))


def erase(node: Node) -> Node:
    """Fixed homomorphic quotient Q_m(n,a,c) -> Q_0(n,a), m > 0."""
    if isinstance(node, (Var, Const, Bottom)):
        return node
    if isinstance(node, App):
        return App(node.name, tuple(erase(a) for a in node.args))
    if isinstance(node, Rec):
        if node.symbol.body == Var("w") and node.symbol.parameters:
            return Rec(Q0, tuple(erase(a) for a in node.args[:2]))
        return Rec(node.symbol, tuple(erase(a) for a in node.args))
    if isinstance(node, Eq):
        return Eq(erase(node.left), erase(node.right))
    if isinstance(node, Binary):
        return Binary(node.op, erase(node.left), erase(node.right))
    return Quant(node.kind, node.variable, erase(node.body))


def alpha_key(node: Node, bound: tuple[str, ...] = ()) -> tuple:
    """Compare formulas up to bound-variable renaming, leaving labels literal."""
    if isinstance(node, Var):
        if node.name in bound:
            return ("bound", bound[::-1].index(node.name))
        return ("free", node.name)
    if isinstance(node, Const):
        return ("constant", node.name)
    if isinstance(node, Bottom):
        return ("bottom",)
    if isinstance(node, App):
        return ("app", node.name, tuple(alpha_key(a, bound) for a in node.args))
    if isinstance(node, Rec):
        label = (alpha_key(node.symbol.body), node.symbol.parameters)
        return ("rec", label, tuple(alpha_key(a, bound) for a in node.args))
    if isinstance(node, Eq):
        return ("eq", alpha_key(node.left, bound), alpha_key(node.right, bound))
    if isinstance(node, Binary):
        return (node.op, alpha_key(node.left, bound), alpha_key(node.right, bound))
    return (node.kind, alpha_key(node.body, bound + (node.variable,)))


def show(node: Node) -> str:
    if isinstance(node, (Var, Const)):
        return node.name
    if isinstance(node, Bottom):
        return "false"
    if isinstance(node, App):
        return f"{node.name}({', '.join(map(show, node.args))})"
    if isinstance(node, Rec):
        if node.symbol.body == Var("w"):
            name = f"Q_{len(node.symbol.parameters)}"
        else:
            params = ",".join(node.symbol.parameters)
            name = f"R[{show(node.symbol.body)};{params}]"
        return f"{name}({', '.join(map(show, node.args))})"
    if isinstance(node, Eq):
        return f"{show(node.left)} = {show(node.right)}"
    if isinstance(node, Binary):
        return f"({show(node.left)} {node.op} {show(node.right)})"
    return f"{node.kind} {node.variable}. {show(node.body)}"


def close(variables: tuple[str, ...], formula: Formula) -> Formula:
    for variable in reversed(variables):
        formula = Quant("forall", variable, formula)
    return formula


def closure(equation: Eq, parameters: tuple[str, ...], old: bool) -> Formula:
    """Z has Sx=0 or E(Sx) in the step; the new Z+ has only E(Sx)."""
    x = Var("x")
    assert free(equation) <= {"x", *parameters}
    assert "x" not in parameters and len(parameters) == len(set(parameters))
    rooted = Binary("or", Eq(x, ZERO), equation)
    step = substitute(equation, {"x": succ(x)})
    if old:
        step = Binary("or", Eq(succ(x), ZERO), step)
    formula = Binary("implies", Quant("forall", "x", Binary("implies", rooted, step)),
                     Quant("forall", "x", rooted))
    return close(parameters, formula)


def module(symbol: Symbol) -> Formula:
    n, a = Var("n"), Var("a")
    parameters = tuple(Var(c) for c in symbol.parameters)
    previous = Rec(symbol, (n, a, *parameters))
    update = substitute(symbol.body, {"v": previous, "w": n,
                                     **dict(zip(symbol.parameters, parameters))})
    base = Eq(Rec(symbol, (ZERO, a, *parameters)), a)
    step = Eq(Rec(symbol, (succ(n), a, *parameters)), update)
    return close(("a", *symbol.parameters),
                 Binary("and", base, Quant("forall", "n", step)))


def unfold(call: Rec) -> Term:
    """One symbolic use of a defining recursion equation; no evaluation loop."""
    counter, initializer, *parameters = call.args
    if counter == ZERO:
        return initializer
    if isinstance(counter, App) and counter.name == "S" and len(counter.args) == 1:
        previous_counter = counter.args[0]
        previous = Rec(call.symbol, (previous_counter, initializer, *parameters))
        return substitute(call.symbol.body,
                          {"v": previous, "w": previous_counter,
                           **dict(zip(call.symbol.parameters, parameters))})
    raise ValueError("Only literal zero or successor counters may unfold.")


def run() -> dict:
    x, a, b, c = map(Var, ("x", "a", "b", "c"))
    nested_symbol = Symbol(Rec(q_symbol(2), (Var("w"), Var("v"),
                                           Var("c1"), Var("c2"))), ("c1", "c2"))
    nested_call = Rec(nested_symbol, (x, a, b, c))
    frozen_x = Rec(Symbol(Var("x"), ("x",)), (a, b, c))
    samples = [
        ("one occurrence", Eq(x, ZERO), ()),
        ("two occurrences", Eq(succ(x), Rec(Q0, (x, a))), ("a",)),
        ("padded calls", Eq(Rec(q_symbol(2), (x, a, b, c)),
                            Rec(Q0, (succ(x), a))), ("a", "b", "c")),
        ("x absent", Eq(succ(a), Rec(Q0, (b, a))), ("a", "b")),
        ("frozen x is not active", Eq(frozen_x, a), ("a", "b", "c")),
        ("nested frozen label", Eq(nested_call, x), ("a", "b", "c")),
        ("vacuous declared parameter", Eq(x, ZERO), ("unused",)),
    ]
    schema_checks = []
    for label, equation, parameters in samples:
        size, count, p = cost(equation), occurrences(equation, "x"), len(parameters)
        new, old = closure(equation, parameters, False), closure(equation, parameters, True)
        assert cost(new) == 3 * size + count + p + 12
        assert cost(old) == 3 * size + count + p + 17
        assert cost(old) - cost(new) == 5
        schema_checks.append({"sample": label, "equation": show(equation),
                              "F": size, "k": count, "p": p,
                              "Z": cost(old), "Z_plus": cost(new), "saved": 5})

    cost_checks, symbolic_checks = [], []
    n = Var("n")
    for m in (1, 2, 3, 5, 8, 16):
        symbol = q_symbol(m)
        parameters = tuple(Var(c) for c in symbol.parameters)
        call = Rec(symbol, (n, a, *parameters))
        axiom = module(symbol)
        assert (cost(call), cost(erase(call))) == (m + 4, 4)
        assert (cost(axiom), cost(erase(axiom))) == (16 + 3 * m, 16 + m)
        assert erase(axiom) == close(("a", *symbol.parameters),
                                    Binary("and", Eq(Rec(Q0, (ZERO, a)), a),
                                           Quant("forall", "n", Eq(Rec(Q0, (succ(n), a)), n))))
        cost_checks.append({"m": m, "call": cost(call), "image_call": cost(erase(call)),
                            "module": cost(axiom), "image_module": cost(erase(axiom)),
                            "vacuous_parameter_quantifiers_retained": m})
        obligations = []
        for name, counter, expected in (("base", ZERO, a), ("step", succ(n), n)):
            left, right = Rec(symbol, (counter, a, *parameters)), Rec(Q0, (counter, a))
            assert unfold(left) == unfold(right) == expected
            obligations.append({"case": name, "left": show(left), "right": show(right),
                                "both_reduce_to": show(expected)})
        symbolic_checks.append({"m": m, "obligations": obligations,
                                "step_uses_induction_hypothesis": False})

    # This descriptor contains a padded Q_2, but it is inactive metadata here.
    assert erase(nested_call).symbol is nested_symbol
    assert erase(nested_call).symbol.body == nested_symbol.body
    assert substitute(nested_call, {"w": x}).symbol is nested_symbol
    assert occurrences(Eq(frozen_x, a), "x") == 0
    assert cost(nested_call) == 11  # Includes all six nodes of its frozen body.

    terms = [x, succ(x), Rec(q_symbol(1), (x, a, succ(b))), nested_call,
             Rec(q_symbol(2), (Rec(q_symbol(1), (x, a, b)), a, b, c))]
    formulas = [row[1] for row in samples]
    formulas += [closure(row[1], row[2], old) for row in samples for old in (False, True)]
    formulas += [module(q_symbol(m)) for m in (1, 2, 5)]
    examples = terms + formulas
    for node in examples:
        assert cost(erase(node)) <= cost(node)
    environments = [{"x": succ(a)}, {"a": Rec(q_symbol(1), (x, b, c))},
                    {"x": a, "a": succ(x)}, {"w": succ(x), "c1": a}]
    commutation_count = 0
    for node in examples:
        for environment in environments:
            left = erase(substitute(node, environment))
            right = substitute(erase(node), {k: erase(v) for k, v in environment.items()})
            assert alpha_key(left) == alpha_key(right)
            commutation_count += 1

    # Erasure can change the chosen fresh name: commutation is up to alpha conversion.
    tricky = Quant("forall", "y", Eq(Rec(q_symbol(1), (x, a, Var("y_0"))), Var("y")))
    left = erase(substitute(tricky, {"x": Var("y")}))
    right = substitute(erase(tricky), {"x": Var("y")})
    assert left != right and alpha_key(left) == alpha_key(right)
    captured_source = Quant("forall", "y", Eq(x, Var("y")))
    safe = substitute(captured_source, {"x": Var("y")})
    unsafe = Quant("forall", "y", Eq(Var("y"), Var("y")))
    assert free(safe) == {"y"} and free(unsafe) == set()
    assert alpha_key(safe) != alpha_key(unsafe)
    context = (Eq(Var("y"), ZERO),)
    assert any("y" in free(assumption) for assumption in context)
    assert all("z" not in free(assumption) for assumption in context)

    boolean_checks = []
    for p in (0, 1):
        for q in (0, 1):
            case = lambda test, at_zero, otherwise: at_zero if test == 0 else otherwise
            values = {"and": case(p, q, 1), "or": case(p, 0, q),
                      "implies": case(p, q, 0)}
            expected = {"and": int(not (p == 0 and q == 0)),
                        "or": int(not (p == 0 or q == 0)),
                        "implies": int(not (p != 0 or q == 0))}
            assert values == expected
            boolean_checks.append({"p": p, "q": q, **values})

    return {
        "status": "passed",
        "scope": "Finite exact syntax checks and symbolic defining-equation obligations; "
                 "not a proof-assistant formalization or a proof by numerical testing.",
        "cost_convention": "One per variable, constant, application, equality, connective, "
                           "falsity, and individual quantifier; every recursor call also "
                           "pays its entire recursively frozen descriptor.",
        "schema_definitions": {
            "P(x)": "x=0 or E(x)",
            "Z": "forall parameters. (forall x. (P(x) implies "
                 "(Sx=0 or E(Sx)))) implies forall x. P(x)",
            "Z_plus": "forall parameters. (forall x. (P(x) implies E(Sx))) "
                      "implies forall x. P(x)",
        },
        "closure_schema_checks": schema_checks,
        "padded_counter_projection_costs": cost_checks,
        "symbolic_equation_induction_obligations": symbolic_checks,
        "frozen_label_checks": {"labels_preserved": True, "active_x_count_in_label_only": 0,
                                "nested_call_cost": cost(nested_call)},
        "homomorphic_checks": {"nonincrease_examples": len(examples),
                               "substitution_commutation_cases": commutation_count,
                               "fresh_name_case_left": show(left),
                               "fresh_name_case_right": show(right),
                               "fresh_name_case_alpha_equivalent": True},
        "negative_checks": {"capture_rejected": True, "safe_substitution": show(safe),
                            "captured_substitution": show(unsafe),
                            "generalization_of_y_from_context_y_eq_0_rejected": True,
                            "fresh_z_eigenvariable_allowed": True},
        "boolean_connective_checks_zero_means_true": boolean_checks,
        "limits": "The report proves induction, equality reflection, source-family retention, "
                  "and bi-interpretability. These finite diagnostics do not establish them.",
    }


if __name__ == "__main__":
    results = run()
    destination = Path(__file__).with_name("verification.json")
    destination.write_text(json.dumps(results, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print("PASS: closure costs, frozen descriptors, symbolic Q_m obligations, "
          "homomorphic erasure, substitution, binding negative checks, Boolean tables.")
    print(f"Results: {destination.name}")
