"""Independent grammar, binding, and certificate-boundary audit.

Run with Python 3.11+:
  python audit.py --checker ../checker.py --output independent_audit.json

The expected syntax and substitutions below use a separate named-variable
representation. They do not call the checker's inference routine, substitution
routine, or constructor-scope table to manufacture expected answers. The
checker is imported only after the specification and test inputs are defined.
Finite tests provide regression evidence; they are not a formal soundness proof.
"""

import argparse
from collections import Counter
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile

Z = -1
T = ['=', Z, Z]
D = ['=', Z, ['s', Z]]
NAMES = itertools.count()
REJECTION = (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError)


def well_formed(a, formula):
    if type(a) is int:
        return not formula and a >= -1
    if type(a) is not list or not a or type(a[0]) is not str:
        return False
    tag = a[0]
    if formula:
        if tag == '=' and len(a) == 3:
            return well_formed(a[1], False) and well_formed(a[2], False)
        if tag == 'pi' and len(a) == 3:
            return well_formed(a[1], True) and well_formed(a[2], True)
        return tag == 'ex' and len(a) == 2 and well_formed(a[1], True)
    if tag == 's' and len(a) == 2:
        return well_formed(a[1], False)
    return tag == 'r' and len(a) == 4 and all(well_formed(x, False) for x in a[1:])


def name(a, bound=()):
    """Translate indices to distinct bound names and free parameter names."""
    if type(a) is int:
        if a == Z:
            return ('zero',)
        if a < len(bound):
            return ('bound', bound[a])
        return ('free', a - len(bound))
    tag = a[0]
    if tag == 'r':
        u, v = ('local', next(NAMES)), ('local', next(NAMES))
        return ('rec', name(a[1], bound), name(a[2], bound), u, v,
                name(a[3], (u, v, *bound)))
    if tag == 'pi':
        x = ('local', next(NAMES))
        return ('forall_imp', x, name(a[1], (x, *bound)), name(a[2], (x, *bound)))
    if tag == 'ex':
        x = ('local', next(NAMES))
        return ('exists', x, name(a[1], (x, *bound)))
    return (tag, *(name(x, bound) for x in a[1:]))


class DeletedParameter(ValueError):
    pass


def replace_names(a, replacements, offset):
    """Simultaneous substitution acts only on free names, never on binders."""
    tag = a[0]
    if tag == 'free':
        i = a[1]
        if i < len(replacements):
            if replacements[i] is None:
                raise DeletedParameter(i)
            return replacements[i]
        return ('free', i + offset)
    if tag in ('zero', 'bound'):
        return a
    if tag == 'rec':
        return ('rec', replace_names(a[1], replacements, offset),
                replace_names(a[2], replacements, offset), a[3], a[4],
                replace_names(a[5], replacements, offset))
    if tag == 'forall_imp':
        return ('forall_imp', a[1], replace_names(a[2], replacements, offset),
                replace_names(a[3], replacements, offset))
    if tag == 'exists':
        return ('exists', a[1], replace_names(a[2], replacements, offset))
    return (tag, *(replace_names(x, replacements, offset) for x in a[1:]))


def index(a, bound=()):
    tag = a[0]
    if tag == 'zero':
        return Z
    if tag == 'free':
        assert a[1] >= 0
        return a[1] + len(bound)
    if tag == 'bound':
        return bound.index(a[1])
    if tag == 'rec':
        return ['r', index(a[1], bound), index(a[2], bound),
                index(a[5], (a[3], a[4], *bound))]
    if tag == 'forall_imp':
        return ['pi', index(a[2], (a[1], *bound)), index(a[3], (a[1], *bound))]
    if tag == 'exists':
        return ['ex', index(a[2], (a[1], *bound))]
    return [tag, *(index(x, bound) for x in a[1:])]


def oracle(a, prefix=(), offset=1, depth=0):
    """Named substitution oracle, including the optional partial-deletion case."""
    bound = tuple(('ambient', i) for i in range(depth))
    replacements = tuple(None if x is None else name(x) for x in prefix)
    return index(replace_names(name(a, bound), replacements, offset), bound)


def random_expression(rng, formula, depth):
    if not formula:
        if depth == 0 or rng.randrange(3) == 0:
            return rng.randrange(-1, 7)
        if rng.randrange(2):
            return ['s', random_expression(rng, False, depth - 1)]
        return ['r', *(random_expression(rng, False, depth - 1) for _ in range(3))]
    if depth == 0 or rng.randrange(3) == 0:
        return ['=', random_expression(rng, False, depth), random_expression(rng, False, depth)]
    if rng.randrange(2):
        return ['pi', random_expression(rng, True, depth - 1),
                random_expression(rng, True, depth - 1)]
    return ['ex', random_expression(rng, True, depth - 1)]


def syntax_samples():
    vals = [None, False, True, -2, -1, 0, 3, -1.0, 0.0, 1.0, 1.5,
            '', 's', 'ss', 'ssss', 'r', 'rrrr', '=', '===', 'pi', 'ex',
            'false', {}, {'s': 0}, {'s': 0, 'ss': 1},
            {'r': 0, 's': 1, 'ss': 2, 'sss': 3},
            {'=': 0, 's': 1, 'ss': 2}, {'pi': 0, '=': 1, 'ex': 2},
            [], ['false'], ['bogus', T], ['s'], ['s', Z], ['s', Z, Z],
            ['r'], ['r', Z, Z], ['r', Z, Z, 0], ['r', Z, Z, 0, 0],
            ['='], ['=', Z], T, ['=', Z, Z, Z],
            ['pi'], ['pi', T], ['pi', T, T], ['pi', T, T, T],
            ['ex'], ['ex', T], ['ex', T, T]]
    bad_terms = [None, True, False, -2, 0.0, [], ['s'], T, ['ex', T], {'s': 0}]
    for b in bad_terms:
        vals.extend([['s', b], ['r', Z, Z, b], ['r', ['s', Z], b, 0],
                     ['=', Z, b], ['ex', ['=', Z, b]], ['pi', T, ['=', b, Z]]])
    vals.extend([['pi', ['s', Z], T], ['ex', 0], ['=', T, Z],
                 ['r', ['s', 0], 1, ['r', 2, 3, ['s', 4]]],
                 ['pi', ['=', 0, 1], ['ex', ['=', 0, 2]]]])
    return vals


def load_checker(path):
    spec = importlib.util.spec_from_file_location('audited_ipra_checker', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def attempt(f, *args, **kwargs):
    try:
        return True, f(*args, **kwargs), None
    except REJECTION as exc:
        return False, None, type(exc).__name__


def run(path, partial=False):
    mod = load_checker(path)
    counts = Counter()
    failures = []
    proof_records = []

    def record(group, label, condition, detail=None):
        counts[group] += 1
        if not condition:
            failures.append({'group': group, 'case': label, 'detail': detail})

    def proof(label, data, expected, group='proof_rules'):
        ok, result, error = attempt(mod.check, data)
        passed = ok == expected and (not ok or result is True)
        record(group, label, passed, {'data': data, 'expected': expected, 'accepted': ok,
                                     'return': result, 'exception': error})
        proof_records.append({'case': label, 'expected': expected, 'passed': passed})

    pool = syntax_samples()
    for i, value in enumerate(pool):
        for formula in (False, True):
            expected = well_formed(value, formula)
            ok, actual, error = attempt(mod.subst, value, (0,), formula=formula)
            record('syntax', f'{i}:{formula}', ok == expected and
                   (not ok or (actual == value and well_formed(actual, formula))),
                   {'value': value, 'formula': formula, 'expected': expected,
                    'actual': actual, 'exception': error})
        if not well_formed(value, True):
            proof(f'context:{i}', [[T, value], T, T], False, 'statement_boundary')

    fixed = [(False, Z), (False, 0), (False, 5), (False, ['s', 0]),
             (False, ['r', 0, 1, ['r', 2, 3, ['s', 4]]]),
             (False, ['r', ['s', 2], 0, ['s', 1]]),
             (True, ['=', 0, 1]), (True, ['pi', ['=', 0, 1], ['=', 1, 2]]),
             (True, ['ex', ['pi', ['=', 0, 2], ['=', 1, 4]]]),
             (True, ['=', ['r', 0, 1, ['s', 2]], ['r', 2, 0, 3]])]
    rng = random.Random(20261106)
    expressions = fixed + [(bool(i % 2), random_expression(rng, bool(i % 2), 4))
                           for i in range(30)]
    environments = [((), 0), ((), 1), ((Z,), -1), ((['s', 0],), 0),
                    ((['r', 1, 0, ['s', 2]], ['s', 1]), -2)]
    if partial:
        environments.append(((None,), -1))
    for i, (formula, a) in enumerate(expressions):
        for depth in (0, 1, 3):
            for j, (prefix, offset) in enumerate(environments):
                try:
                    expected = oracle(a, prefix, offset, depth)
                    expected_ok = True
                except DeletedParameter:
                    expected, expected_ok = None, False
                ok, actual, error = attempt(mod.subst, a, [*prefix, offset], d=depth, formula=formula)
                record('named_substitution', f'{i}:{depth}:{j}', ok == expected_ok and
                       (not ok or (actual == expected and well_formed(actual, formula))),
                       {'expression': a, 'prefix': prefix, 'offset': offset, 'depth': depth,
                        'expected': expected, 'actual': actual, 'exception': error})

    proof('hypothesis', [[T], T, T], True)
    f = ['=', 0, 0]
    proof('safe_boolean_hypothesis_key', [[f], f, ['=', False, False]], True)
    proof('safe_float_hypothesis_key', [[f], f, ['=', 0.0, 0.0]], True)
    for alias in (['=', False, False], ['=', 0.0, 0.0]):
        proof('reject_alias_goal:' + repr(alias), [[f], alias, f], False, 'statement_boundary')
        proof('reject_alias_context:' + repr(alias), [[alias], f, f], False, 'statement_boundary')
    for i, a in enumerate([T, D, ['=', 0, 1], ['ex', ['=', 0, 1]]]):
        proof(f'lambda:{i}', [[], ['pi', a, a], ['lam', a, a]], True)

    witnesses = [Z, 0, ['s', 2], ['r', 1, 0, ['s', 2]]]
    matrices = [T, ['=', 0, 1], ['ex', ['=', 0, 1]],
                ['pi', ['=', 0, 2], ['=', ['r', 1, 2, 3], 2]]]
    for i, (w, b) in enumerate(zip(witnesses, matrices)):
        a = ['=', 0, 2]
        major = ['pi', a, b]
        antecedent = oracle(a, (w,), -1)
        consequent = oracle(b, (w,), -1)
        proof(f'guarded_elimination:{i}', [[major, antecedent], consequent,
              ['use', major, w, antecedent]], True)
        witness_equation = ['=', 0, oracle(w)]
        proof(f'existential_introduction:{i}', [[], ['ex', witness_equation],
              ['pack', w, witness_equation]], True)
        equation = ['=', Z, w]
        left, right = oracle(b, (Z,), -1), oracle(b, (w,), -1)
        proof(f'equality_transport:{i}', [[equation, left], right,
              ['use', equation, b, left]], True)

    major = ['ex', ['=', 0, 0]]
    for i, a in enumerate(matrices):
        proof(f'existential_elimination:{i}', [[major, a], a,
              ['use', major, a, oracle(a)]], True)
    escape_matrices = [['=', 0, Z], ['ex', ['=', 0, 1]],
                       ['pi', T, ['=', 1, 2]], ['=', ['r', Z, Z, 2], Z]]
    for i, body in enumerate(escape_matrices):
        major = ['ex', body]
        proof(f'existential_escape:{i}', [[major], body,
              ['use', major, body, body]], False, 'eigenvariables')
    free_eq = ['=', 0, Z]
    proof('universal_escape', [[free_eq], ['pi', T, free_eq],
          ['lam', T, free_eq]], False, 'eigenvariables')
    proof('wrong_existential_minor_arity', [[['ex', T], T], T,
          ['use', ['ex', T], T]], False, 'certificate_arity')

    invalid_terms = [None, False, True, -2, -1.0, 0.0, [], ['s'], T,
                     ['ex', T], {'s': 0}, ['s', False], ['r', Z, Z, T]]
    universal = ['pi', T, T]
    for i, bad in enumerate(invalid_terms):
        proof(f'unused_universal_witness:{i}', [[universal, T], T,
              ['use', universal, bad, T]], False, 'unused_annotations')
        proof(f'unused_existential_witness:{i}', [[T], ['ex', T],
              ['pack', bad, T]], False, 'unused_annotations')
        # The malformed recursor appears only as an intermediate certificate.
        # Constant equality transport would hide it if whole-r validation failed.
        malformed = [ ['r', Z, Z, bad], ['r', Z, bad, 0],
                      ['r', ['s', Z], bad, Z], ['r', ['s', bad], Z, Z] ]
        for j, r in enumerate(malformed):
            proof(f'hidden_bad_rec:{i}:{j}', [[T], T, ['use', r, T, T]],
                  False, 'recursor_validation')
    for i, n in enumerate([-1.0, 0, False, True, 0.0, ['r', Z, Z, 0], ['s'], ['s', Z, Z]]):
        r = ['r', n, Z, Z]
        proof(f'bad_head_rec:{i}', [[T], T, ['use', r, T, T]], False, 'recursor_validation')

    bodies = [Z, 0, 1, 2, ['s', 0], ['r', 1, 0, ['s', 2]]]
    for i, h in enumerate(bodies):
        r0 = ['r', Z, ['s', 0], h]
        proof(f'recursor_zero:{i}', [[], ['=', r0, ['s', 0]], r0], True)
        n, a = ['r', 0, Z, 1], ['s', 2]
        r = ['r', ['s', n], a, h]
        rhs = oracle(h, (['r', n, a, h], n), -2)
        proof(f'recursor_successor:{i}', [[], ['=', r, rhs], r], True)

    numerical = [['=', 0, 0], ['=', 0, 3], ['ex', ['=', 0, 1]],
                 ['pi', ['=', 0, 1], ['=', 1, 0]],
                 ['ex', ['pi', ['=', 0, 2], ['=', 1, 4]]]]
    for i, a in enumerate(numerical):
        base = oracle(a, (Z,), 0)
        successor = oracle(a, (['s', 0],), 0)
        guard = a if a[0] == '=' else base
        step = ['pi', guard, successor]
        goal = ['pi', base, a]
        proof(f'numerical_rule:{i}', [[step], goal, ['nat', a, step]], True)
        if a != base:
            wrong = ['pi', base if a[0] == '=' else a, successor]
            proof(f'wrong_numerical_guard:{i}', [[wrong], goal, ['nat', a, wrong]],
                  False, 'induction_restriction')
        wrong = ['pi', guard, oracle(a, (Z,), 0)]
        if wrong != step:
            proof(f'wrong_successor_instance:{i}', [[wrong], goal, ['nat', a, wrong]],
                  False, 'induction_restriction')

    proof('no_closed_falsity', [[], D, D], False, 'consistency_regression')
    proof('unknown_instruction', [[T], T, ['bogus', T]], False, 'certificate_arity')
    for i, data in enumerate([None, [], [[], T], [[], T, T, T], ['', T, T], [{}, T, T]]):
        proof(f'document_shape:{i}', data, False, 'statement_boundary')

    cli_cases = [([[], ['pi', T, T], ['lam', T, T]], True),
                 ([[T], T, ['use', ['r', Z, Z, None], T, T]], False),
                 ([[['ex', free_eq]], free_eq,
                   ['use', ['ex', free_eq], free_eq, free_eq]], False)]
    with tempfile.TemporaryDirectory(prefix='ipra-independent-audit-') as temporary:
        for i, (data, expected) in enumerate(cli_cases):
            p = Path(temporary) / f'case-{i}.json'
            p.write_text(json.dumps(data), encoding='utf-8')
            for optimize in (False, True):
                command = [sys.executable, *(['-O'] if optimize else []), str(path), str(p)]
                completed = subprocess.run(command, capture_output=True, text=True, timeout=20)
                passed = ((completed.returncode == 0) == expected and
                          completed.stdout.strip() == ('ACCEPT' if expected else 'REJECT'))
                record('cli_optimized_mode', f'{i}:{optimize}', passed,
                       {'status': completed.returncode, 'stdout': completed.stdout,
                        'stderr': completed.stderr})

    return {'checker': str(path), 'checker_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'python': sys.version.split()[0], 'seed': 20261106,
            'partial_substitution_optional_checks': partial,
            'counts': dict(sorted(counts.items())), 'total': sum(counts.values()),
            'passed': sum(counts.values()) - len(failures), 'failed': len(failures),
            'failures': failures, 'certificate_cases': proof_records,
            'qualification': 'Independent finite regression evidence, not a machine-checked metatheory.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--partial', action='store_true',
                        help='also audit deletion environments; not used by the final checker rules')
    args = parser.parse_args()
    result = run(args.checker.resolve(), partial=args.partial)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in result.items() if k not in ('certificate_cases', 'failures')}, indent=2))
    if result['failures']:
        print(json.dumps(result['failures'], indent=2))
    assert result['failed'] == 0, 'Independent audit found counterexamples; see output JSON.'


if __name__ == '__main__':
    main()
