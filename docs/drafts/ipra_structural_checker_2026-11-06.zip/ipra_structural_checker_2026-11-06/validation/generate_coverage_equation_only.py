#!/usr/bin/env python3
"""Generate an equation-induction-only proof of native encoded coverage.

Usage: python3 generate_coverage_equation_only.py CHECKER.py OUTPUT.json
The generator is untrusted. It uses only the standard library and the supplied
standalone checker; the resulting certificate is independently checkable.
The expected conclusion is fixed as a literal tree, not inferred from the proof.
"""

import importlib.util
import json
import pathlib
import sys


def generate(checker):
    zero = -1

    def eq(s, t):
        return ["=", s, t]

    def succ(t):
        return ["s", t]

    def lift(t, amount=1):
        return checker.subst(t, (amount,), formula=False)

    def choose(n, a, b):
        return ["r", n, a, lift(b, 2)]

    def pred(n):
        return ["r", n, zero, 1]

    def transport(principal, template, minor):
        return ["use", principal, template, minor]

    def refl(t):
        r = ["r", zero, t, zero]
        # r=t; transport the same equation in F(w)=(w=t).
        return transport(r, eq(0, lift(t)), r)

    def symmetry(proof, s):
        # Given s=t, transport s=s in F(w)=(w=s).
        return transport(proof, eq(0, lift(s)), refl(s))

    def transitivity(first, second, s):
        # Given s=t and t=u, transport the former in F(w)=(s=w).
        return transport(second, eq(lift(s), 0), first)

    def constant_selector(n, a):
        # Equation induction on C(k,a,a)=a, with a fixed parameter.
        a_under_k = lift(a)
        matrix = eq(choose(0, a_under_k, a_under_k), a_under_k)
        step = ["lam", matrix,
                choose(succ(0), a_under_k, a_under_k)]
        base = choose(zero, a, a)
        return ["use", ["nat", matrix, step], n, base]

    def predecessor_selector(n):
        # Equation induction on C(k,0,S(p(k)))=k.
        matrix = eq(choose(0, zero, succ(pred(0))), 0)
        r = choose(succ(0), zero, succ(pred(succ(0))))
        # r=S(p(Sk)); p(Sk)=k; transport the right-hand side.
        step_eq = transport(pred(succ(0)), eq(lift(r), succ(0)), r)
        step = ["lam", matrix, step_eq]
        base = choose(zero, zero, succ(pred(zero)))
        return ["use", ["nat", matrix, step], n, base]

    # Inside the two witnessed existential introductions:
    #   y has index 0, z has index 1, and the free parameter x has index 2.
    # The context is [z=x, y=p(x)].
    x, z, y = 2, 1, 0
    left = choose(x, x, x)
    right = choose(x, zero, succ(pred(x)))
    left_eq = constant_selector(x, x)       # left=x
    right_eq = predecessor_selector(x)     # right=x
    equation = transitivity(left_eq, symmetry(right_eq, right), left)

    # Change selector x to z using the witnessed equation z=x.
    z_equals_x = eq(z, x)
    x_equals_z = symmetry(z_equals_x, z)
    selector_template = eq(choose(0, lift(x), lift(x)),
                           choose(0, zero, succ(pred(lift(x)))))
    equation = transport(x_equals_z, selector_template, equation)

    # Change predecessor p(x) to y using the witnessed equation y=p(x).
    y_equals_px = eq(y, pred(x))
    px_equals_y = symmetry(y_equals_px, y)
    witness_template = eq(choose(lift(z), lift(x), lift(x)),
                          choose(lift(z), zero, succ(0)))
    equation = transport(px_equals_y, witness_template, equation)

    proof = ["pack", 0, ["pack", pred(1), equation]]

    # Independently fixed exact expansion of
    # E z E y (C(z,x,x)=C(z,0,Sy)), with the free x at ambient index 0.
    goal = ["ex", ["ex", ["=", ["r", 1, 2, 4],
                                  ["r", 1, -1, ["s", 2]]]]]
    certificate = [[], goal, proof]

    def audit(tree):
        if type(tree) is not list:
            return 0
        count = 0
        if tree and tree[0] == "nat":
            if len(tree) != 3 or tree[1][0] != "=":
                raise AssertionError("Non-equational numerical schema used")
            count += 1
        return count + sum(audit(child) for child in tree)

    nat_count = audit(proof)
    if nat_count != 2:
        raise AssertionError("Expected exactly two equation-induction instances")
    if not checker.check(certificate):
        raise AssertionError("Standalone checker rejected generated proof")
    return certificate, nat_count


def main():
    _, checker_name, output_name = sys.argv
    checker_path = pathlib.Path(checker_name).resolve()
    spec = importlib.util.spec_from_file_location("coverage_checker", checker_path)
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    certificate, nat_count = generate(checker)
    output_path = pathlib.Path(output_name)
    output_path.write_text(json.dumps(certificate, separators=(",", ":")) + "\n",
                           encoding="utf-8")
    print(json.dumps({"status": "ACCEPT", "equation_nat_instances": nat_count,
                      "non_equation_nat_instances": 0,
                      "bytes": output_path.stat().st_size}, sort_keys=True))


if __name__ == "__main__":
    main()
