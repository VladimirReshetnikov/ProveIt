"""Replay the frozen labeled corpus through both complete checker CLIs."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent


def main():
    manifest = json.loads((HERE / "manifest.json").read_text())
    candidate = ROOT / "checker.py"
    baseline = ROOT / "comparison/baselines/sorted_canonical.py"
    tasks = []
    for row in manifest["records"]:
        path = HERE / row["file"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != row["sha256"]:
            raise ValueError("Changed frozen fixture: " + row["file"])
        for optimized in (False, True):
            tasks.append((row, path, optimized, candidate, "candidate"))
        tasks.append((row, path, False, baseline, "baseline"))

    def run(task):
        row, path, optimized, checker, kind = task
        command = [sys.executable, *(["-O"] if optimized else []), str(checker), str(path)]
        process = subprocess.run(command, capture_output=True, text=True, timeout=30)
        expected = (0, "ACCEPT\n") if row["expected"] else (1, "REJECT\n")
        return {"name": row["name"], "checker": kind, "optimized": optimized,
                "expected": row["expected"], "exit": process.returncode,
                "stdout": process.stdout, "stderr": process.stderr,
                "passed": (process.returncode, process.stdout) == expected and not process.stderr}

    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(run, tasks))
    extras = []
    valid = HERE / next(r["file"] for r in manifest["records"] if r["expected"])
    with tempfile.TemporaryDirectory(prefix="ipra-cli-") as temp:
        malformed = Path(temp) / "malformed.json"
        malformed.write_text('{"unfinished":\n')
        cases = [("missing_filename", []), ("extra_filename", [str(valid), str(valid)]),
                 ("unreadable_filename", [str(Path(temp) / "absent.json")]),
                 ("malformed_json", [str(malformed)])]
        for name, arguments in cases:
            for optimized in (False, True):
                process = subprocess.run(
                    [sys.executable, *(["-O"] if optimized else []), str(candidate), *arguments],
                    capture_output=True, text=True, timeout=30)
                extras.append({"name": name, "optimized": optimized,
                               "exit": process.returncode, "stdout": process.stdout,
                               "stderr": process.stderr,
                               "passed": (process.returncode, process.stdout) == (1, "REJECT\n")
                               and not process.stderr})
    candidate_rows = [r for r in results if r["checker"] == "candidate"]
    baseline_rows = [r for r in results if r["checker"] == "baseline"]
    report = {"status": "passed" if all(r["passed"] for r in results + extras) else "failed",
              "python": sys.version.split()[0],
              "checker_sha256": hashlib.sha256(candidate.read_bytes()).hexdigest(),
              "certificate_cases": manifest["cases"], "positive": manifest["positive"],
              "negative": manifest["negative"], "candidate_fixture_cli_invocations": len(candidate_rows),
              "candidate_boundary_cli_invocations": len(extras),
              "total_candidate_cli_invocations": len(candidate_rows) + len(extras),
              "baseline_cli_invocations": len(baseline_rows),
              "rows": results, "boundary_rows": extras}
    (ROOT / "results/cli.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k not in ("rows", "boundary_rows")}, indent=2))
    if report["status"] != "passed":
        raise SystemExit("Fixed-corpus replay failed; inspect results/cli.json.")


if __name__ == "__main__":
    main()
