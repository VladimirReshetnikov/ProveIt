"""Check the fixed coverage goal and ensure that no compound-matrix cases occur."""
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GOAL = ["ex", ["ex", ["=", ["r", 1, 2, 4], ["r", 1, -1, ["s", 2]]]]]


def main():
    path = ROOT / "examples/coverage_equation_only.json"
    data = json.loads(path.read_text())
    if data[:2] != [[], GOAL]:
        raise ValueError("Coverage statement differs from the independently fixed goal.")

    def numerical_instances(tree):
        if type(tree) is not list:
            return []
        here = []
        if tree and tree[0] == "nat":
            if len(tree) != 3 or type(tree[1]) is not list or tree[1][0] != "=":
                raise ValueError("Compound-matrix cases or malformed numerical rule found.")
            here.append(tree[1])
        for child in tree:
            here.extend(numerical_instances(child))
        return here

    matrices = numerical_instances(data[2])
    if len(matrices) != 2:
        raise ValueError("Expected exactly two equation-induction instances.")
    spec = importlib.util.spec_from_file_location("checked_coverage", ROOT / "checker.py")
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    if not checker.check(data):
        raise ValueError("Coverage proof rejected.")
    result = {"status": "ACCEPT", "file": str(path.relative_to(ROOT)),
              "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
              "expected_goal": GOAL, "equation_nat_instances": len(matrices),
              "non_equation_nat_instances": 0, "induction_matrices": matrices}
    (ROOT / "results/coverage.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k not in ("expected_goal", "induction_matrices")}, indent=2))


if __name__ == "__main__":
    main()
