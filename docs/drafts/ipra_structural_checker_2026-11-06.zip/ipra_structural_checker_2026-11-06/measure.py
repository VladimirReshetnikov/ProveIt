"""Recompute complete-program size measurements from the supplied exact files."""
import ast
import hashlib
import io
import json
from pathlib import Path
import sys
import tokenize

ROOT = Path(__file__).resolve().parent


def measure(path):
    raw = path.read_bytes()
    source = raw.decode("utf-8")
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                doc = node.body.pop(0)
                spans.append(((doc.lineno, doc.col_offset), (doc.end_lineno, doc.end_col_offset)))
    excluded = {tokenize.COMMENT, tokenize.ENCODING, tokenize.NL, tokenize.NEWLINE,
                tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
    original_tokens = [t for t in tokenize.generate_tokens(io.StringIO(source).readline)
                       if t.type not in excluded
                       and not any(lo <= t.start and t.end <= hi for lo, hi in spans)]
    normalized = ast.unparse(tree) + "\n"
    normalized_tokens = [t for t in tokenize.generate_tokens(io.StringIO(normalized).readline)
                         if t.type not in excluded]
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(a.name for a in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.append(node.module)
    return {"path": str(path.relative_to(ROOT)), "raw_bytes": len(raw),
            "ast_nodes": len(list(ast.walk(tree))), "source_tokens": len(original_tokens),
            "normalized_tokens": len(normalized_tokens),
            "normalized_bytes": len(normalized.encode("utf-8")),
            "sha256": hashlib.sha256(raw).hexdigest(), "imports": imports}


def main():
    sources = json.loads((ROOT / "comparison/sources.json").read_text())
    baselines = []
    for entry in sources["rows"]:
        row = measure(ROOT / entry["path"])
        if row["sha256"] != entry["sha256"]:
            raise ValueError("Changed comparison source: " + entry["path"])
        baselines.append(row)
    candidate = measure(ROOT / "checker.py")
    axes = ("ast_nodes", "source_tokens", "normalized_tokens", "normalized_bytes", "raw_bytes")
    envelope = {axis: min(row[axis] for row in baselines) for axis in axes}
    result = {
        "python": sys.version.split()[0], "commit": sources["commit"],
        "definitions": {
            "scope": "Entire standalone checker including JSON/file input and CLI; no local imports.",
            "ast_nodes": "All ast.walk nodes after removing module/function/class docstrings.",
            "source_tokens": "Actual-source tokens excluding whitespace, comments and docstrings.",
            "normalized_tokens": "Significant tokens of ast.unparse of that stripped tree.",
            "normalized_bytes": "UTF-8 size of ast.unparse of that tree plus one newline.",
            "raw_bytes": "Complete source bytes, including documentation.",
        },
        "candidate": candidate, "baselines": baselines, "coordinatewise_envelope": envelope,
        "strictly_below_envelope": {axis: candidate[axis] < envelope[axis] for axis in axes},
        "qualification": "A measured finite-source improvement, not an absolute minimality theorem.",
    }
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results/metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"candidate": candidate, "envelope": envelope,
                      "strictly_below": result["strictly_below_envelope"]}, indent=2))
    if not all(result["strictly_below_envelope"].values()):
        raise SystemExit("The claimed strict envelope comparison no longer holds.")


if __name__ == "__main__":
    main()
