A SMALLER COMPLETE PRESENTATION OF iPRA
6 November 2026

Start with report.pdf. Its editable LaTeX source is report.tex.

RESULT

The complete standalone checker has 720 executable AST nodes,
678 significant source tokens, 676 normalized tokens, 2,176 normalized
bytes, and 2,487 raw bytes. It is below the inspected coordinatewise
envelope of all six current ProveIt proposals, including the strongest
optional canonical core and its smaller-byte matched control:
750 / 703 / 701 / 2,265 / 2,574 respectively.

Comparison is pinned to ProveIt commit
473749742630b5a7779e7c3a36cd23ebd9cb53b5.

This is a measured improvement over a finite set of complete programs,
not an absolute minimality theorem. The arithmetic and logical basis is
inherited from the supplied drafts, with full attribution in the report.
The further reduction uses structural computation patterns, shared
elimination data, and exact command-line unpacking. The canonical input
language and accepted-sequent boundary match the sorted baseline.

MATHEMATICAL CONTENT

The paper specifies every native logical rule, computation schema,
numerical rule, syntax requirement, and freshness condition. It derives
all ordinary intuitionistic connectives, equality laws, primitive
recursive operations, and quantifier-free induction. Its ordinary
realization T_cov explicitly includes numerical coverage and the
falsity bridge. T_cov and full first-order iPRA with quantifier-free
induction are bi-interpretable on the whole number domain, with identity
isomorphisms for both composites. The native calculus faithfully
presents that ordinary theory on all sequents.

A further observation separates encoded coverage from numerical cases.
Equation induction alone proves the encoded coverage formula, but the
native formula ((x=0 -> D) -> exists y (Sy=x)) refutes general cases in
the coordinatewise model N x N. Consequently the case branch cannot be
removed by treating encoded coverage as an ordinary disjunction.

RUN

Requires Python 3.10 or newer. No third-party Python packages or network
access are needed for the checker, measurements, or validation.

  python3 checker.py examples/reflexivity.json
  python3 reproduce.py
  python3 reproduce.py --pdf

The last command requires pdfLaTeX and the packages in report.tex.
The checked environment is Python 3.12.14. The acceptance program uses
explicit require checks, so Python -O does not disable validation.

INPUT

A certificate is [context, goal, proof], encoded as finite JSON.
Zero is -1; nonnegative integer leaves are de Bruijn variable indices.
Terms: integer, ["s",t], ["r",n,a,h]. In h, indices 0 and 1 bind
the previous value and previous counter.
Formulas: ["=",s,t], ["pi",A,B], ["ex",A]. Both Pi children bind
one number; the Ex child binds one number. Falsity is the literal
formula ["=",-1,["s",-1]]. There is no separate false alias.

Proofs use formula lookup keys, ["lam",A,p], ["pack",t,p],
["use",p,a,q], recursor expressions at literal zero/successor counters,
and ["nat",P,p]. The full interpretation and rule conditions are in
Sections 2 and 7 of the report. Every context formula and claimed goal
is validated independently of proof inference.

FILES AND TRUST BOUNDARY

checker.py                   Entire trusted application-specific checker.
report.tex / report.pdf       Full theory, proofs, comparison, and limitations.
measure.py                   Whole-source metrics; not imported by checker.
comparison/baselines/        Eight unchanged measured programs.
comparison/sources.json      Original member paths, metrics, and hashes.
comparison/archive_manifest.json  Six original ZIP names and hashes.
comparison/source_inventory.json  Historical-source inventory.
validation/manifest.json     Fixed verdicts and SHA-256 for 257 certificates.
validation/fixtures/         Frozen canonical inputs.
validation/replay.py         Actual CLI replay, including -O and baseline.
validation/audit.py          Independent grammar/substitution/proof audit.
examples/                   Eighteen baseline examples and a new 909-byte
                            equation-induction-only coverage certificate.
results/                    Reproduced metrics, verdicts, and build log.
reproduce.py / build.py      Offline reproduction and PDF compilation.
MANIFEST.sha256              Packaged-file hashes, excluding itself.

The independent audit passes 1,098 checks, including 600 named-variable
substitution comparisons. The candidate passes 522 actual CLI invocations
covering 257 fixed certificates (150 accept, 107 reject) in normal and
optimized Python, plus eight CLI boundary cases. Mathematical proofs
are given in the paper. No Lean or Rocq verification is claimed.

The new coverage certificate has an independently fixed goal and exactly
two literal-equation nat instances. There are zero compound-matrix nat
instances. Its self-contained untrusted generator is
validation/generate_coverage_equation_only.py. Reproduce it with:

  python3 validation/generate_coverage_equation_only.py checker.py examples/coverage_equation_only.json
  python3 validation/verify_coverage.py

The standard Python runtime and JSON parser are shared infrastructure.
Proof generators, translations, measurement code, tests, and PDF build
code are not called by checker.py and are outside its acceptance boundary.

Reproduction rewrites results and may change manifest hashes when Python
or TeX versions differ. The original MANIFEST.sha256 describes the
delivered artifact, not an arbitrary later rebuild.
