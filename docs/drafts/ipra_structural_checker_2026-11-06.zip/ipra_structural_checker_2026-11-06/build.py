"""Compile the TeX sources into report.pdf; no network access is used."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def main():
    if not shutil.which("pdflatex"):
        raise SystemExit("pdfLaTeX is required to rebuild the PDF.")
    with tempfile.TemporaryDirectory(prefix="ipra-tex-") as temporary:
        environment = os.environ.copy()
        if shutil.which("kpsewhich"):
            lookup = subprocess.run(["kpsewhich", "pdflatex.fmt"], capture_output=True, text=True)
            if lookup.returncode:
                initialize = subprocess.run(
                    ["pdftex", "-ini", "-etex", "-interaction=nonstopmode",
                     "-jobname=pdflatex", "-progname=pdflatex",
                     "-output-directory=" + temporary, "pdflatex.ini"],
                    cwd=temporary, capture_output=True, text=True)
                if initialize.returncode:
                    print(initialize.stdout)
                    print(initialize.stderr)
                    raise SystemExit(initialize.returncode)
                environment["TEXFORMATS"] = temporary + os.pathsep + environment.get("TEXFORMATS", "")
        command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                   "-file-line-error", "-output-directory=" + temporary, "report.tex"]
        for _ in range(3):
            process = subprocess.run(command, cwd=ROOT, env=environment, capture_output=True, text=True)
            if process.returncode:
                print(process.stdout)
                print(process.stderr)
                raise SystemExit(process.returncode)
        log = (Path(temporary) / "report.log").read_text(errors="replace")
        (ROOT / "results/build.log").write_text(log)
        if "undefined references" in log.lower() or "Citation" in log and "undefined" in log:
            raise SystemExit("Unresolved TeX references; inspect results/build.log.")
        shutil.copyfile(Path(temporary) / "report.pdf", ROOT / "report.pdf")
    print("Built report.pdf")


if __name__ == "__main__":
    main()
