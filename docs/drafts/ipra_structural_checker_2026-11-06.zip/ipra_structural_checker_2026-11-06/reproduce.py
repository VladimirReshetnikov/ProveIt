"""Run the packaged size comparison and validation; optionally rebuild the PDF."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf", action="store_true")
    args = parser.parse_args()
    commands = [["measure.py"], ["validation/replay.py"],
                ["validation/audit.py", "--checker", "checker.py", "--output", "results/independent_audit.json"],
                ["validation/verify_coverage.py"]]
    if args.pdf:
        commands.append(["build.py"])
    rows = []
    for arguments in commands:
        process = subprocess.run([sys.executable, *arguments], cwd=ROOT,
                                 capture_output=True, text=True)
        rows.append({"command": ["python3", *arguments], "returncode": process.returncode})
        if process.returncode:
            print(process.stdout, end="")
            print(process.stderr, end="", file=sys.stderr)
            raise SystemExit(process.returncode)
        print("PASS: " + " ".join(arguments))
    (ROOT / "results/reproduction.json").write_text(json.dumps(
        {"python": sys.version.split()[0], "status": "passed", "commands": rows}, indent=2) + "\n")


if __name__ == "__main__":
    main()
