PRA WITH A WEAKER CONDITIONAL
Research iteration, November 2, 2026
Source snapshot: 2ba9e7a5767fee450c6611868fdf0c4d3a27754e

START HERE
  report.pdf             Complete report, proofs, comparison, and references.
  report.tex             Main LaTeX source.
  sections/*.tex         Complete included source sections.

RESULT
  W(A;U,V) := (A or U) and (A -> V)
has a seven-node expansion, versus nine for the inspected strong conditional.
Its positive and negative endpoint clauses preserve the one-occurrence
boundary construction. A size selector retains the direct term clause on
small negative zero equations.

Primary full sizes:
  native: min(2G+i+12, G+20)
  raw t!=0: min(2T+i+15, T+22)

The 0,D companion has one raw term as each schema index:
  min(2T+2i+15, T+23)
with a 17-node arithmetic seed. Its finite-set comparison against the covered
24-node seed has exactly four exceptional terms and a sharp three-node net
arithmetic saving. The new logical definition is a SEPARATE 12-node record.

All size claims use the report's stated literal syntax and compatible common
support. They do not prove an absolute shortest axiomatization under arbitrary
changes of language, logic, or coding. Full first-order bi-interpretability is
proved in writing, separately classically and intuitionistically.

REBUILD
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex

  Python 3.10+ (standard library only):
    python3 artifacts/check_and_emit.py
    python3 artifacts/check_discriminator.py

  Lean 4.19.0 (Std only; no mathlib required):
    lean artifacts/BoundaryKernels.lean

  build.sh runs the PDF and Python checks, and runs Lean when available.

ARTIFACTS
  artifacts/BoundaryKernels.lean
    Local constructive logical, induction, zero-filter, and scan kernels.
    Nine principal printed theorem dependencies have no axioms.
    It does not formalize the complete generated arithmetic theory or the
    full first-order interpretation metatheorem.

  artifacts/check_and_emit.py
    Actual syntax ASTs, fully charged frozen descriptors, capture-safe
    substitution, selected axiom emitter, profile checks, Boolean truth
    table minimization, and a two-world Kripke counterexample.
    Run --help for the JSON input format and CLI.
    --exact-bit-support explicitly enables the optional supported chi
    normalization; it is not silently added to the bare arithmetic theory.

  artifacts/check_results.json
  artifacts/examples.json
  artifacts/lean_verification.txt
    Recorded verification and example output.

  artifacts/check_discriminator.py
  artifacts/discriminator_results.json
  artifacts/discriminator_examples.json
    Companion syntax counts and exhaustive enumeration of the four small
    exceptions to pointwise covered-module dominance.

PROVENANCE
  provenance/source_manifest.json
    All five current and eight archived source ZIPs, immutable URLs, sizes,
    Git blob hashes, and SHA-256 hashes.

  provenance/draft_review.json
    Current-versus-archived filter and the supported comparison frontiers.

  SHA256SUMS.txt
    Integrity manifest for the delivered research files.

ATTRIBUTION
The initialized-recursion basis, arithmetic bootstrap, triangular pairing
method, existing native/polarity boundaries, and the direct zero-filter
clause are inherited from the reviewed ProveIt drafts and credited in the
report. The report's new claims are the weaker logical definition, its
signed use and restricted optimum, the new compatible envelopes, and the
companion finite-set comparison. No historical priority beyond the inspected
collection is claimed.
