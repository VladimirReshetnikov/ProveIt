import Std

/-!
# Local kernels for a signed primitive-recursive-arithmetic boundary

This file checks propositional boundary transformations, induction from the
boundary, the inherited direct zero-filter term clause, and a finite scan
on the standard natural numbers. It does not
formalize the generated arithmetic language, the arithmetic bootstrap,
finite-parameter coding, or either full first-order interpretation.

No `sorry`, additional axioms, or classical choice are used. The reverse
matrix transformations need decidable equality of the carrier, but do not
need decidability of the predicate. The scan needs its displayed predicate
as a decidable input; no claim about an internal universal evaluator is made.
-/

namespace PRABoundary

/-- The new primitive connective, expanded to ordinary connectives. -/
def Select (A U V : Prop) : Prop := (A ∨ U) ∧ (A → V)

/-- The previous draft's strong conditional. -/
def StrongIf (A U V : Prop) : Prop := (A ∧ U) ∨ (¬ A ∧ V)

theorem strongIf_to_select {A U V : Prop}
    (h : StrongIf A V U) : Select A U V := by
  cases h with
  | inl h => exact ⟨Or.inl h.1, fun _ => h.2⟩
  | inr h => exact ⟨Or.inr h.2, fun ha => (h.1 ha).elim⟩

theorem select_to_strongIf {A U V : Prop} [Decidable A]
    (h : Select A U V) : StrongIf A V U := by
  by_cases ha : A
  · exact Or.inl ⟨ha, h.2 ha⟩
  · exact Or.inr ⟨ha, h.1.resolve_left ha⟩

theorem select_true (A : Prop) : Select A True True :=
  ⟨Or.inr True.intro, fun _ => True.intro⟩

theorem strongIf_true_iff (A : Prop) :
    StrongIf A True True ↔ A ∨ ¬ A := by
  constructor
  · intro h
    cases h with
    | inl h => exact Or.inl h.1
    | inr h => exact Or.inr h.1
  · intro h
    cases h with
    | inl h => exact Or.inl ⟨h, True.intro⟩
    | inr h => exact Or.inr ⟨h, True.intro⟩

variable {α : Type} (zero : α) (succ : α → α)

/-- The old positive boundary at a fixed witness. -/
def PositiveNative (P : α → Prop) (n b : α) : Prop :=
  (b = zero ∨ P b) ∧ (P (succ b) → b = n)

/-- The old polarity-aware negative boundary at a fixed witness. -/
def NegativeNative (E : α → Prop) (n b : α) : Prop :=
  (E b → b = zero) ∧ (b = n ∨ E (succ b))

/-- The new positive single-occurrence boundary matrix. -/
def PositiveMatrix (P : α → Prop) (n b : α) : Prop :=
  ∀ x, Select (P x) (x = b → b = zero) (x = succ b → b = n)

/-- The new negative single-occurrence boundary matrix. -/
def NegativeMatrix (E : α → Prop) (n b : α) : Prop :=
  ∀ x, Select (E x) (x = succ b → b = n) (x = b → b = zero)

theorem positiveMatrix_to_native {P : α → Prop} {n b : α}
    (h : PositiveMatrix zero succ P n b) :
    PositiveNative zero succ P n b := by
  constructor
  · cases (h b).1 with
    | inl hp => exact Or.inr hp
    | inr hz => exact Or.inl (hz rfl)
  · intro hp
    exact (h (succ b)).2 hp rfl

theorem negativeMatrix_to_native {E : α → Prop} {n b : α}
    (h : NegativeMatrix zero succ E n b) :
    NegativeNative zero succ E n b := by
  constructor
  · intro he
    exact (h b).2 he rfl
  · cases (h (succ b)).1 with
    | inl he => exact Or.inr he
    | inr hn => exact Or.inl (hn rfl)

/-- This direction needs only decidable equality, not decidability of P. -/
theorem positiveNative_to_matrix [DecidableEq α]
    {P : α → Prop} {n b : α}
    (h : PositiveNative zero succ P n b) :
    PositiveMatrix zero succ P n b := by
  intro x
  constructor
  · by_cases hx : x = b
    · cases h.1 with
      | inl hz => exact Or.inr (fun _ => hz)
      | inr hp => exact Or.inl (hx.symm ▸ hp)
    · exact Or.inr (fun he => (hx he).elim)
  · intro hp hx
    exact h.2 (hx ▸ hp)

/-- This direction needs only decidable equality, not decidability of E. -/
theorem negativeNative_to_matrix [DecidableEq α]
    {E : α → Prop} {n b : α}
    (h : NegativeNative zero succ E n b) :
    NegativeMatrix zero succ E n b := by
  intro x
  constructor
  · by_cases hx : x = succ b
    · cases h.2 with
      | inl hn => exact Or.inr (fun _ => hn)
      | inr he => exact Or.inl (hx.symm ▸ he)
    · exact Or.inr (fun he => (hx he).elim)
  · intro he hx
    exact h.1 (hx ▸ he)

theorem positiveBoundary_induction {P : α → Prop}
    (boundary : ∀ n, ∃ b, PositiveMatrix zero succ P n b)
    (base : P zero) (step : ∀ x, P x → P (succ x)) :
    ∀ n, P n := by
  intro n
  obtain ⟨b, hb⟩ := boundary n
  have hn := positiveMatrix_to_native zero succ hb
  have hp : P b := by
    cases hn.1 with
    | inl hz => exact hz.symm ▸ base
    | inr hp => exact hp
  have hbn : b = n := hn.2 (step b hp)
  exact hbn ▸ hp

theorem negativeBoundary_induction {E : α → Prop}
    (boundary : ∀ n, ∃ b, NegativeMatrix zero succ E n b)
    (base : ¬ E zero) (step : ∀ x, ¬ E x → ¬ E (succ x)) :
    ∀ n, ¬ E n := by
  intro n
  obtain ⟨b, hb⟩ := boundary n
  have hn := negativeMatrix_to_native zero succ hb
  have he : ¬ E b := by
    intro eb
    exact base ((hn.1 eb) ▸ eb)
  have hes : ¬ E (succ b) := step b he
  have hbn : b = n := hn.2.resolve_right hes
  exact hbn ▸ he

/-- Standard-natural-number scan of the first available failed step. -/
def scan (P : Nat → Prop) [DecidablePred P] : Nat → Nat
  | 0 => 0
  | Nat.succ n =>
      if P (Nat.succ (scan P n)) then Nat.succ n else scan P n

theorem scan_spec (P : Nat → Prop) [DecidablePred P] :
    ∀ n, PositiveNative 0 Nat.succ P n (scan P n) := by
  intro n
  induction n with
  | zero => exact ⟨Or.inl rfl, fun _ => rfl⟩
  | succ n ih =>
    by_cases hs : P (Nat.succ (scan P n))
    · have eqn : scan P n = n := ih.2 hs
      have hp : P (Nat.succ n) := by simpa only [eqn] using hs
      change PositiveNative 0 Nat.succ P (Nat.succ n)
        (if P (Nat.succ (scan P n)) then Nat.succ n else scan P n)
      rw [if_pos hs]
      exact ⟨Or.inr hp, fun _ => rfl⟩
    · change PositiveNative 0 Nat.succ P (Nat.succ n)
        (if P (Nat.succ (scan P n)) then Nat.succ n else scan P n)
      rw [if_neg hs]
      exact ⟨ih.1, fun hp => (hs hp).elim⟩

theorem positiveBoundary_nat (P : Nat → Prop) [DecidablePred P] :
    ∀ n, ∃ b, PositiveMatrix 0 Nat.succ P n b := by
  intro n
  exact ⟨scan P n, positiveNative_to_matrix 0 Nat.succ (scan_spec P n)⟩

theorem negativeBoundary_nat (E : Nat → Prop) [DecidablePred E] :
    ∀ n, ∃ b, NegativeMatrix 0 Nat.succ E n b := by
  intro n
  let P : Nat → Prop := fun x => ¬ E x
  let b := scan P n
  have hp : PositiveNative 0 Nat.succ P n b := scan_spec P n
  have hn : NegativeNative 0 Nat.succ E n b := by
    constructor
    · intro he
      cases hp.1 with
      | inl hz => exact hz
      | inr hne => exact (hne he).elim
    · by_cases hs : E (Nat.succ b)
      · exact Or.inr hs
      · exact Or.inl (hp.2 hs)
  exact ⟨b, negativeNative_to_matrix 0 Nat.succ hn⟩


/-- An inherited direct term boundary, indexed by a nonzero test. -/
def ZeroDirect (Z : α → α → α) (t : α → α) (n b : α) : Prop :=
  Z (t b) b = zero ∧ (t (succ b) = zero ∨ b = n)

/-- Only Z(0,b)=b is needed for forward induction; no coverage or bits. -/
theorem zeroDirectBoundary_induction (Z : α → α → α)
    (zero_left : ∀ b, Z zero b = b) {t : α → α}
    (boundary : ∀ n, ∃ b, ZeroDirect zero succ Z t n b)
    (base : t zero ≠ zero)
    (step : ∀ x, t x ≠ zero → t (succ x) ≠ zero) :
    ∀ n, t n ≠ zero := by
  intro n
  obtain ⟨b, hb⟩ := boundary n
  have htb : t b ≠ zero := by
    intro ht
    have hb0 : b = zero := by
      simpa only [ht, zero_left] using hb.1
    exact base (hb0 ▸ ht)
  have hts : t (succ b) ≠ zero := step b htb
  have hbn : b = n := hb.2.resolve_left hts
  exact hbn ▸ htb

/-- Coverage and the successor equation supply the nonzero branch law. -/
theorem zero_else_of_coverage (Z : α → α → α)
    (coverage : ∀ v, v = zero ∨ ∃ u, v = succ u)
    (zero_succ : ∀ u b, Z (succ u) b = zero) :
    ∀ v b, v ≠ zero → Z v b = zero := by
  intro v b hv
  cases coverage v with
  | inl hz => exact (hv hz).elim
  | inr hs =>
    obtain ⟨u, hu⟩ := hs
    exact hu.symm ▸ zero_succ u b

/-- The reverse term-boundary proof, with its precise extra hypotheses. -/
theorem positiveNative_to_zeroDirect [DecidableEq α]
    (Z : α → α → α)
    (zero_left : ∀ b, Z zero b = b)
    (zero_else : ∀ v b, v ≠ zero → Z v b = zero)
    {t : α → α} {n b : α}
    (h : PositiveNative zero succ (fun x => t x ≠ zero) n b) :
    ZeroDirect zero succ Z t n b := by
  constructor
  · by_cases ht : t b = zero
    · have hb0 : b = zero := by
        cases h.1 with
        | inl hz => exact hz
        | inr hn => exact (hn ht).elim
      simpa only [ht, zero_left] using hb0
    · exact zero_else (t b) b ht
  · by_cases ht : t (succ b) = zero
    · exact Or.inl ht
    · exact Or.inr (h.2 ht)

/-- Standard arithmetic interpretation of the generated recursor R_0. -/
def natZ (v b : Nat) : Nat := if v = 0 then b else 0

theorem natZ_zero (b : Nat) : natZ 0 b = b := rfl

theorem natZ_else (v b : Nat) (hv : v ≠ 0) : natZ v b = 0 := by
  exact if_neg hv

theorem zeroDirectBoundary_nat (t : Nat → Nat) :
    ∀ n, ∃ b, ZeroDirect 0 Nat.succ natZ t n b := by
  intro n
  let P : Nat → Prop := fun x => t x ≠ 0
  exact ⟨scan P n,
    positiveNative_to_zeroDirect 0 Nat.succ natZ natZ_zero natZ_else
      (scan_spec P n)⟩

#print axioms positiveBoundary_induction
#print axioms negativeBoundary_induction
#print axioms scan_spec
#print axioms positiveBoundary_nat
#print axioms negativeBoundary_nat
#print axioms zeroDirectBoundary_induction
#print axioms zero_else_of_coverage
#print axioms positiveNative_to_zeroDirect
#print axioms zeroDirectBoundary_nat

end PRABoundary
