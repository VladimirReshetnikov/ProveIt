#!/usr/bin/env python3
"""Check the 0,D term-only companion's literal syntax and finite exceptions.

Python 3.10+, standard library only. Run beside check_and_emit.py:

    python3 check_discriminator.py

The script constructs the actual formulas with S(u) fully expanded as D(u,u),
counts every frozen recursor descriptor, and exhaustively enumerates every
literal term of full size <=4 over active slots x,a. Recursor descriptors have
only slots v,w. It checks the four exceptional raw tails and the sharp finite
set ledger. It does NOT prove PRA adequacy, induction, or bi-interpretability;
those are the report's mathematical theorems.

The arithmetic batch ledger treats W as a common primitive logical connective.
The result explicitly reports what happens if W's 12-node definition record
is instead charged only to the new presentation.
"""
from __future__ import annotations

from functools import lru_cache
import json
from pathlib import Path

from check_and_emit import (
    Node, binary, eq, expand_weak, free_vars, full_size, neg,
    occurrences, quantified, rec, substitute, to_json, var, weak, zero,
)


def discr(a: Node, b: Node) -> Node:
    return binary("D", a, b)


def succ_d(a: Node) -> Node:
    """A textual abbreviation, never an extra unary application node."""
    return discr(a, a)


def zcall(counter: Node, seed: Node) -> Node:
    return rec(zero(), counter, seed)


def readable(t: Node) -> str:
    if t.op == "var":
        return t.name
    if t.op in {"0", "false"}:
        return t.op
    if t.op == "D":
        return f"D({readable(t.children[0])},{readable(t.children[1])})"
    if t.op == "R":
        assert t.descriptor is not None
        return (f"R_{{{readable(t.descriptor)}}}"
                f"({readable(t.children[0])},{readable(t.children[1])})")
    if t.op in {"forall", "exists"}:
        return f"{t.op} {t.name}. {readable(t.children[0])}"
    if t.op == "W":
        return "W(" + ", ".join(readable(x) for x in t.children) + ")"
    signs = {"=": "=", "and": "&", "or": "|", "implies": "->"}
    return f"({readable(t.children[0])} {signs[t.op]} {readable(t.children[1])})"


@lru_cache(maxsize=None)
def terms_of_size(size: int, slots: tuple[str, ...]) -> tuple[Node, ...]:
    """All finite literal description trees at a prescribed full size.

    A D application costs 1 plus its two argument trees. An R application costs
    1 plus its frozen body plus its two active argument trees. Hence every
    recursive enumeration call has a strictly smaller size and a finite
    dependency rank. Slots of an R body are always v,w, independently of slots
    available in the active arguments.
    """
    if size <= 0:
        return ()
    if size == 1:
        return (zero(),) + tuple(var(s) for s in slots)
    found: set[Node] = set()
    for left_size in range(1, size - 1):
        right_size = size - 1 - left_size
        for left in terms_of_size(left_size, slots):
            for right in terms_of_size(right_size, slots):
                found.add(discr(left, right))
    for body_size in range(1, size - 2):
        for left_size in range(1, size - body_size - 1):
            right_size = size - 1 - body_size - left_size
            if right_size < 1:
                continue
            for body in terms_of_size(body_size, ("v", "w")):
                for left in terms_of_size(left_size, slots):
                    for right in terms_of_size(right_size, slots):
                        found.add(rec(body, left, right))
    return tuple(sorted(found, key=readable))


def direct_clause(t: Node) -> Node:
    b, n = var("b"), var("n")
    at_b = substitute(t, "x", b)
    at_sb = substitute(t, "x", succ_d(b))
    matrix = binary("and", eq(zcall(at_b, b), zero()),
                    binary("or", eq(at_sb, zero()), eq(b, n)))
    return quantified([("forall", "a"), ("forall", "n"), ("exists", "b")], matrix)


def weak_clause(t: Node) -> Node:
    x, b, n = var("x"), var("b"), var("n")
    at_successor = binary("implies", eq(x, succ_d(b)), eq(b, n))
    at_boundary = binary("implies", eq(x, b), eq(b, zero()))
    matrix = weak(eq(t, zero()), at_successor, at_boundary)
    return quantified([("forall", "a"), ("forall", "n"),
                       ("exists", "b"), ("forall", "x")], matrix)


def inspect(t: Node) -> dict:
    assert free_vars(t) <= {"x", "a"}
    size, count_x = full_size(t), occurrences(t, "x")
    td, tw = direct_clause(t), weak_clause(t)
    td_size, tw_size = full_size(td), full_size(tw)
    assert td_size == 2 * size + 2 * count_x + 15
    assert tw_size == size + 23
    assert full_size(expand_weak(tw)) == 2 * size + 27
    selected = min(td_size, tw_size)
    covered = 2 * size + 18
    assert selected - covered == min(2 * count_x - 3, 5 - size)
    assert selected <= 2 * size + 22  # current shared successor
    assert selected <= size + 30     # current compact D table
    assert selected <= size + 34     # current no-prelude D table
    return {
        "term": readable(t), "full_size": size, "active_x_occurrences": count_x,
        "direct_nodes": td_size, "weak_nodes": tw_size,
        "selected": "TD" if td_size <= tw_size else "TW",
        "selected_nodes": selected, "covered_nodes": covered,
        "excess_over_covered": selected - covered,
    }


def main() -> None:
    x, a, v, w = var("x"), var("a"), var("v"), var("w")
    seed_n = quantified([("exists", "u")], neg(eq(var("u"), zero())))
    seed_off = quantified([("forall", "x"), ("forall", "y")],
                          binary("or", eq(x, var("y")),
                                 eq(discr(x, var("y")), zero())))
    assert (full_size(seed_n), full_size(seed_off)) == (6, 11)

    small_terms = tuple(t for size in range(1, 5)
                        for t in terms_of_size(size, ("x", "a")))
    assert len(small_terms) == len(set(small_terms)) == 39
    assert [len(terms_of_size(s, ("x", "a"))) for s in range(1, 5)] == [3, 0, 9, 27]
    rows = [inspect(t) for t in small_terms]
    exceptions = [row for row in rows if row["excess_over_covered"] > 0]
    assert {row["term"] for row in exceptions} == {
        "D(x,x)", "R_{0}(x,x)", "R_{v}(x,x)", "R_{w}(x,x)"}
    assert all(row["excess_over_covered"] == 1 for row in exceptions)

    # Nontrivial descriptors and arguments separately test complete frozen
    # body charges and active substitution. No evaluated numeric semantics
    # or guessed primitive-function sizes enter these counts.
    nested_samples = [
        rec(discr(v, w), discr(x, a), x),
        rec(rec(zero(), v, w), x, discr(a, x)),
        discr(rec(v, x, a), rec(w, a, x)),
        rec(rec(discr(v, w), v, w), rec(zero(), x, a), x),
    ]
    sample_rows = [inspect(t) for t in nested_samples]
    for t in nested_samples:
        replaced = substitute(t, "x", succ_d(var("b")))
        assert full_size(replaced) == full_size(t) + 2 * occurrences(t, "x")
        if t.op == "R":
            assert replaced.descriptor == t.descriptor

    # Numerical-profile check is a bounded sanity check, independent of the
    # report's proof and of the exact literal-term enumeration above.
    positive_profiles: set[tuple[int, int]] = set()
    for size in range(1, 251):
        for count_x in range((size + 1) // 2 + 1):
            c = min(2 * size + 2 * count_x + 15, size + 23)
            delta = c - (2 * size + 18)
            assert delta == min(2 * count_x - 3, 5 - size)
            if delta > 0:
                positive_profiles.add((size, count_x))
    assert positive_profiles == {(3, 2), (4, 2)}

    arithmetic_new = 17 + sum(row["selected_nodes"] for row in exceptions)
    arithmetic_covered = 24 + sum(row["covered_nodes"] for row in exceptions)
    assert (arithmetic_new, arithmetic_covered) == (123, 126)

    result = {
        "status": "passed",
        "scope": "Literal AST sizes and exhaustive full-size <=4 terms; not a formal arithmetic proof.",
        "fixed_seed": {"N": 6, "Off": 11, "total": 17},
        "formulas": {"TD": "2*T+2*i+15", "TW": "T+23",
                     "TW_expanded": "2*T+27", "covered": "2*T+18",
                     "selected": "min(2*T+2*i+15,T+23)",
                     "difference": "min(2*i-3,5-T)"},
        "terms_per_full_size": {str(s): len(terms_of_size(s, ("x", "a")))
                                for s in range(1, 5)},
        "total_distinct_enumerated_terms": len(rows),
        "positive_excess_exceptions": exceptions,
        "small_term_rows": rows,
        "nested_descriptor_samples": sample_rows,
        "profile_sanity_bound_T": 250,
        "profile_positive_excess_pairs": sorted(positive_profiles),
        "sharp_exception_set_ledger": {
            "new_arithmetic_seed_and_modules": arithmetic_new,
            "covered_arithmetic_seed_and_modules": arithmetic_covered,
            "arithmetic_saving": arithmetic_covered - arithmetic_new,
            "new_W_definition_record_if_charged_only_to_new": 12,
            "new_with_that_record": arithmetic_new + 12,
            "new_excess_if_record_is_unshared": arithmetic_new + 12 - arithmetic_covered,
        },
        "batch_condition": "Finite set of distinct literal terms; canonical slots x,a and v,w.",
        "logical_basis_caveat": (
            "The sharp arithmetic batch saving assumes a common primitive-W basis. "
            "Charging the whole 12-node W definition only to the new presentation "
            "can defeat dominance on a small batch; the four exceptions give 135 versus 126."),
    }
    here = Path(__file__).resolve().parent
    target = here / "discriminator_results.json"
    target.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    examples = [{"term": to_json(t), "TD": to_json(direct_clause(t)),
                 "TW": to_json(weak_clause(t)), "counts": inspect(t)}
                for t in (discr(x, x), rec(zero(), x, x), nested_samples[-1])]
    (here / "discriminator_examples.json").write_text(
        json.dumps(examples, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "passed", "enumerated_terms": len(rows),
                      "exception_terms": [r["term"] for r in exceptions],
                      "sharp_arithmetic_totals": [arithmetic_new, arithmetic_covered],
                      "results": target.name}, indent=2))


if __name__ == "__main__":
    main()
