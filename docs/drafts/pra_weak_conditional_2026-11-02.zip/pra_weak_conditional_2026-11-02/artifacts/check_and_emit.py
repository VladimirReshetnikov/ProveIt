#!/usr/bin/env python3
"""Emit and check the explicitly specified weak-conditional PRA boundaries.

Python 3.10+, standard library only. Run without arguments (or --self-test)
to write check_results.json and examples.json beside this script. Run

    python3 check_and_emit.py --input predicate.json

for a JSON predicate. The input envelope is
    {"predicate": <formula>}
and a bare formula object is also accepted. See examples.json for complete
inputs. Base formulas use =, false, and, or, implies; terms use var, 0, S, R.
An R application contains its finite frozen "body", "counter", and "seed".
Every body has only v,w as active free variables. There is no evaluator.

The explicit --exact-bit-support flag permits primitive chi from a declared
common comparison background. Only with that flag is the ONE syntactic rewrite
chi(r,s)!=0 <-> r=s is available. This is not an axiom of the primary
0,S,R theory, and no other semantic simplification is attempted.

The checks establish syntax counts, finite truth tables, a small Kripke
counterexample, and the stated arithmetic inequalities. They do not replace
the report's proofs of arithmetic adequacy or bi-interpretability.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path
import re
from typing import Any


@dataclass(frozen=True)
class Node:
    op: str
    children: tuple["Node", ...] = ()
    name: str = ""
    descriptor: "Node | None" = None


def var(name: str) -> Node:
    return Node("var", name=name)


def zero() -> Node:
    return Node("0")


def succ(t: Node) -> Node:
    return Node("S", (t,))


def rec(body: Node, counter: Node, seed: Node) -> Node:
    return Node("R", (counter, seed), descriptor=body)


def eq(s: Node, t: Node) -> Node:
    return Node("=", (s, t))


def binary(op: str, a: Node, b: Node) -> Node:
    return Node(op, (a, b))


def neg(a: Node) -> Node:
    return binary("implies", a, Node("false"))


def weak(a: Node, u: Node, v: Node) -> Node:
    return Node("W", (a, u, v))


def quantified(prefix: list[tuple[str, str]], body: Node) -> Node:
    for op, name in reversed(prefix):
        body = Node(op, (body,), name=name)
    return body


def full_size(t: Node) -> int:
    """Tree count, including the full frozen descriptor at EACH R call."""
    return (1 + sum(full_size(c) for c in t.children)
            + (full_size(t.descriptor) if t.descriptor is not None else 0))


def active_size(t: Node) -> int:
    """Same count, but omit all frozen descriptor trees."""
    return 1 + sum(active_size(c) for c in t.children)


def free_vars(t: Node) -> set[str]:
    """Active free variables only; descriptor slots are independently bound."""
    if t.op == "var":
        return {t.name}
    result = set().union(*(free_vars(c) for c in t.children))
    if t.op in {"forall", "exists"}:
        result.discard(t.name)
    return result


def occurrences(t: Node, name: str) -> int:
    if t.op == "var":
        return int(t.name == name)
    if t.op in {"forall", "exists"} and t.name == name:
        return 0
    return sum(occurrences(c, name) for c in t.children)


def all_active_names(t: Node) -> set[str]:
    names = {t.name} if t.name else set()
    for child in t.children:
        names.update(all_active_names(child))
    return names


def fresh_name(base: str, forbidden: set[str]) -> str:
    k = 1
    while f"{base}_{k}" in forbidden:
        k += 1
    return f"{base}_{k}"


def substitute(t: Node, name: str, replacement: Node) -> Node:
    """Capture-avoiding ACTIVE substitution; never enter a frozen body.

    Quantifier support makes the function safe beyond the QF emitter input.
    Alpha-renaming affects only the scope of the renamed binder.
    """
    if t.op == "var":
        return replacement if t.name == name else t
    if t.op in {"forall", "exists"}:
        if t.name == name or name not in free_vars(t.children[0]):
            return t
        binder, body = t.name, t.children[0]
        if binder in free_vars(replacement):
            forbidden = all_active_names(body) | all_active_names(replacement)
            forbidden.update({name, binder})
            renamed = fresh_name(binder, forbidden)
            body = substitute(body, binder, var(renamed))
            binder = renamed
        return Node(t.op, (substitute(body, name, replacement),), name=binder)
    return Node(t.op, tuple(substitute(c, name, replacement)
                            for c in t.children), t.name, t.descriptor)


def expand_weak(t: Node) -> Node:
    if t.op == "W":
        a, u, v = (expand_weak(c) for c in t.children)
        return binary("and", binary("or", a, u), binary("implies", a, v))
    return Node(t.op, tuple(expand_weak(c) for c in t.children),
                t.name, t.descriptor)


def to_json(t: Node) -> dict[str, Any]:
    if t.op in {"var", "atom"}:
        return {"op": t.op, "name": t.name}
    if t.op in {"0", "false"}:
        return {"op": t.op}
    if t.op == "S":
        return {"op": "S", "arg": to_json(t.children[0])}
    if t.op == "R":
        assert t.descriptor is not None
        return {"op": "R", "body": to_json(t.descriptor),
                "counter": to_json(t.children[0]), "seed": to_json(t.children[1])}
    if t.op in {"forall", "exists"}:
        return {"op": t.op, "var": t.name, "body": to_json(t.children[0])}
    if t.op == "W":
        return {"op": "W", "condition": to_json(t.children[0]),
                "left": to_json(t.children[1]), "right": to_json(t.children[2])}
    return {"op": t.op, "left": to_json(t.children[0]),
            "right": to_json(t.children[1])}


def pretty(t: Node) -> str:
    if t.op in {"var", "atom"}:
        return t.name
    if t.op in {"0", "false"}:
        return t.op
    if t.op == "S":
        return f"S({pretty(t.children[0])})"
    if t.op == "R":
        assert t.descriptor is not None
        return (f"R_{{{pretty(t.descriptor)}}}"
                f"({pretty(t.children[0])},{pretty(t.children[1])})")
    if t.op == "chi":
        return f"chi({pretty(t.children[0])},{pretty(t.children[1])})"
    if t.op in {"forall", "exists"}:
        return f"{t.op} {t.name}. {pretty(t.children[0])}"
    if t.op == "W":
        return "W(" + ", ".join(pretty(c) for c in t.children) + ")"
    symbol = {"and": "&", "or": "|", "implies": "->", "=": "="}[t.op]
    return f"({pretty(t.children[0])} {symbol} {pretty(t.children[1])})"


def require_fields(obj: Any, fields: set[str]) -> None:
    if not isinstance(obj, dict) or set(obj) != fields:
        raise ValueError(f"Expected exactly these JSON fields: {sorted(fields)}")


def read_term(obj: Any, exact_bit: bool = False, depth: int = 0) -> Node:
    if depth > 150:
        raise ValueError("Term nesting exceeds the documented limit of 150")
    if not isinstance(obj, dict):
        raise ValueError("A term must be a JSON object")
    op = obj.get("op")
    descend = lambda item: read_term(item, exact_bit, depth + 1)
    if op == "var":
        require_fields(obj, {"op", "name"})
        name = obj["name"]
        if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
            raise ValueError("Invalid variable name")
        return var(name)
    if op == "0":
        require_fields(obj, {"op"})
        return zero()
    if op == "S":
        require_fields(obj, {"op", "arg"})
        return succ(descend(obj["arg"]))
    if op == "R":
        require_fields(obj, {"op", "body", "counter", "seed"})
        body = descend(obj["body"])
        if not free_vars(body) <= {"v", "w"}:
            raise ValueError("A frozen R body may have only v,w as active free slots")
        return rec(body, descend(obj["counter"]), descend(obj["seed"]))
    if op == "chi" and exact_bit:
        require_fields(obj, {"op", "left", "right"})
        return binary("chi", descend(obj["left"]), descend(obj["right"]))
    raise ValueError(f"Term operator {op!r} is not in the declared signature")


def read_formula(obj: Any, exact_bit: bool = False, depth: int = 0) -> Node:
    if depth > 150:
        raise ValueError("Formula nesting exceeds the documented limit of 150")
    if not isinstance(obj, dict):
        raise ValueError("A formula must be a JSON object")
    op = obj.get("op")
    if op == "false":
        require_fields(obj, {"op"})
        return Node("false")
    if op == "=":
        require_fields(obj, {"op", "left", "right"})
        return eq(read_term(obj["left"], exact_bit), read_term(obj["right"], exact_bit))
    if op in {"and", "or", "implies"}:
        require_fields(obj, {"op", "left", "right"})
        return binary(op, read_formula(obj["left"], exact_bit, depth + 1),
                      read_formula(obj["right"], exact_bit, depth + 1))
    raise ValueError(f"Formula operator {op!r} is not in the base QF vocabulary")


def parse_input(obj: Any, exact_bit_support: bool = False) -> tuple[Node, bool]:
    exact_bit = exact_bit_support
    if isinstance(obj, dict) and "predicate" in obj:
        require_fields(obj, {"predicate"})
        predicate = read_formula(obj["predicate"], exact_bit)
    else:
        predicate = read_formula(obj, exact_bit)
    if not free_vars(predicate) <= {"x", "a"}:
        raise ValueError("The predicate's only permitted active free slots are x,a")
    return predicate, exact_bit


def native_boundary(e: Node, negative: bool) -> Node:
    b, n = var("b"), var("n")
    eb, esb = substitute(e, "x", b), substitute(e, "x", succ(b))
    if negative:
        matrix = binary("and", binary("implies", eb, eq(b, zero())),
                        binary("or", eq(b, n), esb))
    else:
        matrix = binary("and", binary("or", eq(b, zero()), eb),
                        binary("implies", esb, eq(b, n)))
    return quantified([("forall", "a"), ("forall", "n"), ("exists", "b")], matrix)


def weak_boundary(e: Node, negative: bool) -> Node:
    x, b, n = var("x"), var("b"), var("n")
    initial = binary("implies", eq(x, b), eq(b, zero()))
    terminal = binary("implies", eq(x, succ(b)), eq(b, n))
    u, v = (terminal, initial) if negative else (initial, terminal)
    matrix = weak(e, u, v)
    return quantified([("forall", "a"), ("forall", "n"),
                       ("exists", "b"), ("forall", "x")], matrix)


def zero_term(e: Node) -> Node | None:
    if e.op != "=":
        return None
    left, right = e.children
    if right.op == "0":
        return left
    if left.op == "0":
        return right
    return None


def zero_direct(t: Node) -> Node:
    """This clause supports NONZERO induction; never use it for t=0."""
    b, n = var("b"), var("n")
    tb, tsb = substitute(t, "x", b), substitute(t, "x", succ(b))
    z_at_b = rec(zero(), tb, b)
    matrix = binary("and", eq(z_at_b, zero()),
                    binary("or", eq(tsb, zero()), eq(b, n)))
    return quantified([("forall", "a"), ("forall", "n"), ("exists", "b")], matrix)


def candidate(kind: str, formula: Node, polarity: str, rewrite: str = "") -> dict[str, Any]:
    return {"kind": kind, "polarity": polarity, "rewrite": rewrite,
            "active_size": active_size(formula), "full_size": full_size(formula),
            "expanded_full_size": full_size(expand_weak(formula)),
            "formula_text": pretty(formula), "formula": to_json(formula)}


def emit(predicate: Node, exact_bit: bool = False) -> dict[str, Any]:
    if not free_vars(predicate) <= {"x", "a"}:
        raise ValueError("Emitter input must have active slots only x,a")
    result: dict[str, Any] = {
        "input": to_json(predicate), "input_text": pretty(predicate),
        "input_active_size": active_size(predicate),
        "input_full_size": full_size(predicate), "input_occurrences": occurrences(predicate, "x"),
        "exact_bit_support": exact_bit,
        "normalization_adapter": ("exact_bit_atomic: explicitly enabled by --exact-bit-support; literal chi(r,s)!=0 only"
                                  if exact_bit else "disabled; primary 0,S,R core"),
        "support_requirement": ("An exact primitive equality bit in the common earlier vocabulary is assumed; its support is not included in these clause counts."
                                if exact_bit else "No primitive equality bit is assumed."),
        "count_convention": "One node per syntax occurrence; frozen R body charged at every call; binder annotation is free.",
    }
    if occurrences(predicate, "x") == 0:
        result.update({"status": "omitted", "reason": "Induction conclusion equals its base premise when x is absent.",
                       "selected": None, "selected_full_size": 0, "candidates": []})
        return result
    negative = predicate.op == "implies" and predicate.children[1].op == "false"
    e = predicate.children[0] if negative else predicate
    sign = "-" if negative else "+"
    candidates = [candidate("B", native_boundary(e, negative), sign)]
    tail = zero_term(e) if negative else None
    if tail is not None:
        candidates.append(candidate("Z-direct", zero_direct(tail), "-"))
    candidates.append(candidate("W", weak_boundary(e, negative), sign))
    if exact_bit and tail is not None and tail.op == "chi":
        atom = eq(*tail.children)
        rewrite = "Declared exact-bit law: chi(r,s)!=0 iff r=s; literal syntax only."
        candidates.append(candidate("B", native_boundary(atom, False), "+", rewrite))
        candidates.append(candidate("W", weak_boundary(atom, False), "+", rewrite))
    priority = {"B": 0, "Z-direct": 1, "W": 2}
    selected = min(enumerate(candidates),
                   key=lambda pair: (pair[1]["full_size"], priority[pair[1]["kind"]], pair[0]))[1]
    result.update({"status": "emitted", "peeled_one_negation": negative,
                   "boundary_atom_full_size": full_size(e),
                   "boundary_atom_occurrences": occurrences(e, "x"),
                   "selected": selected, "selected_full_size": selected["full_size"],
                   "candidates": candidates,
                   "selection": "Least actual full tree size; B then Z-direct then W on ties; stable within kind."})
    return result


def truth_masks() -> dict[str, int]:
    return {name: sum(1 << row for row in range(8) if row & (1 << bit))
            for bit, name in enumerate(("A", "U", "V"))}


def mux_minimum() -> dict[str, Any]:
    """Exhaust all formula truth functions at each exact tree size <= 7.

    Structural induction justifies the recurrence: a non-leaf formula has
    one binary root and subtrees of sizes l,r with l+r+1=n. Keeping one
    witness per (size,truth function) loses no possible parent function.
    """
    masks = truth_masks()
    universe = 255
    target = ((masks["A"] | masks["U"])
              & ((universe ^ masks["A"]) | masks["V"]))
    dp: dict[int, dict[int, str]] = {1: {0: "false", **{v: k for k, v in masks.items()}}}
    for size in range(2, 8):
        table: dict[int, str] = {}
        for left_size in range(1, size - 1):
            right_size = size - 1 - left_size
            for left, left_text in dp.get(left_size, {}).items():
                for right, right_text in dp.get(right_size, {}).items():
                    for op, value in (("&", left & right), ("|", left | right),
                                      ("->", (universe ^ left) | right)):
                        table.setdefault(value, f"({left_text} {op} {right_text})")
        dp[size] = table
    minimum = next(size for size in range(1, 8) if target in dp[size])
    assert minimum == 7
    return {"grammar": "A,U,V,false; binary and,or,implies; tree size, no sharing",
            "row_order": "row bits 0,1,2 are A,U,V respectively",
            "target_mask": target, "minimum_size": minimum,
            "witness": dp[minimum][target],
            "functions_at_exact_size": {str(n): len(dp[n]) for n in range(1, 8)},
            "target_absent_at_sizes_1_through_6": all(target not in dp[n] for n in range(1, 7)),
            "scope": "Restricted propositional formula-tree minimum; not a minimum for arithmetic theories or proof calculi."}


def force(t: Node, world: int, valuation: dict[str, set[int]]) -> bool:
    if t.op == "atom":
        return world in valuation[t.name]
    if t.op == "false":
        return False
    if t.op == "W":
        return force(expand_weak(t), world, valuation)
    left, right = t.children
    if t.op == "and":
        return force(left, world, valuation) and force(right, world, valuation)
    if t.op == "or":
        return force(left, world, valuation) or force(right, world, valuation)
    if t.op == "implies":
        return all(not force(left, later, valuation) or force(right, later, valuation)
                   for later in range(world, 2))
    raise ValueError(f"Not a propositional Kripke formula: {t.op}")


def definition_and_kripke_checks() -> dict[str, Any]:
    a, u, v = (Node("atom", name=name) for name in ("A", "U", "V"))
    w = weak(a, u, v)
    # Same classical mux orientation: if A then V else U.
    strong = binary("or", binary("and", a, v), binary("and", neg(a), u))
    assert full_size(w) == 4 and full_size(expand_weak(w)) == 7 and full_size(strong) == 9
    valuation = {"A": {1}, "U": {0, 1}, "V": {0, 1}}
    assert force(w, 0, valuation) and not force(strong, 0, valuation)
    assert force(w, 1, valuation) and force(strong, 1, valuation)
    return {"definition_record_convention": "left tree + one rewrite node + expanded right tree",
            "weak_left_tree": 4, "weak_right_tree": 7, "weak_record": 12,
            "strong_left_tree": 4, "strong_right_tree": 9, "strong_record": 14,
            "kripke": {"frame": "0 <= 1", "forcing": {k: sorted(vv) for k, vv in valuation.items()},
                       "root_weak": True, "root_strong": False,
                       "top_weak": True, "top_strong": True,
                       "strong_orientation": "(A and V) or ((A -> false) and U)"}}


def profile_checks() -> dict[str, Any]:
    native = raw = boolean_large = 0
    for g in range(3, 121):
        for i in range(1, g + 1):
            new = min(2 * g + i + 12, g + 20)
            assert new == min(2 * g + i + 12, g + 20)  # current strong-conditional envelope
            assert new <= min(2 * g + i + 12, 2 * g + 18, g + 35)
            for small in (1, 2, 3, 4, 5, 6):
                assert new <= min(2 * g + i + 12, 2 * g + 18, g + 29 + small)
            native += 1
    for t in range(1, 121):
        for i in range(1, (t + 1) // 2 + 1):
            new = min(2 * t + i + 15, t + 22)
            old = min(2 * t + i + 15, 2 * t + 18, t + 28)
            assert new <= old
            raw += 1
            if t >= 4:
                assert new <= min(4 * t + i + 8, t + 25)
                boolean_large += 1
    return {"native_profiles_checked": native, "raw_profiles_checked": raw,
            "boolean_profiles_T_at_least_4_checked": boolean_large,
            "native_profile_range": "3<=G<=120, 1<=i<=G; includes conservative relaxations of realizable trees",
            "raw_profile_range": "1<=T<=120, 1<=i<=floor((T+1)/2); necessary binary-tree bound T>=2i-1",
            "new_native": "min(2G+i+12,G+20)",
            "current_native_conditional": "min(2G+i+12,G+20)",
            "new_raw": "min(2T+i+15,T+22)",
            "combined_current_raw": "min(2T+i+15,2T+18,T+28)",
            "current_boolean_extra": "min(4T+i+8,T+25)",
            "scope": "Finite checks of the report's algebraic inequalities; common earlier vocabulary/support, not a proof of global optimality."}


def actual_examples() -> list[tuple[str, Node, bool]]:
    x, a, z = var("x"), var("a"), zero()
    long = x
    for _ in range(15):
        long = succ(long)
    nested_body = rec(succ(var("v")), var("w"), var("v"))
    nested = rec(nested_body, x, a)
    chi = binary("chi", x, a)
    return [
        ("small_equation", eq(x, a), False),
        ("two_input_occurrences", eq(x, x), False),
        ("conjunction", binary("and", eq(x, a), eq(x, z)), False),
        ("one_literal_negation", neg(eq(x, a)), False),
        ("negative_zero_test", neg(eq(x, z)), False),
        ("negative_zero_test_reversed", neg(eq(z, x)), False),
        ("positive_zero_test_no_Z_candidate", eq(x, z), False),
        ("long_equation", eq(long, a), False),
        ("nested_frozen_descriptor", neg(eq(nested, z)), False),
        ("double_negation_peel_exactly_once", neg(neg(eq(x, a))), False),
        ("vacuous_input", eq(a, z), False),
        ("supported_exact_chi_normalization", neg(eq(chi, z)), True),
    ]


def self_test() -> tuple[dict[str, Any], dict[str, Any]]:
    x, a, b = var("x"), var("a"), var("b")
    examples = []
    for name, predicate, exact_bit in actual_examples():
        encoded = {"predicate": to_json(predicate)}
        parsed, support = parse_input(encoded, exact_bit_support=exact_bit)
        assert parsed == predicate and support == exact_bit
        result = emit(parsed, support)
        for item in result["candidates"]:
            if item["rewrite"]:
                assert exact_bit and item["full_size"] >= 0
                continue
            g, i = result["boundary_atom_full_size"], result["boundary_atom_occurrences"]
            if item["kind"] == "B":
                assert item["full_size"] == 2 * g + i + 12
            elif item["kind"] == "W":
                assert item["full_size"] == g + 20
                assert item["expanded_full_size"] == 2 * g + 22
            elif item["kind"] == "Z-direct":
                e = predicate.children[0]
                tail = zero_term(e)
                assert tail is not None
                assert item["full_size"] == 2 * full_size(tail) + occurrences(tail, "x") + 15
        examples.append({"name": name, "required_cli_flags": (["--exact-bit-support"] if exact_bit else []),
                         "input": encoded, "result": result})
    positives = examples[6]["result"]
    assert all(c["kind"] != "Z-direct" for c in positives["candidates"])
    assert examples[10]["result"]["status"] == "omitted"
    assert examples[11]["result"]["selected"]["rewrite"]

    # Check formulas built from actual trees, not only arithmetic profiles.
    terms = [zero(), x, a]
    for depth in range(1, 13):
        t = x
        for _ in range(depth):
            t = succ(t)
        terms.append(t)
    terms.extend(rec(var("v"), s, t) for s in (x, a) for t in (x, a))
    terms.extend([rec(succ(var("v")), x, a), rec(rec(var("w"), var("v"), var("w")), x, a)])
    actual_count = 0
    for left in terms:
        for right in terms:
            for predicate in (eq(left, right), neg(eq(left, right))):
                result = emit(predicate)
                if result["status"] == "emitted":
                    e = predicate.children[0] if result["peeled_one_negation"] else predicate
                    bound = min(2 * full_size(e) + occurrences(e, "x") + 12, full_size(e) + 20)
                    assert result["selected_full_size"] <= bound
                actual_count += 1

    nested_body = rec(succ(var("v")), var("w"), var("v"))
    outer = rec(nested_body, x, a)
    changed = substitute(outer, "x", succ(b))
    assert changed.descriptor is outer.descriptor
    assert full_size(changed) == full_size(outer) + 1
    assert active_size(changed) == active_size(outer) + 1
    # A general-slot test demonstrates frozen slots are not traversed even
    # when their variable name matches the requested substitution.
    v_outer = rec(nested_body, var("v"), a)
    v_changed = substitute(v_outer, "v", succ(b))
    assert v_changed.descriptor is nested_body and v_changed.children[0] == succ(b)
    frozen = {"before": pretty(outer), "after_x_to_Sb": pretty(changed),
              "before_full": full_size(outer), "after_full": full_size(changed),
              "before_active": active_size(outer), "after_active": active_size(changed),
              "nested_descriptor_unchanged": changed.descriptor == nested_body,
              "matching_frozen_slot_unchanged": v_changed.descriptor == nested_body}
    bound = Node("forall", (eq(x, var("y")),), name="y")
    safe = substitute(bound, "x", var("y"))
    assert safe.name != "y" and free_vars(safe) == {"y"}
    assert substitute(Node("forall", (eq(x, a),), name="x"), "x", succ(b)).name == "x"

    tiny = []
    for left in (x, a, zero()):
        for right in (x, a, zero()):
            if "x" not in free_vars(eq(left, right)):
                continue
            tail = binary("chi", left, right)
            result = emit(neg(eq(tail, zero())), exact_bit=True)
            i = occurrences(tail, "x")
            old = min(4 * 3 + i + 8, 3 + 25)
            assert result["selected_full_size"] == 18 + i < old
            tiny.append({"tail": pretty(tail), "T": 3, "i": i,
                         "new": result["selected_full_size"], "old_boolean_envelope": old,
                         "rewrite": result["selected"]["rewrite"]})
    # Ensure unsupported chi is rejected, rather than silently granted.
    try:
        read_term(to_json(binary("chi", x, a)), exact_bit=False)
    except ValueError:
        pass
    else:
        raise AssertionError("Undeclared exact-bit primitive was accepted")

    results = {"status": "all_checks_passed", "schema_version": 1,
               "actual_formula_trees_checked": actual_count,
               "formula_examples": [{"name": e["name"],
                                     "input_full_size": e["result"]["input_full_size"],
                                     "i": e["result"]["input_occurrences"],
                                     "selected_full_size": e["result"]["selected_full_size"],
                                     "selected_kind": (e["result"]["selected"] or {}).get("kind", "omitted")}
                                    for e in examples],
               "frozen_substitution": frozen,
               "capture_avoidance": {"before": pretty(bound), "after": pretty(safe),
                                     "free_variables_after": sorted(free_vars(safe))},
               "definition_and_kripke": definition_and_kripke_checks(),
               "mux_truth_table_dynamic_program": mux_minimum(),
               "cross_draft_profiles": profile_checks(),
               "tiny_boolean_chi_cases": tiny,
               "limitations": ["No semantic theoremhood optimizer is used.",
                               "The explicit exact-chi rewrite requires declared external exact-bit support.",
                               "Z-direct is generated only for negative zero equations.",
                               "Counts do not include a universal bit-level encoding of the generator.",
                               "Finite arithmetic tests supplement, not replace, the written general inequalities."]}
    return results, {"schema_version": 1, "examples": examples}


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--input", type=Path, help="Read one predicate JSON and emit its least-size clause")
    mode.add_argument("--self-test", action="store_true", help="Run all checks (also the default)")
    parser.add_argument("--output", type=Path, help="Optional JSON destination; input mode otherwise prints only")
    parser.add_argument("--exact-bit-support", action="store_true",
                        help="Explicitly assume an exact primitive chi in common support; allow the literal chi(r,s)!=0 to r=s adapter")
    args = parser.parse_args()
    if not __debug__:
        parser.exit(2, "error: Run without -O; verification uses checked assertions.\n")
    try:
        if args.input is not None:
            predicate, exact_bit = parse_input(json.loads(args.input.read_text(encoding="utf-8")),
                                               exact_bit_support=args.exact_bit_support)
            result = emit(predicate, exact_bit)
            if args.output is not None:
                write_json(args.output, result)
            print(json.dumps(result, indent=2, ensure_ascii=False))
        else:
            results, examples = self_test()
            directory = Path(__file__).resolve().parent
            destination = args.output or directory / "check_results.json"
            write_json(destination, results)
            write_json(directory / "examples.json", examples)
            print(json.dumps({"status": results["status"], "results": str(destination),
                              "examples": str(directory / "examples.json"),
                              "actual_formula_trees_checked": results["actual_formula_trees_checked"],
                              "mux_minimum": results["mux_truth_table_dynamic_program"]["minimum_size"]}, indent=2))
    except (ValueError, OSError, RecursionError) as error:
        parser.exit(2, f"error: {error}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
