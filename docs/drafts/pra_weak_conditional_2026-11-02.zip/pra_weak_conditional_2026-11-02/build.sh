#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 artifacts/check_and_emit.py
python3 artifacts/check_discriminator.py
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
if command -v lean >/dev/null 2>&1; then
  lean artifacts/BoundaryKernels.lean
else
  printf '%s\n' 'Lean is optional for rebuilding the PDF. The supplied kernel was checked with Lean 4.19.0.'
fi
