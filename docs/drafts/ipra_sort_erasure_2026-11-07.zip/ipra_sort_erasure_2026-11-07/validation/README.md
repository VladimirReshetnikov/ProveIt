# Focused validation for the full recursion kernel

Run with Python 3.10 or later, using only its standard library:

```sh
python3 validation/validate_boundary.py
python3 validation/validate_erasure.py
```

Both runners locate their fixtures relative to their own file. The boundary
runner also accepts `--checker /absolute/path/to/checker.py`, for running the
same checks against a renamed delivered full kernel. No test, fixture, oracle,
or measurement module is imported by either production checker.

## What passed

The primary full kernel passes 55 inherited positive certificates. Each is
run through its actual JSON/file command-line interface twice, ordinarily and
with Python's `-O` option. The boundary runner makes **166 actual CLI runs** in
total and checks exit status, stdout, and stderr. Of those, 40 are expected
rejections.

The same runner verifies **280 accepted computation equations** by an
independent numerical evaluator. It tests counter values 0 through 3, five
seeds, and fourteen updates: zero, state, counter, successor of either,
double successor of state, empty and binary zeros, successor of binary zero,
and five inner-recursion patterns that distinguish inner state, inner counter,
outer state, and outer counter. No evaluation-budget case was skipped.
The expected right sides are constructed by simultaneous substitution using
explicit variable positions, not by the kernel's two staged openings.

`validate_erasure.py` separately checks 202 inherited positives, 7,000 mutated
positive packets, and 13,000 generated mixed-shape packets against the readable
named-rule oracle. The verdicts agree in all **20,202** cases. Accepted mutated
or generated packets are counted rather than presumed invalid. This oracle's
agreement claim is for the public empty-context acceptance boundary.

These are finite implementation checks. They are not machine-checked proofs
of mathematical soundness, completeness, consistency, or bi-interpretability.

## Targeted acceptance and rejection

The CLI tests include four deliberately new positive cases:

- A numerical binary zero whose annotations include the false formula `0=S0`.
- Empty arrays used as numerical zero in the counter, seed, and right side.
- JSON null, an object, and a string at formula positions erased to truth.
- An empty formula matrix in the paired-introduction rule.

Four further positive cases exercise counter-image use only, state-image use only, both images used, and neither image used. The last two scope-sensitive cases include raw images that are not root-valid when unused.

They also include:

- False `0=S0` and an attempted false zero computation.
- A first-child introduction attack, with true irrelevant prefix cells but
  the meaningful third matrix `y=0`.
- An attempted use of a non-atomic induction hypothesis.
- A bound-coordinate escape from the iterator's dummy slots to a root term.
- An unallocated meaningful negative parameter, including in an unused
  zero-iteration update.
- A malformed four-child array inside a binary zero annotation.
- An attempt to read an `S0` annotation as the value of its numerical binary
  parent rather than zero.

Malformed JSON, trailing garbage, null/number/object top-level packets, an empty
packet, absent arguments, absent files, and a directory path are also checked.
The CPython JSON extensions `NaN`, `Infinity`, and `-Infinity` are tested at
active numerical positions and rejected. Their presence solely at an erased
formula leaf is a different case and is not claimed to be forbidden.

## Mutation controls demonstrate that the tests detect real mistakes

The runner constructs five deliberately incorrect kernel variants in memory.
Each specified attack is rejected by the correct kernel and accepted by its
corresponding mutant:

| Deliberate error | Consequence detected |
|---|---|
| Opening the counter without protecting the state slot | Accepts a closed equation evaluating to `1=0` |
| Replacing the separate counter by the previous state | Accepts a closed equation evaluating to `0=1` |
| Swapping the counter and state opening order | Accepts a closed equation evaluating to `1=0` |
| Using the first child instead of the meaningful third matrix | Accepts the false paired formula with matrix `y=0` |
| Retaining an induction hypothesis for every matrix | Accepts the forbidden non-atomic induction proof packet |

The last case is a **rule-boundary negative**, not a false-conclusion test.
Its conclusion is true, but the packet tries to use a temporary formula
assumption that the actual rule does not provide.

For that packet put `H(y)=R(y,0;v,u.u)` and `A(y)=Q_z(H(y)=0)`.
In the paired-introduction step the packet transports `A(k)` to `A(Sk)` using
the recursion equation and a derived symmetry proof. An incorrect rule makes
`A(k)` available as a temporary induction assumption. The correct rule retains
only the base formula because the matrix is a closure rather than an equation,
so the attempted hypothesis lookup fails. The packet is stored separately in
`fixtures/non_atomic_induction_attempt.json`.

## Reachable-context restriction of the oracle

The public checker always begins with an empty context. Its successful context
extensions contain arrays. A primitive introduction whose normalized matrix is
a scalar fails at `len`; elimination of a proved array major stores a unary
array. With this invariant a scalar-root goal cannot be proved: it cannot
match an array assumption, finish a computation, or finish introduction. A
successful major proof with a scalar root therefore cannot first introduce a
scalar assumption. This excludes otherwise possible Python string-slicing
branches from successful public executions.

The readable oracle explicitly rejects non-array majors. Its equivalence
claim consequently concerns complete public packets starting from the empty
context, not calls to internal `check` with arbitrary fabricated contexts.
Arbitrary non-list values nested at formula leaves are covered by erasure and
are exercised by the positive and mutation cases.

## Provenance and receipts

The two inherited fixture bundles are copied without modification from
`docs/drafts/ipra_uniform_scopes_2026-11-07.zip` at ProveIt commit
`df8beb801d9f3e3eb3a8141722953fb58e63009e`. Their own records preserve their
earlier source paths, hashes, and translations. `fixtures/provenance.json`
records the current archive's Git blob and the exact fixture hashes, plus the
oracle's source and earlier provenance.

`validation_boundary_results.json` and `validation_results.json` record the
observed counts and SHA-256 hashes of the checkers, fixtures, oracle, and
runners. The boundary receipt also contains all sixteen targeted packets, all
five mutation controls, and representative independently evaluated equations.
