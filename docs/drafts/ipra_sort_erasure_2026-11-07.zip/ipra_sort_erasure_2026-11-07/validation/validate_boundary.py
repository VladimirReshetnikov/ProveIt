"""Focused acceptance-boundary and arithmetic checks for the full kernel.

This file is outside the trusted kernel. It uses only the standard library.
Run from any directory; --checker may select the delivered full kernel.
Finite tests are implementation evidence, not a formal soundness proof.
"""
import argparse
import ast
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import json
import math
from pathlib import Path
import platform
import subprocess
import sys
import tempfile

from oracle_erasure import Oracle

HERE = Path(__file__).resolve().parent
FIXTURES = HERE / 'fixtures'


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=True, allow_nan=False).encode('ascii')


def require(condition, description):
    if not condition:
        raise AssertionError(description)


def load_definitions(source):
    """Execute the actual definitions; subprocess checks exercise the driver."""
    tree = ast.parse(source)
    body = []
    for node in tree.body:
        if isinstance(node, ast.Try):
            break
        body.append(node)
    namespace = {}
    exec(compile(ast.Module(body=body, type_ignores=[]), '<checker>', 'exec'),
         namespace)
    return namespace


def trace(namespace, packet):
    stack = deepcopy(packet)
    namespace['k'] = 0
    try:
        namespace['take'] = stack.pop
        accepted = bool(namespace['check'](stack.pop(), []))
    except Exception:
        accepted = False
    remaining = len(stack) if type(stack) is list else None
    return accepted, namespace['k'], remaining


def compare(namespace, packet, expected=None):
    actual = trace(namespace, packet)
    oracle = Oracle(2).run(packet)
    wanted = oracle['accepted'], oracle['final_k'], oracle['remaining']
    require(actual == wanted, ('named-rule oracle disagreement', actual, wanted))
    if expected is not None:
        require(actual[0] is expected, ('unexpected verdict', actual, expected))
    return actual[0]


def numeral(number):
    result = 0
    for _ in range(number):
        result = [result]
    return result


def number_value(term, environment=(), rigid=None):
    """Independent numerical denotation; no checker or substitution is used.

    The explicit environment stores nearest variable first. Numerical binary
    and empty nodes denote zero without evaluating their annotations.
    Bounds below only protect this finite test runner, never acceptance.
    """
    rigid = {} if rigid is None else rigid
    if isinstance(term, (int, float)):
        if isinstance(term, float) and not math.isfinite(term):
            raise ValueError('nonfinite numerical leaf')
        coordinate = math.floor(term)
        if coordinate < 0:
            return rigid[coordinate]
        if coordinate == 0:
            return 0
        return environment[(coordinate - 1) // 2]
    if type(term) is not list:
        raise ValueError('nonnumerical leaf')
    if len(term) in (0, 2):
        return 0
    if len(term) == 1:
        return number_value(term[0], (0,) + environment, rigid) + 1
    if len(term) == 3:
        count = number_value(term[0], (0, 0) + environment, rigid)
        state = number_value(term[1], (0, 0) + environment, rigid)
        if count > 32:
            raise OverflowError('test evaluator count bound')
        for counter in range(count):
            state = number_value(term[2], (state, counter) + environment, rigid)
            if state > 100000:
                raise OverflowError('test evaluator value bound')
        return state
    raise ValueError('numerical arity')


def simultaneous_number(term, state, counter, protected=0):
    """Open state and counter together by variable positions, not depth parity.

    Images in this focused suite are closed numerical expressions. Their
    annotations are normalized independently before insertion.
    """
    if type(term) is not list:
        if not isinstance(term, (int, float)) or not math.isfinite(term):
            raise ValueError('nonnumerical coordinate')
        coordinate = math.floor(term)
        if coordinate <= 0:
            return term
        index = (coordinate - 1) // 2
        if index < protected:
            return term
        if index == protected and state is not None:
            return simultaneous_number(state, None, None)
        if index == protected + 1 and counter is not None:
            return simultaneous_number(counter, None, None)
        raise ValueError('unbound simultaneous-substitution coordinate')
    if len(term) == 0:
        return []
    if len(term) == 1:
        return [simultaneous_number(term[0], state, counter, protected + 1)]
    if len(term) == 2:
        return [simultaneous_formula(child, state, counter, protected + 1)
                for child in term]
    if len(term) == 3:
        return [simultaneous_number(child, state, counter, protected + 2)
                for child in term]
    raise ValueError('numerical arity')


def simultaneous_formula(formula, state, counter, protected=0):
    if type(formula) is not list:
        return 0
    if len(formula) == 0:
        return []
    if len(formula) == 1:
        return [simultaneous_formula(formula[0], state, counter, protected + 1)]
    if len(formula) == 2:
        return [simultaneous_number(child, state, counter, protected)
                for child in formula]
    if len(formula) == 3:
        return [simultaneous_formula(child, state, counter, protected + 2)
                for child in formula]
    raise ValueError('formula arity')


def arithmetic_checks(namespace):
    """Every generated one-step computation is also evaluated numerically."""
    binary_zero = [[0, [0]], [None]]
    seeds = [0, [0], [[0]], [], binary_zero]
    updates = {
        'zero': 0,
        'state': 1,
        'counter': 3,
        'successor_state': [3],
        'successor_counter': [5],
        'twice_successor_state': [[5]],
        'empty_zero': [],
        'binary_zero': binary_zero,
        'successor_binary_zero': [binary_zero],
        # These inner recursors have count 2. Their seed refers to the
        # outer state at slot 2, past two dummy slots. Their update slots
        # are [inner state, inner counter, outer state, outer counter].
        'nested_state': [[[0]], 5, 1],
        'nested_counter': [[[0]], 5, 3],
        'nested_outer_state': [[[0]], 5, 5],
        'nested_outer_counter': [[[0]], 5, 7],
        'nested_successor_outer_state': [[[0]], 5, [7]],
    }
    counts = Counter()
    example_equations = []
    for count in range(4):
        for seed in seeds:
            for name, update in updates.items():
                left = [numeral(count), deepcopy(seed), deepcopy(update)]
                if count == 0:
                    right = deepcopy(seed)
                else:
                    predecessor = numeral(count - 1)
                    previous = [predecessor, deepcopy(seed), deepcopy(update)]
                    right = simultaneous_number(update, previous, predecessor)
                packet = [[], [left, right]]
                compare(namespace, packet, True)
                values = number_value(left), number_value(right)
                require(values[0] == values[1], ('false computation', name, packet, values))
                counts[name] += 1
                if count == 3 and seed == [[0]]:
                    example_equations.append({'update': name, 'packet': packet,
                                              'left_value': values[0], 'right_value': values[1]})
    return {
        'accepted_and_independently_evaluated_equations': sum(counts.values()),
        'by_update_pattern': dict(counts),
        'counter_values': [0, 1, 2, 3],
        'seed_variants': len(seeds),
        'budget_skips': 0,
        'independence': 'An ordinary environment evaluator and simultaneous two-slot substitution; neither calls production inst.',
        'examples': example_equations,
    }


def special_cases():
    binary_zero = [[0, [0]], [None]]
    return [
        {'name': 'binary_zero_annotations', 'expected': True,
         'packet': [[], [[0, binary_zero, 0], binary_zero]],
         'reason': 'A numerical binary array denotes zero even with a false equation as one formula annotation.'},
        {'name': 'empty_numerical_zero', 'expected': True,
         'packet': [[], [[[], [], 0], []]],
         'reason': 'The empty counter and empty seed denote zero.'},
        {'name': 'formula_leaf_erasure', 'expected': True,
         'packet': [0, [None, {'prefix': 17}, ['arbitrary truth']]],
         'reason': 'Formula annotations and the scalar leaf beneath a closure erase to truth.'},
        {'name': 'empty_matrix_introduction', 'expected': True,
         'packet': [0, [0, 0, []]],
         'reason': 'An empty formula matrix means truth; its temporary induction assumption is harmless.'},
        {'name': 'zero_equals_one', 'expected': False,
         'packet': [[], [0, [0]]],
         'reason': 'The false equation 0=S0 has no computation instruction.'},
        {'name': 'false_zero_computation', 'expected': False,
         'packet': [[], [[0, 0, 0], [0]]],
         'reason': 'The zero computation cannot change its seed from zero to one.'},
        {'name': 'first_child_introduction_attack', 'expected': False,
         'packet': [0, [[0, 0], [0, 0], [1, 0]]],
         'reason': 'The matrix is the third child, y=0; an irrelevant first child cannot replace it.'},
        {'name': 'non_atomic_induction_attempt', 'expected': False,
         'packet': json.loads((FIXTURES / 'non_atomic_induction_attempt.json').read_text()),
         'reason': 'This proof attempts to use an undischarged Q-formula induction hypothesis. The conclusion itself is true; this is a rule-boundary negative.'},
        {'name': 'bound_coordinate_escape', 'expected': False,
         'packet': [[], [[0, 3, 0], 3]],
         'reason': 'A seed coordinate protected by dummy binders cannot escape to the root right-hand side.'},
        {'name': 'unallocated_parameter', 'expected': False,
         'packet': [[], [[0, 0, -1], 0]],
         'reason': 'A meaningful unallocated parameter is rejected even in a zero iteration update.'},
        {'name': 'malformed_array_inside_binary_annotation', 'expected': False,
         'packet': [[], [[0, [[0, 0, 0, 0], None], 0], [[0, 0, 0, 0], None]]],
         'reason': 'An array of unsupported arity must not be caught and silently erased as a formula scalar.'},
        {'name': 'false_binary_zero_value', 'expected': False,
         'packet': [[], [[0, binary_zero, 0], [0]]],
         'reason': 'An annotation containing S0 does not make the surrounding numerical binary tree equal to one.'},
        {'name': 'counter_image_only', 'expected': True,
         'packet': [[], [[[0], 0, 3], 0]],
         'reason': 'The counter image is used; the previous-state image is unused.'},
        {'name': 'state_image_only', 'expected': True,
         'packet': [[], [[[1], 0, 1], [1, 0, 1]]],
         'reason': 'The previous-state image validates with two dummy slots although the unused counter image is not root-valid.'},
        {'name': 'neither_image_used', 'expected': True,
         'packet': [[], [[[5], 0, 0], 0]],
         'reason': 'Both raw images may be invalid when the update is constant; the counter still decodes to one under three zero slots.'},
        {'name': 'both_images_used', 'expected': True,
         'packet': [[], [[[0], 0, [7, 5, 1]], [0, [0, 0, [7, 5, 1]], 1]]],
         'reason': 'A nested update operationally uses both the counter and the previous-state images.'},
    ]


def mutation_controls(namespace, source, cases):
    case_by_name = {entry['name']: entry for entry in cases}
    computation = 't = inst(inst(r, n, 3), [n, t, r], 1)'
    controls = [
        ('counter_opening_must_protect_state', computation,
         't = inst(inst(r, n, 1), [n, t, r], 1)',
         [[], [[[0], [0], 1], 0]], True),
        ('counter_is_not_previous_state', computation,
         't = inst(r, [n, t, r], 1)',
         [[], [[[0], [0], 3], [0, [0], 3]]], True),
        ('counter_and_state_order_cannot_be_swapped', computation,
         't = inst(inst(r, [n, t, r], 3), n, 1)',
         [[], [[[0], [0], 1], 0]], True),
        ('third_child_must_be_meaningful', 'a = inst(a[2], t, 2)',
         'a = inst(a[0], t, 2)',
         case_by_name['first_child_introduction_attack']['packet'], False),
        ('induction_hypothesis_requires_atomic_matrix',
         'h = [a, inst(a, 0)][len(a) % 2:]', 'h = [a, inst(a, 0)]',
         case_by_name['non_atomic_induction_attempt']['packet'], False),
    ]
    result = []
    for name, old, new, packet, numerical in controls:
        require(source.count(old) == 1, ('missing mutation anchor', name))
        mutant = load_definitions(source.replace(old, new))
        correct = trace(namespace, packet)[0]
        incorrect = trace(mutant, packet)[0]
        require(not correct and incorrect, ('mutation control lacks power', name, correct, incorrect))
        item = {'name': name, 'correct_accepts': correct, 'mutant_accepts': incorrect,
                'packet': packet}
        if numerical:
            left, right = packet[-1]
            values = number_value(left), number_value(right)
            require(values[0] != values[1], ('control equation is not false', name, values))
            item['false_equation_values'] = values
        result.append(item)
    return result


def public_cli(checker, records, cases):
    counts = Counter()
    rejections = 0

    def run(arguments, expected, category, optimized):
        nonlocal rejections
        command = [sys.executable, *(['-O'] if optimized else []), str(checker), *arguments]
        process = subprocess.run(command, capture_output=True, text=True, timeout=15)
        actual = process.returncode, process.stdout.strip(), process.stderr
        wanted = (0, 'ACCEPT', '') if expected else (1, 'REJECT', '')
        require(actual == wanted, ('public CLI', category, optimized, actual, wanted))
        counts[category] += 1
        rejections += not expected

    with tempfile.TemporaryDirectory(prefix='ipra_boundary_') as name:
        directory = Path(name)
        file = directory / 'packet.json'
        for record in records:
            file.write_bytes(canonical(record['packet']))
            for optimized in (False, True):
                run([str(file)], True, 'inherited_positive', optimized)
        for case in cases:
            file.write_bytes(canonical(case['packet']))
            for optimized in (False, True):
                run([str(file)], case['expected'], case['name'], optimized)
        malformed = {
            'invalid_json': '{',
            'trailing_garbage': '[0] trailing',
            'null_packet': 'null',
            'number_packet': '7',
            'object_packet': '{}',
            'empty_packet': '[]',
            'active_nan': '[[], [[0, NaN, 0], 0]]',
            'active_positive_infinity': '[[], [[0, Infinity, 0], 0]]',
            'active_negative_infinity': '[[], [[0, -Infinity, 0], 0]]',
        }
        for category, text in malformed.items():
            file.write_text(text)
            for optimized in (False, True):
                run([str(file)], False, category, optimized)
        for optimized in (False, True):
            run([], False, 'missing_argument', optimized)
            run([str(directory / 'missing.json')], False, 'missing_file', optimized)
            run([str(directory)], False, 'directory_argument', optimized)
    return {'runs': sum(counts.values()), 'by_category': dict(counts),
            'expected_rejections': rejections, 'normal_and_optimized': True,
            'checked': ['exit status', 'stdout', 'stderr'],
            'parser_extension_note': 'NaN and infinities are CPython JSON extensions, tested only at active numerical positions.'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checker', type=Path, default=HERE.parent / 'checker.py')
    arguments = parser.parse_args()
    checker = arguments.checker.resolve()
    source = checker.read_text()
    namespace = load_definitions(source)
    fixture = FIXTURES / 'direct_positive_certificates.json'
    records = json.loads(fixture.read_text())['records']
    for record in records:
        require(sha256(canonical(record['packet'])).hexdigest() == record['packet_sha256'],
                ('changed inherited fixture', record['id']))
        compare(namespace, record['packet'], True)
    cases = special_cases()
    for case in cases:
        compare(namespace, case['packet'], case['expected'])
    arithmetic = arithmetic_checks(namespace)
    controls = mutation_controls(namespace, source, cases)
    cli = public_cli(checker, records, cases)
    result = {
        'status': 'PASS',
        'python': platform.python_version(),
        'checker_filename': checker.name,
        'checker_sha256': digest(checker),
        'fixture_sha256': digest(fixture),
        'oracle_sha256': digest(HERE / 'oracle_erasure.py'),
        'runner_sha256': digest(Path(__file__)),
        'inherited_full_recursion_positives': len(records),
        'targeted_cases': cases,
        'independent_computation_semantics': arithmetic,
        'mutation_controls': controls,
        'public_cli': cli,
        'scope': 'Finite reproducible implementation evidence, not a machine-checked proof of soundness, completeness, consistency, or bi-interpretability.',
    }
    (HERE / 'validation_boundary_results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'checker': checker.name,
                      'inherited_positives': len(records), 'targeted_cases': len(cases),
                      'evaluated_computations': arithmetic['accepted_and_independently_evaluated_equations'],
                      'mutation_controls': len(controls), 'cli_runs': cli['runs']}, indent=2))


if __name__ == '__main__':
    main()
