"""Independent named-rule oracle differential tests; finite evidence only."""
import ast, copy, json, random, sys
from hashlib import sha256
from pathlib import Path
from oracle_erasure import Oracle
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BASE = HERE / 'fixtures'

def load(path):
    tree=ast.parse(path.read_text());body=[]
    for n in tree.body:
        if isinstance(n,ast.Try):break
        body.append(n)
    ns={};exec(compile(ast.Module(body=body,type_ignores=[]),str(path),'exec'),ns)
    return ns

def run(ns, packet):
    packet=copy.deepcopy(packet);ns['k']=0
    try:
        ns['take']=packet.pop
        return bool(ns['check'](packet.pop(),[]))
    except Exception:
        return False

def random_tree(rng,d=3):
    atoms=[None, False, True, -9, -1,0,1,3,12,0.25,-0.25,'x',{},[]]
    if d==0 or rng.random()<.64:return copy.deepcopy(rng.choice(atoms))
    return [random_tree(rng,d-1) for _ in range(rng.randrange(5))]

def paths(t,p=()):
    out=[p]
    if type(t)==list:
        for i,c in enumerate(t):out.extend(paths(c,p+(i,)))
    return out

def replace(t,p,v):
    if not p:return v
    q=t
    for i in p[:-1]:q=q[i]
    q[p[-1]]=v
    return t

rng=random.Random(19481108)
results=[]
for filename,fixture,width in [('checker_scalar.py','positive_certificates.json',1),('checker.py','direct_positive_certificates.json',2)]:
    ns=load(ROOT/filename);oracle=Oracle(width)
    records=json.loads((BASE/fixture).read_text())['records']
    packets=[r['packet'] for r in records]
    counts={'positive':0,'mutation':0,'random':0,'accepted_mutations':0,'accepted_random':0}
    def audit(packet,kind):
        a=run(ns,packet);b=oracle.run(packet)['accepted']
        if a!=b:
            (HERE/'disagreement.json').write_text(json.dumps({'packet':packet,'kernel':a,'oracle':b,'filename':filename}))
            raise AssertionError(filename+' '+kind)
        counts[kind]+=1
        if kind=='positive' and not a:raise AssertionError('lost canonical positive')
        if kind!='positive' and a:counts['accepted_'+('mutations' if kind=='mutation' else 'random')]+=1
    for p in packets:audit(p,'positive')
    for _ in range(3500):
        p=copy.deepcopy(rng.choice(packets));p=replace(p,rng.choice(paths(p)),random_tree(rng,2));audit(p,'mutation')
    for _ in range(6500):
        p=[random_tree(rng,3) for _ in range(rng.randrange(1,10))];audit(p,'random')
    results.append({'checker':filename,'width':width,**counts})
result={'seed':19481108,'results':results,'scope':'Finite differential implementation evidence; public packets start with empty context; not a formal soundness proof.', 'sha256':{name:sha256(((ROOT if name in ('checker.py','checker_scalar.py') else HERE)/name).read_bytes()).hexdigest() for name in ['checker_scalar.py','checker.py','oracle_erasure.py','validate_erasure.py','fixtures/positive_certificates.json','fixtures/direct_positive_certificates.json']}}
(HERE/'validation_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
