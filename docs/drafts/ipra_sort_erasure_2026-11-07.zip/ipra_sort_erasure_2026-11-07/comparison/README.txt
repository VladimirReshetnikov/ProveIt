REPRODUCIBLE COMPARISON WITH THE CURRENT SIX DRAFTS

Pinned repository: VladimirReshetnikov/ProveIt
Pinned commit: df8beb801d9f3e3eb3a8141722953fb58e63009e
Measurement runtime used here: CPython 3.12.14

PRIMARY COMPARISON

manifest.json identifies every one of the 11 checker*.py files located at
the root of the six current ZIP archives in docs/drafts. All 11 original
sources are frozen byte-for-byte in current/, with SHA-256 checksums. There
are 11 different raw sources and 10 different normalized sources. Keeping
dominated proposals in the table cannot raise the coordinatewise minimum.

The unchanged inherited source_measure.py removes genuine Python
docstrings, applies ast.unparse plus a final newline, and measures:

  * significant Python tokens;
  * all nodes visited by ast.walk, including expression-context nodes;
  * normalized UTF-8 bytes.

Its SHA-256 is
f1404184bf9d39d85c4587f30e191785886c85fed0b3fe01f693191ca6f218dc.

benchmark.py calls that inherited whole-source metric without executing
any measured checker. Its historical metrics()['core'] result is ignored:
that old helper does not remove the newer top-level try/except drivers.

From the delivered report directory, run:

  python3 comparison/benchmark.py

The script automatically compares ../checker.py and ../checker_scalar.py
when they exist. To compare explicit complete sources instead:

  python3 comparison/benchmark.py --candidate /absolute/path/checker.py

Repeat --candidate for another source. JSON results, the complete current
table, and a summary table are written beside the script. --output DIR
chooses a different result directory. No source is modified.

EXACT BOUNDARIES

Delivered: every part of the complete source is counted, including
imports, global initialization, input parsing, inference and substitution,
exception handling, printed verdict, and exit status.

Common filename driver: preserve all source before the sole final
module-level try block; replace only that driver with the exact common
driver printed in measurements.json. It loads JSON from open(sys.argv[1]).

Common stdin driver: the same operation, using json.load(sys.stdin).

Kernel core: remove the sole final module-level try block and module-level
imports only; retain all global initialization and every function body.
This is a precisely delimited core measurement, not a standalone executable.
Unexpected source layouts are rejected rather than silently trimmed.

Results (tokens / all AST nodes / normalized bytes):

                              Old envelope      New full        New scalar
Delivered                     356 / 378 / 1038   354 / 374 / 1007 347 / 368 / 995
Common filename driver        356 / 378 / 1038   354 / 374 / 1007 347 / 368 / 995
Common stdin driver           350 / 372 / 1030   348 / 368 / 999  341 / 362 / 987
Core                          305 / 324 / 882    303 / 320 / 851  296 / 314 / 839

The same three old delivered minima are attained by the actual current
uniform-scopes scalar checker. These are not synthetic candidate programs.
The full-recursion subgroup's old delivered envelope is 363 / 384 / 1050;
its old core envelope is 312 / 330 / 894.

The candidate measurements refer to the exact files whose hashes appear
in measurements.json. Rerunning benchmark.py refreshes those measurements
if a candidate has changed. A change to a frozen comparator or normalizer
causes an error.

EXPANDED ARCHIVAL AUDIT

inventory.json records a fresh scan of all 497 Python member paths in the
six exact current ZIPs: 245 distinct raw sources, all parsing successfully.
This includes historical, frozen, ablation, and support directories.

A broad structural inventory finds 438 paths, representing 195 distinct
sources, with a module-level function named check. Their measured envelope
is also 356 / 378 / 1038. This structural label does not certify each old
experiment as a sound or complete checker.

To guard against a smaller complete checker with some other function name,
every Python source, regardless of its name or structure, was measured.
The 13 distinct sources below at least one current normalized coordinate
were read individually. They are build, packaging, reproduction, or
validation-driver scripts, each requiring other programs or serving an
unrelated purpose. All 13 are included in audit_exclusions/ with individual
hashes and concrete reasons in manifest.json. None contains a standalone
complete proof-checker implementation.

To rescan all historical/support contents, supply the original six ZIPs:

  python3 comparison/scan_archives.py /path/to/ProveIt/docs/drafts

Every archive must match both the pinned SHA-256 and Git blob SHA. The
script never runs archive code. It rejects duplicate member names or
unaccounted nested archives. It writes archive_rescan.json and checks that
all sources below the frontier have recorded reviews. Add --output FILE
to choose another result path. Add --extract DIR to reconstruct just the
11 frozen root sources and 13 reviewed small exclusions into DIR.

The ordinary offline benchmark does not need the original ZIPs. A full
independent historical rescan does require them; the hundreds of other
legacy files are recorded by hash and location instead of being duplicated
in this archive. Canonical URLs and complete archive hashes are in manifest.json.

LIMIT OF THE RESULT

This establishes a finite-corpus comparison under an explicit inherited
software metric. It does not establish an absolute lower bound on all
axiomatizations, programming languages, proof-checker implementations, or
mathematical theories.
