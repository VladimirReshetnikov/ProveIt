"""Reproduce complete, identical-driver, and explicitly delimited core metrics.

Only the inherited source_measure.py is imported. No measured checker source
is executed. The historical metrics()['core'] field is deliberately ignored:
that old field does not remove the modern top-level try/except driver.
"""
import argparse
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import tempfile

HERE = Path(__file__).resolve().parent
NORMAL = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
FIELDS = ('source_tokens', *NORMAL, 'raw_bytes')
COMMON_FILENAME_DRIVER = """try:
    take = json.load(open(sys.argv[1])).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
"""
COMMON_STDIN_DRIVER = COMMON_FILENAME_DRIVER.replace('open(sys.argv[1])', 'sys.stdin')
spec = importlib.util.spec_from_file_location('inherited_source_measure', HERE / 'source_measure.py')
inherited = importlib.util.module_from_spec(spec)
spec.loader.exec_module(inherited)


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def normalized_tree(raw):
    return ast.fix_missing_locations(
        inherited.StripDocstrings().visit(ast.parse(raw.decode('utf-8'))))


def source_metrics(raw, temporary):
    """Use the unchanged inherited whole-source measurement implementation."""
    path = Path(temporary) / 'measured.py'
    path.write_bytes(raw)
    result = inherited.metrics(path)
    result.pop('core')
    normalized = (ast.unparse(normalized_tree(raw)) + '\n').encode('utf-8')
    result['normalized_sha256'] = sha256(normalized)
    return result


def kernel_prefix(raw):
    """Locate the exact source boundary; reject an unrecognized CLI layout."""
    tree = normalized_tree(raw)
    starts = [i for i, node in enumerate(tree.body) if isinstance(node, ast.Try)]
    if len(starts) != 1 or starts[0] != len(tree.body) - 1:
        raise ValueError('Expected exactly one final top-level try/except driver')
    prefix = tree.body[:starts[0]]
    permitted = (ast.Import, ast.ImportFrom, ast.Assign, ast.AnnAssign,
                 ast.FunctionDef, ast.AsyncFunctionDef)
    if not all(isinstance(node, permitted) for node in prefix):
        raise ValueError('Unexpected statement before the public driver')
    return prefix


def derived_sources(raw):
    """Retain every definition and global initialization before the CLI."""
    prefix = kernel_prefix(raw)
    variants = {
        'common_filename': prefix + ast.parse(COMMON_FILENAME_DRIVER).body,
        'common_stdin': prefix + ast.parse(COMMON_STDIN_DRIVER).body,
        'kernel_core': [node for node in prefix
                        if not isinstance(node, (ast.Import, ast.ImportFrom))],
    }
    return {
        name: (ast.unparse(ast.fix_missing_locations(
            ast.Module(body=copy.deepcopy(body), type_ignores=[]))) + '\n').encode('utf-8')
        for name, body in variants.items()
    }


def measure_program(raw, temporary):
    result = {'delivered': source_metrics(raw, temporary)}
    for name, source in derived_sources(raw).items():
        result[name] = source_metrics(source, temporary)
    return result


def minimum(rows, key, fields=NORMAL):
    return {field: min(row[key][field] for row in rows) for field in fields}


def summaries(rows):
    variants = ('delivered', 'common_filename', 'common_stdin', 'kernel_core')
    return {key: minimum(rows, key) for key in variants}


def escaped(text):
    return text.replace('_', r'\_').replace('&', r'\&')


def triple(metrics):
    return ' & '.join(str(metrics[key]) for key in NORMAL)


def write_tables(result, output):
    rows = result['programs']
    current = [r'\begin{center}', r'\small', r'\begin{tabular}{@{}lrrr@{}}',
               r'\toprule', r'Current complete program & Tokens & AST nodes & Bytes\\',
               r'\midrule']
    current += [escaped(row['label']) + ' & ' + triple(row['delivered']) + r'\\'
                for row in rows]
    current += [r'\midrule', 'Coordinatewise minimum & '
                + triple(result['minima']['delivered']) + r'\\',
                r'\bottomrule', r'\end{tabular}', r'\end{center}', '']
    (output / 'current_table.tex').write_text('\n'.join(current))
    table = [r'\begin{center}', r'\small', r'\begin{tabular}{@{}lrrr@{}}',
             r'\toprule', r'Measurement boundary & Tokens & AST nodes & Bytes\\',
             r'\midrule']
    labels = {'delivered': 'Complete delivered source',
              'common_filename': 'Identical filename driver',
              'common_stdin': 'Identical stdin driver',
              'kernel_core': 'Core: initialization and definitions'}
    for key, label in labels.items():
        table.append(escaped(label + ': old minimum') + ' & '
                     + triple(result['minima'][key]) + r'\\')
        for row in result['candidates']:
            table.append(escaped(row['label']) + ' & ' + triple(row[key]) + r'\\')
        if key != 'kernel_core':
            table.append(r'\midrule')
    table += [r'\bottomrule', r'\end{tabular}', r'\end{center}', '']
    (output / 'summary_table.tex').write_text('\n'.join(table))


def run(candidate_paths=()):
    manifest = json.loads((HERE / 'manifest.json').read_text())
    if sha256((HERE / 'source_measure.py').read_bytes()) != manifest['normalizer']['sha256']:
        raise ValueError('The inherited normalizer has changed')
    rows = []
    candidates = []
    with tempfile.TemporaryDirectory(prefix='ipra-comparison-') as temporary:
        for entry in manifest['programs']:
            raw = (HERE / entry['local_file']).read_bytes()
            if sha256(raw) != entry['sha256']:
                raise ValueError('Changed frozen source: ' + entry['local_file'])
            rows.append({**entry, **measure_program(raw, temporary)})
        for path in candidate_paths:
            path = Path(path)
            label = {'checker.py': 'New full recursion',
                     'checker_scalar.py': 'New scalar iterator'}.get(path.name, path.name)
            candidates.append({'file': path.name, 'label': label,
                               **measure_program(path.read_bytes(), temporary)})
        exclusions = []
        for entry in manifest['audit_exclusions']:
            raw = (HERE / entry['local_file']).read_bytes()
            if sha256(raw) != entry['sha256']:
                raise ValueError('Changed audit exclusion: ' + entry['local_file'])
            exclusions.append({**entry, 'delivered': source_metrics(raw, temporary)})
    minima = summaries(rows)
    for row in candidates:
        row['strict_improvement'] = {
            variant: {key: row[variant][key] < minima[variant][key] for key in NORMAL}
            for variant in minima}
    return {
        'repository': manifest['repository'], 'commit': manifest['commit'],
        'python': platform.python_version(), 'implementation': platform.python_implementation(),
        'archive_count': len(manifest['archives']), 'root_program_count': len(rows),
        'root_unique_raw_hashes': len({row['sha256'] for row in rows}),
        'root_unique_normalized_hashes': len({row['delivered']['normalized_sha256'] for row in rows}),
        'normalizer_sha256': manifest['normalizer']['sha256'],
        'normalization': 'Remove genuine docstrings; ast.unparse plus newline; count significant tokens, all AST nodes including expression contexts, and UTF-8 bytes.',
        'boundaries': {
            'delivered': 'The entire source, including imports, input parsing, checking, error handling, verdict, and exit status.',
            'common_filename': 'All original code before the final module-level try block, followed by the exact common_filename_driver below.',
            'common_stdin': 'The same prefix, followed by the common_stdin_driver below.',
            'kernel_core': 'Remove the sole final module-level try block and top-level imports only. Retain all global initialization and every function body. Not a standalone CLI checker.',
        },
        'common_filename_driver': COMMON_FILENAME_DRIVER,
        'common_stdin_driver': COMMON_STDIN_DRIVER,
        'minima': minima,
        'minimum_attainers': {
            variant: {key: [row['label'] for row in rows
                            if row[variant][key] == minima[variant][key]] for key in NORMAL}
            for variant in minima},
        'full_recursion_subgroup_minima': summaries(
            [row for row in rows if row['arithmetic'] == 'full_primitive_recursion']),
        'programs': rows, 'candidates': candidates, 'audit_exclusions': exclusions,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate', action='append', type=Path,
                        help='Complete new checker; repeat to compare several files')
    parser.add_argument('--output', type=Path, default=HERE,
                        help='Directory for JSON and LaTeX tables')
    args = parser.parse_args()
    candidates = args.candidate
    if candidates is None:
        candidates = [HERE.parent / name for name in ('checker.py', 'checker_scalar.py')
                      if (HERE.parent / name).is_file()]
    result = run(candidates)
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / 'measurements.json').write_text(json.dumps(result, indent=2) + '\n')
    write_tables(result, args.output)
    print(json.dumps({key: result[key] for key in (
        'python', 'archive_count', 'root_program_count', 'root_unique_raw_hashes',
        'root_unique_normalized_hashes', 'minima', 'full_recursion_subgroup_minima')}, indent=2))
    for row in result['candidates']:
        print(json.dumps({'candidate': row['file'],
                          'metrics': {key: {k: row[key][k] for k in NORMAL} for key in result['minima']},
                          'strict_improvement': row['strict_improvement']}, indent=2))


if __name__ == '__main__':
    main()
