"""Rescan all Python members of the six exact pinned ZIP archives.

This parses and measures source without executing it. The standard offline
benchmark needs only the frozen current sources. This expanded rescan also
requires the six original ZIPs, whose SHA-256 and Git blob hashes are checked.
"""
import argparse
import ast
import io
import json
from pathlib import Path, PurePosixPath
import platform
import tempfile
import zipfile
import hashlib

import benchmark

HERE = Path(__file__).resolve().parent


def git_blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode('ascii') + b'\0' + raw).hexdigest()


def inventory(archive_directory, manifest, extract=None):
    grouped = {}
    archives = []
    member_bytes = {}
    for entry in manifest['archives']:
        raw = (Path(archive_directory) / entry['archive']).read_bytes()
        if benchmark.sha256(raw) != entry['sha256'] or git_blob(raw) != entry['git_blob_sha']:
            raise ValueError('Archive is not the pinned Git blob: ' + entry['archive'])
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            members = [info for info in archive.infolist() if not info.is_dir()]
            names = [info.filename for info in members]
            if len(set(names)) != len(names):
                raise ValueError('Duplicate ZIP member names: ' + entry['archive'])
            python_members = [name for name in names if name.endswith('.py')]
            nested = [name for name in names if name.endswith(('.zip', '.tar', '.tar.gz'))]
            if nested:
                raise ValueError('Unscanned nested archive: ' + repr(nested))
            archives.append({**entry, 'member_count': len(members),
                             'python_member_count': len(python_members),
                             'nested_archive_members': nested})
            for name in sorted(python_members):
                source = archive.read(name)
                digest = benchmark.sha256(source)
                record = grouped.setdefault(digest, {'raw': source, 'locations': []})
                record['locations'].append({'archive': entry['archive'], 'member': name})
                member_bytes[(entry['archive'], name)] = source
    for entry in manifest['programs']:
        if benchmark.sha256(member_bytes[entry['archive'], entry['archive_member']]) != entry['sha256']:
            raise ValueError('Frozen current source differs from archive member: ' + entry['local_file'])

    rows = []
    errors = []
    with tempfile.TemporaryDirectory(prefix='ipra-archive-audit-') as temporary:
        for digest, entry in sorted(grouped.items()):
            raw = entry['raw']
            try:
                metrics = benchmark.source_metrics(raw, temporary)
                tree = ast.parse(raw.decode('utf-8'))
            except (SyntaxError, UnicodeError) as error:
                errors.append({'sha256': digest, 'locations': entry['locations'],
                               'error': repr(error)})
                continue
            functions = sorted(node.name for node in tree.body
                               if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)))
            rows.append({'sha256': digest, 'metrics': metrics,
                         'locations': entry['locations'], 'path_count': len(entry['locations']),
                         'top_level_functions': functions,
                         'checker_like': 'check' in functions})

    roots = [row for row in rows if any(
        entry['sha256'] == row['sha256'] for entry in manifest['programs'])]
    minima = {key: min(row['metrics'][key] for row in roots) for key in benchmark.NORMAL}
    checker_like = [row for row in rows if row['checker_like']]
    small = [row for row in rows if any(row['metrics'][key] < minima[key]
                                      for key in benchmark.NORMAL)]
    excluded = {entry['sha256']: entry for entry in manifest['audit_exclusions']}
    for row in small:
        entry = excluded.get(row['sha256'])
        row['below_frontier_review'] = entry['reason'] if entry else 'NOT REVIEWED'

    if extract is not None:
        extract = Path(extract)
        for entry in [*manifest['programs'], *manifest['audit_exclusions']]:
            path = PurePosixPath(entry['local_file'])
            if path.is_absolute() or '..' in path.parts:
                raise ValueError('Unsafe frozen destination')
            destination = extract.joinpath(*path.parts)
            destination.parent.mkdir(parents=True, exist_ok=True)
            raw = member_bytes[entry['archive'], entry['archive_member']]
            if benchmark.sha256(raw) != entry['sha256']:
                raise ValueError('Changed source chosen for freezing')
            destination.write_bytes(raw)

    return {
        'repository': manifest['repository'], 'commit': manifest['commit'],
        'python': platform.python_version(), 'implementation': platform.python_implementation(),
        'normalizer_sha256': manifest['normalizer']['sha256'],
        'archive_count': len(archives),
        'python_path_count': sum(len(row['locations']) for row in grouped.values()),
        'unique_python_source_hashes': len(grouped),
        'parse_errors': errors,
        'checker_like_definition': 'A source containing a module-level function named check. This is a broad structural inventory, not a claim that all historical experiments are sound or complete.',
        'checker_like_path_count': sum(row['path_count'] for row in checker_like),
        'unique_checker_like_hashes': len(checker_like),
        'checker_like_minima': {key: min(row['metrics'][key] for row in checker_like)
                               for key in benchmark.NORMAL},
        'current_root_minima': minima,
        'below_current_in_any_coordinate_count': len(small),
        'unreviewed_below_frontier_hashes': [row['sha256'] for row in small
                                            if row['sha256'] not in excluded],
        'exclusion_summary': 'Every Python source below at least one current normalized coordinate was read. The thirteen such sources are build, packaging, reproduction, or validation-driver scripts. Each is frozen separately with a reason; none is a standalone complete proof checker.',
        'scope': 'All Python members in the six current archives, including historical/frozen/support directories. The primary comparison remains the eleven root checker files. This does not certify every historical proposal.',
        'archives': archives,
        'below_frontier_sources': [{key: value for key, value in row.items() if key != 'locations'}
                                   for row in sorted(small, key=lambda row: row['metrics']['normalized_tokens'])],
        'sources': rows,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archives', type=Path,
                        help='Directory containing the six pinned ZIP files')
    parser.add_argument('--output', type=Path, default=HERE / 'archive_rescan.json')
    parser.add_argument('--extract', type=Path,
                        help='Optionally recreate the 11 frozen roots and 13 small excluded scripts here')
    args = parser.parse_args()
    manifest = json.loads((HERE / 'manifest.json').read_text())
    if benchmark.sha256((HERE / 'source_measure.py').read_bytes()) != manifest['normalizer']['sha256']:
        raise ValueError('Changed normalizer')
    result = inventory(args.archives, manifest, args.extract)
    if result['parse_errors'] or result['unreviewed_below_frontier_hashes']:
        raise ValueError('Expanded audit needs additional review')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in (
        'python', 'archive_count', 'python_path_count', 'unique_python_source_hashes',
        'parse_errors', 'checker_like_path_count', 'unique_checker_like_hashes',
        'checker_like_minima', 'current_root_minima',
        'below_current_in_any_coordinate_count', 'unreviewed_below_frontier_hashes')}, indent=2))


if __name__ == '__main__':
    main()
