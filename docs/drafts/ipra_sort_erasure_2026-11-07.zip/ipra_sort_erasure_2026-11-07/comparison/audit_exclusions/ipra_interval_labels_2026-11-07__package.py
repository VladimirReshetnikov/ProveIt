"""Create an integrity manifest and a clean, deterministic ZIP of this package."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent
SKIP_SUFFIXES = {'.aux', '.log', '.out', '.toc', '.fls', '.fdb_latexmk', '.synctex.gz', '.pyc'}


def eligible(path):
    return (path.is_file() and '__pycache__' not in path.parts
            and path.name != 'SHA256SUMS.txt'
            and path.suffix not in SKIP_SUFFIXES)


def main():
    files = sorted(path for path in ROOT.rglob('*') if eligible(path))
    manifest = ROOT / 'SHA256SUMS.txt'
    manifest.write_text(''.join(hashlib.sha256(path.read_bytes()).hexdigest()
                                + '  ' + str(path.relative_to(ROOT)) + '\n'
                                for path in files))
    files.append(manifest)
    output = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(files):
            info = zipfile.ZipInfo(str(Path(ROOT.name) / path.relative_to(ROOT)),
                                   date_time=(2026, 11, 7, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())
    with zipfile.ZipFile(output) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('ZIP CRC check failed')
    print(output)


if __name__ == '__main__':
    main()
