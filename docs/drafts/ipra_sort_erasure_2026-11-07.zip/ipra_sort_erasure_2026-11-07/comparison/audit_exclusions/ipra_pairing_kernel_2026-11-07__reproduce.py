"""Run the package's offline measurement and finite validation."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
for script in ('measure.py', 'validation/run.py', 'arithmetic_checks.py'):
    subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)
