"""Compile the complete LaTeX report; no network access is needed."""
from pathlib import Path
import argparse
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--latex", default="pdflatex")
    args = parser.parse_args()
    for run in range(3):
        result = subprocess.run(
            [args.latex, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
            cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (ROOT / "results" / f"latex_pass_{run + 1}.txt").write_text(result.stdout)
        if result.returncode:
            raise RuntimeError(f"LaTeX pass {run + 1} failed; inspect results/latex_pass_{run + 1}.txt")
    print("Compiled report.pdf")


if __name__ == "__main__":
    main()
