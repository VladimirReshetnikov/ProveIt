"""Build the paper, failing on layout overflow and unresolved references."""
from pathlib import Path
import json
import re
import shutil
import subprocess
import sys

from reproduce import refresh_tables

ROOT = Path(__file__).resolve().parent


def main():
    refresh_tables()
    latex = shutil.which('pdflatex')
    if not latex:
        raise SystemExit('pdflatex is required to rebuild report.pdf')
    records = []
    for iteration in range(1, 4):
        command = [latex, '-no-shell-escape', '-interaction=nonstopmode',
                   '-halt-on-error', '-file-line-error', 'report.tex']
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
        path = ROOT / 'results' / f'latex_pass_{iteration}.txt'
        path.write_text(result.stdout + result.stderr)
        records.append({'pass': iteration, 'exit_code': result.returncode})
        if result.returncode:
            print((result.stdout + result.stderr)[-5000:])
            raise SystemExit(result.returncode)
    log = (ROOT / 'report.log').read_text(errors='replace')
    problems = [line for line in log.splitlines()
                if 'Overfull \\hbox' in line or 'Overfull \\vbox' in line
                or ('undefined' in line and ('Reference' in line or 'Citation' in line))
                or 'There were undefined references' in line]
    receipt = {'status': 'PASS' if not problems else 'FAIL',
               'passes': records, 'layout_or_reference_problems': problems,
               'pdf_bytes': (ROOT / 'report.pdf').stat().st_size}
    (ROOT / 'results/build.json').write_text(json.dumps(receipt, indent=2) + '\n')
    if problems:
        print('\n'.join(problems))
        raise SystemExit(1)
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
