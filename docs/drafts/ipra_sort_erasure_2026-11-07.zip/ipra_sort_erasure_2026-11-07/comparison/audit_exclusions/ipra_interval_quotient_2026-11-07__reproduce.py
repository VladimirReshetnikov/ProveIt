"""Reproduce the finite audit and comparison, without network access."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    logs = []
    for script in ['measure.py', 'validation/verify.py']:
        result = subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT,
                                text=True, capture_output=True)
        logs.append(f'COMMAND: {script}\n{result.stdout}{result.stderr}\nEXIT: {result.returncode}\n')
        if result.returncode:
            print(logs[-1])
            raise SystemExit(result.returncode)
        print(script + ': PASS')
    examples = json.loads((ROOT / 'examples/index.json').read_text())
    count = 0
    for item in examples:
        for checker in item['checkers']:
            result = subprocess.run([sys.executable, str(ROOT / checker)],
                                    input=(ROOT / 'examples' / item['file']).read_text(),
                                    text=True, capture_output=True, timeout=20)
            expected = (0, 'ACCEPT') if item['expected'] else (1, 'REJECT')
            if (result.returncode, result.stdout.strip()) != expected or result.stderr:
                raise RuntimeError((checker, item['file'], result.returncode, result.stdout, result.stderr))
            count += 1
    logs.append(f'PUBLIC EXAMPLES: {count} expected verdicts confirmed.\n')
    (ROOT / 'results/reproduction.txt').write_text('\n'.join(logs))
    print(f'Public examples: {count} expected verdicts confirmed.')


if __name__ == '__main__':
    main()
