"""Reproduce the finite evidence; add --pdf to compile the mathematical report."""
from pathlib import Path
import argparse
import json
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pdf", action="store_true")
    parser.add_argument("--latex", default="pdflatex")
    args = parser.parse_args()
    if (ROOT / "checker_local.py").read_bytes() != (ROOT / "validation_local/checker_local_interval.py").read_bytes():
        raise ValueError("Local validation copy differs from the delivered checker")
    commands = [
        [sys.executable, "measure.py"],
        [sys.executable, "validation/run.py"],
        [sys.executable, "validation_local/validate_local.py"],
    ]
    for number, command in enumerate(commands, 1):
        result = subprocess.run(command, cwd=ROOT, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (ROOT / "results" / f"reproduction_{number}.txt").write_text(result.stdout)
        if result.returncode:
            raise RuntimeError(f"Reproduction step {number} failed; inspect its saved log")
        print(f"PASS: {' '.join(command[1:])}", flush=True)
    shutil.copy2(ROOT / "validation/results/validation.json", ROOT / "results/validation.json")
    shutil.copy2(ROOT / "validation_local/local_validation_summary.json", ROOT / "results/local_validation_summary.json")
    receipts = [json.loads((ROOT / path).read_text()) for path in
                ("results/measurements.json", "results/validation.json", "results/local_validation_summary.json")]
    if not all(receipt["status"] == "PASS" for receipt in receipts):
        raise ValueError("A receipt did not report PASS")
    if args.pdf:
        subprocess.run([sys.executable, "build.py", "--latex", args.latex], cwd=ROOT, check=True)
    print("All requested reproduction steps passed.")


if __name__ == "__main__":
    main()
