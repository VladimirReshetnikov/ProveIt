"""Rebuild the complete paper using a local pdfLaTeX installation."""
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    subprocess.run([sys.executable, str(ROOT / 'measure.py')], cwd=ROOT,
                   check=True, stdout=subprocess.DEVNULL)
    engine = shutil.which('pdflatex')
    if engine is None:
        raise SystemExit('pdflatex is required to rebuild the PDF.')
    build = ROOT / 'results/latex'
    build.mkdir(exist_ok=True)
    for number in range(1, 4):
        run = subprocess.run([engine, '-no-shell-escape', '-interaction=nonstopmode',
                              '-halt-on-error', '-output-directory=' + str(build),
                              'report.tex'], cwd=ROOT, text=True, capture_output=True)
        (ROOT / f'results/latex_pass_{number}.txt').write_text(run.stdout + run.stderr)
        if run.returncode:
            print(run.stdout[-9000:])
            raise SystemExit(run.returncode)
    log = (build / 'report.log').read_text(errors='replace')
    errors = [line for line in log.splitlines()
              if 'Overfull ' in line or 'undefined' in line or 'multiply defined' in line]
    if errors:
        raise SystemExit('Document QA failed:\n' + '\n'.join(errors))
    shutil.copy2(build / 'report.pdf', ROOT / 'report.pdf')
    pages = re.search(r'Output written on .*?\((\d+) pages', log, re.S)
    print('Built report.pdf' + (f' ({pages.group(1)} pages).' if pages else '.'))


if __name__ == '__main__':
    main()
