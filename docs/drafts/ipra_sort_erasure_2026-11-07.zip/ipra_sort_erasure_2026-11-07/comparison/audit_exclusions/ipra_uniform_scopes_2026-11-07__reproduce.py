#!/usr/bin/env python3
"""Reproduce all reported mathematical-computation and implementation evidence."""
import argparse
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pdf', action='store_true', help='also rebuild the PDF')
    args = parser.parse_args()
    scripts = [
        'measure.py',
        'validation/validate.py',
        'validation/direct_validate.py',
        'validation/independent/audit_uniform_semantics.py',
        'validation/check_predecessor_shift.py',
        'validation/predecessor/check_conditional.py',
        'evidence.py',
    ]
    for relative in scripts:
        result = subprocess.run([sys.executable, str(ROOT / relative)], cwd=ROOT,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        name = relative.replace('/', '__').replace('.py', '.log')
        (ROOT / 'results' / ('reproduce_' + name)).write_text(result.stdout)
        if result.returncode:
            print(result.stdout[-16000:])
            raise SystemExit('FAILED: ' + relative)
        print('PASS: ' + relative, flush=True)
    if args.pdf:
        subprocess.run([sys.executable, str(ROOT / 'build.py')], cwd=ROOT, check=True)


if __name__ == '__main__':
    main()
