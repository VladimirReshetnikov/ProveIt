#!/usr/bin/env python3
"""Compile the self-contained LaTeX paper and reject material layout warnings."""
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent


def main():
    for script in ('measure.py', 'evidence.py'):
        subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True,
                       stdout=subprocess.PIPE, text=True)
    latex = shutil.which('pdflatex')
    if not latex:
        raise SystemExit('pdfLaTeX is required to rebuild report.pdf')
    with tempfile.TemporaryDirectory(prefix='ipra-latex-') as directory:
        build = Path(directory)
        outputs = []
        for _ in range(3):
            command = [latex, '-no-shell-escape', '-interaction=nonstopmode',
                       '-halt-on-error', '-file-line-error', '-output-directory', str(build), 'report.tex']
            process = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT, text=True)
            outputs.append(process.stdout)
            if process.returncode:
                (ROOT / 'results/build.log').write_text('\n'.join(outputs))
                print(process.stdout[-12000:])
                raise SystemExit('LaTeX compilation failed; see results/build.log')
        log = (build / 'report.log').read_text(errors='replace')
        (ROOT / 'results/build.log').write_text(log)
        bad = re.findall(r'Overfull \\[hv]box[^\n]*', log)
        undefined = 'There were undefined references' in log or 'Citation ' in log and ' undefined' in log
        if bad or undefined:
            print('\n'.join(bad))
            raise SystemExit('Material layout or reference warning; see results/build.log')
        shutil.copyfile(build / 'report.pdf', ROOT / 'report.pdf')
    result = {'status': 'PASS', 'latex_passes': 3, 'overfull_boxes': 0,
              'undefined_references': False, 'output': 'report.pdf'}
    (ROOT / 'results/build.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
