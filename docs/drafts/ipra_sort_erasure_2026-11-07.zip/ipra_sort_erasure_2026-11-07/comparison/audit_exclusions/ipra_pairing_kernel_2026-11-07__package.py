"""Build a deterministic ZIP with a complete SHA-256 manifest."""
from hashlib import sha256
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
def files():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and '__pycache__' not in p.parts and p.suffix != '.pyc'
                  and p.name != 'SHA256SUMS.txt')

manifest = ''.join(sha256(p.read_bytes()).hexdigest() + '  ' +
                   p.relative_to(ROOT).as_posix() + '\n' for p in files())
(ROOT / 'SHA256SUMS.txt').write_text(manifest)
archive = ROOT.with_suffix('.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for path in sorted(files() + [ROOT / 'SHA256SUMS.txt']):
        info = zipfile.ZipInfo(ROOT.name + '/' + path.relative_to(ROOT).as_posix(),
                               date_time=(2026, 11, 7, 12, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        output.writestr(info, path.read_bytes())
with zipfile.ZipFile(archive) as result:
    if result.testzip() is not None:
        raise ValueError('ZIP verification failed')
print(archive)
