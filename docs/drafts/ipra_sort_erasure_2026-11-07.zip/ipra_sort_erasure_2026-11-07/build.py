#!/usr/bin/env python3
"""Compile the complete paper from its included LaTeX sources."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
BUILD = ROOT / 'build'


def main():
    BUILD.mkdir(exist_ok=True)
    command = [
        'pdflatex', '-interaction=nonstopmode', '-halt-on-error',
        '-file-line-error', '-output-directory=build', 'report.tex',
    ]
    for pass_number in range(1, 4):
        result = subprocess.run(command, cwd=ROOT, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (BUILD / f'pass-{pass_number}.txt').write_text(result.stdout)
        if result.returncode:
            print(result.stdout[-12000:])
            raise SystemExit(result.returncode)
    shutil.copy2(BUILD / 'report.pdf', ROOT / 'report.pdf')
    print(ROOT / 'report.pdf')


if __name__ == '__main__':
    main()
