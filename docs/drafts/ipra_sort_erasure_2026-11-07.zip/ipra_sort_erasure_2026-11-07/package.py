#!/usr/bin/env python3
"""Build a deterministic release ZIP and verify its CRCs and SHA-256 manifest.

Run with Python 3 from any working directory. Only standard-library modules
are used. ZIP and manifest paths are relative to this report directory.
The checksum manifest covers every included file except the manifest itself.
"""
from hashlib import sha256
import json
import os
from pathlib import Path
import stat
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
ARCHIVE = ROOT.parent / (ROOT.name + '.zip')
MANIFEST = 'MANIFEST.sha256'
ZIP_DATE = (2026, 11, 7, 0, 0, 0)
EXCLUDED_DIRECTORIES = {
    'build', '__pycache__', 'tmp', 'temp', '.git', '.cache',
    '.pytest_cache', '.mypy_cache', '.ruff_cache',
}
TEMPORARY_SUFFIXES = {
    '.pyc', '.pyo', '.tmp', '.temp', '.bak', '.swp', '.swo',
    '.aux', '.out', '.toc', '.lof', '.lot', '.fls', '.fdb_latexmk',
    '.synctex', '.dvi', '.xdv',
}
REQUIRED = {
    'report.pdf', 'report.tex', 'checker.py', 'checker_scalar.py',
    'build.py', 'reproduce.py', 'package.py', 'README.md', 'LICENSE',
    'ATTRIBUTION.txt', 'comparison/manifest.json',
    'comparison/measurements.json', 'comparison/inventory.json',
    'comparison/source_measure.py', 'comparison/benchmark.py',
    'comparison/scan_archives.py', 'results/reproduction.json',
    'results/validation_results.json',
    'results/validation_boundary_results.json',
    'validation/fixtures/provenance.json',
    'validation/fixtures/positive_certificates.json',
    'validation/fixtures/direct_positive_certificates.json',
    'validation/fixtures/non_atomic_induction_attempt.json',
}


def eligible(path):
    relative = path.relative_to(ROOT)
    if set(relative.parts[:-1]) & EXCLUDED_DIRECTORIES:
        return False
    if relative.as_posix() == MANIFEST:
        return False
    if path.name in {'.DS_Store', 'Thumbs.db'}:
        return False
    if path.suffix in TEMPORARY_SUFFIXES or path.name.endswith(('.synctex.gz', '~')):
        return False
    if path.name.startswith('.#') or (path.name.startswith('#') and path.name.endswith('#')):
        return False
    return True


def snapshot():
    """Capture each included file once so manifest and ZIP use identical bytes."""
    payload = {}
    for path in sorted(ROOT.rglob('*')):
        if not eligible(path):
            continue
        if path.is_symlink():
            raise ValueError('Release must not depend on a symlink: ' + str(path.relative_to(ROOT)))
        if not path.is_file():
            continue
        name = path.relative_to(ROOT).as_posix()
        if '\n' in name or '\r' in name:
            raise ValueError('Filename is unsuitable for the checksum manifest: ' + repr(name))
        payload[name] = path.read_bytes()

    missing = REQUIRED - payload.keys()
    if missing:
        raise ValueError('Missing required deliverables: ' + ', '.join(sorted(missing)))
    comparison = json.loads(payload['comparison/manifest.json'])
    for entry in comparison['programs'] + comparison['audit_exclusions']:
        name = 'comparison/' + entry['local_file']
        if name not in payload or sha256(payload[name]).hexdigest() != entry['sha256']:
            raise ValueError('Missing or changed frozen comparison source: ' + name)

    checksums = ''.join(sha256(payload[name]).hexdigest() + '  ' + name + '\n'
                        for name in sorted(payload))
    payload[MANIFEST] = checksums.encode('utf-8')
    (ROOT / MANIFEST).write_bytes(payload[MANIFEST])
    return payload


def verify(path, payload):
    prefix = ROOT.name + '/'
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None:
            raise ValueError('ZIP CRC verification failed')
        expected = [prefix + name for name in sorted(payload)]
        if archive.namelist() != expected:
            raise ValueError('ZIP members differ from the exact sorted release snapshot')
        if archive.read(prefix + MANIFEST) != payload[MANIFEST]:
            raise ValueError('ZIP manifest differs from the generated manifest')
        for line in payload[MANIFEST].decode('utf-8').splitlines():
            expected_hash, name = line.split('  ', 1)
            if sha256(archive.read(prefix + name)).hexdigest() != expected_hash:
                raise ValueError('ZIP member checksum mismatch: ' + name)


def main():
    payload = snapshot()
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=ARCHIVE.name + '.', suffix='.tmp', dir=ROOT.parent)
    os.close(descriptor)
    temporary = Path(temporary_name)
    try:
        with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED,
                             compresslevel=9) as archive:
            for name in sorted(payload):
                info = zipfile.ZipInfo(ROOT.name + '/' + name, date_time=ZIP_DATE)
                info.create_system = 3
                info.external_attr = (stat.S_IFREG | 0o644) << 16
                archive.writestr(info, payload[name],
                                 compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        verify(temporary, payload)
        temporary.replace(ARCHIVE)
    finally:
        temporary.unlink(missing_ok=True)

    print(json.dumps({
        'archive': ARCHIVE.name,
        'included_files': len(payload),
        'checksummed_files': len(payload) - 1,
        'bytes': ARCHIVE.stat().st_size,
        'sha256': sha256(ARCHIVE.read_bytes()).hexdigest(),
        'crc_integrity': 'PASS',
        'manifest_integrity': 'PASS',
        'required_entries': 'PASS',
    }, indent=2))


if __name__ == '__main__':
    main()
