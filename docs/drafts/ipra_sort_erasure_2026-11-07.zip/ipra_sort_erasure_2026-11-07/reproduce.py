#!/usr/bin/env python3
"""Reproduce the frozen measurements and finite implementation audits."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'results'


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def run(name, arguments):
    process = subprocess.run([sys.executable, *arguments], cwd=ROOT,
                             text=True, stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT)
    (RESULTS / (name + '.log')).write_text(process.stdout)
    if process.returncode:
        print(process.stdout[-16000:])
        raise SystemExit(process.returncode)


def main():
    RESULTS.mkdir(exist_ok=True)
    provenance = json.loads((ROOT / 'validation/fixtures/provenance.json').read_text())
    for item in provenance['files']:
        path = ROOT / 'validation/fixtures' / item['filename']
        if digest(path) != item['sha256']:
            raise ValueError('Changed inherited fixture: ' + item['filename'])
    run('comparison', ['comparison/benchmark.py'])
    run('differential', ['validation/validate_erasure.py'])
    run('boundary', ['validation/validate_boundary.py'])
    for name in ('validation_results.json', 'validation_boundary_results.json'):
        shutil.copy2(ROOT / 'validation' / name, RESULTS / name)
    measured = json.loads((ROOT / 'comparison/measurements.json').read_text())
    differential = json.loads((RESULTS / 'validation_results.json').read_text())
    boundary = json.loads((RESULTS / 'validation_boundary_results.json').read_text())
    candidates = {row['file']: row for row in measured['candidates']}
    for filename in ('checker.py', 'checker_scalar.py'):
        if candidates[filename]['delivered']['sha256'] != digest(ROOT / filename):
            raise ValueError('Measurement source identity mismatch')
        if not all(all(v.values()) for v in candidates[filename]['strict_improvement'].values()):
            raise ValueError('Candidate is not strictly below a comparison boundary')
    if boundary['checker_sha256'] != digest(ROOT / 'checker.py'):
        raise ValueError('Boundary test source identity mismatch')
    for filename, receipt_key in (('oracle_erasure.py', 'oracle_sha256'),
                                  ('validate_boundary.py', 'runner_sha256')):
        if boundary[receipt_key] != digest(ROOT / 'validation' / filename):
            raise ValueError('Boundary validation dependency changed')
    counts = {
        'Canonical scalar certificates': differential['results'][0]['positive'],
        'Canonical full-recursion certificates': differential['results'][1]['positive'],
        'Mutated packets compared with named-rule oracle': sum(r['mutation'] for r in differential['results']),
        'Generated mixed-shape packets compared with oracle': sum(r['random'] for r in differential['results']),
        'Focused public-boundary cases': len(boundary['targeted_cases']),
        'Independently evaluated full-recursion equations': boundary['independent_computation_semantics']['accepted_and_independently_evaluated_equations'],
        'Deliberately incorrect kernel controls detected': len(boundary['mutation_controls']),
        'Full-kernel public CLI runs, normal and optimized': boundary['public_cli']['runs'],
    }
    example_results = []
    for filename, expected in json.loads((ROOT / 'examples/index.json').read_text()).items():
        process = subprocess.run([sys.executable, str(ROOT / 'checker.py'),
                                  str(ROOT / 'examples' / filename)],
                                 capture_output=True, text=True)
        wanted = (0, 'ACCEPT', '') if expected else (1, 'REJECT', '')
        actual = process.returncode, process.stdout.strip(), process.stderr
        if actual != wanted:
            raise ValueError('Unexpected public example verdict: ' + filename)
        example_results.append({'file': filename, 'accepted': expected})
    lines = [r'\begin{center}', r'\small',
             r'\begin{tabular}{@{}p{0.79\linewidth}r@{}}', r'\toprule',
             r'Finite validation category & Count\\', r'\midrule']
    lines += [label + ' & ' + format(number, ',') + r'\\' for label, number in counts.items()]
    lines += [r'\bottomrule', r'\end{tabular}', r'\end{center}',
              r'All listed checks passed. Test populations can overlap; no sum is claimed as a count of distinct mathematical theorems.']
    (RESULTS / 'validation_summary.tex').write_text('\n'.join(lines) + '\n')
    receipt = {
        'status': 'PASS',
        'commit': measured['commit'],
        'python': measured['python'],
        'checker_hashes': {name: digest(ROOT / name) for name in candidates},
        'counts': counts,
        'public_examples': example_results,
        'metatheory': 'Written proofs; not proof-assistant formalization',
    }
    (RESULTS / 'reproduction.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
