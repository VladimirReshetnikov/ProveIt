# Sort erasure: a smaller complete presentation of iPRA

Prepared for Vladimir Reshetnikov, 7 November 2026 (Pacific date).

## Result

This archive contains a complete axiomatization, a written proof of
equiconsistency and whole-domain bi-interpretability with full first-order
intuitionistic primitive recursive arithmetic, and executable certificate
checkers. It compares against all eleven root programs in the six current
ProveIt drafts at commit `df8beb801d9f3e3eb3a8141722953fb58e63009e`.

| Complete program | Normalized Python tokens | AST nodes | Normalized bytes |
| --- | ---: | ---: | ---: |
| Current coordinatewise minimum | 356 | 378 | 1,038 |
| `checker.py`, full primitive recursion | **354** | **374** | **1,007** |
| `checker_scalar.py`, scalar iteration | **347** | **368** | **995** |

The full-recursion program is the recommended mathematical presentation:
predecessor and every fixed primitive-recursive definition become immediate.
The smaller scalar program has the more involved inherited arithmetic
development, reproduced in the paper's appendices. Both programs use the
same file-input driver as the current minimum. The reduction survives
removing all input/output code and comparing the explicit checking cores.

## New idea

At formula sort, scalar leaves erase to truth before numerical substitution.
Binary numerical trees may therefore denote zero, with their two formula
annotations ignored mathematically. A node's arity alone determines the
single scope increment applied to all its children. This removes the old
binary sort check and the per-child scope-vector traversal.

The two arithmetic computation schemas and five logical inference patterns
are inherited and explicitly credited. This is a new syntax completion and
checker reduction relative to the inspected corpus, not an absolute
shortestness theorem or a new arithmetic foundation.

## Files and commands

- `report.pdf`: the complete paper.
- `report.tex`, `sections/`, `appendices/`: all LaTeX sources.
- `checker.py`: full-recursion acceptance program; no project imports.
- `checker_scalar.py`: optional scalar acceptance program.
- `comparison/`: frozen comparison sources, exact provenance, and metrics.
- `validation/`: independent named-rule oracle, fixtures, and finite audits.
- `examples/`: small standalone certificates and explanations.
- `results/`: reproducible measurements and validation receipts.
- `ATTRIBUTION.txt`, `LICENSE`: contribution boundary and source license.

The checkers require Python 3.10 or later. Exact reported measurements use
the Python version recorded in `comparison/measurements.json`.

```sh
python3 checker.py examples/zero_computation.json
python3 checker.py examples/predecessor_two.json
python3 reproduce.py
python3 build.py
python3 package.py
```

The first two commands should print `ACCEPT` and exit with status zero.
Rejected packets print `REJECT` and exit with status one. A packet is a
JSON array: its final item is the closed goal; preceding instruction cells
are consumed from the end. Unread prefix cells are inert. The public
checker starts with an empty context and accepts no caller-supplied axioms
or executable code.

`reproduce.py` runs the comparison and finite validation, without network
access. `build.py` requires pdfLaTeX and the standard packages listed in
`report.tex`; it rebuilds `report.pdf` from the included sources.
`package.py` creates a clean ZIP archive and a SHA-256 manifest of its
contents, excluding temporary build products and Python bytecode.

## Mathematical status

The ordinary realizations are bi-interpretable with iPRA on the entire
numerical domain, with unchanged equality and identity graphs for both
composite isomorphisms. The native calculus is a faithful presentation of
those ordinary theories. The certificate theorem is sound extraction from
accepted traces and canonical completeness, with sufficient finite
execution resources. This avoids confusing raw packet trees with an
ordinary first-order structure.

The proofs are written mathematical arguments, independently reviewed
during this work, not Lean/Rocq formalizations. The finite audits are
implementation evidence, not proofs of consistency or soundness. Python
resource limits may reject large valid certificates. The program checks
certificates; it does not decide arithmetical truth or theoremhood.
