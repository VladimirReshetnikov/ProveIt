QUANTITATIVE ADVANCES FOR UNION-CLOSED FAMILIES
Prepared for Vladimir Reshetnikov, 25 November 2026
============================================================

Start with union_closed_advances.pdf.
The complete editable source is union_closed_advances.tex plus sections/.

RESULTS

1. Ranked frequencies beyond the independent-sampling threshold.
   For every fixed k, the kth largest frequency has limiting inferior
   at least 0.3828852549667978 as the number N of family members grows.
   The paper gives an explicit O(k/log N) error and a stronger frequency
   profile. For example, at least ceil(0.002925 log_2 N) nonconstant
   elements each belong to strictly more than 38.2% of the members.
   This answers the question in Das-Wu, Section 4.2, about a positive
   improvement beyond (3-sqrt(5))/2 for fixed ranks. The external input
   is Costa-Sadhu's Proposition 6.3; its original computational
   certificate is cited, not rerun in this archive.

2. An improved finite-size approximation.
   Every nontrivial union-closed family of at most 2,600,000,000 distinct
   finite sets has an element in strictly more than 39% of its members.
   At N=1000, some element belongs to at least 407 members.
   The entropy-stability coefficient improves from the supplied draft's
   0.17 to 0.19, while retaining an exact logarithmic destination term.
   All new scalar numerical decisions have exact rational certificates.

3. Sharp structural frequency asymptotics.
   Suppose generators all have size d, every ground element belongs to
   exactly r>=3 generators, and two generators intersect in at most one
   element. Uniform sampling counts each distinct union once.
   The worst possible minimum and worst possible maximum frequencies are

     1 - 2^(-r)
       - 2^(-r-1) [r + r(r-1)(d-1)/(2^(r-1)-1)] (1-2^(1-r))^d
       + O_r(d^3 rho_r^d),

   with explicit rho_r < 1-2^(1-r). There is also a local formula,
   an effective finite error, a triangle-count stability theorem,
   and polynomial-size explicit equality examples to this accuracy.
   The incidence construction is of classical Wenger type; no novelty
   is claimed for that construction itself.

SCOPE

This is not a proof of Frankl's full half-frequency conjecture, nor a
claim to improve the unrestricted universal constant. These are proved
extensions relative to the cited papers and twelve inspected ProveIt
archives. Targeted literature searches found no exact antecedent to
the claimed extensions; this is not an absolute priority guarantee.
There is no Lean/Rocq formalization or external peer review.

REPRODUCE

All verification code needs Python 3.10 or newer and only the standard
library. From this directory run:

    python3 code/run_checks.py

This regenerates the JSON results in data/ and a reproduction summary.
The two scalar-certificate scripts use exact fractions and proven
logarithm remainders. The incidence checks use exact combinatorics and
fractions. The exhaustive entropy audits explicitly use floating point
only as finite sanity checks; they are not the universal proofs.

With a conventional TeX Live installation and latexmk:

    make pdf

or run pdflatex twice on union_closed_advances.tex. Standard packages
are listed in that file. No network access is needed for reproduction.

PROVENANCE

data/source_manifest.json records all twelve source archive names,
Git blob hashes, sizes, and the checked repository commit.
data/literature_audit.txt records primary sources and search limitations.
data/independent_proof_review.txt records separate reviews of all three
arguments, including a detailed audit of the structural remainder.
The manuscript identifies exactly which claims are new deductions and
which ingredients are inherited from the supplied drafts or literature.

CONTENTS

union_closed_advances.pdf   Compiled research paper
union_closed_advances.tex   Main LaTeX source
sections/                  Complete theorem/proof sections and references
code/                      Five verification programs and one runner
data/                      Certificates, audit outputs, source inventory
Makefile                   Conventional build/reproduction commands
MANIFEST.sha256             SHA-256 checksums of the deliverable files
