#!/usr/bin/env python3
"""Exact rational certificates for the 19/100 entropy-stability refinement.

Only the Python standard library is used. All assertions are rational.
Logarithms are enclosed using a positive atanh series after powers-of-two
range reduction. Decimal strings are outward truncations, never evidence
for the assertions. The finite-family audit is in a separate script.
"""
from fractions import Fraction as F
import json
from pathlib import Path


def log_unit(x, terms=32):
    assert F(1) <= x <= F(2)
    t = (x - 1) / (x + 1)
    power = t
    total = F(0)
    for j in range(terms):
        total += 2 * power / (2 * j + 1)
        power *= t * t
    remainder = 2 * power / ((2 * terms + 1) * (1 - t * t))
    return total, total + remainder


LOG2 = log_unit(F(2))


def log_interval(x):
    assert x > 0
    k = 0
    while x < 1:
        x *= 2
        k -= 1
    while x > 2:
        x /= 2
        k += 1
    lo, hi = log_unit(x)
    if k >= 0:
        return lo + k * LOG2[0], hi + k * LOG2[1]
    return lo + k * LOG2[1], hi + k * LOG2[0]


GLO = F(381966011250105, 10**15)
GHI = F(381966011250106, 10**15)
assert (3 - 2 * GLO) ** 2 > 5
assert (3 - 2 * GHI) ** 2 < 5
assert 0 < GLO < GHI < F(2, 5)


def q_lower(s, gamma=GLO):
    j = 1 - (1 + gamma) ** 2 * s * s
    d = 2 * gamma * gamma * s * s
    assert j > 0
    return (j + d) * log_interval((j + d) / j)[0] - d


def f_ratio_lower(q):
    # F(q)/(q(2-q)) in a form with only two logarithms.
    return (log_interval((2 - q) / (2 + q))[0]
            + (4 * q - 2 * log_interval(1 + q)[1]) / (2 - q))


def floor_decimal(value, places=12):
    scale = 10 ** places
    floor = value.numerator * scale // value.denominator
    return f"{floor // scale}.{floor % scale:0{places}d}"


endpoints = [GLO] + [F(x, 1000) for x in
    (382, 383, 384, 385, 386, 388, 390, 395, 400, 410, 420)] + [F(1)]
rows = []
for u, v in zip(endpoints, endpoints[1:]):
    lower = f_ratio_lower(u) + q_lower(1 - v) / (v * (2 - v))
    assert lower > F(19, 100), (u, v, lower)
    rows.append({"u": str(u), "v": str(v),
                 "lower_bound_greater_than": floor_decimal(lower)})


def frequency_lower(s, d_lower, denominator_n, error):
    numerator = d_lower + F(19, 100) * s * s + q_lower(s) - error
    assert numerator > 0
    return GLO + (1 - GHI) * numerator / log_interval(F(denominator_n))[1]


# Uniformly for 2 <= N <= 9, the chain entropy bound suffices.
small = GLO + (1 - GHI) * F(8, 81) / log_interval(F(9))[1]
assert small > F(2, 5)

# Exclude p <= .39 in the two indicated ranges.
middle = frequency_lower(F(61, 100), F(8, 81), 100000, F(1, 100))
large = frequency_lower(F(61, 100), LOG2[0] - F(1, 2) - F(3, 100000),
                        2600000000, F(1, 10**10))
assert middle > F(39, 100)
assert large > F(39, 100)

# At N=1000, exclude at most 406 occurrences.
thousand = frequency_lower(F(594, 1000), LOG2[0] - F(1, 2) - F(3, 1000),
                           1000, F(1, 10**6))
assert thousand > F(406, 1000)

# Simple base-case bound for sN <= 1, N >= 2. Here gamma < .4.
assert F(19, 100) + (2 * F(2, 5)**4 * F(1, 4)
                      / (1 - F(7, 5)**2 / 4)) < 1

result = {
    "arithmetic": "fractions.Fraction only; logarithm series with proven remainder",
    "terms_per_logarithm": 32,
    "coefficient": "19/100",
    "gamma_enclosure": [str(GLO), str(GHI)],
    "scalar_intervals": rows,
    "frequency_lower_bounds_strictly_exceed": {
        "2_to_9": floor_decimal(small),
        "10_to_100000_if_p_le_0.39": floor_decimal(middle),
        "100000_to_2600000000_if_p_le_0.39": floor_decimal(large),
        "N_1000_if_p_le_0.406": floor_decimal(thousand)},
    "status": "all rational assertions passed"
}
print(json.dumps(result, indent=2))
(Path(__file__).resolve().parents[1] / "data" / "entropy_certificate.json").write_text(
    json.dumps(result, indent=2) + "\n")
