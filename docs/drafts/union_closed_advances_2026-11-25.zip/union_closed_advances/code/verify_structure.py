#!/usr/bin/env python3
"""Independent exact checks for the local coefficient and construction.

No third-party packages are required.  Assertions use integers and
fractions, not numerical tolerances.  Exhaustive enumeration is limited
to the named finite examples with at most 15 vertices.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from fractions import Fraction
from itertools import combinations
import json
from pathlib import Path


def inspect_hypergraph(edges, n, r, d):
    edges = [frozenset(e) for e in edges]
    assert len(edges) == len(set(edges))
    assert all(len(e) == r for e in edges)
    incident = [[] for _ in range(n)]
    for i, e in enumerate(edges):
        for v in e:
            assert 0 <= v < n
            incident[v].append(i)
    assert all(len(a) == d for a in incident)
    shared = [dict() for _ in edges]
    vertex_neighbors = [set() for _ in range(n)]
    for v, ids in enumerate(incident):
        for i, j in combinations(ids, 2):
            assert j not in shared[i], "Two distinct edges share two vertices"
            shared[i][j] = v
            shared[j][i] = v
    for e in edges:
        for v in e:
            vertex_neighbors[v].update(e - {v})
    assert all(len(a) == (r-1)*d for a in vertex_neighbors)
    berge_triangles = 0
    concurrent_triangles = 0
    for i, adj in enumerate(shared):
        for j, ell in combinations(sorted(x for x in adj if x > i), 2):
            if ell not in shared[j]:
                continue
            if len({shared[i][j], shared[i][ell], shared[j][ell]}) == 3:
                berge_triangles += 1
            else:
                assert shared[i][j] == shared[i][ell] == shared[j][ell]
                concurrent_triangles += 1
    assert concurrent_triangles == n*d*(d-1)*(d-2)//6

    k = r-1
    a = 1-Fraction(1, 2**k)
    t = (1-Fraction(1, 2**(k-1)))/a
    maximum = r + Fraction(r*(d-1)*k, 2**k-1)
    local = []
    for e in edges:
        multiplicities = Counter()
        for u in e:
            for v in vertex_neighbors[u] - e:
                multiplicities[v] += 1
        assert sum(multiplicities.values()) == r*(d-1)*k
        coeff = r+sum((1-t**c for c in multiplicities.values()), Fraction())
        assert coeff <= maximum
        assert (coeff == maximum) == all(c == 1 for c in multiplicities.values())
        local.append((e, multiplicities, coeff, e | set(multiplicities)))
    seen = {0}
    frontier = [0]
    while frontier:
        v = frontier.pop()
        for w in vertex_neighbors[v] - seen:
            seen.add(w)
            frontier.append(w)
    summary = {
        "vertices": n, "edges": len(edges), "edge_size": r, "degree": d,
        "berge_triangles": berge_triangles,
        "concurrent_intersection_triangles": concurrent_triangles,
        "connected": len(seen) == n,
        "local_coefficient_min": str(min(x[2] for x in local)),
        "local_coefficient_max": str(max(x[2] for x in local)),
        "universal_coefficient_max": str(maximum),
    }
    return edges, incident, local, summary


def parabola(r, d, q):
    assert q > max(r, d) and all(q % v for v in range(2, int(q**0.5)+1))
    def vertex(j, y, z):
        return (j*q + y)*q + z
    edges = [
        [vertex(j, (b+j*a) % q, (c+j*a*a) % q) for j in range(r)]
        for a in range(d) for b in range(q) for c in range(q)
    ]
    _, _, _, summary = inspect_hypergraph(edges, r*q*q, r, d)
    assert summary["berge_triangles"] == 0
    assert summary["local_coefficient_min"] == summary["universal_coefficient_max"]
    assert summary["local_coefficient_max"] == summary["universal_coefficient_max"]
    if d >= 3:
        assert summary["connected"]
    summary["q"] = q
    return summary


def star_dual(graph_edges, graph_order):
    return [[i for i, e in enumerate(graph_edges) if v in e]
            for v in range(graph_order)]


def doily():
    pairs = list(combinations(range(6), 2))
    pair_id = {a: i for i, a in enumerate(pairs)}
    def matchings(points):
        if not points:
            yield []
            return
        a = points[0]
        for b in points[1:]:
            rest = [x for x in points if x not in (a, b)]
            for sub in matchings(rest):
                yield [(a,b)] + sub
    return [[pair_id[tuple(sorted(p))] for p in m] for m in matchings(list(range(6)))]


def finite_law_check(name, edges, n, r, d):
    edges, _, local, summary = inspect_hypergraph(edges, n, r, d)
    edge_masks = [sum(1 << v for v in e) for e in edges]
    k_masks = [sum(1 << v for v in x[3]) for x in local]
    m = len(edges)
    total = 1 << n
    forced_total = 1 << (n-r)
    bad_counts = [0]*n
    forced_bad_counts = [[0]*n for _ in range(m)]
    good_count = 0
    forced_good_counts = [0]*m
    dj_counts = [0]*m
    forced_dj_counts = [0]*m
    q_numerators = [0]*m
    forced_q_numerators = [0]*m
    for mask in range(total):
        supported = 0
        for e in edge_masks:
            if mask & e == e:
                supported |= e
        bad = mask & ~supported
        bad_vertices = [v for v in range(n) if bad >> v & 1]
        for v in bad_vertices:
            bad_counts[v] += 1
        if not bad:
            good_count += 1
        for i, (em, km) in enumerate(zip(edge_masks, k_masks)):
            forced = (mask & em == em)
            if forced:
                for v in bad_vertices:
                    forced_bad_counts[i][v] += 1
                if not bad:
                    forced_good_counts[i] += 1
            if not bad & ~km:
                dj_counts[i] += 1
                q_numerators[i] += bool(bad & km)
                if forced:
                    forced_dj_counts[i] += 1
                    forced_q_numerators[i] += bool(bad & km)
    a = 1-Fraction(1, 2**(r-1))
    p = a**d/2
    t = (1-Fraction(1, 2**(r-2)))/a
    assert all(Fraction(c,total) == p for c in bad_counts)
    frequencies = []
    for i, (e, multiplicities, coeff, K) in enumerate(local):
        for v in range(n):
            expected = 0 if v in e else p*t**multiplicities.get(v, 0)
            assert Fraction(forced_bad_counts[i][v], forced_total) == expected
        assert Fraction(dj_counts[i],total) == Fraction(forced_dj_counts[i],forced_total)
        q0 = Fraction(q_numerators[i],dj_counts[i])
        q1 = Fraction(forced_q_numerators[i],forced_dj_counts[i])
        missing = Fraction(forced_good_counts[i], good_count)
        assert missing == Fraction(1, 2**r)*(1-q1)/(1-q0)
        difference = sum((p-Fraction(forced_bad_counts[i][v],forced_total) for v in K), Fraction())
        assert difference == p*coeff
        assert missing >= Fraction(1,2**r)
        frequencies.append(1-missing)
    summary.update({
        "name": name, "enumerated_vertex_subsets": total,
        "distinct_edge_unions": good_count,
        "star_union_frequency_min": str(min(frequencies)),
        "star_union_frequency_max": str(max(frequencies)),
        "exact_probabilities_and_bayes_identity": "passed",
    })
    return summary


def main():
    construction_cases = [(3,1,5),(3,2,5),(3,3,5),(3,4,5),(3,5,7),
                          (4,3,5),(4,4,5),(4,5,7),(5,4,7)]
    constructions = [parabola(*case) for case in construction_cases]
    tetra = list(combinations(range(4),2))
    bipartite = [(a,b) for a in range(3) for b in range(3,6)]
    fano = sorted({tuple(sorted((a-1,b-1,(a^b)-1)))
                   for a in range(1,8) for b in range(a+1,8)})
    affine = [[3*x+(a*x+b)%3 for x in range(3)] for a in range(3) for b in range(3)]
    affine += [[3*b+y for y in range(3)] for b in range(3)]
    exact = [
        finite_law_check("dual_of_K4", star_dual(tetra,4), 6,3,2),
        finite_law_check("dual_of_K3_3", star_dual(bipartite,6), 9,3,2),
        finite_law_check("Fano_plane", fano, 7,3,3),
        finite_law_check("GQ_2_2_doily", doily(), 15,3,3),
        finite_law_check("affine_plane_order_3", affine, 9,3,4),
    ]
    result = {"status": "all assertions passed",
              "method": "integer incidence checks and exhaustive exact-rational probability checks",
              "construction_checks": constructions, "finite_law_checks": exact}
    destination = (Path(__file__).resolve().parents[1] / "data" / "structure_verification.json")
    destination.write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))


if __name__ == "__main__":
    main()
