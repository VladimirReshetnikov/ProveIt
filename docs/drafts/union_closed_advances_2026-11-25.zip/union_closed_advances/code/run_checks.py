#!/usr/bin/env python3
"""Run the research certificates and independent finite audits."""
from pathlib import Path
import json
import subprocess
import sys


def main():
    root = Path(__file__).resolve().parents[1]
    (root / 'data').mkdir(exist_ok=True)
    jobs = [
        ('verify_ranked_constants.py', 'ranked_constant_checks.json', 'exact rational certificate'),
        ('certify_entropy.py', 'entropy_certificate.json', 'exact rational certificate'),
        ('verify_structure.py', 'structure_verification.json', 'exact combinatorial and rational checks'),
        ('audit_entropy.py', 'entropy_audit.json', 'exhaustive finite sanity audit'),
        ('audit_ranked.py', 'ranked_audit.json', 'exhaustive finite sanity audit'),
    ]
    results = []
    for script, destination, kind in jobs:
        proc = subprocess.run([sys.executable, str(root/'code'/script)],
                              cwd=root, text=True, capture_output=True)
        if proc.returncode:
            sys.stderr.write(proc.stdout+proc.stderr)
            raise SystemExit(f'{script} failed with exit code {proc.returncode}')
        parsed = json.loads(proc.stdout)
        (root/'data'/destination).write_text(json.dumps(parsed, indent=2)+'\n')
        results.append({'script': script, 'kind': kind, 'status': 'passed',
                        'result': 'data/'+destination})
        print(f'PASS {script}', flush=True)
    summary = {'status': 'all five programs passed', 'checks': results,
               'external_dependency': 'Costa-Sadhu Proposition 6.3 is cited, not recertified here',
               'formalization': 'No Lean or Rocq formalization is claimed'}
    (root/'data'/'reproduction_summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print('Saved data/reproduction_summary.json')


if __name__ == '__main__':
    main()
