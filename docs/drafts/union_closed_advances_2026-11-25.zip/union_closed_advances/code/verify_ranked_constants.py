#!/usr/bin/env python3
"""Exact-rational checks for explicit ranked-frequency coefficients.

The analytic proof gives
  J_u >= ((c-u)*ln(N) + kappa*D_N)/M(u),
where M(u)=max_{u<=t<=1}(t-u)h(t).

This script bounds M(u) from above by a tangent to binary entropy at a
rational r. It uses Fraction arithmetic and an explicit logarithm series
with a proved tail bound, with no floating-point inference in assertions.
Decimal output is for readability only. No third-party packages required.
"""

from fractions import Fraction as F
from decimal import Decimal, localcontext
import json


class Interval:
    def __init__(self, lo, hi=None):
        self.lo = F(lo)
        self.hi = F(lo if hi is None else hi)
        assert self.lo <= self.hi

    def __add__(self, other):
        other = as_interval(other)
        return Interval(self.lo + other.lo, self.hi + other.hi)

    __radd__ = __add__

    def __neg__(self):
        return Interval(-self.hi, -self.lo)

    def __sub__(self, other):
        return self + -as_interval(other)

    def __rsub__(self, other):
        return as_interval(other) + -self

    def __mul__(self, other):
        other = as_interval(other)
        v = [self.lo * other.lo, self.lo * other.hi,
             self.hi * other.lo, self.hi * other.hi]
        return Interval(min(v), max(v))

    __rmul__ = __mul__

    def __truediv__(self, other):
        other = as_interval(other)
        assert not other.lo <= 0 <= other.hi
        return self * Interval(1 / other.hi, 1 / other.lo)


def as_interval(x):
    return x if isinstance(x, Interval) else Interval(x)


def log_interval(x, terms=120):
    """ln x = 2 sum_{j>=0} z^(2j+1)/(2j+1), z=(x-1)/(x+1).

    If k terms are retained, the absolute remainder is bounded by
    2 |z|^(2k+1)/((2k+1)(1-z^2)).
    """
    x = F(x)
    assert x > 0
    z = (x - 1) / (x + 1)
    z2 = z * z
    power = z
    partial = F(0)
    for j in range(terms):
        partial += 2 * power / (2*j + 1)
        power *= z2
    error = 2 * abs(power) / ((2*terms + 1) * (1-z2))
    return Interval(partial - error, partial + error)


def decimal(x, places=24):
    with localcontext() as ctx:
        ctx.prec = places
        return str(Decimal(x.numerator) / Decimal(x.denominator))


def tangent_max_upper(u, r):
    """Concavity: h(t)<=h(r)+h'(r)(t-r).

    Since r>1/2, this yields the global quadratic upper bound
    M(u)<= [h(r)-(r-u)h'(r)]^2/(-4h'(r)).
    """
    assert F(1, 2) < r < 1 and 0 <= u < 1
    hr = -r * log_interval(r) - (1-r) * log_interval(1-r)
    hp = log_interval((1-r)/r)
    assert hp.hi < 0
    numerator = hr - (r-u)*hp
    assert numerator.lo > 0
    upper = numerator*numerator / (-4*hp)
    return upper.hi


def main():
    m = F(3085573725166011, 5000000000000000)
    c = 1 - m
    kappa = F(1, 2) + m/F(800000000)
    l2 = log_interval(2)
    # Each r is close to the unique exact maximizer of (t-u)h(t).
    # The asserted rational coefficient lies below (c-u)*ln(2)/M(u).
    cases = [
        (F(382,1000), F(157,200), F(2925,1000000)),
        (F(3825,10000), F(78485,100000), F(1274,1000000)),
        (F(3828,10000), F(78493,100000), F(2822,10000000)),
        (F(38288,100000), F(78495,100000), F(1738,100000000)),
    ]
    output = []
    for u, r, certified in cases:
        upper = tangent_max_upper(u, r)
        coefficient_lower = (c-u)*l2.lo / upper
        assert coefficient_lower > certified
        # All arithmetic in this check is exact, including the test above.
        output.append({
            "threshold": str(u),
            "tangent_point": str(r),
            "M_upper_approx": decimal(upper),
            "coefficient_lower_approx": decimal(coefficient_lower),
            "certified_coefficient_of_log2_N": str(certified),
            "status": "proved by exact-rational interval arithmetic",
        })
    # sqrt(5)>559/250=2.236, since (559/250)^2<5.
    assert F(559,250)**2 < 5
    assert (3-F(559,250))/2 == F(382,1000)
    print(json.dumps({
        "source_constants": {"m": str(m), "c": str(c), "kappa": str(kappa)},
        "checks": output,
    }, indent=2))


if __name__ == "__main__":
    main()
