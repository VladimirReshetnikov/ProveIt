#!/usr/bin/env python3
"""Exhaustive four-coordinate sanity audit of the weighted/profile inequalities.

The universal proof is in the manuscript. This audit uses floating-point
entropy calculations and is not a numerical proof of those theorems.
Closure, frequencies, and representation counts are computed with integers.
Only the Python standard library is required.
"""
from collections import Counter
from itertools import permutations
from math import log
from pathlib import Path
import json


def h(p):
    return 0.0 if p in (0, 1) else -p*log(p)-(1-p)*log(1-p)


def main():
    c = 1914426274833989 / 5000000000000000
    kappa = 0.5 + (1-c) / 800000000
    orders = tuple(permutations(range(4)))
    count = 0
    order_count = 0
    minimum_weighted = float('inf')
    minimum_profile = float('inf')
    thresholds = (0.0, 0.1, 0.2, 0.3, 0.382, 0.3825, 0.3828, 0.38288, 0.5)
    for mask in range(1 << 16):
        if mask.bit_count() < 2:
            continue
        family = [a for a in range(16) if mask & (1 << a)]
        if any(not mask & (1 << (a | b)) for a in family for b in family):
            continue
        count += 1
        n = len(family)
        ln_n = log(n)
        degrees = [sum(bool(a & (1 << i)) for a in family) for i in range(4)]
        frequencies = [d/n for d in degrees]
        representations = Counter(a | b for a in family for b in family)
        assert sum(representations.values()) == n*n
        union_entropy = 2*ln_n-sum(v*log(v) for v in representations.values())/(n*n)
        delta = ln_n-union_entropy
        dn = sum((2*j-1)*log((2*j-1)/n) for j in range(1,n+1))/(n*n)
        assert delta >= dn-1e-12
        projected_entropies = []
        for coordinates in range(16):
            counts = Counter(a & coordinates for a in family)
            projected_entropies.append(ln_n-sum(v*log(v) for v in counts.values())/n)
        target = c*ln_n+kappa*delta
        for order in orders:
            used = 0
            weighted = 0.0
            for i in order:
                after = used | (1 << i)
                hi = projected_entropies[after]-projected_entropies[used]
                assert hi >= -1e-12
                weighted += frequencies[i]*hi
                used = after
            slack = weighted-target
            assert slack >= -1e-12
            minimum_weighted = min(minimum_weighted, slack)
            order_count += 1
        for u in thresholds:
            left = sum((p-u)*h(p) for p in frequencies if p > u)
            slack = left-((c-u)*ln_n+kappa*delta)
            assert slack >= -1e-12
            minimum_profile = min(minimum_profile, slack)
    assert count == 4943
    assert order_count == 118632
    result = {
        'status': 'all integer checks and floating-point sanity comparisons passed',
        'families': count,
        'coordinate_orders': order_count,
        'profile_thresholds': list(thresholds),
        'minimum_weighted_slack_float': minimum_weighted,
        'minimum_profile_slack_float': minimum_profile,
        'limitation': 'finite sanity audit; universal proofs and exact scalar certificates are separate',
    }
    destination = Path(__file__).resolve().parents[1] / 'data' / 'ranked_audit.json'
    destination.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
