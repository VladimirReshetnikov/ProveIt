#!/usr/bin/env python3
"""Independent exhaustive four-point numerical audit, not the proof.

Union closure and the four trace-class masses are checked exactly.
Entropy comparisons use ordinary floating point and are only error checks.
"""
from collections import Counter
import json
import math
from pathlib import Path

gamma = (3 - math.sqrt(5)) / 2


def entropy(counts, total):
    return -sum((x / total) * math.log(x / total) for x in counts if x)


def gap(family):
    n = len(family)
    counts = Counter(a | b for a in family for b in family)
    return (entropy(range(1, 2*n, 2), n*n)
            - entropy(counts.values(), n*n))


def Q(s):
    j = 1 - (1 + gamma)**2 * s*s
    d = 2 * gamma*gamma * s*s
    return (j + d) * math.log1p(d / j) - d


def F(q):
    return ((2*q-q*q)*math.log((2-q)/(2+q))
            + 4*q*q - 2*q*math.log1p(q))


checked = recurrence_checked = 0
min_stability_slack = 100.0
min_recurrence_slack = 100.0
for mask in range(1, 1 << 16):
    family = tuple(a for a in range(16) if (mask >> a) & 1)
    if len(family) < 2:
        continue
    if any(not ((mask >> (a | b)) & 1) for a in family for b in family):
        continue
    n = len(family)
    frequencies = [sum(bool(a & (1 << x)) for a in family) for x in range(4)]
    x = max(range(4), key=frequencies.__getitem__)
    p = frequencies[x] / n
    s = 1 - p
    e = gap(family)
    slack = e - (.19 * s*s + Q(s) - 1 / (n*n))
    assert slack > -2e-13, (family, slack)
    min_stability_slack = min(min_stability_slack, slack)
    checked += 1
    f0 = tuple(a for a in family if not (a & (1 << x)))
    if len(f0) < 2:
        continue
    local_frequency = [sum(bool(a & (1 << y)) for a in f0) for y in range(4)]
    y = max(range(4), key=local_frequency.__getitem__)
    q = local_frequency[y] / len(f0)
    assert x != y
    classes = Counter((bool(a & (1 << x)), bool(a & (1 << y))) for a in family)
    a = classes[(True, False)]
    b = classes[(False, True)]
    c = classes[(False, False)]
    assert a >= b and b > 0 and classes[(True, True)] > 0
    union_classes = Counter((bool((u | v) & (1 << x)), bool((u | v) & (1 << y)))
                            for u in family for v in family)
    assert union_classes[(False, False)] == c*c
    assert union_classes[(False, True)] == (b+c)**2-c*c
    assert union_classes[(True, False)] == (a+c)**2-c*c
    assert union_classes[(True, True)] == n*n-(a+b+c)**2+2*a*b
    j = 1 - (1 + q)**2 * s*s
    delta = 2*q*q*s*s
    if j <= 0 and j > -1e-14:
        raise AssertionError("A nonempty 11 block requires strictly positive J(q).")
    R = (j+delta)*math.log1p(delta/j)-delta
    rs = e - (s*s*(F(q) + gap(f0)) + R)
    assert rs > -2e-13, (family, rs)
    min_recurrence_slack = min(min_recurrence_slack, rs)
    recurrence_checked += 1

result = {
    "ground_set_size": 4,
    "families_checked": checked,
    "recurrences_checked": recurrence_checked,
    "minimum_stability_slack_float": min_stability_slack,
    "minimum_recurrence_slack_float": min_recurrence_slack,
    "status": "all exact class-count assertions and floating-point sanity checks passed",
    "limitation": "not a formal or interval proof of the entropy inequalities"
}
print(json.dumps(result, indent=2))
(Path(__file__).resolve().parents[1] / "data" / "entropy_audit.json").write_text(json.dumps(result, indent=2) + "\n")
