#!/bin/sh
set -eu
cd "$(dirname "$0")"
lean_exe="${LEAN_BIN:-lean}"
"$lean_exe" --version
"$lean_exe" formal/ReducedGuard.lean
"$lean_exe" formal/ProductObstruction.lean
python3 artifacts/schema_comparison.py --output /tmp/pra_guarded_propagation_schema_check.json
python3 - <<'PY'
import json
from pathlib import Path
expected = json.loads(Path('artifacts/schema_comparison.json').read_text())
actual = json.loads(Path('/tmp/pra_guarded_propagation_schema_check.json').read_text())
assert expected == actual, 'Recorded and recomputed syntax counts differ'
print('Recorded and recomputed syntax counts agree.')
PY
