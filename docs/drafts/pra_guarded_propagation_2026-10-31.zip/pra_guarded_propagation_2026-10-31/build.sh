#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build pra_guarded_propagation.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build pra_guarded_propagation.tex
cp build/pra_guarded_propagation.pdf pra_guarded_propagation.pdf
