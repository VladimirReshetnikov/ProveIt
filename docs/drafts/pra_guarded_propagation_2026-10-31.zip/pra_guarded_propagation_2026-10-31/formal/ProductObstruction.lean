/-
  A scoped certificate for the product obstruction to atomic induction.
  Tested with Lean 4.19.0, using only Lean's implicit Init import.

  Scope: the file proves atomic equation induction for arbitrary
  coordinatewise maps Nat x Nat -> Nat x Nat, and exhibits a single
  quantifier-free induction instance that fails for the componentwise
  zero/successor/predecessor structure.  It does not formalize the
  syntax or interpretation of every primitive-recursive description.

  The bridge to such a syntax is the elementary structural fact that
  terms made from componentwise functions evaluate componentwise.
  Fixed parameters are absorbed into the four unary functions below.
-/

namespace PRAProductObstruction

/-- A rectangular subset of Nat x Nat that contains zero and is closed
    under simultaneous successor must be the whole product. -/
theorem rectangular_induction
    (A B : Nat → Prop)
    (base : A 0 ∧ B 0)
    (step : ∀ x y, A x ∧ B y → A (Nat.succ x) ∧ B (Nat.succ y)) :
    ∀ x y, A x ∧ B y := by
  have left_all : ∀ x, A x := by
    intro x
    induction x with
    | zero => exact base.1
    | succ x ih => exact (step x 0 ⟨ih, base.2⟩).1
  have right_all : ∀ y, B y := by
    intro y
    induction y with
    | zero => exact base.2
    | succ y ih => exact (step 0 y ⟨base.1, ih⟩).2
  intro x y
  exact ⟨left_all x, right_all y⟩

/-- Atomic equation induction holds for every pair of coordinatewise
    maps, not just for maps represented by primitive-recursive terms. -/
theorem product_atomic_equation_induction
    (f₁ g₁ f₂ g₂ : Nat → Nat)
    (base : (f₁ 0, f₂ 0) = (g₁ 0, g₂ 0))
    (step : ∀ z : Nat × Nat,
      (f₁ z.1, f₂ z.2) = (g₁ z.1, g₂ z.2) →
      (f₁ (Nat.succ z.1), f₂ (Nat.succ z.2)) =
        (g₁ (Nat.succ z.1), g₂ (Nat.succ z.2))) :
    ∀ z : Nat × Nat, (f₁ z.1, f₂ z.2) = (g₁ z.1, g₂ z.2) := by
  have all_coordinates := rectangular_induction
    (fun x => f₁ x = g₁ x) (fun y => f₂ y = g₂ y)
    ⟨congrArg Prod.fst base, congrArg Prod.snd base⟩
    (by
      intro x y h
      have successor_equality := step (x, y) (Prod.ext h.1 h.2)
      exact ⟨congrArg Prod.fst successor_equality,
        congrArg Prod.snd successor_equality⟩)
  intro z
  exact Prod.ext (all_coordinates z.1 z.2).1
    (all_coordinates z.1 z.2).2

def zero : Nat × Nat := (0, 0)

def succ (z : Nat × Nat) : Nat × Nat :=
  (Nat.succ z.1, Nat.succ z.2)

def pred (z : Nat × Nat) : Nat × Nat :=
  (Nat.pred z.1, Nat.pred z.2)

theorem pred_zero : pred zero = zero := rfl

theorem pred_succ (z : Nat × Nat) : pred (succ z) = z := by
  cases z
  rfl

theorem zero_ne_one : zero ≠ succ zero := by
  intro h
  have impossible : (0 : Nat) = 1 := congrArg Prod.fst h
  cases impossible

theorem successor_nonzero (z : Nat × Nat) : succ z ≠ zero := by
  intro h
  have impossible : Nat.succ z.1 = 0 := congrArg Prod.fst h
  cases impossible

theorem successor_injective (x y : Nat × Nat)
    (h : succ x = succ y) : x = y := by
  exact Prod.ext (Nat.succ.inj (congrArg Prod.fst h))
    (Nat.succ.inj (congrArg Prod.snd h))

/-- The usual quantifier-free predecessor-coverage formula. -/
def Covered (z : Nat × Nat) : Prop :=
  z = zero ∨ z = succ (pred z)

theorem covered_zero : Covered zero := Or.inl rfl

theorem covered_successor (z : Nat × Nat) : Covered (succ z) := by
  apply Or.inr
  rw [pred_succ]

theorem mixed_point_not_covered : ¬ Covered (0, 1) := by
  intro h
  cases h with
  | inl h =>
      have impossible : (1 : Nat) = 0 := congrArg Prod.snd h
      cases impossible
  | inr h =>
      have impossible : (0 : Nat) = 1 := congrArg Prod.fst h
      cases impossible

theorem coverage_fails : ¬ (∀ z, Covered z) := by
  intro h
  exact mixed_point_not_covered (h (0, 1))

/-- A concrete failure of quantifier-free induction, despite the
    general atomic equation-induction theorem above. -/
theorem quantifier_free_induction_instance_fails :
    ¬ ((Covered zero ∧ ∀ z, Covered z → Covered (succ z)) →
      ∀ z, Covered z) := by
  intro induction_instance
  apply coverage_fails
  exact induction_instance
    ⟨covered_zero, fun z _ => covered_successor z⟩

end PRAProductObstruction

#print axioms PRAProductObstruction.product_atomic_equation_induction
#print axioms PRAProductObstruction.quantifier_free_induction_instance_fails
