/-!
# Primitive recursive arithmetic from the reduced successor guard

Lean 4.19.0, Init only. No classical reasoning or choice is used.

The varying expressions in every arithmetic schema are finite terms with
exactly two available variables: the index and one fixed parameter. They
are not arbitrary semantic functions. Arbitrary binary function symbols
can be instantiated with the well-founded seeded recursion descriptions
specified in the accompanying paper. The displayed predecessor constructor
is shorthand for the admitted description P(0,a)=a, P(Sn,a)=n at a=0.

The new schema removes the old condition f(0,a)=0 entirely:

  [forall n, (n=0 or f(n,a)=S(g(n,a))) -> f(Sn,a)=S(g(Sn,a))]
    -> [0 != S(g(0,a)) and forall n, n=0 or f(n,a)=S(g(n,a))].

This certificate verifies the local logical reduction, constructor laws,
one-parameter equation induction, and equivalence with separation plus
the earlier guarded-equation schema. It also verifies the converse from
quantifier-free induction, represented by an actual finite formula syntax.

For comparison it includes the compact package K, which puts the separate
separation axiom in the conclusion of the earlier guarded-equation schema.
This is a logical repackaging, not a claim of a new arithmetic principle.

Scope: this file does not formalize a first-order proof calculus, primitive
recursive description generation, the arithmetic comparator and pairing
bootstrap, or the final conservative definitional-extension theorem. These
are mathematical proofs in the paper. No theorem below assumes a decision
procedure for equality of elements of the arbitrary carrier.
-/

namespace ReducedGuard

universe u v

inductive Var where
  | index
  | parameter
  deriving DecidableEq

inductive Term (Fn : Type u) where
  | var : Var → Term Fn
  | zero : Term Fn
  | succ : Term Fn → Term Fn
  | pred : Term Fn → Term Fn
  | app : Fn → Term Fn → Term Fn → Term Fn

structure Algebra (Fn : Type u) where
  Carrier : Type v
  zero : Carrier
  succ : Carrier → Carrier
  pred : Carrier → Carrier
  app : Fn → Carrier → Carrier → Carrier

def Algebra.eval {Fn : Type u} (M : Algebra.{u,v} Fn)
    (n a : M.Carrier) : Term Fn → M.Carrier
  | .var .index => n
  | .var .parameter => a
  | .zero => M.zero
  | .succ t => M.succ (M.eval n a t)
  | .pred t => M.pred (M.eval n a t)
  | .app f s t => M.app f (M.eval n a s) (M.eval n a t)

structure PredecessorLaws {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop where
  at_zero : M.pred M.zero = M.zero
  at_succ : ∀ n, M.pred (M.succ n) = n

def Premise {Fn : Type u} (M : Algebra.{u,v} Fn)
    (f g : Term Fn) (a : M.Carrier) : Prop :=
  ∀ n, (n = M.zero ∨ M.eval n a f = M.succ (M.eval n a g)) →
    M.eval (M.succ n) a f = M.succ (M.eval (M.succ n) a g)

def Reduced {Fn : Type u} (M : Algebra.{u,v} Fn)
    (f g : Term Fn) (a : M.Carrier) : Prop :=
  Premise M f g a →
  M.zero ≠ M.succ (M.eval M.zero a g) ∧
  ∀ n, n = M.zero ∨ M.eval n a f = M.succ (M.eval n a g)

def Kernel {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop :=
  ∀ (f g : Term Fn) (a : M.Carrier), Reduced M f g a

def Separation {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop :=
  M.zero ≠ M.succ M.zero

def Coverage {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop :=
  ∀ n, n = M.zero ∨ n = M.succ (M.pred n)

theorem separation_and_coverage {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hp : PredecessorLaws M) (hk : Kernel M) :
    Separation M ∧ Coverage M := by
  have hpre : Premise M (.var .index) (.pred (.var .index)) M.zero := by
    intro n _
    change M.succ n = M.succ (M.pred (M.succ n))
    rw [hp.at_succ]
  obtain ⟨hsep, hcov⟩ := hk (.var .index) (.pred (.var .index)) M.zero hpre
  change M.zero ≠ M.succ (M.pred M.zero) at hsep
  rw [hp.at_zero] at hsep
  exact ⟨hsep, hcov⟩

theorem successor_injective {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hp : PredecessorLaws M) {x y : M.Carrier}
    (he : M.succ x = M.succ y) : x = y := by
  have h := congrArg M.pred he
  rw [hp.at_succ, hp.at_succ] at h
  exact h

theorem successor_nonzero {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hp : PredecessorLaws M) (hsep : Separation M) (n : M.Carrier) :
    M.zero ≠ M.succ n := by
  intro he
  have hn : M.zero = n := by
    have h := congrArg M.pred he
    rw [hp.at_zero, hp.at_succ] at h
    exact h
  exact hsep (he.trans (congrArg M.succ hn.symm))

theorem zero_decidable {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hp : PredecessorLaws M) (hk : Kernel M) (n : M.Carrier) :
    n = M.zero ∨ n ≠ M.zero := by
  obtain ⟨hsep, hcov⟩ := separation_and_coverage M hp hk
  rcases hcov n with hz | hs
  · exact Or.inl hz
  · apply Or.inr
    intro hz
    exact successor_nonzero M hp hsep (M.pred n) (hz.symm.trans hs)

def GuardedEquation {Fn : Type u} (M : Algebra.{u,v} Fn)
    (s t : Term Fn) (a : M.Carrier) : Prop :=
  (∀ n, (n = M.zero ∨ M.eval n a s = M.eval n a t) →
    M.eval (M.succ n) a s = M.eval (M.succ n) a t) →
  ∀ n, n = M.zero ∨ M.eval n a s = M.eval n a t

def GuardedEquations {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop :=
  ∀ (s t : Term Fn) (a : M.Carrier), GuardedEquation M s t a

theorem guarded_equations_of_kernel {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hp : PredecessorLaws M) (hk : Kernel M) : GuardedEquations M := by
  intro s t a hstep
  have hpre : Premise M (.succ s) t a := by
    intro n hn
    apply congrArg M.succ
    apply hstep n
    rcases hn with hz | he
    · exact Or.inl hz
    · exact Or.inr (successor_injective M hp he)
  have hall := (hk (.succ s) t a hpre).2
  intro n
  rcases hall n with hz | he
  · exact Or.inl hz
  · exact Or.inr (successor_injective M hp he)

theorem kernel_of_separation_and_guarded_equations {Fn : Type u}
    (M : Algebra.{u,v} Fn) (hp : PredecessorLaws M)
    (hsep : Separation M) (hg : GuardedEquations M) : Kernel M := by
  intro f g a hpre
  exact ⟨successor_nonzero M hp hsep (M.eval M.zero a g),
    hg f (.succ g) a hpre⟩

theorem kernel_iff_separation_and_guarded_equations {Fn : Type u}
    (M : Algebra.{u,v} Fn) (hp : PredecessorLaws M) :
    Kernel M ↔ Separation M ∧ GuardedEquations M := by
  constructor
  · intro hk
    exact ⟨(separation_and_coverage M hp hk).1,
      guarded_equations_of_kernel M hp hk⟩
  · intro h
    exact kernel_of_separation_and_guarded_equations M hp h.1 h.2

def PackedGuard {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop :=
  ∀ (s t : Term Fn) (a : M.Carrier),
    (∀ n, (n = M.zero ∨ M.eval n a s = M.eval n a t) →
      M.eval (M.succ n) a s = M.eval (M.succ n) a t) →
    Separation M ∧ ∀ n, n = M.zero ∨ M.eval n a s = M.eval n a t

theorem packed_guard_iff_separation_and_guarded_equations {Fn : Type u}
    (M : Algebra.{u,v} Fn) :
    PackedGuard M ↔ Separation M ∧ GuardedEquations M := by
  constructor
  · intro hk
    have hsep : Separation M :=
      (hk .zero .zero M.zero (fun _ _ => rfl)).1
    refine ⟨hsep, ?_⟩
    intro s t a hstep
    exact (hk s t a hstep).2
  · intro h s t a hstep
    exact ⟨h.1, h.2 s t a hstep⟩

theorem packed_guard_iff_kernel {Fn : Type u}
    (M : Algebra.{u,v} Fn) (hp : PredecessorLaws M) :
    PackedGuard M ↔ Kernel M :=
  (packed_guard_iff_separation_and_guarded_equations M).trans
    (kernel_iff_separation_and_guarded_equations M hp).symm

def EquationInduction {Fn : Type u} (M : Algebra.{u,v} Fn)
    (s t : Term Fn) (a : M.Carrier) : Prop :=
  M.eval M.zero a s = M.eval M.zero a t →
  (∀ n, M.eval n a s = M.eval n a t →
    M.eval (M.succ n) a s = M.eval (M.succ n) a t) →
  ∀ n, M.eval n a s = M.eval n a t

theorem equation_induction {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hp : PredecessorLaws M) (hk : Kernel M)
    (s t : Term Fn) (a : M.Carrier) : EquationInduction M s t a := by
  intro hbase hstep
  have hguard : ∀ n, (n = M.zero ∨ M.eval n a s = M.eval n a t) →
      M.eval (M.succ n) a s = M.eval (M.succ n) a t := by
    intro n hn
    apply hstep n
    rcases hn with hz | he
    · rw [hz]
      exact hbase
    · exact he
  have hall := guarded_equations_of_kernel M hp hk s t a hguard
  intro n
  rcases hall n with hz | he
  · rw [hz]
    exact hbase
  · exact he

inductive Formula (Fn : Type u) where
  | equal : Term Fn → Term Fn → Formula Fn
  | bottom : Formula Fn
  | and : Formula Fn → Formula Fn → Formula Fn
  | or : Formula Fn → Formula Fn → Formula Fn
  | imp : Formula Fn → Formula Fn → Formula Fn

def Formula.holds {Fn : Type u} (M : Algebra.{u,v} Fn)
    (n a : M.Carrier) : Formula Fn → Prop
  | .equal s t => M.eval n a s = M.eval n a t
  | .bottom => False
  | .and A B => A.holds M n a ∧ B.holds M n a
  | .or A B => A.holds M n a ∨ B.holds M n a
  | .imp A B => A.holds M n a → B.holds M n a

def QuantifierFreeInduction {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop :=
  ∀ (A : Formula Fn) (a : M.Carrier),
    A.holds M M.zero a →
    (∀ n, A.holds M n a → A.holds M (M.succ n) a) →
    ∀ n, A.holds M n a

theorem kernel_of_quantifier_free_induction {Fn : Type u}
    (M : Algebra.{u,v} Fn) (hnonzero : ∀ n, M.zero ≠ M.succ n)
    (hind : QuantifierFreeInduction M) : Kernel M := by
  intro f g a hpre
  let B : Formula Fn := .or (.equal (.var .index) .zero) (.equal f (.succ g))
  have hbase : B.holds M M.zero a := Or.inl rfl
  have hstep : ∀ n, B.holds M n a → B.holds M (M.succ n) a := by
    intro n hn
    exact Or.inr (hpre n hn)
  exact ⟨hnonzero (M.eval M.zero a g), hind B a hbase hstep⟩

#print axioms separation_and_coverage
#print axioms successor_injective
#print axioms successor_nonzero
#print axioms zero_decidable
#print axioms guarded_equations_of_kernel
#print axioms kernel_iff_separation_and_guarded_equations
#print axioms packed_guard_iff_separation_and_guarded_equations
#print axioms packed_guard_iff_kernel
#print axioms equation_induction
#print axioms kernel_of_quantifier_free_induction

end ReducedGuard
