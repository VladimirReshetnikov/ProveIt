PRA BY GUARDED PROPAGATION
Research archive prepared for Vladimir Reshetnikov -- 31 October 2026

READ FIRST
  pra_guarded_propagation.pdf   Complete mathematical report.
  axioms.txt                   Exact axioms without typesetting.

MAIN FINDING
The current seeded-guard draft's premise f(0,a)=0 can be deleted completely
after specifying its factored conclusion directly. The new R schema has
six equality occurrences instead of seven and recovers equation induction
using the direct substitution f=S(s),g=t; no delayed-mask bridge is needed.

For the shortest three-template display, the paper also gives K, which
packages the already-known guarded-equation schema with separation. This
packaging is explicitly distinguished from the new proof simplification.
Both formulations use binary initialized iterators, no passive seed in their
steps, and one fixed numerical parameter in the arithmetic schema.
They are proved equivalent to ordinary PRA separately in classical and
intuitionistic logic, by a complete constructive written proof.

ADDITIONAL OBSTRUCTION
Coordinatewise arithmetic on N x N satisfies all atomic equation-induction
instances and all standard successor laws, but fails predecessor coverage.
Even adding every true universal Horn sentence does not repair it. Thus
atomic induction alone cannot replace the positive guarded schema for the
full first-order equivalence claimed here, even classically.

CONTENTS
  pra_guarded_propagation.tex   Main LaTeX source.
  sections/*.tex               Complete included proof sections.
  formal/ReducedGuard.lean     Scoped syntactic core certificate.
  formal/ProductObstruction.lean
                               Scoped product countermodel certificate.
  formal/verification.txt      Exact verification status and theorem audit.
  lean-toolchain              Lean version used.
  artifacts/schema_comparison.py
                               Reproducible formula syntax counter.
  artifacts/schema_comparison.json
                               Recorded results, including open rows.
  source_audit.json            Six reviewed archives, commit, hashes, scope.
  VALIDATION.txt              Build, proof-check, and document QA status.
  build.sh                   Rebuild the PDF with pdfLaTeX.
  verify.sh                  Recheck Lean files and syntax counts.
  SHA256SUMS                 Checksums of the final archive members.

BUILD
Run from this directory:
  sh build.sh
This needs a normal TeX Live installation with the packages named in the
main source. It runs pdfLaTeX twice and writes temporary build files to build/.

VERIFY
Install or select Lean 4.19.0, then:
  LEAN_BIN=/absolute/path/to/lean sh verify.sh
The Lean files need no external packages. The syntax counter uses Python 3
standard-library modules only. To check file integrity:
  sha256sum -c SHA256SUMS

FORMALIZATION SCOPE
The core certificate uses finite term and formula syntax and does not assume
decidability of equality on its abstract carrier. It verifies the new logical
reduction, not the whole first-order calculus or the complete PRA compiler.
The product certificate verifies coordinatewise atomic induction and the
failed coverage instance. Comparator, pairing, description translation,
conservativity, and the Horn corollary have written proofs in the report.
No claim of a complete Lean formalization is made.

SOURCES
The reviewed ProveIt snapshot is:
  1933ee3d1630a43f96bfe16aeb88a8371b52082e
All six current docs/drafts PRA archives were read. The incoming listing
and README were checked; unrelated incoming ZIPs were not inspected.
The source audit provides exact provenance. No repository change was made.

LIMITS
The improvement is a strict but modest simplification of a supplied basis.
It is not an absolute minimum theorem. The prior one-term schema without
its separate Shift axiom remains open in this report. A section of further
research questions is included.
