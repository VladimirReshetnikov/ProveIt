#!/usr/bin/env python3
"""Count the displayed PRA formula templates in one explicit AST grammar.

Usage: python3 schema_comparison.py --output schema_comparison.json

Each function/placeholder application, variable, constant, equality,
connective, bottom, or quantifier is one node. Negation and XOR are expanded.
The one numerical parameter occurs in every schematic-term application and
its outer universal quantifier is counted. Separate formulas are counted
separately, then added; no artificial conjunction is inserted between them.
Finite program bodies, syntactic admission algorithms, and punctuation are
not counted. The common computation templates are reported separately.

The formulas are direct transcriptions of the archives' axioms.txt files,
with harmless renaming of schematic terms to f,g,t. This is a size check,
not an equivalence proof or an encoding-independent minimality claim.
"""
from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
import json
from pathlib import Path


@dataclass(frozen=True)
class Node:
    tag: str
    children: tuple["Node", ...] = ()


def node(tag, *children):
    return Node(tag, children)


def var(name):
    return node("variable:" + name)


def zero():
    return node("constant:0")


def suc(x):
    return node("function:S", x)


def eq(a, b):
    return node("equality", a, b)


def land(a, b):
    return node("and", a, b)


def lor(a, b):
    return node("or", a, b)


def imp(a, b):
    return node("implies", a, b)


def neg(a):
    return imp(a, node("bottom"))


def iff(a, b):
    return land(imp(a, b), imp(b, a))


def xor(a, b):
    return land(lor(a, b), neg(land(a, b)))


def all_(name, body):
    # Binder names are metadata; the quantifier is one node.
    return node("forall:" + name, body)


def close(body, parameters):
    for parameter in reversed(parameters):
        body = all_(parameter.tag.removeprefix("variable:"), body)
    return body


def templates(kind, parameter_count=1):
    n = var("n")
    a = tuple(var("a" + str(i)) for i in range(parameter_count))

    def f(x):
        return node("placeholder:f", x, *a)

    def g(x):
        return node("placeholder:g", x, *a)

    def t(x):
        return node("placeholder:t", x, *a)

    def e(x):
        return eq(f(x), suc(g(x)))

    def plain(x):
        return eq(f(x), g(x))

    def guarded(x):
        return lor(eq(x, zero()), e(x))

    def plain_guarded(x):
        return lor(eq(x, zero()), plain(x))

    sep = neg(eq(zero(), suc(zero())))
    x, y = var("x"), var("y")

    def monus(u, v):
        return node("fixed_function:M", u, v)

    shift = all_("x", all_("y", eq(monus(suc(x), suc(y)), monus(x, y))))
    shift_zero = all_("x", all_("y", iff(
        eq(monus(suc(x), suc(y)), zero()), eq(monus(x, y), zero()))))

    if kind == "exclusive_X":
        def b(x):
            return lor(eq(f(x), zero()), e(x))
        return (close(imp(
            land(b(zero()), all_("n", imp(b(n), b(suc(n))))),
            all_("n", xor(eq(f(n), zero()), e(n)))), a),)

    if kind in {"guarded_successor_Y1", "seeded_guard_A", "reduced_guard_R", "grounded_successor_R0"}:
        premise = all_("n", imp(guarded(n), e(suc(n))))
        if kind in {"guarded_successor_Y1", "seeded_guard_A"}:
            premise = land(eq(f(zero()), zero()), premise)
        if kind == "guarded_successor_Y1":
            conclusion = all_("n", xor(eq(n, zero()), e(n)))
        else:
            exclusion = sep if kind == "grounded_successor_R0" else neg(eq(zero(), suc(g(zero()))))
            conclusion = land(exclusion,
                              all_("n", guarded(n)))
        return (close(imp(premise, conclusion), a),)

    if kind in {"guarded_G_plus_Sep", "prescribed_initial_XOR", "packed_G_K"}:
        premise = all_("n", imp(plain_guarded(n), plain(suc(n))))
        conclusion = all_("n", plain_guarded(n))
        if kind == "prescribed_initial_XOR":
            conclusion = all_("n", xor(eq(n, zero()), plain(n)))
        elif kind == "packed_G_K":
            conclusion = land(sep, conclusion)
        result = close(imp(premise, conclusion), a)
        return (result, sep) if kind == "guarded_G_plus_Sep" else (result,)

    if kind.startswith("one_term_X"):
        positive = lor(eq(n, zero()), eq(n, suc(t(n))))
        premise = all_("n", imp(positive, eq(n, t(suc(n)))))
        conclusion = all_("n", xor(eq(n, zero()), eq(n, suc(t(n)))))
        result = close(imp(premise, conclusion), a)
        if kind == "one_term_X_plus_Shift":
            return result, shift
        if kind == "one_term_X_plus_Shift0":
            return result, shift_zero
        if kind == "one_term_X_alone_unresolved":
            return (result,)
        raise ValueError(kind)

    if kind == "one_term_Gid_plus_Sep_Shift":
        positive = lor(eq(n, zero()), eq(n, t(n)))
        premise = all_("n", imp(positive, eq(suc(n), t(suc(n)))))
        return close(imp(premise, all_("n", positive)), a), sep, shift

    raise ValueError(kind)


def count(tree):
    result = Counter({tree.tag: 1})
    for child in tree.children:
        result.update(count(child))
    return result


def summarize(trees):
    result = Counter()
    separate = []
    for tree in trees:
        current = count(tree)
        result.update(current)
        separate.append(sum(current.values()))
    return {
        "formula_templates": len(trees),
        "equality_occurrences": result["equality"],
        "schematic_term_applications": sum(v for k, v in result.items()
                                          if k.startswith("placeholder:")),
        "distinct_schematic_terms": sum(k.startswith("placeholder:")
                                        for k in result),
        "total_ast_nodes": sum(result.values()),
        "separate_formula_sizes": separate,
        "by_node": dict(sorted(result.items())),
    }


SOURCES = {
    "exclusive_X": ["pra_binary_and_one_term", "pra_initial_value"],
    "guarded_successor_Y1": ["pra_guarded_successor"],
    "seeded_guard_A": ["pra_seeded_guard"],
    "reduced_guard_R": ["present_report"],
    "grounded_successor_R0": ["present_report_optional_grounded_form"],
    "guarded_G_plus_Sep": ["pra_initial_value", "pra_seeded_guard"],
    "packed_G_K": ["present_report_packaging_of_existing_G_plus_Sep"],
    "prescribed_initial_XOR": ["pra_prescribed_initial"],
    "one_term_X_plus_Shift": ["pra_binary_and_one_term", "pra_one_term_shift"],
    "one_term_X_plus_Shift0": ["pra_one_term_shift"],
    "one_term_X_alone_unresolved": ["pra_binary_and_one_term", "pra_one_term_shift"],
    "one_term_Gid_plus_Sep_Shift": ["pra_one_term_shift"],
}


def computation_templates():
    n, a = var("n"), var("a")

    def fun(name, *args):
        return node("defined_function:" + name, *args)

    def meta(name, *args):
        return node("placeholder:" + name, *args)

    binary = (
        all_("a", eq(fun("F", zero(), a), meta("g", a))),
        all_("n", all_("a", eq(fun("F", suc(n), a),
            meta("h", n, fun("F", n, a), a)))),
    )
    seeded = (
        all_("a", eq(fun("I", zero(), a), a)),
        all_("n", all_("a", eq(fun("I", suc(n), a),
            meta("h", n, fun("I", n, a))))),
    )
    return {"general_binary_recursion": summarize(binary),
            "seeded_iteration": summarize(seeded)}


def make_report():
    # Independent published full-AST checks from guarded_successor.
    for k in range(4):
        assert summarize(templates("exclusive_X", k))["total_ast_nodes"] == 66 + 16*k
        assert summarize(templates("guarded_successor_Y1", k))["total_ast_nodes"] == 50 + 10*k
        assert summarize(templates("guarded_G_plus_Sep", k))["total_ast_nodes"] == 35 + 7*k
    # Equality and placeholder counts checked against direct formula expansion.
    expected = {
        "exclusive_X": (10, 15),
        "guarded_successor_Y1": (8, 9),
        "seeded_guard_A": (7, 8),
        "reduced_guard_R": (6, 7),
        "grounded_successor_R0": (6, 6),
        "guarded_G_plus_Sep": (6, 6),
        "packed_G_K": (6, 6),
        "prescribed_initial_XOR": (7, 8),
        "one_term_X_plus_Shift": (8, 4),
        "one_term_X_plus_Shift0": (11, 4),
        "one_term_X_alone_unresolved": (7, 4),
        "one_term_Gid_plus_Sep_Shift": (7, 3),
    }
    schemas = {}
    for kind, source in SOURCES.items():
        result = summarize(templates(kind, 1))
        assert (result["equality_occurrences"], result["schematic_term_applications"]) == expected[kind]
        result["sources_archive_prefixes"] = source
        result["numerical_schema_parameters"] = 1
        result["total_templates_with_two_computation_templates"] = result["formula_templates"] + 2
        result["status"] = "unresolved without added bridge" if kind.endswith("unresolved") else "claimed sufficient in cited presentation"
        if kind == "packed_G_K":
            result["novelty_note"] = "Packages the existing G and Sep in one conditional schema; this alone is not a new mathematical reduction."
        if kind == "grounded_successor_R0":
            result["novelty_note"] = "Replaces R's exclusion 0!=Sg(0,a) by ground separation 0!=1."
        schemas[kind] = result
    return {
        "metric": {
            "unit": "one AST node per displayed application, variable, constant, equality, connective, bottom, or quantifier",
            "negation": "A -> bottom",
            "xor": "(A or B) and ((A and B) -> bottom)",
            "iff": "(A -> B) and (B -> A)",
            "parameters": "one fixed parameter in every schematic-term application; its outer universal binder included",
            "binder_names": "metadata only, each binder node counts once",
            "separate_formulas": "sizes are summed without inserting conjunctions",
            "omissions": ["punctuation", "finite bodies substituted for schematic terms", "the prescribed-initial admission checker", "recursor description-name encoding"],
            "warning": "Formula-size comparison only; no absolute minimum or independent proof of the source theories is asserted.",
        },
        "schemas": schemas,
        "computation_templates_counted_separately": computation_templates(),
        "source_snapshot": "1933ee3d1630a43f96bfe16aeb88a8371b52082e",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = make_report()
    rendered = json.dumps(report, indent=2, ensure_ascii=True) + "\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
        for kind, result in report["schemas"].items():
            print(f"{kind}: equalities={result['equality_occurrences']}, "
                  f"term_uses={result['schematic_term_applications']}, "
                  f"AST={result['total_ast_nodes']}")
    else:
        print(rendered, end="")


if __name__ == "__main__":
    main()
