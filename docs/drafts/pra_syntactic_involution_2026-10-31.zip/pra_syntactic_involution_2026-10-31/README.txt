PRA FROM ONE TERM AND A SYNTACTIC INVOLUTION
31 October 2026

Main result
-----------
Classical and intuitionistic PRA have the same arithmetic basis:
the two computation equations for binary initialized iterators, plus a
single arithmetic schema indexed by ONE arbitrary two-variable term.

Its second equation endpoint is obtained by swapping the distinguished
variable n with visible S0 subtrees in the term's finite syntax. This
automatically makes the boundary at 1 reflexive. A closed protected
numeral S(B(0,0)) proves that this restricted family still simulates every
three-variable transposition instance in the latest ProveIt drafts.

The simplification concerns schema generation and term-slot count.
The same 39-node endpoint-template arithmetic formula is retained;
charging the three dagger annotations gives 42 nodes, versus 51 for the
prior unrestricted transposition schema. These metrics exclude actual
substituted term bodies and the syntax algorithm. No absolute minimum
or reduction in the size of every concrete instance is claimed.

Contents
--------
pra_syntactic_involution.pdf   Complete research paper.
pra_syntactic_involution.tex   Main LaTeX source.
sections/completion.tex       Full constructive arithmetic completion.
sections/assessment.tex       Logic conventions, comparison, limits.
axioms.txt                    Exact standalone specification.
formal/DaggerSyntax.lean       New finite-syntax certificate, Lean 4.19.0.
formal/verification.log        Recorded compiler and dependency output.
formal/README.txt              Exact formalization scope.
artifacts/check_involution.py  Independent Python syntax and metric checks.
artifacts/check_results.json   Recorded reproducible finite-check report.
comparison.tsv                Compact comparison table.
source_audit.json              Pinned source paths, hashes, and scope.
VALIDATION.txt                Validation summary and limitations.
SHA256SUMS                    Checksums of delivered files.
build.sh, check.sh             Reproduction scripts.
lean-toolchain                Exact Lean release.

Build
-----
  ./build.sh

This needs a LaTeX distribution with latexmk, amsmath, amsthm, mathtools,
lmodern, microtype, geometry, fancyhdr, booktabs, tabularx, enumitem,
xcolor, xurl, and hyperref.

Check
-----
  python3 artifacts/check_involution.py --report
  LEAN=/path/to/lean-4.19.0/bin/lean ./check.sh

Only Python's standard library is required. The Lean file has no imports
or external package dependencies. The check script says explicitly if
Lean was not run. A successful finite Python check is not presented as
a proof of the equivalence theorem.

Source comparison
-----------------
All four current PRA archives under docs/drafts were read at ProveIt
commit 66372d99e4f4e1d3a48822b9d322ae9e9ae7e7e3. The docs/incoming
inventory and index had no further PRA-labelled report. Unrelated Busy
Beaver archives were not unpacked. No repository changes were made.

The earlier PB0 and Swap equivalence, two-instance arithmetic bootstrap,
native equality reconstruction, and triangular pairing are attributed
to the supplied drafts. The new result is the one-term two-slot
involution family and its protected compiler.

Verification boundary
---------------------
Lean checks the new syntactic reduction over an arbitrary carrier.
The full arithmetic equivalence, including native equality reflection,
tuple coding, and the conservative definitional extension, is supplied
as a written proof in the paper. It is not claimed wholly formalized.

The shorter constant-reference and positive-constancy candidates in the
discussion are explicitly unfinished alternatives, not the delivered basis.
