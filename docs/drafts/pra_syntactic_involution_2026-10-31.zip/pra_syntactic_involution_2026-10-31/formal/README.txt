FINITE-SYNTAX CERTIFICATE
=========================

File: DaggerSyntax.lean
Toolchain: Lean 4.19.0
External dependencies: none; no imports.

What the certificate checks
--------------------------
* Finite term syntax with zero, successor, variable slots, and opaque
  natural-number labels for binary function symbols.
* The simultaneous exchange n <-> S0 is an involution.
* Substitution n:=1 gives literally equal boundary terms.
* The closed shield S(B(0,0)) is fixed by the exchange.
* The protected three-slot-to-two-slot compiler has the exact opposite
  substitution as its dagger.
* A concrete literal-boundary pair belongs to neither orientation of
  the dagger family.
* Arbitrary-carrier semantics of the compiler, requiring only the local
  computation equation B(0,0)=0.
* The finite-term-indexed schema implications PB0 -> Inv and Inv -> Swap.

The arithmetic carrier is arbitrary. No induction on it is available
or used in these proofs. The inductions are structural inductions on
finite syntax. Decidable syntactic equality is used only for syntax;
native equality on the arithmetic carrier is not assumed decidable.

Thirteen printed dependency audits are recorded in verification.log.
Each reports no global axioms. In particular there is no sorryAx,
classical choice, or propositional extensionality dependency. The schema
and local computation assumptions remain explicit theorem hypotheses.

What is outside this certificate
-------------------------------
The implementation does not encode the well-founded iterator-description
registry, a first-order derivation calculus, the inherited Swap-to-PRA
bootstrap, native equality reflection, parameter coding, or the full
conservative-extension theorem. The complete written proof is in the
paper. The Python artifact separately checks a small well-founded
iterator registry and concrete syntactic computations.

Reproduce
---------
  /path/to/lean-4.19.0/bin/lean formal/DaggerSyntax.lean

The release tag is leanprover/lean4:v4.19.0.
