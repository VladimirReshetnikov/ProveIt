/-
Finite-syntax certificate for variable--one duality.
Lean 4.19.0, no imports.

Terms use zero, successor, variable slots, and opaque binary symbol labels.
The syntax transformation NEVER enters a binary symbol's stored description.
Label 0 is reserved here for B = I_[0]. The only semantic equation needed
by the compiler is B(0,0) = 0, an instance of its zero computation equation.

The carrier in the final theorems is arbitrary; induction is used only on
finite term syntax, never on that arithmetic carrier. The two schema
interfaces quantify over these finite terms, not over arbitrary functions.
-/

namespace DaggerSyntax

universe u

inductive Term (V : Type) where
  | zero : Term V
  | var : V → Term V
  | succ : Term V → Term V
  | op : Nat → Term V → Term V → Term V
  deriving DecidableEq

inductive TVar where
  | n
  | a
  deriving DecidableEq

inductive SVar where
  | x
  | y
  | a
  deriving DecidableEq

abbrev TTerm := Term TVar
abbrev STerm := Term SVar

def one {V : Type} : Term V := .succ .zero

def subst {V W : Type} (σ : V → Term W) : Term V → Term W
  | .zero => .zero
  | .var v => σ v
  | .succ t => .succ (subst σ t)
  | .op k s t => .op k (subst σ s) (subst σ t)

def atOne : TVar → TTerm
  | .n => one
  | .a => .var .a

def freeze (t : TTerm) : TTerm := subst atOne t

/-- Simultaneously swap the n leaf and the complete subtree S0. -/
def dagger : TTerm → TTerm
  | .zero => .zero
  | .var .n => one
  | .var .a => .var .a
  | .succ .zero => .var .n
  | .succ t => .succ (dagger t)
  | .op k s t => .op k (dagger s) (dagger t)

theorem dagger_eq_zero_iff (t : TTerm) :
    dagger t = .zero ↔ t = .zero := by
  cases t with
  | zero => exact Iff.rfl
  | var v => cases v <;> constructor <;> intro h <;> cases h
  | succ t => cases t <;> constructor <;> intro h <;> cases h
  | op k s t => constructor <;> intro h <;> cases h

theorem dagger_succ_of_ne_zero (t : TTerm) (h : t ≠ .zero) :
    dagger (.succ t) = .succ (dagger t) := by
  cases t with
  | zero => exact False.elim (h rfl)
  | var v => rfl
  | succ t => rfl
  | op k s t => rfl

theorem dagger_involution (t : TTerm) : dagger (dagger t) = t := by
  induction t with
  | zero => rfl
  | var v => cases v <;> rfl
  | succ t ih =>
      by_cases hz : t = .zero
      · subst t
        rfl
      · have hd : dagger t ≠ .zero := by
          intro h
          exact hz ((dagger_eq_zero_iff t).mp h)
        rw [dagger_succ_of_ne_zero t hz,
          dagger_succ_of_ne_zero (dagger t) hd, ih]
  | op k s t ihs iht =>
      change Term.op k (dagger (dagger s)) (dagger (dagger t)) = Term.op k s t
      rw [ihs, iht]

theorem freeze_dagger (t : TTerm) : freeze (dagger t) = freeze t := by
  induction t with
  | zero => rfl
  | var v => cases v <;> rfl
  | succ t ih =>
      by_cases hz : t = .zero
      · subst t
        rfl
      · rw [dagger_succ_of_ne_zero t hz]
        exact congrArg Term.succ ih
  | op k s t ihs iht =>
      change Term.op k (freeze (dagger s)) (freeze (dagger t)) =
        Term.op k (freeze s) (freeze t)
      rw [ihs, iht]

/-- A protected one. It has no visible S0 and is fixed by dagger. -/
def protectedOne : TTerm := .succ (.op 0 .zero .zero)

theorem dagger_protectedOne : dagger protectedOne = protectedOne := rfl

/-
These two compilers first replace every original visible S0 in H by
protectedOne, then substitute (n,1,a) or (1,n,a) for (x,y,a).
In particular, a one originally present in H is protected; a one inserted
for a distinguished input is deliberately exposed to dagger.
-/

def compileLeft : STerm → TTerm
  | .zero => .zero
  | .var .x => .var .n
  | .var .y => one
  | .var .a => .var .a
  | .succ .zero => protectedOne
  | .succ t => .succ (compileLeft t)
  | .op k s t => .op k (compileLeft s) (compileLeft t)

def compileRight : STerm → TTerm
  | .zero => .zero
  | .var .x => one
  | .var .y => .var .n
  | .var .a => .var .a
  | .succ .zero => protectedOne
  | .succ t => .succ (compileRight t)
  | .op k s t => .op k (compileRight s) (compileRight t)

theorem compileLeft_eq_zero_iff (t : STerm) :
    compileLeft t = .zero ↔ t = .zero := by
  cases t with
  | zero => exact ⟨fun _ => rfl, fun _ => rfl⟩
  | var v => cases v <;> constructor <;> intro h <;> cases h
  | succ t => cases t <;> constructor <;> intro h <;> cases h
  | op k s t => constructor <;> intro h <;> cases h

theorem compileLeft_succ_of_ne_zero (t : STerm) (h : t ≠ .zero) :
    compileLeft (.succ t) = .succ (compileLeft t) := by
  cases t with
  | zero => exact False.elim (h rfl)
  | var v => rfl
  | succ t => rfl
  | op k s t => rfl

theorem compileRight_succ_of_ne_zero (t : STerm) (h : t ≠ .zero) :
    compileRight (.succ t) = .succ (compileRight t) := by
  cases t with
  | zero => exact False.elim (h rfl)
  | var v => rfl
  | succ t => rfl
  | op k s t => rfl

theorem compiler_dagger (t : STerm) :
    dagger (compileLeft t) = compileRight t := by
  induction t with
  | zero => rfl
  | var v => cases v <;> rfl
  | succ t ih =>
      by_cases hz : t = .zero
      · subst t
        rfl
      · have hl : compileLeft t ≠ .zero := by
          intro h
          exact hz ((compileLeft_eq_zero_iff t).mp h)
        rw [compileLeft_succ_of_ne_zero t hz,
          dagger_succ_of_ne_zero (compileLeft t) hl, ih,
          compileRight_succ_of_ne_zero t hz]
  | op k s t ihs iht =>
      change Term.op k (dagger (compileLeft s)) (dagger (compileLeft t)) =
        Term.op k (compileRight s) (compileRight t)
      rw [ihs, iht]

/-- A nontrivial admitted pair outside the exact dagger-indexed subfamily. -/
def witnessLeft : TTerm := .op 1 (.var .n) (.var .n)
def witnessRight : TTerm := .op 1 one (.var .n)

theorem witness_boundary : freeze witnessLeft = freeze witnessRight := rfl

theorem witness_not_dagger : dagger witnessLeft ≠ witnessRight := by decide

theorem witness_not_reverse_dagger : dagger witnessRight ≠ witnessLeft := by decide

structure Algebra (A : Type u) where
  zero : A
  succ : A → A
  op : Nat → A → A → A

def Algebra.one {A : Type u} (C : Algebra A) : A := C.succ C.zero

def eval {A : Type u} (C : Algebra A) {V : Type} (env : V → A) : Term V → A
  | .zero => C.zero
  | .var v => env v
  | .succ t => C.succ (eval C env t)
  | .op k s t => C.op k (eval C env s) (eval C env t)

def targetEnv {A : Type u} (n a : A) : TVar → A
  | .n => n
  | .a => a

def sourceEnv {A : Type u} (x y a : A) : SVar → A
  | .x => x
  | .y => y
  | .a => a

def targetValue {A : Type u} (C : Algebra A) (t : TTerm) (n a : A) : A :=
  eval C (targetEnv n a) t

def sourceValue {A : Type u} (C : Algebra A) (t : STerm) (x y a : A) : A :=
  eval C (sourceEnv x y a) t

variable {A : Type u} (C : Algebra A)

theorem compileLeft_semantics
    (hB : C.op 0 C.zero C.zero = C.zero)
    (t : STerm) (n a : A) :
    targetValue C (compileLeft t) n a = sourceValue C t n C.one a := by
  induction t with
  | zero => rfl
  | var v => cases v <;> rfl
  | succ t ih =>
      by_cases hz : t = .zero
      · subst t
        exact congrArg C.succ hB
      · rw [compileLeft_succ_of_ne_zero t hz]
        exact congrArg C.succ ih
  | op k s t ihs iht =>
      change C.op k (targetValue C (compileLeft s) n a)
          (targetValue C (compileLeft t) n a) =
        C.op k (sourceValue C s n C.one a) (sourceValue C t n C.one a)
      rw [ihs, iht]

theorem compileRight_semantics
    (hB : C.op 0 C.zero C.zero = C.zero)
    (t : STerm) (n a : A) :
    targetValue C (compileRight t) n a = sourceValue C t C.one n a := by
  induction t with
  | zero => rfl
  | var v => cases v <;> rfl
  | succ t ih =>
      by_cases hz : t = .zero
      · subst t
        exact congrArg C.succ hB
      · rw [compileRight_succ_of_ne_zero t hz]
        exact congrArg C.succ ih
  | op k s t ihs iht =>
      change C.op k (targetValue C (compileRight s) n a)
          (targetValue C (compileRight t) n a) =
        C.op k (sourceValue C s C.one n a) (sourceValue C t C.one n a)
      rw [ihs, iht]

def DaggerEquation (f : TTerm) (n a : A) : Prop :=
  targetValue C f n a = targetValue C (dagger f) n a

def SwapEquation (H : STerm) (n a : A) : Prop :=
  sourceValue C H n C.one a = sourceValue C H C.one n a

theorem compiled_equation
    (hB : C.op 0 C.zero C.zero = C.zero)
    (H : STerm) (n a : A) :
    DaggerEquation C (compileLeft H) n a ↔ SwapEquation C H n a := by
  unfold DaggerEquation SwapEquation
  rw [compiler_dagger, compileLeft_semantics C hB, compileRight_semantics C hB]

def DaggerSchema : Prop :=
  ∀ f : TTerm, ∀ a : A,
    (∀ n, DaggerEquation C f n a → DaggerEquation C f (C.succ n) a) →
    C.zero ≠ C.one ∧ ∀ n, n = C.zero ∨ DaggerEquation C f n a

def SwapSchema : Prop :=
  ∀ H : STerm, ∀ a : A,
    (∀ n, SwapEquation C H n a → SwapEquation C H (C.succ n) a) →
    C.zero ≠ C.one ∧ ∀ n, n = C.zero ∨ SwapEquation C H n a

def ReflexiveBaseSchema : Prop :=
  ∀ f g : TTerm, freeze f = freeze g → ∀ a : A,
    (∀ n, targetValue C f n a = targetValue C g n a →
      targetValue C f (C.succ n) a = targetValue C g (C.succ n) a) →
    C.zero ≠ C.one ∧ ∀ n, n = C.zero ∨
      targetValue C f n a = targetValue C g n a

theorem reflexiveBase_implies_dagger (hRB : ReflexiveBaseSchema C) :
    DaggerSchema C := by
  intro f a hstep
  exact hRB f (dagger f) (freeze_dagger f).symm a hstep

theorem dagger_implies_swap
    (hB : C.op 0 C.zero C.zero = C.zero)
    (hD : DaggerSchema C) : SwapSchema C := by
  intro H a hstep
  have hcompiled : ∀ n, DaggerEquation C (compileLeft H) n a →
      DaggerEquation C (compileLeft H) (C.succ n) a := by
    intro n hn
    exact (compiled_equation C hB H (C.succ n) a).mpr
      (hstep n ((compiled_equation C hB H n a).mp hn))
  rcases hD (compileLeft H) a hcompiled with ⟨hsep, hall⟩
  refine ⟨hsep, ?_⟩
  intro n
  rcases hall n with hz | he
  · exact Or.inl hz
  · exact Or.inr ((compiled_equation C hB H n a).mp he)

#print axioms dagger_eq_zero_iff
#print axioms dagger_involution
#print axioms freeze_dagger
#print axioms dagger_protectedOne
#print axioms compiler_dagger
#print axioms witness_boundary
#print axioms witness_not_dagger
#print axioms witness_not_reverse_dagger
#print axioms compileLeft_semantics
#print axioms compileRight_semantics
#print axioms compiled_equation
#print axioms reflexiveBase_implies_dagger
#print axioms dagger_implies_swap

end DaggerSyntax
