#!/usr/bin/env python3
"""Reproducible finite checks for the numeral-transposition PRA schema.

The mathematical structural proofs belong in the accompanying paper.  This
program independently checks finite syntax, a fixed iterator registry, the
compiler, deliberately unsafe operation orders, and the stated formula metric.
Finite checking is not a proof of the complete theory-equivalence theorem.

Run ``python3 check_involution.py --report`` for a deterministic JSON report.
No third-party packages are required.
"""

from __future__ import annotations

import argparse
from functools import lru_cache
import json
import random
from typing import Iterable


# Immutable application trees.  Iterator descriptions are registry entries,
# not children of an application node, and hence remain opaque to dagger.
Term = tuple


def var(name: str) -> Term:
    return ("var", name)


ZERO: Term = ("zero",)
N = var("n")
A = var("a")
X = var("x")
Y = var("y")
STATE = var("v")


def succ(t: Term) -> Term:
    return ("succ", t)


ONE = succ(ZERO)


def app(symbol: str, counter: Term, seed: Term) -> Term:
    return ("iter", symbol, counter, seed)


# Dependency order is material: updates can contain only earlier symbols.
REGISTRY: tuple[tuple[str, Term], ...] = (
    ("P", N),
    ("A", succ(STATE)),
    ("B", ZERO),
    ("K", ONE),
    ("Id", STATE),
    ("M", app("P", STATE, ZERO)),
)
UPDATES = dict(REGISTRY)
SYMBOLS = tuple(UPDATES)


def children(t: Term) -> tuple[Term, ...]:
    if t[0] in ("var", "zero"):
        return ()
    if t[0] == "succ":
        return (t[1],)
    if t[0] == "iter":
        return (t[2], t[3])
    raise ValueError(f"Unknown syntax tag: {t[0]!r}")


def variables(t: Term) -> set[str]:
    if t[0] == "var":
        return {t[1]}
    result: set[str] = set()
    for child in children(t):
        result.update(variables(child))
    return result


def symbols(t: Term) -> set[str]:
    result = {t[1]} if t[0] == "iter" else set()
    for child in children(t):
        result.update(symbols(child))
    return result


def validate(t: Term, allowed_variables: set[str]) -> None:
    tag = t[0]
    if tag == "zero":
        assert len(t) == 1
    elif tag == "var":
        assert len(t) == 2 and t[1] in allowed_variables
    elif tag == "succ":
        assert len(t) == 2
        validate(t[1], allowed_variables)
    elif tag == "iter":
        assert len(t) == 4 and t[1] in UPDATES
        validate(t[2], allowed_variables)
        validate(t[3], allowed_variables)
    else:
        raise AssertionError(f"Ill-formed tag {tag!r}")


def substitution(t: Term, replacements: dict[str, Term]) -> Term:
    """Simultaneous substitution; inserted trees are not substituted again."""
    tag = t[0]
    if tag == "var":
        return replacements.get(t[1], t)
    if tag == "zero":
        return t
    if tag == "succ":
        return succ(substitution(t[1], replacements))
    if tag == "iter":
        return app(t[1], *(substitution(c, replacements) for c in children(t)))
    raise ValueError(tag)


def dagger(t: Term) -> Term:
    """Swap n and visible S(0), leaving all symbol descriptions opaque."""
    if t == N:
        return ONE
    if t == ONE:
        return N
    if t[0] in ("var", "zero"):
        return t
    if t[0] == "succ":
        return succ(dagger(t[1]))
    if t[0] == "iter":
        return app(t[1], *(dagger(c) for c in children(t)))
    raise ValueError(t[0])


def kappa() -> Term:
    """The closed term S(B(0,0)); B's zero equation proves that it is one."""
    return succ(app("B", ZERO, ZERO))


def visible_ones(t: Term) -> int:
    return int(t == ONE) + sum(visible_ones(c) for c in children(t))


def protect_ones(t: Term) -> Term:
    """Protect original numerals before substituting the two swap slots."""
    if t == ONE:
        return kappa()
    if t[0] in ("var", "zero"):
        return t
    if t[0] == "succ":
        return succ(protect_ones(t[1]))
    if t[0] == "iter":
        return app(t[1], *(protect_ones(c) for c in children(t)))
    raise ValueError(t[0])


def compile_swap(h: Term) -> tuple[Term, Term, Term]:
    validate(h, {"x", "y", "a"})
    protected = protect_ones(h)
    f = substitution(protected, {"x": N, "y": ONE})
    expected = substitution(protected, {"x": ONE, "y": N})
    return f, dagger(f), expected


def normalize_b_zero(t: Term) -> Term:
    """Use only B(0,u)=u, bottom-up; no successor or arithmetic equations."""
    if t[0] in ("var", "zero"):
        return t
    if t[0] == "succ":
        return succ(normalize_b_zero(t[1]))
    first, second = (normalize_b_zero(c) for c in children(t))
    if t[1] == "B" and first == ZERO:
        return second
    return app(t[1], first, second)


def display(t: Term) -> str:
    if t[0] == "var":
        return t[1]
    if t[0] == "zero":
        return "0"
    if t[0] == "succ":
        return f"S({display(t[1])})"
    return f"{t[1]}({display(t[2])},{display(t[3])})"


@lru_cache(maxsize=None)
def exact_terms(size: int, names: tuple[str, ...]) -> tuple[Term, ...]:
    """Exhaust all application trees of an exact node count."""
    if size == 1:
        return (ZERO,) + tuple(var(name) for name in names)
    result: list[Term] = [succ(t) for t in exact_terms(size - 1, names)]
    for left_size in range(1, size - 1):
        right_size = size - left_size - 1
        for left in exact_terms(left_size, names):
            for right in exact_terms(right_size, names):
                result.extend(app(symbol, left, right) for symbol in SYMBOLS)
    return tuple(result)


def all_terms(max_size: int, names: tuple[str, ...]) -> Iterable[Term]:
    for size in range(1, max_size + 1):
        yield from exact_terms(size, names)


def random_term(rng: random.Random, depth: int, names: tuple[str, ...]) -> Term:
    if depth == 0 or rng.randrange(5) == 0:
        return rng.choice((ZERO,) + tuple(var(name) for name in names))
    if rng.randrange(3) == 0:
        return succ(random_term(rng, depth - 1, names))
    return app(
        rng.choice(SYMBOLS),
        random_term(rng, depth - 1, names),
        random_term(rng, depth - 1, names),
    )


def value(t: Term, environment: dict[str, int]) -> int:
    """Standard numerical interpretation, for diagnostics only."""
    if t[0] == "zero":
        return 0
    if t[0] == "var":
        return environment[t[1]]
    if t[0] == "succ":
        return value(t[1], environment) + 1
    count = value(t[2], environment)
    state = value(t[3], environment)
    for counter in range(count):
        state = value(UPDATES[t[1]], {"n": counter, "v": state})
    return state


def check_two_slot(t: Term) -> None:
    validate(t, {"n", "a"})
    transformed = dagger(t)
    validate(transformed, {"n", "a"})
    assert dagger(transformed) == t
    assert (transformed == ZERO) == (t == ZERO)
    assert substitution(t, {"n": ONE}) == substitution(transformed, {"n": ONE})
    assert symbols(transformed) == symbols(t)


def check_three_slot(h: Term) -> None:
    protected = protect_ones(h)
    assert visible_ones(protected) == 0
    f, transformed, expected = compile_swap(h)
    assert transformed == expected
    left_original = substitution(h, {"x": N, "y": ONE})
    right_original = substitution(h, {"x": ONE, "y": N})
    assert normalize_b_zero(f) == normalize_b_zero(left_original)
    assert normalize_b_zero(transformed) == normalize_b_zero(right_original)
    check_two_slot(f)


# The formula metric counts one node per variable, constant, application,
# equality, connective, falsum or quantifier.  Placeholder descriptions are
# excluded.  A dagger annotation costs either zero (matching the drafts'
# completed-application metric) or one (explicitly charging the transformation).
# The annotation names an ALREADY TRANSFORMED template f_dagger. It is not
# dagger applied after substituting the displayed index into f.
def leaf(name: str) -> tuple:
    return (name,)


def call(name: str, *args: tuple) -> tuple:
    return ("call:" + name,) + args


def formula(equation_kind: str) -> tuple:
    n, a, zero = leaf("n"), leaf("a"), leaf("0")
    one = call("S", zero)

    def equation(index: tuple) -> tuple:
        if equation_kind == "swap":
            return ("eq", call("H", index, one, a), call("H", one, index, a))
        left = call("f", index, a)
        if equation_kind == "dagger":
            right = ("template_annotation:dagger", call("f_dagger", index, a))
        else:
            right = call("g", index, a)
        return ("eq", left, right)

    progression = ("forall:n", ("imp", equation(n), equation(call("S", n))))
    separation = ("imp", ("eq", zero, one), leaf("false"))
    conclusion = ("forall:n", ("or", ("eq", n, zero), equation(n)))
    return ("forall:a", ("imp", progression, ("and", separation, conclusion)))


def formula_nodes(tree: tuple, charge_dagger: bool = False) -> int:
    cost = int(charge_dagger) if tree[0] == "template_annotation:dagger" else 1
    return cost + sum(formula_nodes(t, charge_dagger) for t in tree[1:])


def equality_occurrences(tree: tuple) -> int:
    return int(tree[0] == "eq") + sum(equality_occurrences(t) for t in tree[1:])


def run_checks() -> dict:
    dependencies = []
    available: set[str] = set()
    for name, update in REGISTRY:
        validate(update, {"n", "v"})
        used = symbols(update)
        assert used <= available
        assert name not in used
        dependencies.append({"symbol": name, "update": display(update),
                             "earlier_dependencies": sorted(used)})
        available.add(name)

    assert UPDATES["K"] == ONE
    assert dagger(kappa()) == kappa()
    assert visible_ones(kappa()) == 0
    assert variables(kappa()) == set()
    assert normalize_b_zero(kappa()) == ONE
    assert value(kappa(), {}) == 1
    # The visible application trees do not include K's stored update S(0).
    assert dagger(app("K", A, ZERO)) == app("K", A, ZERO)
    for a in range(20):
        assert value(app("K", succ(A), ZERO), {"a": a}) == 1

    two_count = 0
    for t in all_terms(5, ("n", "a")):
        check_two_slot(t)
        two_count += 1
    three_count = 0
    for h in all_terms(5, ("x", "y", "a")):
        check_three_slot(h)
        three_count += 1

    seed = 20261031
    rng = random.Random(seed)
    random_count = 2000
    for _ in range(random_count):
        check_two_slot(random_term(rng, 6, ("n", "a")))
        check_three_slot(random_term(rng, 6, ("x", "y", "a")))

    special_h = (
        ONE,
        succ(X),
        succ(Y),
        succ(ONE),
        app("A", X, ONE),
        app("M", app("A", X, Y), succ(A)),
        app("K", succ(X), ZERO),
        app("A", app("A", X, X), app("A", Y, ONE)),
    )
    accidental_cases = []
    numerical_count = 0
    for h in special_h:
        check_three_slot(h)
        f, transformed, expected = compile_swap(h)
        accidental_cases.append({"H": display(h), "f": display(f),
                                 "dagger_f": display(transformed),
                                 "expected_transpose": display(expected)})
        for n in (0, 1, 2, 4):
            for a in (0, 1, 3):
                env = {"n": n, "a": a}
                assert value(f, env) == value(h, {"x": n, "y": 1, "a": a})
                assert value(transformed, env) == value(
                    h, {"x": 1, "y": n, "a": a}
                )
                numerical_count += 2

    s = app("A", N, N)
    t = app("A", ONE, N)
    assert substitution(s, {"n": ONE}) == substitution(t, {"n": ONE})
    assert dagger(s) != t and dagger(t) != s

    # These intentionally unequal trees confirm the order-of-operations warning.
    order_left = dagger(substitution(N, {"n": succ(N)}))
    order_right = substitution(dagger(N), {"n": succ(N)})
    assert order_left != order_right
    parameter_left = dagger(substitution(A, {"a": ONE}))
    parameter_right = substitution(dagger(A), {"a": ONE})
    assert parameter_left != parameter_right
    unprotected = substitution(ONE, {"x": N, "y": ONE})
    unprotected_target = substitution(ONE, {"x": ONE, "y": N})
    assert dagger(unprotected) != unprotected_target

    metrics = {}
    expected_sizes = {"RB": 39, "Swap": 51, "Dagger": 39,
                      "Dagger_with_annotations": 42}
    for label, kind, charge in (
        ("RB", "pair", False),
        ("Swap", "swap", False),
        ("Dagger", "dagger", False),
        ("Dagger_with_annotations", "dagger", True),
    ):
        tree = formula(kind)
        count = formula_nodes(tree, charge)
        assert count == expected_sizes[label]
        assert equality_occurrences(tree) == 5
        metrics[label] = {
            "AST_nodes": count,
            "equality_occurrences": equality_occurrences(tree),
            "templates_including_D0_DS": 3,
            "dagger_annotation_cost": int(charge),
            "formula_tree": tree,
        }

    return {
        "status": "passed",
        "scope": (
            "Finite syntax and registry checks, compiler diagnostics, and exact "
            "template counts. These checks are not a proof of full PRA equivalence; "
            "the paper provides the structural and mathematical arguments."
        ),
        "registry": dependencies,
        "shield": {
            "raw_term": display(kappa()),
            "B_update": display(UPDATES["B"]),
            "free_variables": sorted(variables(kappa())),
            "visible_one_subtrees": visible_ones(kappa()),
            "dagger_fixed": True,
            "defining_equation_used": "B(0,u)=u",
            "one_step_reduct": display(normalize_b_zero(kappa())),
            "standard_numerical_value": 1,
            "descriptions_are_opaque": True,
        },
        "opaque_description_diagnostic": {
            "K_update": display(UPDATES["K"]),
            "dagger_K_a_zero": display(dagger(app("K", A, ZERO))),
            "K_successor_seed_checks": 20,
            "note": "K is an extra diagnostic symbol; the compiler shield uses only B.",
        },
        "exhaustive": {
            "maximum_term_nodes": 5,
            "binary_iterator_symbols": list(SYMBOLS),
            "two_slot_terms_checked": two_count,
            "three_slot_contexts_compiled": three_count,
        },
        "sampled": {
            "seed": seed,
            "maximum_depth": 6,
            "two_slot_terms_checked": random_count,
            "three_slot_contexts_compiled": random_count,
        },
        "special_compiler_cases": accidental_cases,
        "standard_numerical_diagnostic_equalities": numerical_count,
        "proper_subfamily_witness": {
            "s": display(s), "t": display(t),
            "common_literal_boundary": display(substitution(s, {"n": ONE})),
            "dagger_s": display(dagger(s)), "dagger_t": display(dagger(t)),
            "PB0_admitted": True, "is_a_dagger_pair_in_either_orientation": False,
        },
        "deliberately_unequal_operation_orders": {
            "dagger_after_n_to_Sn": display(order_left),
            "n_to_Sn_after_dagger": display(order_right),
            "dagger_after_a_to_one": display(parameter_left),
            "a_to_one_after_dagger": display(parameter_right),
            "unprotected_original_H": display(ONE),
            "unprotected_dagger": display(dagger(unprotected)),
            "required_transpose": display(unprotected_target),
        },
        "formula_metrics": metrics,
        "metric_scope": (
            "One node per variable, constant, application, equality, connective, "
            "falsum and quantifier; 1 is expanded as S(0). The completed "
            "placeholder-application metric does not expand substituted term "
            "descriptions. Charging each of three dagger annotations adds 3 nodes. "
            "The common D0 and DS formulas and the transformation algorithm are "
            "not included in these arithmetic-formula counts."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", action="store_true", help="print the JSON report")
    arguments = parser.parse_args()
    report = run_checks()
    if arguments.report:
        print(json.dumps(report, indent=2, sort_keys=True))
    else:
        print("PASS: finite involution, shielding, compilation, and metric checks")
        print(json.dumps({"exhaustive": report["exhaustive"],
                          "sampled": report["sampled"]}, indent=2))


if __name__ == "__main__":
    main()
