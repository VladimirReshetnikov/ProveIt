#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 artifacts/check_involution.py --report > artifacts/check_results.json
python3 - <<'PY'
import json
from pathlib import Path
data = json.loads(Path('artifacts/check_results.json').read_text())
print('PASS: independent syntax, compiler, and formula-metric checks')
print(json.dumps({k: v['AST_nodes'] for k, v in data['formula_metrics'].items()},
                 indent=2))
PY
if [ -n "${LEAN:-}" ]; then
  "$LEAN" formal/DaggerSyntax.lean > formal/verification.log 2>&1
  cat formal/verification.log
elif command -v lean >/dev/null 2>&1; then
  lean formal/DaggerSyntax.lean > formal/verification.log 2>&1
  cat formal/verification.log
else
  echo 'Lean was not run: set LEAN to a Lean 4.19.0 executable.'
fi
