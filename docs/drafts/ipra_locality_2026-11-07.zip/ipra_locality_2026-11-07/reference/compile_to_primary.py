"""Translate canonical direct-native certificates into the primary certificate dialect.

Only consumed instructions are emitted. Failed-major fall-through is rejected:
canonical certificates use the rule they request. The translator is untrusted
certificate-producing tooling; the primary checker independently rechecks its output.
"""
import ast
import json
from pathlib import Path
from expand_formula import native_to_surface

ROOT = Path(__file__).resolve().parent


class ObserveInstructions(ast.NodeTransformer):
    def visit_Call(self, node):
        self.generic_visit(node)
        if isinstance(node.func, ast.Name) and node.func.id == 'take':
            node.args = [ast.Name(id='a', ctx=ast.Load()), ast.Name(id='g', ctx=ast.Load())]
        return node

    def visit_match_case(self, node):
        self.generic_visit(node)
        if (isinstance(node.guard, ast.Call) and isinstance(node.guard.func, ast.Name)
                and node.guard.func.id == 'check'):
            node.guard.func.id = 'require_major'
        return node


def compile_packet(data):
    data = json.loads(json.dumps(data))
    goal = data.pop()
    transformed = []
    module = ast.parse((ROOT / 'native_checker.py').read_text())
    definitions = [n for n in module.body
                   if isinstance(n, (ast.Import, ast.Assign, ast.FunctionDef))]
    tree = ObserveInstructions().visit(ast.Module(body=definitions, type_ignores=[]))
    namespace = {}
    exec(compile(ast.fix_missing_locations(tree), 'observed_native_checker.py', 'exec'), namespace)

    def take(a, g):
        instruction = data.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            if isinstance(major, int):
                matrix, _ = g[major]
                transformed.append([[native_to_surface(matrix)], annotation])
            else:
                converted = native_to_surface(major)
                transformed.append([converted, native_to_surface(annotation)
                                    if len(major) == 2 else 0])
        else:
            transformed.append(instruction)
        return instruction

    def require_major(a, g):
        accepted = namespace['check'](a, g)
        if not accepted:
            raise ValueError('failed-major fallback is outside the canonical translator')
        return accepted

    namespace['take'] = take
    namespace['require_major'] = require_major
    if not namespace['check'](goal, []):
        raise ValueError('native certificate rejected')
    return list(reversed(transformed)) + [native_to_surface(goal)]
