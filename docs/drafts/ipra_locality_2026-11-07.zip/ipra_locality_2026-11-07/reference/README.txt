DIRECT Q-FREE REFERENCE AND FORMULA EXPANSION
============================================

STATUS AND ATTRIBUTION
----------------------
The equality-plus-paired-binder calculus with context closure licenses is
already described in the supplied ipra_context_freshness_2026-11-07,
sections/11_research.tex. It is inherited mathematics, made explicit here.
The direct checker derives from the scalar-iteration checker and the
scope-complement/staged-verdict implementation conventions in the current
ProveIt drafts. It is an optional reference implementation.

Whole-program normalized measurement (CPython 3.12 normalization):
  native_checker.py: 394 significant normalized tokens,
                    423 AST nodes,
                    1129 normalized UTF-8 bytes.
This is ABOVE the current overall minima 375 / 403 / 1117. It is below
the supplied direct Q-free prototypes 428 / 464 / 1211 and 416 / 455 / 1224.
The smaller primary certificate checker is a separate implementation;
no checker-size saving is being attributed to removing Q syntax.

TWO SERIALIZATIONS
------------------
All numerical terms use:
  0          zero
  [t]        successor
  [n,a,h]    initialized scalar iteration (h binds its previous value)

The direct native checker uses:
  [s,t]      equation
  [B]        D_{x,y} B, binding TWO numerical variables, y nearest

The primary certificate dialect uses:
  [s,t]      equation
  [B]        auxiliary Q_y B, binding ONE numerical variable
  [B,P1,P2]  D_{x,y} B, binding TWO variables, with validated inert padding

DO NOT exchange unary formula arrays between these two representations.
Terms are sorted, so their successor arrays have the same meaning in both.

FORMULA TRANSLATION
-------------------
expand_formula.py provides:
  expand_formula(A, ambient=0, floor=0)
    source certificate dialect -> direct unary-D native serialization;
  expand_for_primary(A, ambient=0, floor=0)
    source certificate dialect -> native formula in primary ternary-D
    serialization, with no Q constructor;
  native_to_surface(A)
    embed the direct native serialization using ternary D.

The translation of Q_y B inserts an unused outer witness:
  Q_y B  ->  D_{u,y} B, with u fresh.
It shifts coordinates referring past y, including occurrences beneath
nested iterator update binders. It validates all source padding before
discarding it. Positive coordinates 2j-1 and 2j denote the same jth nearest
bound variable; output uses 2j-1. Optional ambient binders are declared
explicitly. Rigid negative parameters must lie between floor and -1.
The default checks a closed formula.

DIRECT PROOF FORMAT
-------------------
A packet is a JSON array; the last item is the closed goal. Instructions
are consumed from right to left. An unused leading prefix is permitted.
A goal already among ordinary local assumptions consumes no instruction.

[] requests an iterator defining equation.
[m,t], with a formula m, first proves m. For equality m, t is a transport
motive. For native D, it opens a fresh first witness and installs a local
closure clause, then continues proving the original goal.
[i,t], with an integer context index i, applies the indexed closure clause
B(y) at t: the goal must be B(t), and the remaining proof must establish
B(0). Ordinary assumptions cannot be used as closure clauses.
Any other instruction t introduces native D with first witness t. Its
minor retains B(t,0), and also B(t,z) exactly when B is literally equality;
the minor proves B(t,Sz). The numerical z is fresh.

The internal context is one list. Ordinary assumptions are formulas.
A closure clause is stored as [B,0], which cannot itself be a well-formed
formula: B is a formula, whereas an equality's first field is a term.
Clause lookup destructures exactly two fields. An ordinary D has only one;
an ordinary equality supplies a term where formula validation is required.
The disjointness of numerical and formula syntax therefore protects both
hypothesis use and clause application, including vacuous closure clauses.

The scope validator has the same rigid-name floor/open-hole convention as
the supplied scalar checkers. Used Boolean or floating numerical tokens
reject. Python accepts Boolean context indices and negative indexing as
harmless administrative aliases; canonical indices are nonnegative integers.
Fresh names are allocated -1,-2,... at binder rules. A negative name cannot
occur in a closed initial goal. Witness/annotation data unused by a rule
is inert. Failed-major fall-through is inherited; the canonical translator
below deliberately rejects that noncanonical mechanism.

RUNNING AND CHECKS
------------------
  python3 native_checker.py examples/literal_equation_induction.json
  python3 test_native.py
  python3 test_expand.py
  python3 test_compile_primary.py PATH_TO_PRIMARY_CHECKER.py

compile_to_primary.py compiles canonical direct-native packets into the
primary certificate dialect. A local native closure-clause use becomes an
application of the corresponding Q assumption generated by primary D
elimination. All final goals use only equality and ternary D. The primary
checker independently verifies every emitted certificate; the compiler is
not part of its acceptance boundary.

The finite checks include an independent named-variable oracle for formula
expansion, substitution commutation, arithmetic computations, equality
transport, an essential use of the equation induction hypothesis, paired
introduction/elimination, clause use, compound clauses, witness repacking,
vacuous-clause safety, malformed inputs, scope boundaries, and CLI verdicts.
These finite checks do not constitute a proof-assistant formalization of
the mathematical equivalence theorem.
