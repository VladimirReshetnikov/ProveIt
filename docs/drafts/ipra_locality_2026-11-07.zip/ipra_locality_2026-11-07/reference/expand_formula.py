"""Expand the old eq/Q/D formula dialect into the Q-free eq/D grammar.

Source formulas:
  equality [s,t], Q [B], D [B,P1,P2] (validated inert padding).
Target formulas:
  equality [s,t], D [B].
Terms keep the old zero/successor/scalar-iterator encoding.  A positive
coordinate 2*j-1 or 2*j refers to the j-th nearest bound variable; output
coordinates use the canonical odd spelling.  Zero is the term 0.

The optional ambient count declares surrounding binders.  The optional
floor declares available rigid parameters floor,...,-1.  The default
accepts closed formulas.  This transformer is explanatory tooling, not
an import of either complete acceptance checker.
"""


def expand_formula(formula, ambient=0, floor=0):
    if type(ambient) is not int or ambient < 0:
        raise ValueError('ambient must be a nonnegative integer')
    if type(floor) is not int or floor > 0:
        raise ValueError('floor must be a nonpositive integer')

    def push(environment, source, target):
        return tuple(range(1, source + 1)) + tuple(i + target for i in environment)

    def term(t, environment):
        if type(t) is int:
            if floor <= t <= 0:
                return t
            if t > 0 and (t + 1) // 2 <= len(environment):
                return 2 * environment[(t - 1) // 2] - 1
            raise ValueError('out-of-scope numerical coordinate')
        if type(t) is not list:
            raise ValueError('a term must be an integer or array')
        if len(t) == 1:
            return [term(t[0], environment)]
        if len(t) == 3:
            n, a, h = t
            return [term(n, environment), term(a, environment),
                    term(h, push(environment, 1, 1))]
        raise ValueError('invalid term constructor')

    def form(a, environment):
        if type(a) is not list:
            raise ValueError('a formula must be an array')
        if len(a) == 2:
            return [term(t, environment) for t in a]
        if len(a) == 1:
            # Source y is still nearest; a fresh unused u is inserted outside it.
            return [form(a[0], push(environment, 1, 2))]
        if len(a) == 3:
            scope = push(environment, 2, 2)
            translated = [form(child, scope) for child in a]
            return translated[:1]
        raise ValueError('invalid formula constructor')

    return form(formula, tuple(range(1, ambient + 1)))


def native_to_surface(formula):
    """Embed a Q-free unary-D formula into the original ternary-D dialect."""
    if type(formula) is not list:
        raise ValueError('a formula must be an array')
    if len(formula) == 2:
        return formula
    if len(formula) == 1:
        return [native_to_surface(formula[0]), [0, 0], [0, 0]]
    raise ValueError('invalid native formula constructor')


def expand_for_primary(formula, ambient=0, floor=0):
    """Return a Q-free goal in the primary checker's ternary-D serialization.

    This uses only source-dialect equality and ternary D constructors. No unary
    Q formula remains. Terms retain their ordinary unary-successor arrays.
    """
    return native_to_surface(expand_formula(formula, ambient=ambient, floor=floor))
