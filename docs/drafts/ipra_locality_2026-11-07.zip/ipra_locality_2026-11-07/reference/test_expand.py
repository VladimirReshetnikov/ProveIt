"""Finite scope/translation checks, with a separate named-variable oracle."""
import json
import random
from pathlib import Path
from expand_formula import expand_formula, native_to_surface, expand_for_primary


class Names:
    def __init__(self):
        self.next = 0

    def fresh(self):
        self.next += 1
        return 'v' + str(self.next)


def decode_source(formula, ambient, names):
    def term(t, environment):
        if type(t) is int:
            return ('bound', environment[(t - 1) // 2]) if t > 0 else ('constant', t)
        if len(t) == 1:
            return ('S', term(t[0], environment))
        n, a, h = t
        u = names.fresh()
        return ('I', term(n, environment), term(a, environment),
                u, term(h, [u] + environment))

    def form(a, environment):
        if len(a) == 2:
            return ('=', term(a[0], environment), term(a[1], environment))
        if len(a) == 1:
            y = names.fresh()
            return ('Q', y, form(a[0], [y] + environment))
        x, y = names.fresh(), names.fresh()
        return ('D', x, y, form(a[0], [y, x] + environment))

    return form(formula, ambient)


def translate_named(a, names):
    if a[0] == '=':
        return a
    if a[0] == 'Q':
        _, y, body = a
        return ('D', names.fresh(), y, translate_named(body, names))
    _, x, y, body = a
    return ('D', x, y, translate_named(body, names))


def encode_native(formula, ambient):
    def term(t, environment):
        tag = t[0]
        if tag == 'constant':
            return t[1]
        if tag == 'bound':
            return 2 * environment.index(t[1]) + 1
        if tag == 'S':
            return [term(t[1], environment)]
        _, n, a, u, h = t
        return [term(n, environment), term(a, environment), term(h, [u] + environment)]

    def form(a, environment):
        if a[0] == '=':
            return [term(a[1], environment), term(a[2], environment)]
        _, x, y, body = a
        return [form(body, [y, x] + environment)]

    return form(formula, ambient)


def substitute_outer(formula, image, source):
    """Substitute a closed term for one ambient variable, by standard de Bruijn rank."""
    def term(t, depth):
        if type(t) is int:
            if t <= 0:
                return t
            rank = (t + 1) // 2
            if rank <= depth:
                return 2 * rank - 1
            if rank == depth + 1:
                return image
            return 2 * (rank - 1) - 1
        if len(t) == 1:
            return [term(t[0], depth)]
        n, a, h = t
        return [term(n, depth), term(a, depth), term(h, depth + 1)]

    def form(a, depth):
        if len(a) == 2:
            return [term(t, depth) for t in a]
        binders = 1 if source and len(a) == 1 else 2
        return [form(child, depth + binders) for child in a]

    return form(formula, 0)


rng = random.Random(742391)


def random_term(depth, budget):
    if not budget or rng.randrange(3) == 0:
        if depth and rng.randrange(2):
            # Exercise both accepted spellings of a source coordinate.
            return 2 * rng.randrange(1, depth + 1) - rng.randrange(2)
        return rng.randrange(-3, 1)
    if rng.randrange(2):
        return [random_term(depth, budget - 1)]
    return [random_term(depth, budget - 1), random_term(depth, budget - 1),
            random_term(depth + 1, budget - 1)]


def random_formula(depth, budget):
    tag = rng.randrange(3) if budget else 0
    if tag == 0:
        return [random_term(depth, 2), random_term(depth, 2)]
    if tag == 1:
        return [random_formula(depth + 1, budget - 1)]
    return [random_formula(depth + 2, budget - 1),
            random_formula(depth + 2, 0), random_formula(depth + 2, 0)]


def main():
    sample_count = 2500
    for _ in range(sample_count):
        ambient = rng.randrange(5)
        a = random_formula(ambient, 4)
        result = expand_formula(a, ambient=ambient, floor=-3)
        names = Names()
        outer = [names.fresh() for _ in range(ambient)]
        expected = encode_native(translate_named(decode_source(a, outer, names), names), outer)
        assert result == expected, (a, result, expected)
        primary = expand_for_primary(a, ambient=ambient, floor=-3)
        assert primary == native_to_surface(result)
        def no_q(formula):
            return len(formula) == 2 or len(formula) == 3 and all(no_q(c) for c in formula)
        assert no_q(primary)
        assert expand_formula(native_to_surface(result), ambient=ambient, floor=-3) == result

    coherence_count = 1500
    for _ in range(coherence_count):
        a = random_formula(1, 4)
        def canonical_term(t):
            if type(t) is int:
                return 2 * ((t + 1) // 2) - 1 if t > 0 else t
            return [canonical_term(child) for child in t]
        image = canonical_term(random_term(0, 3))
        source_first = expand_formula(substitute_outer(a, image, True), floor=-3)
        target_first = substitute_outer(expand_formula(a, ambient=1, floor=-3), image, False)
        assert source_first == target_first, (a, image, source_first, target_first)

    # The native Q expansion is itself a unary paired binder, hence only two nesting brackets.
    assert expand_formula([[1, 3]], ambient=1) == [[1, 5]]
    # The iterator updater adds a protected variable before all formula binders.
    assert expand_formula([[[0, 3, [1, 0, 7]], 3]], ambient=1) == [[[0, 5, [1, 0, 9]], 5]]

    invalid = [None, True, {}, [], [0], [0, []], [0, True],
               [0, 1], [[1, 3]], [[0, 0], [0, 9], [0, 0]],
               [[0, 0], [0, 0], {'bad': 'padding'}]]
    for a in invalid:
        try:
            expand_formula(a)
        except ValueError:
            pass
        else:
            raise AssertionError(('malformed source accepted', a))
    result = {'named_oracle_comparisons': sample_count,
              'native_embedding_round_trips': sample_count,
              'primary_serialization_and_no_Q_checks': sample_count,
              'substitution_commutation_checks': coherence_count,
              'explicit_nested_scope_checks': 2,
              'malformed_inputs_rejected': len(invalid)}
    Path(__file__).with_name('expansion_test_results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
