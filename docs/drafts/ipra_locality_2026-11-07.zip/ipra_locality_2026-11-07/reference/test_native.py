"""Canonical closed certificates and boundary tests for the direct Q-free checker."""
import ast
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def number(n):
    t = 0
    for _ in range(n):
        t = [t]
    return t


def reflexivity(t):
    """Instructions in reading order for t=t, with no eigenvariable allocation."""
    major = [[0, t, 0], t]
    return [[major, [1, t]], [], []]


def packet(goal, instructions):
    return list(reversed(instructions)) + [goal]


def load_checker():
    module = ast.parse((ROOT / 'native_checker.py').read_text())
    definitions = [n for n in module.body
                   if isinstance(n, (ast.Import, ast.Assign, ast.FunctionDef))]
    namespace = {}
    exec(compile(ast.Module(body=definitions, type_ignores=[]), 'native_checker.py', 'exec'), namespace)
    return namespace


def accept(data, context=None, floor=0):
    namespace = load_checker()
    data = json.loads(json.dumps(data))
    namespace['k'] = floor
    namespace['take'] = data.pop
    try:
        return bool(namespace['check'](data.pop(), [] if context is None else context))
    except Exception:
        return False


def fixtures():
    result = {}
    result['iterator_zero'] = packet([[0, number(3), [1]], number(3)], [[]])
    result['iterator_successor'] = packet([[[0], 0, [1]], [[0, 0, [1]]]], [[]])
    result['reflexivity_zero'] = packet([0, 0], reflexivity(0))
    result['reflexivity_three'] = packet([number(3), number(3)], reflexivity(number(3)))
    result['native_D_constant'] = packet([[0, 0]], [0])
    result['native_D_witness_used'] = packet([[3, 3]], [number(3)])
    result['native_D_compound'] = packet([[[0, 0]]], [0])
    # Literal-equation induction with an essential use of its local IH.
    # I(y,0;u.Su)=y, represented as the reified closure D_{x,y} of that equation.
    iteration_goal = [[[1, 0, [1]], 1]]
    previous = [-1, 0, [1]]
    step_left = [[-1], 0, [1]]
    hypothesis = [previous, -1]
    motive = [step_left, [1]]
    result['literal_equation_induction'] = packet(iteration_goal, [0, [hypothesis, motive], []])

    # D_{u,y}(y=y) is the native reification of Q_y(y=y).
    major = [[1, 1]]
    major_steps = [0] + reflexivity([-1])
    result['reified_Q_reflexivity'] = packet(major, major_steps)
    # The major's introduction allocates -1; elimination allocates -2.
    # The local clause has index 0 and is applied at the closed numeral 3.
    result['clause_application_reflexivity'] = packet(
        [number(3), number(3)],
        [[major, 0]] + major_steps + [[0, number(3)]] + reflexivity(0))

    # A compound closure matrix: B(y)=D_{u,v}(y=y). Its paired formula is
    # D_{x,y}B(y), so y has coordinate 5 inside the inner paired binder.
    compound_major = [[[5, 5]]]
    result['clause_application_compound'] = packet(
        [[number(2), number(2)]],
        [[compound_major, 0], 0, 0, [0, number(2)], 0])

    # A fresh witness may be repacked under a paired binder, but not escape.
    witness_major = [[[0, 3, 0], 3]]
    result['existential_witness_repacking'] = packet(
        [[3, 3]], [[witness_major, 0], number(2), -2])
    return result


def main():
    examples = ROOT / 'examples'
    examples.mkdir(exist_ok=True)
    positives = fixtures()
    for name, data in positives.items():
        assert accept(data), ('positive rejected', name, data)
        (examples / (name + '.json')).write_text(json.dumps(data, separators=(',', ':')) + '\n')

    # Extra equation/paired-witness instances exercise term updates and scope.
    for n in range(10):
        t = number(n)
        assert accept(packet([t, t], reflexivity(t)))
        assert accept(packet([[3, 3]], [t]))

    false_conclusions = 0
    for name, data in positives.items():
        forged = data[:-1] + [[0, [0]]]
        assert not accept(forged), ('false conclusion accepted', name)
        false_conclusions += 1

    malformed = [None, True, False, 0, 1, -1, '', [], {}, [0],
                 [0, True], [0, -1], [0, 1], [0, []], [[0, 0], 0],
                 [[0, 0], [0, 0], [0, 0]], [[0, 5]],
                 [[0, 0, True], 0], [[[0], 0, 5], 0]]
    for goal in malformed:
        assert not accept([[], goal]), ('malformed goal accepted', goal)

    boundary = [
        # A vacuous closure (0=1)->forall y(0=1) supplies no fact 0=1.
        (packet([0, [0]], []), [[[0, [0]], 0]], 0),
        # An ordinary equation cannot be misused as a closure-clause matrix.
        (packet([0, [0]], [[0, 0], []]), [[0, 0]], 0),
        # An ordinary D assumption also cannot be treated as a closure clause.
        (packet([0, [0]], [[0, 0], []]), [[[0, [0]]]], 0),
        # A negative variable in a closed goal may not escape.
        (packet([-1, -1], reflexivity(-1)), [], 0),
        # The first witness is used, so this future rigid parameter must reject.
        (packet([[3, 0]], [-1]), [], 0),
        # Missing and out-of-range clause indices reject.
        (packet([0, 0], [[0, 0], []]), [], 0),
        (packet([0, 0], [[99, 0], []]), [[[1, 1], 0]], 0),
    ]
    for data, context, floor in boundary:
        assert not accept(data, context, floor), ('boundary accepted', data, context)

    # The vacuous clause can still be used soundly when its base is supplied.
    assert accept(packet([0, 0], [[0, number(2)]] + reflexivity(0)), [[[0, 0], 0]])

    cli_checks = 0
    for name in positives:
        run = subprocess.run([sys.executable, str(ROOT / 'native_checker.py'),
                              str(examples / (name + '.json'))],
                             capture_output=True, text=True, timeout=10)
        assert (run.returncode, run.stdout) == (0, 'ACCEPT\n'), (name, run)
        cli_checks += 1
    bad_path = examples / 'false_equation.json'
    bad_path.write_text(json.dumps([[], [0, [0]]]) + '\n')
    run = subprocess.run([sys.executable, str(ROOT / 'native_checker.py'), str(bad_path)],
                         capture_output=True, text=True, timeout=10)
    assert (run.returncode, run.stdout) == (1, 'REJECT\n')
    cli_checks += 1

    results = {'closed_positive_fixtures': len(positives),
               'additional_arithmetic_and_witness_instances': 20,
               'false_conclusion_rejections': false_conclusions,
               'malformed_goal_rejections': len(malformed),
               'context_and_scope_boundary_rejections': len(boundary),
               'vacuous_clause_with_proved_base': 1,
               'CLI_checks': cli_checks}
    (ROOT / 'native_test_results.json').write_text(json.dumps(results, indent=2) + '\n')
    (examples / 'index.json').write_text(json.dumps({**{k: True for k in positives},
                                                   'false_equation': False}, indent=2) + '\n')
    print(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()
