"""Check all native fixture translations with an independent primary checker file."""
import ast
import json
import sys
from pathlib import Path
from compile_to_primary import compile_packet
from test_native import fixtures

ROOT = Path(__file__).resolve().parent


def accepts(path, packet):
    tree = ast.parse(path.read_text())
    definitions = [n for n in tree.body
                   if isinstance(n, (ast.Import, ast.Assign, ast.FunctionDef))]
    ns = {}
    exec(compile(ast.Module(body=definitions, type_ignores=[]), str(path), 'exec'), ns)
    data = json.loads(json.dumps(packet))
    ns['take'] = data.pop
    try:
        return bool(ns['check'](data.pop(), []))
    except Exception:
        return False


def main():
    primary = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT.parent / 'checker.py'
    output = ROOT / 'examples_primary'
    output.mkdir(exist_ok=True)
    count = 0
    for name, packet in fixtures().items():
        result = compile_packet(packet)
        assert accepts(primary, result), ('translated native certificate rejected', name, result)
        def no_q(formula):
            return len(formula) == 2 or len(formula) == 3 and all(no_q(child) for child in formula)
        assert no_q(result[-1])
        (output / (name + '.json')).write_text(json.dumps(result, separators=(',', ':')) + '\n')
        count += 1
    result = {'translated_closed_certificates_accepted': count,
              'all_final_goals_have_no_Q_constructor': True,
              'primary_checker': primary.name}
    (ROOT / 'primary_translation_test_results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
