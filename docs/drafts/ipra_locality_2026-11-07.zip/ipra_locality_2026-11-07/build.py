"""Build the complete PDF from local LaTeX sources."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    engine = shutil.which("pdflatex")
    if engine is None:
        raise SystemExit("Install pdfLaTeX and the packages named in report.tex.")
    (ROOT / "results").mkdir(exist_ok=True)
    for i in range(3):
        process = subprocess.run(
            [engine, "-no-shell-escape", "-interaction=nonstopmode",
             "-halt-on-error", "report.tex"], cwd=ROOT, capture_output=True, text=True)
        (ROOT / "results" / f"latex-pass-{i + 1}.txt").write_text(process.stdout + process.stderr)
        if process.returncode:
            print(process.stdout[-6000:])
            raise SystemExit(process.returncode)
    print("Built report.pdf")


if __name__ == "__main__":
    main()
