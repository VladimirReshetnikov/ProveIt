"""Independent finite audit of the synthesized scope/raw/staged checker.

This is untrusted validation support and is never imported by the checker.
"""
import ast
from collections import Counter
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile

from raw_scope_oracle import RawOracle
from mutation_support import mutate

HERE = Path(__file__).resolve().parent
FIXTURES = HERE / 'fixtures'


def load(path):
    tree = ast.parse(path.read_text())
    tree.body = [node for node in tree.body if isinstance(node, (ast.Import, ast.ImportFrom, ast.FunctionDef)) or isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'k' for t in node.targets)]
    result = {}
    exec(compile(tree, str(path), 'exec'), result)
    return result


def run(module, packet):
    stack = deepcopy(packet)
    module['k'] = 0
    used = []
    def take():
        value = stack.pop()
        used.append(deepcopy(value))
        return value
    try:
        module['take'] = take
        accepted = bool(module['check'](stack.pop(), []))
    except Exception:
        accepted = False
    return {'accepted': accepted, 'final_k': module['k'], 'remaining': len(stack) if type(stack) is list else None, 'used': used}


def unwrap(value):
    if type(value) is list and len(value) == 1:
        witness = value[0]
        if type(witness) is int or type(witness) is list and len(witness) in (1, 3):
            return witness
        return 0
    return value


def main():
    target_path = HERE.parent / 'checker.py'
    target = load(target_path)
    old = load(FIXTURES / 'frozen_scope_checker.py')
    rows = []
    folder = FIXTURES
    for filename in ('inherited_fixtures.json', 'new_fixtures.json', 'new_scope_cases.json'):
        rows += json.loads((folder / filename).read_text())
    counts = Counter()
    rule_counts = Counter()
    translated = []
    details = []
    def audit(packet, label, expected=None):
        result = run(target, packet)
        oracle = RawOracle().run(packet)
        assert result['accepted'] == oracle['accepted'], (label, result, oracle)
        if result['accepted']:
            assert result['final_k'] == oracle['final_k'], label
            assert result['remaining'] == oracle['remaining'], label
            rule_counts.update(oracle['rules'])
        if expected is not None:
            assert result['accepted'] == expected, (label, expected, result)
        counts['accepted' if result['accepted'] else 'rejected'] += 1
        details.append({'label': label, 'accepted': result['accepted']})
        return result
    for row in rows:
        result = run(old, row['packet'])
        if result['accepted']:
            packet = list(reversed([unwrap(c) for c in result['used']])) + [deepcopy(row['packet'][-1])]
            out = audit(packet, row['name'], True)
            assert out['final_k'] == result['final_k'], row['name']
            translated.append({'name': row['name'], 'packet': packet})
        else:
            p = row['packet']
            packet = [unwrap(c) for c in p[:-1]] + [deepcopy(p[-1])] if type(p) is list and p else p
            audit(packet, row['name'])
    false_major = [[0, 0, 0], [0]]
    audit([[], [false_major, None], [[0, 0]]], 'failed-major-fallback', True)
    audit([[], [false_major, None], [0, [0]]], 'failed-major-cannot-prove-false-equation', False)
    audit([[], [false_major, None], [[0, 0], [0, 0], [0, 0]]], 'failed-major-vacuous-paired-fallback', True)
    audit([[], [false_major, None], [[3, 3], [0, 0], [0, 0]]], 'failed-major-used-paired-witness-rejects', False)
    rng = random.Random(202611081)
    for i in range(3000):
        audit(mutate(translated[i % len(translated)]['packet'], rng), f'mutation-{i}')
    cli = []
    with tempfile.TemporaryDirectory() as directory:
        tests = [r['packet'] for r in translated[:20]]
        tests += [r['packet'][:-1] + [[0, [0]]] for r in translated[:20]]
        for i, packet in enumerate(tests):
            expected = run(target, packet)['accepted']
            path = Path(directory) / f'{i}.json'
            path.write_text(json.dumps(packet))
            for flags in ([], ['-O']):
                p = subprocess.run([sys.executable, *flags, str(target_path), str(path)], capture_output=True, text=True)
                assert (p.returncode, p.stdout) == ((0, 'ACCEPT\n') if expected else (1, 'REJECT\n')), (i, p)
                cli.append({'test': i, 'optimized': bool(flags), 'accepted': expected})
    result = {'status': 'PASS', 'checker_sha256': hashlib.sha256(target_path.read_bytes()).hexdigest(), 'counts': dict(counts), 'positive_translations': len(translated), 'cli_calls': len(cli), 'rule_counts': dict(rule_counts), 'details': details}
    (HERE / 'audit_results.json').write_text(json.dumps(result, indent=2) + '\n')
    (HERE / 'translated_certificates.json').write_text(json.dumps(translated, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'details'}, indent=2))


if __name__ == '__main__':
    main()
