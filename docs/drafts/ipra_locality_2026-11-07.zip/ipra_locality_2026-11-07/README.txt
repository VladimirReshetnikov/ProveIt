A SMALLER VERIFIER FOR iPRA AND AN INITIALIZATION OBSTRUCTION
Prepared for Vladimir Reshetnikov, 7 November 2026
============================================================

Read report.pdf for the complete mathematical development.
report.tex and sections/*.tex contain all editable LaTeX source.

RESULTS AND LIMITS
------------------
The primary checker is strictly below the ten current root programs:

                          Normalized tokens    AST nodes    Normalized bytes
Current observed minimum                375          403                1117
Delivered checker.py                    372          399                1107

The improvement survives an identical-driver comparison and a consistent
checking-core comparison. It is a small implementation synthesis, not a
new arithmetic foundation or a proof of absolute shortestness.

The article gives a complete equality-plus-one-logical-binder calculus
with context closure clauses. This idea is already outlined in the
current context-freshness draft; the present package gives its full
specification, proof/context translations, ordinary realization, and
audited equivalence argument. The primary certificate syntax retains Q
as a conservative abbreviation, and ALL of its checking machinery is
counted. The optional direct native checker is larger (394/423/1129).

The new mathematical result is an interpretation obstruction for scalar
update-tied initialization J(n;h)=h^n(S(h(0))). Its standard structure
cannot interpret iPRA by any finite-dimensional first-order interpretation,
including arbitrarily quantified graph definitions, finite parameters,
definable subset domains, and definable quotients.

The theorem survives adding unary helpers with only finitely many infinite
fibres, including predecessor, halving, finite-to-one functions, and
finite-range predicates. It uses a strengthened rectangular decomposition
and Gaifman locality. It does NOT cover arbitrary unary helpers, all
diagonal seeds, or previous-counter-dependent updates. Pairing projections
violate the helper hypothesis. No worldwide-priority claim is made.

The positive calculus is bi-interpretable and equiconsistent with full
first-order intuitionistic PRA through its faithful ordinary realization.
Both numerical domains are unrestricted; internal uniqueness establishes
the two identity-graph composite isomorphisms, including nonstandard inputs.
These are written proofs, not a Lean or Rocq formalization.

RUN
---
  python3 checker.py examples/iterator_zero.json
  python3 checker.py examples/clause_application_reflexivity.json
  python3 checker.py examples/false_equation.json

The first two print ACCEPT and exit 0. The last prints REJECT and exits 1.
Rejection concerns that certificate, not provability of its formula.

  python3 reproduce.py
  python3 build.py

The first command verifies frozen comparator identities, reproduces the
complete/core/common-driver measurements, runs the independent named-syntax
audit, tests formula expansion and the optional native checker, and verifies
compiled native certificates with the primary checker. It needs no network.
The second builds the PDF using pdfLaTeX with shell escape disabled.
Exact measurements use CPython 3.12.14; the checker needs Python 3.10+.

PRIMARY CERTIFICATE SEMANTICS
-----------------------------
The last JSON array item is a closed surface goal. It asserts the native
formula obtained by Q_y B -> D_{u,y} B, with unused u. Native formulas
already containing only equality and ternary D retain their meaning.

reference/expand_formula.py supplies expand_for_primary(A), which makes
that expansion explicit in primary ternary-D syntax. It is inspection
support and is not imported by checker.py.

The optional reference/native_checker.py uses a DIFFERENT serialization:
its unary formula arrays denote D binding two variables. In checker.py,
unary formula arrays denote Q binding one variable. Read reference/README.txt
before using those optional files; do not interchange their packets.

VALIDATION
-----------
3,230 packet comparisons agree with the independent named-binder oracle:
305 accept, 2,925 reject. These include 130 translated positive source
proofs and 3,000 deterministic mutation comparisons. Eighty actual CLI runs
include optimized Python. Every rule is exercised. Both unused-annotation
failed-major fallback forms have targeted controls.

Separate expansion, direct-native, and certificate-compilation checks have
their exact receipts in reference/. Finite validation is distinguished from
the universal mathematical proof.

CONTENTS
--------
checker.py                 Complete trusted primary acceptance program.
report.tex / report.pdf    Full mathematical article.
sections/                  Complete editable proof sections.
FORMAT.txt                 Precise primary packet format.
examples/                  Runnable primary packets.
comparison/                Frozen current and historical sources, hashes, metrics.
validation/                Independent syntax oracle and certificate audit.
reference/                 Optional native checker, expansion, and proof compiler.
results/                   Actual measurements, build and document QA receipts.
reproduce.py / build.py     Offline reproduction and PDF build.
ATTRIBUTION.txt             Inherited and new contributions.
LICENSE_SOURCE.txt         Preserved source permissions.
SHA256SUMS                  Packaged file identities.

PINNED SOURCE
-------------
VladimirReshetnikov/ProveIt, docs/drafts:
25e16049bbc73c92703296181e0696370c987577
https://github.com/VladimirReshetnikov/ProveIt/tree/25e16049bbc73c92703296181e0696370c987577/docs/drafts
