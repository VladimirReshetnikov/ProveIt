"""Reproduce complete-program, core, and identical-driver comparisons.

Analysis support only; the production checker imports none of this file.
The normalizer is the unchanged supplied source_measure.py. The consistent
driver split is adapted from the independent analysis in this iteration.
"""
import ast
import copy
import csv
import hashlib
import json
from pathlib import Path
import platform

from source_measure import metrics

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
FIELDS = ("normalized_tokens", "ast_nodes", "normalized_bytes")
DRIVER = """try:
    take = json.load(open(sys.argv[1])).pop
    if not check(take(), []):
        raise ValueError
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
"""


def split(source):
    tree = ast.parse(source)
    prefix = []
    for node in tree.body:
        if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
            if not prefix:
                continue
        if isinstance(node, (ast.Try, ast.If)):
            break
        if not isinstance(node, (ast.Import, ast.ImportFrom, ast.Assign, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            raise ValueError("Unexpected prefix node: " + ast.dump(node))
        prefix.append(node)
    else:
        raise ValueError("No public driver found")
    if not any(isinstance(n, ast.FunctionDef) and n.name == "check" for n in prefix):
        raise ValueError("Missing check entry point")
    used = {n.id for node in prefix if not isinstance(node, (ast.Import, ast.ImportFrom))
            for n in ast.walk(node) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)}
    core = []
    for node in prefix:
        if isinstance(node, ast.Import):
            kept = [a for a in node.names if not
                    (a.name in ("json", "sys") and (a.asname or a.name.split(".")[0]) not in used)]
            if kept:
                core.append(ast.Import(names=kept))
        else:
            core.append(node)
    return core


def unparse(nodes):
    return ast.unparse(ast.fix_missing_locations(
        ast.Module(body=copy.deepcopy(nodes), type_ignores=[]))) + "\n"


def compact(path):
    m = metrics(path)
    return {k: m[k] for k in (*FIELDS, "source_tokens", "raw_bytes", "sha256")}


def main():
    manifest = json.loads((HERE / "manifest.json").read_text())
    generated = HERE / "controls"
    generated.mkdir(exist_ok=True)
    result_dir = ROOT / "results"
    result_dir.mkdir(exist_ok=True)
    rows = []
    entries = manifest["programs"] + [{
        "label": "delivered/checker.py", "local_file": "../checker.py"}]
    for i, entry in enumerate(entries):
        path = HERE / entry["local_file"]
        raw = path.read_bytes()
        if "sha256" in entry and hashlib.sha256(raw).hexdigest() != entry["sha256"]:
            raise ValueError("Modified frozen comparator: " + str(path))
        core = split(raw.decode("utf-8"))
        core_path = generated / f"{i:02d}_core.py"
        common_path = generated / f"{i:02d}_common.py"
        core_path.write_text(unparse(core))
        common_path.write_text(unparse(ast.parse("import json, sys\n").body +
                                       core + ast.parse(DRIVER).body))
        rows.append({
            "label": entry["label"],
            "role": "candidate" if i == len(entries) - 1 else "current",
            "whole": compact(path), "core": compact(core_path),
            "common_driver": compact(common_path),
            "core_file": str(core_path.relative_to(HERE)),
            "common_driver_file": str(common_path.relative_to(HERE))})
    minima = {mode: {k: min(r[mode][k] for r in rows[:-1]) for k in FIELDS}
              for mode in ("whole", "core", "common_driver")}
    improvements = {mode: {k: rows[-1][mode][k] < minima[mode][k] for k in FIELDS}
                    for mode in minima}
    if not all(all(v.values()) for v in improvements.values()):
        raise ValueError("Strict improvement no longer holds")
    result = {
        "python": platform.python_version(), "implementation": platform.python_implementation(),
        "commit": manifest["commit"], "archive_count": len(manifest["archives"]),
        "current_program_count": len(rows) - 1,
        "normalization": "Remove actual docstrings; ast.unparse plus trailing newline; significant tokens, all AST nodes, normalized UTF-8 bytes.",
        "complete_boundary": "All imports, fixed data, syntax, substitution, rules, JSON input, errors, verdicts, and exit behavior.",
        "core_boundary": "All definitions and initialization before the complete public-driver tail; remove only driver-only json/sys imports; no changes inside functions.",
        "common_driver": "Attach identical json/sys imports and the identical file-argument driver to every core.",
        "current_coordinatewise_minima": minima,
        "strict_improvement": improvements, "programs": rows}
    (result_dir / "measurements.json").write_text(json.dumps(result, indent=2) + "\n")
    with (result_dir / "measurements.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["label", "mode", *FIELDS, "sha256"])
        for r in rows:
            for mode in minima:
                writer.writerow([r["label"], mode, *(r[mode][k] for k in FIELDS), r[mode]["sha256"]])
    print(json.dumps({k: v for k, v in result.items() if k != "programs"}, indent=2))


if __name__ == "__main__":
    main()
