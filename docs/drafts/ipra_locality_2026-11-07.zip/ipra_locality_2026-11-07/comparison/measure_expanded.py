"""Sensitivity inventory of historical and current JSON acceptance sources."""
from pathlib import Path
import hashlib
import json
import platform
from source_measure import metrics

HERE = Path(__file__).resolve().parent


def main():
    manifest = json.loads((HERE / "expanded_manifest.json").read_text())
    fields = ("normalized_tokens", "ast_nodes", "normalized_bytes")
    rows = []
    for row in manifest["distinct"]:
        path = HERE / row["local_file"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != row["sha256"]:
            raise ValueError("Modified inventory source: " + str(path))
        measured = metrics(path)
        rows.append({**row, **{k: measured[k] for k in fields}})
    result = {
        "python": platform.python_version(), "commit": manifest["commit"],
        "source_path_count": len(manifest["paths"]), "distinct_source_count": len(rows),
        "selection": manifest["selection"],
        "coordinatewise_minima": {k: min(r[k] for r in rows) for k in fields}}
    (HERE.parent / "results/expanded_measurements.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
