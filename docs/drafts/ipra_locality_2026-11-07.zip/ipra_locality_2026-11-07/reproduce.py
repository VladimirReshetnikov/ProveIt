"""Recompute the frozen-corpus comparison and finite validation, offline."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    scripts = [
        ("comparison/measure_all.py", []),
        ("comparison/measure_expanded.py", []),
        ("validation/verify_synthesis.py", []),
        ("reference/test_expand.py", []),
        ("reference/test_native.py", []),
        ("reference/test_compile_primary.py", [str(ROOT / "checker.py")]),
    ]
    for script, args in scripts:
        print("Running " + script, flush=True)
        subprocess.run([sys.executable, str(ROOT / script), *args], cwd=ROOT, check=True)
    print("All bundled reproduction checks passed.")


if __name__ == "__main__":
    main()
