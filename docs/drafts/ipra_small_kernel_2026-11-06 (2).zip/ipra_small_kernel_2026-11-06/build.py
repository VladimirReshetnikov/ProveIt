"""Reproduce certificates, checks, measurements, and the compiled report."""

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VERIFY = ROOT / "verification"


def run_python(name, destination):
    result = subprocess.run([sys.executable, str(ROOT / "code" / name)],
                            cwd=ROOT, capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(result.stdout + result.stderr)
    parsed = json.loads(result.stdout)
    (VERIFY / destination).write_text(json.dumps(parsed, indent=2) + "\n")
    return parsed


def metrics_macros(metrics):
    names = {"recommended": "H", "hilbert_reflexivity": "HR", "natural_deduction": "ND"}
    fields = {"bytes": "Bytes", "code_lines": "Lines", "ast_nodes": "AST",
              "lexical_tokens": "Tokens", "normalized_bytes": "Normalized"}
    lines = []
    for key, prefix in names.items():
        for field, suffix in fields.items():
            value = metrics["variants"][key]["totals"][field]
            lines.append("\\newcommand{\\" + prefix + suffix + "}{" + f"{value:,}" + "}")
    h = metrics["variants"]["recommended"]["totals"]
    nd = metrics["variants"]["natural_deduction"]["totals"]
    for field, name in (("bytes", "RawSaving"), ("normalized_bytes", "NormalizedSaving")):
        value = 100 * (nd[field] - h[field]) / nd[field]
        lines.append("\\newcommand{\\" + name + "}{" + f"{value:.2f}" + "\\%}")
    (VERIFY / "metrics.tex").write_text("\n".join(lines) + "\n")


def main():
    VERIFY.mkdir(exist_ok=True)
    results = {}
    results["certificates"] = run_python("make_examples.py", "certificates.json")
    results["nd_certificates"] = run_python("make_nd_examples.py", "nd_certificates.json")
    results["kernel_tests"] = run_python("test_kernel.py", "kernel_tests.json")
    results["binding_tests"] = run_python("test_binding.py", "binding_tests.json")
    results["nd_tests"] = run_python("test_nd.py", "nd_tests.json")
    results["metrics"] = run_python("measure.py", "checker_metrics.json")
    metrics_macros(results["metrics"])
    for number in range(1, 4):
        command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex"]
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
        if result.returncode:
            (VERIFY / "latex_error.txt").write_text(result.stdout + result.stderr)
            raise RuntimeError("LaTeX compilation failed; see verification/latex_error.txt")
    log = (ROOT / "report.log").read_text(errors="replace")
    results["latex"] = {
        "passes": 3,
        "overfull_boxes": log.count("Overfull "),
        "undefined_references": log.count("undefined references"),
        "undefined_citations": log.count("Citation") if "undefined" in log else 0,
        "pdf_bytes": (ROOT / "report.pdf").stat().st_size,
    }
    (VERIFY / "build_results.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps({"status": "PASS", "latex": results["latex"]}, indent=2))


if __name__ == "__main__":
    main()
