# Audit of the six current iPRA draft archives

Snapshot: `VladimirReshetnikov/ProveIt`, commit `86b708a209fd20431908347c5aa051d73c8d4682`. All six archive byte strings were verified against the Git blob hashes returned for this pinned directory. This audit concerns these six current files; older archives cited within them are historical sources.

## Main conclusion

**None of the six current archives contains a complete executable proof checker.** Every supplied Python artifact is explicitly a finite diagnostic: syntax and tree-size accounting, substitution/translation examples, standard-natural-number calculations, or local equational trace replay. There is no proof datatype encompassing all logical inference rules and no acceptance procedure for arbitrary proof trees of the specified complete theory. Therefore there is no measured “smallest complete checker” among the delivered source programs, and comparing a new actual kernel's bytes with their diagnostic-program bytes would be misleading.

All six nevertheless specify a complete mathematical theory. Their ordinary core is substantially the same: full intuitionistic first-order natural deduction with equality, the separation sentence `(0=S0)->false`, initialized primitive-recursion computation equations, and the same positive-successor equation closure principle. The differences are mainly vocabulary pruning, optional translations, and representation of closure as an axiom or as a contextual inference rule.

The existing five-node improvements are improvements in *expanded axiom instance syntax*, not reductions in implementation source size. Their own limitations sections expressly distinguish these measures. Thus the present user metric asks for a new benchmark the archives do not yet provide.

## Core specification comparison

| Archive | Ordinary core | Extra conditions or variants | Consequence for a checker-size comparison |
|---|---|---|---|
| `ipra_direct_induction_2026-11-03.zip` | Raw initialized recursion; all equation instances of positive-successor closure | Allows unused parameters and literal identity recursors | Simplest obvious unoptimized baseline; no support analysis or optimizer needed |
| `ipra_rooted_step_2026-11-03.zip` | Same raw core and same closure, named rooted step | Separate certified initialization erasure and nonbinary zero-test compiler | Optional optimizers are not needed to check the ordinary theory |
| `ipra_successor_rule_2026-11-03.zip` | Same raw core; closure as a contextual rule | Separate unused-parameter interpretation preserving historical labels | Optional support checker and translation add implementation obligations |
| `ipra_explicit_2026-11-03(1).zip` | Same arithmetic closure | Primary signature requires exact active parameter support and omits literal `h=v`; separate padded counter-projection quotient | Smaller formulas may require larger formation checker; exact support requires active-FV computation and canonical slot discipline |
| `ipra_positive_step_2026-11-03.zip` | Same closure; conclusion in the primary rule is universally quantified | Minimal-support signature; separate selector fusion and source-preserving refinements; optional native binder notation | Universal conclusion can avoid an arbitrary-result instantiation in the arithmetic rule; many optional optimizations should stay outside trusted kernel |
| `ipra_successor_progress_2026-11-03.zip` | Same raw core and contextual closure | Standalone reduced theory erases descriptors whose completed raw computation normal form is the state variable | The reduced language's formation predicate needs a normalizer or explicit checkable certificates; formula savings do not imply checker savings |

The common equation closure is, for equation `E(x,c)`,

`[forall x ((x=0 or E(x,c)) -> E(Sx,c))] -> forall x (x=0 or E(x,c))`,

universally closed in the parameters. Its contextual rule is

`Gamma, x=0 or E(x,c) |- E(Sx,c)` / `Gamma |- t=0 or E(t,c)`,

with `x` fresh for retained context, result term and parameter tuple. Positive-step uses the equivalent universally quantified result. Direct-induction and rooted-step explicitly state rule/axiom equivalence.

The ordinary natural-deduction interfaces have 17 logical rule schemata when separate conjunction eliminations and disjunction introductions are counted separately: assumption, weakening, equality reflexivity and elimination, three conjunction rules, three disjunction rules, two implication rules, falsity elimination, two universal and two existential rules. An arithmetic-axiom leaf and the arithmetic closure mechanism are additional. This count is descriptive; it is not a source-code lower bound.

## Exact code measurements

`draft_metrics.json` contains exact bytes, physical lines, nonblank lines, lines after excluding blank and comment-only lines, Python AST node counts, imports, and top-level function names. The following table excludes build scripts and copied historical sources. These are **diagnostic sizes, never full-kernel sizes**.

| Archive | Program | UTF-8 bytes | Physical lines | Nonblank lines | Python AST nodes |
|---|---|---:|---:|---:|---:|
| direct-induction | `artifacts/check_core.py` | 16,389 | 378 | 303 | 3,179 |
| explicit | `artifacts/verify.py` | 17,262 | 413 | 349 | 3,994 |
| positive-step | `verify_reductions.py` | 23,671 | 590 | 486 | 5,274 |
| rooted-step | `artifacts/check_syntax.py` | 19,006 | 494 | 408 | 4,044 |
| rooted-step | `artifacts/check_zero_tests.py` | 12,704 | 356 | 309 | 2,026 |
| successor-progress | `artifacts/verify.py` | 26,546 | 715 | 603 | 5,463 |
| successor-rule | `artifacts/check_syntax.py` | 35,750 | 803 | 695 | 6,171 |

The direct-induction code is smallest in this incidental diagnostic-byte table. That fact says nothing about the smallest checker. For instance successor-rule spends much of its larger file enumerating fixtures, recording metrics and testing source-relative translations; that code is neither necessary nor sufficient to recognize the theory's proofs.

## Re-executed validation

I copied each diagnostic program into `an isolated temporary directory for each archive` and ran that copy, so no source-archive extraction was modified. All seven programs exited successfully; stderr was empty. Exact commands' program names, return codes, stdout, stderr and wall times are in `diagnostic_run_results.json`.

- Direct-induction passed its syntax, arithmetic, Boolean compiler and finite pointed-successor-map suites.
- Explicit passed closure costs, frozen descriptor behavior, symbolic padded-counter obligations, homomorphic erasure, substitution, binding negative controls and Boolean tables.
- Positive-step reported 6,084 successful finite checks.
- Rooted-step passed syntax counts and initialization certificates. Its zero-test program checked 6,328 formulas on 64 assignments (404,992 formula-assignment cases), plus numeric identities and cost checks.
- Successor-progress replayed the 17-step stride-seven equational certificate and passed its negative trace and budget controls.
- Successor-rule checked 1,722 source terms, 1,686 target terms, 10,333 closure-cost cases, 961 full formulas, 12 original recursion modules and 13 unused-parameter-family cases.

Passing these tests does not mechanically verify intuitionistic soundness, the unrestricted quantified language, induction recovery, or the bi-interpretation theorem. The mathematical claims rely on the reports' proofs. No additional defect was exposed by these runs, and I did not find evidence justifying a claim that a full current mathematical presentation is inconsistent or unsound.

## Trust boundary and hidden costs

A genuine complete checker must at least implement or encode:

1. Term/formula formation, including generated recursor descriptions and active arities.
2. Correct scoping of descriptors: substitution touches actual arguments but not frozen labels; a descriptor's own formal slots are substituted only when the computation schema is instantiated.
3. Capture avoidance or an equivalent nameless binder discipline.
4. Context management and discharge, including branch hypotheses.
5. Eigenvariable freshness for universal introduction, existential elimination and arithmetic induction.
6. Equality elimination for arbitrary formulas, or a complete alternative equality interface.
7. Both computation equations and their substitution instances.
8. Precisely equation-only or otherwise justified restricted induction; quantifier-free recognition cannot be silently omitted if unrestricted formulas could then be inducted upon.
9. Finite-certificate validation, including index bounds, arities and malformed input rejection.

A uniform native recursion binder may avoid frozen-descriptor metadata at the cost of substitution under two new binders and a proof that elaboration commutes with substitution up to provable equality. The positive-step appendix already identifies that subtlety. A new implementation should not count a high-level substitution or normalization library as zero cost.

For descriptor-normalization erasure, either the normalizer is part of the trusted grammar/axiom generator, or a finite certificate must be replayed in a simpler raw theory. Keeping optimization external and checking its output with the raw kernel is attractive under the user's metric, but changes the object being measured: it improves the trusted checker while potentially increasing certificates.

Unused-parameter removal similarly cannot be credited as a source-code improvement simply because call syntax is shorter. Allowing unused slots makes formation checking simpler; semantic independence can be derived and then used by an external compiler.

## Comparison conclusions

1. A complete kernel for the common raw core is already “at the level of” all six ordinary mathematical presentations, since they share that core up to harmless definitional vocabulary conventions and rule/axiom interderivation. This is a theory comparison, not a byte lower-bound theorem.
2. For an implementation-size claim, implement variants in the same language, AST representation, scoping method and acceptance contract, then compare only necessary kernel functions and count the entire trusted input-validation layer. Include the common baseline source, reproducible metric script and exact scope.
3. A change that removes a primitive connective/rule family with explicitly proved definitions may give a genuine structural saving. A claim of “X bytes shorter than every supplied checker” is unavailable because supplied complete checkers do not exist.
4. The earlier tree nonincrease theorems remain valid in their declared ledgers but cannot establish the user-requested checker-code lower envelope.
5. No absolute optimum over arbitrary computably presented languages and software encodings is established by these drafts or by this audit.

## Source locations supporting the audit

Every archive's `README.txt` has a final “Verification scope/status” section. Direct-induction `artifacts/check_core.py` opens with an especially explicit disclaimer. Successor-rule `artifacts/check_syntax.py` opens with a detailed list of unverified metatheorems. Rooted-step `sections/05_limits_artifacts.tex` separates tree counts from whole generator/calculus complexity. Positive-step `sections/06_refinement.tex` ends its packet-size discussion by disclaiming a shorter whole schema generator; `sections/07_limits.tex` asks for a genuine checker/lower-bound benchmark. Successor-progress `SPECIFICATION.txt`, section D, makes its externally total descriptor normalizer explicit, and its `README.txt` disclaims uniform primitive-recursive runtime.
