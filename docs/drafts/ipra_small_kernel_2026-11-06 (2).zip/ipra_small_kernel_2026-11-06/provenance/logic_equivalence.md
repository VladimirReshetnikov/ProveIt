# Independent logical equivalence and implementation audit

## 1. The reflexivity deletion is sound

Fix an arbitrary numerical term `t`, including any free parameters and any generated recursor symbols. Let `q = R_0(0,t)`, where the frozen update description is the constant zero term, with no auxiliary parameters. The existing base-computation schema gives

    q = t.

Instantiate full Leibniz substitution with `s=q`, `u=t`, and the formula template `A(z) := z=t`. Its instance is

    q=t -> ((q=t) -> (t=t)).

Two applications of modus ponens to the same computation theorem produce `t=t`. Thus the ordinary reflexivity schema is derivable and may be deleted. Neither step presupposes equality symmetry, equality reflexivity, natural-deduction discharge, nor a semantic argument about the standard numbers.

In the implementation's de Bruijn notation the template must be

    Eq(0, lift(t)),

not `Eq(0,t)`, because slot 0 is the newly introduced placeholder and all existing parameters of `t` are outer parameters. The resulting proof has four records: a computation instance, a Leibniz instance, and two MPs.

The descriptor `h=0` exists in all six reviewed signatures; restrictions removing unused parameter slots or the identity update do not remove this descriptor. Hence this is a strict deletion common to their complete calculi. It does not require a new primitive symbol or new axiom family.

The post-deletion inventory is **14 logical schemas, four arithmetic families, and two inference rules**. Pure equality logic without arithmetic no longer has its usual reflexivity axiom, but the complete proposed arithmetic theory derives it. State the equivalence for the complete theory, not for its isolated 14-template logical fragment.

A useful related observation is that `A -> A` is derivable without the K/S identity construction: use the fixed computation equality `R_0(0,0)=0` and Leibniz with the placeholder-independent template `lift(A)`. This is a derived proof abbreviation, not another kernel primitive.

## 2. Exact syntax and namespace conventions

Every object-level numerical variable is a nonnegative de Bruijn index. At the outer level, index `i` is a free parameter. A quantifier binds the nearest slot 0, so its body is in a namespace containing one extra leading slot. At depth `d`, indices below `d` refer to enclosing binders; larger indices refer to outer free parameters after subtracting `d`.

A frozen recursor description has a separate local namespace consisting of slots for previous value, previous counter, then auxiliary parameters. It is a function symbol label. Active substitution changes a recursor call's actual arguments and never traverses its frozen label. A nested descriptor has its own local namespace. The finite syntax tree supplies a well-founded dependency rank.

Let `sub(e,sigma)` simultaneously replace the free numerical parameters of an expression. Under a logical binder the environment is lifted to

    sigma_up(0)   = 0,
    sigma_up(i+1) = lift(sigma(i)).

Here `lift(e) = sub(e, i |-> i+1)`. The implementation's `inst(A,t)` is

    sub(A, i |-> t if i=0 else i-1).

It consumes the formal leading slot. These definitions are standard capture-avoiding substitution, including when `t` itself has free parameters and when `A` contains nested quantifiers. The two important identities are

    sub(lift(B), sigma_up) = lift(sub(B,sigma)),

    sub(inst(A,t), sigma)
      = inst(sub(A,sigma_up), sub(t,sigma)).

They follow by structural induction. Frozen labels remain identical on both sides. These identities, rather than informal alpha-renaming, justify quantifier and equality template instantiation in the checker.

## 3. Four quantifier schemas without freshness tests

For formula bodies `A,B` and number term `t`, the four generators are:

    UI:  All(A) -> inst(A,t)
    EI:  inst(A,t) -> Ex(A)
    UD:  All(lift(A) -> B) -> (A -> All(B))
    ED:  All(A -> lift(B)) -> (Ex(A) -> B).

In UD, `A` is an outer formula while `B` is a body in the extended namespace. In ED, `B` is an outer formula while `A` is a body. The apparent asymmetry is intentional. The lifted component cannot acquire a free occurrence of the newly bound variable. Thus the familiar side conditions `x not free in A` and `x not free in B` are enforced by construction, with no separate free-variable scan.

A formula body is not a second-order object in the theory. It is finite syntax supplied to an axiom schema. Quantification is solely over the one numerical sort.

## 4. Why generalization is just wrapping

The checker stores only theorems; it has no undischarged assumptions. Its primitive rule is

    from F infer All(F).

This binds the nearest free parameter slot 0. The meanings of remaining outer parameters are canonically reindexed. Under the named-variable reading this is universal generalization followed by an admissible renaming of the remaining free parameters. It is not the rule that generalizes a formula under an arbitrary open assumption.

A precise semantic check is simple. Given an arbitrary outer valuation `rho` and any domain element `a`, define `rho'(0)=a` and `rho'(i+1)=rho(i)`. Because `F` is a theorem for every assignment, it holds at `rho'`. Hence `All(F)` holds at `rho`. This uses no classical logical principle.

For a syntactic check, substitution of arbitrary terms for free parameters is admissible in the complete Hilbert system. Prove this by induction on the certificate, with the induction hypothesis quantified over every substitution environment. MP is homomorphic. Each axiom is an instance of the same family after substitution, using the identities above. In the Gen case, translate its premise under `sigma_up` and then apply Gen. The rooted arithmetic schema is stable because its leading induction variable is bound and `sigma_up` fixes that slot. Computation instances are stable because labels are frozen and their actual parameters transform simultaneously.

In particular, permutations and renamings of free parameters are admissible. To generalize another selected parameter, first permute it into slot 0, then use wrapping. This is an external proof transformation, not additional trusted kernel functionality.

The implementation correctly allows arbitrary finite free indices on every proof line (`bound=None`). A different checker that forced every line into one fixed arity would have to account for the extra binder explicitly; that is not what this implementation does.

## 5. Hilbert to natural deduction

Let `H` be the proposed checker calculus, and let `N` be standard intuitionistic natural deduction over the same numerical signature with the same arithmetic axiom family. For a source presented by an arithmetic rule, first use the rule/axiom equivalence in section 7 below.

Every Hilbert axiom has a natural-deduction derivation:

- K introduces two assumptions and retains the first.
- S introduces its three assumptions, obtains the two consequences of the last assumption, and applies implication elimination.
- The three conjunction and three disjunction axioms follow from their usual introduction/elimination rules.
- `false -> A` is ordinary falsity elimination under a discharged assumption.
- UI and EI are the quantifier elimination/introduction rules under an implication assumption.
- UD introduces its outer antecedent and `A`, instantiates the universal premise at a fresh number, obtains the body, then universally generalizes. The lift enforces freshness for `A`.
- ED applies existential elimination to a fresh witness and uses the universal implication at that witness. The lift ensures that the witness cannot escape into the conclusion.
- Leibniz is two implication introductions followed by equality elimination.

MP is natural-deduction implication elimination. Gen is valid because every Hilbert line is a theorem with an empty assumption context; the preceding namespace account explains its canonical parameter renaming. Arithmetic leaves are the same axioms. Therefore every accepted Hilbert theorem is a natural-deduction theorem.

Deleting reflexivity only strengthens this soundness argument: the deleted rule is never trusted. Its four-line derivation shows that nothing is lost in the other direction.

## 6. Natural deduction to Hilbert

For this proof only, consider Hilbert derivations with a finite set of undischarged hypotheses and permit generalization only on parameters absent from those hypotheses. This is a mathematical intermediate calculus; it is not an input mode of the shipped checker.

The standard deduction theorem is effective:

    Gamma,A |- B  implies  Gamma |- A -> B,

provided the generalizations of the source derivation obey the stated restriction. Its proof is an induction on the finite derivation:

1. An axiom or an assumption from `Gamma` is prefixed with `A ->` using K.
2. The hypothesis `A` is replaced by a derivation of `A -> A` (from K/S, or the computation/Leibniz derivation above).
3. A modus-ponens step is transformed by S.
4. For a generalization step, the induction hypothesis gives `A -> B`; generalize the allowed fresh parameter and use UD to obtain `A -> All(B)`.

This gives explicit algorithms, with finite proof expansion, rather than assuming implication introduction as an extra kernel rule.

Now translate a natural-deduction derivation by induction on its tree:

- An assumption is an intermediate Hilbert hypothesis.
- Weakening merely adds hypotheses; eigenvariables are renamed first when necessary.
- Conjunction and disjunction introductions/projections use their templates and MP.
- For disjunction elimination, apply the deduction theorem to each branch, then the disjunction elimination template and MP.
- Implication introduction is the deduction theorem; implication elimination is MP.
- Falsity elimination is the falsity template and MP.
- Universal elimination and existential introduction use UI/EI.
- Universal introduction uses generalization, with the same freshness condition as the natural-deduction source.
- For existential elimination, the translated witness branch and deduction theorem give `A(y) -> C`; generalize the fresh witness `y`; ED then gives `(exists x A(x)) -> C`, followed by MP with the existential premise.
- Equality elimination uses Leibniz and two MPs.
- Equality reflexivity uses the four-line derived proof from section 1.
- Arithmetic axioms are unchanged; the contextual arithmetic rule is handled by section 7.

Finally discharge all hypotheses by the deduction theorem. For an arbitrary finite context `(G1,...,Gm)`, this produces an ordinary theorem certificate for

    G1 -> (G2 -> ... (Gm -> A)...).

In particular, an empty-context source proof gives a checker certificate of the same theorem. Define contextual entailment of the theorem-only checker by this currying convention. Its usual intuitionistic structural properties follow from the propositional templates; the checker does not need to implement contexts.

Consequently `H` and `N` have exactly the same theorems and contextual consequences in the **full first-order language**, not just on quantifier-free or negative formulas. The identity maps are interpretations in both directions and both round trips are literally identities. Genuine falsity is fixed. Thus the equivalence preserves syntactic consistency, and it gives the desired full bi-interpretability once the supplied arithmetic reconstruction of iPRA is composed with it.

## 7. The rooted rule and its axiom form

Let `E(x,c)` be a single equation and write `B(x,c) := (x=0 or E(x,c))`. The implemented arithmetic schema is

    (forall x (B(x,c) -> E(Sx,c))) -> forall x B(x,c).

Its equivalence with the natural-deduction rule

    from Gamma, B(x,c) |- E(Sx,c)
    infer Gamma |- B(t,c),

where `x` is fresh for `Gamma,t,c`, is exact.

From the axiom: discharge `B(x,c)` from the premise, generalize the fresh `x`, apply the schema by MP, and instantiate the result at `t`.

From the rule: assume the axiom's antecedent; under an additional assumption `B(x,c)`, instantiate that antecedent at a fresh `x` and derive `E(Sx,c)`. Apply the rule to a fresh target parameter, universally generalize that target, and discharge the original antecedent. This derives the axiom.

The free parameters `c` need not be closed terms. They are held fixed during the induction step. In the implemented de Bruijn schema they are slots 1,2,... of `E`; the outer quantifier binds only slot 0. Arbitrary parameter substitutions therefore remain valid.

## 8. Independent review of the actual implementation

Reviewed files (as present during this audit):

- `code/syntax.py`
- `code/arithmetic.py`
- `code/hilbert.py`
- `code/check.py`

**No soundness defect was found in these four files during this review.** This is a manual review of the implementation and invariants, not a formal verification theorem. Specific checks:

1. `sort` distinguishes number terms from formulas; Python booleans cannot masquerade as integer variable indices because it uses `type(e) is int`. Negative variable indices are rejected.
2. Every external axiom argument and the requested goal are recursively validated. Unknown constructors, malformed tuple lengths, formula-valued numerical arguments, and out-of-range descriptor variables are rejected.
3. A recursor node has descriptor, counter, initializer, and zero or more parameter arguments. Its descriptor bound `len(args)-1` is exactly two plus the number of auxiliary parameters. Nested labels get separate bounds. Finite trees prevent circular function definitions.
4. Ordinary substitutions leave descriptor labels unchanged and transform all actual arguments. R1 substitutes the tuple `(previous_recursion_value, previous_counter, parameters...)` into the validated descriptor. R0's supplied counter is harmlessly ignored because the output instance uses zero.
5. Logical substitution under both quantifiers uses the correct lifted environment. UD and ED lift the outer formula in the correct position; UI, EI and equality all use the same consuming instantiation operation.
6. `ind` requires an atomic equation. Its successor substitution changes only the distinguished slot 0 to `S(0)` and fixes parameter slots; the surrounding quantifiers then bind exactly that slot.
7. MP checks that its major premise is an implication and that the antecedent equals the minor premise. Both references must point strictly backward. Generalization also references an already proved theorem.
8. Generated conclusions need not be redundantly revalidated: each generator preserves typing/scoping by the above checks, MP extracts a validated formula component, and Gen adds a valid binder. This is an invariant of the accepted proof list.
9. The public JSON entry point requires exactly `proof` and `goal`, recursively freezes lists to tuples, rejects malformed shapes through the checker, and catches relevant parsing/validation/index/recursion/file exceptions. Invalid examples cannot become theorem lines merely by providing a purported conclusion: line conclusions are synthesized by the kernel.
10. Integer indices and all tuple/formula comparisons rely on Python's standard exact arithmetic and structural equality. These runtime services belong to the stated trusted substrate for both implementations.

One documentation point matters: two calls with the same descriptor body but different numbers of unused auxiliary arguments denote different generated symbols. The effective label includes the declared arity, represented by the actual argument-vector length; it is not merely the raw body tree. This is sound, and should match the report's signature definition.

## 9. Further deletion and minimality limits

I did not find another justified logical-template deletion that is simultaneously a straightforward code reduction. I considered replacing the falsity schema with a fixed arithmetic bridge `false -> 0=S0`; arithmetic collapse would then derive full explosion by external formula induction. This is sound with Sep retained, but it replaces one short template by a longer fixed axiom and gives no evident checker-size improvement. The weaker bridge `0=S0 -> false` alone does not derive explosion in minimal logic.

A bounded typed-combinator search also explored whether K follows economically from S and the conjunction axioms; it found no witness within the searched size, which is not an independence result and should not be presented as one. No conclusion in the report need depend on this experiment.

The reflexivity deletion is an exact theorem independent of the source-code metric. The Hilbert-versus-ND size comparison is encoding dependent and must include the fixed template table and shared parser/validation/scoping layer. An optimized ND baseline should make weakening implicit in ambient contexts, rather than implementing an artificially expensive separate set-inclusion operation.

Neither a finite list of proposals nor a byte comparison establishes an absolute lower bound on all iPRA axiomatizations or all programming languages. The warranted claim is: a complete equivalent theory, one strict common redundancy removed, and a measured implementation improvement under an explicit common representation. Its provable-equivalence claim is exact; its global minimality claim must remain limited.

## 10. Final report and controlled-baseline review

I independently read `report.tex` and `sections/arithmetic_proof.tex` after they were assembled. No rigorous mathematical defect was found. In particular, I rechecked the residual reconstruction induction, the asymmetric equality zero-test `Q(d(Ss,t),1)`, its constructive decidability argument, the full quantifier-free reflection including implication, and the product countermodel. The proof order does not circularly use quantifier-free induction to obtain equation reflection or coverage. The stated whole-carrier interpretation composites use internal uniqueness, which is the required stronger argument beyond merely giving two interpretations.

The controlled Hilbert-with-reflexivity implementation is an exact copy of the recommended kernel plus the three-line `refl` branch. Its JSON entry point differs only in the imported module name. Existing six certificates are accepted by both variants; a one-line primitive-reflexivity certificate is accepted only by the comparison variant. The raw total difference of 99 bytes consists of **87 bytes of additional checking code and 12 bytes of longer module-import name**. Both are included in full-closure totals, but only the former should be described as the mathematical deletion's code branch.

`code/measure.py` emits one complete JSON object on stdout and writes the same object to `verification/checker_metrics.json`. The requested keys are `variants.recommended`, `variants.hilbert_reflexivity`, and `variants.natural_deduction`. Totals include shared syntax and arithmetic once. `nonblank_lines` is explicitly the alias for nonblank, noncomment source lines (docstrings retained); `code_lines` is additionally provided and excludes docstrings. AST nodes, lexical tokens and normalized AST-unparse bytes exclude docstrings/comments/layout as specified in the JSON definitions. Every source file has a SHA-256 hash. No original diagnostic-script size is used in the comparison.
