"""Reproduce complete checker-size metrics; this script is not trusted code."""

import ast
import hashlib
import io
import json
from pathlib import Path
import sys
import tokenize


CODE = Path(__file__).resolve().parent
ROOT = CODE.parent
SHARED = ("syntax.py", "arithmetic.py")
CLOSURES = {
    "hilbert": SHARED + ("hilbert.py", "check.py"),
    "hilbert_with_reflexivity": SHARED + (
        "hilbert_reflexivity.py", "check_hilbert_reflexivity.py"
    ),
    "natural_deduction": SHARED + ("nd.py", "check_nd.py"),
}
REFLEXIVITY_BRANCH = (
    '    if tag == "refl":\n'
    '        arguments(args, "t")\n'
    '        return Eq(args[0], args[0])\n'
)
METRICS = (
    "bytes", "physical_lines", "nonblank_noncomment_lines", "code_lines",
    "ast_nodes", "lexical_tokens", "normalized_ast_unparse_bytes",
)


def docstring_statement(node):
    if not isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef,
                             ast.ClassDef)) or not node.body:
        return None
    first = node.body[0]
    if isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant):
        if isinstance(first.value.value, str):
            return first
    return None


class RemoveDocstrings(ast.NodeTransformer):
    def generic_visit(self, node):
        first = docstring_statement(node)
        if first is not None:
            node.body = node.body[1:]
        return super().generic_visit(node)


def measure(path):
    data = path.read_bytes()
    source = data.decode("utf-8")
    tree = ast.parse(source, filename=path.name)
    docstrings = []
    for node in ast.walk(tree):
        statement = docstring_statement(node)
        if statement is not None:
            docstrings.append((
                (statement.lineno, statement.col_offset),
                (statement.end_lineno, statement.end_col_offset),
            ))
    excluded = {
        tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
        tokenize.NEWLINE, tokenize.NL, tokenize.INDENT, tokenize.DEDENT,
    }
    tokens = []
    for token in tokenize.generate_tokens(io.StringIO(source).readline):
        if token.type in excluded:
            continue
        if any(start <= token.start and token.end <= end
               for start, end in docstrings):
            continue
        tokens.append(token)
    code_lines = set()
    for token in tokens:
        code_lines.update(range(token.start[0], token.end[0] + 1))
    stripped_tree = RemoveDocstrings().visit(tree)
    normalized = ast.unparse(stripped_tree) + "\n"
    lines = source.splitlines()
    return {
        "path": "code/" + path.name,
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "physical_lines": len(lines),
        "nonblank_noncomment_lines": sum(
            bool(line.strip()) and not line.lstrip().startswith("#")
            for line in lines
        ),
        "code_lines": len(code_lines),
        "ast_nodes": sum(1 for _ in ast.walk(stripped_tree)),
        "lexical_tokens": len(tokens),
        "normalized_ast_unparse_bytes": len(normalized.encode("utf-8")),
    }


def verify_control():
    original = (CODE / "hilbert.py").read_text()
    marker = "    return arithmetic(tag, args)\n"
    if original.count(marker) != 1:
        raise ValueError("cannot identify the unique arithmetic dispatch")
    expected = original.replace(marker, REFLEXIVITY_BRANCH + marker)
    if (CODE / "hilbert_reflexivity.py").read_text() != expected:
        raise ValueError("reflexivity baseline is not the specified exact copy")
    entry = (CODE / "check.py").read_text()
    marker = "from hilbert import check"
    if entry.count(marker) != 1:
        raise ValueError("cannot identify the Hilbert import")
    expected_entry = entry.replace(marker, "from hilbert_reflexivity import check")
    if (CODE / "check_hilbert_reflexivity.py").read_text() != expected_entry:
        raise ValueError("baseline entry point has differences beyond its import")
    return {
        "verified": True,
        "difference": "one reflexivity schema branch and the entry-point import",
        "added_branch": REFLEXIVITY_BRANCH,
    }


def main():
    result = {
        "python_version": sys.version.split()[0],
        "scope": (
            "Each total includes syntax, validation, substitution, arithmetic, "
            "the full logical kernel including template data, and the JSON entry "
            "point exactly once. Python/runtime/standard-library implementations, "
            "proof producers, tests and this measurement script are excluded "
            "equally. No old diagnostic-program bytes are used as a comparator."
        ),
        "definitions": {
            "bytes": "UTF-8 source bytes, including documentation and whitespace",
            "physical_lines": "number of source splitlines(), including blank lines",
            "nonblank_noncomment_lines": (
                "nonblank lines not starting with # after whitespace; docstrings count"
            ),
            "code_lines": (
                "distinct physical lines occupied by nonlayout, noncomment tokens, "
                "excluding module/function/class docstrings"
            ),
            "ast_nodes": "ast.walk node count after removal of docstring statements",
            "lexical_tokens": (
                "Python tokens excluding encoding/end markers, layout, comments "
                "and module/function/class docstrings"
            ),
            "normalized_ast_unparse_bytes": (
                "UTF-8 bytes of ast.unparse after docstring removal, plus one newline"
            ),
        },
        "controlled_baseline": verify_control(),
        "files": {},
        "checkers": {},
    }
    names = sorted({name for closure in CLOSURES.values() for name in closure})
    for name in names:
        if (CODE / name).is_file():
            result["files"][name] = measure(CODE / name)
    for name, closure in CLOSURES.items():
        missing = [item for item in closure if item not in result["files"]]
        if missing:
            result["checkers"][name] = {
                "status": "pending", "files": list(closure), "missing": missing,
            }
            continue
        totals = {
            metric: sum(result["files"][item][metric] for item in closure)
            for metric in METRICS
        }
        result["checkers"][name] = {
            "status": "measured", "files": list(closure), "totals": totals,
        }
    baseline = result["checkers"]["hilbert_with_reflexivity"]["totals"]
    candidate = result["checkers"]["hilbert"]["totals"]
    result["reflexivity_deletion_savings"] = {
        metric: baseline[metric] - candidate[metric] for metric in METRICS
    }
    result["definitions"]["nonblank_lines"] = (
        "alias of nonblank_noncomment_lines; docstrings are retained"
    )
    result["definitions"]["normalized_bytes"] = (
        "alias of normalized_ast_unparse_bytes"
    )
    result["variants"] = {}
    variant_names = {
        "recommended": "hilbert",
        "hilbert_reflexivity": "hilbert_with_reflexivity",
        "natural_deduction": "natural_deduction",
    }
    for display_name, checker_name in variant_names.items():
        item = result["checkers"][checker_name]
        variant = {"status": item["status"], "files": item["files"]}
        if item["status"] == "measured":
            totals = dict(item["totals"])
            totals["nonblank_lines"] = totals["nonblank_noncomment_lines"]
            totals["normalized_bytes"] = totals["normalized_ast_unparse_bytes"]
            variant["totals"] = totals
        else:
            variant["missing"] = item["missing"]
        result["variants"][display_name] = variant
    destination = ROOT / "verification" / "checker_metrics.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
