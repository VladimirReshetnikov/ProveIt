"""Focused positive and adversarial tests for the independent ND baseline."""

import json
from pathlib import Path
import subprocess
import sys
import tempfile
from syntax import Z, BOT, S, Eq, Imp, Or, All, Ex, lift, inst
from arithmetic import arithmetic
from nd import check


def main():
    t, u, a = Eq(Z, Z), Eq(S(Z), S(Z)), Eq(0, Z)
    refl = ("refl",)
    h = ("hyp", 0)
    positive = [
        ("reflexivity", refl, t),
        ("assumption_and_discharge", ("lam", h), Imp(a, a)),
        ("conjunction_intro", ("pair", refl, refl), ("&", t, u)),
        ("left_intro", ("left", refl), Or(t, a)),
        ("right_intro", ("right", refl), Or(a, t)),
        ("first_projection", ("fst", u, ("pair", refl, refl)), t),
        ("second_projection", ("snd", t, ("pair", refl, refl)), u),
        ("implication_elim", ("app", t, ("lam", h), refl), t),
        ("falsity_elim", ("lam", ("false", h)), Imp(BOT, a)),
        ("all_intro", ("all", refl), All(Eq(0, 0))),
        ("freshness_by_lifting", ("lam", ("all", h)), Imp(a, All(lift(a)))),
        ("existence_intro", ("exists", S(0), refl), Ex(Eq(0, 0))),
        ("universal_elim", ("inst", Eq(0, 0), S(0), ("all", refl)), Eq(S(0), S(0))),
        ("disjunction_cases", ("lam", ("cases", t, u, h,
            ("right", ("hyp", 1)), ("left", ("hyp", 1)))), Imp(Or(t, u), Or(u, t))),
        ("existential_elim", ("lam", ("choose", Eq(0, S(0)), h,
            ("exists", 0, ("hyp", 1)))), Imp(Ex(Eq(0, S(0))), Ex(Eq(0, S(0))))),
        ("equality_symmetry", ("lam", ("subst", 0, 1, Eq(0, 1), h, refl)),
            Imp(Eq(0, 1), Eq(1, 0))),
        ("equality_under_binder", ("lam", ("subst", 0, 1, All(Eq(1, 2)), h,
            ("all", refl))), Imp(Eq(0, 1), All(Eq(2, 1)))),
        ("nested_instantiation", ("inst", Ex(Eq(1, 0)), S(0),
            ("all", ("exists", 0, refl))), Ex(Eq(S(1), 0))),
    ]
    r = ("r", S(0), 5, 0)
    for name, args in (("sep", ()), ("r0", (r,)), ("r1", (r,)), ("ind", (Eq(0, 0),))):
        positive.append(("arithmetic_" + name, ("ax", name, *args), arithmetic(name, args)))
    negative = [
        ("undischarged_assumption", h, a),
        ("wrong_reflexivity", refl, Eq(0, 1)),
        ("wrong_reflexivity_sort", refl, BOT),
        ("universal_eigenvariable_escape", ("lam", ("all", h)), Imp(a, All(a))),
        ("existential_eigenvariable_escape", ("lam", ("choose", Eq(0, S(0)), h,
            ("hyp", 1))), Imp(Ex(Eq(0, S(0))), Eq(0, S(0)))),
        ("wrong_substitution_orientation", ("lam", ("subst", 0, 1, Eq(0, 1), h, refl)),
            Imp(Eq(0, 1), Eq(0, 1))),
        ("wrong_instantiation", ("inst", Eq(0, 0), Z, ("all", refl)), Eq(0, 0)),
        ("wrong_arithmetic_goal", ("ax", "sep"), BOT),
        ("formula_as_term", ("exists", BOT, refl), Ex(Eq(0, 0))),
        ("unrestricted_induction", ("ax", "ind", All(t)), t),
        ("unknown_rule", ("magic",), t),
        ("extra_proof_argument", ("refl", 0), t),
        ("boolean_context_index", ("lam", ("hyp", False)), Imp(t, t)),
        ("negative_context_index", ("lam", ("hyp", -1)), Imp(t, t)),
        ("negative_variable", refl, Eq(-1, -1)),
        ("malformed_descriptor", ("ax", "r0", ("r", 2, Z, Z)), t),
        ("malformed_goal", refl, ("=", Z)),
        ("empty_proof", (), t),
    ]
    for name, proof, goal in positive:
        if check(proof, goal) != goal:
            raise RuntimeError(name)
    for name, proof, goal in negative:
        try:
            check(proof, goal)
        except (ValueError, TypeError, KeyError, IndexError, RecursionError):
            continue
        raise RuntimeError("unsound acceptance: " + name)
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "certificate.json"
        for expected, item in ((0, positive[0]), (1, negative[0])):
            _, proof, goal = item
            path.write_text(json.dumps({"proof": proof, "goal": goal}), encoding="utf-8")
            result = subprocess.run([sys.executable, str(Path(__file__).with_name("check_nd.py")),
                                     str(path)], capture_output=True, text=True)
            if result.returncode != expected:
                raise RuntimeError("CLI contract failed")
    print(json.dumps({"positive_cases": len(positive), "negative_cases": len(negative),
                      "cli_cases": 2, "status": "passed"}, sort_keys=True))


if __name__ == "__main__":
    main()
