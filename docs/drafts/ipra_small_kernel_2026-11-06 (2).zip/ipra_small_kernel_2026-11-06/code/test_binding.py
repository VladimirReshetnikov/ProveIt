"""Independent focused audit of binding/freshness and descriptor boundaries.

These are finite implementation diagnostics, not a proof of the metatheory.
Run from any directory with Python 3.10+.
"""
import itertools
import random
import json
import sys
from pathlib import Path

CODE = Path(__file__).resolve().parent
sys.path.insert(0, str(CODE))
from syntax import Z, BOT, S, Eq, Imp, All, Ex, lift, inst, sub, sort
from hilbert import axiom, check
from make_examples import Builder
from test_kernel import random_formula, random_term, finite_value


def must_reject(proof, goal):
    try:
        check(proof, goal)
    except (ValueError, TypeError, KeyError, IndexError, RecursionError):
        return
    raise RuntimeError("adversarial proof accepted")


def require(p, message):
    if not p:
        raise RuntimeError(message)


def check_formula_valid(f, nfree=2):
    require(sort(f) == "f", "generated axiom ill formed")
    for env in itertools.product(range(3), repeat=nfree):
        require(finite_value(f, env, 3), "generated logical axiom false in finite structure")


def focused_freshness_tests():
    # Removing either lift makes the following generated schema invalid.
    a = Eq(0, Z)
    good_ud = axiom("ud", (a, a))
    bad_ud = Imp(All(Imp(a, a)), Imp(a, All(a)))
    require(finite_value(good_ud, (0,), 2), "ud false")
    require(not finite_value(bad_ud, (0,), 2), "ud negative control did not fail")
    good_ed = axiom("ed", (a, a))
    bad_ed = Imp(All(Imp(a, a)), Imp(Ex(a), a))
    require(finite_value(good_ed, (1,), 2), "ed false")
    require(not finite_value(bad_ed, (1,), 2), "ed negative control did not fail")

    # Naively generalizing a formula dependent on a retained hypothesis would
    # yield a -> forall x a.  There is no hypothesis line in the kernel; the
    # tempting use of distribution is rejected at modus ponens, not at a
    # final-goal comparison.
    for tag, false_goal in (("ud", Imp(a, All(a))), ("ed", Imp(Ex(a), a))):
        b = Builder()
        p = b.add("gen", b.identity(a))
        q = b.add(tag, a, a)
        proof = tuple(b.proof) + (("mp", q, p),)
        must_reject(proof, false_goal)

    # A capture bug in existential introduction would turn the theorem
    # forall y (y=y) into exists x forall y (y=x), false in a two-element
    # structure.  The correct antecedent retains the free witness parameter.
    b = Builder()
    p = b.add("gen", b.refl(0))
    q = b.add("ei", All(Eq(0, 1)), 0)
    false_goal = Ex(All(Eq(0, 1)))
    require(not finite_value(false_goal, (), 2), "existential negative control failed")
    must_reject(tuple(b.proof) + (("mp", q, p),), false_goal)

    # An invalid middle line cannot be hidden by a final goal mismatch.
    sep = axiom("sep", ())
    for record in (("hyp", BOT), ("refl", Z), ("gen", True), ("gen", -1)):
        must_reject((("sep",), record, ("sep",)), sep)
    return 9


def generated_template_tests():
    rng = random.Random(202611061)
    cases = 0
    for _ in range(120):
        outer_a = random_formula(rng, 3, 2)
        outer_b = random_formula(rng, 3, 2)
        inner_a = random_formula(rng, 3, 3)
        inner_b = random_formula(rng, 3, 3)
        s = random_term(rng, 2, 2)
        t = random_term(rng, 2, 2)
        # Evaluate the actual kernel outputs, not a separately handwritten
        # abstract logical schema.  This checks placement of lifting and
        # instantiation in each implementation branch.
        for tag, args in (
            ("ui", (inner_a, t)),
            ("ei", (inner_a, t)),
            ("ud", (outer_a, inner_b)),
            ("ed", (inner_a, outer_b)),
            ("eq", (s, t, inner_a)),
        ):
            f = axiom(tag, args)
            check(((tag, *args),), f)
            check_formula_valid(f)
            cases += 9
    return cases


def descriptor_and_parameter_tests():
    # A frozen counter slot remains 1 while the active theorem variables are
    # bound and then re-instantiated.  The old initializer parameter becomes
    # free index 0 after generalization of the old counter index 0.
    r = ("r", 1, 0, 1)
    computation = axiom("r1", (r,))
    ui = axiom("ui", (computation, Z))
    expected = Eq(("r", 1, S(Z), 0), Z)
    proof = (("r1", r), ("gen", 0), ("ui", computation, Z), ("mp", 2, 1))
    check(proof, expected)

    # Nested call: its actual arguments use the outer descriptor's slots;
    # its own descriptor is a separate immutable local scope.
    h = ("r", 1, 0, 2)
    r = ("r", h, 0, 1, 2)
    expected = Eq(("r", h, S(0), 1, 2), ("r", 1, r, 2))
    check((("r1", r),), expected)

    # An index just past an inner descriptor's available slots is forbidden,
    # even though the surrounding descriptor has a third parameter slot.
    bad_h = ("r", 2, 0, 2)
    bad_r = ("r", bad_h, 0, 1, 2)
    sep = axiom("sep", ())
    must_reject((("r1", bad_r), ("sep",)), sep)

    # A large outer parameter index is legal and is shifted by each binding;
    # generalized theorems have no retained assumptions whose freshness
    # could be violated by the operation.
    b = Builder()
    p = b.refl(37)
    for _ in range(6):
        p = b.add("gen", p)
    goal = Eq(37, 37)
    for _ in range(6):
        goal = All(goal)
    check(tuple(b.proof), goal)
    return 4


if __name__ == "__main__":
    print(json.dumps({
        "focused_freshness_tests": focused_freshness_tests(),
        "actual_generated_template_semantic_cases": generated_template_tests(),
        "descriptor_and_parameter_cases": descriptor_and_parameter_tests(),
        "status": "PASS",
    }, indent=2))
