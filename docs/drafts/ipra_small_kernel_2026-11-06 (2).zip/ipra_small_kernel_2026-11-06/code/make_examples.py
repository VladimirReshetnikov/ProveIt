"""Untrusted certificate producer. Every exported example is replayed by hilbert.py."""

import json
from pathlib import Path
from syntax import Z, BOT, S, Eq, Imp, Or, All, Ex, lift, inst
from hilbert import axiom, check


class Builder:
    def __init__(self):
        self.proof, self.formulas = [], []

    def add(self, tag, *args):
        if tag == "hyp":
            value = args[0]
        elif tag == "mp":
            major, minor = (self.formulas[i] for i in args)
            if major[0] != ">" or major[1] != minor:
                raise ValueError("producer modus ponens error")
            value = major[2]
        elif tag == "gen":
            value = All(self.formulas[args[0]])
        else:
            value = axiom(tag, args)
        self.proof.append((tag, *args))
        self.formulas.append(value)
        return len(self.proof) - 1

    def prop(self, number, a, b=BOT, c=BOT):
        return self.add("p", number, a, b, c)

    def mp(self, major, minor):
        return self.add("mp", major, minor)

    def identity(self, a):
        p = self.prop(0, a, Imp(a, a))
        q = self.prop(0, a, a)
        s = self.prop(1, a, Imp(a, a), a)
        return self.mp(self.mp(s, p), q)

    def refl(self, t):
        r = ("r", Z, Z, t)
        base = self.add("r0", r)
        replacement = self.add("eq", r, t, Eq(0, lift(t)))
        return self.mp(self.mp(replacement, base), base)

    def replace(self, equation, premise, template):
        _, s, t = self.formulas[equation]
        rule = self.add("eq", s, t, template)
        return self.mp(self.mp(rule, equation), premise)

    def symmetry(self, equation):
        _, s, _ = self.formulas[equation]
        return self.replace(equation, self.refl(s), Eq(0, lift(s)))

    def transitivity(self, left, right):
        _, a, _ = self.formulas[left]
        return self.replace(right, left, Eq(lift(a), 0))

    def congruence(self, equation, template):
        _, s, _ = self.formulas[equation]
        source = inst(template, s)
        return self.replace(equation, self.refl(source), Eq(lift(source), template))

    def discharge(self, a):
        """The elementary K/S deduction algorithm; no generalization inside."""
        out, translated = Builder(), []
        for record, value in zip(self.proof, self.formulas):
            if value == a:
                result = out.identity(a)
            elif record[0] == "mp":
                major, minor = record[1:]
                b = self.formulas[minor]
                s = out.prop(1, a, b, value)
                result = out.mp(out.mp(s, translated[major]), translated[minor])
            else:
                if record[0] == "gen":
                    raise ValueError("generalize after discharging in this producer")
                old = out.add(*record)
                k = out.prop(0, value, a)
                result = out.mp(k, old)
            translated.append(result)
        return out


def examples():
    result = {}
    b = Builder()
    b.refl(0)
    result["derived_reflexivity"] = b

    b = Builder()
    r = b.refl(0)
    intro = b.add("ei", Eq(0, 1), 0)
    b.add("gen", b.mp(intro, r))
    result["every_number_has_an_equal_witness"] = b

    b = Builder()
    b.identity(All(Ex(Eq(0, 1))))
    result["identity_with_quantifiers"] = b

    b = Builder()
    p = lambda t: ("r", 1, t, Z)
    computation = b.add("r1", p(0))
    successor_equation = b.congruence(computation, S(0))
    e = Eq(S(p(0)), 0)
    rooted = Or(Eq(0, Z), e)
    progress = b.mp(b.prop(0, b.formulas[successor_equation], rooted), successor_equation)
    premise = b.add("gen", progress)
    b.mp(b.add("ind", e), premise)
    result["successor_coverage"] = b

    b = Builder()
    assumption = Eq(S(0), S(1))
    assumed = b.add("hyp", assumption)
    left, right = b.add("r1", p(0)), b.add("r1", p(1))
    middle = b.congruence(assumed, p(0))
    b.transitivity(b.transitivity(b.symmetry(left), middle), right)
    b = b.discharge(assumption)
    b.add("gen", b.add("gen", len(b.proof) - 1))
    result["successor_injective"] = b

    b = Builder()
    assumption = Eq(S(0), Z)
    assumed = b.add("hyp", assumption)
    x_equal = []
    for a in (Z, S(Z)):
        q = lambda t: ("r", 1, t, a)
        left, right = b.add("r1", q(0)), b.add("r0", q(Z))
        middle = b.congruence(assumed, q(0))
        x_equal.append(b.transitivity(b.transitivity(b.symmetry(left), middle), right))
    collapse = b.transitivity(b.symmetry(x_equal[0]), x_equal[1])
    b.mp(b.add("sep"), collapse)
    b = b.discharge(assumption)
    b.add("gen", len(b.proof) - 1)
    result["successor_nonzero"] = b
    return result


def main():
    folder = Path(__file__).resolve().parents[1] / "certificates"
    folder.mkdir(exist_ok=True)
    summary = {}
    for name, builder in examples().items():
        goal, proof = builder.formulas[-1], tuple(builder.proof)
        check(proof, goal)
        path = folder / (name + ".json")
        path.write_text(json.dumps({"goal": goal, "proof": proof}, separators=(",", ":")) + "\n")
        summary[name] = {"proof_lines": len(proof), "bytes": path.stat().st_size}
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
