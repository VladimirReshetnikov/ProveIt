"""Independent finite diagnostics and adversarial tests; not a metatheory formalization."""

import itertools
import json
import random
import subprocess
import sys
from pathlib import Path
from syntax import Z, BOT, S, Eq, Imp, Or, All, Ex, sort, sub, lift, inst, freeze
from hilbert import check, axiom
from make_examples import examples


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def rejects(proof, goal):
    try:
        check(proof, goal)
    except (ValueError, TypeError, KeyError, IndexError, RecursionError):
        return
    raise RuntimeError("bad certificate accepted")


def finite_value(e, values, domain=3):
    """An independent finite first-order interpretation, not a model of arithmetic."""
    if type(e) is int:
        return values[e]
    tag, args = e[0], e[1:]
    if tag == "z":
        return 0
    if tag == "s":
        return (finite_value(args[0], values, domain) + 1) % domain
    if tag == "r":
        # Each frozen descriptor/arity denotes a fixed arbitrary total operation.
        seed = sum((i + 1) * ord(c) for i, c in enumerate(repr((args[0], len(args) - 1))))
        actual = [finite_value(a, values, domain) for a in args[1:]]
        return (seed + sum((i + 2) * a for i, a in enumerate(actual))) % domain
    if tag in ("@", "?"):
        instances = [finite_value(args[0], (n, *values), domain) for n in range(domain)]
        return all(instances) if tag == "@" else any(instances)
    if tag == "F":
        return False
    a, b = (finite_value(x, values, domain) for x in args)
    return {"=": lambda: a == b, "&": lambda: a and b,
            "|": lambda: a or b, ">": lambda: not a or b}[tag]()


def random_term(rng, depth, variables):
    if depth == 0:
        return Z if rng.randrange(3) == 0 else rng.randrange(variables)
    choice = rng.randrange(4)
    if choice == 0:
        return rng.randrange(variables)
    if choice == 1:
        return S(random_term(rng, depth - 1, variables))
    count = rng.randrange(2)
    label = random_term(rng, depth - 1, count + 2)
    actual = tuple(random_term(rng, depth - 1, variables) for _ in range(count + 2))
    return ("r", label, *actual)


def random_formula(rng, depth, variables):
    if depth == 0:
        return Eq(random_term(rng, 2, variables), random_term(rng, 2, variables))
    tag = rng.choice(("&", "|", ">", "@", "?", "F"))
    if tag == "F":
        return BOT
    if tag in ("@", "?"):
        return (tag, random_formula(rng, depth - 1, variables + 1))
    return (tag, random_formula(rng, depth - 1, variables),
            random_formula(rng, depth - 1, variables))


def substitution_tests():
    require(lift(All(Eq(0, 1))) == All(Eq(0, 2)), "capture in lift")
    require(inst(All(Eq(0, 1)), S(0)) == All(Eq(0, S(1))), "capture in instantiation")
    r = ("r", 1, 0, 1, 2)
    require(sub(r, lambda i: i + 10) == ("r", 1, 10, 11, 12), "descriptor changed")
    rng = random.Random(20261106)
    cases = 0
    for _ in range(240):
        a = random_formula(rng, 3, 4)
        t = random_term(rng, 2, 3)
        require(sort(a) == "f" and sort(t) == "t", "bad test generator")
        for values in itertools.product(range(3), repeat=3):
            actual = finite_value(inst(a, t), values)
            expected = finite_value(a, (finite_value(t, values), *values))
            require(actual == expected, "substitution semantics mismatch")
            for extra in range(3):
                require(finite_value(lift(inst(a, t)), (extra, *values)) == actual,
                        "lifting semantics mismatch")
                cases += 1
            cases += 1
    return cases


def heyting_tests():
    # Diamond-shaped Kripke frame 0<1<3 and 0<2<3, with all upsets.
    future = ({0, 1, 2, 3}, {1, 3}, {2, 3}, {3})
    top = frozenset(range(4))
    values = [frozenset(i for i in range(4) if mask >> i & 1) for mask in range(16)]
    upsets = [a for a in values if all(future[i] <= a for i in a)]
    implication = lambda a, b: frozenset(i for i in range(4) if not ((future[i] & a) - b))
    atoms = (Eq(0, Z), Eq(1, Z), Eq(2, Z))
    def evaluate(formula, assignment):
        if formula in assignment:
            return assignment[formula]
        if formula == BOT:
            return frozenset()
        tag, left, right = formula
        a, b = evaluate(left, assignment), evaluate(right, assignment)
        return {"&": lambda: a & b, "|": lambda: a | b,
                ">": lambda: implication(a, b)}[tag]()
    templates = [axiom("p", (i, *atoms)) for i in range(9)]
    cases = 0
    for a, b, c in itertools.product(upsets, repeat=3):
        assignment = dict(zip(atoms, (a, b, c)))
        require(all(evaluate(s, assignment) == top for s in templates),
                "nonintuitionistic logical template")
        cases += len(templates)
    for outer, a, b in itertools.product(upsets, repeat=3):
        universal_distribution = implication(implication(outer, a) & implication(outer, b),
                                               implication(outer, a & b))
        existential_elimination = implication(implication(a, outer) & implication(b, outer),
                                              implication(a | b, outer))
        require(universal_distribution == top and existential_elimination == top,
                "quantifier distribution failure")
        cases += 2
    a = frozenset({3})
    require(a | implication(a, frozenset()) != top, "classical negative control failed")
    return cases


def malformed_tests():
    bad_axioms = [
        ("refl", 0), ("hyp", BOT), ("lem", All(Eq(0, Z))), ("sep", 0),
        ("ind", Imp(Eq(0, Z), BOT)), ("ind", All(Eq(0, Z))),
        ("r0", Z), ("r1", ("r", 2, Z, Z)),
        ("r0", ("r", BOT, Z, Z)), ("r0", ("r", Z, Z)),
        ("r1", ("r", ("r", 3, Z, Z), Z, Z)),
        ("p", True, BOT, BOT, BOT), ("p", -1, BOT, BOT, BOT),
        ("p", 9, BOT, BOT, BOT), ("p", 0, Z, BOT, BOT),
        ("ui", Eq(0, Z), BOT), ("ui", Eq(-1, Z), Z),
        ("ei", ("@", Eq(0, Z), BOT), Z), ("eq", 0, 1, Z),
        ("eq", -1, 0, Eq(0, Z)), ("ed", BOT, 0),
        ("ud", BOT), ("unknown",),
    ]
    # Test axiom validation directly: a wrong final goal cannot mask a bug.
    for record in bad_axioms:
        try:
            axiom(record[0], record[1:])
        except (ValueError, TypeError, KeyError, IndexError, RecursionError):
            continue
        raise RuntimeError("malformed axiom was generated")
    sep = Imp(Eq(Z, S(Z)), BOT)
    bad_proofs = [
        ((("mp", -1, 0),), BOT), ((("mp", 0, 0),), BOT),
        ((("gen", 0),), All(sep)),
        ((("sep",), ("mp", 0, 0)), BOT),
        ((("sep",), ("gen", -1)), All(sep)),
        ((("sep",), ("sep",), ("gen", True)), All(sep)),
        ((("p", 0, BOT, BOT, BOT), ("sep",), ("mp", 0, 1)), Imp(BOT, BOT)),
        ((), BOT), (((),), BOT), (("sep",), BOT),
    ]
    for proof, goal in bad_proofs:
        rejects(proof, goal)
    rejects((("sep",),), Eq(Z, Z))
    for goal in [Z, -1, True, (), ("=", Z), ("F", Z), {"fake": "formula"}]:
        rejects((("sep",),), goal)
    return len(bad_axioms) + len(bad_proofs) + 8


def main():
    summary = {}
    builders = examples()
    for name, b in builders.items():
        check(tuple(b.proof), b.formulas[-1])
        # All examples are consistent theorems, not proofs of falsity.
        rejects(tuple(b.proof), BOT)
    summary["replayed_complete_certificates"] = len(builders)
    summary["capture_and_substitution_semantic_checks"] = substitution_tests()
    summary["finite_heyting_template_checks"] = heyting_tests()
    summary["malformed_or_forged_certificates_rejected"] = malformed_tests()
    folder = Path(__file__).resolve().parents[1]
    cli_count = 0
    for path in sorted((folder / "certificates").glob("*.json")):
        run = subprocess.run([sys.executable, str(folder / "code" / "check.py"), str(path)],
                             text=True, capture_output=True)
        require(run.returncode == 0 and run.stdout.strip() == "ACCEPT", "CLI replay failure")
        cli_count += 1
    summary["json_cli_certificates_replayed"] = cli_count
    from hilbert_reflexivity import check as check_with_reflexivity
    for b in builders.values():
        check_with_reflexivity(tuple(b.proof), b.formulas[-1])
    check_with_reflexivity((("refl", 0),), Eq(0, 0))
    rejects((("refl", 0),), Eq(0, 0))
    summary["controlled_baseline_acceptance_checks"] = len(builders) + 2
    summary["status"] = "PASS"
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
