"""Untrusted producer of independent ND arithmetic certificates."""

import json
from pathlib import Path
from syntax import Z, BOT, S, Eq, Imp, Or, All, lift, inst
from arithmetic import arithmetic
from nd import check


def ax(tag, *args):
    return arithmetic(tag, args), ("ax", tag, *args)


def replace(equality, premise, template):
    _, s, t = equality[0]
    if premise[0] != inst(template, s):
        raise ValueError("producer substitution mismatch")
    return inst(template, t), ("subst", s, t, template, equality[1], premise[1])


def symmetry(equality):
    _, s, _ = equality[0]
    return replace(equality, (Eq(s, s), ("refl",)), Eq(0, lift(s)))


def transitivity(left, right):
    return replace(right, left, Eq(lift(left[0][1]), 0))


def congruence(equality, template):
    source = inst(template, equality[0][1])
    return replace(equality, (Eq(source, source), ("refl",)), Eq(lift(source), template))


def examples():
    result = {}
    p = lambda t: ("r", 1, t, Z)
    computation = ax("r1", p(0))
    step = congruence(computation, S(0))
    e = Eq(S(p(0)), 0)
    rooted = Or(Eq(0, Z), e)
    premise = All(Imp(rooted, step[0]))
    rule = ax("ind", e)
    result["successor_coverage"] = (All(rooted),
        ("app", premise, rule[1], ("all", ("lam", step[1]))))

    assumption = Eq(S(0), S(1))
    assumed = assumption, ("hyp", 0)
    left, right = ax("r1", p(0)), ax("r1", p(1))
    middle = congruence(assumed, p(0))
    conclusion = transitivity(transitivity(symmetry(left), middle), right)
    result["successor_injective"] = (All(All(Imp(assumption, conclusion[0]))),
        ("all", ("all", ("lam", conclusion[1]))))

    assumption = Eq(S(0), Z)
    assumed = assumption, ("hyp", 0)
    x_equal = []
    for a in (Z, S(Z)):
        q = lambda t: ("r", 1, t, a)
        left, right = ax("r1", q(0)), ax("r0", q(Z))
        middle = congruence(assumed, q(0))
        x_equal.append(transitivity(transitivity(symmetry(left), middle), right))
    collapse = transitivity(symmetry(x_equal[0]), x_equal[1])
    contradiction = ("app", collapse[0], ax("sep")[1], collapse[1])
    result["successor_nonzero"] = (All(Imp(assumption, BOT)), ("all", ("lam", contradiction)))
    return result


def main():
    folder = Path(__file__).resolve().parents[1] / "certificates" / "nd"
    folder.mkdir(exist_ok=True)
    summary = {}
    for name, (goal, proof) in examples().items():
        check(proof, goal)
        from syntax import freeze
        counterpart = json.loads((folder.parent / (name + ".json")).read_text())
        if freeze(counterpart["goal"]) != goal:
            raise ValueError("comparison certificates have different goals")
        path = folder / (name + ".json")
        path.write_text(json.dumps({"goal": goal, "proof": proof}, separators=(",", ":")) + "\n")
        summary[name] = {"bytes": path.stat().st_size}
    print(json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
