A SMALL COMPLETE CHECKER FOR iPRA
6 November 2026
================================

The main report is report.pdf; its complete source is report.tex plus
sections/*.tex. The report gives every logical and arithmetic schema,
both inference rules, the arithmetic reconstruction, and the two
whole-carrier interpretation round trips.

MAIN RESULT

Equality reflexivity is unnecessary as a primitive rule. Put
q = R_0(0,t), using the constant-zero update descriptor. The recursion
base equation gives q=t. Equality substitution with A(z) := z=t gives
q=t -> ((q=t) -> t=t). Two modus ponens steps prove t=t.

The recommended calculus has 14 logical schemas, four arithmetic
families (separation, recursion base, recursion step, rooted equation
progression), and two inference rules (MP and generalization). The
checker retains full intuitionistic first-order logic, genuine falsity,
and unrestricted quantifiers. It does not use a negative translation.

WHAT TO READ OR RUN

report.pdf / report.tex
    Complete mathematical answer, implementation accounting, and limits.

SPECIFICATION.txt
    Stand-alone concise theory and concrete certificate format.

code/syntax.py, code/arithmetic.py, code/hilbert.py, code/check.py
    The entire recommended acceptance program. No theorem prover,
    normalizer, code evaluator, or other arithmetic library is imported.

certificates/*.json
    Complete checked proofs of reflexivity, an existential witness
    theorem, implication identity, successor coverage, successor
    injectivity, and successor nonzeroness.

code/make_examples.py
    Untrusted certificate producer. Hypotheses and deduction compilation
    occur only here, outside the acceptance procedure.

code/test_kernel.py, code/test_binding.py
    Finite semantic diagnostics and adversarial implementation tests.
    They are not a proof-assistant formalization of soundness or of the
    bi-interpretation theorem.

code/nd.py, code/check_nd.py, code/test_nd.py
    Compact natural-deduction comparison using the same term/formula
    representation, substitution, arithmetic and JSON input substrate.

code/hilbert_reflexivity.py, code/check_hilbert_reflexivity.py
    Controlled baseline retaining precisely the omitted reflexivity
    case. This isolates the strict deletion from presentation changes.

code/measure.py
    Reproducible complete-source measurements, with shared files counted
    once per kernel. The fixed logical axiom tables are included.

provenance/source_manifest.json
    The six current source archives pinned at ProveIt commit
    86b708a209fd20431908347c5aa051d73c8d4682, with Git blob and SHA-256 hashes.

verification/
    Reproduced execution results, metrics, and independent review notes.

REPRODUCTION

Run from this folder:

    python3 build.py

This regenerates the example certificates, runs the diagnostic suites,
measures the source, and compiles report.pdf. It needs Python 3.10+ and
pdflatex with the packages named in report.tex. The checker itself uses
only the Python standard library:

    python3 code/check.py certificates/successor_coverage.json

It prints ACCEPT and exits zero on acceptance, otherwise REJECT and a
nonzero status. Generated files may differ in PDF metadata across builds.

STATUS AND COMPARISON LIMITS

The reports in the six input archives do not ship complete proof
checkers. Their diagnostic-file sizes are not competing kernel sizes.
This archive supplies a controlled implementation comparison and a
strict redundancy deletion, not an encoding-independent shortest-program
theorem. The full mathematical equivalence is proved in the report;
the Python implementation is manually reviewed and tested, not formally
verified in Lean or Rocq. Resource limits can reject sufficiently large
otherwise valid certificates.
