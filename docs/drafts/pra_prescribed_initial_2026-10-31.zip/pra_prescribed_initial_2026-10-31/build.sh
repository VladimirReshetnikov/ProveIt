#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 verify.py
latexmk -pdf -interaction=nonstopmode -halt-on-error pra_prescribed_initial.tex
