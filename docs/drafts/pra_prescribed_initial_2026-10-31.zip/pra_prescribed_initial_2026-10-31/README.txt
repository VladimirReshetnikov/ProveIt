PRA WITH PRESCRIBED INITIAL VALUES
Research report prepared for Vladimir Reshetnikov, 31 October 2026.

Start with pra_prescribed_initial.pdf. Its editable source is
pra_prescribed_initial.tex. The report gives a complete constructive proof
of the main axiomatization theorem, a precise comparison with all five
current PRA draft archives, and a separate analysis of open candidates.

Main result
-----------
Use the usual primitive-recursion computation equations D. A term pair
a(n,u), b(n,u) is eligible when substituting 0 for n yields 0 and S0,
respectively, using at most one forward computation rewrite each, at any
term position, with the numerical parameters u left as variables.

For each eligible pair, put E(n,u) := a(n,u)=b(n,u), and add

  [forall n ((n=0 or E(n,u)) -> E(Sn,u))]
       -> forall n ((n=0) XOR E(n,u)).

All parameters are universally closed. XOR(P,Q) abbreviates
(P or Q) and not(P and Q). These axioms give exactly intuitionistic PRA;
with classical logic they give exactly classical PRA. Classically one
may instead use the conclusion forall n (n=0 iff not E(n,u)).

What is new relative to the reviewed drafts
------------------------------------------
The arithmetic schema has no explicit base-case premise and no separate
separation axiom. It shortens the existing exclusive-induction formula
from 10 equality occurrences to 7 (22 to 16 formula-skeleton nodes), while
adding a small decidable syntactic eligibility condition. These counts
exclude term structure and the eligibility checker. No absolute or
historical shortestness claim is made.

The one-rewrite budget is sharp within this exact family: with zero
rewrites the resulting theory is only D plus 0 != S0. The report proves
this, and proves that the classical negative-conclusion formulation is
insufficient in intuitionistic logic.

Files
-----
pra_prescribed_initial.tex   Complete LaTeX source.
pra_prescribed_initial.pdf   Compiled report.
axioms.txt                  Complete plain-text specification.
verify.py                   Standard-library syntax/rewriting checker and
                            finite diagnostic checks; not a proof assistant.
validation_report.json      Exact output of the included checker.
source_audit.json            Immutable GitHub revision, URLs and checksums.
build.sh                    Rebuild instructions as an executable script.
SHA256SUMS.txt              SHA-256 checksums of the delivered files.

Reproduction
------------
Run python3 verify.py. To rebuild the PDF, run:
  latexmk -pdf -interaction=nonstopmode -halt-on-error pra_prescribed_initial.tex
or run bash build.sh. A conventional TeX Live installation supplies the
packages used. Python 3.10 or newer is recommended for the checker.

Verification boundary
---------------------
The universal mathematical claims are proved in the report. The Python
artifact checks the new syntactic admission procedure, concrete symbolic
instances, formula counts, and selected finite computations. It does not
formalize first-order deduction, establish universal claims by testing,
or provide a Lean/Rocq certification.

Source scope
------------
Repository VladimirReshetnikov/ProveIt, commit
487040529a8792ae3239ae75e695424aee3d665c.
All five PRA archives in docs/drafts were read. The docs/incoming
directory inventory and README were inspected; neither listed a PRA
archive or PRA entry. Unrelated incoming Busy Beaver archives were not
treated as PRA sources. Original archives are not duplicated here.
