#!/usr/bin/env python3
"""Check the finite syntax and examples in the prescribed-initial PRA note.

Standard library only. This is a syntax checker and a finite numerical check,
not a proof assistant or a verification of the universal equivalence theorem.
The mathematical equivalence proof is in the accompanying paper.

Run: python3 verify.py
The default output is validation_report.json beside this script.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Union


@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Succ:
    arg: "Term"


@dataclass(frozen=True)
class Call:
    name: str
    args: tuple["Term", ...]


Term = Union[Var, Zero, Succ, Call]
ZERO = Zero()
ONE = Succ(ZERO)


def call(name: str, *args: Term) -> Call:
    return Call(name, tuple(args))


def show(term: Term) -> str:
    if isinstance(term, Var):
        return term.name
    if isinstance(term, Zero):
        return "0"
    if isinstance(term, Succ):
        return "S(" + show(term.arg) + ")"
    if isinstance(term, Call):
        return term.name + "(" + ",".join(map(show, term.args)) + ")"
    raise TypeError(term)


def free_vars(term: Term) -> set[str]:
    if isinstance(term, Var):
        return {term.name}
    if isinstance(term, Zero):
        return set()
    if isinstance(term, Succ):
        return free_vars(term.arg)
    if isinstance(term, Call):
        return set().union(*(free_vars(arg) for arg in term.args))
    raise TypeError(term)


def subst(term: Term, replacements: dict[str, Term]) -> Term:
    """Simultaneous substitution; terms contain no binders."""
    if isinstance(term, Var):
        return replacements.get(term.name, term)
    if isinstance(term, Zero):
        return term
    if isinstance(term, Succ):
        return Succ(subst(term.arg, replacements))
    if isinstance(term, Call):
        return Call(term.name, tuple(subst(a, replacements) for a in term.args))
    raise TypeError(term)


@dataclass(frozen=True)
class Recursor:
    name: str
    parameters: tuple[str, ...]
    base: Term
    step: Term
    index_var: str = "k"
    value_var: str = "v"

    @property
    def arity(self) -> int:
        return 1 + len(self.parameters)


@dataclass(frozen=True)
class Rewrite:
    result: Term
    path: tuple[int, ...]
    rule: str


class Language:
    """An ordered collection of well-founded primitive recursion descriptions."""

    def __init__(self) -> None:
        self.descriptions: dict[str, Recursor] = {}

    def validate(self, term: Term) -> None:
        if isinstance(term, Var):
            if not term.name:
                raise ValueError("An empty variable name is not allowed")
        elif isinstance(term, Zero):
            return
        elif isinstance(term, Succ):
            self.validate(term.arg)
        elif isinstance(term, Call):
            if term.name not in self.descriptions:
                raise ValueError("Unknown or non-earlier function: " + term.name)
            if len(term.args) != self.descriptions[term.name].arity:
                raise ValueError("Wrong arity for " + term.name)
            for arg in term.args:
                self.validate(arg)
        else:
            raise TypeError(term)

    def declare(self, description: Recursor) -> None:
        if (description.name in self.descriptions or
                description.name in {"0", "S"} or not description.name):
            raise ValueError("A recursor must have a fresh nonempty name")
        variables = (*description.parameters,
                     description.index_var, description.value_var)
        if any(not name for name in variables) or len(set(variables)) != len(variables):
            raise ValueError("Formal variables must be nonempty and distinct")
        # Validate before inserting: self-reference and forward reference fail.
        self.validate(description.base)
        self.validate(description.step)
        if not free_vars(description.base) <= set(description.parameters):
            raise ValueError("The base has an undeclared free variable")
        if not free_vars(description.step) <= set(variables):
            raise ValueError("The step has an undeclared free variable")
        self.descriptions[description.name] = description

    def root_rewrite(self, term: Term) -> Rewrite | None:
        if not isinstance(term, Call):
            return None
        description = self.descriptions[term.name]
        argument, *parameters = term.args
        environment = dict(zip(description.parameters, parameters))
        if isinstance(argument, Zero):
            return Rewrite(subst(description.base, environment), (),
                           description.name + ".R0")
        if isinstance(argument, Succ):
            environment[description.index_var] = argument.arg
            environment[description.value_var] = Call(
                term.name, (argument.arg, *parameters))
            return Rewrite(subst(description.step, environment), (),
                           description.name + ".RS")
        return None

    def one_step(self, term: Term) -> list[Rewrite]:
        """All single forward D rewrites, including below any term context.

        A path is a sequence of zero-based child positions. S has child 0;
        the children of a call are its arguments. No parameter is evaluated.
        """
        self.validate(term)
        rewrites: list[Rewrite] = []
        root = self.root_rewrite(term)
        if root is not None:
            rewrites.append(root)
        if isinstance(term, Succ):
            for rw in self.one_step(term.arg):
                rewrites.append(Rewrite(Succ(rw.result), (0, *rw.path), rw.rule))
        elif isinstance(term, Call):
            for index, arg in enumerate(term.args):
                for rw in self.one_step(arg):
                    arguments = list(term.args)
                    arguments[index] = rw.result
                    rewrites.append(Rewrite(Call(term.name, tuple(arguments)),
                                            (index, *rw.path), rw.rule))
        return rewrites

    def boundary(self, term: Term, target: Term,
                 index_var: str = "n") -> dict | None:
        self.validate(term)
        initial = subst(term, {index_var: ZERO})
        if initial == target:
            return {"initial": show(initial), "target": show(target),
                    "rewrite_count": 0, "path": [], "rule": None}
        for rw in self.one_step(initial):
            if rw.result == target:
                return {"initial": show(initial), "target": show(target),
                        "rewrite_count": 1, "path": list(rw.path),
                        "rule": rw.rule}
        return None

    def eligibility(self, left: Term, right: Term,
                    index_var: str = "n") -> dict:
        first = self.boundary(left, ZERO, index_var)
        second = self.boundary(right, ONE, index_var)
        return {"eligible": first is not None and second is not None,
                "left": show(left), "right": show(right),
                "left_boundary": first, "right_boundary": second}

    def shift(self, name: str, source: Term, initial: Term,
              parameters: tuple[str, ...] = ("a",),
              index_var: str = "n") -> Term:
        """Name A(0,a)=initial, A(Sn,a)=source(n,a), ignoring prior value."""
        self.validate(source)
        if not free_vars(source) <= {index_var, *parameters}:
            raise ValueError("The source has an undisplayed free variable")
        used = free_vars(source) | set(parameters) | {index_var}
        new_index = "_index"
        while new_index in used:
            new_index += "_"
        used.add(new_index)
        new_value = "_previous"
        while new_value in used:
            new_value += "_"
        description = Recursor(
            name, parameters, initial,
            subst(source, {index_var: Var(new_index)}), new_index, new_value)
        self.declare(description)
        return call(name, Var(index_var), *(Var(a) for a in parameters))

    def evaluate(self, term: Term, environment: dict[str, int]) -> int:
        if isinstance(term, Var):
            return environment[term.name]
        if isinstance(term, Zero):
            return 0
        if isinstance(term, Succ):
            return 1 + self.evaluate(term.arg, environment)
        if isinstance(term, Call):
            values = tuple(self.evaluate(arg, environment) for arg in term.args)
            return self.evaluate_call(term.name, values)
        raise TypeError(term)

    @lru_cache(maxsize=None)
    def evaluate_call(self, name: str, arguments: tuple[int, ...]) -> int:
        description = self.descriptions[name]
        if len(arguments) != description.arity or any(x < 0 for x in arguments):
            raise ValueError("Evaluation requires natural inputs of the right arity")
        index, *parameters = arguments
        environment = dict(zip(description.parameters, parameters))
        value = self.evaluate(description.base, environment)
        for k in range(index):
            environment[description.index_var] = k
            environment[description.value_var] = value
            value = self.evaluate(description.step, environment)
        return value


@dataclass(frozen=True)
class Formula:
    kind: str
    args: tuple = ()


def atom(label: str) -> Formula:
    return Formula("atom", (label,))


def form(kind: str, *args) -> Formula:
    return Formula(kind, tuple(args))


def exclusive(left: Formula, right: Formula) -> Formula:
    return form("and", form("or", left, right),
                form("not", form("and", left, right)))


def metrics(formula: Formula) -> dict[str, int]:
    counts = {"atoms": 0, "connectives": 0, "quantifiers": 0}

    def visit(current: Formula) -> None:
        if current.kind in ("atom", "eq", "false", "true"):
            counts["atoms"] += 1
        elif current.kind == "forall":
            counts["quantifiers"] += 1
            visit(current.args[1])
        elif current.kind in ("and", "or", "implies", "not"):
            counts["connectives"] += 1
            for child in current.args:
                visit(child)
        else:
            raise ValueError(current.kind)

    visit(formula)
    counts["total"] = sum(counts.values())
    return counts


def formula_metrics() -> dict:
    def first(x: str) -> Formula:
        return atom("r(" + x + ")=0")

    def second(x: str) -> Formula:
        return atom("r(" + x + ")=S(u(" + x + "))")

    def positive(x: str) -> Formula:
        return form("or", first(x), second(x))

    old = form("implies",
               form("and", positive("0"),
                    form("forall", "n", form("implies", positive("n"),
                                               positive("Sn")))),
               form("forall", "n", exclusive(first("n"), second("n"))))
    new = form("implies",
               form("forall", "n",
                    form("implies", form("or", atom("n=0"), atom("E(n)")),
                         atom("E(Sn)"))),
               form("forall", "n", exclusive(atom("n=0"), atom("E(n)"))))
    result = {"convention": "XOR expanded; negation primitive; term structure, "
                            "eligibility checker, and outer parameter quantifiers omitted",
              "existing_X": metrics(old), "restricted_GX": metrics(new)}
    assert result["existing_X"] == {
        "atoms": 10, "connectives": 10, "quantifiers": 2, "total": 22}
    assert result["restricted_GX"] == {
        "atoms": 7, "connectives": 7, "quantifiers": 2, "total": 16}
    result["skeleton_nodes_saved"] = 6
    return result


def distance(left: Term, right: Term) -> Term:
    # M(n,a) is the countdown a dotminus n, so this is zero iff left=right.
    return call("c", call("M", left, right), call("M", right, left), ONE)


def compile_error(formula: Formula) -> Term:
    """The report's Boolean compiler: 0 is true and 1 is false."""
    kind, args = formula.kind, formula.args
    if kind == "eq":
        return call("c", distance(args[0], args[1]), ZERO, ONE)
    if kind == "false":
        return ONE
    if kind == "true":
        return ZERO
    if kind == "not":
        return call("c", compile_error(args[0]), ONE, ZERO)
    left, right = map(compile_error, args)
    if kind == "and":
        return call("c", left, right, ONE)
    if kind == "or":
        return call("c", left, ZERO, right)
    if kind == "implies":
        return call("c", left, right, ZERO)
    raise ValueError(kind)


def evaluate_formula(language: Language, formula: Formula,
                     environment: dict[str, int]) -> bool:
    kind, args = formula.kind, formula.args
    if kind == "eq":
        return language.evaluate(args[0], environment) == language.evaluate(args[1], environment)
    if kind == "false":
        return False
    if kind == "true":
        return True
    if kind == "not":
        return not evaluate_formula(language, args[0], environment)
    left = evaluate_formula(language, args[0], environment)
    right = evaluate_formula(language, args[1], environment)
    if kind == "and":
        return left and right
    if kind == "or":
        return left or right
    if kind == "implies":
        return not left or right
    raise ValueError(kind)


def run_checks() -> dict:
    language = Language()
    n, a, k, v, u, w = map(Var, ("n", "a", "k", "v", "u", "w"))
    language.declare(Recursor("p", (), ZERO, k))
    language.declare(Recursor("q", ("u",), ZERO, u))
    language.declare(Recursor("add", ("a",), a, Succ(v)))
    language.declare(Recursor("M", ("a",), a, call("p", v)))

    rejected: list[str] = []

    def expect_rejection(label: str, operation) -> None:
        try:
            operation()
        except (ValueError, TypeError):
            rejected.append(label)
        else:
            raise AssertionError("Expected rejection: " + label)

    expect_rejection("wrong arity", lambda: language.validate(call("p", n, a)))
    expect_rejection("unknown symbol", lambda: language.validate(call("unknown", n)))
    expect_rejection("self reference", lambda: language.declare(
        Recursor("self", (), ZERO, call("self", k))))
    expect_rejection("forward reference", lambda: language.declare(
        Recursor("forward", (), ZERO, call("later", k))))
    expect_rejection("undeclared base variable", lambda: language.declare(
        Recursor("bad_base", (), a, ZERO)))
    expect_rejection("undeclared step variable", lambda: language.declare(
        Recursor("bad_step", (), ZERO, a)))
    expect_rejection("repeated formal variable", lambda: language.declare(
        Recursor("bad_formals", ("k",), ZERO, ZERO)))
    expect_rejection("nonfresh function name", lambda: language.declare(
        Recursor("p", (), ZERO, ZERO)))
    expect_rejection("reserved initial symbol", lambda: language.declare(
        Recursor("S", (), ZERO, ZERO)))

    addition_step = language.root_rewrite(call("add", Succ(n), a))
    assert addition_step is not None
    assert addition_step.result == Succ(call("add", n, a))
    assert language.root_rewrite(call("p", a)) is None
    independent_positions = language.one_step(call("add", call("p", ZERO),
                                                   call("p", ZERO)))
    assert {rw.path for rw in independent_positions} == {(0,), (1,)}
    assert {rw.result for rw in independent_positions} == {
        call("add", ZERO, call("p", ZERO)), call("add", call("p", ZERO), ZERO)}

    coverage = language.eligibility(n, Succ(call("p", n)))
    assert coverage["eligible"]
    assert coverage["left_boundary"]["rewrite_count"] == 0
    assert coverage["right_boundary"]["path"] == [0]
    assert coverage["right_boundary"]["rule"] == "p.R0"

    boundary_rejections = {
        "unrestricted tautological equation": language.eligibility(n, n),
        "parameter is not a numeral": language.eligibility(a, ONE),
        "two rewrites exceed bound": language.eligibility(n, Succ(call("p", call("p", n)))),
        "reversed prescribed numerals": language.eligibility(ONE, ZERO),
    }
    assert all(not item["eligible"] for item in boundary_rejections.values())
    # Simultaneous substitution does not recursively substitute into replacements.
    assert subst(n, {"n": a, "a": ZERO}) == a

    sources = [ZERO, ONE, n, a, Succ(n), call("p", n), call("add", n, a),
               call("add", a, n), call("M", n, a), call("q", n, a)]
    shifts: list[dict] = []
    for i, source_left in enumerate(sources):
        for j, source_right in enumerate(sources):
            left = language.shift(f"A_{i}_{j}", source_left, ZERO)
            right = language.shift(f"B_{i}_{j}", source_right, ONE)
            certificate = language.eligibility(left, right)
            assert certificate["eligible"]
            for key in ("left_boundary", "right_boundary"):
                assert certificate[key]["rewrite_count"] == 1
                assert certificate[key]["path"] == []
            for shifted, source in ((left, source_left), (right, source_right)):
                successor = subst(shifted, {"n": Succ(n)})
                root = language.root_rewrite(successor)
                assert root is not None and root.result == source
            if len(shifts) < 3 or (i, j) == (6, 7):
                shifts.append({"source_left": show(source_left),
                               "source_right": show(source_right),
                               "certificate": certificate})

    source_left, source_right = call("add", n, a), call("add", a, n)
    left_previous = subst(source_left, {"n": call("p", n)})
    right_previous = subst(source_right, {"n": call("p", n)})
    gate_pair = language.eligibility(call("q", n, Succ(left_previous)),
                                     Succ(call("q", n, right_previous)))
    assert gate_pair["eligible"]
    assert gate_pair["left_boundary"]["path"] == []
    assert gate_pair["right_boundary"]["path"] == [0]

    # Numerical helpers are also legal earlier-description recursors.
    language.declare(Recursor("z", (), ONE, ZERO))
    language.declare(Recursor("c", ("u", "w"), u, w))
    numerical_pairs = 0
    for x in range(13):
        assert language.evaluate_call("p", (x,)) == max(x - 1, 0)
        for y in range(13):
            environment = {"n": x, "a": y}
            assert language.evaluate_call("M", (x, y)) == max(y - x, 0)
            assert (language.evaluate(distance(n, a), environment) == 0) == (x == y)
            reconstruction = call("c", call("M", a, n),
                                  call("M", call("M", n, a), a), n)
            assert language.evaluate(reconstruction, environment) == x
            numerical_pairs += 1

    atoms = [form("eq", n, a), form("eq", call("M", n, a), ZERO),
             form("eq", Succ(n), a), form("eq", n, ZERO),
             form("true"), form("false")]
    formulas = atoms + [form("not", f) for f in atoms]
    formulas += [form(kind, f, g) for kind in ("and", "or", "implies")
                 for f in atoms for g in atoms]
    formula_checks = 0
    for formula in formulas:
        compiled = compile_error(formula)
        language.validate(compiled)
        for x in range(9):
            for y in range(9):
                environment = {"n": x, "a": y}
                truth = evaluate_formula(language, formula, environment)
                code = language.evaluate(compiled, environment)
                assert code in (0, 1)
                assert (code == 0) == truth
                assert (code == 1) == (not truth)
                formula_checks += 1

    return {
        "status": "passed",
        "scope": {
            "verified": ["finite well-founded description and term validation",
                         "single defining-equation rewrites at arbitrary positions",
                         "at-most-one-rewrite prescribed-initial eligibility",
                         "fresh-shift boundary and successor rewrite certificates",
                         "formula-skeleton counts", "finite standard-natural examples"],
            "not_verified": ["the universal PRA equivalence theorem by a proof assistant",
                             "all schema instances", "intuitionistic proof derivations",
                             "global shortestness or historical priority"],
            "source_terms": "All examples are actual valid terms using earlier recursors; "
                            "no opaque function symbols or semantic equality oracle are used.",
        },
        "syntax": {"valid_description_count": len(language.descriptions),
                   "invalid_cases_rejected": rejected,
                   "coverage_certificate": coverage,
                   "ineligible_examples": boundary_rejections,
                   "shift_pairs_checked": len(sources) ** 2,
                   "shift_parameters": ["a"],
                   "shift_maximum_primitive_arity": 2,
                   "shift_samples": shifts,
                   "binary_gate_alternative": gate_pair},
        "formula_metrics": formula_metrics(),
        "finite_numerical_checks": {
            "domain_for_predecessor_countdown_comparator_reconstruction": [0, 12],
            "pairs_checked": numerical_pairs,
            "compiler_formula_count": len(formulas),
            "compiler_input_domain": [0, 8],
            "compiler_valuations_checked": formula_checks,
            "warning": "Finite standard-natural truth tables are sanity checks, "
                       "not proofs in the reduced arithmetic theory.",
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().with_name("validation_report.json"))
    args = parser.parse_args()
    report = run_checks()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "report": str(args.output.resolve()),
                      "shift_pairs_checked": report["syntax"]["shift_pairs_checked"],
                      "compiler_valuations_checked": report["finite_numerical_checks"]
                                                        ["compiler_valuations_checked"]},
                     indent=2))


if __name__ == "__main__":
    main()
