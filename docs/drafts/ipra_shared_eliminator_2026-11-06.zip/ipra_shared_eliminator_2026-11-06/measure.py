"""Recompute every measured source size without importing benchmark code."""

import ast
import copy
import hashlib
import io
import json
from pathlib import Path
import sys
import tokenize

ROOT = Path(__file__).resolve().parent
SKIP = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
        tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
DOCOWNERS = (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)
COUNTS = ("raw_bytes", "lexical_tokens", "token_characters", "ast_nodes")


def is_docstring(node):
    return (isinstance(node, DOCOWNERS) and node.body
            and isinstance(node.body[0], ast.Expr)
            and isinstance(node.body[0].value, ast.Constant)
            and isinstance(node.body[0].value.value, str))


def measure(path):
    raw = path.read_bytes()
    source = raw.decode("utf-8")
    tree = ast.parse(source)
    spans = [((node.body[0].lineno, node.body[0].col_offset),
              (node.body[0].end_lineno, node.body[0].end_col_offset))
             for node in ast.walk(tree) if is_docstring(node)]
    executable = copy.deepcopy(tree)
    for node in ast.walk(executable):
        if is_docstring(node):
            del node.body[0]
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(source).readline)
              if t.type not in SKIP
              and not any(start <= t.start and t.end <= end for start, end in spans)]
    return {"raw_bytes": len(raw), "lexical_tokens": len(tokens),
            "token_characters": sum(len(t.string) for t in tokens),
            "ast_nodes": sum(1 for _ in ast.walk(executable)),
            "sha256": hashlib.sha256(raw).hexdigest()}


def run():
    manifest = json.loads((ROOT / "benchmark/original_measurements.json").read_text())
    paths = {f["path"]: f for variant in manifest["variants"] for f in variant["files"]}
    measured = {}
    for name, expected in sorted(paths.items()):
        actual = measure(ROOT / "benchmark" / name)
        if actual != {key: expected[key] for key in actual}:
            raise ValueError("benchmark source or measurement changed: " + name)
        measured[name] = actual
    for variant in manifest["variants"]:
        total = {key: sum(measured[f["path"]][key] for f in variant["files"])
                 for key in COUNTS}
        if total != variant["whole_source_totals"]:
            raise ValueError("benchmark total mismatch: " + variant["variant"])

    new = measure(ROOT / "kernel.py")
    old = measure(ROOT / "baseline/checker.py")
    minimum = {key: min(v["whole_source_totals"][key] for v in manifest["variants"])
               for key in COUNTS}
    if not (new["lexical_tokens"] < minimum["lexical_tokens"]
            and new["ast_nodes"] < minimum["ast_nodes"]):
        raise ValueError("candidate no longer improves both observed frontiers")
    result = {
        "python_version": sys.version,
        "new": new, "matched_baseline": old, "observed_minima": minimum,
        "matched_savings": {key: old[key] - new[key] for key in COUNTS},
        "matched_reduction_percent": {key: 100 * (old[key] - new[key]) / old[key]
                                      for key in COUNTS},
        "archives": len(manifest["archives"]), "variants": len(manifest["variants"]),
        "distinct_benchmark_source_files": len(measured),
        "convention": manifest["measurement_convention"],
        "limits": manifest["limitations"],
        "all_benchmark_sources_verified": True,
    }
    (ROOT / "verification/measurements.json").write_text(json.dumps(result, indent=2) + "\n")
    macros = {"NewTokens": new["lexical_tokens"], "NewAST": new["ast_nodes"],
              "NewBytes": new["raw_bytes"], "OldTokens": old["lexical_tokens"],
              "OldAST": old["ast_nodes"], "OldBytes": old["raw_bytes"],
              "TokenSaving": old["lexical_tokens"] - new["lexical_tokens"],
              "ASTSaving": old["ast_nodes"] - new["ast_nodes"],
              "MinAST": minimum["ast_nodes"]}
    (ROOT / "measurements.tex").write_text("".join(
        "\\newcommand{\\" + key + "}{" + str(value) + "}\n" for key, value in macros.items()))
    lines = ["\\begin{tabularx}{\\textwidth}{@{}Xrrr@{}}", "\\toprule",
             "Current archive & Tokens & AST & Bytes\\\\", "\\midrule"]
    for archive in manifest["archives"]:
        row = archive["recommended_whole_source_totals"]
        name = archive["name"].replace("_", "\\_")
        lines.append("\\texttt{" + name + "} & " + str(row["lexical_tokens"])
                     + " & " + str(row["ast_nodes"]) + " & " + str(row["raw_bytes"]) + "\\\\")
    lines += ["\\midrule", "\\textbf{This deliverable} & \\textbf{" + str(new["lexical_tokens"])
              + "} & \\textbf{" + str(new["ast_nodes"]) + "} & " + str(new["raw_bytes"]) + "\\\\",
              "\\bottomrule", "\\end{tabularx}"]
    (ROOT / "benchmark_table.tex").write_text("\n".join(lines) + "\n")
    print(json.dumps({key: result[key] for key in
                      ("new", "matched_baseline", "observed_minima", "archives", "variants")}, indent=2))
    return result


if __name__ == "__main__":
    run()
