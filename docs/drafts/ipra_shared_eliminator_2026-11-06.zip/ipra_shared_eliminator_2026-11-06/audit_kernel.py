"""Independent targeted audit of the fused equality/Pi/Sigma eliminator.

Expected capture results are written explicitly, rather than calculated
with the candidate substitution code. This is a finite regression audit,
not a formal proof of kernel soundness.
"""

import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parent
TARGET = ROOT / "kernel.py"
if len(sys.argv) > 1:
    TARGET = Path(sys.argv[1]).resolve()
spec = importlib.util.spec_from_file_location("audited_shared_kernel", TARGET)
kernel = importlib.util.module_from_spec(spec)
spec.loader.exec_module(kernel)

Z = ("z",)
ONE = ("s", Z)
TOP = ("=", Z, Z)
FALSE = ("false",)


def eq(s, t):
    return ("=", s, t)


def refl(t):
    # This helper needs only variables and the two closed numerals below.
    if type(t) is int:
        lifted = t + 1
    elif t in (Z, ONE):
        lifted = t
    else:
        raise ValueError("unsupported test-builder argument")
    r = ("r", Z, t, Z)
    p = ("rec", r)
    return ("use", p, eq(0, lifted), p)


fixtures = []


def add(name, accepted, assumptions, goal, proof):
    fixtures.append({"name": name, "expected": accepted,
                     "data": {"assumptions": list(assumptions),
                              "goal": goal, "proof": proof}})


# Equality payload is a formula with its own formal numerical slot.
# F(u) = Pi y (TOP, rec(0,u;v,w.u)=u). The recursor body contains
# three local binders (y,v,w), so the external parameter is index 3.
F = ("pi", TOP, eq(("r", Z, 1, 3), 1))
FX = ("pi", TOP, eq(("r", Z, 1, 3), 1))
FY = ("pi", TOP, eq(("r", Z, 2, 4), 2))
F_CAPTURE = ("pi", TOP, eq(("r", Z, 0, 2), 0))
g_eq = (eq(0, 1), FX)
p_eq = ("use", ("hyp", 0), F, ("hyp", 1))
add("eq_nested_binders_preserve_parameter", True, g_eq, FY, p_eq)
add("eq_nested_binders_reject_capture", False, g_eq, F_CAPTURE, p_eq)
add("eq_reject_term_payload", False, g_eq, FY,
    ("use", ("hyp", 0), 0, ("hyp", 1)))
add("eq_reject_reverse_minor_instance", False, (eq(0, 1), FY), FX, p_eq)

# Pi x (TOP, Pi y (TOP, x=y)); after instantiating x with ambient 0,
# the output must retain that ambient variable as index 1 under y.
PI_MAJOR = ("pi", TOP, ("pi", TOP, eq(1, 0)))
PI_RESULT = ("pi", TOP, eq(1, 0))
PI_CAPTURE = ("pi", TOP, eq(0, 0))
p_pi = ("use", ("hyp", 0), 0, refl(Z))
add("pi_instantiation_preserves_free_variable", True, (PI_MAJOR,), PI_RESULT, p_pi)
add("pi_instantiation_rejects_bound_capture", False, (PI_MAJOR,), PI_CAPTURE, p_pi)
add("pi_reject_formula_payload", False, (PI_MAJOR,), PI_RESULT,
    ("use", ("hyp", 0), TOP, refl(Z)))
add("pi_reject_wrong_minor", False, (PI_MAJOR, eq(Z, ONE)), PI_RESULT,
    ("use", ("hyp", 0), 0, ("hyp", 1)))

# Sigma elimination opens the witness and adds its two component assumptions.
SIG_MAJOR = ("sig", TOP, eq(0, Z))
add("sigma_closed_conclusion", True, (SIG_MAJOR,), TOP,
    ("use", ("hyp", 0), TOP, ("hyp", 1)))
add("sigma_reject_witness_escape", False, (SIG_MAJOR,), eq(0, Z),
    ("use", ("hyp", 0), eq(0, Z), ("hyp", 2)))
add("sigma_reject_term_payload", False, (SIG_MAJOR,), TOP,
    ("use", ("hyp", 0), 0, ("hyp", 1)))
add("sigma_retains_shifted_ambient_assumption", True,
    (SIG_MAJOR, eq(0, Z)), eq(0, Z),
    ("use", ("hyp", 0), eq(0, Z), ("hyp", 1)))
add("sigma_reject_ambient_assumption_capture", False,
    (SIG_MAJOR, eq(1, Z)), eq(0, Z),
    ("use", ("hyp", 0), eq(0, Z), ("hyp", 1)))
PI_ID = ("pi", TOP, eq(0, 0))
add("sigma_nested_binder_conclusion", True, (SIG_MAJOR,), PI_ID,
    ("use", ("hyp", 0), PI_ID, ("pi", TOP, refl(0))))
add("use_reject_falsity_principal", False, (FALSE,), FALSE,
    ("use", ("hyp", 0), FALSE, ("hyp", 0)))

# Open ambient scopes still require fresh local numerical variables.
BIG = 10**30
add("open_scope_large_ambient_index", True, (), eq(BIG, BIG), refl(BIG))
add("open_scope_pi_retains_ambient_variable", True, (eq(0, Z),),
    ("pi", TOP, eq(1, Z)), ("pi", TOP, ("hyp", 0)))
add("open_scope_pi_reject_ambient_capture", False, (eq(0, Z),),
    ("pi", TOP, eq(0, Z)), ("pi", TOP, ("hyp", 0)))

# Matrix x |-> parameter=0: the ambient parameter must stay fixed.
P_PARAMETER = eq(1, Z)
add("nat_retains_fixed_parameter", True, (eq(0, Z),), eq(0, Z),
    ("nat", P_PARAMETER, 0, ("hyp", 0), ("hyp", 0)))

# Constant quantified matrices isolate the forbidden induction assumption.
# Their conclusions are harmless theorems; their forged proofs are invalid
# because the step hypothesis index must not exist for a non-equation.
P_PI = ("pi", TOP, TOP)
PI_PROOF = ("pi", TOP, ("hyp", 0))
add("nat_pi_cases_without_ih", True, (), P_PI,
    ("nat", P_PI, 0, PI_PROOF, PI_PROOF))
add("nat_pi_reject_injected_ih", False, (), P_PI,
    ("nat", P_PI, 0, PI_PROOF, ("hyp", 0)))
P_SIG = ("sig", TOP, TOP)
SIG_PROOF = ("pair", P_SIG, Z, refl(Z), refl(Z))
add("nat_sigma_cases_without_ih", True, (), P_SIG,
    ("nat", P_SIG, 0, SIG_PROOF, SIG_PROOF))
add("nat_sigma_reject_injected_ih", False, (), P_SIG,
    ("nat", P_SIG, 0, SIG_PROOF, ("hyp", 0)))
add("nat_falsity_reject_injected_ih", False, (FALSE,), FALSE,
    ("nat", FALSE, 0, ("hyp", 0), ("hyp", 1)))
add("nat_reject_ih_in_base", False, (), eq(0, 0),
    ("nat", eq(0, 0), 0, ("hyp", 0), refl(("z",))))

# Public JSON boundary / sorts / exact shapes.
add("reject_boolean_variable", False, (eq(True, Z),), eq(True, Z), ("hyp", 0))
add("reject_boolean_hypothesis_index", False, (TOP,), TOP, ("hyp", False))
add("reject_negative_variable", False, (eq(-1, Z),), eq(-1, Z), ("hyp", 0))
add("reject_malformed_sigma_arity", False, (("sig", TOP),), TOP, ("hyp", 0))
add("reject_formula_in_term_position", False, (eq(TOP, Z),), eq(TOP, Z), ("hyp", 0))
add("reject_unknown_formula_tag", False, (("unknown",),), ("unknown",), ("hyp", 0))
add("reject_unknown_proof_tag", False, (), TOP, ("unknown",))
add("reject_nonrecursor_rec_leaf", False, (), TOP, ("rec", ("s", Z)))
add("reject_recursion_unknown_counter", False, (), TOP, ("rec", ("r", 0, Z, Z)))
add("reject_negative_nat_target", False, (), P_PI,
    ("nat", P_PI, -1, PI_PROOF, PI_PROOF))


def accepts(data):
    try:
        return kernel.check(data) is True
    except (ValueError, TypeError, IndexError, KeyError, RecursionError):
        return False


results = []
for f in fixtures:
    # JSON round-trip is deliberate: the public input consists of JSON values.
    data = json.loads(json.dumps(f["data"]))
    got = accepts(data)
    result = {"name": f["name"], "expected": f["expected"], "actual": got,
              "pass": got == f["expected"]}
    results.append(result)
    if not result["pass"]:
        raise AssertionError(json.dumps(result))

# Exercise independent fresh fixtures through the actual CLI, in both modes.
cli_names = {"eq_nested_binders_preserve_parameter", "eq_nested_binders_reject_capture",
             "sigma_retains_shifted_ambient_assumption", "sigma_reject_witness_escape",
             "nat_pi_cases_without_ih", "nat_pi_reject_injected_ih"}
cli_results = []
with tempfile.TemporaryDirectory(prefix="shared-elimination-audit-") as temporary:
    for f in fixtures:
        if f["name"] not in cli_names:
            continue
        path = Path(temporary) / (f["name"] + ".json")
        path.write_text(json.dumps(f["data"]), encoding="utf-8")
        for optimized in (False, True):
            cmd = [sys.executable, *(["-O"] if optimized else []), str(TARGET), str(path)]
            run = subprocess.run(cmd, text=True, capture_output=True, timeout=10)
            expected_code = 0 if f["expected"] else 1
            expected_text = "ACCEPT" if f["expected"] else "REJECT"
            okay = run.returncode == expected_code and run.stdout.strip() == expected_text
            row = {"name": f["name"], "optimized": optimized,
                   "returncode": run.returncode, "output": run.stdout.strip(), "pass": okay}
            cli_results.append(row)
            if not okay:
                raise AssertionError(json.dumps(row))

report = {"candidate": str(TARGET), "api_checks": len(results),
          "positive_checks": sum(f["expected"] for f in fixtures),
          "negative_checks": sum(not f["expected"] for f in fixtures),
          "cli_checks": len(cli_results), "all_passed": True,
          "checks": results, "cli": cli_results,
          "scope": "Independent finite targeted audit; not a general formal soundness proof."}
(ROOT / "verification/independent_audit.json").write_text(json.dumps(report, indent=2) + "\n")
(ROOT / "verification/independent_fixtures.json").write_text(json.dumps(fixtures, indent=2) + "\n")
print(json.dumps({k: report[k] for k in ("candidate", "api_checks", "positive_checks",
                                        "negative_checks", "cli_checks", "all_passed")}, indent=2))
