"""Reproduce checks, compile the paper, and package the complete deliverable."""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
SKIP_SUFFIXES = {".aux", ".log", ".out", ".toc", ".pyc", ".fls", ".fdb_latexmk"}


def run(command):
    subprocess.run(command, cwd=ROOT, check=True)


def validation_summary():
    main = json.loads((ROOT / "verification/replay.json").read_text())["summary"]
    audit = json.loads((ROOT / "verification/independent_audit.json").read_text())
    if not (main["all_passed"] and audit["all_passed"]):
        raise ValueError("validation is not successful")
    text = ("The main suite replays all " + str(main["source_certificates_replayed"])
            + " source certificates and recovers all their original proof trees exactly. "
            + "It additionally checks " + str(main["native_builder_certificates"])
            + " certificates emitted directly in the new format, including quantified "
            + "explosion and disjunction. All " + str(main["reverse_translations_checked"])
            + " reverse translations are accepted by the archived verifier. "
            + "It preserves six inherited valid adversarial cases, rejects "
            + str(main["rejected_cases_total"]) + " invalid inputs, and passes "
            + str(main["cli_checks"]) + " command-line checks in ordinary and optimized Python.\n\n"
            + "The separate independent audit passes " + str(audit["api_checks"])
            + " targeted API checks (" + str(audit["positive_checks"]) + " valid and "
            + str(audit["negative_checks"]) + " invalid), plus " + str(audit["cli_checks"])
            + " additional command-line checks in the two Python modes. "
            + "All results and exact fixtures are included under \\texttt{verification/}.\n")
    (ROOT / "verification_summary.tex").write_text(text)


def members():
    return sorted(p for p in ROOT.rglob("*") if p.is_file()
                  and "__pycache__" not in p.parts
                  and p.suffix not in SKIP_SUFFIXES
                  and p.name not in {"SHA256SUMS.txt", ".DS_Store"})


def package():
    paths = members()
    if not (ROOT / "report.pdf").is_file():
        raise FileNotFoundError("report.pdf must exist before packaging")
    checksums = "".join(hashlib.sha256(p.read_bytes()).hexdigest()
                        + "  " + p.relative_to(ROOT).as_posix() + "\n" for p in paths)
    (ROOT / "SHA256SUMS.txt").write_text(checksums)
    target = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in [*paths, ROOT / "SHA256SUMS.txt"]:
            archive.write(path, ROOT.name + "/" + path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(target) as archive:
        bad = archive.testzip()
        if bad:
            raise ValueError("archive CRC failure: " + bad)
    print("Created", target.name, "with", len(paths) + 1, "files")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package-only", action="store_true")
    args = parser.parse_args()
    if not args.package_only:
        for script in ("test_kernel.py", "audit_kernel.py", "measure.py"):
            run([sys.executable, "-B", script])
        validation_summary()
        for number in (1, 2, 3):
            result = subprocess.run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                                     "report.tex"], cwd=ROOT, capture_output=True, text=True)
            (ROOT / f"verification/latex_pass_{number}.txt").write_text(result.stdout + result.stderr)
            if result.returncode:
                raise RuntimeError("LaTeX failed; inspect verification/latex_pass_" + str(number) + ".txt")
    package()


if __name__ == "__main__":
    main()
