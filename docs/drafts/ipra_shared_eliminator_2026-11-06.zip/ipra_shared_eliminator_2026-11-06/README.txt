A SMALLER iPRA PROOF CHECKER WITH A SHARED ELIMINATOR
6 November 2026
=================================================

RESULT

The complete verifier has 1,098 significant Python tokens and 1,183 AST
nodes. This is below both observed minima among 55 supplied implementation
variants from all eleven current ProveIt draft archives: 1,167 tokens and
1,248 AST nodes. The exact matched predecessor has 1,167 tokens and 1,252
AST nodes; the shared operation saves 69 of each. Raw source is 4,026 bytes.

The theory is full first-order intuitionistic primitive recursive arithmetic
in a compact presentation: native initialized recursion; equations, genuine
falsity, Pi=forall(implication), Sigma=exists(conjunction); derived reflexivity
and explosion; and a rule providing equation induction and numerical cases.
All logical/nonlogical axioms, schemas, rules and side conditions are given
in SPECIFICATION.txt and proved equivalent to iPRA in report.pdf.

Both interpretations use the whole number carrier. Internal equation
induction proves both numerical round trips, including at nonstandard
counters. Falsity is preserved literally, so syntactic equiconsistency follows.

The mathematical core is inherited from the current smallest draft. The new
contribution is a smaller complete checker and certificate grammar: equality,
Pi and Sigma elimination use one principal-directed record, "use". The three
mathematical rule instances remain explicit. No global smallest-program
theorem is claimed; these are measured improvements over supplied programs.

SOURCE SNAPSHOT

Repository: https://github.com/VladimirReshetnikov/ProveIt
Directory: docs/drafts
Commit: b079e5787b1d708049ff0643ce1b534c1a225198
All eleven archive downloads were checked against their Git blob identities.
source_manifest.json records exact paths, sizes, hashes and pinned URLs.
The closest baseline is code/checker.py from ipra_kernel_2026-11-06.zip.
baseline/checker.py is that file verbatim.

CONTENTS

report.tex, sections/, report.pdf   Complete paper, proofs and source listing.
SPECIFICATION.txt                  Exact standalone mathematical/certificate spec.
kernel.py                          Entire trusted verifier, including JSON/CLI.
translation.py                     Untrusted lossless proof-format adapters.
proof_builders.py                  Untrusted native proof-producing helpers.
test_kernel.py                     Proof replay, round trips and rejection suite.
audit_kernel.py                    Independent capture/sort/freshness audit.
certificates/                      Accepted and deliberately rejected examples.
baseline/                          Exact predecessor and its source fixtures.
benchmark/                         67 source snapshots; 55 variant measurements.
measure.py                         Offline hash/size comparison, no source execution.
verification/                      Results, review, compiler logs and PDF inspection.
build.py                           Reproduction, PDF compilation and ZIP creation.
SHA256SUMS.txt                     Checksums for the other delivered files.

QUICK START

From this extracted directory, using Python 3.10 or newer:

  python3 kernel.py certificates/builders/reflexivity_with_free_recursion_parameters.json
  python3 test_kernel.py
  python3 audit_kernel.py
  python3 measure.py

The kernel prints ACCEPT and exits 0 only for an accepted certificate;
invalid certificates print REJECT and exit 1. Nonempty assumptions mean the
claim is a sequent, not an unconditional theorem. Numerical variables use
nonnegative integer indices, while zero is ["z"]. See SPECIFICATION.txt.

To rebuild the PDF and ZIP (also needs pdflatex and the ordinary packages in
report.tex):

  python3 build.py

To refresh the ZIP/checksums without recompiling after an unchanged PDF:

  python3 build.py --package-only

VALIDATION

Main suite: 53 source certificates replayed; all 53 old proof trees recovered
exactly; 8 direct native-use builder certificates; all 61 reverse translations
accepted by the archived verifier; 28 invalid cases rejected; 4 CLI checks in
ordinary and optimized Python. Six inherited valid adversarial cases also pass.

Independent audit: 35 API checks (10 valid, 25 invalid) and 12 further CLI
checks in ordinary/optimized Python. All pass. These check finite certificates;
the universal soundness, interpretation and round-trip results are written
mathematical proofs, not completed Lean/Rocq formalizations.

Measurement includes fixed data, syntax validation, substitution, all rule
checks, imports, error handling and CLI. Comments/layout/docstrings are omitted
only from the significant-token and AST counts. Standard Python and its
standard libraries are common external dependencies. Some wider-inventory
alternative cores use an unchanged shared adapter by installing the selected
core as kernel.py; these groups are labeled. API-only variants and duplicates
are retained in the 55-variant inventory. The main matched comparison has
identical term/formula syntax and the same root input contract.

The concrete verifier may reject very large valid proofs due to host resource
limits. There is no arithmetic evaluator, proof-search oracle or implicit
normalization in the trusted verifier.
