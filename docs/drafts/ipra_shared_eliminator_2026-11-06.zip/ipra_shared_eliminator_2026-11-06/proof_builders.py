"""Untrusted examples of derived rules, emitting native `use` certificates.

The verifier never imports this module. Every constructed certificate is
checked by kernel.check before it is returned. Arithmetic and disjunction
constructions follow the supplied draft_03 derived.py; the explosion builder
uses an explicit implication from falsity, avoiding a proof-lifting routine.
"""

import kernel as k


Z, FALSE = k.ZERO, k.FALSE
ONE = ("s", Z)
TRUE = ("=", Z, Z)


def eq(s, t):
    return ("=", s, t)


def suc(t):
    return ("s", t)


def rec(n, initial, body):
    return ("r", n, initial, body)


def implies(a, b):
    return ("pi", k.shift(a), k.shift(b))


def conjunction(a, b):
    return ("sig", k.shift(a), k.shift(b))


def disjunction(a, b):
    # The outer witness has index 1 beneath each inner Pi binder.
    return ("sig", ("pi", eq(1, Z), k.shift(a, 2)),
            ("pi", eq(1, suc(0)), k.shift(b, 2)))


def refl(t):
    computation = ("rec", rec(Z, t, Z))
    return ("use", computation, eq(0, k.shift(t)), computation)


def sym(equality_proof, left):
    return ("use", equality_proof, eq(0, k.shift(left)), refl(left))


def trans(first, second, left):
    return ("use", second, eq(k.shift(left), 0), first)


def collapse(clash_proof, s, t):
    """Derive s=t from an actual proof of the closed equation 0=S0."""
    body = k.shift(t, 2)
    successor = rec(ONE, s, body)
    template = eq(rec(0, k.shift(s), k.shift(t, 3)), k.shift(s))
    moved = ("use", clash_proof, template, ("rec", rec(Z, s, body)))
    return trans(sym(moved, successor), ("rec", successor), s)


def separate(n, zero_successor_proof):
    """Derive genuine falsity from a proof of 0=S(n), without induction."""
    successor = rec(suc(n), Z, ONE)
    template = eq(rec(0, Z, ONE), Z)
    moved = ("use", zero_successor_proof, template, ("rec", rec(Z, Z, ONE)))
    clash = trans(sym(moved, successor), ("rec", successor), Z)
    return ("bridge", clash)


def from_false_assumption(formula, false_index):
    """Structural derivation from a designated undischarged FALSE hypothesis."""
    match formula:
        case ("false",):
            return ("hyp", false_index)
        case ("=", s, t):
            return collapse(("bridge", ("hyp", false_index)), s, t)
        case ("pi", a, b):
            # Appending a guard leaves the old bottom hypothesis index intact.
            return ("pi", a, from_false_assumption(b, false_index))
        case ("sig", a, b):
            return ("pair", formula, Z,
                    from_false_assumption(k.inst(a, Z), false_index),
                    from_false_assumption(k.inst(b, Z), false_index))
        case _:
            raise ValueError("unknown formula in explosion builder")


def explode(false_proof, formula, context_size):
    """Derive an arbitrary formula from a supplied FALSE proof in its context."""
    implication = ("pi", FALSE,
                   from_false_assumption(k.shift(formula), context_size))
    return ("use", implication, Z, false_proof)


def or_left(a, b, assumption=0, context_size=1):
    first = ("pi", TRUE, ("hyp", assumption))
    second = ("pi", eq(Z, suc(0)),
              explode(separate(0, ("hyp", context_size)), k.shift(b), context_size + 1))
    return ("pair", disjunction(a, b), Z, first, second)


def or_right(a, b, assumption=0, context_size=1):
    first = ("pi", eq(ONE, Z),
             explode(("bridge", sym(("hyp", context_size), ONE)),
                     k.shift(a), context_size + 1))
    second = ("pi", eq(ONE, suc(0)), ("hyp", assumption))
    return ("pair", disjunction(a, b), ONE, first, second)


def or_eliminate(a, b, c):
    """Derive C under exactly [A OR B, A -> C, B -> C]."""
    # Sigma adds witness slot 0 and guard hypotheses 3,4. The case predicate
    # compares this fixed witness with a fresh variable before returning C.
    predicate = implies(eq(1, 0), k.shift(c, 2))
    base = ("pi", eq(1, Z),
            ("use", ("hyp", 1), Z,
             ("use", ("hyp", 3), Z, ("hyp", 5))))
    step = ("pi", eq(2, suc(1)),
            ("use", ("hyp", 2), Z,
             ("use", ("hyp", 4), 1, ("hyp", 5))))
    cases = ("nat", predicate, 0, base, step)
    return ("use", ("hyp", 0), c, ("use", cases, Z, refl(0)))


def certificate(goal, proof, assumptions=()):
    result = {"assumptions": list(assumptions), "goal": goal, "proof": proof}
    k.check(result)
    return result


def examples():
    """Eight small-to-nested examples exercising the derived constructions."""
    term = rec(0, 1, suc(2))
    compound = ("pi", eq(0, 1),
                ("sig", eq(2, 1), ("pi", FALSE, eq(1, 3))))
    a = ("pi", eq(0, 1), eq(2, 0))
    b = ("sig", eq(0, 1), FALSE)
    c = ("sig", ("pi", eq(0, 2), eq(1, 3)), TRUE)
    return {
        "reflexivity_with_free_recursion_parameters":
            certificate(eq(term, term), refl(term)),
        "symmetry_with_free_parameters":
            certificate(eq(1, 0), sym(("hyp", 0), 0), [eq(0, 1)]),
        "arithmetic_collapse_under_recursion":
            certificate(eq(term, 2), collapse(("hyp", 0), term, 2), [k.CLASH]),
        "explosion_of_a_quantified_formula":
            certificate(compound, explode(("hyp", 0), compound, 1), [FALSE]),
        "explosion_from_a_derived_false_proof":
            certificate(compound, explode(separate(0, ("hyp", 0)), compound, 1),
                        [eq(Z, suc(0))]),
        "disjunction_left_with_quantifiers":
            certificate(disjunction(a, b), or_left(a, b), [a]),
        "disjunction_right_with_quantifiers":
            certificate(disjunction(a, b), or_right(a, b), [b]),
        "disjunction_elimination_with_quantifiers":
            certificate(c, or_eliminate(a, b, c),
                        [disjunction(a, b), implies(a, c), implies(b, c)]),
    }
