"""Untrusted certificate adapters between the old and fused-use kernels.

These functions are proof producers, not part of either trusted checker.
Always validate the resulting document with its destination checker.
The decoder uses the candidate's inferred principal type to choose the old
eliminator, retaining the exact context at every recursive proof node.
"""


def freeze(a):
    return tuple(map(freeze, a)) if type(a) is list else a


def encode_proof(p):
    """Replace old app/eq/let proof constructors by the shared use form."""
    match p:
        case ("hyp", _):
            return p
        case ("pi", a, q):
            return ("pi", a, encode_proof(q))
        case (("app" | "eq" | "let"), p, a, q):
            return ("use", encode_proof(p), a, encode_proof(q))
        case ("pair", a, t, p, q):
            return ("pair", a, t, encode_proof(p), encode_proof(q))
        case ("bridge", p):
            return ("bridge", encode_proof(p))
        case ("rec", _):
            return p
        case ("nat", a, t, p, q):
            return ("nat", a, t, encode_proof(p), encode_proof(q))
        case _:
            raise ValueError("unknown old proof constructor")


def decode_proof(p, g, kernel):
    """Expand an accepted candidate proof under its actual ambient context."""
    match p:
        case ("hyp", _):
            return p
        case ("pi", a, q):
            inner = (*map(kernel.shift, g), a)
            return ("pi", a, decode_proof(q, inner, kernel))
        case ("use", p, a, q):
            principal = kernel.infer(p, g)
            tag = {"pi": "app", "=": "eq", "sig": "let"}[principal[0]]
            inner = ((*map(kernel.shift, g), *principal[1:])
                     if principal[0] == "sig" else g)
            return (tag, decode_proof(p, g, kernel), a,
                    decode_proof(q, inner, kernel))
        case ("pair", a, t, p, q):
            return ("pair", a, t, decode_proof(p, g, kernel),
                    decode_proof(q, g, kernel))
        case ("bridge", p):
            return ("bridge", decode_proof(p, g, kernel))
        case ("rec", _):
            return p
        case ("nat", a, t, p, q):
            hypotheses = (a,) if a[0] == "=" else ()
            inner = (*map(kernel.shift, g), *hypotheses)
            return ("nat", a, t, decode_proof(p, g, kernel),
                    decode_proof(q, inner, kernel))
        case _:
            raise ValueError("unknown candidate proof constructor")


def encode_document(data):
    """Translate a document without dropping any root validation fields."""
    return {**data, "proof": encode_proof(freeze(data["proof"]))}


def decode_document(data, kernel):
    """Validate with the candidate, then produce a document for the old checker."""
    kernel.check(data)
    g = tuple(map(freeze, data["assumptions"]))
    return {**data, "proof": decode_proof(freeze(data["proof"]), g, kernel)}
