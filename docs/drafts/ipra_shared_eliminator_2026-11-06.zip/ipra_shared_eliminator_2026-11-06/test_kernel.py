"""Reproduce finite certificate checks and both proof-translation directions.

Run with Python 3.10 or later: python3 test_kernel.py
The test generates certificates/ and verification/replay.json. It does not
modify the archived baseline or the trusted verifier. These are executable
regressions, not a machine-checked proof of the universal metatheorems.
"""

from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys

sys.dont_write_bytecode = True

import kernel as k
import proof_builders as b
import translation as tr


ROOT = Path(__file__).resolve().parent
REJECTION_ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError)


def ensure(condition, message):
    # Test failures remain effective when this script itself is run with -O.
    if not condition:
        raise AssertionError(message)


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def json_document(data):
    return json.loads(json.dumps(data))


def save_certificate(relative_path, document):
    path = ROOT / relative_path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(document, separators=(",", ":")) + "\n")
    return path


def document(goal, proof, assumptions=()):
    return {"assumptions": list(assumptions), "goal": goal, "proof": proof}


def malformed_documents():
    """Small independent checks of the new eliminator and certificate boundary."""
    true = b.TRUE
    pi = ("pi", true, true)
    sigma = ("sig", true, true)
    h0, h1 = ("hyp", 0), ("hyp", 1)
    result = {
        "use_pi_formula_payload":
            document(true, ("use", h0, true, h1), [pi, true]),
        "use_eq_term_payload":
            document(true, ("use", h0, b.Z, h1), [true, true]),
        "use_sigma_term_payload":
            document(true, ("use", h0, b.Z, h1), [sigma]),
        "use_falsity_principal":
            document(true, ("use", h0, true, h1), [k.FALSE, true]),
        "use_pi_wrong_minor":
            document(true, ("use", h0, b.Z, h1), [pi, k.CLASH]),
        "use_eq_wrong_minor":
            document(b.eq(1, b.Z), ("use", h0, b.eq(0, b.Z), h1),
                     [b.eq(0, 1), b.eq(1, 0)]),
        "use_sigma_wrong_branch_conclusion":
            document(k.FALSE, ("use", h0, k.FALSE, h1), [sigma]),
        "use_missing_argument":
            document(true, ("use", h0, true), [true]),
        "use_extra_argument":
            document(true, ("use", h0, b.Z, h1, h1), [pi, true]),
        "use_boolean_numerical_payload":
            document(true, ("use", h0, True, h1), [pi, true]),
        "malformed_formula_arity":
            document(("=", b.Z), h0, [true]),
        "bridge_without_a_premise":
            document(k.FALSE, ("bridge",)),
        "deleted_reflexivity_tag":
            document(true, ("refl", b.Z)),
        "deleted_explosion_tag":
            document(true, ("abort", h0, true), [k.FALSE]),
    }
    extra = document(true, h0, [true])
    extra["ignored_field"] = 0
    result["extra_root_field"] = extra
    bad_context = document(true, h0)
    bad_context["assumptions"] = {"0": true}
    result["nonlist_assumptions"] = bad_context
    return result


def expect_rejected(name, data):
    try:
        k.check(json_document(data))
    except REJECTION_ERRORS:
        return
    raise AssertionError("accepted a rejected example: " + name)


def run():
    old = load_module("archived_checker", ROOT / "baseline/checker.py")
    results = {"source_replay": [], "builder_examples": [],
               "inherited_adversarial": [], "malformed_rejections": [],
               "cli": []}

    # The old document is checked before translation. Source formula syntax
    # is unchanged; only the three elimination proof tags are combined.
    sources = sorted((ROOT / "baseline/certificates").glob("*.json"))
    ensure(len(sources) == 53, "expected the 53 pinned source certificates")
    for path in sources:
        source = json.loads(path.read_text())
        ensure(old.check(source) is True, path.name)
        encoded = json_document(tr.encode_document(source))
        ensure(k.check(encoded) is True, "encoded " + path.name)
        decoded = tr.decode_document(encoded, k)
        ensure(old.check(decoded) is True, "decoded " + path.name)
        ensure(tr.freeze(source["proof"]) == tr.freeze(decoded["proof"]),
               "source proof round trip " + path.name)
        relative = "certificates/replay/" + path.name
        save_certificate(relative, encoded)
        results["source_replay"].append({"source": "baseline/certificates/" + path.name,
                                          "candidate": relative, "exact_roundtrip": True})

    # These proofs are built directly with use, then decoded and re-encoded.
    builders = b.examples()
    for name, generated in builders.items():
        native = json_document(generated)
        ensure(k.check(native) is True, name)
        decoded = tr.decode_document(native, k)
        ensure(old.check(decoded) is True, "builder decoded " + name)
        reencoded = tr.encode_document(decoded)
        ensure(tr.freeze(native["proof"]) == tr.freeze(reencoded["proof"]),
               "candidate proof round trip " + name)
        relative = "certificates/builders/" + name + ".json"
        save_certificate(relative, native)
        results["builder_examples"].append({"name": name, "certificate": relative,
                                            "exact_roundtrip": True})

    # The archived adversarial module imports its original checker by this
    # short name. Restore the previous module entry immediately after loading.
    previous = sys.modules.get("checker")
    sys.modules["checker"] = old
    try:
        adversarial = load_module("archived_adversarial", ROOT / "baseline/adversarial.py")
    finally:
        if previous is None:
            del sys.modules["checker"]
        else:
            sys.modules["checker"] = previous
    for name, source, expected in adversarial.cases:
        encoded = json_document(tr.encode_document(source))
        try:
            actual = k.check(encoded)
        except REJECTION_ERRORS:
            actual = False
        ensure(actual == expected, "inherited adversarial outcome: " + name)
        if actual:
            ensure(old.check(tr.decode_document(encoded, k)) is True, name)
        else:
            save_certificate("certificates/rejected/inherited_" + name + ".json", encoded)
        results["inherited_adversarial"].append({"name": name, "accepted": actual,
                                                 "expected": expected})

    for name, data in malformed_documents().items():
        expect_rejected(name, data)
        relative = "certificates/rejected/" + name + ".json"
        save_certificate(relative, data)
        results["malformed_rejections"].append({"name": name, "certificate": relative})

    positive = ROOT / "certificates/builders/disjunction_elimination_with_quantifiers.json"
    negative = ROOT / "certificates/rejected/use_pi_formula_payload.json"
    for optimized in (False, True):
        command = [sys.executable, *(["-O"] if optimized else []), str(ROOT / "kernel.py")]
        for path, expected_exit, expected_text in ((positive, 0, "ACCEPT"),
                                                    (negative, 1, "REJECT")):
            completed = subprocess.run([*command, str(path)], cwd=ROOT, timeout=30,
                                       text=True, capture_output=True)
            ensure(completed.returncode == expected_exit and
                   completed.stdout.strip() == expected_text,
                   (optimized, path.name, completed.returncode,
                    completed.stdout, completed.stderr))
            results["cli"].append({"optimized": optimized,
                                   "certificate": str(path.relative_to(ROOT)),
                                   "exit_code": completed.returncode,
                                   "output": completed.stdout.strip()})

    inherited_accepts = sum(r["accepted"] for r in results["inherited_adversarial"])
    inherited_rejections = len(results["inherited_adversarial"]) - inherited_accepts
    results["summary"] = {
        "source_certificates_replayed": len(sources),
        "source_proofs_recovered_exactly": len(sources),
        "native_builder_certificates": len(builders),
        "native_proofs_recovered_exactly": len(builders),
        "reverse_translations_checked": len(sources) + len(builders),
        "inherited_adversarial_accepts": inherited_accepts,
        "inherited_adversarial_rejections": inherited_rejections,
        "additional_malformed_rejections": len(results["malformed_rejections"]),
        "rejected_cases_total": inherited_rejections + len(results["malformed_rejections"]),
        "cli_checks": len(results["cli"]),
        "all_passed": True,
    }
    results["sha256"] = {
        name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
        for name in ("kernel.py", "baseline/checker.py", "translation.py",
                     "proof_builders.py", "test_kernel.py")
    }
    results["scope"] = ("Finite executable regressions and proof-translation replays; "
                        "no formal verification of universal soundness or bi-interpretability.")
    destination = ROOT / "verification/replay.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results["summary"], indent=2))
    return results


if __name__ == "__main__":
    run()
