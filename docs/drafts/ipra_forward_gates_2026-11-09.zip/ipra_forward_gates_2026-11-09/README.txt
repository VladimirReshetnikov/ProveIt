FORWARD-GATED SCALAR ARITHMETIC
Research prepared for Vladimir Reshetnikov, 9 November 2026

STATUS
------
A new mathematical reduction of the current gated-induction proposal is
proved: its full PR-description language can be replaced by scalar
initialized iteration, and arbitrary equation induction is recovered
before predecessor and before full logical reconstruction.

The requested strict improvement below the current best complete
checker sizes HAS NOT BEEN ACHIEVED. The corpus envelope is
299 normalized tokens / 340 AST nodes / 815 normalized bytes, attained
by different Choice-DI programs. The complete readable checker supplied
here measures 2755 / 3014 / 12653. This package must not be described as
an absolute simplest axiomatization or a significant checker-size record.

MAIN FILES
----------
report.pdf             Complete 31-page mathematical report.
report.tex             Main LaTeX file; inputs sections/ and appendices/.
report_standalone.tex  Flattened, self-contained LaTeX source.
code/checker.py        Complete standalone acceptance program.
code/FORMAT.txt        Exact numerical, formula, scope and proof format.
code/forward_gate_producer.py
                      Untrusted expanded-proof producer.
code/fixtures/forward_gate_induction.json
                      Closed 214-node primitive proof.
code/fixtures/forward_gate_induction_scoped.json
                      Arbitrary-counter/initializer scoped proof.
code/validation.json   Detailed finite verification receipt.
comparison/           Unchanged attributed frontier programs and normalizer.
evidence/             Pinned corpus audit, measurements and written reviews.
STATUS.json           Machine-readable contribution/limitation record.
MANIFEST.json         SHA-256 hashes of the distributed package members.

REPRODUCTION
------------
Python 3.12.14 was used; only the standard library is needed for checking.
From this directory:

    python3 reproduce.py
    python3 code/checker.py < code/fixtures/forward_gate_induction.json

The latter prints ACCEPT. The scoped companion is replayed by reproduce.py
through Checker.check with an explicit open scope; it is not a closed CLI
packet.

To rebuild the paper with an installed pdflatex and the packages named in
report.tex:

    python3 build.py

No network access or repository checkout is needed for these commands.
MANIFEST.json describes the original distributed bytes; rebuilding a PDF
may change its creation metadata and therefore its digest.

MATHEMATICS
-----------
Numerical syntax is x, 0, S(t), I(n,a;u.h). Only h binds u.
The two computation schemas are I(0,a;u.h)=a and
I(Sn,a;u.h)=h[I(n,a;u.h)/u].

Formulas are equations or paired D(x,y) binders. Immediate atomic matrices
must be literal forward gates C(y,0,s)=C(y,0,t), where
C(v,a,b)=I(v,a;u.b) with unused u. Primitive inference patterns are
clause Use, deterministic gated introduction GI, paired elimination DE,
and equality transport Tr. The full specification is in the report.

The new restoration lemma uses c=s(0) and numerical equation cases to prove
C(n,c,C(n,0,s(n)))=s(n) and C(n,c,C(n,0,r(n)))=r(n).
The second zero case uses the supplied base s(0)=r(0). Congruence of the
outer selector removes the forward gate. This recovers equation induction
without first assuming predecessor, arithmetic equality reflection,
pairing, coverage as a disjunction, or ordinary quantifiers.

The inherited scalar arithmetic construction is reproduced with
attribution. Both numerical interpretation composites are proved equal
internally at arbitrary arguments. Formula round trips use the
characterization of D through the grammar-preserving logical macros,
avoiding an illicit assumption that a double translation preserves the
literal gate shape. The ordinary realization retains (0=1) -> bottom.

EVIDENCE BOUNDARY
-----------------
The two expanded certificates have 214 primitive nodes each and maximum
depth 16. They use the main induction hypothesis; replacing it by a
forged computation is rejected. The integrated run contains 757 finite
checks, including positive and negative derivations, substitution and
scope controls, and 74 normal/optimized standalone executions.

These are executable certificates and tests of particular programs and
instances. Universal soundness, the arithmetic bootstrap and
bi-interpretability are written proofs with independent review, not
Lean/Rocq formalizations.

PROVENANCE
----------
Repository: https://github.com/VladimirReshetnikov/ProveIt
Snapshot: aac8216be66b1a6f043fed87a8d515bc5b5d0790
Directory: docs/drafts
Archives: 30
See ATTRIBUTION.txt, evidence/repository_snapshot.json and
evidence/frontier_summary.json. No modification was published to ProveIt.
