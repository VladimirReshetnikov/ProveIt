"""Untrusted finite proof producers, independent of checker.py."""
import copy
import json
from pathlib import Path

Z = ["0"]


def v(identifier):
    return ["$", identifier]


def S(term):
    return ["S", copy.deepcopy(term)]


def I(counter, seed, state, update):
    return ["I", copy.deepcopy(counter), copy.deepcopy(seed), state,
            copy.deepcopy(update)]


def eq(left, right):
    return ["=", copy.deepcopy(left), copy.deepcopy(right)]


def D(x, y, body):
    return ["D", x, y, copy.deepcopy(body)]


def C(control, left, right):
    return I(control, left, "_selector_state", right)


def gate(control, left, right):
    return eq(C(control, Z, left), C(control, Z, right))


def numeral(number):
    result = Z
    for _ in range(number):
        result = S(result)
    return result


def comp(left, right):
    return {"rule": "comp", "conclusion": eq(left, right)}


def truth():
    return comp(I(Z, Z, "_truth", Z), Z)


def hyp(formula, index):
    return {"rule": "use", "conclusion": copy.deepcopy(formula),
            "clause": index, "term": Z, "premise": truth()}


def gi(conclusion, witness, eigen, premise):
    return {"rule": "gi", "conclusion": copy.deepcopy(conclusion),
            "witness": witness, "eigen": eigen, "premise": premise}


def de(conclusion, major, eigen, premise):
    return {"rule": "de", "conclusion": copy.deepcopy(conclusion),
            "major": major, "eigen": eigen, "premise": premise}


class Builder:
    def __init__(self):
        self.counter = 0

    def tr_explicit(self, equality, before, variable, motive, result):
        return {"rule": "tr", "conclusion": result, "equality": equality,
                "before": before, "variable": variable, "motive": motive}

    def refl(self, term):
        self.counter += 1
        hole = "_proof_hole" + str(self.counter)
        lhs = I(Z, term, "_identity_state", Z)
        axiom = comp(lhs, term)
        return self.tr_explicit(axiom, copy.deepcopy(axiom), hole,
                                eq(v(hole), term), eq(term, term))

    def paired_refl(self, payload=Z, witness=Z, eigen="step_parameter"):
        body = gate(v("bound_counter"), payload, payload)
        target = D("bound_witness", "bound_counter", body)
        step_term = C(S(v(eigen)), Z, payload)
        return gi(target, witness, eigen, self.refl(step_term))

    def main_cases(self):
        two = numeral(2)
        one = numeral(1)
        identity_update = I(Z, two, "u", S(v("u")))
        next_value = I(Z, two, "u", S(v("u")))
        positive = {
            "iterator_zero": comp(identity_update, two),
            "iterator_successor": comp(I(one, two, "u", S(v("u"))), S(next_value)),
            "derived_reflexivity": self.refl(two),
            "atomic_gi": self.paired_refl(two),
        }
        witness_body = gate(v("counter"), v("witness"), v("witness"))
        witness_goal = D("witness", "counter", witness_body)
        step = self.refl(C(S(v("variable_step")), Z, two))
        positive["nonzero_witness"] = gi(witness_goal, two, "variable_step", step)

        inner = self.paired_refl(Z, eigen="inner_step")
        F = inner["conclusion"]
        outer = D("unused_x", "unused_n", F)
        outer_proof = gi(outer, Z, "compound_step", hyp(F, 0))
        minor = {"rule": "use", "conclusion": F, "clause": 0,
                 "term": one, "premise": inner}
        positive["compound_base_and_elimination"] = de(F, outer_proof, "opened", minor)

        ih_eigen = "ih_parameter"
        ih_body = gate(v("n"), Z, Z)
        ih_goal = D("unused", "n", ih_body)
        retained = gate(v(ih_eigen), Z, Z)
        step_formula = gate(S(v(ih_eigen)), Z, Z)
        step_refl = self.refl(C(S(v(ih_eigen)), Z, Z))
        ih_step = self.tr_explicit(hyp(retained, 0), step_refl, "unused_hole",
                                   step_formula, step_formula)
        positive["atomic_hypothesis_consumed"] = gi(ih_goal, Z, ih_eigen, ih_step)

        scope = {"z"}
        z = v("z")
        source = I(Z, S(z), "source_state", Z)
        equality = comp(source, S(z))
        old_term = I(Z, Z, "renamed_state", source)
        new_term = I(Z, Z, "renamed_state", S(z))
        motive_term = I(Z, Z, "z", v("transport_hole"))
        capture_I = self.tr_explicit(equality, self.refl(old_term), "transport_hole",
                                     eq(motive_term, motive_term), eq(new_term, new_term))

        motive_D = D("z", "n", gate(v("n"), v("hole_D"), v("hole_D")))
        old_D = D("renamed_witness", "n", gate(v("n"), source, source))
        old_step = self.refl(C(S(v("capture_step")), Z, source))
        old_proof = gi(old_D, Z, "capture_step", old_step)
        new_D = D("renamed_witness", "n", gate(v("n"), S(z), S(z)))
        capture_D = self.tr_explicit(equality, old_proof, "hole_D", motive_D, new_D)
        scoped = {
            "transport_avoids_iterator_capture": {"scope": scope, "context": (), "proof": capture_I},
            "transport_avoids_paired_capture": {"scope": scope, "context": (), "proof": capture_D},
        }
        nested = I(one, z, "u", I(Z, Z, "z", v("u")))
        recursive = I(Z, z, "u", I(Z, Z, "z", v("u")))
        unfolded = I(Z, Z, "renamed_numeric", recursive)
        scoped["iterator_unfolding_avoids_capture"] = {
            "scope": scope, "context": (), "proof": comp(nested, unfolded)}
        clause_body = eq(I(Z, v("b"), "u", S(v("u"))), v("b"))
        clause = (truth()["conclusion"], "b", clause_body)
        use = {"rule": "use", "conclusion": eq(I(Z, two, "u", S(v("u"))), two),
               "clause": 0, "term": two, "premise": truth()}
        scoped["retained_clause_specialization"] = {"scope": set(), "context": (clause,), "proof": use}
        return positive, scoped


def packet(proof):
    return {"goal": copy.deepcopy(proof["conclusion"]), "proof": copy.deepcopy(proof)}


def write_cases(directory):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    closed, scoped = Builder().main_cases()
    for label, proof in closed.items():
        (directory / (label + ".json")).write_text(json.dumps(packet(proof), indent=2) + "\n")
    for label, case in scoped.items():
        obj = {**case, "scope": sorted(case["scope"]), "goal": case["proof"]["conclusion"]}
        (directory / (label + "_scoped.json")).write_text(json.dumps(obj, indent=2) + "\n")
    return closed, scoped


if __name__ == "__main__":
    write_cases(Path(__file__).resolve().parent / "fixtures")
