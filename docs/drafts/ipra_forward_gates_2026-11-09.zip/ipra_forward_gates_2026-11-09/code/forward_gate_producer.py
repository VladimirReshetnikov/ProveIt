"""Untrusted full proof producer for predecessor-free forward-gate induction.

No checker is imported.  Every derived operation expands to comp/use/gi/de/tr.
The emitted proof contains no derived-rule tags or external theorem calls.
The main example proves I(3,1;u.u)=1 by the general algebraic-gluing
translation of equation induction; its atomic GI step genuinely uses its IH.
The companion scoped fixture uses arbitrary counter and seed parameters.

This is an untrusted finite certificate producer, not a verified compiler.
External input families must avoid the reserved fg_ namespace and provide
correctly scoped base/step proofs; all emitted trees are checked separately.
"""

from copy import deepcopy
import json
from pathlib import Path


def V(name):
    return ["$", name]


def Z():
    return ["0"]


def S(t):
    return ["S", deepcopy(t)]


def Eq(s, t):
    return ["=", deepcopy(s), deepcopy(t)]


def I(n, a, u, h):
    return ["I", deepcopy(n), deepcopy(a), u, deepcopy(h)]


def D(x, y, body):
    return ["D", x, y, deepcopy(body)]


def numeral(n):
    result = Z()
    for _ in range(n):
        result = S(result)
    return result


def lift(proof, boundary, amount=1):
    """Insert unused retained clauses at one ambient context boundary."""
    result = deepcopy(proof)

    def visit(node):
        if node["rule"] == "use" and node["clause"] >= boundary:
            node["clause"] += amount
        for key in ("premise", "major", "equality", "before"):
            if key in node:
                visit(node[key])

    visit(result)
    return result


class Builder:
    def __init__(self):
        self.serial = 0

    def fresh(self, prefix="v"):
        self.serial += 1
        return "fg_" + prefix + "_" + str(self.serial)

    def C(self, n, a, b):
        return I(n, a, self.fresh("const"), b)

    def gate(self, n, equation):
        assert equation[0] == "="
        return Eq(self.C(n, Z(), equation[1]), self.C(n, Z(), equation[2]))

    def comp(self, term, result):
        return {"rule": "comp", "conclusion": Eq(term, result)}

    def truth(self):
        return self.comp(I(Z(), Z(), "_truth", Z()), Z())

    def hyp(self, formula, index):
        return {"rule": "use", "conclusion": deepcopy(formula),
                "clause": index, "term": Z(), "premise": self.truth()}

    def transport(self, equality, before, motive):
        hole = self.fresh("transport")
        equation = equality["conclusion"]
        return {"rule": "tr", "conclusion": motive(equation[2]),
                "equality": equality, "before": before,
                "variable": hole, "motive": motive(V(hole))}

    def refl(self, term):
        identity = self.comp(I(Z(), term, self.fresh("unused"), Z()), term)
        return self.transport(identity, deepcopy(identity), lambda h: Eq(h, term))

    def sym(self, proof):
        s = proof["conclusion"][1]
        return self.transport(proof, self.refl(s), lambda h: Eq(h, s))

    def trans(self, left, right):
        s = left["conclusion"][1]
        return self.transport(right, left, lambda h: Eq(s, h))

    def congruence(self, proof, term_motive):
        s = term_motive(proof["conclusion"][1])
        return self.transport(proof, self.refl(s),
                              lambda h: Eq(s, term_motive(h)))

    def gate_zero(self, equation):
        result = self.gate(Z(), equation)
        left, right = result[1:]
        return self.trans(self.comp(left, Z()), self.sym(self.comp(right, Z())))

    def gate_successor(self, proof, predecessor):
        equation = proof["conclusion"]
        result = self.gate(S(predecessor), equation)
        left, right = result[1:]
        left_to_s = self.comp(left, equation[1])
        right_to_t = self.comp(right, equation[2])
        return self.trans(self.trans(left_to_s, proof), self.sym(right_to_t))

    def ungate_successor(self, proof):
        left, right = proof["conclusion"][1:]
        assert left[0] == right[0] == "I"
        assert left[1][0] == right[1][0] == "S"
        # A constant update's one-step result is its unchanged payload.
        left_to_s = self.comp(left, left[4])
        right_to_t = self.comp(right, right[4])
        return self.trans(self.trans(self.sym(left_to_s), proof), right_to_t)

    def pad_formula(self, equation):
        x, y = self.fresh("pad_witness"), self.fresh("pad_counter")
        return D(x, y, self.gate(V(y), equation))

    def pad(self, proof, context_length):
        formula = self.pad_formula(proof["conclusion"])
        eigen = self.fresh("pad_step")
        premise = self.gate_successor(lift(proof, context_length), V(eigen))
        return {"rule": "gi", "conclusion": formula, "witness": Z(),
                "eigen": eigen, "premise": premise}

    def unpad(self, proof, context_length):
        major = proof["conclusion"]
        assert major[0] == "D" and major[3][0] == "="
        # All producers of padding use fresh, unused witness and counter
        # variables in the payload equation, so opening leaves payloads intact.
        body = major[3]
        equation = Eq(body[1][4], body[2][4])
        target = self.gate(numeral(1), equation)
        use = {"rule": "use", "conclusion": target,
               "clause": context_length, "term": numeral(1),
               "premise": self.gate_zero(equation)}
        minor = self.ungate_successor(use)
        return {"rule": "de", "conclusion": equation, "major": proof,
                "eigen": self.fresh("pad_open"), "premise": minor}

    def equation_cases(self, family, target, base, successor_proof, context_length):
        """Expand NC for equations using compound padding, never induction.

        family(q) returns an equation.  base proves family(0) in the given
        context. successor_proof(q, length) constructs family(Sq) in a
        context extended by an unused outer paired-introduction base.
        """
        x, y = self.fresh("cases_witness"), self.fresh("cases_counter")
        matrix = self.pad_formula(family(V(y)))
        goal = D(x, y, matrix)
        eigen = self.fresh("cases_step")
        step = successor_proof(V(eigen), context_length + 1)
        major = {"rule": "gi", "conclusion": goal, "witness": Z(),
                 "eigen": eigen,
                 "premise": self.pad(step, context_length + 1)}
        # In DE's continuation the outer clause is at context_length.
        padded_base = self.pad(lift(base, context_length), context_length + 1)
        use = {"rule": "use", "conclusion": self.pad_formula(family(target)),
               "clause": context_length, "term": deepcopy(target),
               "premise": padded_base}
        minor = self.unpad(use, context_length + 1)
        return {"rule": "de", "conclusion": family(target), "major": major,
                "eigen": self.fresh("cases_open"), "premise": minor}

    def unwrap_gate(self, gated, family, base, target, context_length):
        """Prove E(target) from G_target E(target) and a proof of E(0).

        Algebraic gluing uses two explicitly expanded equation-NC proofs.
        It uses neither disjunction nor coverage nor any prior induction.
        """
        seed = family(Z())[1]

        def lifted_term(q, side):
            payload = family(q)[side]
            return self.C(q, seed, self.C(q, Z(), payload))

        def identity_family(side):
            return lambda q: Eq(lifted_term(q, side), family(q)[side])

        def endpoint_successor(side):
            def build(predecessor, unused_length):
                q = S(predecessor)
                expression = lifted_term(q, side)
                inner = expression[4]
                return self.trans(self.comp(expression, inner),
                                  self.comp(inner, family(q)[side]))
            return build

        left_at_zero = lifted_term(Z(), 1)
        left_base = self.comp(left_at_zero, seed)
        right_at_zero = lifted_term(Z(), 2)
        right_base = self.trans(self.comp(right_at_zero, seed), base)
        left_identity = self.equation_cases(identity_family(1), target,
                                             left_base, endpoint_successor(1),
                                             context_length)
        right_identity = self.equation_cases(identity_family(2), target,
                                              right_base, endpoint_successor(2),
                                              context_length)
        lifted_equality = self.congruence(gated, lambda h: self.C(target, seed, h))
        return self.trans(self.trans(self.sym(left_identity), lifted_equality),
                          right_identity)

    def equation_induction(self, family, target, base, step, context_length=0):
        """Translate one equation-induction application into primitive rules.

        step(predecessor, proof_of_E_predecessor, context_length) returns an
        explicit proof of E(S predecessor), using the supplied proof as needed.
        """
        x, y = self.fresh("induction_witness"), self.fresh("induction_counter")
        matrix = self.gate(V(y), family(V(y)))
        major_formula = D(x, y, matrix)
        eigen = self.fresh("induction_step")
        z = V(eigen)
        retained = self.gate(z, family(z))
        ih = self.hyp(retained, context_length)
        recovered = self.unwrap_gate(ih, family, lift(base, context_length),
                                     z, context_length + 1)
        successor = step(z, recovered, context_length + 1)
        major = {"rule": "gi", "conclusion": major_formula, "witness": Z(),
                 "eigen": eigen, "premise": self.gate_successor(successor, z)}
        target_gate = self.gate(target, family(target))
        use = {"rule": "use", "conclusion": target_gate,
               "clause": context_length, "term": deepcopy(target),
               "premise": self.gate_zero(family(Z()))}
        minor = self.unwrap_gate(use, family, lift(base, context_length),
                                target, context_length + 1)
        result = {"rule": "de", "conclusion": family(target), "major": major,
                  "eigen": self.fresh("induction_open"), "premise": minor}
        return result


def example(seed=1, target=3):
    builder = Builder()
    seed_term = numeral(seed)

    def value(n):
        return I(n, seed_term, "identity_state", V("identity_state"))

    def family(n):
        return Eq(value(n), seed_term)

    base = builder.comp(value(Z()), seed_term)

    def step(n, ih, unused_length):
        return builder.trans(builder.comp(value(S(n)), value(n)), ih)

    proof = builder.equation_induction(family, numeral(target), base, step)
    return {"goal": deepcopy(proof["conclusion"]), "proof": proof}


def symbolic_example():
    """An open derivation at arbitrary model elements, for the checked API.

    It is intentionally a scoped fixture, not a closed public CLI packet.
    """
    builder = Builder()
    seed = V("passive_seed")
    target = V("arbitrary_counter")

    def value(n):
        return I(n, seed, "identity_state", V("identity_state"))

    def family(n):
        return Eq(value(n), seed)

    base = builder.comp(value(Z()), seed)

    def step(n, ih, unused_length):
        return builder.trans(builder.comp(value(S(n)), value(n)), ih)

    proof = builder.equation_induction(family, target, base, step)
    return {"scope": ["passive_seed", "arbitrary_counter"], "context": [],
            "goal": deepcopy(proof["conclusion"]), "proof": proof}


def node_counts(proof):
    counts = {}
    stack = [proof]
    while stack:
        item = stack.pop()
        counts[item["rule"]] = counts.get(item["rule"], 0) + 1
        stack.extend(item[key] for key in ("premise", "major", "equality", "before")
                     if key in item)
    return counts


def generate(destination=None):
    destination = Path(destination or Path(__file__).parent / "fixtures")
    destination.mkdir(parents=True, exist_ok=True)
    packet = example()
    output = destination / "forward_gate_induction.json"
    output.write_text(json.dumps(packet, separators=(",", ":")) + "\n", encoding="utf-8")
    symbolic = symbolic_example()
    symbolic_output = destination / "forward_gate_induction_scoped.json"
    symbolic_output.write_text(json.dumps(symbolic, separators=(",", ":")) + "\n",
                               encoding="utf-8")
    receipt = {"file": output.name, "size_bytes": output.stat().st_size,
               "rule_counts": node_counts(packet["proof"]),
               "scoped_file": symbolic_output.name,
               "scoped_size_bytes": symbolic_output.stat().st_size,
               "scoped_rule_counts": node_counts(symbolic["proof"]),
               "scoped_interface": "Checker.check with the supplied explicit scope and empty context",
               "primitive_rules_only": True,
               "uses_algebraic_gluing": True,
               "uses_disjunction_or_coverage": False,
               "claim": "Finite expanded induction translation; not a mechanized universal metatheorem."}
    (destination / "forward_gate_induction_receipt.json").write_text(
        json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    return receipt


if __name__ == "__main__":
    print(json.dumps(generate(), indent=2))
