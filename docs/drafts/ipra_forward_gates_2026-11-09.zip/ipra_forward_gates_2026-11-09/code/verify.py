"""Finite validation and measurement, outside the trusted acceptance program."""
import copy
import hashlib
import io
import json
from pathlib import Path
import platform
import random
import subprocess
import sys

import checker
import fixtures
import forward_gate_producer
from source_measure import metrics

ROOT = Path(__file__).resolve().parent
RECEIPT = {"python": platform.python_version(), "checks": [], "counts": {}}


def record(category, label, passed, detail=None):
    if not passed:
        raise RuntimeError(category + ": " + label + ": " + str(detail))
    RECEIPT["counts"][category] = RECEIPT["counts"].get(category, 0) + 1
    RECEIPT["checks"].append({"category": category, "label": label, "passed": True,
                              "detail": detail})


def rejection(label, packet):
    try:
        checker.check_packet(packet)
    except Exception as error:
        record("negative_packets", label, True, type(error).__name__ + ": " + str(error))
        return
    record("negative_packets", label, False, "accepted")


def negative_cases(closed):
    p = fixtures.packet(closed["iterator_zero"])
    cases = {}
    q = copy.deepcopy(p); q["extra"] = 0; cases["extra_packet_field"] = q
    q = copy.deepcopy(p); q["declarations"] = []; cases["forbidden_declarations"] = q
    q = copy.deepcopy(p); q["proof"]["rule"] = "axiom"; cases["unknown_rule"] = q
    q = copy.deepcopy(p); q["proof"]["extra"] = None; cases["extra_proof_field"] = q
    q = copy.deepcopy(p); q["proof"]["conclusion"] = fixtures.eq(fixtures.Z, fixtures.S(fixtures.Z)); cases["false_goal"] = q
    for label, term in [
            ("zero_arity", ["0", ["0"]]),
            ("successor_arity", ["S"]),
            ("unknown_term", ["plus", ["0"], ["0"]]),
            ("free_variable", ["$", "future"]),
            ("boolean_state_name", ["I", ["0"], ["0"], True, ["0"]]),
            ("state_does_not_bind_counter", ["I", ["$", "u"], ["0"], "u", ["0"]]),
            ("state_does_not_bind_seed", ["I", ["0"], ["$", "u"], "u", ["0"]]),
            ("malformed_array", []),
            ("boolean_term", True)]:
        cases[label] = fixtures.packet({"rule": "comp", "conclusion": ["=", term, ["0"]]})
    cases["reflexivity_is_not_computation"] = fixtures.packet(fixtures.comp(fixtures.Z, fixtures.Z))
    cases["two_computations_are_not_one"] = fixtures.packet(fixtures.comp(
        fixtures.I(fixtures.S(fixtures.Z), fixtures.Z, "u", fixtures.S(fixtures.v("u"))),
        fixtures.S(fixtures.Z)))
    for label, body in [
            ("ungated_atomic_binder", fixtures.eq(fixtures.Z, fixtures.Z)),
            ("wrong_gate_control", fixtures.gate(fixtures.v("x"), fixtures.Z, fixtures.Z)),
            ("nonzero_gate_seed", fixtures.eq(
                fixtures.C(fixtures.v("y"), fixtures.S(fixtures.Z), fixtures.Z),
                fixtures.C(fixtures.v("y"), fixtures.Z, fixtures.Z))),
            ("state_dependent_gate_update", fixtures.eq(
                fixtures.I(fixtures.v("y"), fixtures.Z, "u", fixtures.v("u")),
                fixtures.C(fixtures.v("y"), fixtures.Z, fixtures.Z)))]:
        goal = fixtures.D("x", "y", body)
        proof = fixtures.gi(goal, fixtures.Z, "z", fixtures.truth())
        cases[label] = fixtures.packet(proof)
    q = fixtures.packet(closed["atomic_gi"]); q["proof"]["mode"] = "ind"; cases["obsolete_choice_mode"] = q
    q = fixtures.packet(closed["compound_base_and_elimination"])
    q["proof"]["major"]["premise"]["clause"] = True
    cases["boolean_clause_index"] = q
    q = fixtures.packet(closed["compound_base_and_elimination"])
    q["proof"]["major"]["premise"]["clause"] = 1
    cases["out_of_range_clause"] = q
    q = fixtures.packet(closed["atomic_gi"]); q["proof"]["witness"] = fixtures.v("future")
    cases["escaping_witness"] = q
    q = fixtures.packet(closed["atomic_gi"]); q["proof"]["eigen"] = "not a name"
    cases["bad_eigen_name"] = q
    return cases


def numeric_value(term, valuation):
    head = term[0]
    if head == "$": return valuation[term[1]]
    if head == "0": return 0
    if head == "S": return numeric_value(term[1], valuation) + 1
    _, counter, seed, state, update = term
    count = numeric_value(counter, valuation)
    if count > 100:
        raise OverflowError("finite test limit")
    result = numeric_value(seed, valuation)
    for _ in range(count):
        result = numeric_value(update, {**valuation, state: result})
    return result


def substitution_checks():
    rng = random.Random(11409)
    def term(depth, scope):
        if depth == 0:
            return fixtures.v(rng.choice(sorted(scope))) if rng.randrange(2) else fixtures.Z
        tag = rng.randrange(4)
        if tag < 2: return term(0, scope)
        if tag == 2: return fixtures.S(term(depth - 1, scope))
        state = rng.choice(["a", "b", "u", "v"])
        return fixtures.I(term(depth - 1, scope), term(depth - 1, scope), state,
                          term(depth - 1, scope | {state}))
    mapping = {"a": fixtures.S(fixtures.v("b")),
               "b": fixtures.I(fixtures.S(fixtures.Z), fixtures.S(fixtures.v("a")),
                                 "a", fixtures.S(fixtures.v("a")))}
    for index in range(70):
        source = term(3, {"a", "b"})
        target = checker.subst_term(source, mapping)
        checker.Checker().term(target, {"a", "b"})
        for a in range(3):
            for b in range(3):
                environment = {"a": a, "b": b}
                replaced = {key: numeric_value(value, environment) for key, value in mapping.items()}
                old = numeric_value(source, replaced)
                new = numeric_value(target, environment)
                record("substitution_evaluation", f"{index}:{a}:{b}", old == new)
    source = fixtures.D("a", "b", fixtures.gate(fixtures.v("b"),
                         fixtures.v("parameter"), fixtures.I(fixtures.Z, fixtures.v("a"), "b", fixtures.v("b"))))
    for index, image in enumerate([fixtures.v("a"), fixtures.v("b"), fixtures.S(fixtures.v("a")),
                                  fixtures.I(fixtures.Z, fixtures.v("b"), "a", fixtures.v("a"))]):
        result = checker.subst_formula(source, {"parameter": image})
        checker.Checker().formula(result, {"a", "b"})
        record("gate_substitution", str(index), checker.fv_formula(result) == checker.fv_term(image))


def main():
    closed, scoped = fixtures.write_cases(ROOT / "fixtures")
    RECEIPT["forward_gate_production"] = forward_gate_producer.generate(ROOT / "fixtures")
    forward = forward_gate_producer.example()
    closed["forward_gate_induction"] = forward["proof"]
    symbolic = forward_gate_producer.symbolic_example()
    scoped["forward_gate_induction_arbitrary_parameters"] = {
        "scope": set(symbolic["scope"]), "context": symbolic["context"], "proof": symbolic["proof"]}
    for label, proof in closed.items():
        receipt = checker.check_packet(fixtures.packet(proof))
        record("positive_packets", label, receipt["accepted"], receipt)
    for label, case in scoped.items():
        receipt = checker.Checker().check(case["proof"], context=case["context"], scope=case["scope"])
        record("positive_scoped", label, receipt["accepted"], receipt)
    negatives = negative_cases(closed)
    # Remove the actual main induction-hypothesis reference while retaining its
    # asserted equation: it is not a computation axiom at the fresh parameter.
    bad = copy.deepcopy(forward)
    induction_eigen = bad["proof"]["major"]["eigen"]
    stack = [bad["proof"]["major"]]
    replaced = False
    while stack:
        node = stack.pop()
        if (node["rule"] == "use" and node["clause"] == 0
                and node["conclusion"][0] == "="
                and node["conclusion"][1][0] == "I"
                and node["conclusion"][1][1] == fixtures.v(induction_eigen)):
            conclusion = node["conclusion"]
            node.clear(); node.update({"rule": "comp", "conclusion": conclusion})
            replaced = True
            break
        stack.extend(node[key] for key in ("premise", "major", "equality", "before") if key in node)
    record("dependency_setup", "located_main_atomic_IH", replaced)
    negatives["forward_gate_IH_replaced_by_computation"] = bad
    for label, mutate in [
            ("forward_wrong_witness", lambda p: p["proof"]["major"].update(witness=["$", "outside"])),
            ("forward_wrong_eigen", lambda p: p["proof"]["major"].update(eigen="different_eigen")),
            ("forward_wrong_result", lambda p: p["proof"].update(conclusion=fixtures.eq(fixtures.Z, fixtures.S(fixtures.Z))))]:
        bad = copy.deepcopy(forward); mutate(bad); negatives[label] = bad
    for label, packet in negatives.items():
        rejection(label, packet)
    for label in ("transport_avoids_iterator_capture", "transport_avoids_paired_capture"):
        bad = copy.deepcopy(scoped[label])
        conclusion = bad["proof"]["conclusion"]
        if label.endswith("iterator_capture"):
            conclusion[1][3] = conclusion[2][3] = "z"
        else:
            conclusion[1] = "z"
        try:
            checker.Checker().check(bad["proof"], scope=bad["scope"])
        except checker.ProofError:
            record("negative_scoped", label + "_captured", True)
        else:
            record("negative_scoped", label + "_captured", False)
    bad = copy.deepcopy(closed["atomic_gi"])
    try:
        checker.Checker().check(bad, scope={bad["eigen"]})
    except checker.ProofError:
        record("negative_scoped", "reused_eigenvariable", True)
    else:
        record("negative_scoped", "reused_eigenvariable", False)
    for label, raw in [("duplicate_keys", '{"goal":0,"goal":1,"proof":{}}'),
                       ("nan", '{"goal":NaN,"proof":{}}'),
                       ("infinity", '{"goal":Infinity,"proof":{}}')]:
        try:
            checker.load_packet(io.StringIO(raw))
        except checker.ProofError:
            record("parser", label, True)
        else:
            record("parser", label, False)
    substitution_checks()
    cli_packets = [(name, fixtures.packet(proof), True) for name, proof in closed.items()]
    cli_packets += [(name, packet, False) for name, packet in negatives.items()]
    for optimized in (False, True):
        command = [sys.executable] + (["-O"] if optimized else []) + [str(ROOT / "checker.py")]
        for name, packet, accept in cli_packets:
            result = subprocess.run(command, input=json.dumps(packet), text=True,
                                    capture_output=True, timeout=30)
            good = (result.returncode == 0 and result.stdout == "ACCEPT\n") if accept else (
                result.returncode == 1 and result.stdout == "REJECT\n")
            record("cli", ("optimized:" if optimized else "normal:") + name, good,
                   {"exit_code": result.returncode, "stdout": result.stdout.strip()})
    RECEIPT["checker_measurement"] = metrics(ROOT / "checker.py")
    RECEIPT["status"] = "all finite checks passed"
    RECEIPT["limits"] = ["Finite checks are not universal metatheory proofs.",
                          "The complete scalar arithmetic bootstrap is written, not replayed here.",
                          "The small atomic_hypothesis_consumed example uses its IH but does not need it mathematically; the separate expanded forward-gate derivation has a checked IH-deletion control."]
    (ROOT / "validation.json").write_text(json.dumps(RECEIPT, indent=2) + "\n")
    print(json.dumps({"counts": RECEIPT["counts"], "measurement": RECEIPT["checker_measurement"],
                      "status": RECEIPT["status"]}, indent=2))


if __name__ == "__main__":
    main()
