SCALAR GATED iPRA: READABLE CHECKER AND EXPANDED CERTIFICATES
==========================================================

This folder implements the complete scalar-gated native calculus described in
the accompanying mathematical report. It is an independently usable proof
checker, not only a validator for the one supplied example.

    python checker.py < fixtures/forward_gate_induction.json
    python verify.py

The first command accepts the explicit 214-node finite derivation of

    I(3,1;u.u) = 1.

A second fixture, forward_gate_induction_scoped.json, is an OPEN derivation of

    I(arbitrary_counter, passive_seed;u.u) = passive_seed

for arbitrary numerical parameters. verify.py checks it through Checker.check
with exactly the two displayed free parameters and an empty retained context.
It is not a closed packet for the standalone command-line interface.

Both certificates expand the predecessor-free forward-gate induction argument
into only the five primitive rule tags comp/use/gi/de/tr. The certificate has
214 inference nodes, maximum depth 16, and rule counts

    comp: 96, tr: 86, gi: 13, de: 9, use: 10.

No predecessor, pairing, primitive-recursive declaration, derived induction
rule, coverage rule, or disjunction rule is imported by the checker. The proof
producer expands equation cases and algebraic gluing into primitive rules.
Replacing the main atomic induction-hypothesis Use by a computation proof of
the same equation is rejected. This checks the actual dependency in the emitted
proof; it does not assert that its fixed-numeral conclusion has no other proof.

Validation
----------

The reproduced validation.json records:

  8 positive closed derivations;
  5 positive scoped derivations;
  29 rejected closed malformed/incorrect packets;
  3 rejected scoped capture/freshness controls;
  3 strict-JSON parser controls;
  630 independent finite numerical evaluation checks of simultaneous
      capture-free substitution;
  4 grammar-preservation substitution checks for gated formulas;
  74 standalone runs, split equally between normal and optimized Python;
  1 setup check locating the main induction-hypothesis reference.

All checks passed on CPython 3.12.14. The substitution evaluations range over
70 generated terms, with all nine valuations of two parameters in {0,1,2}.
They test implementation behavior; the universal substitution and
bi-interpretation metatheorems remain mathematical proofs in the report.

Complete checker measurements
-----------------------------

Under the unchanged corpus normalizer, checker.py has:

  2755 normalized Python tokens;
  3014 AST nodes;
  12653 normalized UTF-8 bytes;
  14150 raw bytes, including documentation;
  SHA-256 f969aba6d5563a36a727eec7c3a1c993e166b63f329223bc61d900761d6eb8df.

The complete program is counted, including input, output, rejection, syntax,
scopes, alpha-equivalence, capture avoidance, and every inference rule. There
is no claim that this readable implementation beats the current compact corpus
frontier of 299 tokens / 340 AST nodes / 815 normalized bytes. Those frontier
coordinates are themselves attained by different programs.

Files
-----

checker.py                  complete standalone acceptance program
FORMAT.txt                  exact syntax, rules, scoping, and packet interface
fixtures.py                 independent small proof producers
forward_gate_producer.py    expanded forward-gate certificate producer
verify.py                   finite tests and source measurements
validation.json             complete finite validation receipt
fixtures/                   closed and explicitly scoped certificates
source_measure.py           unchanged inherited measurement functions
ATTRIBUTION.txt              contribution and source boundary
ATTRIBUTION-inherited.txt    upstream source attribution
LICENSE-inherited.txt        inherited MIT No Attribution License

The producer and tests are untrusted: checker.py imports none of them. There is
no executable assertion in the acceptance logic. All data supplied to the
standalone checker are parsed as JSON, never executed as Python code.
