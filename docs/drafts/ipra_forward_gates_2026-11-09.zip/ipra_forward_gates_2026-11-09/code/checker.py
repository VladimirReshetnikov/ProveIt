"""Standalone proof checker for scalar gated iPRA.

Numerical syntax: 0, S, variables, and initialized scalar iteration I.
Formula syntax: equality and paired D; every immediate atomic D matrix
must be a literal constant-update zero gate in its second bound variable.
Rules: I0/IS computation, clause Use, deterministic GI, DE, and transport.

Adapted from Choice-DI code/readable/checker.py in the pinned ProveIt
corpus. This version adds numerical-binder capture avoidance and removes
all primitive-recursive declarations. See ATTRIBUTION.txt and FORMAT.txt.
Only Python's standard json module is imported by the acceptance program.
"""
import json


class ProofError(ValueError):
    """Invalid syntax, scope, inference, or input packet."""


def require(condition, message):
    if not condition:
        raise ProofError(message)


def fields(value, names, description):
    require(type(value) is dict, description + " must be an object")
    require(set(value) == set(names), description + " has incorrect fields")


def name(value):
    return type(value) is str and value.isidentifier()


def variable(identifier):
    return ["$", identifier]


def zero():
    return ["0"]


def successor(term):
    return ["S", term]


def truth_formula():
    return ["=", ["I", zero(), zero(), "_truth", zero()], zero()]


def fv_term(term):
    head = term[0]
    if head == "$":
        return {term[1]}
    if head == "0":
        return set()
    if head == "S":
        return fv_term(term[1])
    _, counter, seed, state, update = term
    return fv_term(counter) | fv_term(seed) | (fv_term(update) - {state})


def names_term(term):
    if term[0] == "$":
        return {term[1]}
    if term[0] == "0":
        return set()
    if term[0] == "S":
        return names_term(term[1])
    _, counter, seed, state, update = term
    return names_term(counter) | names_term(seed) | names_term(update) | {state}


def fv_formula(formula):
    if formula[0] == "=":
        return fv_term(formula[1]) | fv_term(formula[2])
    return fv_formula(formula[3]) - {formula[1], formula[2]}


def all_names(formula):
    if formula[0] == "=":
        return names_term(formula[1]) | names_term(formula[2])
    return {formula[1], formula[2]} | all_names(formula[3])


def fresh_name(used, prefix="_v"):
    number = 0
    while prefix + str(number) in used:
        number += 1
    return prefix + str(number)


def image_names(mapping):
    result = set()
    for term in mapping.values():
        result.update(fv_term(term))
    return result


def subst_term(term, mapping):
    """Capture-free simultaneous substitution; only I's update binds state."""
    head = term[0]
    if head == "$":
        return mapping.get(term[1], term)
    if head == "0":
        return zero()
    if head == "S":
        return successor(subst_term(term[1], mapping))
    _, counter, seed, state, update = term
    active = {key: value for key, value in mapping.items() if key != state}
    images = image_names(active)
    if state in images:
        fresh = fresh_name(names_term(update) | images | set(active) | {state})
        update = subst_term(update, {state: variable(fresh)})
        state = fresh
    return ["I", subst_term(counter, mapping), subst_term(seed, mapping),
            state, subst_term(update, active)]


def subst_formula(formula, mapping):
    """Simultaneous substitution, including capture avoidance in both sorts."""
    if formula[0] == "=":
        return ["=", subst_term(formula[1], mapping),
                subst_term(formula[2], mapping)]
    x, y, body = formula[1:]
    active = {key: value for key, value in mapping.items() if key not in (x, y)}
    images = image_names(active)
    used = all_names(body) | images | set(active) | {x, y}
    renaming = {}
    binders = [x, y]
    for index, old in enumerate((x, y)):
        if old in images:
            fresh = fresh_name(used)
            used.add(fresh)
            binders[index] = fresh
            renaming[old] = variable(fresh)
    if renaming:
        body = subst_formula(body, renaming)
    return ["D", *binders, subst_formula(body, active)]


def term_key(term, environment=()):
    """Alpha key, with a lexical stack shared by D and I binders."""
    head = term[0]
    if head == "$":
        identifier = term[1]
        if identifier in environment:
            return ("bound", environment[::-1].index(identifier))
        return ("free", identifier)
    if head == "0":
        return ("0",)
    if head == "S":
        return ("S", term_key(term[1], environment))
    _, counter, seed, state, update = term
    return ("I", term_key(counter, environment), term_key(seed, environment),
            term_key(update, environment + (state,)))


def alpha_key(formula, environment=()):
    if formula[0] == "=":
        return ("=", term_key(formula[1], environment),
                term_key(formula[2], environment))
    return ("D", alpha_key(formula[3], environment + tuple(formula[1:3])))


def alpha_equal(left, right):
    return alpha_key(left) == alpha_key(right)


def hypothesis(formula):
    """Ordinary assumption F as the constant clause H -> forall v F."""
    return (truth_formula(), fresh_name(all_names(formula), "_h"), formula)


def is_gate_term(term, control):
    return (term[0] == "I" and term[1] == variable(control)
            and term[2] == zero() and term[3] not in fv_term(term[4]))


class Checker:
    def __init__(self):
        self.nodes = 0
        self.max_depth = 0
        self.rule_counts = {}

    def term(self, value, scope):
        require(type(value) is list and len(value) >= 1,
                "term must be a nonempty array")
        head = value[0]
        require(type(head) is str, "term head must be a string")
        if head == "$":
            require(len(value) == 2 and name(value[1]) and value[1] in scope,
                    "numerical variable is malformed or outside the scope")
        elif head == "0":
            require(len(value) == 1, "zero has incorrect arity")
        elif head == "S":
            require(len(value) == 2, "successor has incorrect arity")
            self.term(value[1], scope)
        else:
            require(head == "I" and len(value) == 5, "unknown numerical constructor")
            _, counter, seed, state, update = value
            require(name(state), "iterator state binder is invalid")
            self.term(counter, scope)
            self.term(seed, scope)
            self.term(update, scope | {state})

    def formula(self, value, scope):
        require(type(value) is list and len(value) >= 1,
                "formula must be a nonempty array")
        head = value[0]
        require(type(head) is str, "formula head must be a string")
        if head == "=":
            require(len(value) == 3, "equation has incorrect arity")
            self.term(value[1], scope)
            self.term(value[2], scope)
        else:
            require(head == "D" and len(value) == 4, "unknown formula constructor")
            x, y, body = value[1:]
            require(name(x) and name(y) and x != y,
                    "paired binders must have distinct names")
            self.formula(body, scope | {x, y})
            if body[0] == "=":
                require(is_gate_term(body[1], y) and is_gate_term(body[2], y),
                        "an atomic paired matrix must have both literal zero gates")

    def computation(self, term):
        """One I0 or IS equation, never recursive evaluation."""
        require(term[0] == "I", "only an iterator has a computation axiom")
        _, counter, seed, state, update = term
        if counter == zero():
            return seed
        require(counter[0] == "S", "iterator counter is neither zero nor successor")
        previous = ["I", counter[1], seed, state, update]
        return subst_term(update, {state: previous})

    def computes(self, formula):
        if formula[0] != "=":
            return False
        try:
            return term_key(self.computation(formula[1])) == term_key(formula[2])
        except ProofError:
            return False

    def check(self, proof, context=(), scope=frozenset(), expected=None):
        require(type(scope) in (set, frozenset) and all(name(item) for item in scope),
                "scope must be a set of variable names")
        scope = set(scope)
        require(type(context) in (tuple, list), "context must be a sequence of clauses")
        for clause in context:
            require(type(clause) in (tuple, list) and len(clause) == 3,
                    "context entry must be an antecedent, binder, and body")
            antecedent, binder, body = clause
            require(name(binder), "clause binder is invalid")
            self.formula(antecedent, scope)
            require(binder not in fv_formula(antecedent),
                    "clause binder occurs in its antecedent")
            self.formula(body, scope | {binder})
        if expected is not None:
            self.formula(expected, scope)
        self.nodes = self.max_depth = 0
        self.rule_counts = {}
        self._check(proof, tuple(context), scope, expected, 0)
        return {"accepted": True, "proof_nodes": self.nodes,
                "maximum_depth": self.max_depth, "rule_counts": dict(self.rule_counts)}

    def _check(self, proof, context, scope, expected, depth):
        require(type(proof) is dict, "proof node must be an object")
        rule = proof.get("rule")
        required = {
            "comp": ("rule", "conclusion"),
            "use": ("rule", "conclusion", "clause", "term", "premise"),
            "gi": ("rule", "conclusion", "witness", "eigen", "premise"),
            "de": ("rule", "conclusion", "major", "eigen", "premise"),
            "tr": ("rule", "conclusion", "equality", "before", "variable", "motive"),
        }
        require(type(rule) is str and rule in required, "unknown inference rule")
        fields(proof, required[rule], "proof node")
        conclusion = proof["conclusion"]
        self.formula(conclusion, scope)
        if expected is not None:
            require(alpha_equal(conclusion, expected), "premise has the wrong conclusion")
        self.nodes += 1
        self.max_depth = max(self.max_depth, depth)
        self.rule_counts[rule] = self.rule_counts.get(rule, 0) + 1

        if rule == "comp":
            require(self.computes(conclusion), "conclusion is not one computation equation")
            return
        if rule == "use":
            index = proof["clause"]
            require(type(index) is int and 0 <= index < len(context),
                    "clause index is outside the context")
            argument = proof["term"]
            self.term(argument, scope)
            antecedent, binder, body = context[index]
            target = subst_formula(body, {binder: argument})
            require(alpha_equal(conclusion, target), "clause specialization has wrong conclusion")
            self._check(proof["premise"], context, scope, antecedent, depth + 1)
            return
        if rule == "gi":
            require(conclusion[0] == "D", "paired introduction needs a paired conclusion")
            witness, eigen = proof["witness"], proof["eigen"]
            self.term(witness, scope)
            require(name(eigen) and eigen not in scope, "introduction eigenvariable is not fresh")
            x, y, body = conclusion[1:]
            control = variable(eigen) if body[0] == "=" else zero()
            retained = subst_formula(body, {x: witness, y: control})
            step = subst_formula(body, {x: witness, y: successor(variable(eigen))})
            self._check(proof["premise"], context + (hypothesis(retained),),
                        scope | {eigen}, step, depth + 1)
            return
        if rule == "de":
            major = proof["major"]
            self._check(major, context, scope, None, depth + 1)
            paired = major["conclusion"]
            require(paired[0] == "D", "paired elimination needs a paired major")
            eigen = proof["eigen"]
            require(name(eigen) and eigen not in scope, "elimination eigenvariable is not fresh")
            x, y, body = paired[1:]
            binder = fresh_name(all_names(body) | scope | {eigen}, "_b")
            base = subst_formula(body, {x: variable(eigen), y: zero()})
            opened = subst_formula(body, {x: variable(eigen), y: variable(binder)})
            self._check(proof["premise"], context + ((base, binder, opened),),
                        scope | {eigen}, conclusion, depth + 1)
            return
        equality = proof["equality"]
        self._check(equality, context, scope, None, depth + 1)
        equation = equality["conclusion"]
        require(equation[0] == "=", "transport major must be an equation")
        placeholder = proof["variable"]
        require(name(placeholder) and placeholder not in scope,
                "transport placeholder must be fresh")
        motive = proof["motive"]
        self.formula(motive, scope | {placeholder})
        old = subst_formula(motive, {placeholder: equation[1]})
        target = subst_formula(motive, {placeholder: equation[2]})
        require(alpha_equal(conclusion, target), "transport has wrong conclusion")
        self._check(proof["before"], context, scope, old, depth + 1)


def check_packet(packet):
    fields(packet, ("goal", "proof"), "proof packet")
    checker = Checker()
    return checker.check(packet["proof"], expected=packet["goal"])


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON object key")
        result[key] = value
    return result


def reject_constant(value):
    raise ProofError("nonfinite JSON numeric constant: " + value)


def load_packet(stream):
    return json.load(stream, object_pairs_hook=unique_object,
                     parse_constant=reject_constant)


if __name__ == "__main__":
    try:
        with open(0, encoding="utf-8") as stream:
            check_packet(load_packet(stream))
        print("ACCEPT")
    except Exception:
        print("REJECT")
        raise SystemExit(1)
