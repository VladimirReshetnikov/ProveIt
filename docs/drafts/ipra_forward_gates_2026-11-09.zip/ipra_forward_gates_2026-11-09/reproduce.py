"""Replay the delivered certificates and whole-program source measurements."""
from pathlib import Path
import importlib.util
import json
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
subprocess.run([sys.executable, str(ROOT / "code/verify.py")], cwd=ROOT, check=True)
spec = importlib.util.spec_from_file_location("measure", ROOT / "comparison/source_measure.py")
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
rows = []
for relative in ("comparison/choice_tokens.py", "comparison/choice_structure.py",
                 "comparison/choice_bytes.py", "code/checker.py"):
    path = ROOT / relative
    rows.append({"file": relative, **measure.metrics(path)})
result = {"python": platform.python_version(), "programs": rows}
(ROOT / "evidence/reproduced_measurements.json").write_text(
    json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))
