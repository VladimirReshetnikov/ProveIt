# Independent review of the scalar-gated presentation

Reviewed on 2026-11-09. This is a written mathematical review, not a Lean or Rocq verification.

## Result

I found no mathematical gap in the predecessor-free forward-gate induction argument, in the inherited internal scalar predecessor construction, or in the subsequent equality-reflection and primitive-recursion compilation arguments. The combination establishes a complete scalar-gated presentation, subject to spelling out the inherited gate-preserving formula operations and all four primitive inference patterns. It does not by itself establish a complete-checker size improvement.

## Exact dependencies checked

1. **Before numerical induction:** scalar computation yields the constant-update selector. Gate-preserving syntactic operations and binder congruence yield padding. Padding yields numerical cases for arbitrary native formulas. Implication, conjunction, existence, and disjunction are obtained without predecessor or induction. Pointwise numerical coverage is then derived by numerical cases, before constructing the universal-quantifier elimination rule. This order avoids a logical circularity.

2. **Universal quantification:** the new macro `A(0) ∧ D G_z A(z)` supplies its zero instance separately and its gated arbitrary instance through the paired clause. Pointwise coverage removes the gate at a successor. Its introduction uses substitution in a proof with a fresh free variable. It does not require induction or predecessor.

3. **Forward-gate equation induction:** for an arbitrary equation `E(y)`, the matrix `B(y)=L_y(E(y))` has a computationally true zero instance. Under the single retained progress assumption `B(z)`, numerical coverage of `z` supplies `E(z)`: use the given base when `z=0`, and gate removal when `z=S v`. The supplied original induction-step derivation then yields `B(S z)`. After gated introduction and paired elimination yield `B(t)`, a second coverage split supplies `E(t)`. Every use of the given base remains in the original retained context. The progress assumption is always a literal equation.

4. **Scalar predecessor:** all helpers in `scalar_predecessor.tex` are finite scalar terms. Addition's commutative-monoid laws do not require successor cancellation. Boolean range of `N` follows from cases and the range of `Z`, not induction on a disjunction. The ramp identities, factor-map identities, iterator rotation/scaling, comparator equations, saturated-shift equation, and diagonal identities are each legitimate literal-equation inductions. In particular the equation `W(S t,S m)=S W(t,m)` is proved with `m` fixed and universally available before the diagonal substitution `t=m=n`. The final comparison of `V(t,m)` with `W(t,m)` avoids assuming an iterator-body extensionality rule.

5. **Stronger coverage after predecessor:** pointwise `x=0 ∨ ∃v x=S v` and `P(S v)=v` give `x=0 ∨ x=S(P x)` by existential elimination and equality transport. This is the exact coverage form used by the equality-reflection appendix. It is useful to state this passage explicitly.

6. **Equality reflection before general primitive recursion:** the proof uses only `P`, the selector, addition, and `d(x,y)=I(y,x;u.P u)`. The source appendix explicitly explains this scalar application. No arbitrary primitive-recursion description is needed to construct the faithful equality characteristic. The residual equation `C(sg(d(x,y)),x,y+d(x,y))=x` is a single equation. Its proof does not use induction on implication, disjunction, or a quantified formula. Reflection at residual one then uses the already derived predecessor to cancel successor. The Boolean translation of quantifier-free implications is valid intuitionistically because the numerical characteristic has a proved two-value range.

7. **Pairing and scalar compilation:** the bounded-square-root search uses quantifier-free induction only after quantifier-free induction has been recovered. Its simultaneous invariant is quantifier free with the input `n` fixed. If an update increments, the old strict upper square bound is impossible and the old state must equal the counter; if it does not increment, the new strict upper bound holds. This verifies the stated invariant. At counter `n`, the elementary inequality `n < (n+1)^2` completes the root bracket. The square pairing has internal left/right projections on its image, which is sufficient: surjectivity and replacing the entire domain by a coded subset are unnecessary. The scalar simulation of a primitive recursion maintains the first-coordinate clock by equation induction and obtains both defining equations for the second coordinate.

8. **Numerical round trips:** apply uniqueness with a fresh iteration counter and all original outer variables retained as passive parameters. Only after the universally parameterized equality is established may the original counter term be substituted. This handles native terms whose seed or update has outer parameters also occurring in the counter expression. The external structural induction on each finite description then gives the internal equality of each original operation and its double translation at arbitrary source elements.

9. **Formula round trips:** the reverse PR compiler need not preserve the gate as a literal piece of syntax. The safe proof uses the structural hypothesis at *top-level matrix instances*, ordinary logical congruence of the derived macros, and the native characterization `D B ↔ ∃x(B(x,0)→∀y B(x,y))`. It should not introduce `D` over a double-translated atomic matrix unless its literal gate condition has separately been checked. The supplied proof follows the safe characterization route.

10. **Falsity:** native inconsistency means derivability of `0=1`. A conventional first-order realization must explicitly relate this equation to genuine falsity by `(0=1)→⊥`. Positive decoded equations and rules alone have a singleton model and are a different theory. The proposed section states this distinction and its interpretation uses actual equality throughout.

## Small presentation details

- With `p(n)=I(n,0;u.δ(u))`, the conjunction macro obtains the **right** conjunct by specializing at `1` and the **left** conjunct at `2`, because `p(1)=1` and `p(2)=0`.
- In the scalar theory, replace the old context's projection-computation theorem `H` by a fixed scalar computation theorem such as `I(0,0;u.0)=0`.
- Keep the explicit gate-preserving selector and gate definitions from the gated draft. A naive recursive gate at all atomic leaves would destroy admissibility at existing immediate atomic matrices.
- The inherited equality-reflection appendix discusses full PR descriptions for its general completion theorem, but its introductory scalar specialization is essential to the dependency order here.

## Sources inspected

- `logical_reduction_scalar_gating.tex` (new section)
- `corpus/extracted/ipra_choice_2026-11-09/appendices/scalar_predecessor.tex`
- `corpus/extracted/ipra_choice_2026-11-09/appendices/equality_reflection.tex`
- `corpus/extracted/ipra_choice_2026-11-09/appendices/primitive_recursion.tex`
- `corpus/extracted/ipra_gated_induction_2026-11-09/ipra_gated_induction_2026-11-09/sections/gated_candidate.tex`

These checks validate the written dependency chain and derivations. They do not verify every parser path or malformed certificate of a proposed executable checker, and they are not an absolute minimality argument.
