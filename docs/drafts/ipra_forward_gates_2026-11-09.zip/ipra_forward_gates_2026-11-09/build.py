"""Flatten and compile the complete report with an installed pdflatex."""
from pathlib import Path
import re
import shutil
import subprocess
import json

ROOT = Path(__file__).resolve().parent
if not shutil.which("pdflatex"):
    raise SystemExit("An installed pdflatex toolchain is required.")

def flatten(text):
    return re.sub(r"\\input\{([^}]+)\}",
                  lambda m: flatten((ROOT / (m.group(1) + ".tex")).read_text()),
                  text)

standalone = flatten((ROOT / "report.tex").read_text())
(ROOT / "report_standalone.tex").write_text(standalone, encoding="utf-8")
passes = []
for number in range(1, 4):
    result = subprocess.run(["pdflatex", "-interaction=nonstopmode",
                             "-halt-on-error", "report.tex"],
                            cwd=ROOT, capture_output=True, text=True)
    (ROOT / "evidence" / f"latex_pass_{number}.txt").write_text(
        result.stdout + result.stderr, encoding="utf-8")
    passes.append({"pass": number, "returncode": result.returncode})
    if result.returncode:
        raise SystemExit(result.stdout[-6000:] + result.stderr)
(ROOT / "evidence/build.json").write_text(json.dumps(
    {"passes": passes, "pdf_bytes": (ROOT / "report.pdf").stat().st_size},
    indent=2) + "\n")
print(ROOT / "report.pdf")
