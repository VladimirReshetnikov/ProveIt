ATOMIC TRANSPORT: UNTRUSTED SYMBOLIC PROOF PRODUCER
================================================

These supporting programs are not imported by the measured proof checker.
The checker accepts finite JSON data and rechecks every produced certificate.

producer.py implements four explicit proof transformations:
  * Quotient-free removal of object Q syntax by its vacuous-D presentation.
    Q remains available as an internal elimination clause.
  * General transport through Eq/D formulas by structural induction. The
    compound step uses case DI, backwards transport on the retained base,
    closure specialization, and forwards transport on the successor.
  * Eq/D identity expansion when an ordinary hypothesis is requested as a
    conclusion. An available hypothesis is otherwise used directly only
    as an elimination major.
  * A computation-proved box for a zero numerical witness, whose raw JSON
    form is truthy. The box has a checked equation to zero; no unchecked
    conversion occurs in the measured checker.

The serializer accounts for the exact global order of fresh labels. It
elides a major subproof only when the major formula matches an available
retained context formula. D elimination supplies [] as its unused template
field so the arithmetic motive-arity check can evaluate len(template).

The named AST uses globally fresh binder names. Its substitution operation
therefore does not rename binders on the fly. The fixture producer ensures
this freshness convention. The producer is untrusted; the raw verifier's
scope checks remain the final authority.

inherited_r.py is copied unchanged from the attributed upstream draft.
Its evaluator is unused by the certificate verification workflow and is
not part of the proof checker. The inheritance map and byte hashes are
recorded in ATTRIBUTION.json; upstream LICENSE-inherited.txt is included.

Run:
  python3 tests/verify_symbolic.py code/checker.py

The script regenerates certificates.json and examples/, runs each public
CLI input under normal Python and Python -O, and writes validation.json.
The verifier has a package-relative default kernel path.

The positive tests are symbolic proofs, not numeral-evaluation comparisons.
They include arbitrary DI-bound initializer/counter parameters, the J0/JS
recursion compiler equations, actual literal-equation induction, repeated
internal closure use, a nonvacuous witness, a boxed zero witness, conditional
false-base reasoning, and identity/transport at three compound depths.

The negative direct_compound_transport_rejected packet intentionally uses
an unrestricted primitive transport. It is rejected by the atomic checker
and accepted by the matched unrestricted endpoint checker. It tests that
the primitive rule restriction is actually enforced, although the same
conclusion has a separate valid expanded atomic certificate.

The finite checks are supporting evidence, not a formalization of the
universal soundness/completeness theorem or an exhaustive input audit.
