UNCERTIFIED RESEARCH PROTOTYPES

These files record rejected source-size experiments. They are included only
so the quoted experimental source metrics can be reproduced. They are not
certified proof checkers or part of the delivered theory, and are imported
by neither code/checker.py nor its support workflow. No universal soundness
claim is made for either prototype. Use code/checker.py for delivered proofs.
