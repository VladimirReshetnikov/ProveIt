# Historical novelty correction

The subsequently retrieved archive `ipra_fixed_position_2026-11-09.zip` contains **Equality through one fixed iterator position**. Its own source snapshot is ProveIt commit `aac8216be66b1a6f043fed87a8d515bc5b5d0790`.

The main `report.tex` already contains:

- A statement in Section 1 that other drafts already restrict equality to atomic formulas, individual occurrences, neutral sources, forward orientation, or the left side.
- A corollary deriving arbitrary atomic equation transport from its more restrictive Root and Seed rules.
- Theorem **Full native formula transport**, in Section 3's subsection **The logical lifting uses no hidden induction**. Its D case is exactly the backward-base / old-clause specialization / forward-successor construction used in the current atomic-transport proof. It also covers Q as an object constructor in that older, larger language.

The historical numerical theory changes scalar computation into I0, direct I1, and I2+ in order to derive arbitrary numerical congruence from two fixed rewrite positions. That numerical trade is not needed for the general atomic-to-compound lifting theorem once atomic transport is granted. Thus its different numerical basis does not preserve a novelty claim for the latter lifting argument.

The current elimination-only variant replaces the historical Hyp uses with the independently known identity expansion. The existing elimination-assumptions identity proof already uses only atomic equality motives, and its R adaptation obtains the needed computation from `W(Ss)=s`. These are valid consolidations, but not a new structural principle or significant mathematical breakthrough.

Recommended characterization:

> We re-establish the inherited atomic-to-compound transport reduction in the combined successor-recursion and elimination-only interface, giving the explicit sorted proof and a smaller complete implementation. The logical lifting and its use of case introduction are already present in earlier repository work. The implementation savings combine inherited techniques.

The new complete 714-byte checker, and the matched unrestricted 698-byte checker if independently validated, retain their measured comparison claims. The claim that the atomic-transport theorem itself is new relative to inspected repository work must be removed.

