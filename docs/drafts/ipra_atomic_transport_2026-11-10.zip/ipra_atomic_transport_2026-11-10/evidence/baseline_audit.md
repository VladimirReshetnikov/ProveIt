# Current-draft audit

Snapshot: `VladimirReshetnikov/ProveIt` commit `7bded17cc0122767f86e494fcf256b47fe85c9b8`, the ten top-level archives in `docs/drafts`, retrieved and blob-checked by the parent.

## Independently reproduced complete-checker envelope

All 154 extracted Python file occurrences, comprising 109 distinct byte contents, were parsed and measured with the unmodified corpus normalizer (`ipra_named_specialization/reference/source_measure.py`). There are no nested ZIPs. The recorded runtime is CPython 3.12.14, matching the published comparison runtime.

| Attainer | Normalized tokens | AST nodes | Normalized bytes |
|---|---:|---:|---:|
| `ipra_endpoint_certificates_2026-11-09/code/compact.py` | **287** | 328 | 749 |
| `ipra_named_specialization/code/kernel_tokens.py` | **287** | 331 | 811 |
| `ipra_endpoint_certificates_2026-11-09/reference/matched_legacy_structure.py` | 293 | **323** | 893 |
| `ipra_successor_recursion_2026-11-09/code/kernel.py` | 305 | 351 | **738** |
| `ipra_endpoint_certificates_2026-11-09/code/explicit_failure.py` | 289 | 330 | 739 |

Thus the current coordinate envelope is **287 / 323 / 738**. It is attained by different complete programs. In particular, `matched_legacy_structure.py` is a hidden-in-plain-sight complete control with a smaller AST count than the 326-node named-specialization headline. It imports only standard `json`, contains substitution, context, inference, input, and verdict logic, and must be counted. It does not import a hidden checker.

The programs smaller than any of these thresholds were individually classified: they are build scripts, source-measurement wrappers, archive integrity verifiers, reproduction wrappers, or snapshot downloaders, not complete checkers. All measured source records are in `all_source_metrics.json`. The complete kernel programs have no external trusted helper except common Python/JSON runtime infrastructure. This is an empirical attained upper-bound envelope, never a universal lower bound or a proof of simplestness.

## Current mathematical and implementation contributions

1. **all_starts**: fuses the original zero-start and successor-progression elimination into arbitrary-start elimination. Its own complete checker is 323 / 374 / 974. The fixed-seed obstruction is restricted and explicitly does not rule out all allowed interpretations.
2. **elimination_assumptions**: removes arbitrary hypothesis leaves from the native calculus. Assumptions are available only as elimination majors; explicit identity expansion recovers arbitrary native assumption use in `4+3d(A)` nodes. Complete profiles are 291 / 339 / 846, 298 / 329 / 855, and 300 / 351 / 745. This is a real logical rule reduction; its source savings are modest.
3. **endpoint_certificates**: preserves inherited Choice-DI mathematics, changes certificate fields from major/payload to checked major/source/target/template, and shares equality/closure endpoint handling. Main compact profile is 287 / 328 / 749; explicit-failure profile is 289 / 330 / 739. The matched legacy structure control supplies the current 323-node frontier. This is a certificate/checker implementation improvement, not a new arithmetic theory.
4. **k_iteration**: primitive `K`, application and zero-seeded `J`, with `S(a)=K a`. Equations `(K a)b=a`, `J(K;u.h)=K`, and `J(Kn;u.h)=h[J(n;u.h)/u]`. Whole-domain iPRA equivalence is claimed with full arguments. Readable full checker 1242 / 1406 / 5236; compact alternative 332 / 393 / 1017. Neither beats the current envelope.
5. **named_specialization**: restricts closure specialization to in-scope variables and numeral 1, recovering arbitrary term targets by existentially naming values. Written preservation theorem covers raw native sequents with at most nine added primitive proof nodes. Restricted checker is 337 / 395 / 947. Separate inherited-calculus uniform-continuation profiles are 287 / 331 / 811, 289 / 326 / 840 and 292 / 341 / 753. Their size must not be attributed to the restriction theorem.
6. **scalar_countdown**: three-schema `0,G,J` numerical basis, ordinary coverage/separation, fixed countdown uniqueness, and a fixed sentence `L(b,S(S(a)))=2 -> a=b`. Internal scalar reset yields QF induction; observation levels at least 2 work, levels 0 and 1 are inconsistent. Complete native checker 1754 / 1996 / 6536; no frontier saving.
7. **scalar_feedback**: numerical grammar `0,S,e,I`, no initial comparator equations, and one scalar self-comparison rule. Finite-state scalar iterators calibrate `e` as actual Boolean inequality; induction and PR arithmetic follow. Its own complete checker is 358 / 401 / 941. The separate 762-byte Choice checker is only an inherited-calculus implementation advance.
8. **successor_recursion**: only `0` and counter-aware successor-seeded recursion `R`, with abbreviation `S(a)=R(0,a;u,v.0)`. Equations `R(0,a;u,v.h)=S(a)` and `R(Sn,a;u,v.h)=h[n/u,R(n,a;u,v.h)/v]`. A computation-only predecessor-at-successors `W(n)=R(n,0;u,v.u)` and `C(n,a,b)=W(R(n,a;u,v.S(b)))` compile general primitive recursion without the scalar pairing bootstrap. Own complete checker 305 / 351 / 738, the current byte leader, although its serialized unary successor abbreviation remains charged.
9. **three_schema**: numerical `0,B,J`, `S(x)=B(0,x)`, equations `B(B(0,a),b)=a`, `J(0;u.h)=0`, and `J(Sn;u.h)=h[J(n;u.h)/u]`. Direct selector/predecessor plus one invariant recover initialized iteration. The shipped symbolic checker is equational-fragment only and cannot enter the full-checker comparison.
10. **three_schema (1)**: essentially the same `0,G,J` arithmetic simplification with full native checker 1442 / 1674 / 5323 and matched four-schema checker 1529 / 1772 / 5620. Companion compact controls are inherited scalar Choice-DI programs, separate from the new arithmetic.

## The shared logical baseline

Numerical scalar terms are `0`, `S`, and initialized fixed-update iteration `I(n,a;u.h)`. The update is a fixed finite template with passive parameters; no variable ranges over function codes and there is no universal total evaluator.

Native object formulas are literal equations and paired binders `D_{x,y} B(x,y)`, with ordinary realization

`D_{x,y} B := exists x (B(x,0) -> forall y B(x,y))`.

An internal unary closure `Q_y B` realizes `B(0) -> forall y B(y)`. The compact checker uses Eq/Q/D syntax. Primitive behavior is computation, hypothesis, equality transport, closure specialization, paired elimination, and choice paired introduction. Case introduction retains `B(t,0)` to prove `B(t,Sz)` and permits every formula. Progress introduction retains `B(t,z)` to prove `B(t,Sz)` and is restricted to a **literal equation**. The existential witness and induction eigenparameter have all usual freshness constraints.

The core report derives numerical cases, contextual equation induction, reflexivity and equality reasoning, formula selectors/gates, and all ordinary intuitionistic connectives and quantifiers. The ordinary bridge explicitly includes numerical coverage and `(0=S0)->falsity`; the latter cannot be silently omitted because positive equations alone have singleton models.

The arithmetic bridge is not just standard-numeral agreement. It must obtain predecessor, actual equality reflection, QF characteristic equations, and PR recursion internally over all model elements. Both domains remain the full numerical domain, and both composite isomorphisms have graph `x=y`. Staged function definitions and binder-substitution coherence require internal equation-induction uniqueness arguments.

## Assessment and limits of this audit

I read the complete inherited Choice-DI logical proof, ordinary interpretation bridge, the named-specialization kernel correctness arguments, all ten README status sections, all smallest complete source files, and independently measured every Python source. I did not formally verify the universal arithmetic bridge or run every delivered historical suite. I found no immediate contradiction in the reviewed Choice-DI logical derivations. This should not be described as Lean/Rocq certification or comprehensive peer review.

Any proposed advance should be compared against the combined current envelope, explicitly assign its own complete checker, count all syntax/side-condition code, and distinguish a genuinely new theory from recombination of these existing certificate reductions. A claim of one program below the current three-coordinate envelope requires strictly fewer than 287 tokens, 323 AST nodes, and 738 normalized bytes in that one complete program. Improvements to individual coordinates should be stated separately.
