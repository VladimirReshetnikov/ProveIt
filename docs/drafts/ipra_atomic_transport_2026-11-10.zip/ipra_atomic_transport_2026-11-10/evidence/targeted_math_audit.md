# Targeted bootstrap audit and transport reduction

This note concerns the exact inherited scalar basis `0,S,I` in the current drafts. It is a written mathematical audit, not a proof-assistant certificate.

## 1. The scalar predecessor bootstrap has no detected circularity

I checked the complete files `ipra_named_specialization/reference/scalar_predecessor.tex`, `equality_reflection.tex`, and `primitive_recursion.tex`, not only their summaries.

The available resources before predecessor are scalar iterator computation, equality reasoning, numerical zero/successor cases for arbitrary formulas, and contextual induction on one literal equation. Full quantifier-free induction, pairing, predecessor, successor injectivity, and actual equality decision are not used as inputs.

The proof follows this legitimate dependency chain:

1. `C(n,a,b)=I(n,a;u.b)` gives a zero/successor selector. `Z(n)=C(n,1,0)` has range `{0,1}` by coverage. Addition is scalar successor iteration; its associative and commutative equations use only equation induction.
2. `N(n)=I(n,0;u.Z(u))` has Boolean range by cases on its counter, not induction on a disjunction. Hence double complementation and period two hold. Equational induction proves `N(2n)=0` and `N(3n)=N(n)`.
3. `j(u)=Z(u)+2N(u)` has the finitely computed values `j(0)=1`, `j(1)=2`, `j(2)=0`; `M(n)=I(n,0;j)` does not need a global modulo-three theorem.
4. The ramp `G(n)=I(n,0;u.u+M(u)+1)` has the single-equation invariant `M(G(n))=N(n)`. Its step uses the already proved Boolean range of `N(n)`. This gives `G(n+2)=G(n)+3`, `G(2n)=3n`, and `G(3n)=3G(n)+N(n)` by equation inductions.
5. `H(u)=C(N(u),G(u),u)` satisfies `H(2u)=3u`, `H(1)=1`, and `H(3u)=3H(u)`. The last identity splits the Boolean `N(u)`; it does not assume every number is explicitly even or odd.
6. Scalar rotation and scaling are separate equation inductions with fixed passive parameters: `I(Sy,a;h)=I(y,h(a);h)` and `I(y,3a;H)=3I(y,a;H)`. With `E(x)=I(x,1;u.2u)`, the comparator `L(x,y)=N(I(y,E(x);H))` therefore satisfies `L(0,y)=1`, `L(Sx,0)=0`, `L(Sx,Sy)=L(x,y)` internally on the full domain.
7. Put `B_m(u)=C(L(Su,m),u,Su)` and `W(t,m)=I(t,0;B_m)`. Selector congruence and comparator equations give `B_{Sm}(0)=1` and `B_{Sm}(Su)=S B_m(u)`. A single-equation induction on `t`, with `m` fixed, gives `W(St,Sm)=S W(t,m)`.
8. Only after that universal fixed-parameter identity is proved, substitute `t=m=n` to prove `W(n,n)=n` by another equation induction. Similarly `L(Sn,n)=0`. Hence `W(Sn,n)=n`. There is no illicit change of an active induction parameter.
9. The final predecessor `P(m)=I(m,0;u.C(L(SSu,m),u,Su))` satisfies `P(0)=0`. For `P(Sm)`, introduce a separate parameterized iterator `V(t,m)` and prove `V(t,m)=W(t,m)` by equation induction using pointwise update equality. Thus `P(Sm)=W(Sm,m)=m`. This explicitly avoids assuming iterator-body extensionality before proving it.

Every displayed use of induction has a literal equation invariant. Numerical disjunctions in individual steps are obtained by cases or already established finite range theorems.

## 2. Actual equality reflection is also correctly ordered

After predecessor is available, numerical coverage gives `x=0 or x=S(Px)`. Applying `P` proves successor injectivity. Applying the sign selector to a hypothetical `Sx=0` and using the explicit separation bridge proves successor/zero separation.

The sign and countdown tests have their correct whole-domain meanings using only coverage, predecessor, and separation. Truncated subtraction `d(x,y)=I(y,x;P)` is already a scalar term; no general primitive-recursion compiler is needed.

The decisive invariant is the literal equation

`C(sg(d(x,y)), x, y+d(x,y)) = x`.

It is proved by induction on `y`, with `x` fixed. In the successor step, write `r=d(x,y)` and `r'=P(r)`. Coverage of `r'` gives the zero branch (trivial reflexivity) and the successor branch. In the latter, coverage of `r` either contradicts `r'!=0`, or gives `r=S(r')`. The previous equation then gives `y+r=x`; addition shifts the successor to obtain `(Sy)+r'=x`. This uses the same fixed `x,y` induction instance throughout.

Substitute `x=Sa,y=b` into the proved invariant. If `d(Sa,b)=1`, then `b+1=Sa`, hence `Sb=Sa`, and predecessor yields `a=b`. Conversely, the separately proved diagonal `d(Sa,a)=1` gives the reverse implication. Therefore

`e(a,b)=sg(K(d(Sa,b)))`

is a Boolean characteristic of **actual logical equality**, because `K(u)=0 iff u=1` and `sg(v)=0 iff v=0` were independently proved. Equality decidability is a conclusion, not an input.

The subsequent external construction of quantifier-free characteristics is constructively valid, including implication: split the already proved Boolean characteristic of the antecedent. No excluded middle for quantified formulas enters. Equation induction on the characteristic equation yields full QFI.

## 3. Pairing and staged-description cautions

The square-root pairing appendix starts only after QFI and equality reflection. All its numerical operations are scalar terms. Its bounded root iterator keeps the parameter `n` fixed; the three-component invariant is quantifier-free and QFI now legitimately applies. Both projections are proved only on pair encodings; surjectivity is neither used nor claimed.

Two presentation points should be preserved in any new report:

- The old equality-reflection source first describes a full PR signature generically. Its introductory specialization is essential: the proof actually uses only predecessor, selector, addition, subtraction, and their compositions, all scalar terms already constructed. State this specialization directly rather than relying on the generic opening wording.
- When binder syntax is elaborated into a staged first-order signature, substitution can produce a syntactically different iterator description. Equality of the two elaborations requires the ordinary uniqueness/coherence lemma, proved by equation induction with passive parameters fixed. It is not literal symbol identity. This does not invalidate the full theory, which has that induction, but a claimed *pre-induction* syntactic derivation must say which binder convention it uses. The current reports already flag this issue in several places.

I did not find a fatal arithmetic gap. The remaining burden for a formalized proof is substantial but consists of explicit fixed-equation inductions, not a missing nonstandard-model reflection theorem.

## 4. A precise logical simplification: atomic transport suffices

Let `C_at` have the ordinary Choice-DI computations, hypothesis/Use rules, closure specialization, paired elimination, and both case/progress introductions, but replace arbitrary-formula transport by the restricted rule

`s=t, U(s)=V(s) / U(t)=V(t)`,

where `U,V` are fixed capture-free numerical term templates. Thus both the minor and conclusion of primitive transport are literal equations.

**Theorem.** Every arbitrary-formula transport inference is derivable in `C_at`. Consequently it proves exactly the same native sequents as the inherited calculus. The derivation of the extension uses case introduction only, not progress induction.

**Proof.** First derive reflexivity from the zero-computation equation exactly as before; all involved motives are equations. Symmetry, transitivity, and numerical congruence also have atomic motives.

Induct externally on the native formula `F(v)` to derive `F(s) -> F(t)` in a context containing `s=t`.

- If `F` is an equation, use the new primitive rule.
- Suppose `F(v)=D_{x,y}B(v,x,y)`. Eliminate `D B(s)` at a fresh witness `a`, obtaining the closure `Q_y B(s,a,y)`. To introduce `D B(t)`, use witness `a` and case DI. Its retained assumption is `B(t,a,0)`. By the structural induction hypothesis and symmetry of `s=t`, derive `B(s,a,0)`. Specialize the old closure at `Sz`, obtaining `B(s,a,Sz)`. By the induction hypothesis in the forward direction, derive `B(t,a,Sz)`. Case DI introduces `D B(t)`, and paired elimination discharges the fresh witness.

The converse inclusion is immediate, since the inherited transport rule includes atomic motives. All fixed template parameters and newly bound variables are renamed to avoid capture.

For a serialized calculus permitting unary `Q` as an auxiliary conclusion, the same induction extends to `Q`: use the displayed zero-to-successor argument, introduce `D` with an unused existential coordinate, then eliminate it and return its supplied `Q` assumption. Thus this is not restricted merely to closed Eq/D goals.

This reduction is a clean logical theorem relative to the inspected native calculus. It is not a literature-wide novelty claim. Its syntactic proof translator can be untrusted.

### Why this does not automatically make the current checker smaller

The current compact kernel already uses one generic opening routine for equality transport, closure specialization, and paired rules. Enforcing that a transport motive has an equation root adds a guard; it does not remove that opening routine. Replacing the operation by path-addressed contextual rewriting normally adds another recursive traversal, address validation, and capture handling. Therefore I recommend this theorem as an optional restricted logical interface, not as an unmeasured byte-saving claim.

One-hole **numerical** rewriting is also sufficient: from `s=t` and `C[s]=r`, infer `C[t]=r`, for one numerical occurrence hole. Symmetry and repeated one-occurrence steps recover arbitrary atomic motives, and the theorem above recovers all formula transport. However checking the single-hole/path restriction adds its own code, and the current sources already refer to earlier one-hole research; priority should not be asserted without consulting those earlier archives.

## 5. Iterator uniqueness instead of induction: a useful conditional theorem

There is a conceptual equivalence that may guide later work but does not presently lower this kernel. Assume the base already has selectors and a correct Boolean characteristic `b_A` for each target equation or QF formula. Let scalar iteration have its computation equations and the contextual **eta/uniqueness** rule:

from `f(0)=a` and `f(Sn)=h(f(n))`, conclude `f(n)=I(n,a;h)`,

for each fixed numerical term `f`, with all passive parameters fixed and the usual fresh `n`.

Then eta derives induction for every such `A`. Given its base and step, define the retraction

`r(u)=C(b_A(u),u,0)`.

One proves `A(r(u))`, `r(r(u))=r(u)`, `r(0)=0`, and `r(S(r(u)))=S(r(u))` by Boolean cases, the given base, and the given induction step. Put `h(u)=S(r(u))` and `F(n)=I(n,0;h)`.

Eta gives the usual fusion law whenever `r(h(u))=h(r(u))`: compare the recurrences of `r(I(n,a;h))` and `I(n,r(a);h)`. Here it yields `r(F(n))=F(n)`. Thus `F(0)=0` and `F(Sn)=S(F(n))`. Eta identifies `F(n)` and the identity term `n` with `I(n,0;S)`, so `F(n)=n`. Since `A(r(F(n)))`, obtain `A(n)`.

This proof uses a correct characteristic **before** deriving induction. In the scalar inherited bootstrap that characteristic was obtained using equation induction, so merely replacing EI by eta and citing the old arithmetic appendices would be circular. A successful eta-only proposal must independently build/calibrate the characteristic or change the base; that extra work and checker cost cannot be hidden. The existing scalar-feedback and countdown reports already investigate nearby calibration mechanisms.

## Recommendation

For the current new kernel, retain the audited scalar arithmetic bridge unless the counter-aware R representation fits its source budget; the latter greatly shortens the arithmetic proof but is already known in the current drafts. Present atomic-only transport as a proved optional interface reduction if useful. Do not switch to eta-only induction or arbitrary contextual rewriting without a fully charged checker and an independent arithmetic bootstrap.
