ATOMIC TRANSPORT FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov, November 10, 2026
================================================================

RESULT AND LIMIT
----------------
This package gives a fully specified Eq/D axiomatization whose primitive
equality transport is restricted to literal equations. Compound transport
and general object-assumption use have explicit derivations. The numerical
basis is the inherited successor-seeded counter-aware recursor R. Written
proofs establish full-domain, actual-equality bi-interpretability with
first-order iPRA and equiconsistency.

The complete atomic checker measures 304 normalized Python tokens,
345 AST nodes, and 714 normalized bytes. The complete current corpus
envelope is 287 / 323 / 738, attained by different programs. Thus this
construction improves the byte coordinate by 24 bytes (3.25%), while
not improving the other two independent minima. A delivered matched
unrestricted control is smaller still: 297 / 335 / 698, a 5.42% byte
improvement over the previous byte leader. It retains general transport.

The atomic guard costs 16 bytes. The byte saving comes from combining
inherited certificate, assumption-availability, and recursor techniques,
not from restricting transport. This is a modest improvement, not the
requested significant breakthrough, absolute minimum, or simultaneous
improvement of every current source metric. No such claim is made.

A historical check found the same compound-transport lifting in the older
ipra_fixed_position_2026-11-09 draft. The report explicitly attributes it.
The current package is a consolidation with a smaller complete byte checker
and executable proof expansion, not a new mathematical transport theorem.

START HERE
----------
report.pdf                   Complete compiled research report.
report.tex                   Main editable LaTeX source.
code/checker.py              Entire measured 714-byte normalized kernel.
code/unrestricted_control.py Entire 698-byte unrestricted control.
code/readable_checker.py     Explanatory implementation of the atomic kernel.
code/FORMAT.txt              Exact certificate syntax, scope, and rule policy.
code/producer.py             Untrusted identity/transport proof expansion.
code/inherited_r.py          Attributed upstream named R syntax and constructors.
tests/certificates.json      17 positive and 12 targeted negative packets.
tests/examples/              Individually runnable JSON proof certificates.
tests/check_boundaries.py    Independent binding and rule-boundary checks.
reference/                  Frozen old checkers, unchanged measurement code,
                            and upstream license.
evidence/                   Source inventory, metrics, test receipts, reviews.
notes/                      Detailed atomic theorem and rejected conversion
                            architecture (not a verified alternative kernel).
MANIFEST.json               SHA-256 and length of every distributed payload.

REPRODUCE
---------
From the extracted package root, run:

    python3 reproduce.py

The script verifies the distributed manifest before regenerating evidence,
rebuilds all symbolic packets, checks the atomic and readable programs under
ordinary and optimized Python, isolates the atomic guard against the
unrestricted control, and remeasures every complete comparison module.
Only the Python standard library is needed. Exact recorded metrics use
CPython 3.12.14; the script reports the actual version.
Reproduction rewrites generated receipts; the manifest identifies their
distributed versions, so integrity verification starts from a fresh extraction.

For a single certificate:

    python3 code/checker.py < tests/examples/compound_transport_depth_3.json

To rebuild the PDF using an installed TeX distribution:

    python3 build.py

No network or shell escape is used. The main source includes the local
checker listing and generated validation summary. The standalone source
ipra_atomic_transport_standalone.tex embeds both, so it compiles alone.

THEORY BOUNDARY
---------------
Object formulas are equations and paired D formulas. Q is an internal
reusable closure clause, available as an elimination major, not a general
object goal. Its ordinary meaning is B(0) -> forall y B(y). The report
does not claim identity preservation for every legacy raw Q goal.
Progress introduction remains restricted to literal equation matrices;
compound induction is not introduced by the transport expansion.

VERIFICATION BOUNDARY
--------------------
The universal claims are written mathematical proofs. Symbolic proof
certificates and targeted corruption tests provide executable supporting
evidence. There is no Lean/Rocq formalization of the entire theory or
Python implementation and no external human peer review.

PROVENANCE
----------
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 7bded17cc0122767f86e494fcf256b47fe85c9b8
Directory: docs/drafts
All ten direct ZIP files were checked by byte length and Git blob identity.
Repository contents were accessed read-only. No repository changes were made.
Inherited techniques and copied sources are attributed in the report and
evidence/inherited_files.json. The upstream license is included.
