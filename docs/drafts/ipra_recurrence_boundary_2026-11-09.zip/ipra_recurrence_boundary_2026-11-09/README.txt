FIXED RECURRENCE RULES FOR iPRA
Prepared for Vladimir Reshetnikov, 9 November 2026.

STATUS
The requested smallest axiomatization and a complete checker strictly below
the current frontier were not obtained. No claim of a significant completed
breakthrough or a new minimum is made.

START WITH report.pdf
The report contains:
1. A countermodel theorem for contextual recurrence uniqueness when a fixed
   finite transition factors through a bounded numerical observation.
   Counter-dependent updates and unbounded passive parameters are allowed.
2. A stronger theorem: all updates h(n,Q(u),p), with a separately defined
   standard identity program Q at the state input, can have their uniqueness
   rules validated together in a model that is not bi-interpretable with iPRA.
   In particular the known sufficient signed update B and B composed with Q
   agree on standard numbers but have different foundational strength.
3. An exact trade between full contextual stationarity and one fixed
   iterator-retraction sentence when the update has a PR right inverse.
4. Rigorous partial calibration of W(0)=1, W(Sn)=n, including
   I_W(n,S^m n)=m for every fixed standard numeral m. Full iPRA equivalence
   of this candidate remains unproved.
5. The complete ordinary logic/PR description inventory and the strongest
   relevant inherited one-signed-update baseline, clearly attributed.

The current complete-source minimum remains 309 normalized Python tokens,
344 AST nodes, and 864 normalized UTF-8 bytes. The 19 frozen comparator
programs are inherited; none is a newly implemented theory.

FILES
report.tex / report.pdf        Main standalone research report.
reference/known_equivalence/  Unchanged complete prior equivalence source/PDF.
reference/checkers/           19 unchanged inherited complete comparators.
reference/source_measure.py  Unchanged source normalizer.
code/                        Measurement and finite-transcription diagnostics.
evidence/                    Snapshot, measurements, checks, build, rendering.
reviews/                     Independent assistant mathematical reviews.
CLAIMS.json                  Explicit proved/unproved/inherited claim ledger.
ATTRIBUTION.txt               Provenance and limits of novelty.
MANIFEST.json                Payload SHA-256 identities.

REPRODUCE
  python3 reproduce.py
  python3 build.py
  python3 package.py

Exact inherited ast.unparse measurements are recorded under CPython 3.12.
The PDF build needs pdfLaTeX and the packages listed in report.tex.
No network access is needed to reproduce the supplied evidence.

TRUST BOUNDARY
The main theorems have written proofs and independent assistant reviews.
They are not Lean/Rocq formalizations or external peer-reviewed results.
Finite numerical checks only detect transcription errors on standard inputs.
They do not establish the universal identities or the nonstandard model.
The large linear-cover construction and existing B-equivalence are attributed
dependencies; the current report recalls the cover proof and supplies the
new recurrence-validity arguments.

SOURCE
ProveIt commit e707d8bd1bcbc036631663e7538efd8b42b1e130, docs/drafts.
All 11 current archives were verified against their Git blob identities.
The repository was read only.
