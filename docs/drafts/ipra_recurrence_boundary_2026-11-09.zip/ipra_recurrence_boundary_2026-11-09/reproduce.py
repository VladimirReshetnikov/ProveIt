"""Reproduce measurements and explicitly limited finite diagnostics."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
for script in ("code/audit_frontier.py", "code/check_examples.py"):
    subprocess.run([sys.executable, str(root / script)], cwd=root, check=True)
