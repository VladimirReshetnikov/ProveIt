"""Compile the standalone report; requires pdfLaTeX."""
from pathlib import Path
import json
import subprocess

root = Path(__file__).resolve().parent
logs = []
for run in range(3):
    process = subprocess.run(
        ["pdflatex", "-no-shell-escape", "-interaction=nonstopmode",
         "-halt-on-error", "-file-line-error", "report.tex"],
        cwd=root, capture_output=True, text=True)
    logs.append(process.stdout + process.stderr)
    if process.returncode:
        (root / "evidence/build.log").write_text("\n".join(logs))
        raise SystemExit("PDF compilation failed; see evidence/build.log")
(root / "evidence/build.log").write_text("\n".join(logs))
(root / "evidence/build.json").write_text(json.dumps({
    "passes": 3, "shell_escape": False, "output": "report.pdf",
    "returncode": 0, "bytes": (root / "report.pdf").stat().st_size
}, indent=2) + "\n")
print("Compiled report.pdf")
