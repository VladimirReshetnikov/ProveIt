"""Remeasure frozen complete reference sources; this is not an iPRA checker."""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import platform

ROOT = Path(__file__).resolve().parents[1]
manifest = json.loads((ROOT / "reference/comparators.json").read_text())
normalizer_path = ROOT / "reference/source_measure.py"
digest = hashlib.sha256(normalizer_path.read_bytes()).hexdigest()
if digest != manifest["normalizer_sha256"]:
    raise ValueError("Reference normalizer changed")
spec = importlib.util.spec_from_file_location("inherited_source_measure", normalizer_path)
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
rows = []
for entry in manifest["programs"]:
    path = ROOT / entry["file"]
    if hashlib.sha256(path.read_bytes()).hexdigest() != entry["sha256"]:
        raise ValueError("Changed comparator: " + entry["file"])
    profile = measure.metrics(path)
    rows.append({**entry, **{k: profile[k] for k in (
        "normalized_tokens", "ast_nodes", "normalized_bytes", "raw_bytes"
    )}})
coordinates = ("normalized_tokens", "ast_nodes", "normalized_bytes")
minimum = {key: min(row[key] for row in rows) for key in coordinates}
result = {
    "scope": "Nineteen inherited complete programs, entire modules, no new candidate.",
    "classification": "Inherited from the current frontier audit, not independently re-proved.",
    "python": platform.python_version(),
    "implementation": platform.python_implementation(),
    "program_count": len(rows),
    "coordinate_minimum": minimum,
    "attainers": {key: [r["label"] for r in rows if r[key] == minimum[key]]
                  for key in coordinates},
    "programs": rows,
}
(ROOT / "evidence/frontier_metrics.json").write_text(json.dumps(result, indent=2) + "\n")
with (ROOT / "evidence/frontier_metrics.csv").open("w", newline="") as stream:
    writer = csv.DictWriter(stream, ("label", *coordinates, "sha256"), extrasaction="ignore")
    writer.writeheader()
    writer.writerows(rows)
print(json.dumps({k: v for k, v in result.items() if k != "programs"}, indent=2))
