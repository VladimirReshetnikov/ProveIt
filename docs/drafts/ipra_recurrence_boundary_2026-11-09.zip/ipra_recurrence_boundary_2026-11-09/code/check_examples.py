"""Finite transcription checks, not a verification of the nonstandard theorems."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]


def W(u):
    return 1 if u == 0 else u - 1


def iterate(update, n, a):
    for _ in range(n):
        a = update(a)
    return a


def successor_iterator(n, a):
    return iterate(lambda u: u + 1, n, a)


def Q(n):
    # The literal defining update S(P(Su)), independently of its expected value.
    return iterate(lambda u: max((u + 1) - 1, 0) + 1, n, 0)


def signed_B(u):
    return u + 2 if u % 2 == 0 else max(u - 2, 0)


def two_step_bounded(u):
    return u + 1 if u % 2 == 0 else 0


counts = {"countdown_diagonal": 0, "retraction_in_standard_numbers": 0,
          "rotation": 0, "bounded_second_iterate": 0,
          "failed_reflection_examples": 0, "standard_identity_mask": 0}
for n in range(81):
    for m in range(13):
        if iterate(W, n, n + m) != m:
            raise ValueError(("diagonal", n, m))
        counts["countdown_diagonal"] += 1
    for a in range(61):
        if iterate(W, n, successor_iterator(n, a)) != a:
            raise ValueError(("standard retraction", n, a))
        counts["retraction_in_standard_numbers"] += 1
        if iterate(W, n, W(a)) != W(iterate(W, n, a)):
            raise ValueError(("rotation", n, a))
        counts["rotation"] += 1
for b in range(201):
    a = b + 2
    if not (a != b and iterate(W, a, b) == 0 and iterate(W, a, b + 1) == 1):
        raise ValueError(("failed reflection", a, b))
    counts["failed_reflection_examples"] += 1
for u in range(2001):
    if two_step_bounded(two_step_bounded(u)) != u % 2:
        raise ValueError(("second iterate", u))
    counts["bounded_second_iterate"] += 1
    if Q(u) != u or signed_B(Q(u)) != signed_B(u):
        raise ValueError(("standard mask", u))
    counts["standard_identity_mask"] += 1
result = {
    "scope": "Finite standard-natural calculations only; no proof of universal or nonstandard claims.",
    "counts": counts,
    "total_checks": sum(counts.values()),
    "explicit_noninjectivity": {"inputs": [0, 2], "common_W_output": W(0)},
    "status": "passed",
}
(ROOT / "evidence/numerical_examples.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
