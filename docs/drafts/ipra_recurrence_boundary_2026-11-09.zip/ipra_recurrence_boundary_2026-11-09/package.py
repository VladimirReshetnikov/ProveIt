"""Create a reproducible ZIP and verify its payload hashes."""
from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parent
excluded = {".aux", ".out", ".toc", ".fls", ".fdb_latexmk", ".synctex.gz"}


def eligible(path):
    relative = path.relative_to(root)
    return (path.is_file() and "__pycache__" not in relative.parts
            and path.suffix not in excluded and not path.name.endswith(".pyc")
            and relative.as_posix() not in {"report.log", "MANIFEST.json"})


files = sorted(p for p in root.rglob("*") if eligible(p))
manifest = {
    "format": "sha256-payload-v1",
    "files": {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in files},
}
(root / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
files.append(root / "MANIFEST.json")
target = root.parent / (root.name + ".zip")
with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(files):
        info = zipfile.ZipInfo(root.name + "/" + path.relative_to(root).as_posix(),
                               date_time=(2026, 11, 9, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, path.read_bytes())
with zipfile.ZipFile(target) as archive:
    if archive.testzip() is not None:
        raise ValueError("ZIP CRC check failed")
    for path, digest in manifest["files"].items():
        actual = hashlib.sha256(archive.read(root.name + "/" + path)).hexdigest()
        if actual != digest:
            raise ValueError("ZIP payload mismatch: " + path)
print(json.dumps({"archive": target.name, "payload_files": len(files),
                  "bytes": target.stat().st_size,
                  "sha256": hashlib.sha256(target.read_bytes()).hexdigest()}, indent=2))
