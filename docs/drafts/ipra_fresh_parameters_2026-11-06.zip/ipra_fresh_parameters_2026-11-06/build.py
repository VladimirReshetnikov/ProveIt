"""Compile report.pdf with pdfLaTeX; preserve the build log for inspection."""
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    engine = shutil.which('pdflatex')
    if not engine:
        raise SystemExit('pdfLaTeX is required to rebuild report.pdf.')
    if not (ROOT / 'results/numbers.tex').exists():
        subprocess.run([sys.executable, str(ROOT / 'measure.py')], cwd=ROOT, check=True)
    logs = []
    for _ in range(3):
        result = subprocess.run([engine, '-interaction=nonstopmode', '-halt-on-error',
                                 '-file-line-error', 'report.tex'], cwd=ROOT,
                                capture_output=True, text=True)
        logs.append(result.stdout + result.stderr)
        if result.returncode:
            (ROOT / 'results/latex_build.txt').write_text('\n'.join(logs))
            print(result.stdout[-10000:])
            raise SystemExit(result.returncode)
    (ROOT / 'results/latex_build.txt').write_text('\n'.join(logs))
    print('Built report.pdf')


if __name__ == '__main__':
    main()
