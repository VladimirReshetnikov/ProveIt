"""Run the complete packaged finite validation without network access."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    stages = ['measure.py', 'validation/opening.py', 'validation/audit.py',
              'validation/verify_corpus.py']
    for stage in stages:
        result = subprocess.run([sys.executable, str(ROOT / stage)], cwd=ROOT,
                                capture_output=True, text=True)
        if result.returncode:
            print(result.stdout)
            print(result.stderr)
            raise SystemExit(result.returncode)
        print(stage + ': PASS')
    summary = {'status': 'PASS', 'stages': stages,
               'results': ['results/metrics.json', 'results/opening.json',
                           'results/results_audit.json', 'results/corpus.json',
                           'results/public_cli.json']}
    (ROOT / 'results/reproduction.json').write_text(json.dumps(summary, indent=2) + '\n')
    print('All packaged checks passed.')


if __name__ == '__main__':
    main()
