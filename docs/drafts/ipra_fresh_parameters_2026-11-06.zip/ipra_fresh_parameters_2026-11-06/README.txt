A SMALLER COMPLETE PRESENTATION OF iPRA
Fresh Parameters and Direct Witnesses
Prepared for Vladimir Reshetnikov, 6 November 2026

RESULT

The strict standalone checker has 491 normalized significant Python tokens,
496 AST nodes, and 1,540 normalized UTF-8 bytes. It is below all three
coordinatewise minima 505 / 510 / 1,554 across all 16 top-level checkers
in the six current ProveIt draft archives at commit:
  9e8e3161b0dffb54fceb0b75ee818cc9e4ed2b10

The same reduction holds for the uniformly isolated core:
  strict new: 433 / 430 / 1,279
  prior minimum: 447 / 444 / 1,292

The demand-validation companion is smaller still:
  complete program: 484 / 491 / 1,519
  core: 426 / 425 / 1,258

The new idea is locally nameless opening with fresh rigid parameters.
All substitution images are locally closed. The checker therefore no
longer shifts contexts or lifts substitution images, and it carries no
affine offset for remaining free indices. Existential introduction uses
its numerical witness directly.

The underlying unary-closure arithmetic basis is inherited and credited.
This is an improved complete proof presentation and implementation, not
a proof of absolute minimality or a claim of fewer mathematical axioms.

FILES

report.tex, sections/*.tex       Complete self-contained mathematical report
report.pdf                      Compiled report
checker.py                      Primary strict standalone theorem checker
checker_demand.py               Smaller demand-validation companion
FORMAT.txt                      Concrete syntax and proof stream conventions
examples/strict, examples/demand Generated certificates, with provenance
validation/                     Translator, exact source fixtures, audits
comparison/                     All 16 unchanged current baseline checkers
results/                        Reproducible measurements and audit results
measure.py                      Regenerate comparison and LaTeX tables
reproduce.py                    Run all packaged validation
build.py                        Rebuild report.pdf
MANIFEST.sha256                 Packaged-file integrity hashes

RUN

Python 3.12 was used for the recorded normalization metrics. Python 3.10+
provides the checker syntax features, but ast.unparse output can vary by
release. The checkers and validation use only the standard library.

  python3 checker.py examples/strict/draft_5/reflexivity_zero.json
  python3 reproduce.py
  python3 build.py

The checker prints ACCEPT and exits 0, or prints REJECT and exits 1.
The same behavior holds under python3 -O. Rebuilding the PDF requires
pdfLaTeX with the ordinary packages listed in report.tex.

VALIDATION

Each policy passed 143 historical fixtures: 122 unconditional theorem
fixtures (45 distinct translated certificates) and 21 explicitly
conditional open-sequent checks. The theorem CLI always starts with an
empty context. The 122 primary theorem fixtures passed the actual CLI
both normally and under -O. Separate tests ran 18,000 opening comparisons,
96 end-to-end adversarial cases, and three sensitivity controls that
deliberately break the checker and reproduce the expected vulnerabilities.

These are finite computational checks. The report gives mathematical
proofs of the general metatheory; it does not claim a Lean/Rocq
formalization of the complete checker or bi-interpretability theorem.

LANGUAGE AND EQUIVALENCE

The native language has zero, successor, finite syntactic initialized
recursion, equality, existential quantification, and unary numerical
closure Q_x B = (B(0) -> forall x B(x)). Every primitive logical and
arithmetic rule is stated in the report. Ordinary intuitionistic logic
and quantifier-free induction are derived. An ordinary first-order
realization is bi-interpretable with iPRA on the whole numerical domain;
the two composite isomorphisms are defined by x=y. Equiconsistency follows.

Negative integer tokens name free numerical parameters; they are not
negative numerical values. Positive integer tokens are bound indices
and must not escape their syntactic binder. See FORMAT.txt.

The two checker variants prove the same theorems but can require different
certificate names. Strict validation scans every witness; demand validation
may ignore an unused annotation, which can be replaced by zero. Their
separately generated example directories account for this difference.

SOURCE ATTRIBUTION

The six archives, their immutable Git identities, and all baseline source
hashes are recorded under comparison/. The original mathematical basis
and implementation ancestry are credited in report.tex and its sources
section. LICENSE_SOURCE.txt preserves the provided source license.

