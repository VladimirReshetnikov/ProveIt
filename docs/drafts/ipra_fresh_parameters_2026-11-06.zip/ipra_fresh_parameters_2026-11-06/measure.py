"""Reproduce the pinned whole-program and core comparisons (Python 3.12)."""
import ast
import csv
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

ROOT = Path(__file__).resolve().parent
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body.pop(0)
        return node
    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def count(tree):
    normalized = ast.unparse(tree) + '\n'
    return {
        'normalized_tokens': sum(t.type not in IGNORED for t in
                                tokenize.generate_tokens(io.StringIO(normalized).readline)),
        'ast_nodes': sum(1 for _ in ast.walk(tree)),
        'normalized_bytes': len(normalized.encode('utf-8')),
    }


def metrics(path):
    raw = Path(path).read_bytes()
    tree = ast.fix_missing_locations(StripDocstrings().visit(ast.parse(raw)))
    whole = count(tree)
    tree.body = [n for n in tree.body
                 if not isinstance(n, (ast.Import, ast.ImportFrom))
                 and not (isinstance(n, ast.If) and '__name__' in ast.unparse(n.test))]
    return {'whole': whole, 'core': count(tree), 'raw_bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    manifest = json.loads((ROOT / 'comparison/baseline_manifest.json').read_text())
    rows = []
    for entry in manifest['rows']:
        measured = metrics(ROOT / 'comparison' / entry['local_file'])
        if measured['sha256'] != entry['sha256']:
            raise ValueError('Modified comparator: ' + entry['local_file'])
        rows.append({**entry, **measured})
    envelopes = {}
    for cohort, selected in [('all', rows), ('strict', [r for r in rows if r['strict']])]:
        envelopes[cohort] = {boundary: {field: min(r[boundary][field] for r in selected)
                                      for field in FIELDS}
                             for boundary in ('whole', 'core')}
    candidates = {name: metrics(ROOT / name) for name in ('checker.py', 'checker_demand.py')}
    for name, candidate in candidates.items():
        for boundary in ('whole', 'core'):
            for field in FIELDS:
                if not candidate[boundary][field] < envelopes['all'][boundary][field]:
                    raise ValueError(f'No strict improvement: {name}, {boundary}, {field}')
    result = {'python': platform.python_version(), 'implementation': platform.python_implementation(),
              'commit': manifest['commit'], 'archive_count': 6, 'program_count': len(rows),
              'envelopes': envelopes, 'candidates': candidates, 'programs': rows}
    results = ROOT / 'results'
    results.mkdir(exist_ok=True)
    (results / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    with (results / 'metrics.csv').open('w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['program', 'boundary', *FIELDS, 'sha256'])
        for r in rows + [{'local_file': k, **v} for k, v in candidates.items()]:
            for b in ('whole', 'core'):
                writer.writerow([r['local_file'], b, *(r[b][x] for x in FIELDS), r['sha256']])
    macros = []
    for prefix, data in [('Old', envelopes['all']), ('New', candidates['checker.py']),
                         ('Demand', candidates['checker_demand.py'])]:
        for boundary, mid in [('whole', ''), ('core', 'Core')]:
            for field, suffix in zip(FIELDS, ('Tokens', 'AST', 'Bytes')):
                macros.append('\\newcommand{\\' + prefix + mid + suffix + '}{'
                              + str(data[boundary][field]) + '}')
    (results / 'numbers.tex').write_text('\n'.join(macros) + '\n')
    table = ['\\begin{longtable}{llrrr}', '\\toprule',
             r'Archive & Program & Tokens & AST & Bytes\\', '\\midrule', '\\endhead']
    for r in rows:
        pieces = Path(r['local_file']).parts
        label = 'D' + pieces[-2].split('_')[-1]
        stem = Path(pieces[-1]).stem.replace('checker', 'main')
        vals = ' & '.join(str(r['whole'][f]) for f in FIELDS)
        table.append(label + r' & \code{' + stem + '} & ' + vals + r'\\')
    table += ['\\bottomrule', '\\end{longtable}']
    (results / 'baseline_table.tex').write_text('\n'.join(table) + '\n')
    print(json.dumps({k: result[k] for k in ('python', 'commit', 'program_count', 'envelopes', 'candidates')}, indent=2))


if __name__ == '__main__':
    main()
