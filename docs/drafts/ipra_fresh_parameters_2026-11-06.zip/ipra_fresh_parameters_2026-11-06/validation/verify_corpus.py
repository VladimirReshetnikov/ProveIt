"""Regenerate and verify the complete archived positive certificate corpus.

Run from any directory:
    python3 validation/verify_corpus.py

The 21 open-sequent fixtures are internal-interface tests, with every external
assumption explicitly validated. They are not inputs to the public theorem
interface. All 122 unconditional strict fixtures are also run as independent
CLI processes, both normally and with Python optimization enabled.
"""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
VALIDATION = ROOT / 'validation'
RESULTS = ROOT / 'results'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_translator():
    spec = importlib.util.spec_from_file_location('corpus_translator', VALIDATION / 'translate.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def verified_sources():
    manifest = json.loads((VALIDATION / 'source_manifest.json').read_text())
    reference = ROOT / manifest['reference_checker']
    if digest(reference) != manifest['reference_checker_sha256']:
        raise ValueError('Frozen reference checker hash changed')
    records = []
    for entry in manifest['fixtures']:
        path = ROOT / entry['local_file']
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != entry['sha256']:
            raise ValueError('Source fixture hash changed: ' + entry['local_file'])
        if len(raw) != entry['size_bytes']:
            raise ValueError('Source fixture size changed: ' + entry['local_file'])
        data = json.loads(raw)
        if len(data) - 2 != entry['external_context_size']:
            raise ValueError('Source context count changed: ' + entry['local_file'])
        records.append((entry, data))
    if len(records) != manifest['fixture_count']:
        raise ValueError('Source fixture count does not match manifest')
    return manifest, records


def regenerate(translator, records, policy):
    checker = ROOT / ('checker.py' if policy == 'strict' else 'checker_demand.py')
    checker_hash = digest(checker)
    previous_path = RESULTS / ('corpus_' + policy + '.json')
    previous = {}
    if previous_path.exists():
        previous = {r['source']: r for r in json.loads(previous_path.read_text())['results']}
    rows = []
    for entry, data in records:
        certificate, details = translator.translate(data, checker, policy)
        encoded = (json.dumps(certificate, separators=(',', ':')) + '\n').encode()
        output = ROOT / 'examples' / policy / entry['label']
        if output.exists() and output.read_bytes() != encoded:
            raise ValueError('Regenerated certificate differs: ' + str(output.relative_to(ROOT)))
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(encoded)
        row = {
            'source': entry['label'],
            'source_sha256': entry['sha256'],
            'output': str(output.relative_to(ROOT)),
            'output_sha256': hashlib.sha256(encoded).hexdigest(),
            **details,
        }
        if entry['label'] in previous:
            old = previous[entry['label']]
            for key in ('parameters', 'final_counter', 'target_instructions', 'output_sha256'):
                if old[key] != row[key]:
                    raise ValueError(('Counter/parameter reproducibility failure', entry['label'], key))
        rows.append(row)
    if digest(checker) != checker_hash:
        raise ValueError('Target checker changed during corpus regeneration')
    theorem_rows = [r for r in rows if r['external_context_size'] == 0]
    count_keys = (
        'closure_introductions', 'existential_eliminations',
        'guarded_existential_introductions_removed', 'guard_reflexivity_certificates',
        'source_assumption_subproofs_shortened', 'source_instructions', 'target_instructions',
    )
    result = {
        'policy': policy,
        'target_checker': str(checker.relative_to(ROOT)),
        'target_checker_sha256': checker_hash,
        'accepted': len(rows),
        'theorem_certificates': len(theorem_rows),
        'open_sequent_certificates': len(rows) - len(theorem_rows),
        'distinct_theorem_certificate_hashes': len({r['output_sha256'] for r in theorem_rows}),
        'counter_replay_matches': len(rows),
        'totals': {key: sum(r[key] for r in rows) for key in count_keys},
        'failures': [],
        'results': rows,
    }
    write_json(previous_path, result)
    return result


def verify_cli(strict_result):
    checker = ROOT / strict_result['target_checker']
    theorem_rows = [r for r in strict_result['results'] if r['external_context_size'] == 0]

    def run(item):
        row, optimized = item
        command = [sys.executable, *(['-O'] if optimized else []), str(checker), str(ROOT / row['output'])]
        process = subprocess.run(command, text=True, capture_output=True, timeout=30)
        return {
            'source': row['source'], 'optimized': optimized,
            'exit_code': process.returncode, 'stdout': process.stdout.strip(),
            'stderr': process.stderr.strip(),
        }

    jobs = [(row, optimized) for optimized in (False, True) for row in theorem_rows]
    with ThreadPoolExecutor(max_workers=8) as pool:
        rows = list(pool.map(run, jobs))
    failures = [r for r in rows if r['exit_code'] != 0 or r['stdout'] != 'ACCEPT']
    result = {
        'target_checker': strict_result['target_checker'],
        'target_checker_sha256': strict_result['target_checker_sha256'],
        'theorem_certificates': len(theorem_rows),
        'distinct_certificate_hashes': strict_result['distinct_theorem_certificate_hashes'],
        'normal_cli_acceptances': sum(not r['optimized'] and r['exit_code'] == 0 and r['stdout'] == 'ACCEPT' for r in rows),
        'optimized_cli_acceptances': sum(r['optimized'] and r['exit_code'] == 0 and r['stdout'] == 'ACCEPT' for r in rows),
        'failures': failures,
    }
    if digest(checker) != strict_result['target_checker_sha256']:
        raise ValueError('Target checker changed during CLI verification')
    write_json(RESULTS / 'public_cli.json', result)
    if failures:
        raise ValueError('One or more public CLI theorem checks failed')
    return result


def verify():
    manifest, records = verified_sources()
    translator = load_translator()
    strict = regenerate(translator, records, 'strict')
    demand = regenerate(translator, records, 'demand')
    cli = verify_cli(strict)
    result = {
        'python_version': platform.python_version(),
        'source_commit': manifest['commit'],
        'source_fixtures_verified_by_sha256': len(records),
        'theorem_fixtures': strict['theorem_certificates'],
        'open_sequent_fixtures': strict['open_sequent_certificates'],
        'strict_accepted': strict['accepted'],
        'demand_accepted': demand['accepted'],
        'strict_distinct_theorem_certificates': strict['distinct_theorem_certificate_hashes'],
        'demand_distinct_theorem_certificates': demand['distinct_theorem_certificate_hashes'],
        'strict_counter_replay_matches': strict['counter_replay_matches'],
        'demand_counter_replay_matches': demand['counter_replay_matches'],
        'normal_cli_acceptances': cli['normal_cli_acceptances'],
        'optimized_cli_acceptances': cli['optimized_cli_acceptances'],
        'failures': [],
        'details': ['results/corpus_strict.json', 'results/corpus_demand.json', 'results/public_cli.json'],
    }
    write_json(RESULTS / 'corpus.json', result)
    print(json.dumps(result, indent=2))
    return result


if __name__ == '__main__':
    verify()
