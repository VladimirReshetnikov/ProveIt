"""Independent opening and name-supply checks for both standalone kernels.

Run from any working directory with Python 3.10 or later:
    python3 validation/opening.py

This is untrusted validation support. Neither acceptance kernel imports it.
The mathematical reference is the frozen affine-substitution routine in the
smallest supplied demand checker. The tests use a deterministic random seed.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import platform
import random

ROOT = Path(__file__).resolve().parents[1]
SEED = 711966
ROUNDS_PER_HOLE_COUNT = 1500


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def require(condition, detail):
    if not condition:
        raise AssertionError(detail)


def negative_leaves(expression):
    if type(expression) is int:
        return [expression] if expression < 0 else []
    if type(expression) is list:
        return [value for child in expression for value in negative_leaves(child)]
    return []


def run():
    baseline_path = ROOT / 'comparison/sources/draft_2/checker_demand.py'
    reference = load('opening_reference', baseline_path)
    paths = {'strict': ROOT / 'checker.py', 'demand': ROOT / 'checker_demand.py'}
    modules = {policy: load('opening_' + policy, path) for policy, path in paths.items()}
    rng = random.Random(SEED)
    stats = {
        policy: {
            'formula_comparisons': 0,
            'term_comparisons': 0,
            'supply_checks': 0,
            'output_closedness_checks': 0,
            'malformed_goal_terms_rejected': 0,
            'used_bad_images_rejected': 0,
            'unused_bad_images_rejected': 0,
            'unused_images_ignored': 0,
            'unused_valid_images_registered': 0,
            'rigid_parameter_checks': 0,
        }
        for policy in modules
    }

    def term(size, depth=0, holes=0):
        if not size or rng.randrange(3) == 0:
            return rng.choice([0, -1, -2, -17, -1001, *range(1, depth + holes + 1)])
        if rng.randrange(2):
            return ['s', term(size - 1, depth, holes)]
        return ['r', term(size - 1, depth, holes), term(size - 1, depth, holes),
                term(size - 1, depth + 2, holes)]

    def formula(size, depth=0, holes=0):
        if not size or rng.randrange(3) == 0:
            return ['=', term(size, depth, holes), term(size, depth, holes)]
        return [rng.choice(['u', 'ex']), formula(size - 1, depth + 1, holes)]

    def opening(module, policy, expression, images, is_formula):
        # The strict helper has a precondition: all images are already closed
        # numerical terms and their parameter names have been registered.
        if policy == 'strict':
            images = [module.inst(image, formula=False) for image in images]
        return module.inst(expression, images, formula=is_formula)

    # 3 hole counts x 1500 examples x 2 syntactic sorts = 9000 per policy.
    for holes in (0, 1, 2):
        for _ in range(ROUNDS_PER_HOLE_COUNT):
            images = [term(3) for _ in range(holes)]
            for is_formula in (False, True):
                expression = (formula if is_formula else term)(4, holes=holes)
                initial = rng.choice([0, -3, -2000])
                expected = reference.subst(expression, [*images, -holes], formula=is_formula)
                for policy, module in modules.items():
                    module.k = initial
                    actual = opening(module, policy, expression, images, is_formula)
                    require(actual == expected,
                            {'phase': 'opening', 'policy': policy, 'expression': expression,
                             'images': images, 'actual': actual, 'expected': expected})
                    support = negative_leaves(actual)
                    if policy == 'strict':
                        support.extend(value for image in images for value in negative_leaves(image))
                    expected_supply = min(initial, 0, *support)
                    require(module.k == expected_supply,
                            {'phase': 'supply', 'policy': policy, 'actual': module.k,
                             'expected': expected_supply})
                    require(module.inst(actual, formula=is_formula) == actual,
                            {'phase': 'output closedness', 'policy': policy})
                    count = stats[policy]
                    count['formula_comparisons' if is_formula else 'term_comparisons'] += 1
                    count['supply_checks'] += 1
                    count['output_closedness_checks'] += 1

    invalid_terms = (1, 2, True, False, None, 1.0, [], ['s'], ['r', 0, 0],
                     ['s', 1], ['r', 0, 0, 3])
    for policy, module in modules.items():
        for bad in invalid_terms:
            module.k = 0
            try:
                module.inst(['=', bad, 0])
            except Exception:
                stats[policy]['malformed_goal_terms_rejected'] += 1
            else:
                raise AssertionError(('malformed goal accepted', policy, bad))

        for good in (-1, -1000000, ['s', -2], ['r', -7, -1000, ['s', 1]]):
            module.k = 0
            require(module.inst(good, formula=False) == good, ('rigid parameter changed', policy, good))
            require(module.k == min(0, *negative_leaves(good)), ('rigid parameter untracked', policy, good))
            stats[policy]['rigid_parameter_checks'] += 1

    # Positive free indices in images must not become captured beneath an
    # existential, numerical binder, or two-slot recursor update.
    used_matrices = (
        ['=', 1, 0],
        ['ex', ['=', 2, 1]],
        ['u', ['=', 2, 1]],
        ['=', ['r', 0, 0, 3], 0],
    )
    bad_images = (None, True, False, 1, ['s', 1], ['r', 0, 0, 3])
    for policy, module in modules.items():
        for body in used_matrices:
            for bad in bad_images:
                module.k = 0
                try:
                    opening(module, policy, body, [bad], True)
                except Exception:
                    stats[policy]['used_bad_images_rejected'] += 1
                else:
                    raise AssertionError(('bad image captured or accepted', policy, body, bad))

    # An unused annotation is deliberately ignored by demand validation.
    # Strict validation still rejects malformed annotations and registers
    # names in valid annotations even when no substitution slot uses them.
    unused_matrices = (['=', 0, 0], ['ex', ['=', 1, 1]], ['u', ['=', 1, 1]])
    unused_images = (None, True, 1, ['s', 1], -1000000)
    for body in unused_matrices:
        for image in unused_images:
            demand = modules['demand']
            demand.k = 0
            require(opening(demand, 'demand', body, [image], True) == body,
                    ('unused demand image changed matrix', body, image))
            require(demand.k == 0, ('unused demand image registered names', body, image))
            stats['demand']['unused_images_ignored'] += 1
            strict = modules['strict']
            strict.k = 0
            if image == -1000000:
                require(opening(strict, 'strict', body, [image], True) == body,
                        ('unused valid strict image changed matrix', body, image))
                require(strict.k == image, ('unused strict image name not registered', image))
                stats['strict']['unused_valid_images_registered'] += 1
            else:
                try:
                    opening(strict, 'strict', body, [image], True)
                except Exception:
                    stats['strict']['unused_bad_images_rejected'] += 1
                else:
                    raise AssertionError(('unused malformed strict image accepted', body, image))

    # Negative integers are names, never Python negative environment indices.
    for policy, module in modules.items():
        module.k = 0
        images = [['s', 0], 0]
        require(opening(module, policy, -1, images, False) == -1,
                ('negative name aliased an environment entry', policy))
        require(module.k == -1, ('negative name not registered', policy))

    result = {
        'status': 'passed',
        'python': platform.python_version(),
        'seed': SEED,
        'rounds_per_hole_count': ROUNDS_PER_HOLE_COUNT,
        'hole_counts': [0, 1, 2],
        'reference': {
            'path': str(baseline_path.relative_to(ROOT)),
            'sha256': hashlib.sha256(baseline_path.read_bytes()).hexdigest(),
        },
        'kernels': {
            policy: {'path': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
            for policy, path in paths.items()
        },
        'counts': stats,
        'negative_environment_alias_checks': len(modules),
        'scope': 'Deterministic randomized comparison and boundary checks; not a formal proof of checker correctness.',
    }
    output = ROOT / 'results/opening.json'
    output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'counts': stats,
                      'negative_environment_alias_checks': len(modules)}, indent=2))


if __name__ == '__main__':
    run()
