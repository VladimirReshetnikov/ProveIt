"""Independent end-to-end scope audit of the two complete iPRA checkers.

Run: python3 validation/audit.py

Cases are mathematical certificates stored in audit_cases.json. The primary
and demand kernels use different witness policies; expected outcomes are
explicit per case. Each independent check starts with k=0. Three deliberate
UNSOUND mutants are positive controls for capture/freshness attacks, and are
never written as deliverable checkers or used to approve a theorem.
"""
from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
CASE_PATH = ROOT / 'validation/audit_cases.json'
RESULT_PATH = ROOT / 'results/results_audit.json'
PROGRAMS = {'strict': ROOT / 'checker.py', 'demand': ROOT / 'checker_demand.py'}


def load_source(source, name):
    module = {'__name__': name}
    exec(compile(source, name, 'exec'), module)
    return module


def verdict(module, goal, stack):
    module['k'] = 0
    try:
        accepted = bool(module['check'](copy.deepcopy(goal), copy.deepcopy(stack), []))
        return accepted, None, module['k']
    except Exception as exc:
        return False, type(exc).__name__, module['k']


def mutate_once(source, old, new):
    if source.count(old) != 1:
        raise AssertionError('Audit mutation no longer matches exactly once: ' + old)
    return source.replace(old, new, 1)


def main():
    cases = json.loads(CASE_PATH.read_text())
    case_by_name = {case['name']: case for case in cases}
    if len(case_by_name) != len(cases):
        raise AssertionError('Duplicate case names')
    sources = {policy: path.read_text() for policy, path in PROGRAMS.items()}
    modules = {policy: load_source(source, policy + '_audited_checker')
               for policy, source in sources.items()}
    rows = []
    for case in cases:
        row = {'name': case['name']}
        for policy, module in modules.items():
            actual, error, counter = verdict(module, case['goal'], case['proof'])
            expected = case['expected_' + policy]
            row[policy] = {'expected': expected, 'accepted': actual,
                           'exception': error, 'final_counter': counter}
            if actual != expected:
                raise AssertionError(row)
        rows.append(row)

    # These edits intentionally destroy invariants and must make the attacks pass.
    # They are diagnostic controls, not proposed alternative implementations.
    unsafe_fresh = mutate_once(sources['strict'], '        k = min(k, a)\n', '')
    unsafe_capture = mutate_once(sources['strict'],
                                 '[0, inst(t, formula=False)]', '[0, t]')
    mutants = {
        'registration_deleted': load_source(unsafe_fresh, 'unsafe_freshness_mutant'),
        'QE_image_validation_deleted': load_source(unsafe_capture, 'unsafe_capture_mutant')
    }
    control_specs = [
        ('registration_deleted', 'freshness_collision_with_goal_parameter'),
        ('registration_deleted', 'freshness_collision_with_major_only_parameter'),
        ('QE_image_validation_deleted', 'capture_by_illegal_positive_witness')
    ]
    controls = []
    for mutant, name in control_specs:
        case = case_by_name[name]
        accepted, error, counter = verdict(mutants[mutant], case['goal'], case['proof'])
        if not accepted:
            raise AssertionError((mutant, name, accepted, error, counter))
        controls.append({'mutant': mutant, 'attack': name,
                         'unsound_mutant_accepted_attack': accepted})

    # Verify the actual process boundary, including Python's optimization mode.
    cli_names = ['reflexivity_0', 'capture_by_illegal_positive_witness',
                 'freshness_collision_with_goal_parameter',
                 'unused_bad_witness_False', 'wrong_existential_arity']
    cli_rows = []
    with tempfile.TemporaryDirectory(prefix='ipra_audit_') as directory:
        for index, name in enumerate(cli_names):
            case = case_by_name[name]
            certificate = Path(directory) / ('case_' + str(index) + '.json')
            certificate.write_text(json.dumps([case['goal'], case['proof']]) + '\n')
            for policy, program in PROGRAMS.items():
                for optimized in (False, True):
                    command = [sys.executable] + (['-O'] if optimized else [])
                    command += [str(program), str(certificate)]
                    result = subprocess.run(command, capture_output=True, text=True, timeout=15)
                    expected = case['expected_' + policy]
                    wanted_code = 0 if expected else 1
                    wanted_text = 'ACCEPT' if expected else 'REJECT'
                    row = {'name': name, 'policy': policy, 'optimized': optimized,
                           'expected': expected, 'exit_code': result.returncode,
                           'stdout': result.stdout.strip()}
                    if result.returncode != wanted_code or row['stdout'] != wanted_text:
                        row['stderr'] = result.stderr
                        raise AssertionError(row)
                    cli_rows.append(row)

    result = {
        'source_sha256': {policy: hashlib.sha256(source.encode()).hexdigest()
                          for policy, source in sources.items()},
        'case_sha256': hashlib.sha256(CASE_PATH.read_bytes()).hexdigest(),
        'case_count': len(cases), 'checker_executions': len(cases) * len(PROGRAMS),
        'cases': rows, 'positive_controls': controls,
        'cli_executions': len(cli_rows), 'cli_cases': cli_rows,
        'status': 'all expected outcomes matched'
    }
    RESULT_PATH.parent.mkdir(exist_ok=True)
    RESULT_PATH.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in
                      ('case_count', 'checker_executions', 'cli_executions', 'status')},
                     indent=2))


if __name__ == '__main__':
    main()
