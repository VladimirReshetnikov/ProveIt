PRA FROM A SELECTED ADJACENT STEP
Research report prepared for Vladimir Reshetnikov, 1 November 2026.

Start with report.pdf or AXIOMS.txt. report.tex is the complete source.

RESULT
The main presentation has the same nonlogical specification in classical
and intuitionistic first-order logic. It uses only pure product iteration
and one arithmetic certificate schema. After ordinary scalar expansion,
every axiom is universal with a quantifier-free matrix. The report proves
inverse whole-domain term interpretations with matching first-order PRA,
including internal identity round trips. Three direct matrix constructors
form a proper subset of the current product draft's admitted matrix set.

The outer display has 18 nodes under the stated partial metric; the older
P15 display has 15. No new outer-node minimum is claimed. The real reduction
is removal of the quantified progress premise and simplification of the
matrix admission process. The Boolean/witness compiler is fully specified
and is not free in a complete size comparison. Universal axiomatizability
of PRA is known and attributed to primary sources.

A separate scalar result replaces binary K by unary predecessor, with a
short constructive inverse-definition proof and a four-node saving in its
fixed universally closed equations.

FILES
  report.tex / report.pdf       Complete specification and mathematical proofs.
  AXIOMS.txt                   Standalone extractable theory specification.
  build.py                     Rebuild PDF and diagnostics.
  checks/check_witness_compiler.py  Pure typed term compiler and bounded checks.
  checks/check_counts.py       Reproducible partial syntax counts.
  formal/WitnessKernel.lean    Checked constructive logical kernel.
  formal/SCOPE.txt             Exact formal-verification boundary.
  formal/lean-check.log        Eleven empty axiom-dependency reports.
  audit/source_manifest.json   Immutable source identities for all five drafts.
  audit/                      Build, diagnostic, review, and visual records.
  SHA256SUMS.txt               Archive-content checksums (excluding itself).

VERIFICATION SCOPE
The Lean kernel is checked with Lean 4.19.0, without Mathlib. All eleven
theorems report no axiom dependencies. This is not an end-to-end machine
formalization of the arithmetic compiler or bi-interpretation theorem.
The complete interpretation argument is a written mathematical proof.
Python evaluations are bounded diagnostics, not proofs about arbitrary
or nonstandard models. Source draft code and their reported formal checks
were not rerun as part of the baseline review.

REBUILD
  python3 build.py
Optional local Lean recheck:
  python3 build.py --lean /path/to/lean
Requires Python 3.10+ and a pdflatex installation with the packages named
in report.tex. Lean 4.19.0 is needed only for the optional formal recheck.
The build script performs no network activity or package installation.

The final section of the paper lists further research questions.
