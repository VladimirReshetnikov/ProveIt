#!/usr/bin/env python3
"""Pure-product-iterator compiler for quantifier-free tests and local witnesses.

No opaque numerical comparison or conditional occurs in generated terms.
The Python evaluator uses ordinary integers only to check bounded instances.
Finite checks are diagnostics, not an internal formal proof.
"""
from __future__ import annotations
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

N = 'N'
def Prod(a, b): return (a, b)

def V(name, ty=N): return ('var', name, ty)
def Z(): return ('zero',)
def S(t): return ('succ', t)
def P(x, y): return ('pair', x, y)
def Fst(t): return ('fst', t)
def Snd(t): return ('snd', t)
def It(name, n, seed): return ('iter', name, n, seed)

REG = {}
def free(t):
    tag = t[0]
    if tag == 'var': return {t[1]}
    if tag == 'zero': return set()
    if tag in ('succ', 'fst', 'snd'): return free(t[1])
    if tag == 'pair': return free(t[1]) | free(t[2])
    if tag == 'iter': return free(t[2]) | free(t[3])
    raise ValueError(tag)

def refs(t):
    tag = t[0]
    if tag in ('var', 'zero'): return set()
    if tag in ('succ', 'fst', 'snd'): return refs(t[1])
    if tag == 'pair': return refs(t[1]) | refs(t[2])
    if tag == 'iter': return {t[1]} | refs(t[2]) | refs(t[3])
    raise ValueError(tag)

def typ(t):
    tag = t[0]
    if tag == 'var': return t[2]
    if tag == 'zero': return N
    if tag == 'succ':
        if typ(t[1]) != N: raise ValueError('successor type')
        return N
    if tag == 'pair': return Prod(typ(t[1]), typ(t[2]))
    if tag in ('fst', 'snd'):
        ty = typ(t[1])
        if ty == N: raise ValueError('projection type')
        return ty[0 if tag == 'fst' else 1]
    if tag == 'iter':
        if t[1] not in REG: raise ValueError('unknown/forward iterator')
        st = REG[t[1]]['type']
        if typ(t[2]) != N or typ(t[3]) != st:
            raise ValueError('iterator type')
        return st
    raise ValueError(tag)

def var_annotations(t):
    tag = t[0]
    if tag == 'var': return {(t[1], t[2])}
    if tag == 'zero': return set()
    if tag in ('succ', 'fst', 'snd'): return var_annotations(t[1])
    if tag == 'pair': return var_annotations(t[1]) | var_annotations(t[2])
    if tag == 'iter': return var_annotations(t[2]) | var_annotations(t[3])
    raise ValueError(tag)

def register(name, ty, body):
    if name in REG: raise ValueError('duplicate iterator')
    if free(body) - {'v'}: raise ValueError('update has frozen free parameter')
    if any(name != 'v' or vt != ty for name, vt in var_annotations(body)):
        raise ValueError('state-variable annotation mismatch')
    if typ(body) != ty: raise ValueError('update is not an endomorphism')
    # typ above also verifies that all referenced descriptors already exist.
    REG[name] = {'type': ty, 'body': body, 'index': len(REG),
                 'dependencies': sorted(refs(body))}

def subst(t, env):
    tag = t[0]
    if tag == 'var': return env.get(t[1], t)
    if tag == 'zero': return t
    if tag in ('succ', 'fst', 'snd'): return (tag, subst(t[1], env))
    if tag == 'pair': return P(subst(t[1], env), subst(t[2], env))
    if tag == 'iter':
        # Substitution does not enter a stored descriptor.
        return It(t[1], subst(t[2], env), subst(t[3], env))
    raise ValueError(tag)

def ev(t, env):
    tag = t[0]
    if tag == 'var': return env[t[1]]
    if tag == 'zero': return 0
    if tag == 'succ': return ev(t[1], env) + 1
    if tag == 'pair': return (ev(t[1], env), ev(t[2], env))
    if tag == 'fst': return ev(t[1], env)[0]
    if tag == 'snd': return ev(t[1], env)[1]
    if tag == 'iter':
        steps, state = ev(t[2], env), ev(t[3], env)
        for _ in range(steps): state = ev(REG[t[1]]['body'], {'v': state})
        return state
    raise ValueError(tag)

# Fixed helper descriptions, all pure unary updates.
v = V('v')
register('zero', N, Z())
register('succ', N, S(v))
pair_ty = Prod(N, N)
pv = V('v', pair_ty)
register('pred_state', pair_ty, P(S(Fst(pv)), Fst(pv)))
def pred(x): return Snd(It('pred_state', x, P(Z(), Z())))
register('pred', N, pred(v))
def zero_test(x): return It('zero', x, S(Z()))
def add(x, y): return It('succ', y, x)
def sub(x, y): return It('pred', y, x)
def cond(z, yes_zero, yes_nonzero):
    # C(0,a,b)=a and C(Sn,a,b)=b.
    return add(It('zero', z, yes_zero),
               It('zero', zero_test(z), yes_nonzero))
def equal(ty, x, y):
    if ty == N: return zero_test(add(sub(x, y), sub(y, x)))
    left = equal(ty[0], Fst(x), Fst(y))
    right = equal(ty[1], Snd(x), Snd(y))
    return cond(left, Z(), right)

# Formula AST. True tests have numerical value 1, false tests 0.
def Eq(x, y):
    if typ(x) != typ(y): raise ValueError('equality type mismatch')
    return ('eq', x, y)
def Bot(): return ('bot',)
def And(a, b): return ('and', a, b)
def Or(a, b): return ('or', a, b)
def Imp(a, b): return ('imp', a, b)
def Not(a): return Imp(a, Bot())

def fsubst(f, env):
    if f[0] == 'eq': return Eq(subst(f[1], env), subst(f[2], env))
    if f[0] == 'bot': return f
    return (f[0], fsubst(f[1], env), fsubst(f[2], env))

def bit(f):
    tag = f[0]
    if tag == 'bot': return Z()
    if tag == 'eq': return equal(typ(f[1]), f[1], f[2])
    a, b = bit(f[1]), bit(f[2])
    if tag == 'and': return cond(a, Z(), b)
    if tag == 'or': return cond(a, b, S(Z()))
    if tag == 'imp': return cond(a, S(Z()), b)
    raise ValueError(tag)

def fev(f, env):
    tag = f[0]
    if tag == 'bot': return False
    if tag == 'eq': return ev(f[1], env) == ev(f[2], env)
    a, b = fev(f[1], env), fev(f[2], env)
    if tag == 'and': return a and b
    if tag == 'or': return a or b
    if tag == 'imp': return (not a) or b
    raise ValueError(tag)

def witness(name, f, pty=N):
    state_ty = Prod(N, Prod(pty, N))
    st = V('v', state_ty)
    clock, param, oldw = Fst(st), Fst(Snd(st)), Snd(Snd(st))
    test = bit(fsubst(f, {'n': clock, 'a': param}))
    neww = cond(test, oldw, clock)
    update = P(S(clock), P(param, neww))
    register(name, state_ty, update)
    result = It(name, V('n'), P(Z(), P(V('a', pty), Z())))
    return Snd(Snd(result))


def main():
    counts = {'helper_cases': 0, 'boolean_cases': 0, 'witness_cases': 0,
              'invariant_cases': 0, 'rejection_controls': 0}
    for x in range(9):
        if ev(pred(V('x')), {'x': x}) != max(0, x-1): raise AssertionError('pred')
        counts['helper_cases'] += 1
        for y in range(9):
            env = {'x': x, 'y': y}
            for t, expected in [(add(V('x'),V('y')),x+y),
                                (sub(V('x'),V('y')),max(0,x-y)),
                                (equal(N,V('x'),V('y')),int(x==y))]:
                if ev(t,env) != expected: raise AssertionError('helper')
                counts['helper_cases'] += 1
    n, a = V('n'), V('a')
    register('flip', N, zero_test(v))
    parity = It('flip', n, Z())
    atoms = [Eq(n,a), Eq(pred(n),a), Eq(parity,Z()), Eq(add(n,a),S(a))]
    formulas = [Bot(), Eq(n,Z()), *atoms, Not(atoms[0]),
                And(atoms[0],atoms[2]), Or(atoms[0],atoms[2]),
                Imp(atoms[0],atoms[1]), Imp(Or(atoms[0],atoms[2]),atoms[3])]
    # Add the exact guarded normalization used to recover induction.
    delta = Eq(Z(), S(Z()))
    formulas += [Imp(Or(fsubst(f,{'n':Z()}),delta),f) for f in list(formulas)]
    for i,f in enumerate(formulas):
        bf = bit(f)
        wf = witness('w_'+str(i), f)
        if typ(bf) != N or typ(wf) != N: raise AssertionError('output type')
        for av in range(6):
            base = fev(f, {'n':0,'a':av})
            for nv in range(10):
                env = {'n':nv,'a':av}
                truth, bv = fev(f,env), ev(bf,env)
                if bv != int(truth): raise AssertionError('Boolean compiler')
                counts['boolean_cases'] += 1
                wv = ev(wf,env)
                fw = fev(f,{'n':wv,'a':av})
                fsw = fev(f,{'n':wv+1,'a':av})
                if base:
                    if not (fw and ((not fsw) or truth)):
                        raise AssertionError('tracker invariant')
                    if ((not fw) or fsw) and not truth:
                        raise AssertionError('single witness axiom')
                    counts['invariant_cases'] += 1
                if nv > 0:
                    prev = {'n':nv-1,'a':av}
                    expected = nv-1 if fev(f,prev) else ev(wf,prev)
                    if wv != expected: raise AssertionError('tracker recurrence')
                elif wv != 0: raise AssertionError('tracker base')
                counts['witness_cases'] += 1
    # Product-native equality and a product frozen parameter.
    pa = V('a', Prod(N,N))
    f = Or(Eq(P(n,Z()),pa), Eq(n,Fst(pa)))
    wf = witness('w_product', f, Prod(N,N))
    for av in [(x,y) for x in range(4) for y in range(4)]:
        for nv in range(8):
            env={'n':nv,'a':av}
            if ev(bit(f),env) != int(fev(f,env)): raise AssertionError('product eq')
            counts['boolean_cases'] += 1
            wv=ev(wf,env)
            if fev(f,{'n':0,'a':av}):
                fw=fev(f,{'n':wv,'a':av}); fsw=fev(f,{'n':wv+1,'a':av})
                if not (fw and ((not fsw) or fev(f,env))): raise AssertionError('product invariant')
                counts['invariant_cases'] += 1
            counts['witness_cases'] += 1
    for name,ty,body in [('bad_free',N,V('a')),('bad_forward',N,It('missing',Z(),v)),
                         ('bad_type',N,P(v,v)),
                         ('bad_annotation',N,Fst(V('v',Prod(N,N))))]:
        try: register(name,ty,body)
        except ValueError: counts['rejection_controls'] += 1
        else: raise AssertionError('failed rejection')
    for name,desc in REG.items():
        if free(desc['body']) - {'v'}: raise AssertionError('descriptor scope')
        for dep in desc['dependencies']:
            if REG[dep]['index'] >= desc['index']: raise AssertionError('dependency order')
    result={'status':'passed','scope':'finite diagnostics; not a formal proof',
            'counts':counts,'descriptors':len(REG),
            'updates_have_one_state_variable':True,'dependencies_are_strictly_earlier':True,
            'term_primitives':['zero','successor','pair','fst','snd','pure_iterator'],
            'sample_witness_state_type':REG['w_0']['type']}
    target=Path(__file__).with_name('compiler_checks.json')
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__ == '__main__': main()
