#!/usr/bin/env python3
"""Reproduce the explicitly PARTIAL syntax-tree counts in the paper."""
import json
from pathlib import Path

def node(name, *args):
    return (name, *args)

def size(t):
    # Every tuple is one syntax node; names and binder annotations are metadata.
    return 1 + sum(size(a) for a in t[1:])

n, a, zero = node('n'), node('a'), node('0')
succ = lambda x: node('S', x)
eq = lambda x,y: node('=',x,y)
imp = lambda x,y: node('implies',x,y)
alln = lambda x: node('forall_n',x)
alla = lambda x: node('forall_a',x)
F = lambda x,y: node('F',x,y)
w = node('w_F',n,a)
certificate = alln(alla(node('and',F(w,a),imp(F(succ(w),a),F(n,a)))))
single_step = alln(alla(imp(imp(F(w,a),F(succ(w),a)),F(n,a))))
propagation = alla(imp(alln(imp(F(n,a),F(succ(n),a))),alln(F(n,a))))
K0 = alla(eq(node('K',zero,a),a))
KS = alln(alla(eq(node('K',succ(n),a),n)))
p0 = eq(node('p',zero),zero)
pS = alln(eq(node('p',succ(n)),n))
result = {
    'metric': 'partial AST; F and w_F opaque; binders one node; type metadata excluded',
    'certificate_C': size(certificate),
    'single_step_W': size(single_step),
    'baseline_P15': size(propagation),
    'K_fixed_equations': [size(K0),size(KS)],
    'p_fixed_equations': [size(p0),size(pS)],
    'fixed_equation_saving': size(K0)+size(KS)-size(p0)-size(pS),
    'excluded_costs': ['expanded matrices','expanded witness terms','helper definitions',
                       'type grammar','scalar expansion','description/admission compiler']
}
assert (result['certificate_C'],result['single_step_W'],result['baseline_P15']) == (18,18,15)
assert result['K_fixed_equations'] == [6,8]
assert result['p_fixed_equations'] == [4,6]
assert result['fixed_equation_saving'] == 4
Path(__file__).with_name('counts.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
