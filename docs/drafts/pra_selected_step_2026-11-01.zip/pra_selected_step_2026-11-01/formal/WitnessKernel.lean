/-
Constructive logical kernel for the one-step witness presentation of PRA.

This file checks the abstract invariant, its local step, the implication
from the invariant to one-step checking, and recovery of local induction.
It does not formalize first-order syntax, the staged iterator language,
the term compiler, or the complete bi-interpretability proof.

The arithmetic carrier is arbitrary. No use of Nat induction, excluded
middle, or Classical.choice is made. Decidability of the selected matrix
and the relevant induction instance are explicit hypotheses only in the
reverse (soundness) direction. Forward recovery needs neither.
-/

namespace WitnessKernel

universe u v

variable {N : Type u} {P : Type v}

def Invariant (S : N → N) (F : N → P → Prop)
    (w : N → P → N) (n : N) (a : P) : Prop :=
  F (w n a) a ∧ (F (S (w n a)) a → F n a)

theorem invariant_base
    (z : N) (S : N → N) (F : N → P → Prop) (w : N → P → N)
    (base : ∀ a, F z a)
    (w_zero : ∀ a, w z a = z) :
    ∀ a, Invariant S F w z a := by
  intro a
  constructor
  · rw [w_zero a]
    exact base a
  · intro _
    exact base a

theorem invariant_step
    (S : N → N) (F : N → P → Prop) (w : N → P → N)
    (decF : ∀ n a, Decidable (F n a))
    (when_true : ∀ n a, F n a → w (S n) a = n)
    (when_false : ∀ n a, ¬ F n a → w (S n) a = w n a) :
    ∀ n a, Invariant S F w n a → Invariant S F w (S n) a := by
  intro n a inv
  cases decF n a with
  | isTrue hn =>
      change F (w (S n) a) a ∧ (F (S (w (S n) a)) a → F (S n) a)
      rw [when_true n a hn]
      exact And.intro hn (fun h => h)
  | isFalse hn =>
      change F (w (S n) a) a ∧ (F (S (w (S n) a)) a → F (S n) a)
      rw [when_false n a hn]
      exact And.intro inv.left (fun h => False.elim (hn (inv.right h)))

theorem one_step_from_invariant
    (S : N → N) (F : N → P → Prop) (w : N → P → N)
    (n : N) (a : P) (inv : Invariant S F w n a) :
    (F (w n a) a → F (S (w n a)) a) → F n a := by
  intro local_step
  exact inv.right (local_step inv.left)

theorem certificate_soundness_from_induction
    (z : N) (S : N → N) (F : N → P → Prop) (w : N → P → N)
    (decF : ∀ n a, Decidable (F n a))
    (base : ∀ a, F z a)
    (w_zero : ∀ a, w z a = z)
    (when_true : ∀ n a, F n a → w (S n) a = n)
    (when_false : ∀ n a, ¬ F n a → w (S n) a = w n a)
    (induction_for_invariant :
      (∀ a, Invariant S F w z a) →
      (∀ n a, Invariant S F w n a → Invariant S F w (S n) a) →
      ∀ n a, Invariant S F w n a) :
    ∀ n a, Invariant S F w n a := by
  exact induction_for_invariant
    (invariant_base z S F w base w_zero)
    (invariant_step S F w decF when_true when_false)

theorem soundness_from_induction
    (z : N) (S : N → N) (F : N → P → Prop) (w : N → P → N)
    (decF : ∀ n a, Decidable (F n a))
    (base : ∀ a, F z a)
    (w_zero : ∀ a, w z a = z)
    (when_true : ∀ n a, F n a → w (S n) a = n)
    (when_false : ∀ n a, ¬ F n a → w (S n) a = w n a)
    (induction_for_invariant :
      (∀ a, Invariant S F w z a) →
      (∀ n a, Invariant S F w n a → Invariant S F w (S n) a) →
      ∀ n a, Invariant S F w n a) :
    ∀ n a, (F (w n a) a → F (S (w n a)) a) → F n a := by
  have inv := induction_for_invariant
    (invariant_base z S F w base w_zero)
    (invariant_step S F w decF when_true when_false)
  intro n a
  exact one_step_from_invariant S F w n a (inv n a)

/- A stationary matrix is extracted by implication reflexivity.
   The witness and its equations disappear completely in this case. -/
theorem stationary_extraction
    (C : P → Prop) (schema : ∀ a, ((C a → C a) → C a)) :
    ∀ a, C a := by
  intro a
  exact schema a (fun h => h)

theorem stationary_certificate_extraction
    (z : N) (C : P → Prop)
    (certificates : ∀ _n : N, ∀ a, C a ∧ (C a → C a)) :
    ∀ a, C a := by
  intro a
  exact (certificates z a).left

/- This is the forward direction of the proposed presentation.
   W is completely arbitrary. In particular, neither its equations nor
   any decidability or induction assumption is used. -/
theorem local_induction_from_guarded_instances
    (z : N) (S : N → N) (A : N → P → Prop)
    (delta : Prop) (W : N → P → N)
    (instances : ∀ n a,
      (((A z a ∨ delta) → A (W n a) a) →
       ((A z a ∨ delta) → A (S (W n a)) a)) →
      ((A z a ∨ delta) → A n a)) :
    ∀ a, A z a → (∀ n, A n a → A (S n) a) → ∀ n, A n a := by
  intro a base step n
  have guarded : (A z a ∨ delta) → A n a :=
    instances n a (by
      intro current guard
      exact step (W n a) (current guard))
  exact guarded (Or.inl base)

theorem local_induction_from_guarded_certificates
    (z : N) (S : N → N) (A : N → P → Prop)
    (delta : Prop) (W : N → P → N)
    (certificates : ∀ n a,
      ((A z a ∨ delta) → A (W n a) a) ∧
      (((A z a ∨ delta) → A (S (W n a)) a) →
       ((A z a ∨ delta) → A n a))) :
    ∀ a, A z a → (∀ n, A n a → A (S n) a) → ∀ n, A n a := by
  intro a base step n
  have cert := certificates n a
  have next : (A z a ∨ delta) → A (S (W n a)) a := by
    intro guard
    exact step (W n a) (cert.left guard)
  exact cert.right next (Or.inl base)

theorem separation_from_stationary_guard
    (delta : Prop)
    (schema : (((False ∨ delta) → False) →
                 ((False ∨ delta) → False)) →
                ((False ∨ delta) → False)) :
    ¬ delta := by
  intro hd
  exact schema (fun h => h) (Or.inr hd)

theorem separation_from_stationary_certificate
    (delta : Prop)
    (certificate : ((False ∨ delta) → False) ∧
      (((False ∨ delta) → False) → ((False ∨ delta) → False))) :
    ¬ delta := by
  intro hd
  exact certificate.left (Or.inr hd)

#print axioms invariant_base
#print axioms invariant_step
#print axioms one_step_from_invariant
#print axioms certificate_soundness_from_induction
#print axioms soundness_from_induction
#print axioms stationary_extraction
#print axioms stationary_certificate_extraction
#print axioms local_induction_from_guarded_instances
#print axioms local_induction_from_guarded_certificates
#print axioms separation_from_stationary_guard
#print axioms separation_from_stationary_certificate

end WitnessKernel
