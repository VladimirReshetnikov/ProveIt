#!/usr/bin/env python3
"""Rebuild paper and diagnostics; optionally recheck the Lean kernel.

Usage: python3 build.py [--lean /path/to/lean]
Dependencies: Python 3.10+, pdflatex; Lean 4.19.0 only for --lean.
No downloads, package installation, or network access are performed.
"""
from pathlib import Path
import argparse, hashlib, json, shutil, subprocess, sys

root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--lean', help='Lean executable (version 4.19.0 recommended)')
args=parser.parse_args()
audit=root/'audit'
audit.mkdir(exist_ok=True)
receipt={'python':sys.version.split()[0], 'checks':[], 'latex_passes':3,
         'lean_rechecked':False}

def run(cmd, logfile):
    p=subprocess.run(cmd,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (audit/logfile).write_text(p.stdout)
    if p.returncode:
        print(p.stdout[-6000:])
        raise SystemExit(f'Failed ({p.returncode}): {cmd[0]}; see audit/{logfile}')
    return p.stdout

for script, result in [('check_witness_compiler.py','compiler_checks.json'),
                       ('check_counts.py','counts.json')]:
    run([sys.executable,str(root/'checks'/script)],script.removesuffix('.py')+'.log')
    shutil.copyfile(root/'checks'/result,audit/result)
    receipt['checks'].append(script)

for i in range(1,4):
    run(['pdflatex','-interaction=nonstopmode','-halt-on-error','report.tex'],f'latex_pass_{i}.log')
log=(root/'report.log').read_text()
receipt['overfull_boxes']=log.count('Overfull')
receipt['undefined_references']='There were undefined references' in log
receipt['pdf_bytes']=(root/'report.pdf').stat().st_size
if receipt['overfull_boxes'] or receipt['undefined_references']:
    raise SystemExit('PDF requires review: overfull boxes or undefined references.')

if args.lean:
    version=run([args.lean,'--version'],'lean_version.log').strip()
    checked=run([args.lean,str(root/'formal'/'WitnessKernel.lean')],'lean_rebuild.log')
    if checked.count('does not depend on any axioms') != 11:
        raise SystemExit('Unexpected Lean axiom-dependency output; inspect audit/lean_rebuild.log')
    receipt['lean_rechecked']=True
    receipt['lean_version']=version
    receipt['lean_theorems_with_empty_axiom_dependencies']=11

receipt['report_tex_sha256']=hashlib.sha256((root/'report.tex').read_bytes()).hexdigest()
receipt['lean_source_sha256']=hashlib.sha256((root/'formal'/'WitnessKernel.lean').read_bytes()).hexdigest()
(audit/'build_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
