"""Recount the entire trusted checker and the pinned comparison sources.

This program is outside the trusted proof checker.  Run with Python 3.11+
from any directory.  Results and LaTeX tables are written next to it.
"""

import ast
import hashlib
import io
import json
import platform
from pathlib import Path
import tokenize

ROOT = Path(__file__).resolve().parent
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL,
           tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
OWNERS = (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)


def metrics(path):
    raw = path.read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, OWNERS) and node.body:
            first = node.body[0]
            if (isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant)
                    and isinstance(first.value.value, str)):
                spans.append(((first.lineno, first.col_offset),
                              (first.end_lineno, first.end_col_offset)))
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(source).readline)
              if t.type not in IGNORED and not any(
                  start <= t.start and t.end <= end for start, end in spans)]

    class RemoveDocstrings(ast.NodeTransformer):
        def generic_visit(self, node):
            super().generic_visit(node)
            if isinstance(node, OWNERS) and node.body:
                first = node.body[0]
                if (isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant)
                        and isinstance(first.value.value, str)):
                    node.body.pop(0)
            return node

    tree = RemoveDocstrings().visit(tree)
    normalized = ast.unparse(tree) + '\n'
    norm_tokens = [t for t in tokenize.generate_tokens(io.StringIO(normalized).readline)
                   if t.type not in IGNORED]
    return {'tokens': len(tokens), 'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'normalized_bytes': len(normalized.encode()), 'raw_bytes': len(raw),
            'normalized_tokens': len(norm_tokens),
            'token_characters': sum(len(t.string) for t in tokens),
            'imports': [ast.unparse(n) for n in tree.body
                        if isinstance(n, (ast.Import, ast.ImportFrom))],
            'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    inventory = json.loads((ROOT / 'comparison/inventory.json').read_text())
    rows = []
    cache = {}
    for row in inventory['sources']:
        path = ROOT / 'comparison' / row['copied_source']
        if row['sha256'] not in cache:
            cache[row['sha256']] = metrics(path)
        measured = cache[row['sha256']]
        if measured['sha256'] != row['sha256']:
            raise ValueError('comparison source hash mismatch: ' + str(path))
        rows.append({**row, **measured})
    main_rows = sorted((r for r in rows if r['main_archive']), key=lambda r: r['tokens'])
    if len(main_rows) != 6:
        raise ValueError('expected the six current primary checkers')
    for r in main_rows:
        if set(r['imports']) != {'import json', 'import sys'}:
            raise ValueError('a primary checker has an uncounted custom dependency')
    candidate = metrics(ROOT / 'checker.py')
    if set(candidate['imports']) != {'import json', 'import sys'}:
        raise ValueError('candidate trusted dependency boundary changed')
    keys = ('tokens', 'ast_nodes', 'normalized_bytes')
    minimum = {k: min(r[k] for r in rows) for k in keys}
    primary_minimum = {k: min(r[k] for r in main_rows) for k in keys}
    if minimum != primary_minimum:
        raise ValueError('broader inventory lowered a primary minimum; update report')
    if not all(candidate[k] < minimum[k] for k in keys):
        raise ValueError('candidate no longer improves every reported measure')
    controls = {}
    control_dir = ROOT / 'controls'
    if control_dir.exists():
        controls = {p.name: metrics(p) for p in sorted(control_dir.glob('*.py'))}
    result = {'python': platform.python_version(), 'commit': inventory['commit'],
              'candidate': candidate, 'minimum': minimum,
              'main_checkers': main_rows, 'broader_inventory_count': len(rows),
              'unique_source_count': len(cache), 'controls': controls,
              'broader_inventory': rows}
    (ROOT / 'comparison/metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    macros = {'NewTokens': candidate['tokens'], 'NewAST': candidate['ast_nodes'],
              'NewNorm': candidate['normalized_bytes'], 'NewRaw': candidate['raw_bytes']}
    (ROOT / 'measurements.tex').write_text(''.join(
        '\\newcommand{\\' + name + '}{' + f'{value:,}' + '}\n'
        for name, value in macros.items()))
    labels = {
        'ipra_composed_kernel_2026-11-06.zip': 'Composed',
        'ipra_compact_2026-11-06.zip': 'Compact',
        'ipra_factored_kernel_2026-11-06.zip': 'Factored',
        'ipra_combined_kernel_2026-11-06.zip': 'Combined',
        'ipra_compact_kernel_2026-11-06.zip': 'Compact kernel',
        'ipra_compact_kernel_2026-11-06(1).zip': 'Compact kernel (1)'}
    table = ['\\begin{tabular}{@{}lrrr@{}}', '\\toprule',
             'Complete checker & Tokens & AST nodes & Normalized bytes\\\\', '\\midrule']
    for r in main_rows:
        table.append(labels[r['main_archive']] + ' & ' + ' & '.join(
            f'{r[k]:,}' for k in keys) + '\\\\')
    table += ['\\midrule', 'New explicit-falsity checker & ' + ' & '.join(
        '\\textbf{' + f'{candidate[k]:,}' + '}' for k in keys) + '\\\\',
        '\\bottomrule', '\\end{tabular}']
    (ROOT / 'comparison_table.tex').write_text('\n'.join(table) + '\n')
    print(json.dumps({'candidate': candidate, 'minimum': minimum,
                      'inventory_paths': len(rows), 'unique_sources': len(cache)}, indent=2))


if __name__ == '__main__':
    main()
