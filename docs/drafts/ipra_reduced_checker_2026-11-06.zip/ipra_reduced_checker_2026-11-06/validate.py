"""Offline regression and independent-baseline cross-checks.

Every accepted candidate is expanded into the separately implemented,
verbatim fused K checker.  The numerical axioms and witness introductions
therefore pass through the older contextual numerical and ordinary Sigma
rules.  These finite tests are not a machine formalization of soundness.
Neither checker imports this module or the untrusted compiler.
"""

from pathlib import Path
import hashlib
import json
import subprocess
import sys
import platform

import checker as k
import translate as tr

ROOT = Path(__file__).resolve().parent
OLD = tr.old
ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError)
Z = k.ZERO
T = ["=", Z, Z]
F = ["=", Z, ["s", Z]]
BOTTOM = ["false"]


def json_value(value):
    return json.loads(json.dumps(value))


def eq(s, t):
    return ["=", s, t]


def source_wrap(source, witness):
    """An ordinary Sigma-I wrapper, checked by the original kernel."""
    goal = OLD.freeze(source["goal"])
    principal = ("sig", OLD.shift(goal), ("=", 0, 0))
    result = {"assumptions": source["assumptions"], "goal": principal,
              "proof": ("pair", principal, witness, OLD.freeze(source["proof"]),
                        tr.old_reflexivity(witness))}
    OLD.check(result)
    return result


def direct_positive_cases():
    yield "identity", [[], ["pi", ["false"], ["false"]],
                       ["pi", ["false"], ["hyp", ["false"]]]]
    yield "derived_reflexivity", [[], eq(0, 0), tr.reflexivity(0)]
    large = 10**50
    yield "large_free_parameter", [[eq(large, Z)], eq(large, Z),
                                   ["hyp", eq(large, Z)]]
    yield "bridge_false_to_clash", [[BOTTOM], F, ["bridge", ["hyp", BOTTOM]]]
    yield "bridge_clash_to_false", [[F], BOTTOM, ["bridge", ["hyp", F]]]
    yield "bridge_round_trip", [[BOTTOM], BOTTOM,
                                ["bridge", ["bridge", ["hyp", BOTTOM]]]]
    yield "transport_of_false", [[T, BOTTOM], BOTTOM,
                                ["use", ["hyp", T], BOTTOM, ["hyp", BOTTOM]]]
    sigma = ["sig", T, T]
    yield "sigma_elimination_to_false", [[BOTTOM, sigma], BOTTOM,
                                        ["use", ["hyp", sigma], BOTTOM,
                                         ["hyp", BOTTOM]]]
    # A malformed lookup key can be Python-equal to a stored valid formula.
    # The checker deliberately returns that stored formula.  It must not
    # return the key; the latter would violate the formation invariant.
    yield "lookup_returns_stored_formula", [[eq(1, Z)], eq(1, Z),
                                            ["hyp", eq(True, Z)]]
    witness = ["r", ["s", 3], 4, ["r", 1, 0, ["s", 0]]]
    guard = eq(0, k.shift(witness))
    yield "witness_equation_is_available", [[], ["sig", guard, guard],
                                            ["pair", witness,
                                             ["hyp", guard], ["hyp", guard]]]

    # Obtain expected schema conclusions from derivations in original K,
    # not from the candidate's numerical generator.
    templates = [
        ("=", 0, 0),
        ("=", ("r", 0, 1, ("s", 0)), 2),
        OLD.CLASH,
        OLD.FALSE,
        ("pi", ("=", 0, 1), ("=", 1, 2)),
        ("sig", ("=", 0, 1), ("pi", ("=", 2, 0), ("=", 3, 2))),
        ("pi", ("sig", ("=", 0, 2), ("=", 1, 3)),
         ("=", ("r", 1, 2, ("r", 1, 0, ("s", 0))), 0)),
        ("pi", OLD.FALSE, ("sig", OLD.FALSE, ("=", 0, 0))),
    ]
    for context_size in (0, 2):
        context = tuple(("=", i, OLD.ZERO) for i in range(context_size))
        for i, template in enumerate(templates):
            derivation = tr.expand_numerical(template, context_size)
            expected = OLD.infer(derivation, context)
            source = {"assumptions": context, "goal": expected, "proof": derivation}
            OLD.check(json_value(source))
            yield f"numerical_schema_{i}_context_{context_size}", [
                tr.encode(context), tr.encode(expected), ["nat", tr.encode(template)]]



def additional_negative_cases():
    # Falsity is now a genuine independent syntax constructor.  The bridge
    # is explicit; syntactic matching must not silently identify the two.
    yield "bottom_has_no_implicit_conversion", [[BOTTOM], BOTTOM, ["hyp", F]]
    yield "bridge_wrong_source", [[T], BOTTOM, ["bridge", ["hyp", T]]]
    yield "bridge_wrong_target", [[F], F, ["bridge", ["hyp", F]]]
    yield "false_is_not_use_principal", [[BOTTOM, T], T,
                                        ["use", ["hyp", BOTTOM], Z, ["hyp", T]]]
    # These specifically test the shared signature and explicit annotation
    # formation checks, where a zip truncation or coercion would be unsafe.
    malformed = [
        ("extra_equality_child", ["=", 0, Z, Z]),
        ("missing_pi_child", ["pi", T]),
        ("extra_pi_child", ["pi", T, T, T]),
        ("unknown_template_constructor", ["unknown", 0, Z]),
        ("dictionary_template", {"=": 0}),
        ("extra_false_child", ["false", Z]),
    ]
    for name, template in malformed:
        yield name, [[T], T, ["use", ["hyp", T], template, ["hyp", T]]]


def ensure(condition, message):
    if not condition:
        raise AssertionError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_provenance():
    metadata = json.loads((ROOT / "validation" / "provenance.json").read_text())
    for record in metadata["files"]:
        ensure(digest(ROOT / record["local_path"]) == record["sha256"],
               ("changed preserved source", record["local_path"]))
    return len(metadata["files"])


def main():
    provenance_count = verify_provenance()
    positive = []
    negative = []
    cli_files = []
    output = ROOT / "certificates"
    output.mkdir(exist_ok=True)

    def save(name, data, accepted):
        path = output / (name.replace("/", "_") + ".json")
        path.write_text(json.dumps(data, separators=(",", ":")) + "\n")
        cli_files.append((path, accepted))

    def accept(name, data, save_file=False):
        data = json_value(data)
        k.check(data)
        expanded = tr.backward_certificate(data)
        # These are literal formula/context equalities after representation
        # conversion of zero only.  Genuine falsity remains ["false"].
        ensure(tr.encode(expanded["goal"]) == data[1],
               ("expanded goal changed", name))
        ensure(tr.encode(expanded["assumptions"]) == data[0],
               ("expanded context changed", name))
        recompiled = tr.certificate(expanded)
        ensure(recompiled[:2] == data[:2], ("recompiled sequent changed", name))
        positive.append(name)
        if save_file:
            save(name, data, True)

    def reject(name, data, save_file=True):
        data = json_value(data)
        try:
            k.check(data)
        except ERRORS:
            pass
        else:
            raise AssertionError(("negative accepted", name))
        negative.append(name)
        if save_file:
            save("reject/" + name, data, False)

    inherited = []
    for folder in ("baseline", "stress"):
        paths = sorted((ROOT / "validation" / folder).glob("*.json"))
        expected = 53 if folder == "baseline" else 6
        ensure(len(paths) == expected, ("wrong fixture count", folder, len(paths)))
        for path in paths:
            source = json.loads(path.read_text())
            translated = tr.certificate(source)
            ensure(translated[0] == tr.encode(source["assumptions"])
                   and translated[1] == tr.encode(source["goal"]),
                   ("forward sequent changed", path.name))
            name = folder + "/" + path.stem
            accept(name, translated, save_file=True)
            inherited.append((name, source))
            # One and two extra witness binders stress local Pi/Sigma
            # assumptions, induction hypotheses, and both recursion slots.
            wrapped = source
            for depth, witness in enumerate((13, ("r", ("s", 2), 5,
                                                   ("r", 1, 0, ("s", 0)))), 1):
                wrapped = source_wrap(wrapped, witness)
                accept(f"wrapped_{depth}/{name}", tr.certificate(wrapped))

    for name, source in inherited:
        # Instantiate every free parameter by a dependent nested recursor.
        # Environments are lifted independently under local proof binders.
        env = lambda i: ["r", ["s", i + 2], i + 5, ["r", 1, 0, ["s", 0]]]
        context = tuple(map(OLD.freeze, source["assumptions"]))
        target = [[tr.expression(a, env) for a in context],
                  tr.expression(OLD.freeze(source["goal"]), env),
                  tr.translate(OLD.freeze(source["proof"]), context, env)]
        accept("substitution/" + name, target)

    for name, data in direct_positive_cases():
        accept("direct/" + name, data, save_file=True)

    inherited_negatives = sorted((ROOT / "validation" / "inherited_negative").glob("*.json"))
    ensure(len(inherited_negatives) == 45, "expected 45 applicable preserved negatives")
    for path in inherited_negatives:
        reject("inherited/" + path.stem, json.loads(path.read_text()))
    for name, data in additional_negative_cases():
        reject("signature_and_bottom/" + name, data)

    rejected_source = []
    for path in sorted((ROOT / "validation" / "invalid_baseline").glob("*.json")):
        try:
            tr.certificate(json.loads(path.read_text()))
        except ERRORS:
            rejected_source.append(path.name)
        else:
            raise AssertionError(("invalid source survived compiler", path.name))
    # The compiler checks the whole source before using any simplification,
    # including the constant-bottom numerical-rule shortcut.
    for name, source in [
        ("invalid_bridge", {"assumptions": [("=", OLD.ZERO, OLD.ZERO)],
          "goal": OLD.FALSE, "proof": ("bridge", ("hyp", 0))}),
        ("bad_discarded_bottom_step", {"assumptions": [OLD.FALSE],
          "goal": OLD.FALSE, "proof": ("nat", OLD.FALSE, OLD.ZERO,
          ("hyp", 0), ("hyp", 99))})]:
        try:
            tr.certificate(json_value(source))
        except ERRORS:
            rejected_source.append(name)
        else:
            raise AssertionError(("invalid source survived", name))

    for path, expected in cli_files:
        for optimized in (False, True):
            command = [sys.executable, *(["-O"] if optimized else []),
                       str(ROOT / "checker.py"), str(path)]
            result = subprocess.run(command, text=True, capture_output=True)
            ensure(result.returncode == (0 if expected else 1)
                   and result.stdout.strip() == ("ACCEPT" if expected else "REJECT")
                   and not result.stderr,
                   ("CLI", path.name, optimized, result.returncode,
                    result.stdout, result.stderr))

    summary = {
        "status": "PASS",
        "python": platform.python_version(),
        "checker_sha256": digest(ROOT / "checker.py"),
        "translator_sha256": digest(ROOT / "translate.py"),
        "baseline_sha256": digest(ROOT / "validation" / "baseline_checker.py"),
        "preserved_files_hash_verified": provenance_count,
        "baseline_original_certificates": 53,
        "inherited_binding_stress_certificates": 6,
        "wrapped_certificates": 2 * len(inherited),
        "numerical_substitution_certificates": len(inherited),
        "additional_direct_candidate_certificates": len(positive) - 4 * len(inherited),
        "candidate_positive_certificates": len(positive),
        "independent_baseline_expansion_checks": len(positive),
        "candidate_recompilation_checks": len(positive),
        "exact_sequent_round_trips": len(positive),
        "candidate_negative_certificates": len(negative),
        "invalid_sources_rejected_before_compilation": len(rejected_source),
        "saved_candidate_certificate_files": len(cli_files),
        "normal_and_optimized_cli_checks": 2 * len(cli_files),
        "positive_names": positive,
        "negative_names": negative,
        "rejected_source_names": rejected_source,
        "scope": "Finite executable regressions, bidirectional compiler checks, and replay in the preserved baseline. Every accepted candidate expands and recompiles with exactly the same assumptions and conclusion, including genuine falsity. No Lean/Rocq formalization or universal machine-checked soundness theorem is claimed.",
    }
    (ROOT / "validation" / "results.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({key: value for key, value in summary.items()
                      if not key.endswith("_names")}, indent=2))


if __name__ == "__main__":
    main()
