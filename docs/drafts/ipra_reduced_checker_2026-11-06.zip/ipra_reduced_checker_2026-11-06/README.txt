A SMALLER EXPLICIT-FALSITY CHECKER FOR iPRA
Prepared for Vladimir Reshetnikov, 6 November 2026

RESULT
The complete checker has 938 significant Python source tokens, 998
executable AST nodes, and 2,968 normalized source bytes. The corresponding
minima of the six current ProveIt drafts are 957, 1,013, and 3,127.
The comparison is pinned to commit:
36fb791c722edc2549719744c38feef74fa422fb

The mathematical theory is bi-interpretable and equiconsistent with full
intuitionistic first-order primitive recursive arithmetic with all fixed
primitive-recursive descriptions and quantifier-free induction, including
parameters. Genuine falsity is explicit. Both internal interpretation
round trips use the entire number domain. See report.pdf for complete
axioms, schemas, rules, derivations, and the precise ordinary first-order
realization of the compact native syntax.

The result improves this finite implementation frontier. It is not an
absolute shortest-program theorem. Written metatheoretic proofs and
executable tests are provided; no Lean/Rocq formalization is claimed.

START HERE
  report.pdf             Compiled research paper.
  report.tex             Main LaTeX source.
  implementation.tex     Checker specification and correctness proof.
  validation.tex         Comparison, validation evidence, and reproduction.
  checker.py             Entire trusted acceptance program, 3,330 bytes.
  examples/              One accepted and one rejected complete certificate.

The source checker imports only Python's standard json and sys modules.
No other file in this package is consulted when checking a certificate.

CHECK A PROOF
  python3 checker.py examples/reflexivity.json
  python3 checker.py examples/rejected_false.json

The first prints ACCEPT and exits 0; the second prints REJECT and exits 1.
A certificate is [assumptions, goal, proof]. An empty assumptions list is
required for an unconditional theorem. The integer -1 encodes the number
zero; nonnegative integer leaves are variable indices, not numerals.
Number one is ["s", -1]. Falsity is ["false"], distinct from ["=",-1,["s",-1]].

REPRODUCE WITHOUT NETWORK ACCESS
  python3 measure.py
  python3 validate.py
  python3 audit/audit_candidate.py
  python3 verify_controls.py
  python3 build.py

Python 3.10+ supports the syntax. Measurements were recorded with Python
3.12.14; use that version for identical AST normalization. No pip package is
needed. Rebuilding the PDF additionally needs pdflatex and the standard
LaTeX packages listed in report.tex. The supplied PDF is already compiled.

build.py runs all four verification commands, compiles the PDF twice,
writes a SHA-256 manifest, and creates a ZIP next to this directory.
Use --pdf-only after a prose/layout-only change to avoid rerunning tests.

VERIFICATION ARTIFACTS
  translate.py           Untrusted proof compiler in both directions.
  validate.py            262 positive certificates, exact round trips,
                         55 negative candidates, 30 invalid sources,
                         280 normal/optimized CLI executions.
  validation/            Independently implemented preserved baseline,
                         source fixtures, hashes, provenance, and results.
  certificates/          140 generated positive/negative certificates.
  audit/                 Independent grammar and named-variable binding
                         oracle; 716 checks, 77 accepted and 209 rejected
                         certificate inputs; all accepts replayed in baseline.
  controls/              Two one-change implementation controls; both match
                         the 426 saved outcomes from the two suites.
  comparison/            Exact comparison source snapshots and measurements:
                         253 inventoried paths, 82 distinct source files.
  manifest.json          Hashes for every delivered file except itself.

To translate a supplied baseline certificate:
  python3 translate.py INPUT.json OUTPUT.json
To expand a new certificate back to the preserved baseline:
  python3 translate.py --backward INPUT.json OUTPUT.json
Both source and output are independently checked; the candidate never
imports the compiler or the baseline checker.

PROVENANCE AND CREDIT
The mathematics and several kernel reductions build on the six proposals
in VladimirReshetnikov/ProveIt/docs/drafts at the pinned commit. The current
checker consolidates constructor formation and variable binding in one
finite signature, with a uniform explicit annotation check. It preserves
the earlier useful reductions: two guarded binders, witness-equation pair
introduction, shared elimination, packaged numerical axioms, and derived
reflexivity/explosion. Detailed sources are credited in the paper; exact
comparison source copies and per-file hashes are included.

TEST LIMITS
Finite tests and replay in a second checker support the implementation;
they do not replace a universally quantified soundness proof. That proof,
the arithmetic reconstruction, and bi-interpretability are written in the
paper. Host memory/recursion limits can prevent processing very large
valid certificates, as with the predecessor implementations.
