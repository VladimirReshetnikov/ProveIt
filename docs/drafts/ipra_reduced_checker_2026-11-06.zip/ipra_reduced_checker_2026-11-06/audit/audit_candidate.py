"""Independent focused audit of the shared-signature iPRA checker.

No mathematical-checker implementation function is used to compute expected
binding operations, numerical schemas, or recursion reductions.  A separate
named-variable representation supplies those expectations.  Every accepted
certificate is also expanded by the untrusted reverse compiler and checked
by its preserved independent kernel.  These are finite tests, not a formal
verification of the universal metatheorems.
"""

import argparse
import copy
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import subprocess
import sys


HERE = Path(__file__).resolve().parent
ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError)
Z = -1
F = ["false"]
T = ["=", Z, Z]
D = ["=", Z, ["s", Z]]
COUNTER = itertools.count()


def eq(a, b):
    return ["=", a, b]


def suc(a):
    return ["s", a]


def rec(n, seed, body):
    return ["r", n, seed, body]


def pi(a, b):
    return ["pi", a, b]


def sig(a, b):
    return ["sig", a, b]


def hyp(a):
    return ["hyp", a]


def oracle_wf(a, formula=False):
    """Explicit formation cases; no signature-table lookup."""
    if type(a) is int:
        return not formula and a >= -1
    if type(a) is not list:
        return False
    match a:
        case ["s", t]:
            return not formula and oracle_wf(t)
        case ["r", n, t, h]:
            return not formula and all(oracle_wf(x) for x in (n, t, h))
        case ["=", s, t]:
            return formula and oracle_wf(s) and oracle_wf(t)
        case ["false"]:
            return formula
        case [("pi" | "sig"), a, b]:
            return formula and oracle_wf(a, True) and oracle_wf(b, True)
        case _:
            return False


def to_names(a, bound=()):
    """Protect each binder with a globally fresh name."""
    if type(a) is int:
        if a == Z:
            return ("zero",)
        if a < len(bound):
            return ("bound", bound[a])
        return ("free", a - len(bound))
    match a:
        case ["s", t]:
            return ("s", to_names(t, bound))
        case ["r", n, seed, body]:
            state, counter = next(COUNTER), next(COUNTER)
            return ("r", state, counter, to_names(n, bound),
                    to_names(seed, bound),
                    to_names(body, (state, counter, *bound)))
        case ["=", s, t]:
            return ("=", to_names(s, bound), to_names(t, bound))
        case ["false"]:
            return ("false",)
        case [("pi" | "sig") as tag, a, b]:
            witness = next(COUNTER)
            env = (witness, *bound)
            return (tag, witness, to_names(a, env), to_names(b, env))
        case _:
            raise ValueError("malformed oracle input")


def from_names(a, bound=()):
    match a:
        case ("zero",):
            return Z
        case ("bound", name):
            return bound.index(name)
        case ("free", index):
            return len(bound) + index
        case ("s", t):
            return suc(from_names(t, bound))
        case ("r", state, counter, n, seed, body):
            return rec(from_names(n, bound), from_names(seed, bound),
                       from_names(body, (state, counter, *bound)))
        case ("=", s, t):
            return eq(from_names(s, bound), from_names(t, bound))
        case ("false",):
            return ["false"]
        case (("pi" | "sig") as tag, witness, a, b):
            env = (witness, *bound)
            return [tag, from_names(a, env), from_names(b, env)]
        case _:
            raise ValueError("malformed named oracle input")


def replace_free(a, env):
    if a[0] == "free":
        return env(a[1])
    return tuple(replace_free(x, env) if type(x) is tuple else x for x in a)


def oshift(a, count=1):
    return from_names(replace_free(to_names(a), lambda i: ("free", i + count)))


def osubst(a, env):
    return from_names(replace_free(to_names(a), lambda i: to_names(env(i))))


def oinst(a, t):
    return osubst(a, lambda i: t if i == 0 else i - 1)


def numerical(matrix, force_induction=False):
    base = oinst(matrix, Z)
    guard = matrix if matrix[0] == "=" or force_induction else oshift(base)
    successor = osubst(matrix, lambda i: suc(0) if i == 0 else i)
    step = pi(guard, successor)
    return pi(sig(oshift(base, 2), oshift(step, 2)), matrix)


def orec_equation(r):
    _, n, seed, body = r
    if n == Z:
        value = seed
    else:
        k = n[1]
        value = osubst(body, lambda i: rec(k, seed, body) if i == 0 else
                       k if i == 1 else i - 2)
    return eq(r, value)


def reflexivity(t):
    computation = ["rec", rec(Z, t, Z)]
    return ["use", computation, eq(0, oshift(t)), computation]


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checker", type=Path,
                        default=HERE.parent / "checker.py")
    parser.add_argument("--translator", type=Path,
                        default=HERE.parent / "translate.py")
    parser.add_argument("--output", type=Path, default=HERE / "results")
    args = parser.parse_args()
    candidate_hash = hashlib.sha256(args.checker.read_bytes()).hexdigest()
    k = load_module("audited_kernel", args.checker)
    sys.modules["checker"] = k
    tr = load_module("audited_reverse_compiler", args.translator)
    out = args.output
    out.mkdir(parents=True, exist_ok=True)
    (out / "certificates").mkdir(exist_ok=True)
    (out / "expanded").mkdir(exist_ok=True)
    checks, certificates, failures = [], [], []

    def record(name, expected, actual, category, detail=None):
        good = expected == actual
        checks.append(dict(name=name, category=category, expected=expected,
                           actual=actual, passed=good, detail=detail))
        if not good:
            failures.append(name)

    def formed(a, formula):
        try:
            return k.wf(a, formula) is True
        except ERRORS:
            return False

    def certificate(name, data, accepted, category):
        data = json.loads(json.dumps(data, allow_nan=False))
        error = None
        try:
            actual = k.check(copy.deepcopy(data)) is True
        except ERRORS as exc:
            actual, error = False, type(exc).__name__
        record(name, accepted, actual, category, error)
        (out / "certificates" / (name + ".json")).write_text(json.dumps(data) + "\n")
        certificates.append((name, data, accepted))
        if actual and accepted:
            try:
                old_doc = tr.backward_certificate(copy.deepcopy(data))
                accepted_old = tr.old.check(old_doc) is True
                statement_ok = (old_doc["assumptions"] == list(map(tr.decode, data[0]))
                                and old_doc["goal"] == tr.decode(data[1]))
                record(name + "_independent_kernel", True,
                       accepted_old and statement_ok, "backward_replay")
                (out / "expanded" / (name + ".json")).write_text(
                    json.dumps(old_doc) + "\n")
            except Exception as exc:
                record(name + "_independent_kernel", True, False,
                       "backward_replay", type(exc).__name__ + ": " + str(exc))

    nested_r = rec(suc(3), 4, rec(0, 2, rec(1, 4, suc(6))))
    terms = [Z, 0, 1, 17, suc(Z), suc(0), rec(Z, 0, 0),
             rec(suc(0), 2, 1), nested_r,
             rec(rec(0, 1, 2), nested_r, rec(0, 2, suc(4)))]
    deep = pi(eq(rec(3, 1, suc(4)), suc(0)),
              sig(F, pi(eq(1, rec(0, 2, rec(1, 4, suc(6)))),
                        eq(rec(suc(2), 0, rec(1, 3, suc(4))), 3))))
    formulas = [T, F, D, eq(0, 1), eq(nested_r, 3),
                pi(eq(0, 1), F), sig(F, eq(0, 2)), deep,
                pi(sig(eq(0, 2), F), pi(T, eq(0, 3))),
                sig(pi(eq(0, 2), F), sig(T, eq(0, 3)))]
    malformed = [None, True, False, 0.0, -1.0, -2, "false", {}, [],
                 ["unknown", Z], [["false"]], ["s"], ["s", Z, Z],
                 ["s", F], ["r", Z, Z], ["r", Z, Z, Z, Z],
                 ["r", F, Z, Z], ["r", Z, F, Z], ["r", Z, Z, F],
                 ["=", Z], ["=", Z, Z, Z], ["=", F, Z], ["=", Z, F],
                 ["pi", T], ["pi", T, T, T], ["pi", Z, T], ["pi", T, Z],
                 ["sig", T], ["sig", T, T, T], ["sig", Z, T], ["sig", T, Z],
                 ["false", Z], eq(False, Z), eq(0.0, Z), eq(-1.0, Z),
                 pi(T, eq(0, False)), sig(eq(0, Z), ["r", Z, Z, 0])]

    # Every grammar constructor is checked positively and with missing/extra
    # children and wrong child sorts.  Exceptions are permitted rejections.
    for i, a in enumerate(terms + formulas + malformed):
        for sort in (False, True):
            record(f"formation_{i:02d}_{int(sort)}", oracle_wf(a, sort),
                   formed(a, sort), "formation")
    for i, a in enumerate(malformed):
        certificate(f"malformed_formula_{i:02d}", [[a], a, hyp(a)], False,
                    "root_formation")
        certificate(f"malformed_term_{i:02d}", [[eq(a, Z)], eq(a, Z), hyp(eq(a, Z))],
                    False, "root_formation")

    # Independent named-variable oracle exercises r's two local variables,
    # both local sides of Pi/Sigma, zero, equality, and primitive falsity.
    envs = [lambda i: i, lambda i: suc(i + 1),
            lambda i: rec(suc(i), i + 2, suc(2)),
            lambda i: nested_r if i == 0 else i - 1]
    for i, a in enumerate(terms + formulas):
        record(f"named_round_trip_{i:02d}", a, from_names(to_names(a)), "oracle_roundtrip")
        for count in (0, 1, 3):
            record(f"shift_{i:02d}_{count}", oshift(a, count), k.shift(a, count), "binding")
        for j, env in enumerate(envs):
            record(f"substitution_{i:02d}_{j}", osubst(a, env), k.subst(a, env), "binding")
        for j, t in enumerate((Z, 0, nested_r)):
            record(f"instantiation_{i:02d}_{j}", oinst(a, t), k.inst(a, t), "binding")

    for i, t in enumerate(terms):
        certificate(f"reflexivity_{i:02d}", [[], eq(t, t), reflexivity(t)], True,
                    "recursion_and_transport")
    for i, h in enumerate(terms):
        for j, count in enumerate((Z, suc(0), suc(nested_r))):
            r = rec(count, nested_r, h)
            expected = orec_equation(r)
            certificate(f"recursion_{i:02d}_{j}", [[], expected, ["rec", r]], True,
                        "recursion_and_transport")
            if j:
                swapped = osubst(h, lambda n: count[1] if n == 0 else
                                  rec(count[1], nested_r, h) if n == 1 else n - 2)
                if swapped != expected[2]:
                    certificate(f"recursion_swapped_locals_{i:02d}_{j}",
                                [[], eq(r, swapped), ["rec", r]], False, "recursion_scope")

    left, right = nested_r, rec(suc(0), 2, suc(2))
    equality = eq(left, right)
    for i, a in enumerate(formulas):
        source, goal = oinst(a, left), oinst(a, right)
        certificate(f"transport_{i:02d}",
                    [[equality, source], goal, ["use", hyp(equality), a, hyp(source)]],
                    True, "annotation_validation")
        # The valid Sigma conclusion is verified only by its shifted premise.
        principal = sig(eq(0, Z), F)
        certificate(f"sigma_conclusion_{i:02d}",
                    [[principal, a], a, ["use", hyp(principal), a, hyp(oshift(a))]],
                    True, "annotation_validation")
    for i, a in enumerate(malformed + terms):
        certificate(f"bad_transport_template_{i:02d}",
                    [[equality, T], T, ["use", hyp(equality), a, hyp(T)]], False,
                    "annotation_validation")
        principal = sig(T, T)
        certificate(f"bad_sigma_conclusion_{i:02d}",
                    [[principal, T], T, ["use", hyp(principal), a, hyp(T)]], False,
                    "annotation_validation")

    # Canonical lookup permits an opaque key equal to the stored formula,
    # but may not return the malformed key itself.
    stored = eq(0, Z)
    alias = eq(False, -1.0)
    context = [stored]
    record("stored_hypothesis_identity", True,
           k.infer(hyp(alias), context) is stored, "alias_boundary")
    certificate("alias_hypothesis_key", [[stored], stored, hyp(alias)], True, "alias_boundary")
    certificate("alias_root_context", [[alias], stored, hyp(stored)], False, "alias_boundary")
    certificate("alias_root_goal", [[stored], alias, hyp(stored)], False, "alias_boundary")
    certificate("alias_pi_guard", [[], pi(stored, stored), ["pi", alias, hyp(stored)]],
                False, "alias_boundary")
    certificate("alias_witness", [[], sig(stored, stored), ["pair", False, hyp(stored), hyp(stored)]],
                False, "alias_boundary")
    certificate("alias_nat_matrix", [[], numerical(stored), ["nat", alias]], False, "alias_boundary")
    certificate("alias_transport_template", [[stored, T], T,
                ["use", hyp(stored), eq(False, Z), hyp(T)]], False, "alias_boundary")
    principal = sig(T, T)
    certificate("alias_sigma_conclusion", [[principal, stored], stored,
                ["use", hyp(principal), alias, hyp(oshift(stored))]], False, "alias_boundary")

    for i, a in enumerate(formulas):
        certificate(f"numerical_schema_{i:02d}", [[], numerical(a), ["nat", a]], True,
                    "numerical_schema")
        forged = numerical(a, force_induction=True)
        if a[0] != "=" and forged != numerical(a):
            certificate(f"forged_quantified_induction_{i:02d}", [[], forged, ["nat", a]], False,
                        "numerical_schema")
    # Constant falsity's two guards coincide; it does not receive a useful
    # induction hypothesis or prove falsity without the false base premise.
    record("constant_falsity_guard_coincidence", numerical(F), numerical(F, True),
           "numerical_schema")
    certificate("unproved_false", [[], F, hyp(F)], False, "falsity")
    certificate("unproved_false_by_nat", [[], F, ["nat", F]], False, "falsity")
    certificate("bridge_false_to_clash", [[F], D, ["bridge", hyp(F)]], True, "falsity")
    certificate("bridge_clash_to_false", [[D], F, ["bridge", hyp(D)]], True, "falsity")
    certificate("bridge_rejects_true", [[T], F, ["bridge", hyp(T)]], False, "falsity")
    certificate("use_rejects_false_principal", [[F, T], T, ["use", hyp(F), T, hyp(T)]],
                False, "falsity")

    local = eq(0, Z)
    principal = sig(local, local)
    certificate("sigma_witness_escape", [[principal], local,
                ["use", hyp(principal), local, hyp(local)]], False, "scope_escape")
    certificate("pi_retained_context_unshifted", [[local], pi(T, local),
                ["pi", T, hyp(local)]], False, "scope_escape")
    a = deep
    certificate("nested_pi_sigma_retains_context", [[principal, a], pi(T, oshift(a)),
                ["pi", T, ["use", hyp(oshift(principal)), oshift(a), hyp(oshift(a, 2))]]],
                True, "local_scopes")
    witness = nested_r
    guard = eq(0, oshift(witness))
    certificate("pair_compound_witness", [[], sig(guard, guard),
                ["pair", witness, hyp(guard), hyp(guard)]], True, "local_scopes")
    inner_goal = pi(T, oshift(guard))
    certificate("pair_then_pi_scope", [[], sig(inner_goal, guard),
                ["pair", witness, ["pi", T, hyp(oshift(guard))], hyp(guard)]], True,
                "local_scopes")
    certificate("pair_witness_scope_forgery", [[], sig(eq(0, witness), eq(0, witness)),
                ["pair", witness, hyp(eq(0, witness)), hyp(eq(0, witness))]], False,
                "scope_escape")
    certificate("pi_then_pair_scope", [[local], pi(T, sig(oshift(local, 2), eq(0, Z))),
                ["pi", T, ["pair", Z, hyp(oshift(local, 2)), hyp(eq(0, Z))]]], True,
                "local_scopes")

    malformed_roots = [None, False, 0, "abc", {}, [], [[], T], [[], T, hyp(T), 0],
                       {"assumptions": [], "goal": T, "proof": hyp(T)}]
    for i, data in enumerate(malformed_roots):
        certificate(f"malformed_root_{i:02d}", data, False, "input_boundary")

    selected = {"reflexivity_08", "alias_hypothesis_key", "bridge_false_to_clash",
                "nested_pi_sigma_retains_context", "bad_transport_template_00",
                "sigma_witness_escape", "forged_quantified_induction_05", "malformed_root_06"}
    for name, data, expected in certificates:
        if name not in selected:
            continue
        path = out / "certificates" / (name + ".json")
        for optimized in (False, True):
            result = subprocess.run([sys.executable, *(["-O"] if optimized else []),
                                     str(args.checker), str(path)], capture_output=True,
                                    text=True, timeout=15)
            passed = (result.returncode == (0 if expected else 1)
                      and result.stdout.strip() == ("ACCEPT" if expected else "REJECT")
                      and not result.stderr)
            record(name + ("_optimized_cli" if optimized else "_normal_cli"), True, passed,
                   "cli", dict(exit=result.returncode, stdout=result.stdout, stderr=result.stderr))
    record("candidate_unchanged_during_audit", candidate_hash,
           hashlib.sha256(args.checker.read_bytes()).hexdigest(), "integrity")
    categories = {}
    for row in checks:
        categories[row["category"]] = categories.get(row["category"], 0) + 1
    summary = dict(status="PASS" if not failures else "FAIL", checker_sha256=candidate_hash,
                   translator_sha256=hashlib.sha256(args.translator.read_bytes()).hexdigest(),
                   independent_baseline_sha256=hashlib.sha256(
                       (args.translator.parent / "validation/baseline_checker.py").read_bytes()).hexdigest(),
                   checks=len(checks), certificates=len(certificates),
                   expected_accepted=sum(x[2] for x in certificates),
                   expected_rejected=sum(not x[2] for x in certificates),
                   categories=categories, failures=failures,
                   scope="Finite focused independent binding/formation audit and reverse proof replay; not formal verification.")
    (out / "results.json").write_text(json.dumps(dict(summary=summary, checks=checks), indent=2) + "\n")
    (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
    return not failures


if __name__ == "__main__":
    raise SystemExit(0 if main() else 1)
