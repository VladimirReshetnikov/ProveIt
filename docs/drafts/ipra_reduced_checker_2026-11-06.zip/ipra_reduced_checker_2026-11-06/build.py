"""Reproduce the offline package, compiled paper, hashes, and ZIP archive."""

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {'.aux', '.log', '.out', '.toc', '.fls', '.fdb_latexmk', '.pyc'}


def deliverable_paths():
    for path in sorted(ROOT.rglob('*')):
        relative = path.relative_to(ROOT)
        if (path.is_file() and '__pycache__' not in relative.parts
                and 'build' not in relative.parts
                and path.suffix not in EXCLUDED_SUFFIXES
                and path.name != 'manifest.json'):
            yield path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pdf-only', action='store_true',
                        help='compile only; use after a prose/layout-only edit')
    parser.add_argument('--no-archive', action='store_true')
    args = parser.parse_args()
    if not args.pdf_only:
        for script in ['measure.py', 'validate.py', 'audit/audit_candidate.py',
                       'verify_controls.py']:
            subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)
    latex = shutil.which('pdflatex')
    if not latex:
        raise SystemExit('pdflatex is required to rebuild report.pdf')
    log_dir = ROOT / 'build'
    log_dir.mkdir(exist_ok=True)
    for run in (1, 2):
        result = subprocess.run([latex, '-interaction=nonstopmode', '-halt-on-error',
                                 'report.tex'], cwd=ROOT, capture_output=True, text=True)
        (log_dir / f'latex-{run}.txt').write_text(result.stdout + result.stderr)
        if result.returncode:
            print(result.stdout[-6000:])
            raise SystemExit(result.returncode)
    entries = [{'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size,
                'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
               for p in deliverable_paths()]
    (ROOT / 'manifest.json').write_text(json.dumps({
        'format': 'SHA-256 manifest of every deliverable except this manifest',
        'files': entries}, indent=2) + '\n')
    if not args.no_archive:
        archive = ROOT.parent / (ROOT.name + '.zip')
        with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED,
                             compresslevel=9) as z:
            paths = [*deliverable_paths(), ROOT / 'manifest.json']
            for path in sorted(paths):
                info = zipfile.ZipInfo(str(Path(ROOT.name) / path.relative_to(ROOT)),
                                       date_time=(2026, 11, 6, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                z.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED,
                           compresslevel=9)
        print(f'Created {archive.name}: {archive.stat().st_size:,} bytes')
    print('Compiled report.pdf and wrote manifest.json')


if __name__ == '__main__':
    main()
