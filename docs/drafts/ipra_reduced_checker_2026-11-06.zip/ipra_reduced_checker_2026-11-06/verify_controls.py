"""Check the two one-change controls on the already established corpus."""

import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError)


def load(path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    expectations = {r['name']: r['expected'] for r in json.loads(
        (ROOT / 'audit/results/results.json').read_text())['checks']}
    cases = []
    for path in sorted((ROOT / 'certificates').glob('*.json')):
        cases.append((str(path.relative_to(ROOT)), json.loads(path.read_text()),
                      not path.name.startswith('reject_')))
    for path in sorted((ROOT / 'audit/results/certificates').glob('*.json')):
        cases.append((str(path.relative_to(ROOT)), json.loads(path.read_text()),
                      expectations[path.stem]))
    summaries = []
    for path in sorted((ROOT / 'controls').glob('*.py')):
        kernel = load(path)
        for name, data, expected in cases:
            try:
                accepted = kernel.check(data) is True
            except ERRORS:
                accepted = False
            if accepted != expected:
                raise AssertionError((path.name, name, expected, accepted))
        summaries.append({'control': path.name, 'cases': len(cases), 'status': 'PASS'})
    (ROOT / 'controls/results.json').write_text(json.dumps(summaries, indent=2) + '\n')
    print(json.dumps(summaries, indent=2))


if __name__ == '__main__':
    main()
