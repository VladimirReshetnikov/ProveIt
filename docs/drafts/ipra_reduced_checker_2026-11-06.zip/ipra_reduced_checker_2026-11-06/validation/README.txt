Validation inputs and reproducibility
====================================

Run from any working directory:

    python3 /path/to/ipra_reduced_checker_2026-11-06/validate.py

The suite verifies the SHA-256 hashes of every preserved source, translates
all 53 baseline derivations and 6 binding-stress derivations into checker.py,
and expands every accepted candidate back into the separately implemented
baseline_checker.py. It checks exact equality of assumptions and conclusions
after changing only the representation of zero. Genuine falsity is preserved.
A further forward compilation checks each reverse expansion, again preserving
the exact sequent.

One- and two-witness wrappers and substitution of dependent nested recursion
terms exercise capture avoidance under logical and computational binders.
Direct axiom instances include genuine falsity, compound matrices, arithmetic
clash, and two distinct ambient-context sizes. Positive bridge cases and
negative implicit-conversion cases test that bottom is not silently erased.
The suite rejects inherited and newly constructed adversarial inputs, and
runs every saved certificate through the normal and optimized (-O) CLI.

results.json records all case names and aggregate counts. It is regenerated
by validate.py. Certificate files under ../certificates/ are also regenerated;
the larger wrapper and substitution cases are regenerated in memory.

Preserved inputs
----------------
baseline/: 53 source certificates.
stress/: 6 source binder/recursion stress certificates.
invalid_baseline/: 28 invalid source certificates.
inherited_negative/: 45 applicable candidate rejection certificates.
baseline_checker.py: exact separately implemented fused checker.
inherited_baseline_provenance.json: provenance supplied in the source archive.
provenance.json: immediate source archive, pinned repository commit, member
paths, and SHA-256 hashes for all 134 preserved files.

The source archive is docs/drafts/ipra_composed_kernel_2026-11-06.zip in
VladimirReshetnikov/ProveIt at commit
36fb791c722edc2549719744c38feef74fa422fb.

The old negative fixture named reject_primitive_bridge_absent.json was not
inherited: this theory deliberately has an explicit bridge record. A new
bridge_wrong_target test independently checks the direction of that record.

Trust and limits
----------------
The new checker imports neither validate.py nor translate.py. These programs
are untrusted testing/proof-building tools. Every compiler output is checked
by the corresponding standalone kernel. Finite tests and proof replay do not
constitute a Lean/Rocq formalization or a universal proof of checker soundness.
