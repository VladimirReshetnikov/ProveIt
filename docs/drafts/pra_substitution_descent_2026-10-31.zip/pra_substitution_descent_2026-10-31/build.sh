#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build \
  pra_substitution_descent.tex >build/latex-pass-1.log
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build \
  pra_substitution_descent.tex >build/latex-pass-2.log
cp build/pra_substitution_descent.pdf pra_substitution_descent.pdf
printf '%s\n' 'Built pra_substitution_descent.pdf'
