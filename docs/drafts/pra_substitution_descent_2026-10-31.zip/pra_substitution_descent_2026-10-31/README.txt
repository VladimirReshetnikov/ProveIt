PRA from Parameter Substitution and Stationary Separation
======================================================
Research report prepared for Vladimir Reshetnikov, 31 October 2026.

READ FIRST
  pra_substitution_descent.pdf -- complete mathematical report.
  AXIOMS.txt -- standalone exact specification.

RESULT
Two computation templates, one fixed positive sentence, and one arithmetic
schema suffice. The same nonlogical basis is definitionally equivalent to
classical PRA in classical equality logic, and to intuitionistic PRA in
intuitionistic equality logic. Both interpretations have identity domain
and native equality, with explicitly proved round trips.

The computation language permits one distinguished parameter a to change
to an earlier unary term k(a) at a recursive call. Other parameters stay
fixed. This familiar primitive-recursive closure operation makes the
diagonal of a particular equality program literally stationary. Applying
stationary separation to e(e(n,n),1) derives e(n,n)=1, so the corresponding
fixed diagonal axiom can be deleted from the stationary-separation draft.

QUALIFIED SIMPLICITY CLAIM
The one-parameter template count is 54 versus 60 for the full-parameter
version of that draft. The change in grammar and the equality program's
descriptor cost are disclosed. The historical delayed-uniqueness display
has 52 nodes before its separate descriptor transformation. This report
does not claim an encoding-independent optimum or dominance on all metrics.

CONTENTS
  pra_substitution_descent.tex  LaTeX source, with bibliography included.
  pra_substitution_descent.pdf  Compiled report.
  AXIOMS.txt                   Exact language, axioms, theorem, and compiler.
  formal/Bootstrap.lean        Constructive Lean 4.19.0 arithmetic kernel.
  formal/README.txt            Exact formal scope and limitations.
  formal/Bootstrap.log         Successful check and six axiom audits.
  formal/lean-version.txt      Tool version used.
  artifacts/schema_metrics.py  Explicit AST counter.
  artifacts/schema_metrics.json  Reproduced counts and descriptor sizes.
  artifacts/check_compiler.py  Finite diagnostic checks of the compiler.
  artifacts/compiler_checks.json  Results and mutation check.
  audit/source_manifest.json   Pinned GitHub sources and hashes.
  audit/proof_review.txt       Independent review and remaining scope.
  audit/validation.json        Package validation summary.
  build.sh, check.sh           Reproduction commands.
  SHA256SUMS                  Integrity manifest (excludes itself).

BUILD
  bash build.sh
Requires pdflatex and ordinary TeX Live packages named in the preamble.
Two passes resolve cross-references. The build directory is disposable.

CHECK
  bash check.sh
Python scripts use only the standard library. They regenerate their JSON
diagnostics. For the Lean check, put Lean 4.19.0 on PATH or run:
  PRA_LEAN_BIN=/absolute/path/to/lean bash check.sh

FORMAL SCOPE
The Lean certificate proves the diagonal bootstrap, exact equality bit,
decidability, constancy, and shifted-latch induction over an abstract
carrier. It has explicit semantic hypotheses, no induction principle on
the carrier, and no globally admitted axioms. Every stationarity use is
listed as an explicit term instance in the paper.
The full finite-syntax interpretation theorem and the descent/fold
compiler's general correctness are written proofs. Finite Python checks
are implementation diagnostics, not substitutes for those proofs.

SOURCES
All six archives then in ProveIt/docs/drafts were inspected at commit
3af028c8eb45b393331630537c5a94939c536341. docs/incoming's inventory and
README identified no additional PRA archive. The report attributes the
stationary-separation architecture to those drafts and the established
parameter-substitution closure operation to the cited literature.

The downloaded reference archives are not bundled in this deliverable;
their immutable URLs and hashes are retained for reproduction.
