/-
Constructive kernel for PRA from substitution recursion and separation.

Scope: an arbitrary carrier, with the off-diagonal disjunction and the
stationary-separation interface as explicit hypotheses.  The interface
quantifies over functions semantically; the manuscript lists every use
as a finite term instance.  This file does not formalize term syntax,
the first-order proof calculus, parameter coding, or the bi-interpretation.

The Kernel interface uses the diagonal base and step.  The constructor
ofSubstitutionEquations derives both directly from the defining equations
for e, the predecessor equation, and the selector equations.

No classical logic, choice, induction on the carrier, or admitted proof
is used.  The stationary-separation instances used below are exactly:
  (1) the constant zero function;
  (2) n |-> e(e(n,n),1);
  (3) n |-> e(t(n),t(0)).
The derived constancy lemma is then used for the shifted latch
n |-> r(S n).  Fixed numerical parameters can be held in the closure
of each function; the corresponding term instances are in the paper.
-/

universe u

namespace PRASubstitutionDescent

structure Kernel (α : Type u) where
  zero : α
  succ : α → α
  eqtest : α → α → α
  eqtest_diagonal_base : eqtest zero zero = succ zero
  eqtest_diagonal_step : ∀ n, eqtest (succ n) (succ n) = eqtest n n
  off : ∀ x y, eqtest x y = zero ∨ x = y
  stationarySeparation : ∀ f : α → α,
    (∀ n, f (succ n) = f n) → ∀ n, succ (f n) ≠ f zero

def ofSubstitutionEquations {α : Type u}
    (zero : α) (succ pred : α → α)
    (branch eqtest : α → α → α) (select : α → α → α → α)
    (pred_succ : ∀ n, pred (succ n) = n)
    (branch_zero : ∀ a, branch zero a = a)
    (select_succ : ∀ n u v, select (succ n) u v = v)
    (eqtest_base : ∀ y, eqtest zero y = branch y (succ zero))
    (eqtest_step : ∀ n y,
      eqtest (succ n) y = select y zero (eqtest n (pred y)))
    (off : ∀ x y, eqtest x y = zero ∨ x = y)
    (separation : ∀ f : α → α,
      (∀ n, f (succ n) = f n) → ∀ n, succ (f n) ≠ f zero) : Kernel α where
  zero := zero
  succ := succ
  eqtest := eqtest
  eqtest_diagonal_base := (eqtest_base zero).trans (branch_zero (succ zero))
  eqtest_diagonal_step := by
    intro n
    calc
      eqtest (succ n) (succ n) =
          select (succ n) zero (eqtest n (pred (succ n))) := eqtest_step n (succ n)
      _ = eqtest n (pred (succ n)) := select_succ n zero (eqtest n (pred (succ n)))
      _ = eqtest n n := congrArg (eqtest n) (pred_succ n)
  off := off
  stationarySeparation := separation

namespace Kernel

variable {α : Type u} (D : Kernel α)

abbrev one : α := D.succ D.zero

theorem one_ne_zero : D.one ≠ D.zero := by
  exact D.stationarySeparation (fun _ => D.zero) (fun _ => rfl) D.zero

theorem zero_ne_one : D.zero ≠ D.one := by
  intro h
  exact D.one_ne_zero h.symm

theorem eqtest_diagonal_one (x : α) : D.eqtest x x = D.one := by
  let u : α → α := fun n => D.eqtest (D.eqtest n n) D.one
  have ustep : ∀ n, u (D.succ n) = u n := by
    intro n
    exact congrArg (fun z => D.eqtest z D.one) (D.eqtest_diagonal_step n)
  have ubase : u D.zero = D.one := by
    calc
      u D.zero = D.eqtest D.one D.one := congrArg
        (fun z => D.eqtest z D.one) D.eqtest_diagonal_base
      _ = D.eqtest D.zero D.zero := D.eqtest_diagonal_step D.zero
      _ = D.one := D.eqtest_diagonal_base
  have hs := D.stationarySeparation u ustep x
  cases D.off (D.eqtest x x) D.one with
  | inl hz =>
    have heq : D.succ (u x) = u D.zero :=
      (congrArg D.succ hz).trans ubase.symm
    exact False.elim (hs heq)
  | inr hone => exact hone

theorem eqtest_bits (x y : α) :
    D.eqtest x y = D.zero ∨ D.eqtest x y = D.one := by
  cases D.off x y with
  | inl hz => exact Or.inl hz
  | inr hxy =>
    cases hxy
    exact Or.inr (D.eqtest_diagonal_one x)

theorem eqtest_one_iff (x y : α) :
    D.eqtest x y = D.one ↔ x = y := by
  constructor
  · intro h
    cases D.off x y with
    | inl hz => exact False.elim (D.one_ne_zero (h.symm.trans hz))
    | inr hxy => exact hxy
  · intro hxy
    cases hxy
    exact D.eqtest_diagonal_one x

theorem eqtest_zero_iff (x y : α) :
    D.eqtest x y = D.zero ↔ x ≠ y := by
  constructor
  · intro h hxy
    cases hxy
    exact D.one_ne_zero ((D.eqtest_diagonal_one x).symm.trans h)
  · intro hxy
    cases D.off x y with
    | inl hz => exact hz
    | inr heq => exact False.elim (hxy heq)

include D in
theorem equality_decision (x y : α) : x = y ∨ x ≠ y := by
  cases D.off x y with
  | inl hz => exact Or.inr ((D.eqtest_zero_iff x y).mp hz)
  | inr hxy => exact Or.inl hxy

theorem constancy (t : α → α)
    (stationary : ∀ n, t (D.succ n) = t n) :
    ∀ n, t n = t D.zero := by
  let q : α → α := fun n => D.eqtest (t n) (t D.zero)
  have qstep : ∀ n, q (D.succ n) = q n := by
    intro n
    exact congrArg (fun x => D.eqtest x (t D.zero)) (stationary n)
  have qbase : q D.zero = D.one := D.eqtest_diagonal_one (t D.zero)
  intro n
  have hs := D.stationarySeparation q qstep n
  cases D.off (t n) (t D.zero) with
  | inl hz =>
    have heq : D.succ (q n) = q D.zero :=
      (congrArg D.succ hz).trans qbase.symm
    exact False.elim (hs heq)
  | inr heq => exact heq

/- The latch is supplied with its literal recurrence.  In the full-tuple
grammar it is directly available by ordinary primitive recursion. -/
theorem shifted_latch_induction
    (select : α → α → α → α)
    (select_zero : ∀ u v, select D.zero u v = u)
    (select_one : ∀ u v, select D.one u v = v)
    (P : α → Prop) (b r : α → α)
    (bits : ∀ n, b n = D.zero ∨ b n = D.one)
    (truth : ∀ n, P n ↔ b n = D.one)
    (rbase : r D.zero = D.one)
    (rstep : ∀ n, r (D.succ n) = select (b n) D.zero (r n))
    (base : P D.zero) (step : ∀ n, P n → P (D.succ n)) :
    ∀ n, P n := by
  have select_same (z : α) (hz : z = D.zero ∨ z = D.one) :
      select z D.zero D.zero = D.zero := by
    cases hz with
    | inl h => exact h ▸ select_zero D.zero D.zero
    | inr h => exact h ▸ select_one D.zero D.zero
  have bbase : b D.zero = D.one := (truth D.zero).mp base
  have shifted_base : r (D.succ D.zero) = D.one := by
    calc
      r (D.succ D.zero) = select (b D.zero) D.zero (r D.zero) := rstep D.zero
      _ = select D.one D.zero (r D.zero) := congrArg (fun z =>
        select z D.zero (r D.zero)) bbase
      _ = r D.zero := select_one D.zero (r D.zero)
      _ = D.one := rbase
  have shifted_step : ∀ n, r (D.succ (D.succ n)) = r (D.succ n) := by
    intro n
    cases bits n with
    | inl hz =>
      have hn : r (D.succ n) = D.zero := by
        calc
          r (D.succ n) = select (b n) D.zero (r n) := rstep n
          _ = select D.zero D.zero (r n) := congrArg
            (fun z => select z D.zero (r n)) hz
          _ = D.zero := select_zero D.zero (r n)
      calc
        r (D.succ (D.succ n)) =
            select (b (D.succ n)) D.zero (r (D.succ n)) := rstep (D.succ n)
        _ = select (b (D.succ n)) D.zero D.zero := congrArg
          (fun z => select (b (D.succ n)) D.zero z) hn
        _ = D.zero := select_same (b (D.succ n)) (bits (D.succ n))
        _ = r (D.succ n) := hn.symm
    | inr hone =>
      have hnext : b (D.succ n) = D.one :=
        (truth (D.succ n)).mp (step n ((truth n).mpr hone))
      calc
        r (D.succ (D.succ n)) =
            select (b (D.succ n)) D.zero (r (D.succ n)) := rstep (D.succ n)
        _ = select D.one D.zero (r (D.succ n)) := congrArg
          (fun z => select z D.zero (r (D.succ n))) hnext
        _ = r (D.succ n) := select_one D.zero (r (D.succ n))
  have shifted_one : ∀ n, r (D.succ n) = D.one := by
    intro n
    exact (D.constancy (fun j => r (D.succ j)) shifted_step n).trans shifted_base
  intro n
  apply (truth n).mpr
  cases bits n with
  | inl hz =>
    have hn : r (D.succ n) = D.zero := by
      calc
        r (D.succ n) = select (b n) D.zero (r n) := rstep n
        _ = select D.zero D.zero (r n) := congrArg
          (fun z => select z D.zero (r n)) hz
        _ = D.zero := select_zero D.zero (r n)
    exact False.elim (D.one_ne_zero ((shifted_one n).symm.trans hn))
  | inr hone => exact hone

#print axioms one_ne_zero
#print axioms eqtest_diagonal_one
#print axioms equality_decision
#print axioms eqtest_one_iff
#print axioms constancy
#print axioms shifted_latch_induction

end Kernel
end PRASubstitutionDescent
