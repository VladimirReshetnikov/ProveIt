FORMAL VERIFICATION SCOPE
=========================

Bootstrap.lean checks a constructive proof kernel over an arbitrary carrier.
It imports no library and assumes no induction principle on that carrier.
All numerical operations, computation equations, the off-diagonal law, and
the stationary-separation interface are explicit parameters or structure
fields. No declaration adds a global axiom.

Verified results
----------------
1. The defining predecessor, selector, and substituted-recursion equations
   imply e(0,0)=1 and e(Sn,Sn)=e(n,n).
2. Stationary separation on the constant zero function gives 1 != 0.
3. The observer u(n)=e(e(n,n),1), together with the off-diagonal law,
   proves e(n,n)=1 directly.
4. The equality test is an exact Boolean code for native equality, and
   native equality is decidable constructively.
5. Stationary separation applied to e(t(n),t(0)) gives ordinary constancy.
6. The shifted latch r(Sn) proves induction for any proposition family
   accompanied by a truth bit and the displayed latch recurrence.

The semantic stationary-separation interface is quantified over functions
on the carrier. This is a convenient theorem interface, not a claim that
the first-order axiom schema quantifies over all functions. Every use in
the proof is one of the explicit finite-term instances listed above.
Fixed numerical parameters are held in the corresponding function closure.

Not formalized
--------------
Finite description syntax, substitution admissibility, the complete
primitive-recursive compiler, arbitrary formula-to-bit translation, and
the two bi-interpretation round trips remain written mathematical proofs
in the paper. The theorem does not claim that the whole first-order
metatheory has been verified by Lean.

Reproduction
------------
Lean 4.19.0 (commit 6caaee842e94, Release) was used:

    lean Bootstrap.lean

The process exited with status 0. Bootstrap.log records six axiom audits,
all reporting no global axioms. This does not remove the explicitly
supplied hypotheses from the theorem statements.
