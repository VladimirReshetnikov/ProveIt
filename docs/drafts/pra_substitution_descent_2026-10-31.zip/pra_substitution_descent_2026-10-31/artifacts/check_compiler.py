#!/usr/bin/env python3
"""Finite diagnostics for the frozen parameter-substitution PR compiler.

The general diagnostic engine accepts equations
    R(0, a) = g(a)
    R(n + 1, a) = h(n, a, R(n, k(a))).

The compiler follows a parameter orbit down to the base and folds the
answers upwards. Exact finite checks exercise the defining equations and
the bounded trace invariant used in the written uniqueness proof. They do
not establish the universal metatheorem or formalize first-order proofs.

The final paper needs only one changing coordinate and any number of frozen
coordinates. Tuple-swap and multi-coordinate examples additionally exercise
the broader tuple-substitution extension; that extension is not needed for
the proposed axiomatization. Empty tuples abbreviate an unused dummy parameter.

Uses only the Python standard library. Run from any working directory.
"""

from __future__ import annotations

import argparse
import itertools
import json
import platform
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Callable


Params = tuple[int, ...]


@dataclass(frozen=True)
class Case:
    name: str
    arity: int
    base: Callable[[Params], int]
    step: Callable[[int, Params, int], int]
    transform: Callable[[Params], Params]
    maximum_depth: int = 6
    parameter_bound: int = 4


CASES = (
    Case(
        "ordinary_recursion_identity_transform",
        2,
        lambda a: a[0],
        lambda n, a, z: z + a[1] + n,
        lambda a: a,
    ),
    Case(
        "equality_by_predecessor_substitution",
        1,
        lambda a: int(a[0] == 0),
        lambda n, a, z: 0 if a[0] == 0 else z,
        lambda a: (max(a[0] - 1, 0),),
        maximum_depth=12,
        parameter_bound=13,
    ),
    Case(
        "nonlinear_state_and_nonmonotone_parameter",
        1,
        lambda a: a[0] * a[0] + 1,
        lambda n, a, z: (n + 1) * (z * z + a[0] + 1),
        lambda a: ((a[0] * a[0] + 1) % 17,),
    ),
    Case(
        "growing_parameter_orbit",
        1,
        lambda a: a[0] + 2,
        lambda n, a, z: z + a[0] * a[0] + n,
        lambda a: (2 * a[0] + 1,),
    ),
    Case(
        "swapped_coordinates_with_nonlinear_update",
        2,
        lambda a: 2 * a[0] + a[1] * a[1],
        lambda n, a, z: (n + 1) * z + a[0] * a[1] + 1,
        lambda a: (a[1], a[0] + 1),
    ),
    Case(
        "one_changed_parameter_two_frozen_parameters",
        3,
        lambda a: a[0] * a[1] + a[2] + 1,
        lambda n, a, z: (a[1] + 1) * z + a[0] + a[2] * n,
        lambda a: ((2 * a[0] + 1) % 11, a[1], a[2]),
        parameter_bound=3,
    ),
    Case(
        "noninjective_parameter_transform",
        2,
        lambda a: a[0] + a[1] + 1,
        lambda n, a, z: z + a[0] * a[0] + 2 * a[1] + n,
        lambda a: (a[0] // 2, (a[0] + a[1]) % 5),
    ),
    Case(
        "empty_parameter_tuple",
        0,
        lambda a: 2,
        lambda n, a, z: z * (n + 1) + 1,
        lambda a: (),
    ),
)


def orbit(case: Case, depth: int, initial: Params) -> list[Params]:
    """The ordinary-PR orbit K(0,a)=a, K(j+1,a)=k(K(j,a))."""
    trace = [initial]
    for _ in range(depth):
        next_value = case.transform(trace[-1])
        assert len(next_value) == case.arity
        assert all(isinstance(x, int) and x >= 0 for x in next_value)
        trace.append(next_value)
    return trace


def compiled_with_prefixes(
    case: Case, depth: int, initial: Params
) -> tuple[int, list[int], list[Params]]:
    """Return Rhat(N,a), every U(i,N,a) for i<=N, and its K orbit."""
    trace = orbit(case, depth, initial)
    value = case.base(trace[depth])
    prefixes = [value]
    for i in range(depth):
        value = case.step(i, trace[depth - i - 1], value)
        assert isinstance(value, int) and value >= 0
        prefixes.append(value)
    return value, prefixes, trace


def compiled(case: Case, depth: int, initial: Params) -> int:
    return compiled_with_prefixes(case, depth, initial)[0]


def diagnose(case: Case) -> dict[str, object]:
    @lru_cache(maxsize=None)
    def direct(n: int, a: Params) -> int:
        if n == 0:
            return case.base(a)
        return case.step(n - 1, a, direct(n - 1, case.transform(a)))

    sample_count = 0
    invariant_count = 0
    recurrence_count = 0
    maximum_result_bits = 0
    for a in itertools.product(range(case.parameter_bound), repeat=case.arity):
        for n in range(case.maximum_depth + 1):
            actual, prefixes, trace = compiled_with_prefixes(case, n, a)
            expected = direct(n, a)
            assert actual == expected, (case.name, n, a, "direct mismatch")
            maximum_result_bits = max(maximum_result_bits, actual.bit_length())
            sample_count += 1

            # The actual finite instance of the uniqueness induction matrix:
            # F(i,K(N-i,a)) = U(i,N,a) for 0<=i<=N.
            for i in range(n + 1):
                assert direct(i, trace[n - i]) == prefixes[i], (
                    case.name, n, a, i, "bounded trace mismatch"
                )
                invariant_count += 1

            # Compare the generated ordinary-PR implementation with the
            # original substitution equation, independently at each input.
            right = case.step(n, a, compiled(case, n, case.transform(a)))
            assert compiled(case, n + 1, a) == right, (
                case.name, n, a, "recurrence mismatch"
            )
            recurrence_count += 1

            if case.name == "equality_by_predecessor_substitution":
                assert actual == int(n == a[0]), (n, a, "equality mismatch")

    return {
        "name": case.name,
        "arity": case.arity,
        "parameter_values_per_coordinate": case.parameter_bound,
        "maximum_direct_depth": case.maximum_depth,
        "direct_comparisons": sample_count,
        "bounded_trace_instances": invariant_count,
        "successor_recurrence_instances": recurrence_count,
        "maximum_result_bits": maximum_result_bits,
        "status": "passed",
    }


def check_order_sensitivity() -> dict[str, int]:
    """Confirm a stale-parameter fold is distinguishable in a small example."""
    case = Case(
        "order_sensitivity",
        1,
        lambda a: a[0] * a[0],
        lambda n, a, z: a[0] + 2 * z + n,
        lambda a: (a[0] + 1,),
    )
    n, a = 2, (1,)
    correct = compiled(case, n, a)
    wrong = case.base(orbit(case, n, a)[n])
    for i in range(n):
        wrong = case.step(i, a, wrong)
    assert correct == 42 and wrong == 40
    return {"correct_trace_fold": correct, "incorrect_stale_parameter_fold": wrong}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(__file__).with_name("compiler_checks.json"),
        help="Path for the machine-readable finite diagnostic report.",
    )
    args = parser.parse_args()
    results = [diagnose(case) for case in CASES]
    report = {
        "scope": (
            "Exact finite diagnostics, not a proof of general equivalence, "
            "bi-interpretability, or the first-order metatheorem."
        ),
        "python_version": platform.python_version(),
        "recursion_form": "R(n+1,a)=h(n,a,R(n,k(a)))",
        "parameter_transform_reads_counter": False,
        "primary_grammar": "Only the first coordinate changes; other parameters "
                           "are frozen. Broader tuple examples are extra diagnostics.",
        "cases": results,
        "order_sensitivity": check_order_sensitivity(),
        "totals": {
            key: sum(int(result[key]) for result in results)
            for key in (
                "direct_comparisons",
                "bounded_trace_instances",
                "successor_recurrence_instances",
            )
        },
        "status": "passed",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "totals": report["totals"]}))


if __name__ == "__main__":
    main()
