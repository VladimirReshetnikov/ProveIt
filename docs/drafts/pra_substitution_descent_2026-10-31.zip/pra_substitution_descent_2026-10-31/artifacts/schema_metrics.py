#!/usr/bin/env python3
"""Reproduce the paper's formula-tree counts (not encoded program lengths)."""
from dataclasses import dataclass
from pathlib import Path
import json


@dataclass(frozen=True)
class Node:
    label: str
    children: tuple = ()

    def size(self):
        return 1 + sum(child.size() for child in self.children)


def call(name, *args):
    return Node(name, args)


def eq(left, right):
    return call("=", left, right)


def conj(left, right):
    return call("and", left, right)


def disj(left, right):
    return call("or", left, right)


def implies(left, right):
    return call("implies", left, right)


def neq(left, right):
    return implies(eq(left, right), Node("false"))


def forall(variables, body):
    for variable in reversed(variables):
        body = Node("forall " + variable.label, (body,))
    return body


zero, n, a, x, y, v = (Node(s) for s in ("0", "n", "a", "x", "y", "v"))


def succ(t):
    return call("S", t)


one = succ(zero)


def ordinary_definitions(params, substituted=False):
    base = forall(params, eq(call("R", zero, *params), call("g", *params)))
    changed = (call("k", params[0]), *params[1:]) if substituted else params
    step = forall((n, *params), eq(
        call("R", succ(n), *params),
        call("h", n, *params, call("R", n, *changed))))
    return base.size() + step.size()


def initialized_definitions():
    base = forall((a,), eq(call("I", zero, a), a))
    step = forall((n, a), eq(
        call("I", succ(n), a), call("h", n, call("I", n, a))))
    return base.size() + step.size()


def stationary_separation(params):
    f = lambda t: call("f", t, *params)
    return forall(params, implies(
        forall((n,), eq(f(succ(n)), f(n))),
        forall((n,), neq(succ(f(n)), f(zero)))))


def positive_constancy(params):
    f = lambda t: call("f", t, *params)
    return forall(params, implies(
        forall((n,), eq(f(succ(succ(n))), f(succ(n)))),
        forall((n,), disj(eq(n, zero), eq(f(n), f(one))))))


def positive_equation_induction(params):
    equation = lambda t: eq(call("f", t, *params), call("g", t, *params))
    positive = lambda t: disj(eq(t, zero), equation(t))
    return forall(params, implies(
        forall((n,), implies(positive(n), equation(succ(n)))),
        forall((n,), positive(n))))


def positive_successor(params):
    f = lambda t: call("f", t, *params)
    pred_n = call("P", n, zero)
    comparison = succ(call("A", pred_n, f(zero)))
    return forall(params, implies(
        forall((n,), eq(f(succ(n)), succ(f(n)))),
        conj(neq(zero, one), forall((n,), disj(eq(n, zero), eq(f(n), comparison))))))


def delayed_uniqueness(params):
    f = lambda t: call("f", t, *params)
    rho = lambda t: call("rho", t)
    return forall(params, implies(
        forall((n,), eq(f(succ(n)), rho(f(n)))),
        conj(neq(zero, one), forall((n,), disj(
            eq(n, zero), eq(f(n), rho(call("D_rho", n, f(zero)))))))))


def main():
    e = lambda t, u: call("e", t, u)
    off_body = disj(eq(e(x, y), zero), eq(x, y))
    off = forall((x, y), off_body).size()
    old_e = forall((x, y), conj(eq(e(x, x), one), off_body)).size()
    flat = forall((x, y), conj(eq(e(x, x), x), off_body)).size()
    sep = neq(zero, one).size()
    minimum = forall((x, y), eq(
        call("M", call("M", x, y), y),
        call("M", call("M", y, x), x))).size()
    retract = forall((n, a), eq(call("M", n, call("A", n, a)), a)).size()
    iterator = initialized_definitions()
    ordinary = ordinary_definitions((a,))
    substituted = ordinary_definitions((a,), True)
    ss = stationary_separation((a,)).size()
    pc = positive_constancy((a,)).size()
    pi = positive_equation_induction((a,)).size()
    ps = positive_successor((a,)).size()
    delayed = delayed_uniqueness((a,)).size()
    rows = [
        ("original_SS_binary", iterator, ss, old_e),
        ("original_SS_flat_meet", iterator, ss, flat),
        ("original_SS_full_PR", ordinary, ss, old_e),
        ("new_substitution_SS_Off", substituted, ss, off),
        ("PC_Sep_Min_binary", iterator, pc, sep + minimum),
        ("PI_full_PR", ordinary, pi, sep),
        ("PS_Ret_full_PR", ordinary, ps, retract),
        ("historical_delayed_uniqueness_display", iterator, delayed, 0),
    ]
    counts = {name: {"computation": d, "arithmetic": ar, "fixed": fixed,
                     "total": d + ar + fixed} for name, d, ar, fixed in rows}
    expected = [58, 57, 60, 54, 63, 62, 65, 52]
    assert [counts[name]["total"] for name, *_ in rows] == expected
    parameter_checks = []
    for m in range(1, 9):
        params = (a, *(Node(f"b{i}") for i in range(1, m)))
        d_old = ordinary_definitions(params)
        d_new = ordinary_definitions(params, True)
        arithmetic = stationary_separation(params).size()
        assert d_old == 7 * m + 13
        assert d_new == 7 * m + 14
        assert arithmetic == 5 * m + 17
        assert d_old + arithmetic + old_e - (d_new + arithmetic + off) == 6
        parameter_checks.append({"parameters": m, "old": 12*m + 48,
                                 "new": 12*m + 42, "saving": 6})
    descriptor = {
        "g_B_y_one": call("B", y, one).size(),
        "h_expanded_selector": call("P", call("B", y, one), v).size(),
        "k_expanded_predecessor": call("P", y, zero).size(),
    }
    assert list(descriptor.values()) == [4, 6, 3]
    result = {
        "metric": "AST templates; one node per symbol occurrence and quantifier",
        "scope": "Counts do not include all program bodies, symbol-name encodings, "
                 "or the implementation of the effective grammar.",
        "one_parameter_comparison": counts,
        "uniform_parameter_checks": parameter_checks,
        "equality_descriptor_bodies": descriptor,
        "historical_caution": "The 52-node display has a separate delayed-descriptor "
                              "transformation and is not the new theory.",
    }
    destination = Path(__file__).with_name("schema_metrics.json")
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
