#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 artifacts/schema_metrics.py
python3 artifacts/check_compiler.py
if [[ -n "${PRA_LEAN_BIN:-}" ]]; then
  "$PRA_LEAN_BIN" formal/Bootstrap.lean
elif command -v lean >/dev/null 2>&1; then
  lean formal/Bootstrap.lean
else
  printf '%s\n' 'Lean not on PATH; set PRA_LEAN_BIN to a Lean 4.19.0 executable.'
  printf '%s\n' 'The included successful Lean log records the delivered verification.'
fi
