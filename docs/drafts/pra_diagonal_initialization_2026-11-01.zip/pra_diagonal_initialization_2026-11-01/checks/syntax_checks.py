#!/usr/bin/env python3
"""Reproducible finite checks for diagonal initialization.

This standard-library-only program checks syntax transformations, admission,
round trips, and the disclosed schema-display metric.  It does not verify a
first-order proof calculus, arithmetic completeness, or bi-interpretability.

Run with Python 3.10 or later:
    python3 syntax_checks.py
The default output is syntax_results.json beside this file.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import platform
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Union


# Finite term syntax.  Function bodies are metadata of function symbols, not
# free variables of an application.  Here names are atomic identifiers; the
# separate well-founded language-generation theorem is outside this check.
@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Succ:
    term: Term


@dataclass(frozen=True)
class Symbol:
    name: str
    arity: int = 2


@dataclass(frozen=True)
class App:
    symbol: Symbol
    args: tuple[Term, ...]

    def __post_init__(self):
        if len(self.args) != self.symbol.arity:
            raise ValueError("Application arity does not match its symbol")


Term = Union[Var, Zero, Succ, App]


# Complete formula grammar used in the report: equality, falsity, the three
# positive connectives, and quantifiers.  Matrices are schematic placeholders
# used ONLY to compute the display metric; admission rejects them.
@dataclass(frozen=True)
class Eq:
    left: Term
    right: Term


@dataclass(frozen=True)
class Bot:
    pass


@dataclass(frozen=True)
class And:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Or:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Imp:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Forall:
    variable: str
    body: Formula


@dataclass(frozen=True)
class Exists:
    variable: str
    body: Formula


@dataclass(frozen=True)
class Matrix:
    name: str
    args: tuple[Term, ...]


Formula = Union[Eq, Bot, And, Or, Imp, Forall, Exists, Matrix]
Node = Union[Term, Formula]
PathAddress = tuple[int, ...]

N = Var("n")
A = Var("a")
O = Zero()
R = Symbol("R_h")
K = Symbol("R_k")
H = Symbol("h")  # Schematic stored update, used only in metric displays.
EPSILON = Eq(O, Succ(O))
TOP = Eq(O, O)


def r0(term: Term = A, recursor: Symbol = R) -> Term:
    return App(recursor, (O, term))


def children(node: Node) -> tuple[Node, ...]:
    if isinstance(node, (Var, Zero, Bot)):
        return ()
    if isinstance(node, Succ):
        return (node.term,)
    if isinstance(node, (App, Matrix)):
        return node.args
    if isinstance(node, (Eq, And, Or, Imp)):
        return (node.left, node.right)
    if isinstance(node, (Forall, Exists)):
        return (node.body,)
    raise TypeError(type(node))


def rebuild(node: Node, parts: tuple[Node, ...]) -> Node:
    if isinstance(node, (Var, Zero, Bot)):
        if parts:
            raise ValueError("A leaf cannot have children")
        return node
    if isinstance(node, Succ):
        return Succ(parts[0])
    if isinstance(node, App):
        return App(node.symbol, tuple(parts))
    if isinstance(node, Matrix):
        return Matrix(node.name, tuple(parts))
    if isinstance(node, (Eq, And, Or, Imp)):
        return type(node)(*parts)
    if isinstance(node, (Forall, Exists)):
        return type(node)(node.variable, parts[0])
    raise TypeError(type(node))


def size(node: Node) -> int:
    """One node per occurrence; quantifier variable labels are not extra nodes."""
    return 1 + sum(size(child) for child in children(node))


def free_variables(node: Node) -> frozenset[str]:
    if isinstance(node, Var):
        return frozenset((node.name,))
    names = frozenset().union(*(free_variables(c) for c in children(node)))
    if isinstance(node, (Forall, Exists)):
        names -= {node.variable}
    return names


def is_qf(node: Node) -> bool:
    if isinstance(node, (Forall, Exists, Matrix)):
        return False
    return all(is_qf(child) for child in children(node))


def is_term(node: Node) -> bool:
    if isinstance(node, (Var, Zero)):
        return True
    if isinstance(node, Succ):
        return is_term(node.term)
    if isinstance(node, App):
        return all(is_term(argument) for argument in node.args)
    return False


def is_formula(node: Node) -> bool:
    if isinstance(node, Bot):
        return True
    if isinstance(node, Eq):
        return is_term(node.left) and is_term(node.right)
    if isinstance(node, (And, Or, Imp)):
        return is_formula(node.left) and is_formula(node.right)
    if isinstance(node, (Forall, Exists)):
        return is_formula(node.body)
    if isinstance(node, Matrix):
        return all(is_term(argument) for argument in node.args)
    return False


def require_matrix(formula: Formula) -> None:
    if not is_formula(formula) or not is_qf(formula):
        raise ValueError("The matrix must be an actual quantifier-free formula")
    if not free_variables(formula) <= {"n", "a"}:
        raise ValueError("Only n and a may be free")


def substitute(node: Node, replacements: dict[str, Term]) -> Node:
    """Simultaneous, one-pass substitution on binder-free syntax.

    No substitution is made inside an inserted replacement.  Quantifiers are
    deliberately rejected: full capture-avoiding first-order substitution is
    not needed by, or claimed for, this implementation.
    """
    if isinstance(node, Var):
        return replacements.get(node.name, node)
    if isinstance(node, (Forall, Exists)):
        raise ValueError("This substitution interface is binder-free")
    return rebuild(node, tuple(substitute(c, replacements) for c in children(node)))


def variable_positions(node: Node, name: str) -> tuple[PathAddress, ...]:
    found: list[PathAddress] = []

    def visit(current: Node, path: PathAddress):
        if isinstance(current, Var) and current.name == name:
            found.append(path)
        for i, child in enumerate(children(current)):
            visit(child, path + (i,))

    visit(node, ())
    return tuple(found)


def selective_base(
    matrix: Formula, marked: frozenset[PathAddress], recursor: Symbol = R
) -> Formula:
    """Set n to 0 and replace precisely the marked original a occurrences."""
    require_matrix(matrix)
    if not marked <= set(variable_positions(matrix, "a")):
        raise ValueError("A mark must identify an original occurrence of a")

    def visit(current: Node, path: PathAddress) -> Node:
        if isinstance(current, Var):
            if current.name == "n":
                return O
            if current.name == "a" and path in marked:
                return r0(A, recursor)
            return current
        return rebuild(
            current,
            tuple(visit(child, path + (i,)) for i, child in enumerate(children(current))),
        )

    return visit(matrix, ())


def formal_template(matrix: Formula, marked: frozenset[PathAddress]) -> Formula:
    """Recover F(x,z,w): marked a becomes z; unmarked a becomes w."""
    require_matrix(matrix)
    if not marked <= set(variable_positions(matrix, "a")):
        raise ValueError("Invalid mark")

    def visit(current: Node, path: PathAddress) -> Node:
        if isinstance(current, Var):
            if current.name == "n":
                return Var("x")
            if current.name == "a":
                return Var("z" if path in marked else "w")
        return rebuild(
            current,
            tuple(visit(child, path + (i,)) for i, child in enumerate(children(current))),
        )

    return visit(matrix, ())


class NoMatch(Exception):
    pass


def recover_template(
    matrix: Formula, base: Formula, recursor: Symbol = R
) -> Formula | None:
    """Joint structural matcher, independent of the marking generator.

    At an n leaf in C, D must have 0.  At an a leaf, D must have
    either a or R_h(0,a).  All other constructors and symbol names must
    agree.  Successful matching returns its unique F(x,z,w) witness.
    """
    try:
        require_matrix(matrix)
        if not is_formula(base) or not is_qf(base):
            raise NoMatch

        def visit(c: Node, d: Node) -> Node:
            if isinstance(c, Var):
                if c.name == "n" and d == O:
                    return Var("x")
                if c.name == "a" and d == A:
                    return Var("w")
                if c.name == "a" and d == r0(A, recursor):
                    return Var("z")
                raise NoMatch
            if type(c) is not type(d):
                raise NoMatch
            if isinstance(c, App) and c.symbol != d.symbol:
                raise NoMatch
            if isinstance(c, (Forall, Exists, Matrix)):
                raise NoMatch
            c_parts, d_parts = children(c), children(d)
            if len(c_parts) != len(d_parts):
                raise NoMatch
            return rebuild(c, tuple(visit(x, y) for x, y in zip(c_parts, d_parts)))

        return visit(matrix, base)
    except (NoMatch, ValueError):
        return None


@dataclass(frozen=True)
class Admission:
    matrix: Formula
    base: Formula
    template: Formula


def admit(
    formula: Formula, recursor: Symbol = R, max_marks: int | None = 1
) -> Admission | None:
    """Recognize A(n,a) = (D(a) or epsilon) -> C(n,a).

    The recommended theory permits at most ONE marked seed occurrence.
    max_marks=None is available only to diagnose the larger optional family.
    """
    if not isinstance(formula, Imp) or not isinstance(formula.left, Or):
        return None
    if formula.left.right != EPSILON:
        return None
    c, d = formula.right, formula.left.left
    witness = recover_template(c, d, recursor)
    if witness is None:
        return None
    if max_marks is not None and len(variable_positions(witness, "z")) > max_marks:
        return None
    return Admission(c, d, witness)


def wrapper(matrix: Formula, marked: frozenset[PathAddress], recursor: Symbol = R):
    return Imp(Or(selective_base(matrix, marked, recursor), EPSILON), matrix)


def to_data(node: Node):
    if isinstance(node, Var):
        return ["var", node.name]
    if isinstance(node, Zero):
        return ["zero"]
    if isinstance(node, Bot):
        return ["bot"]
    if isinstance(node, Succ):
        return ["succ", to_data(node.term)]
    if isinstance(node, App):
        return ["app", node.symbol.name, node.symbol.arity, [to_data(x) for x in node.args]]
    if isinstance(node, Matrix):
        return ["matrix", node.name, [to_data(x) for x in node.args]]
    if isinstance(node, (Eq, And, Or, Imp)):
        return [type(node).__name__.lower(), to_data(node.left), to_data(node.right)]
    if isinstance(node, (Forall, Exists)):
        return [type(node).__name__.lower(), node.variable, to_data(node.body)]
    raise TypeError(type(node))


def from_data(data) -> Node:
    if not isinstance(data, list) or not data or not isinstance(data[0], str):
        raise ValueError("A syntax node must be a nonempty tagged list")
    tag = data[0]
    if tag in {"zero", "bot"} and len(data) == 1:
        return Zero() if tag == "zero" else Bot()
    if tag == "var" and len(data) == 2 and isinstance(data[1], str):
        return Var(data[1])
    if tag == "succ" and len(data) == 2:
        return Succ(from_data(data[1]))
    if tag == "app" and len(data) == 4 and isinstance(data[1], str):
        if not isinstance(data[2], int) or data[2] < 0 or not isinstance(data[3], list):
            raise ValueError("Malformed application")
        return App(Symbol(data[1], data[2]), tuple(from_data(x) for x in data[3]))
    if tag == "matrix" and len(data) == 3 and isinstance(data[1], str):
        return Matrix(data[1], tuple(from_data(x) for x in data[2]))
    binary = {"eq": Eq, "and": And, "or": Or, "imp": Imp}
    if tag in binary and len(data) == 3:
        return binary[tag](from_data(data[1]), from_data(data[2]))
    if tag in {"forall", "exists"} and len(data) == 3 and isinstance(data[1], str):
        constructor = Forall if tag == "forall" else Exists
        return constructor(data[1], from_data(data[2]))
    raise ValueError("Unknown or malformed syntax node")


def universal(variables: tuple[str, ...], formula: Formula) -> Formula:
    for variable in reversed(variables):
        formula = Forall(variable, formula)
    return formula


R0_BODY = Eq(r0(), A)
RS_BODY = Eq(App(R, (Succ(N), A)), App(H, (N, App(R, (N, A)))))
R0_AXIOM = Forall("a", R0_BODY)
RS_AXIOM = universal(("n", "a"), RS_BODY)
SEP_AXIOM = Imp(EPSILON, Bot())


def progress(matrix_at) -> Formula:
    return Forall("n", Imp(matrix_at(N), matrix_at(Succ(N))))


def fused_closure(matrix_at) -> Formula:
    return Forall("a", Imp(progress(matrix_at), Forall("n", And(matrix_at(N), RS_BODY))))


def metric_checks():
    f = lambda t, s, w: Matrix("F", (t, s, w))
    diagonal = lambda t: f(t, A, A)
    diagonal_base = f(O, r0(), A)
    direct = Forall(
        "a",
        Imp(
            And(Or(diagonal_base, EPSILON), progress(diagonal)),
            Forall("n", And(diagonal(N), RS_BODY)),
        ),
    )
    compact = fused_closure(lambda t: Matrix("A", (t, A)))
    expanded = fused_closure(lambda t: Imp(Or(diagonal_base, EPSILON), diagonal(t)))
    ordinary = lambda t: Matrix("C", (t, A))
    naive_all_fused = Forall(
        "a",
        Imp(
            And(Or(ordinary(O), EPSILON), progress(ordinary)),
            Forall("n", And(ordinary(N), And(R0_BODY, RS_BODY))),
        ),
    )
    assert size(R0_AXIOM) == 6
    assert size(RS_AXIOM) == 12
    assert size(SEP_AXIOM) == 6
    assert size(direct) == 41
    assert size(compact) == 26
    assert size(expanded) == 65
    assert size(naive_all_fused) == 41
    assert size(compact) + size(R0_AXIOM) + size(SEP_AXIOM) == 38
    profiles = []
    for q in range(5):
        names = tuple(f"c{i}" for i in range(q))
        params = tuple(Var(name) for name in names)
        m = lambda t: Matrix("F", (t,) + params)
        old_fused = universal(
            names,
            Imp(And(Or(m(O), EPSILON), progress(m)), Forall("n", m(N))),
        )
        old_reflexive = universal(names, Imp(progress(m), Forall("n", m(N))))
        old_fused_total = size(R0_AXIOM) + size(RS_AXIOM) + size(old_fused)
        old_reflexive_total = (
            size(R0_AXIOM) + size(RS_AXIOM) + size(SEP_AXIOM) + size(old_reflexive)
        )
        assert old_fused_total == 37 + 5 * q
        assert old_reflexive_total == 35 + 4 * q
        am = lambda t, s: Matrix("A", (t, s) + params)
        old_implicit = universal(
            ("a",) + names,
            Imp(
                And(Or(am(O, r0()), EPSILON), progress(lambda t: am(t, A))),
                Forall("n", And(am(N, A), RS_BODY)),
            ),
        )
        assert size(old_implicit) == 37 + 5 * q
        profiles.append(
            {
                "q": q,
                "fused_basis_with_q_frozen_parameters": old_fused_total,
                "reflexive_basis_with_q_frozen_parameters": old_reflexive_total,
                "implicit_basis_with_q_extra_parameters_besides_seed": size(old_implicit),
            }
        )
    for node in (direct, compact, expanded, naive_all_fused, R0_AXIOM, RS_AXIOM, SEP_AXIOM):
        assert from_data(json.loads(json.dumps(to_data(node)))) == node
    return {
        "definition": "One AST node per occurrence, including schematic application and argument nodes; quantifier variable labels are not additional nodes. The metric excludes admission grammar, descriptor bodies, and substituted matrix bodies.",
        "R0": size(R0_AXIOM),
        "RS": size(RS_AXIOM),
        "separation_expanded": size(SEP_AXIOM),
        "direct_diagonal_schema": size(direct),
        "naive_all_computation_fusion": size(naive_all_fused),
        "compact_admitted_A_schema": size(compact),
        "compact_after_expanding_A_using_F": size(expanded),
        "guarded_reflexive_variant_with_explicit_R0": size(compact) + size(R0_AXIOM),
        "plain_reflexive_with_RS_fused_and_explicit_R0_and_separation": size(compact) + size(R0_AXIOM) + size(SEP_AXIOM),
        "current_one_parameter_fused_basis": 42,
        "current_reflexive_basis_at_one_parameter": 39,
        "current_implicit_basis_at_equality_probe_arity": 42,
        "parameter_profiles": profiles,
        "caveat": "The 26-node number excludes the explicit admission grammar; its F-expanded template has 65 nodes. This is not a concrete-axiom shortening from 41 to 26.",
        "concrete_instance_formulas": {
            "notation": "c=|C(n,a)|, s=|C(Sn,a)|, e=|C(0,a)|, k=number of marked a leaves (0 or 1), d=|D(a)|=e+2k.",
            "direct_diagonal": "d+2c+s+22",
            "naive_all_computation_fusion": "e+2c+s+28",
            "unfused_R0_RS_and_fused_induction_basis": "e+2c+s+29",
            "compact_expanded": "3d+2c+s+34",
            "direct_saving_against_naive_joint_at_k0_k1": [6, 4],
            "direct_saving_against_unfused_basis_at_k0_k1": [7, 5],
            "compact_expansion_excess_over_direct": "2d+12",
        },
    }


def unique(nodes):
    return list(dict.fromkeys(nodes))


def corpus():
    rng = random.Random(20261101)
    leaves = (O, N, A)
    terms = list(leaves)
    terms.extend(Succ(t) for t in leaves)
    terms.extend(App(symbol, (x, y)) for symbol in (R, K) for x in leaves for y in leaves)
    terms.extend((r0(r0()), Succ(App(K, (A, N))), App(R, (Succ(N), r0()))))
    formulas: list[Formula] = [Bot()]
    formulas.extend(Eq(x, y) for x in terms for y in terms)
    atoms = tuple(formulas)
    for i, atom in enumerate(atoms):
        peer = atoms[(i * 37 + 11) % len(atoms)]
        formulas.append((And, Or, Imp)[i % 3](atom, peer))

    def random_term(depth: int) -> Term:
        if depth == 0 or rng.randrange(4) == 0:
            return rng.choice(leaves)
        if rng.randrange(3) == 0:
            return Succ(random_term(depth - 1))
        return App(rng.choice((R, K)), (random_term(depth - 1), random_term(depth - 1)))

    def random_formula(depth: int) -> Formula:
        if depth == 0 or rng.randrange(4) == 0:
            if rng.randrange(11) == 0:
                return Bot()
            return Eq(random_term(2), random_term(2))
        return rng.choice((And, Or, Imp))(random_formula(depth - 1), random_formula(depth - 1))

    formulas.extend(random_formula(3) for _ in range(600))
    return unique(formulas)


def markings(positions: tuple[PathAddress, ...], rng: random.Random):
    if len(positions) <= 5:
        return tuple(
            frozenset(p for p, bit in zip(positions, bits) if bit)
            for bits in itertools.product((False, True), repeat=len(positions))
        )
    choices = [frozenset(), frozenset(positions), frozenset(positions[::2]), frozenset(positions[1::2])]
    choices.extend(frozenset((position,)) for position in positions)
    choices.extend(frozenset(p for p in positions if rng.randrange(2)) for _ in range(8))
    return tuple(unique(choices))


def finite_checks():
    formulas = corpus()
    rng = random.Random(261101)
    total = 0
    single_mark_total = 0
    multiple_mark_rejections = 0
    savings = {"0": {"joint": set(), "unfused": set()}, "1": {"joint": set(), "unfused": set()}}
    maximum_marks = 0
    all_addresses = []
    digest = hashlib.sha256()
    for c in formulas:
        require_matrix(c)
        assert from_data(json.loads(json.dumps(to_data(c)))) == c
        ps = variable_positions(c, "a")
        maximum_marks = max(maximum_marks, len(ps))
        all_addresses.append(len(ps))
        for marks in markings(ps, rng):
            d = selective_base(c, marks)
            f = formal_template(c, marks)
            recovered = recover_template(c, d)
            assert recovered == f
            assert substitute(f, {"x": N, "z": A, "w": A}) == c
            assert substitute(f, {"x": O, "z": r0(), "w": A}) == d
            assert free_variables(d) <= {"a"}
            normalized = wrapper(c, marks)
            result = admit(normalized, max_marks=None)
            assert result == Admission(c, d, f)
            if len(marks) <= 1:
                assert admit(normalized) == result
                single_mark_total += 1
                c_at = lambda term: substitute(c, {"n": term})
                e = c_at(O)
                s = c_at(Succ(N))
                direct = Forall(
                    "a",
                    Imp(
                        And(Or(d, EPSILON), progress(c_at)),
                        Forall("n", And(c, RS_BODY)),
                    ),
                )
                joint = Forall(
                    "a",
                    Imp(
                        And(Or(e, EPSILON), progress(c_at)),
                        Forall("n", And(c, And(R0_BODY, RS_BODY))),
                    ),
                )
                old_fused = Forall(
                    "a", Imp(And(Or(e, EPSILON), progress(c_at)), Forall("n", c))
                )
                expanded = fused_closure(lambda term: Imp(Or(d, EPSILON), c_at(term)))
                direct_size = size(direct)
                joint_size = size(joint)
                unfused_size = size(R0_AXIOM) + size(RS_AXIOM) + size(old_fused)
                assert size(d) == size(e) + 2 * len(marks)
                assert direct_size == size(d) + 2 * size(c) + size(s) + 22
                assert joint_size == size(e) + 2 * size(c) + size(s) + 28
                assert unfused_size == size(e) + 2 * size(c) + size(s) + 29
                assert size(expanded) == 3 * size(d) + 2 * size(c) + size(s) + 34
                assert size(expanded) - direct_size == 2 * size(d) + 12
                assert joint_size - direct_size == 6 - 2 * len(marks)
                assert unfused_size - direct_size == 7 - 2 * len(marks)
                savings[str(len(marks))]["joint"].add(joint_size - direct_size)
                savings[str(len(marks))]["unfused"].add(unfused_size - direct_size)
            else:
                assert admit(normalized) is None
                multiple_mark_rejections += 1
            assert free_variables(normalized) <= {"n", "a"}
            assert from_data(json.loads(json.dumps(to_data(normalized)))) == normalized
            digest.update(json.dumps(to_data(normalized), separators=(",", ":")).encode())
            total += 1

    controls = {}
    # The equality probe marks only the left occurrence; the occurrence of a
    # already inside the right-hand R_h is deliberately left untouched.
    c = Eq(A, r0())
    left_only = frozenset(((0,),))
    d = selective_base(c, left_only)
    assert d == Eq(r0(), r0())
    assert admit(wrapper(c, left_only)) is not None
    assert formal_template(c, left_only) == Eq(Var("z"), r0(Var("w")))
    controls["initialization_probe_with_partial_replacement"] = "accepted"

    c_existing = Eq(r0(), A)
    all_marks = frozenset(variable_positions(c_existing, "a"))
    assert selective_base(c_existing, all_marks) == Eq(r0(r0()), r0())
    assert admit(wrapper(c_existing, all_marks), max_marks=None) is not None
    assert admit(wrapper(c_existing, all_marks)) is None
    controls["two_mark_variant_in_recommended_theory"] = "rejected"
    inside_only = frozenset((variable_positions(c_existing, "a")[0],))
    assert selective_base(c_existing, inside_only) == Eq(r0(r0()), A)
    assert admit(wrapper(c_existing, inside_only)) is not None
    controls["one_replacement_inside_existing_application"] = "accepted"

    assert admit(wrapper(Bot(), frozenset())) is not None
    assert admit(wrapper(TOP, frozenset())) is not None
    controls["separation_probe_and_successor_equation_probe"] = "accepted"

    invalid = {
        "recursive_rewriting_inside_inserted_term": Imp(Or(Eq(r0(r0()), O), EPSILON), Eq(A, O)),
        "wrong_recursor_name": Imp(Or(Eq(r0(A, K), O), EPSILON), Eq(A, O)),
        "incorrect_counter_base": Imp(Or(Eq(Succ(O), A), EPSILON), Eq(N, A)),
        "rewritten_zero_constant": Imp(Or(Eq(r0(), A), EPSILON), Eq(O, A)),
        "extra_free_variable": Imp(Or(Eq(O, Var("c")), EPSILON), Eq(N, Var("c"))),
        "quantified_matrix": Imp(Or(Forall("n", TOP), EPSILON), Forall("n", TOP)),
        "schematic_placeholder_as_actual_matrix": Imp(Or(Matrix("C", (O, A)), EPSILON), Matrix("C", (N, A))),
        "wrong_exception": Imp(Or(TOP, Eq(Succ(O), O)), TOP),
        "wrong_outer_shape": Or(Imp(TOP, TOP), EPSILON),
        "term_used_in_place_of_formula": Imp(Or(A, EPSILON), A),
    }
    for label, formula in invalid.items():
        assert admit(formula) is None, label
        controls[label] = "rejected"

    for label, thunk in {
        "mark_nonvariable_node": lambda: selective_base(Eq(A, O), frozenset(((),))),
        "mark_counter_instead_of_seed": lambda: selective_base(Eq(N, A), frozenset(((0,),))),
        "substitution_under_binder": lambda: substitute(Forall("a", TOP), {"a": O}),
        "incorrect_function_arity": lambda: App(R, (A,)),
        "malformed_serialized_node": lambda: from_data(["undefined", 1, 2]),
    }.items():
        try:
            thunk()
        except ValueError:
            controls[label] = "rejected"
        else:
            raise AssertionError(label)

    return {
        "deterministic_seed": 20261101,
        "distinct_quantifier_free_matrices": len(formulas),
        "admitted_marked_wrappers_checked": total,
        "recommended_zero_or_one_mark_wrappers_checked": single_mark_total,
        "larger_family_wrappers_rejected_by_single_mark_restriction": multiple_mark_rejections,
        "maximum_seed_occurrences_in_a_matrix": maximum_marks,
        "all_markings_exhausted_when_seed_occurrences_at_most": 5,
        "normalized_corpus_sha256": digest.hexdigest(),
        "checks": [
            "independent generator and structural matcher agree",
            "unique F(x,z,w) witness reconstructed",
            "both diagonal substitutions reproduce C and D",
            "only the advertised free variables survive",
            "simultaneous one-pass occurrence replacement",
            "AST serialization round trips",
            "every zero-mark and every one-mark variant of every corpus matrix",
            "exact concrete-instance count and saving formulas",
        ],
        "observed_concrete_savings": {
            k: {name: sorted(values) for name, values in families.items()}
            for k, families in savings.items()
        },
        "positive_and_negative_controls": controls,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("syntax_results.json"))
    args = parser.parse_args()
    report = {
        "status": "all finite checks passed",
        "scope": "Executable syntax and display-metric diagnostics only. Mathematical equivalence is proved in the manuscript, not established by this finite corpus.",
        "python": platform.python_version(),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "metric": metric_checks(),
        "finite_syntax_checks": finite_checks(),
    }
    text = json.dumps(report, indent=2, sort_keys=True) + "\n"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(text, encoding="utf-8")
    print(text, end="")


if __name__ == "__main__":
    main()
