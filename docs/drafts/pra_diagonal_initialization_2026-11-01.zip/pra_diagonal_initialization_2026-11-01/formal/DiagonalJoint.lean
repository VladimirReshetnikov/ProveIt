import Init

/-!
Concrete quantifier-free syntax check for the diagonal seed-probe schema
and its compact occurrence-mask normalization, including the stronger
at-most-one-mark admission grammar.
This file proves the logical reduction for one selected binary function symbol.
The interpretation of all binary symbols and the selected update is arbitrary.
No induction over arbitrary carrier predicates is assumed: the induction basis
ranges only over the concrete `QF` syntax below. Both the direct and compact
schemas are proved equivalent to R0, RS, separation, and induction on concrete
2-variable QF syntax. This does not formalize the primitive-recursive descriptor
grammar, arithmetic bootstrap, object-language proof calculus, or round trips.
-/

universe u v w
namespace DiagonalJoint

theorem congrTwo {α : Sort u} {β : Sort v} {γ : Sort w}
    (f : α → β → γ) {a a' : α} {b b' : β}
    (ha : a = a') (hb : b = b') : f a b = f a' b' := by
  cases ha
  cases hb
  rfl

inductive Tm (Symbol : Type u) (arity : Nat) where
  | var : Fin arity → Tm Symbol arity
  | zero : Tm Symbol arity
  | succ : Tm Symbol arity → Tm Symbol arity
  | app : Symbol → Tm Symbol arity → Tm Symbol arity → Tm Symbol arity

inductive QF (Symbol : Type u) (arity : Nat) where
  | eq : Tm Symbol arity → Tm Symbol arity → QF Symbol arity
  | bot : QF Symbol arity
  | and : QF Symbol arity → QF Symbol arity → QF Symbol arity
  | or : QF Symbol arity → QF Symbol arity → QF Symbol arity
  | imp : QF Symbol arity → QF Symbol arity → QF Symbol arity

variable {Symbol : Type u} {D : Type v}

structure Interpretation (Symbol : Type u) (D : Type v) where
  zero : D
  succ : D → D
  fn : Symbol → D → D → D

def val (x z w : D) : Fin 3 → D := fun i =>
  match i.val with
  | 0 => x
  | 1 => z
  | _ => w

def Tm.eval (I : Interpretation Symbol D) {arity : Nat} (ρ : Fin arity → D) : Tm Symbol arity → D
  | .var i => ρ i
  | .zero => I.zero
  | .succ t => I.succ (t.eval I ρ)
  | .app f s t => I.fn f (s.eval I ρ) (t.eval I ρ)

def QF.eval (I : Interpretation Symbol D) {arity : Nat} (ρ : Fin arity → D) : QF Symbol arity → Prop
  | .eq s t => s.eval I ρ = t.eval I ρ
  | .bot => False
  | .and A B => A.eval I ρ ∧ B.eval I ρ
  | .or A B => A.eval I ρ ∨ B.eval I ρ
  | .imp A B => A.eval I ρ → B.eval I ρ


/-- Syntactic renaming never creates a new function symbol or quantifier. -/
def Tm.rename {m n : Nat} (f : Fin m → Fin n) : Tm Symbol m → Tm Symbol n
  | .var i => .var (f i)
  | .zero => .zero
  | .succ t => .succ (t.rename f)
  | .app g s t => .app g (s.rename f) (t.rename f)

def QF.rename {m n : Nat} (f : Fin m → Fin n) : QF Symbol m → QF Symbol n
  | .eq s t => .eq (s.rename f) (t.rename f)
  | .bot => .bot
  | .and A B => .and (A.rename f) (B.rename f)
  | .or A B => .or (A.rename f) (B.rename f)
  | .imp A B => .imp (A.rename f) (B.rename f)

theorem Tm.eval_rename (I : Interpretation Symbol D) {m n : Nat}
    (f : Fin m → Fin n) (ρ : Fin n → D) (t : Tm Symbol m) :
    (t.rename f).eval I ρ = t.eval I (fun i => ρ (f i)) := by
  induction t with
  | var i => rfl
  | zero => rfl
  | succ t ih => exact congrArg I.succ ih
  | app g s t ihs iht => exact congrTwo (I.fn g) ihs iht

theorem QF.eval_rename (I : Interpretation Symbol D) {m n : Nat}
    (f : Fin m → Fin n) (ρ : Fin n → D) (A : QF Symbol m) :
    (A.rename f).eval I ρ = A.eval I (fun i => ρ (f i)) := by
  induction A with
  | eq s t => exact congrTwo Eq (Tm.eval_rename I f ρ s) (Tm.eval_rename I f ρ t)
  | bot => rfl
  | and A B ihA ihB => exact congrTwo And ihA ihB
  | or A B ihA ihB => exact congrTwo Or ihA ihB
  | imp A B ihA ihB => exact congrTwo (fun P Q : Prop => P → Q) ihA ihB

theorem Tm.eval_congr (I : Interpretation Symbol D) {m : Nat}
    (ρ σ : Fin m → D) (H : ∀ i, ρ i = σ i) (t : Tm Symbol m) :
    t.eval I ρ = t.eval I σ := by
  induction t with
  | var i => exact H i
  | zero => rfl
  | succ t ih => exact congrArg I.succ ih
  | app g s t ihs iht => exact congrTwo (I.fn g) ihs iht

theorem QF.eval_congr (I : Interpretation Symbol D) {m : Nat}
    (ρ σ : Fin m → D) (H : ∀ i, ρ i = σ i) (A : QF Symbol m) :
    A.eval I ρ = A.eval I σ := by
  induction A with
  | eq s t => exact congrTwo Eq (Tm.eval_congr I ρ σ H s) (Tm.eval_congr I ρ σ H t)
  | bot => rfl
  | and A B ihA ihB => exact congrTwo And ihA ihB
  | or A B ihA ihB => exact congrTwo Or ihA ihB
  | imp A B ihA ihB => exact congrTwo (fun P Q : Prop => P → Q) ihA ihB

def val2 (x a : D) : Fin 2 → D := fun i => if i.val = 0 then x else a

def diagVar (i : Fin 3) : Fin 2 :=
  if i.val = 0 then ⟨0, by decide⟩ else ⟨1, by decide⟩

def liftVar (i : Fin 2) : Fin 3 := ⟨i.val, Nat.lt_trans i.isLt (by decide)⟩

theorem eval_diagonal (I : Interpretation Symbol D) (F : QF Symbol 3) (x a : D) :
    (F.rename diagVar).eval I (val2 x a) = F.eval I (val x a a) := by
  rw [QF.eval_rename]
  apply QF.eval_congr
  intro i
  rcases i with ⟨i, hi⟩
  cases i with
  | zero => rfl
  | succ i => cases i <;> rfl

theorem eval_lift (I : Interpretation Symbol D) (A : QF Symbol 2) (x a : D) :
    (A.rename liftVar).eval I (val x a a) = A.eval I (val2 x a) := by
  rw [QF.eval_rename]
  apply QF.eval_congr
  intro i
  rcases i with ⟨i, hi⟩
  cases i with
  | zero => rfl
  | succ i => cases i <;> rfl

def Induction2 (I : Interpretation Symbol D) : Prop :=
  ∀ (A : QF Symbol 2) a,
    A.eval I (val2 I.zero a) →
    (∀ n, A.eval I (val2 n a) → A.eval I (val2 (I.succ n) a)) →
    ∀ n, A.eval I (val2 n a)

abbrev denote (I : Interpretation Symbol D) (A : QF Symbol 3) (x z w : D) : Prop :=
  A.eval I (val x z w)

def R0 (I : Interpretation Symbol D) (r : Symbol) : Prop :=
  ∀ a, I.fn r I.zero a = a

def RS (I : Interpretation Symbol D) (r : Symbol) (h : D → D → D) : Prop :=
  ∀ n a, I.fn r (I.succ n) a = h n (I.fn r n a)

/-- All matrices here use at most the counter and one actual parameter.
The third formal slot is identified with the second, and any ordinary
2-variable QF formula embeds by ignoring the third slot. -/
def DiagonalInduction (I : Interpretation Symbol D) : Prop :=
  ∀ (A : QF Symbol 3) a,
    denote I A I.zero a a →
    (∀ n, denote I A n a a → denote I A (I.succ n) a a) →
    ∀ n, denote I A n a a

def Joint (I : Interpretation Symbol D) (r : Symbol) (h : D → D → D) : Prop :=
  ∀ (F : QF Symbol 3) a,
    ((denote I F I.zero (I.fn r I.zero a) a ∨ I.zero = I.succ I.zero) ∧
     (∀ n, denote I F n a a → denote I F (I.succ n) a a)) →
    ∀ n, denote I F n a a ∧ I.fn r (I.succ n) a = h n (I.fn r n a)

def Separate (I : Interpretation Symbol D) (r : Symbol) (h : D → D → D) : Prop :=
  R0 I r ∧ RS I r h ∧ (I.zero ≠ I.succ I.zero) ∧ DiagonalInduction I

def seed : Tm Symbol 3 := .var ⟨1, by decide⟩
def probe : Tm Symbol 3 := .var ⟨2, by decide⟩
def initializationProbe (r : Symbol) : QF Symbol 3 := .eq seed (.app r .zero probe)
def truth : QF Symbol 3 := .eq .zero .zero

theorem initialization {I : Interpretation Symbol D} {r : Symbol} {h : D → D → D}
    (joint : Joint I r h) : R0 I r := by
  intro a
  have hf := joint (initializationProbe r) a
  change (((I.fn r I.zero a = I.fn r I.zero a ∨ I.zero = I.succ I.zero) ∧
    (∀ _ : D, a = I.fn r I.zero a → a = I.fn r I.zero a)) →
    ∀ n, (a = I.fn r I.zero a) ∧ I.fn r (I.succ n) a = h n (I.fn r n a)) at hf
  exact (hf ⟨Or.inl rfl, fun _ p => p⟩ I.zero).1.symm

theorem successorComputation {I : Interpretation Symbol D} {r : Symbol} {h : D → D → D}
    (joint : Joint I r h) : RS I r h := by
  intro n a
  exact (joint truth a ⟨Or.inl rfl, fun _ _ => rfl⟩ n).2

theorem separation {I : Interpretation Symbol D} {r : Symbol} {h : D → D → D}
    (joint : Joint I r h) : I.zero ≠ I.succ I.zero := by
  intro collision
  exact (joint .bot I.zero ⟨Or.inr collision, fun _ p => p⟩ I.zero).1

theorem induction {I : Interpretation Symbol D} {r : Symbol} {h : D → D → D}
    (joint : Joint I r h) : DiagonalInduction I := by
  intro A a base step n
  have shifted : denote I A I.zero (I.fn r I.zero a) a := by
    rw [initialization joint a]
    exact base
  exact (joint A a ⟨Or.inl shifted, step⟩ n).1

theorem joint_implies_separate {I : Interpretation Symbol D} {r : Symbol} {h : D → D → D}
    (joint : Joint I r h) : Separate I r h :=
  ⟨initialization joint, successorComputation joint, separation joint, induction joint⟩

theorem separate_implies_joint {I : Interpretation Symbol D} {r : Symbol} {h : D → D → D}
    (basis : Separate I r h) : Joint I r h := by
  intro F a assumptions n
  have base : denote I F I.zero a a := by
    cases assumptions.1 with
    | inl shifted =>
      rw [basis.1 a] at shifted
      exact shifted
    | inr collision => exact False.elim (basis.2.2.1 collision)
  exact ⟨basis.2.2.2 F a base assumptions.2 n, basis.2.1 n a⟩

theorem equivalence (I : Interpretation Symbol D) (r : Symbol) (h : D → D → D) :
    Joint I r h ↔ Separate I r h :=
  ⟨joint_implies_separate, separate_implies_joint⟩

#print axioms initialization
#print axioms successorComputation
#print axioms separation
#print axioms induction
#print axioms joint_implies_separate
#print axioms separate_implies_joint
#print axioms equivalence


/-- Explicit two-variable syntax has exactly the same induction content
as diagonal evaluation of the three-variable schema interface. -/
theorem diagonal_iff_two_variable (I : Interpretation Symbol D) :
    DiagonalInduction I ↔ Induction2 I := by
  constructor
  · intro di A a base step n
    have b : denote I (A.rename liftVar) I.zero a a := by
      change (A.rename liftVar).eval I (val I.zero a a)
      rw [eval_lift]
      exact base
    have s : ∀ m, denote I (A.rename liftVar) m a a →
        denote I (A.rename liftVar) (I.succ m) a a := by
      intro m hm
      change (A.rename liftVar).eval I (val m a a) at hm
      rw [eval_lift] at hm
      change (A.rename liftVar).eval I (val (I.succ m) a a)
      rw [eval_lift]
      exact step m hm
    have result := di (A.rename liftVar) a b s n
    change (A.rename liftVar).eval I (val n a a) at result
    rw [eval_lift] at result
    exact result
  · intro qi F a base step n
    have b : (F.rename diagVar).eval I (val2 I.zero a) := by
      rw [eval_diagonal]
      exact base
    have s : ∀ m, (F.rename diagVar).eval I (val2 m a) →
        (F.rename diagVar).eval I (val2 (I.succ m) a) := by
      intro m hm
      rw [eval_diagonal] at hm
      rw [eval_diagonal]
      exact step m hm
    have result := qi (F.rename diagVar) a b s n
    rw [eval_diagonal] at result
    exact result

theorem joint_iff_one_parameter_basis
    (I : Interpretation Symbol D) (r : Symbol) (h : D → D → D) :
    Joint I r h ↔
    (R0 I r ∧ RS I r h ∧ (I.zero ≠ I.succ I.zero) ∧ Induction2 I) := by
  constructor
  · intro J
    have b := joint_implies_separate J
    exact ⟨b.1, b.2.1, b.2.2.1, (diagonal_iff_two_variable I).1 b.2.2.2⟩
  · intro b
    exact separate_implies_joint
      ⟨b.1, b.2.1, b.2.2.1, (diagonal_iff_two_variable I).2 b.2.2.2⟩

#print axioms Tm.eval_rename
#print axioms QF.eval_rename
#print axioms eval_diagonal
#print axioms eval_lift
#print axioms diagonal_iff_two_variable
#print axioms joint_iff_one_parameter_basis


/-! ## Compact normalized form

A 3-slot source formula records which occurrences of the single actual seed
are changed at the base. Slot 1 occurrences are replaced by `r(0,a)`; slot 2
occurrences remain `a`. On the diagonal both slots are `a`. Thus these finite
syntax operations implement an occurrence mask, not an induction schema over
unrestricted carrier predicates.
-/

def Tm.subst {m n : Nat} (f : Fin m → Tm Symbol n) : Tm Symbol m → Tm Symbol n
  | .var i => f i
  | .zero => .zero
  | .succ t => .succ (t.subst f)
  | .app g s t => .app g (s.subst f) (t.subst f)

def QF.subst {m n : Nat} (f : Fin m → Tm Symbol n) : QF Symbol m → QF Symbol n
  | .eq s t => .eq (s.subst f) (t.subst f)
  | .bot => .bot
  | .and A B => .and (A.subst f) (B.subst f)
  | .or A B => .or (A.subst f) (B.subst f)
  | .imp A B => .imp (A.subst f) (B.subst f)

theorem Tm.eval_subst (I : Interpretation Symbol D) {m n : Nat}
    (f : Fin m → Tm Symbol n) (ρ : Fin n → D) (t : Tm Symbol m) :
    (t.subst f).eval I ρ = t.eval I (fun i => (f i).eval I ρ) := by
  induction t with
  | var i => rfl
  | zero => rfl
  | succ t ih => exact congrArg I.succ ih
  | app g s t ihs iht => exact congrTwo (I.fn g) ihs iht

theorem QF.eval_subst (I : Interpretation Symbol D) {m n : Nat}
    (f : Fin m → Tm Symbol n) (ρ : Fin n → D) (A : QF Symbol m) :
    (A.subst f).eval I ρ = A.eval I (fun i => (f i).eval I ρ) := by
  induction A with
  | eq s t => exact congrTwo Eq (Tm.eval_subst I f ρ s) (Tm.eval_subst I f ρ t)
  | bot => rfl
  | and A B ihA ihB => exact congrTwo And ihA ihB
  | or A B ihA ihB => exact congrTwo Or ihA ihB
  | imp A B ihA ihB => exact congrTwo (fun P Q : Prop => P → Q) ihA ihB

def baseMap (r : Symbol) (i : Fin 3) : Tm Symbol 3 :=
  match i.val with
  | 0 => .zero
  | 1 => .app r .zero probe
  | _ => probe

def bodyMap (i : Fin 3) : Tm Symbol 3 :=
  match i.val with
  | 0 => .var ⟨0, by decide⟩
  | _ => probe

def collisionFormula : QF Symbol 3 := .eq .zero (.succ .zero)

def normalize (r : Symbol) (F : QF Symbol 3) : QF Symbol 3 :=
  .imp (.or (F.subst (baseMap r)) collisionFormula) (F.subst bodyMap)

abbrev normalizedDenote (I : Interpretation Symbol D) (r : Symbol)
    (F : QF Symbol 3) (n a : D) : Prop :=
  (denote I F I.zero (I.fn r I.zero a) a ∨ I.zero = I.succ I.zero) →
    denote I F n a a

theorem eval_baseMap (I : Interpretation Symbol D) (r : Symbol)
    (F : QF Symbol 3) (n a : D) :
    (F.subst (baseMap r)).eval I (val n a a) =
    denote I F I.zero (I.fn r I.zero a) a := by
  rw [QF.eval_subst]
  apply QF.eval_congr
  intro i
  rcases i with ⟨i, hi⟩
  cases i with
  | zero => rfl
  | succ i => cases i <;> rfl

theorem eval_bodyMap (I : Interpretation Symbol D) (F : QF Symbol 3) (n a : D) :
    (F.subst bodyMap).eval I (val n a a) = denote I F n a a := by
  rw [QF.eval_subst]
  apply QF.eval_congr
  intro i
  rcases i with ⟨i, hi⟩
  cases i with
  | zero => rfl
  | succ i => cases i <;> rfl

theorem eval_normalize (I : Interpretation Symbol D) (r : Symbol)
    (F : QF Symbol 3) (n a : D) :
    denote I (normalize r F) n a a = normalizedDenote I r F n a := by
  change (((F.subst (baseMap r)).eval I (val n a a) ∨ I.zero = I.succ I.zero) →
    (F.subst bodyMap).eval I (val n a a)) = normalizedDenote I r F n a
  rw [eval_baseMap, eval_bodyMap]

/-- The occurrence-mask grammar is generated concretely by `normalize r F`.
The displayed object-language schema is just progress implies invariant
and successor computation. -/
def Compact (I : Interpretation Symbol D) (r : Symbol) (h : D → D → D) : Prop :=
  ∀ (F : QF Symbol 3) a,
    (∀ n, normalizedDenote I r F n a → normalizedDenote I r F (I.succ n) a) →
    ∀ n, normalizedDenote I r F n a ∧
      I.fn r (I.succ n) a = h n (I.fn r n a)

theorem compact_implies_joint {I : Interpretation Symbol D} {r : Symbol} {h : D → D → D}
    (compact : Compact I r h) : Joint I r h := by
  intro F a hypotheses n
  have progress : ∀ m, normalizedDenote I r F m a →
      normalizedDenote I r F (I.succ m) a := by
    intro m hm condition
    exact hypotheses.2 m (hm condition)
  have result := compact F a progress n
  exact ⟨result.1 hypotheses.1, result.2⟩

theorem separate_implies_compact {I : Interpretation Symbol D} {r : Symbol} {h : D → D → D}
    (basis : Separate I r h) : Compact I r h := by
  intro F a progress n
  have base : denote I (normalize r F) I.zero a a := by
    rw [eval_normalize]
    intro condition
    cases condition with
    | inl shifted =>
      rw [basis.1 a] at shifted
      exact shifted
    | inr collision => exact False.elim (basis.2.2.1 collision)
  have step : ∀ m, denote I (normalize r F) m a a →
      denote I (normalize r F) (I.succ m) a a := by
    intro m hm
    rw [eval_normalize] at hm
    rw [eval_normalize]
    exact progress m hm
  have result := basis.2.2.2 (normalize r F) a base step n
  rw [eval_normalize] at result
  exact ⟨result, basis.2.1 n a⟩

theorem compact_iff_joint (I : Interpretation Symbol D) (r : Symbol) (h : D → D → D) :
    Compact I r h ↔ Joint I r h :=
  ⟨compact_implies_joint, fun J => separate_implies_compact (joint_implies_separate J)⟩

theorem compact_iff_one_parameter_basis
    (I : Interpretation Symbol D) (r : Symbol) (h : D → D → D) :
    Compact I r h ↔
    (R0 I r ∧ RS I r h ∧ (I.zero ≠ I.succ I.zero) ∧ Induction2 I) := by
  constructor
  · intro C
    exact (joint_iff_one_parameter_basis I r h).1 (compact_implies_joint C)
  · intro b
    exact (compact_iff_joint I r h).2 ((joint_iff_one_parameter_basis I r h).2 b)

#print axioms Tm.eval_subst
#print axioms QF.eval_subst
#print axioms eval_normalize
#print axioms compact_implies_joint
#print axioms separate_implies_compact
#print axioms compact_iff_joint
#print axioms compact_iff_one_parameter_basis


/-! ## At most one marked seed occurrence

The smaller admission grammar permits at most one occurrence of source slot 1.
The initialization probe uses it exactly once. Separation and QFI extraction
need none. For QFI, the two-variable matrix is lifted into slots 0 and 2,
leaving slot 1 unused. This is a genuine restriction of the source matrices.
-/

def Tm.markedCount : Tm Symbol 3 → Nat
  | .var i => if i.val = 1 then 1 else 0
  | .zero => 0
  | .succ t => t.markedCount
  | .app _ s t => s.markedCount + t.markedCount

def QF.markedCount : QF Symbol 3 → Nat
  | .eq s t => s.markedCount + t.markedCount
  | .bot => 0
  | .and A B => A.markedCount + B.markedCount
  | .or A B => A.markedCount + B.markedCount
  | .imp A B => A.markedCount + B.markedCount

def OneMarked (F : QF Symbol 3) : Prop := F.markedCount ≤ 1

/-- Counter maps to slot 0; the only parameter maps to the unmarked slot 2. -/
def unmarkedLift (i : Fin 2) : Fin 3 :=
  if i.val = 0 then ⟨0, by decide⟩ else ⟨2, by decide⟩

theorem Tm.unmarked_lift_count (t : Tm Symbol 2) :
    (t.rename unmarkedLift).markedCount = 0 := by
  induction t with
  | var i =>
    rcases i with ⟨i, hi⟩
    cases i <;> rfl
  | zero => rfl
  | succ t ih => exact ih
  | app f s t ihs iht => exact congrTwo Nat.add ihs iht

theorem QF.unmarked_lift_count (A : QF Symbol 2) :
    (A.rename unmarkedLift).markedCount = 0 := by
  induction A with
  | eq s t => exact congrTwo Nat.add (Tm.unmarked_lift_count s) (Tm.unmarked_lift_count t)
  | bot => rfl
  | and A B ihA ihB => exact congrTwo Nat.add ihA ihB
  | or A B ihA ihB => exact congrTwo Nat.add ihA ihB
  | imp A B ihA ihB => exact congrTwo Nat.add ihA ihB

theorem eval_unmarked_lift (I : Interpretation Symbol D) (A : QF Symbol 2)
    (x z a : D) :
    (A.rename unmarkedLift).eval I (val x z a) = A.eval I (val2 x a) := by
  rw [QF.eval_rename]
  apply QF.eval_congr
  intro i
  rcases i with ⟨i, hi⟩
  cases i <;> rfl

def OneJoint (I : Interpretation Symbol D) (r : Symbol) (h : D → D → D) : Prop :=
  ∀ (F : QF Symbol 3), OneMarked F → ∀ a,
    ((denote I F I.zero (I.fn r I.zero a) a ∨ I.zero = I.succ I.zero) ∧
     (∀ n, denote I F n a a → denote I F (I.succ n) a a)) →
    ∀ n, denote I F n a a ∧ I.fn r (I.succ n) a = h n (I.fn r n a)

def OneCompact (I : Interpretation Symbol D) (r : Symbol) (h : D → D → D) : Prop :=
  ∀ (F : QF Symbol 3), OneMarked F → ∀ a,
    (∀ n, normalizedDenote I r F n a → normalizedDenote I r F (I.succ n) a) →
    ∀ n, normalizedDenote I r F n a ∧
      I.fn r (I.succ n) a = h n (I.fn r n a)

theorem one_initialization {I : Interpretation Symbol D} {r : Symbol} {h : D → D → D}
    (joint : OneJoint I r h) : R0 I r := by
  intro a
  have admitted : OneMarked (initializationProbe r) := by
    change 1 ≤ 1
    exact Nat.le_refl 1
  have hf := joint (initializationProbe r) admitted a
  change (((I.fn r I.zero a = I.fn r I.zero a ∨ I.zero = I.succ I.zero) ∧
    (∀ _ : D, a = I.fn r I.zero a → a = I.fn r I.zero a)) →
    ∀ n, (a = I.fn r I.zero a) ∧ I.fn r (I.succ n) a = h n (I.fn r n a)) at hf
  exact (hf ⟨Or.inl rfl, fun _ p => p⟩ I.zero).1.symm

theorem one_successorComputation {I : Interpretation Symbol D} {r : Symbol} {h : D → D → D}
    (joint : OneJoint I r h) : RS I r h := by
  intro n a
  exact (joint truth (by change 0 ≤ 1; exact Nat.zero_le 1) a ⟨Or.inl rfl, fun _ _ => rfl⟩ n).2

theorem one_separation {I : Interpretation Symbol D} {r : Symbol} {h : D → D → D}
    (joint : OneJoint I r h) : I.zero ≠ I.succ I.zero := by
  intro collision
  exact (joint .bot (by change 0 ≤ 1; exact Nat.zero_le 1) I.zero ⟨Or.inr collision, fun _ p => p⟩ I.zero).1

theorem one_induction {I : Interpretation Symbol D} {r : Symbol} {h : D → D → D}
    (joint : OneJoint I r h) : Induction2 I := by
  intro A a base step n
  have admitted : OneMarked (A.rename unmarkedLift) := by
    unfold OneMarked
    rw [QF.unmarked_lift_count]
    decide
  have shifted : denote I (A.rename unmarkedLift) I.zero (I.fn r I.zero a) a := by
    change (A.rename unmarkedLift).eval I (val I.zero (I.fn r I.zero a) a)
    rw [eval_unmarked_lift]
    exact base
  have progress : ∀ m, denote I (A.rename unmarkedLift) m a a →
      denote I (A.rename unmarkedLift) (I.succ m) a a := by
    intro m hm
    change (A.rename unmarkedLift).eval I (val m a a) at hm
    rw [eval_unmarked_lift] at hm
    change (A.rename unmarkedLift).eval I (val (I.succ m) a a)
    rw [eval_unmarked_lift]
    exact step m hm
  have result := (joint (A.rename unmarkedLift) admitted a
    ⟨Or.inl shifted, progress⟩ n).1
  change (A.rename unmarkedLift).eval I (val n a a) at result
  rw [eval_unmarked_lift] at result
  exact result

theorem one_joint_iff_one_parameter_basis
    (I : Interpretation Symbol D) (r : Symbol) (h : D → D → D) :
    OneJoint I r h ↔
    (R0 I r ∧ RS I r h ∧ (I.zero ≠ I.succ I.zero) ∧ Induction2 I) := by
  constructor
  · intro J
    exact ⟨one_initialization J, one_successorComputation J, one_separation J, one_induction J⟩
  · intro basis F admitted a hypotheses n
    exact (joint_iff_one_parameter_basis I r h).2 basis F a hypotheses n

theorem one_compact_implies_one_joint
    {I : Interpretation Symbol D} {r : Symbol} {h : D → D → D}
    (compact : OneCompact I r h) : OneJoint I r h := by
  intro F admitted a hypotheses n
  have progress : ∀ m, normalizedDenote I r F m a →
      normalizedDenote I r F (I.succ m) a := by
    intro m hm condition
    exact hypotheses.2 m (hm condition)
  have result := compact F admitted a progress n
  exact ⟨result.1 hypotheses.1, result.2⟩

theorem one_compact_iff_one_parameter_basis
    (I : Interpretation Symbol D) (r : Symbol) (h : D → D → D) :
    OneCompact I r h ↔
    (R0 I r ∧ RS I r h ∧ (I.zero ≠ I.succ I.zero) ∧ Induction2 I) := by
  constructor
  · intro C
    exact (one_joint_iff_one_parameter_basis I r h).1 (one_compact_implies_one_joint C)
  · intro basis F admitted a progress n
    exact (compact_iff_one_parameter_basis I r h).2 basis F a progress n

theorem one_joint_iff_joint (I : Interpretation Symbol D) (r : Symbol) (h : D → D → D) :
    OneJoint I r h ↔ Joint I r h := by
  constructor
  · intro O
    exact (joint_iff_one_parameter_basis I r h).2
      ((one_joint_iff_one_parameter_basis I r h).1 O)
  · intro J F admitted
    exact J F

theorem one_compact_iff_compact (I : Interpretation Symbol D) (r : Symbol) (h : D → D → D) :
    OneCompact I r h ↔ Compact I r h := by
  constructor
  · intro O
    exact (compact_iff_one_parameter_basis I r h).2
      ((one_compact_iff_one_parameter_basis I r h).1 O)
  · intro C F admitted
    exact C F

#print axioms Tm.unmarked_lift_count
#print axioms QF.unmarked_lift_count
#print axioms eval_unmarked_lift
#print axioms one_initialization
#print axioms one_successorComputation
#print axioms one_separation
#print axioms one_induction
#print axioms one_joint_iff_one_parameter_basis
#print axioms one_compact_implies_one_joint
#print axioms one_compact_iff_one_parameter_basis
#print axioms one_joint_iff_joint
#print axioms one_compact_iff_compact

end DiagonalJoint
