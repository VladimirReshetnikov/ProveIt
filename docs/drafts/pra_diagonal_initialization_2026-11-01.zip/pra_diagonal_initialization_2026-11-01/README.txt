ONE MARK SUFFICES: DIAGONAL INITIALIZATION FOR PRA
Research report prepared for Vladimir Reshetnikov, 1 November 2026.

Read report.pdf. Complete LaTeX source is report.tex, arithmetic.tex,
and comparison.tex. All three source files are required to rebuild.

RESULT
The implicit-initialization schema can be restricted to one actual seed
parameter and at most one initialized occurrence in its formula template.
Every axiom has at most two individual variables. The resulting single
axiom family is constructively equivalent to binary initialized recursion,
separation, and one-parameter quantifier-free induction. The paper proves
whole-carrier identity bi-interpretations with matching-logic first-order
PRA, separately for classical and intuitionistic logic.

The 41-node direct display is not an absolute shortestness result: an
explicit fusion obtainable from the supplied drafts also has 41 nodes.
The one-occurrence restriction gives a uniform saving of four or six
nodes for matching expanded matrices. The optional 26-node outer display
has an explicit admission grammar and longer expanded instances.

FILES
  report.pdf / report.tex     Main paper and entry-point source
  arithmetic.tex             Arithmetic, pairing, compiler, round trips
  comparison.tex             Comparison, verification, further questions
  formal/DiagonalJoint.lean   Concrete-syntax constructive Lean kernel
  formal/lean-check.log       Exact successful proof-check output
  formal/SCOPE.txt            Formalization boundary
  checks/syntax_checks.py     Independent syntax and size diagnostics
  checks/syntax_results.json  Recorded diagnostic results
  audit/source_manifest.json  Pinned five-archive GitHub provenance
  audit/                     Build and mathematical review records
  build.py                   Reproducible build/check entry point

BUILD
  python3 build.py

Requires pdflatex and the packages listed at the top of report.tex.
Python checks need only the standard library:
  python3 checks/syntax_checks.py

Optional combined rebuild and verification:
  python3 build.py --checks --lean /absolute/path/to/lean

The formal source was checked with Lean 4.19.0 and imports Init only.
All 32 printed theorem endpoints report no global axiom dependencies.
This checks the logical and syntactic reduction. The entire first-order
proof calculus, description grammar, arithmetic bootstrap, and full
bi-interpretations are not claimed to be mechanized.

INPUT SNAPSHOT
  Repository: https://github.com/VladimirReshetnikov/ProveIt
  Commit: 0bf6525f9b09421e5ffacdd5fba7648d28b7fcff
  Directory: docs/drafts
  Five archives inspected; all Git blob identifiers verified.
  Exact archive and LaTeX-member hashes are in audit/source_manifest.json.

No changes were made to the source repository.
