#!/usr/bin/env python3
"""Build the paper and optionally rerun the supplied independent checks."""
from __future__ import annotations
import argparse
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checks", action="store_true", help="run the syntax diagnostics")
    parser.add_argument("--lean", metavar="EXECUTABLE", help="check the Lean source with this executable")
    args = parser.parse_args()
    (ROOT / "audit").mkdir(exist_ok=True)
    if args.checks:
        subprocess.run([sys.executable, str(ROOT / "checks" / "syntax_checks.py")],
                       cwd=ROOT, check=True)
    if args.lean:
        checked = subprocess.run([args.lean, "formal/DiagonalJoint.lean"], cwd=ROOT,
                                 text=True, capture_output=True)
        (ROOT / "formal" / "lean-check.log").write_text(
            checked.stdout + checked.stderr, encoding="utf-8")
        if checked.returncode:
            raise SystemExit(checked.returncode)
    if shutil.which("pdflatex") is None:
        raise SystemExit("pdflatex is required (TeX Live with the packages named in report.tex).")
    outputs = []
    for _ in range(3):
        result = subprocess.run(
            ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
            cwd=ROOT, text=True, capture_output=True)
        outputs.append(result.stdout + result.stderr)
        if result.returncode:
            (ROOT / "audit" / "build-output.txt").write_text(
                "\n".join(outputs), encoding="utf-8")
            raise SystemExit(result.returncode)
    log = (ROOT / "report.log").read_text(encoding="utf-8", errors="replace")
    problems = [line for line in log.splitlines()
                if any(fragment in line for fragment in (
                    "Overfull", "Missing character", "undefined", "Rerun to get"))]
    pdf = ROOT / "report.pdf"
    result = {
        "pdf": pdf.name,
        "pdf_bytes": pdf.stat().st_size,
        "pdf_sha256": hashlib.sha256(pdf.read_bytes()).hexdigest(),
        "compiler_runs": len(outputs),
        "log_findings": problems,
    }
    (ROOT / "audit" / "build.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8")
    (ROOT / "audit" / "build-output.txt").write_text(
        "\n".join(outputs), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
