"""Recount complete Python checkers. This program is not trusted by checker.py."""
import ast
import copy
import hashlib
import io
import json
from pathlib import Path
import sys
import tokenize

ROOT = Path(__file__).resolve().parent
SKIP = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
        tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
OWNERS = (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)


def docstring(node):
    return (isinstance(node, OWNERS) and node.body
            and isinstance(node.body[0], ast.Expr)
            and isinstance(node.body[0].value, ast.Constant)
            and isinstance(node.body[0].value.value, str))


def measure(path):
    raw = path.read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    spans = [((node.body[0].lineno, node.body[0].col_offset),
              (node.body[0].end_lineno, node.body[0].end_col_offset))
             for node in ast.walk(tree) if docstring(node)]
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(source).readline)
              if t.type not in SKIP
              and not any(lo <= t.start and t.end <= hi for lo, hi in spans)]
    executable = copy.deepcopy(tree)
    for node in ast.walk(executable):
        if docstring(node):
            del node.body[0]
    normalized = ast.unparse(executable) + '\n'
    return {'raw_bytes': len(raw), 'tokens': len(tokens),
            'token_characters': sum(len(t.string) for t in tokens),
            'ast_nodes': sum(1 for _ in ast.walk(executable)),
            'normalized_bytes': len(normalized.encode('utf-8')),
            'sha256': hashlib.sha256(raw).hexdigest()}


def run():
    rows = json.loads((ROOT / 'comparisons/source_inventory.json').read_text())
    for row in rows:
        row['metrics'] = measure(ROOT / row['path'])
        if row['metrics']['sha256'] != row['sha256']:
            raise ValueError('comparison source changed: ' + row['path'])
    candidate = measure(ROOT / 'checker.py')
    keys = ('tokens', 'ast_nodes', 'raw_bytes', 'normalized_bytes', 'token_characters')
    minima = {k: min(r['metrics'][k] for r in rows) for k in keys}
    result = {'python': sys.version, 'candidate': candidate, 'minima': minima,
              'strictly_below_all_minima': all(candidate[k] < minima[k] for k in keys),
              'convention': 'Complete source, including syntax, arithmetic data, JSON CLI, imports. '
              'Tokens exclude comments, layout and docstrings. AST includes all executable nodes '
              'after docstring removal. Normalized bytes use ast.unparse. No local imports.',
              'scope': 'Six current primary checkers and eleven explicitly supplied alternatives. '
              'Historical copied predecessors are not recounted. This is an observed comparison, '
              'not a theorem about all languages or possible programs.', 'baselines': rows}
    (ROOT / 'validation').mkdir(exist_ok=True)
    (ROOT / 'validation/metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    macros = {'CandidateTokens': candidate['tokens'], 'CandidateAST': candidate['ast_nodes'],
              'CandidateBytes': candidate['raw_bytes'], 'MinimumTokens': minima['tokens'],
              'MinimumAST': minima['ast_nodes'], 'MinimumBytes': minima['raw_bytes']}
    (ROOT / 'measurements.tex').write_text(''.join(
        '\\newcommand{\\' + k + '}{' + str(v) + '}\n' for k, v in macros.items()))
    lines = ['\\begin{tabular}{@{}lrrrr@{}}', '\\toprule',
             'Complete checker & Tokens & AST nodes & Raw bytes & Norm. bytes\\\\', '\\midrule']
    for row in rows:
        if row['role'] == 'primary':
            name = row['archive'].replace('ipra_', '').replace('_2026-11-06.zip', '').replace('_', ' ')
            m = row['metrics']
            lines.append(name.capitalize() + ' & ' + ' & '.join(str(m[k]) for k in keys[:4]) + '\\\\')
    lines += ['\\midrule', 'All 17: coordinate minima & ' + ' & '.join(str(minima[k]) for k in keys[:4]) + '\\\\',
              '\\textbf{This checker} & ' + ' & '.join('\\textbf{' + str(candidate[k]) + '}' for k in keys[:4]) + '\\\\',
              '\\bottomrule', '\\end{tabular}']
    (ROOT / 'comparison_table.tex').write_text('\n'.join(lines) + '\n')
    print(json.dumps({k: result[k] for k in ('candidate', 'minima', 'strictly_below_all_minima')}, indent=2))
    return result


if __name__ == '__main__':
    run()
