"""Untrusted compiler from the pinned ordinary-iPRA baseline to this checker.

Every source document is checked before translation and every result is
independently checked afterward. Neither trusted checker imports this file.
The construction applies to arbitrary finite valid baseline derivations,
including open number parameters, nested proof binders, and retained
assumptions. It changes only the representation of the stated sequent.

Attribution: the witness-equation construction and protected-slot lifting
follow ipra_witness_kernel_2026-11-06/code/translate_baseline.py. The numerical
axiom expansion follows ipra_universal_kernel_2026-11-06/code/translate.py.
Both drafts were read at ProveIt commit 3e7b2d6ae159163a2ac9b5000318cd5e822c6e30.
This compiler adapts those constructions to formula-valued hypotheses,
shared elimination, genuine falsity, and the integer zero token.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path

import checker as new


ROOT = Path(__file__).resolve().parent
_spec = importlib.util.spec_from_file_location(
    "ipra_original_checker", ROOT / "comparisons" / "baseline_checker.py")
if _spec is None or _spec.loader is None:
    raise ImportError("the pinned baseline checker is missing")
old = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(old)


def syntax(expression):
    """Translate a well-formed old term/formula; only zero changes."""
    if type(expression) is int:
        return expression
    if tuple(expression) == old.ZERO:
        return new.ZERO
    return [expression[0], *(syntax(child) for child in expression[1:])]


def old_syntax(expression):
    """Inverse syntax map, useful for checking the exact stated sequent."""
    if type(expression) is int:
        return old.ZERO if expression == new.ZERO else expression
    return (expression[0], *(old_syntax(child) for child in expression[1:]))


def insert_number(expression, protected=0):
    """Insert a fresh ambient number below `protected` local number slots."""
    return new.walk(expression, lambda i, depth: i + depth + 1, protected)


def lift(proof, context, protected=0):
    """Weaken a target proof by one fresh ambient numerical variable.

    Local proof binders are protected; the syntax walker independently
    protects binders internal to terms and formulas. Formula-valued
    hypotheses need numerical renaming but no positional reindexing when
    an extra assumption is added. `context` is the original, unrenamed
    context at the current node, and is used only to determine the type
    of a shared elimination's already checked principal premise.
    """
    def rename(expression, extra=0):
        return insert_number(expression, protected + extra)

    def child(subproof):
        return lift(subproof, context, protected)

    match proof:
        case ["hyp", formula]:
            return ["hyp", rename(formula)]
        case ["pi", guard, body]:
            local = [*map(new.shift, context), guard]
            return ["pi", rename(guard, 1), lift(body, local, protected + 1)]
        case ["pair", witness, left, right]:
            local = [*map(new.shift, context), ["=", 0, new.shift(witness)]]
            return ["pair", rename(witness),
                    lift(left, local, protected + 1),
                    lift(right, local, protected + 1)]
        case ["use", principal, annotation, minor]:
            formula = new.infer(principal, context)
            tag = formula[0]
            if tag == "sig":
                local = [*map(new.shift, context), *formula[1:]]
                return ["use", child(principal), rename(annotation),
                        lift(minor, local, protected + 1)]
            if tag not in ("=", "pi"):
                raise ValueError("invalid principal in untrusted proof lifting")
            return ["use", child(principal),
                    rename(annotation, 1 if tag == "=" else 0), child(minor)]
        case ["bridge", premise]:
            return ["bridge", child(premise)]
        case ["rec", recursor]:
            return ["rec", rename(recursor)]
        case ["nat", template]:
            return ["nat", rename(template, 1)]
        case _:
            raise ValueError("unknown target proof constructor in untrusted lifting")


def reflexivity(term):
    """Derive t=t using R0 and equality replacement, without Sigma."""
    computation = ["rec", ["r", new.ZERO, term, new.ZERO]]
    return ["use", computation, ["=", 0, new.shift(term)], computation]


def symmetry(equality, left):
    return ["use", equality, ["=", 0, new.shift(left)], reflexivity(left)]


def sigma_intro(principal, witness, left, right, context):
    """Compile ordinary Sigma introduction into the witness-equation rule."""
    equation = ["=", 0, new.shift(witness)]
    backwards = symmetry(["hyp", equation], 0)

    def branch(matrix, premise):
        # The replacement placeholder remains slot 0; insert the fresh
        # witness variable below it, shifting all old parameters.
        template = insert_number(matrix, 1)
        return ["use", backwards, template, lift(premise, context)]

    return ["pair", witness,
            branch(principal[1], left), branch(principal[2], right)]


def translate(proof, context):
    """Translate a valid frozen source proof under its source context.

    A target context may contain additional assumptions. Since target
    hypotheses are selected by their formulas, weakening introduces no
    positional changes, including below subsequent Pi/Sigma binders.
    """
    def child(subproof):
        return translate(subproof, context)

    match proof:
        case ("hyp", index):
            return ["hyp", syntax(context[index])]
        case ("pi", guard, body):
            local = (*map(old.shift, context), guard)
            return ["pi", syntax(guard), translate(body, local)]
        case ("app", principal, witness, minor):
            return ["use", child(principal), syntax(witness), child(minor)]
        case ("pair", principal, witness, left, right):
            return sigma_intro(syntax(principal), syntax(witness),
                               child(left), child(right), list(map(syntax, context)))
        case ("let", principal, conclusion, body):
            formula = old.infer(principal, context)
            local = (*map(old.shift, context), *formula[1:])
            return ["use", child(principal), syntax(conclusion), translate(body, local)]
        case ("eq", equality, template, minor):
            return ["use", child(equality), syntax(template), child(minor)]
        case ("bridge", premise):
            return ["bridge", child(premise)]
        case ("rec", recursor):
            return ["rec", syntax(recursor)]
        case ("nat", template, target, base, step):
            formula = syntax(template)
            atomic = template[0] == "="
            guard = formula if atomic else new.shift(new.inst(formula, new.ZERO))
            hypotheses = (template,) if atomic else ()
            local = (*map(old.shift, context), *hypotheses)
            successor = ["pi", guard, translate(step, local)]
            with_base = ["use", ["nat", formula], syntax(target), child(base)]
            return ["use", with_base, new.ZERO, successor]
        case _:
            raise ValueError("unknown source proof constructor")


def certificate(document):
    """Check the source, compile it, and independently check the result."""
    old.check(document)
    context = tuple(map(old.freeze, document["assumptions"]))
    result = {
        "assumptions": [syntax(formula) for formula in context],
        "goal": syntax(old.freeze(document["goal"])),
        "proof": translate(old.freeze(document["proof"]), context),
    }
    new.check(result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", nargs="?", type=Path)
    args = parser.parse_args()
    result = certificate(json.loads(args.input.read_text(encoding="utf-8")))
    encoded = json.dumps(result, separators=(",", ":")) + "\n"
    if args.output is None:
        print(encoded, end="")
    else:
        args.output.write_text(encoded, encoding="utf-8")


if __name__ == "__main__":
    main()
