"""Replay all 53 original certificates through both independent checkers.

The additional tests put every old proof under one and two fresh witness
binders, and exercise dependent witnesses, recursion bodies, local Pi/Sigma
assumptions, and the added non-equational numerical guard. They test the
untrusted compiler's binder handling; they are not a formal soundness proof.

The wrapping strategy and first six stress constructors are adapted from
ipra_witness_kernel_2026-11-06/code/test_translation.py, pinned in the same
repository snapshot identified in translator.py. Two extra constructors
specifically test the numerical-axiom/shared-elimination combination.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import translator as tr


ROOT = Path(__file__).resolve().parent
old = tr.old
Z = old.ZERO
BASELINE_SHA256 = "4228564e6bbebbab98246f7879f01cedf80c566edbf814b14afb0cba6d2af0d2"


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def encoded(document):
    return (json.dumps(document, separators=(",", ":")) + "\n").encode("utf-8")


def eq(left, right):
    return ("=", left, right)


def reflexivity(term):
    computation = ("rec", ("r", Z, term, Z))
    return ("eq", computation, eq(0, old.shift(term)), computation)


def document(goal, proof, assumptions=()):
    result = {"assumptions": list(assumptions), "goal": goal, "proof": proof}
    old.check(result)
    return result


def wrap(source, witness):
    """Place an arbitrary valid old proof inside an ordinary Sigma pair."""
    goal = old.freeze(source["goal"])
    principal = ("sig", old.shift(goal), eq(0, 0))
    return document(principal,
                    ("pair", principal, witness, old.freeze(source["proof"]),
                     reflexivity(witness)),
                    [old.freeze(formula) for formula in source["assumptions"]])


def stress_cases():
    # Dependence on two parameters and two nested recursion binders.
    witness = ("r", ("s", 0), 1, ("r", 1, 0, ("s", 0)))
    recursive = ("r", 0, 1, ("s", 0))
    principal = ("sig", eq(0, old.shift(witness)), eq(recursive, recursive))
    yield "dependent_recursion_witness", document(
        principal, ("pair", principal, witness, reflexivity(witness),
                    reflexivity(old.inst(recursive, witness))))

    # A local Pi assumption must remain the selected hypothesis after lift.
    witness = ("s", 4)
    matrix = ("pi", eq(0, 1), eq(0, 1))
    principal = ("sig", matrix, eq(0, 0))
    context = [eq(2, Z)]
    left = ("pi", eq(0, old.shift(witness)), ("hyp", 1))
    yield "dependent_pi_and_local_assumption", document(
        principal, ("pair", principal, witness, left, reflexivity(witness)), context)

    # Compile an inner dependent pair, then lift its complete new proof.
    witness = ("s", 0)
    matrix = ("sig", eq(0, 1), eq(1, 1))
    principal = ("sig", matrix, eq(0, 0))
    inner = old.inst(matrix, witness)
    left = ("pair", inner, witness, reflexivity(witness), reflexivity(witness))
    yield "dependent_nested_sigma", document(
        principal, ("pair", principal, witness, left, reflexivity(witness)))

    # Both locally introduced Sigma assumptions are used by a transport.
    witness = ("s", 0)
    existence = ("sig", eq(0, old.shift(witness)), eq(0, 0))
    conclusion = eq(witness, witness)
    branch = ("eq", ("hyp", 1), eq(0, 0), ("hyp", 2))
    eliminated = ("let", ("hyp", 0), conclusion, branch)
    principal = ("sig", eq(0, 0), eq(0, 0))
    yield "sigma_elimination_local_assumptions", document(
        principal, ("pair", principal, witness, eliminated, reflexivity(witness)),
        [existence])

    # The equation induction hypothesis is genuinely used in the step.
    witness = ("r", ("s", 3), 0, ("s", 0))
    invariant = eq(0, 0)
    step = ("eq", ("hyp", 0), eq(("s", 0), ("s", 1)),
            reflexivity(("s", 0)))
    induction = ("nat", invariant, witness, reflexivity(Z), step)
    principal = ("sig", invariant, invariant)
    yield "equation_induction_hypothesis_lifting", document(
        principal, ("pair", principal, witness, induction, reflexivity(witness)))

    # Falsity remains genuine; the axiom introduces a base guard while an
    # inner Pi introduces a different local assumption.
    truth = eq(Z, Z)
    assumption = ("pi", truth, old.FALSE)
    base = ("app", ("hyp", 0), Z, reflexivity(Z))
    identity = ("app", ("pi", truth, ("hyp", 1)), Z, reflexivity(Z))
    step = ("app", ("hyp", 0), Z, identity)
    yield "falsity_case_local_hypothesis", document(
        old.FALSE, ("nat", old.FALSE, 7, base, step), [assumption])

    # A non-equation case template depends on the number being analyzed.
    # The source step has no extra assumption; the target Pi step does.
    invariant = ("pi", eq(0, 1), eq(0, 1))
    target = ("s", 5)
    existence = ("sig", eq(0, 0), eq(0, 0))
    base_formula = old.inst(invariant, Z)
    successor = old.subst(invariant, lambda i: ("s", 0) if i == 0 else i)
    base = ("pi", base_formula[1], ("hyp", 1))
    direct_step = ("pi", successor[1], ("hyp", 1))
    yield "case_guard_under_local_pi", document(
        old.inst(invariant, target),
        ("nat", invariant, target, base, direct_step), [existence])

    # Put the same step below Sigma elimination and another Pi binder.
    local_goal = old.shift(successor)
    step_body = ("pi", local_goal[1], ("hyp", 3))
    nested_step = ("let", ("hyp", 0), successor, step_body)
    yield "case_guard_under_sigma_and_pi", document(
        old.inst(invariant, target),
        ("nat", invariant, target, base, nested_step), [existence])


def check_same_sequent(source, target):
    require(tr.old_syntax(target["goal"]) == old.freeze(source["goal"]),
            "translation changed the stated goal")
    require(tuple(map(tr.old_syntax, target["assumptions"])) ==
            tuple(map(old.freeze, source["assumptions"])),
            "translation changed the retained context")


def rejected(function, value):
    try:
        function(value)
    except (ValueError, TypeError, IndexError, KeyError, RecursionError):
        return True
    return False


def main():
    require(digest(ROOT / "comparisons" / "baseline_checker.py") == BASELINE_SHA256,
            "pinned baseline checker bytes changed")
    originals = ROOT / "comparisons" / "original_certificates"
    translated = ROOT / "certificates" / "translated"
    stress_dir = ROOT / "certificates" / "stress"
    validation = ROOT / "validation"
    for directory in (translated, stress_dir, validation):
        directory.mkdir(parents=True, exist_ok=True)
    paths = sorted(originals.glob("*.json"))
    require(len(paths) == 53, "expected exactly 53 original certificates")

    results = []
    wrapping = []
    source_bytes = target_bytes = 0
    for path in paths:
        source = json.loads(path.read_text(encoding="utf-8"))
        target = tr.certificate(source)
        check_same_sequent(source, target)
        output = translated / path.name
        output.write_bytes(encoded(target))
        source_bytes += len(encoded(source))
        target_bytes += len(encoded(target))
        results.append({
            "name": path.name,
            "source_sha256": digest(path),
            "target_sha256": digest(output),
            "source_accepted": True,
            "target_accepted": True,
            "same_sequent": True,
        })
        # Wrappers are regenerated, not duplicated as large archive files.
        witnesses = (13, ("r", ("s", 2), 5, ("r", 1, 0, ("s", 0))))
        for depth, witness in enumerate(witnesses, 1):
            source = wrap(source, witness)
            target = tr.certificate(source)
            check_same_sequent(source, target)
            wrapping.append({"name": path.name, "depth": depth, "accepted": True})

    stress = []
    for name, source in stress_cases():
        target = tr.certificate(source)
        check_same_sequent(source, target)
        path = stress_dir / (name + ".json")
        path.write_bytes(encoded(target))
        stress.append({"name": name, "source_accepted": True,
                       "target_accepted": True, "same_sequent": True,
                       "target_sha256": digest(path)})

    # The compiler must reject malformed source proofs, even when an
    # erroneous simplification could have erased their bad subderivation.
    invalid_sources = {
        "invalid_bridge": {
            "assumptions": [eq(Z, Z)], "goal": old.FALSE,
            "proof": ("bridge", ("hyp", 0))},
        "invalid_numerical_step": {
            "assumptions": [old.FALSE], "goal": old.FALSE,
            "proof": ("nat", old.FALSE, Z, ("hyp", 0), ("hyp", 99))},
        "wrong_sigma_instance": {
            "assumptions": [], "goal": ("sig", eq(0, Z), eq(0, Z)),
            "proof": ("pair", ("sig", eq(0, Z), eq(0, Z)), ("s", Z),
                      reflexivity(("s", Z)), reflexivity(("s", Z)))},
    }
    negative = []
    for name, source in invalid_sources.items():
        require(rejected(tr.certificate, source), "invalid source survived: " + name)
        negative.append(name)

    report = {
        "status": "PASS",
        "original_certificates": len(results),
        "wrapped_certificates": len(wrapping),
        "stress_certificates": len(stress),
        "positive_translations": len(results) + len(wrapping) + len(stress),
        "compiler_rejection_checks": len(negative),
        "source_compact_json_bytes": source_bytes,
        "target_compact_json_bytes": target_bytes,
        "checker_sha256": digest(ROOT / "checker.py"),
        "baseline_checker_sha256": digest(ROOT / "comparisons" / "baseline_checker.py"),
        "translator_sha256": digest(ROOT / "translator.py"),
        "regression_sha256": digest(Path(__file__)),
        "claim": "Both standalone checkers accepted every positive source/target pair; the syntax inverse recovers exactly the original goal and retained assumptions.",
        "scope": "Finite implementation tests; neither this compiler nor its tests belong to the trusted checker. They do not replace the mathematical translation proofs.",
        "originals": results,
        "wrapping": wrapping,
        "stress": stress,
        "rejected_sources": negative,
    }
    (validation / "regression_results.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8")
    summary = {key: report[key] for key in (
        "status", "original_certificates", "wrapped_certificates",
        "stress_certificates", "positive_translations", "compiler_rejection_checks")}
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
