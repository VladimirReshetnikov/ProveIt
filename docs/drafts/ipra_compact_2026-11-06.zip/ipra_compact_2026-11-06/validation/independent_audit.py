"""Targeted independent audit of the combined kernel, using finite JSON inputs.

This is an untrusted regression suite, not part of the proof checker. Expected
formulas are written explicitly; they are not obtained from the kernel's
substitution functions. Run from any directory with Python 3.10 or later.
"""

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("audited_kernel", ROOT / "checker.py")
KERNEL = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(KERNEL)

Z = -1
F = ["false"]


def eq(a, b):
    return ["=", a, b]


def suc(a):
    return ["s", a]


def pi(a, b):
    return ["pi", a, b]


def sig(a, b):
    return ["sig", a, b]


def rec(n, a, h):
    return ["r", n, a, h]


def hyp(a):
    return ["hyp", a]


def use(p, a, q):
    return ["use", p, a, q]


def claim(assumptions, goal, proof):
    return {"assumptions": assumptions, "goal": goal, "proof": proof}


T = eq(Z, Z)
C = eq(Z, suc(Z))
CASES = []


def add(name, accepted, data, risk):
    # Reparse actual JSON so fixtures cannot accidentally depend on Python
    # tuples, subclass behavior, object aliasing, or concurrent mutation.
    data = json.loads(json.dumps(data, allow_nan=False))
    CASES.append((name, accepted, data, risk))


add("bridge_false_to_clash", True, claim([F], C, ["bridge", hyp(F)]),
    "Genuine falsity remains available in the public and native language.")
add("bridge_clash_to_false", True, claim([C], F, ["bridge", hyp(C)]),
    "Arithmetic contradiction is converted to genuine falsity.")
add("bridge_does_not_accept_other_equations", False,
    claim([T], F, ["bridge", hyp(T)]), "The bridge is restricted to two formulas.")
add("bridge_does_not_accept_reverse_clash_directly", False,
    claim([eq(suc(Z), Z)], F, ["bridge", hyp(eq(suc(Z), Z))]),
    "A symmetric contradiction needs a separately checked symmetry proof.")
add("false_is_not_an_axiom", False, claim([], F, ["bridge", hyp(C)]),
    "The bridge requires an actual premise.")
add("false_cannot_be_a_use_principal", False,
    claim([F, T], T, use(hyp(F), T, hyp(T))),
    "The shared eliminator does not silently accept a fourth principal type.")

add("pi_identity", True, claim([], pi(eq(0, Z), eq(0, Z)),
    ["pi", eq(0, Z), hyp(eq(0, Z))]), "The guard may use its newly bound number.")
add("pi_shifts_old_context", True,
    claim([eq(0, Z)], pi(T, eq(1, Z)), ["pi", T, hyp(eq(1, Z))]),
    "An ambient parameter is shifted past the newly introduced number.")
add("pi_cannot_reuse_unshifted_context", False,
    claim([eq(0, Z)], pi(T, eq(0, Z)), ["pi", T, hyp(eq(0, Z))]),
    "Old assumptions cannot become facts about the fresh number.")
principal = pi(eq(0, 1), eq(1, 0))
add("pi_use_preserves_parameter", True,
    claim([principal, eq(0, 0)], eq(0, 0), use(hyp(principal), 0, hyp(eq(0, 0)))),
    "Instantiation distinguishes the bound variable from the outer parameter.")
add("pi_use_rejects_formula_witness", False,
    claim([pi(T, T), T], T, use(hyp(pi(T, T)), F, hyp(T))),
    "A logical formula cannot occupy a numerical witness position.")

witness_equation = eq(0, 1)
add("pair_infers_parameterized_conclusion", True,
    claim([], sig(witness_equation, witness_equation),
          ["pair", 0, hyp(witness_equation), hyp(witness_equation)]),
    "The new witness equation is discharged; the witness term is shifted.")
add("pair_does_not_capture_witness_term", False,
    claim([], sig(eq(0, 0), eq(0, 0)), ["pair", 0, hyp(eq(0, 0)), hyp(eq(0, 0))]),
    "The fresh witness is not definitionally the old parameter.")
add("pair_rejects_formula_witness", False,
    claim([], sig(T, T), ["pair", F, hyp(T), hyp(T)]),
    "Witness introduction validates its term before extending the context.")
rw = rec(Z, Z, 2)
rw_lifted = rec(Z, Z, 3)
rw_eq = eq(0, rw_lifted)
add("pair_shifts_parameter_below_recursion", True,
    claim([], sig(rw_eq, rw_eq), ["pair", rw, hyp(rw_eq), hyp(rw_eq)]),
    "Recursion body slots 0 and 1 stay bound while its external slot moves.")
bad_rw_eq = eq(0, rw)
add("pair_rejects_parameter_capture_below_recursion", False,
    claim([], sig(bad_rw_eq, bad_rw_eq), ["pair", rw, hyp(bad_rw_eq), hyp(bad_rw_eq)]),
    "A parameter beneath a recursor cannot become the fresh existential witness.")

sg = sig(T, T)
add("sigma_use_with_closed_result", True,
    claim([sg], T, use(hyp(sg), T, hyp(T))), "Both existential assumptions are usable.")
sg = sig(eq(0, 0), T)
add("sigma_witness_cannot_escape", False,
    claim([sg], eq(0, 0), use(hyp(sg), eq(0, 0), hyp(eq(0, 0)))),
    "The conclusion must refer to the outer context, not the fresh witness.")
rc = eq(rec(Z, Z, 2), Z)
rc_lifted = eq(rec(Z, Z, 3), Z)
sg = sig(rc, T)
add("sigma_witness_cannot_escape_below_recursion", False,
    claim([sg], rc, use(hyp(sg), rc, hyp(rc))),
    "Freshness is also enforced inside the body of a recursion term.")
sg = sig(T, rc_lifted)
add("sigma_valid_result_below_recursion", True,
    claim([sg], rc, use(hyp(sg), rc, hyp(rc_lifted))),
    "A legitimately shifted external conclusion can contain recursion.")
sg = sig(T, T)
add("sigma_old_context_remains_shifted", False,
    claim([eq(0, Z), sg], eq(0, Z), use(hyp(sg), eq(0, Z), hyp(eq(0, Z)))),
    "Sigma elimination cannot consult an unshifted ambient assumption.")
add("sigma_valid_shifted_old_context", True,
    claim([eq(0, Z), sg], eq(0, Z), use(hyp(sg), eq(0, Z), hyp(eq(1, Z)))),
    "A shifted old assumption gives the legitimate outer conclusion.")

e = eq(0, Z)
template = pi(T, eq(1, 1))
left = pi(T, eq(1, 1))
right = pi(T, T)
add("equality_transport_below_pi", True,
    claim([e, left], right, use(hyp(e), template, hyp(left))),
    "The distinguished equality slot is outside the inner Pi binder.")
add("equality_transport_rejects_captured_result", False,
    claim([e, left], pi(T, eq(0, 0)), use(hyp(e), template, hyp(left))),
    "Transport does not substitute for an inner bound number.")
template = eq(rec(Z, Z, 2), Z)
add("equality_transport_below_recursion", True,
    claim([e, template], eq(rec(Z, Z, Z), Z), use(hyp(e), template, hyp(template))),
    "Only the free template slot beneath two recursion binders is replaced.")
add("equality_use_rejects_term_template", False,
    claim([e, T], T, use(hyp(e), 0, hyp(T))),
    "Equality replacement requires a formula template.")
add("equality_use_rejects_malformed_template", False,
    claim([e, T], T, use(hyp(e), eq(-2, Z), hyp(T))),
    "Substitution cannot repair a malformed negative variable.")

r = rec(Z, 0, suc(1))
add("recursion_base_with_parameter", True, claim([], eq(r, 0), ["rec", r]),
    "The sentinel zero selects the base equation without shifting parameters.")
h = rec(1, 0, suc(4))
r = rec(suc(0), 1, h)
rhs = rec(0, rec(0, 1, h), suc(2))
add("recursion_step_simultaneous_and_nested", True,
    claim([], eq(r, rhs), ["rec", r]),
    "Simultaneous state/counter substitution respects nested recursion binders.")
r = rec(0, Z, Z)
add("recursion_has_no_implicit_variable_evaluation", False,
    claim([], eq(r, Z), ["rec", r]), "The counter must literally be zero or a successor.")
r = rec(-1.0, Z, Z)
add("recursion_rejects_float_alias_of_zero", False,
    claim([], T, ["rec", r]), "Type validation precedes the n == ZERO comparison.")
r = rec(Z, Z, F)
add("recursion_rejects_formula_body", False,
    claim([], T, ["rec", r]), "A recursion update must be a number term.")

matrix = eq(0, Z)
step = pi(matrix, eq(suc(0), Z))
schema = pi(T, pi(step, eq(1, Z)))
add("equation_induction_schema", True, claim([], schema, ["nat", matrix]),
    "The equation matrix receives its induction hypothesis.")
matrix = eq(0, 1)
schema = pi(eq(Z, 1), pi(pi(eq(0, 3), eq(suc(0), 3)), eq(1, 2)))
add("induction_schema_parameter_depths", True, claim([], schema, ["nat", matrix]),
    "The curried schema puts the target and parameters in different slots.")
matrix = pi(T, eq(1, Z))
base = pi(T, T)
successor = pi(T, eq(suc(1), Z))
schema = pi(base, pi(pi(base, successor), pi(T, eq(2, Z))))
add("quantified_matrix_gets_fixed_base_guard", True,
    claim([], schema, ["nat", matrix]),
    "Pi matrices receive number cases, not an induction hypothesis.")
forged_schema = pi(base, pi(pi(matrix, successor), pi(T, eq(2, Z))))
add("quantified_induction_is_rejected", False,
    claim([], forged_schema, ["nat", matrix]),
    "Using the quantified matrix as the step guard would strengthen the theory.")
matrix = sig(T, eq(1, Z))
base = sig(T, T)
successor = sig(T, eq(suc(1), Z))
schema = pi(base, pi(pi(base, successor), sig(T, eq(2, Z))))
add("existential_matrix_gets_fixed_base_guard", True,
    claim([], schema, ["nat", matrix]),
    "The non-equation branch applies to Sigma as well as Pi.")
forged_schema = pi(base, pi(pi(matrix, successor), sig(T, eq(2, Z))))
add("existential_induction_is_rejected", False,
    claim([], forged_schema, ["nat", matrix]),
    "Existential matrices cannot obtain an induction hypothesis.")

good = claim([eq(0, Z)], eq(0, Z), hyp(eq(0, Z)))
alias = copy.deepcopy(good)
alias["proof"] = hyp(eq(False, -1.0))
add("hypothesis_alias_returns_stored_formula", True, alias,
    "A key alias may select an assumption but cannot introduce its own malformed syntax.")
bad = copy.deepcopy(good)
bad["goal"] = eq(False, Z)
add("boolean_variable_in_goal_is_rejected", False, bad,
    "JSON booleans are not numerical variables.")
bad = copy.deepcopy(good)
bad["assumptions"] = [eq(0.0, Z)]
add("float_variable_in_assumption_is_rejected", False, bad,
    "Malformed assumptions cannot enter the checked context.")
for name, goal in [
        ("negative_variable", eq(-2, Z)),
        ("unknown_constructor", ["mystery", Z]),
        ("wrong_constructor_arity", ["=", Z]),
        ("empty_constructor", []),
        ("unhashable_constructor", [[], Z]),
        ("formula_in_term_position", eq(F, Z)),
        ("term_in_guard_position", pi(0, T)),
        ("number_as_formula", 0)]:
    add(name, False, claim([], goal, ["rec", rec(Z, Z, Z)]),
        "The table-driven grammar must reject this malformed finite JSON assertion.")
bad = copy.deepcopy(good)
bad["extra"] = None
add("extra_root_key", False, bad, "The root input contract has exactly three fields.")
bad = copy.deepcopy(good)
bad["assumptions"] = {}
add("non_list_assumptions", False, bad, "An empty object is not an assumption list.")
add("unknown_proof_constructor", False, claim([], F, ["axiom", F]),
    "Unknown proof instructions cannot introduce an arbitrary assertion.")
add("old_annotated_pair_format_is_rejected", False,
    claim([T], sig(T, T), ["pair", sig(T, T), Z, hyp(T), hyp(T)]),
    "The new witness rule has exactly one accepted certificate shape.")


def run():
    results = []
    failures = []
    for name, expected, data, risk in CASES:
        error = None
        try:
            actual = KERNEL.check(copy.deepcopy(data)) is True
        except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError) as exc:
            actual = False
            error = type(exc).__name__
        except Exception as exc:
            actual = False
            error = "UNEXPECTED:" + type(exc).__name__
        ok = actual == expected and not (error or "").startswith("UNEXPECTED:")
        results.append({"name": name, "expected": expected, "accepted": actual,
                        "passed": ok, "exception": error, "risk": risk})
        if not ok:
            failures.append(name)

    # An alias lookup must return the actual stored valid object. Merely
    # returning an equal, unvalidated key would be a type-validation hole.
    context = [eq(0, Z)]
    stored = KERNEL.infer(hyp(eq(False, -1.0)), context)
    stored_ok = stored is context[0] and type(stored[1]) is int and type(stored[2]) is int
    if not stored_ok:
        failures.append("stored_context_identity")

    selected = {"bridge_false_to_clash", "bridge_clash_to_false", "false_is_not_an_axiom",
                "quantified_induction_is_rejected", "sigma_witness_cannot_escape_below_recursion",
                "recursion_step_simultaneous_and_nested", "unhashable_constructor",
                "hypothesis_alias_returns_stored_formula"}
    cli_results = []
    with tempfile.TemporaryDirectory(prefix="ipra-independent-audit-") as tmp:
        for name, expected, data, _ in CASES:
            if name not in selected:
                continue
            path = Path(tmp) / (name + ".json")
            path.write_text(json.dumps(data, allow_nan=False), encoding="utf-8")
            for optimize in (False, True):
                command = [sys.executable, *( ["-O"] if optimize else []),
                           str(ROOT / "checker.py"), str(path)]
                proc = subprocess.run(command, capture_output=True, text=True, timeout=20)
                ok = (proc.returncode == (0 if expected else 1)
                      and proc.stdout.strip() == ("ACCEPT" if expected else "REJECT")
                      and not proc.stderr)
                cli_results.append({"name": name, "optimized": optimize,
                                    "passed": ok, "exit_code": proc.returncode,
                                    "stdout": proc.stdout.strip(), "stderr": proc.stderr})
                if not ok:
                    failures.append(name + ("_optimized_cli" if optimize else "_cli"))

    report = {
        "python": sys.version.split()[0],
        "checker_sha256": hashlib.sha256((ROOT / "checker.py").read_bytes()).hexdigest(),
        "scope": "Finite targeted regression and source audit; no universal formal-verification claim.",
        "api_cases": len(results),
        "expected_accepted": sum(x[1] for x in CASES),
        "expected_rejected": sum(not x[1] for x in CASES),
        "stored_context_identity": stored_ok,
        "cli_cases": len(cli_results),
        "failures": failures,
        "cases": results,
        "cli_results": cli_results,
    }
    out = Path(__file__).with_name("independent_audit_results.json")
    out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k not in ("cases", "cli_results")}, indent=2))
    return not failures


if __name__ == "__main__":
    raise SystemExit(0 if run() else 1)
