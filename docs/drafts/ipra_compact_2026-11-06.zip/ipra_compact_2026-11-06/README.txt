A SMALLER COMPLETE CHECKER FOR INTUITIONISTIC PRA
Prepared for Vladimir Reshetnikov, 6 November 2026
=================================================

START HERE

  report.pdf                 Complete research report
  report.tex                 Rebuildable LaTeX source
  SPECIFICATION.txt          Entire primitive calculus and wire format
  checker.py                 Entire trusted acceptance program

RESULT

The proposed theory K is bi-interpretable with full first-order intuitionistic
PRA with quantifier-free induction. Both interpretations use the whole number
carrier and preserve genuine falsity. Internal equation-induction arguments
prove both interpretation round trips, including recursion parameter coherence.
The report specifies every primitive logical and arithmetic rule and schema.

Complete checker measurements, under one common source-counting convention:

                             This checker    Current coordinatewise minima
  Significant Python tokens       981                    1089
  Executable AST nodes           1039                    1154
  Raw UTF-8 source bytes         3535                    3817
  Normalized executable bytes    3127                    3486
  Token characters               2098                    2296

All syntax handling, scope operations, arithmetic data, rule checking, imports,
and the JSON CLI are counted. Comments/docstrings/layout are excluded from
tokens and AST; raw bytes include them. The same Python interpreter and standard
library are outside every source count. Exact definitions are in measure.py.

The comparison covers all six current primary draft checkers and eleven supplied
alternatives from ProveIt commit 3e7b2d6ae159163a2ac9b5000318cd5e822c6e30.
Archive Git blob hashes were verified. The 17 standalone source files are
included verbatim, so measurements require no network access. Earlier historical
copies nested in these archives are not recounted. This is a reproducible
improvement of the inspected frontier, not a global shortest-program theorem.

THE CONSTRUCTION

Terms: variables, zero, successor, finite initialized recursion R(n,a;u,v.h).
Formulas: equality, genuine falsity, guarded Pi, guarded Sigma.

Seven proof-record formats: hyp, pi, pair, use, bridge, rec, nat.
This does not mean seven distinct mathematical inference rules: use dispatches
three eliminations, bridge has two directions, and rec has two computation cases.

The new source combines independent draft reductions: shared elimination,
existential introduction under a witness equation, a numerical axiom schema,
direct JSON lists, safe stored-formula lookup, syntax tables, and a zero sentinel.
It keeps genuine falsity and an explicit arithmetic bridge. All eliminated
ordinary logical operations are derived. The numeric schema grants an induction
hypothesis only to a literal equation; other formulas receive constructor cases.
An explicit arithmetic equality test recovers all quantifier-free induction.

Two redundant guards were removed after independent review. The 998-token
explicit-guard version is preserved in controls/checker_explicit_guards.py.
validation/guard_equivalence.txt proves identical finite-JSON acceptance,
apart from implementation resource limits, for the two versions.

REPRODUCE

Requires Python 3.10+ and the standard library; tested with Python 3.12.14.
From the extracted directory:

  python3 reproduce.py
  python3 checker.py examples/reflexivity.json
  python3 measure.py

To compile a source-baseline proof into this format:

  python3 translator.py comparisons/original_certificates/legacy_exists_introduction.json compiled.json
  python3 checker.py compiled.json

translator.py is an untrusted compiler for the identified earlier native
certificate format. It is not an implemented front end for arbitrary iPRA
notation; the mathematical translations for that language are in the report.
An accepted certificate with assumptions proves a sequent. Use an empty
assumptions list for an unconditional theorem.

To rebuild the PDF and ZIP (also requires pdflatex and its listed packages):

  python3 build.py

The builder creates a local pdflatex format if the installed TeX distribution
does not have one. It compiles three passes and checks for overfull boxes and
unresolved references. PDF metadata may change on recompilation. The source
counts and certificate outcomes do not depend on the PDF build.

VERIFICATION

  53 original source certificates translated with identical stated sequents
  106 additional wrapped translations (one and two witness binders)
  8 additional translation stress examples
  167 positive translation checks in total, all passing
  3 invalid-source compiler rejection checks, all passing
  53 independent boundary API cases: 19 accepts, 34 rejects as expected
  1 stored-context identity check, passing
  16 CLI replays, ordinary and python -O, all passing

The independent mathematical review checks full logic, equation reflection,
the numerical schema, and both internal interpretation round trips. Written
proofs and finite tests accompany the implementation. No Lean/Rocq verification
of the Python kernel or metatheory is claimed. Very large finite proofs can
exceed the host stack or memory limits, as with the compared Python checkers.

CONTENTS

  report.pdf, report.tex       Research paper, including all axioms and source
  measurements.tex            Automatically generated exact size macros
  comparison_table.tex        Automatically generated comparison table
  checker.py                  Entire trusted checker
  translator.py               Untrusted source-certificate compiler
  regression.py               Translation/regression runner
  reproduce.py, build.py       Reproduction and PDF/archive building
  examples/                   Small self-contained certificate
  certificates/               Translated positive examples and stress cases
  comparisons/                Exact source copies, manifests, original fixtures
  controls/                   Acceptance-equivalent explicit-guard checker
  validation/                 Tests, measurements, mathematical/source audits
  SHA256SUMS.txt              Checksums of all other packaged files

ATTRIBUTION

All source drafts are from VladimirReshetnikov/ProveIt at the pinned commit.
The finite-recursion arithmetic, two guarded binders, derived equality and
explosion, equality-test argument and interpretation method are inherited.
The report credits the individual sources of the combined implementation cuts.
No source repository has been modified.
