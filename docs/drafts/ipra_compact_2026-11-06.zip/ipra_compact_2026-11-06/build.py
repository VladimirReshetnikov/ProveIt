"""Compile the report and package the complete source-and-PDF deliverable."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
NAME = 'ipra_compact_2026-11-06'


def compile_pdf():
    build = ROOT / 'build'
    build.mkdir(exist_ok=True)
    env = os.environ.copy()
    probe = subprocess.run(['kpsewhich', 'pdflatex.fmt'], text=True,
                           capture_output=True, cwd=build)
    if not probe.stdout.strip() and not (build / 'pdflatex.fmt').exists():
        with (build / 'format_creation.log').open('w') as log:
            subprocess.run(['pdftex', '-ini', '-etex', '-jobname=pdflatex',
                            '-progname=pdflatex', 'pdflatex.ini'], cwd=build,
                           stdout=log, stderr=subprocess.STDOUT, check=True)
    if (build / 'pdflatex.fmt').exists():
        env['TEXFORMATS'] = str(build) + os.pathsep + env.get('TEXFORMATS', '')
    for number in range(1, 4):
        with (build / ('latex_pass_%d.txt' % number)).open('w') as log:
            subprocess.run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
                            '-output-directory=' + str(build), 'report.tex'],
                           cwd=ROOT, env=env, stdout=log,
                           stderr=subprocess.STDOUT, check=True)
    log = (build / 'report.log').read_text()
    problems = [line for line in log.splitlines()
                if any(s in line for s in ('Overfull', 'undefined references',
                                          'undefined citations', 'Rerun to get'))]
    if problems:
        raise RuntimeError('PDF needs layout/reference review: ' + ' | '.join(problems))
    target = ROOT / 'report.pdf'
    shutil.copyfile(build / 'report.pdf', target)
    result = {'status': 'compiled', 'file': target.name,
              'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
              'bytes': target.stat().st_size, 'passes': 3, 'overfull_boxes': 0,
              'unresolved_references': 0}
    (ROOT / 'validation/build_results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


def package():
    if not (ROOT / 'report.pdf').is_file():
        raise FileNotFoundError('Build report.pdf before packaging')
    excluded_dirs = {'build', 'qa', '__pycache__', '.git'}
    excluded_suffixes = {'.zip', '.pyc', '.aux', '.log', '.out', '.toc', '.fmt'}
    selected = sorted(p for p in ROOT.rglob('*') if p.is_file()
                      and not any(c in excluded_dirs for c in p.relative_to(ROOT).parts)
                      and p.suffix not in excluded_suffixes and p.name != 'SHA256SUMS.txt')
    hashes = ''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  '
                     + p.relative_to(ROOT).as_posix() + '\n' for p in selected)
    manifest = ROOT / 'SHA256SUMS.txt'
    manifest.write_text(hashes)
    archive = ROOT.parent / (NAME + '.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in [*selected, manifest]:
            info = zipfile.ZipInfo(NAME + '/' + path.relative_to(ROOT).as_posix(),
                                   date_time=(2026, 11, 6, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, path.read_bytes())
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise RuntimeError('ZIP integrity failure')
        for line in hashes.splitlines():
            digest, path = line.split('  ', 1)
            if hashlib.sha256(z.read(NAME + '/' + path)).hexdigest() != digest:
                raise RuntimeError('ZIP checksum mismatch: ' + path)
    print(json.dumps({'archive': str(archive), 'files': len(selected) + 1,
                      'bytes': archive.stat().st_size,
                      'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--package-only', action='store_true')
    parser.add_argument('--pdf-only', action='store_true')
    args = parser.parse_args()
    if not args.package_only:
        compile_pdf()
    if not args.pdf_only:
        package()
