"""Replay the checked deliverable without network access; not part of the kernel."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

for arguments in [
    ['regression.py'],
    ['validation/independent_audit.py'],
    ['measure.py'],
    ['checker.py', 'examples/reflexivity.json'],
]:
    subprocess.run([sys.executable, *arguments], cwd=ROOT, check=True)
