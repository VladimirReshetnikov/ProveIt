"""Build the report with a local format fallback for incomplete TeX installations."""
from pathlib import Path
import argparse
import os
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--format', type=Path, help='Optional existing pdflatex.fmt')
    args = parser.parse_args()
    if shutil.which('pdflatex') is None:
        raise SystemExit('Install a LaTeX distribution containing pdflatex and the packages in report.tex.')
    env = os.environ.copy()
    env['SOURCE_DATE_EPOCH'] = '1794019742'
    env['FORCE_SOURCE_DATE'] = '1'
    with tempfile.TemporaryDirectory(prefix='ipra-tex-') as temporary:
        fmt = args.format.resolve() if args.format else None
        if fmt is None:
            found = subprocess.run(['kpsewhich', 'pdflatex.fmt'], capture_output=True, text=True)
            if not found.stdout.strip():
                ini = subprocess.check_output(['kpsewhich', 'pdflatex.ini'], text=True).strip()
                generated = subprocess.run(
                    ['pdftex', '-ini', '-etex', '-jobname=pdflatex', '-progname=pdflatex', ini],
                    cwd=temporary, env=env, capture_output=True, text=True)
                if generated.returncode:
                    raise RuntimeError(generated.stdout + generated.stderr)
                fmt = Path(temporary) / 'pdflatex.fmt'
        command = ['pdflatex', *(['-fmt=' + str(fmt)] if fmt else []),
                   '-interaction=nonstopmode', '-halt-on-error', 'report.tex']
        for _ in range(2):
            result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True)
            if result.returncode:
                raise RuntimeError(result.stdout + result.stderr)
        log = (ROOT / 'report.log').read_text(errors='replace')
        if 'undefined references' in log or 'Overfull' in log:
            raise RuntimeError('Inspect report.log: unresolved references or an overfull box.')
    print(str(ROOT / 'report.pdf'))


if __name__ == '__main__':
    main()
