"""Reproduce every reported code metric and proof-certificate audit offline."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PYTHON = sys.executable


def run(label, args):
    result = subprocess.run([PYTHON, '-B', *map(str, args)], cwd=ROOT,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    logs = ROOT / 'validation' / 'logs'
    logs.mkdir(exist_ok=True)
    (logs / (label + '.txt')).write_text(result.stdout)
    if result.returncode:
        print(result.stdout)
        raise RuntimeError(label + ' failed')
    print(label + ': passed')


def cli_checks():
    sys.path.insert(0, str(ROOT / 'validation'))
    from run_audit import cases
    selected = {
        'lam', 'nat_compound_false_induction_hypothesis',
        'eigenvariable_escape_rec_body', 'invalid_goal_float',
        'invalid_unused_context_formula',
    }
    folder = ROOT / 'validation' / 'cli_cases'
    folder.mkdir(exist_ok=True)
    records = []
    for name, data, accepted in cases('parameter'):
        if name not in selected:
            continue
        path = folder / (name + '.json')
        path.write_text(json.dumps(data, separators=(',', ':')) + '\n')
        for optimized in (False, True):
            cmd = [PYTHON, '-B', *(['-O'] if optimized else []),
                   str(ROOT / 'checker.py'), str(path)]
            result = subprocess.run(cmd, capture_output=True, text=True)
            expected = 'ACCEPT' if accepted else 'REJECT'
            passed = (result.returncode == (0 if accepted else 1)
                      and result.stdout.strip() == expected)
            records.append({'case': name, 'optimized': optimized,
                            'expected': expected, 'exit_code': result.returncode,
                            'output': result.stdout.strip(), 'passed': passed})
            if not passed:
                raise RuntimeError('CLI mismatch: ' + name)
    if len(records) != 10:
        raise RuntimeError('CLI suite selection changed')
    (ROOT / 'validation' / 'cli_results.json').write_text(json.dumps(records, indent=2) + '\n')
    return records


def main():
    initial = hashlib.sha256((ROOT / 'checker.py').read_bytes()).hexdigest()
    baseline = ROOT / 'comparison/sources/67d0fa6095dfa8c2d59de42bccc7d296f5c455158802815785e6cdc3a177b1a8.py'
    run('comparison', [ROOT / 'comparison/measure.py'])
    run('independent_oracle', [ROOT / 'validation/run_audit.py', ROOT / 'checker.py',
                              '--mode', 'parameter', '--out', ROOT / 'validation/independent_results.json'])
    run('exact_translations', [ROOT / 'validation/check_translations.py',
                              '--new', ROOT / 'checker.py', '--global-kernel', baseline,
                              '--local-kernel', ROOT / 'validation/local_control.py',
                              '--out', ROOT / 'validation/exact_translation_results.json'])
    run('schema_regression', [ROOT / 'validation/parameter_axiom_audit.py'])
    run('corpus_roundtrips', [ROOT / 'validation/roundtrips/run.py', '--target', ROOT / 'checker.py'])
    cli = cli_checks()
    if hashlib.sha256((ROOT / 'checker.py').read_bytes()).hexdigest() != initial:
        raise RuntimeError('The acceptance source changed during validation')
    metrics = json.loads((ROOT / 'comparison/metrics.json').read_text())
    oracle = json.loads((ROOT / 'validation/independent_results.json').read_text())
    translation = json.loads((ROOT / 'validation/exact_translation_results.json').read_text())
    schema = json.loads((ROOT / 'validation/parameter_axiom_audit.json').read_text())
    corpus = json.loads((ROOT / 'validation/roundtrips/results.json').read_text())
    result = {'python': sys.version.split()[0], 'checker_sha256': initial,
              'strict_improvement': metrics['strictly_below'],
              'independent_cases': oracle['explicit_count'],
              'independent_mutations': oracle['differential_mutations'],
              'oracle_disagreements': len(oracle['mismatches']),
              'translation_derivations': translation['checked_derivations'],
              'schema_derivations': sum(schema['counts'].values()),
              'cli_cases': len(cli), 'corpus_results': corpus,
              'all_passed': True}
    (ROOT / 'validation/reproduction.json').write_text(json.dumps(result, indent=2) + '\n')
    print('All suites passed; source hash ' + initial)


if __name__ == '__main__':
    main()
