A SMALLER AXIOMATIC KERNEL FOR iPRA
6 November 2026

START HERE

Read report.pdf. Its complete source is report.tex plus sections/ and the
generated comparison/ and validation/ numerical tables. The report includes
all logical rules and nonlogical schemas, full intuitionistic logical recovery,
primitive recursive arithmetic, whole-domain bi-interpretability, equiconsistency,
the checker invariant, exact proof translations, and further research questions.

THE RESULT

The native theory uses initialized recursion, equality, a guarded universal
binder, and an existential binder. Its nonlogical axioms are the two recursion
equations and one parameterized numerical axiom. Equation matrices get induction;
compound matrices get only zero/successor cases.

The new numerical axiom uses its outer universally quantified number as an
ordinary parameter of the matrix. This eliminates special premise-checking code
without adding strength. Both proof translations with the previous numerical
rule are explicit and executable.

The complete checker has 656 AST nodes, 622 normalized tokens and 1,988 normalized
bytes. The six current drafts' coordinatewise minima are 675, 634 and 2,053.
Source tokens are 624 versus 636; raw bytes are 2,136 versus 2,205.
The historical comparison includes 186 complete standalone candidates and 74
recorded dependency groups. All five strict inequalities are reproduced locally.
These are finite-corpus results, not an unrestricted minimality theorem.

TRUSTED ACCEPTANCE PROGRAM

Only checker.py participates in acceptance, together with Python and its standard
json/sys runtime. All other Python files are untrusted construction, comparison,
translation, or validation support. The main checker imports none of them.

Input is the finite JSON triple [context, goal, proof]. The context is a list
of reusable native formulas. Numerical zero is integer -1; nonnegative integers
in terms are de Bruijn number indices. A nat axiom payload has index 0 for the
induction/cases number and index 1 for the newly bound ordinary parameter.
See the report for the complete grammar and certificate format.

Negative and Boolean hypothesis indices are harmless aliases for stored formulas.
Booleans and floats are not valid number terms. A universal witness annotation
may be opaque only when the substituted number occurs in neither principal
component; zero reconstructs the same mathematical inference in that case.

USAGE

    python3 checker.py examples/reflexivity.json
    python3 reproduce.py
    python3 build.py

The checker prints ACCEPT or REJECT. Its direct function check(g,a,p) returns
normally on acceptance and raises on rejection; it does not return a Boolean.
The reproduction command checks hashes, compares sizes, replays proof round trips,
runs an independently written explicit oracle, and checks the CLI with and without
Python optimization. The build command regenerates the PDF with pdflatex and can
create a temporary local format when a TeX installation lacks pdflatex.fmt.

Python 3.12.14 was used for the published metrics. The checker requires Python
3.10 or later. Other versions may change AST pretty-printing measurements.
Support scripts use the standard library. PDF building requires the LaTeX
packages listed in report.tex, including amsmath, amsthm, mathtools, lmodern,
microtype, geometry, booktabs, tabularx, enumitem, xcolor, listings, fancyhdr,
hyperref, and bookmark. The prebuilt PDF is included.

EVIDENCE

- 63 explicit boundary cases: 29 acceptances and 34 rejections.
- 14,076 mutations compared against the independent oracle: zero disagreements.
- 2,163 exact schema/scope derivation checks.
- A separate 500-matrix regression: 2,000 derivation checks.
- 1,833 inherited labelled source records, including 1,262 positives completing
  both whole-proof round trips and 571 source-checker negative controls.
- 288 distinct resulting native certificates and 179 distinct sequents.
- 8,143 checker invocations in the corpus replay, with zero failures.

The negative source controls test their frozen source kernels; invalid source
proofs are not translated into new-kernel rejection cases. The independent audit
provides the new-kernel negative evidence. Finite tests supplement the paper's
proofs; no Lean/Rocq formalization of the full metatheory is claimed.

FILES

report.pdf, report.tex, sections/     The complete paper and LaTeX sources.
checker.py                          The complete measured acceptance program.
examples/                           Accepted proofs, including parameterized axioms.
comparison/manifest.json            Pinned provenance and accounting boundary.
comparison/sources/                 Frozen complete programs and group dependencies.
comparison/metrics.json              Full measurements and strict comparisons.
validation/oracle.py                 Independent explicit-tree semantics.
validation/roundtrips/               Portable corpus, translators and frozen checkers.
validation/local_control.py          Equivalent local-rule control (662 AST nodes).
validation/reproduction.json         Results of the full offline reproduction.
build.py, reproduce.py               PDF build and verification entry points.
LICENSE                             ProveIt's MIT No Attribution license.

CREDIT

The inherited logical basis, most arithmetic and interpretation arguments,
demand validation, checked scope deletion, and several implementation reductions
are due to the ProveIt draft series. The exact inspected source is
VladimirReshetnikov/ProveIt at commit
0a86fcbd7c5e0d6a541291b4ac06c7dc77989161, docs/drafts.
The parameterized axiom internalization, its complete implementation and the
present measured comparison are the new contribution. Source hashes and exact
origins are recorded throughout the archive.
