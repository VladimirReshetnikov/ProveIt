"""Exact inferred-sequent checks for the parameterized nat axiom translations."""
import argparse
import hashlib
import importlib.util
import json
import random
from pathlib import Path
from oracle import nat_parts, raise_formula


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def matrices():
    rng = random.Random(231747)
    def term(depth):
        if depth == 0 or rng.randrange(3) == 0:
            return rng.randrange(-1, 5)
        if rng.randrange(2):
            return ['s', term(depth-1)]
        return ['r', term(depth-1), term(depth-1), term(depth-1)]
    def formula(depth):
        if depth == 0 or rng.randrange(3) == 0:
            return ['=', term(2), term(2)]
        if rng.randrange(2):
            return ['ex', formula(depth-1)]
        return ['pi', formula(depth-1), formula(depth-1)]
    result = [
        ['=', 0, 0], ['=', 0, 1], ['=', 1, 2],
        ['=', ['r', 0, 1, ['r', 2, 3, 6]], 2],
        ['ex', ['=', 0, 1]], ['ex', ['=', 1, 2]],
        ['pi', ['=', 1, 2], ['ex', ['=', 2, 4]]],
    ]
    result += [formula(3) for _ in range(96)]
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--new', type=Path, required=True)
    ap.add_argument('--global-kernel', type=Path, required=True)
    ap.add_argument('--local-kernel', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    new = module(args.new, 'translation_new')
    glob = module(args.global_kernel, 'translation_global')
    local = module(args.local_kernel, 'translation_local')
    checked = 0
    failures = []
    contexts = [[], [['=', 0, 0]], [['ex', ['=', 0, 1]], ['=', 2, 3]]]
    for index, a in enumerate(matrices()):
        base, successor, guard = nat_parts(a)
        step = ['pi', guard, successor]
        conclusion = ['pi', base, a]
        axiom = ['pi', step, conclusion]
        for g in contexts:
            specifications = [
                ('axiom_to_global', glob, ['lam', step, ['nat', a, -1]], g, axiom),
                ('axiom_to_local', local, ['lam', step, ['nat', a, [-2, 0, -1]]], g, axiom),
                ('axiom_new', new, ['nat', a], g, axiom),
                ('global_to_axiom', new, [['nat', raise_formula(a, cutoff=1)], -1, -1],
                 g+[step], conclusion),
                ('global_source', glob, ['nat', a, -1], g+[step], conclusion),
                ('local_to_axiom', new, [['nat', raise_formula(a, cutoff=1)], -1,
                                        ['lam', guard, [-2, 0, -1]]], g+[step], conclusion),
                ('local_source', local, ['nat', a, [-2, 0, -1]], g+[step], conclusion),
            ]
            for name, kernel, proof, context, goal in specifications:
                checked += 1
                try:
                    actual = kernel.infer(proof, context)
                    if actual != goal:
                        failures.append({'case': name, 'matrix': index,
                                         'actual': actual, 'goal': goal})
                except Exception as error:
                    failures.append({'case': name, 'matrix': index,
                                     'error': type(error).__name__ + ': ' + str(error)})
    report = {'matrices': len(matrices()), 'contexts': len(contexts),
              'checked_derivations': checked, 'failures': failures,
              'new_sha256': hashlib.sha256(args.new.read_bytes()).hexdigest(),
              'passed': not failures}
    args.out.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))
    return 0 if not failures else 1

if __name__ == '__main__':
    raise SystemExit(main())
