"""Independent finite regression of the parameterized axiom equivalence.
This script is untrusted evidence, not part of the acceptance kernel.
"""
from pathlib import Path
import importlib.util
import json
import random

ROOT = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


old = load('old_demand', ROOT / 'comparison/sources/67d0fa6095dfa8c2d59de42bccc7d296f5c455158802815785e6cdc3a177b1a8.py')
new = load('new_parameter_axiom', ROOT / 'checker.py')
rng = random.Random(20261106)


def term(depth):
    if depth == 0 or rng.randrange(4) == 0:
        return rng.randrange(-1, 8)
    if rng.randrange(2):
        return ['s', term(depth - 1)]
    return ['r', term(depth - 1), term(depth - 1), term(depth - 1)]


def formula(depth):
    if depth == 0 or rng.randrange(3) == 0:
        return ['=', term(2), term(2)]
    if rng.randrange(2):
        return ['ex', formula(depth - 1)]
    return ['pi', formula(depth - 1), formula(depth - 1)]


counts = {'axiom_old_derivations': 0, 'axiom_new_derivations': 0,
          'old_rule_derivations': 0, 'new_rule_simulations': 0}
for _ in range(500):
    a = formula(3)
    base = old.subst(a, [-1, 0])
    step = ['pi', a if a[0] == '=' else base,
            old.subst(a, [['s', 0], 0])]
    conclusion = ['pi', base, a]
    axiom = ['pi', step, conclusion]
    context = [formula(2), formula(2)]
    # Under the outer fresh ordinary parameter z, the step is the last
    # hypothesis. The original N checks exactly that step and returns
    # its guarded conclusion. No assumption concerning z is retained.
    old.check(context, axiom, ['lam', step, ['nat', a, -1]])
    counts['axiom_old_derivations'] += 1
    new.check(context, axiom, ['nat', a])
    counts['axiom_new_derivations'] += 1
    # Conversely, use an old N premise as an arbitrary hypothesis.
    # Protect the distinguished counter (index 0) and open a new slot at
    # index 1 for the axiom's ordinary parameter z; make z vacuous.
    old.check([*context, step], conclusion, ['nat', a, -1])
    counts['old_rule_derivations'] += 1
    a_padded = old.subst(a, (1,), 1)
    new.check([*context, step], conclusion, [['nat', a_padded], -1, -1])
    counts['new_rule_simulations'] += 1

result = {'seed': 20261106, 'matrices': 500, 'max_formula_depth': 3,
          'term_generation_depth': 2, 'free_index_range': [0, 7],
          'counts': counts, 'all_passed': True}
path = Path(__file__).with_name('parameter_axiom_audit.json')
path.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
