"""Independent, explicit finite-tree semantics for the three candidate kernels.

This is an audit oracle, not part of the acceptance kernel. Unlike the kernel,
it has separate grammar checking, raising, substitution, and inference code.
"""

class Reject(ValueError):
    pass


def demand(ok):
    if not ok:
        raise Reject('invalid certificate')


def term(t):
    if type(t) is int:
        demand(t >= -1)
    elif type(t) is list and len(t) == 2 and t[0] == 's':
        term(t[1])
    elif type(t) is list and len(t) == 4 and t[0] == 'r':
        for child in t[1:]:
            term(child)
    else:
        raise Reject('not a term')


def formula(a):
    demand(type(a) is list and bool(a))
    if a[0] == '=' and len(a) == 3:
        term(a[1]); term(a[2])
    elif a[0] == 'pi' and len(a) == 3:
        formula(a[1]); formula(a[2])
    elif a[0] == 'ex' and len(a) == 2:
        formula(a[1])
    else:
        raise Reject('not a formula')


def raise_term(t, amount=1, cutoff=0):
    term(t)
    if type(t) is int:
        return t if t < cutoff else t + amount
    if t[0] == 's':
        return ['s', raise_term(t[1], amount, cutoff)]
    return ['r', raise_term(t[1], amount, cutoff),
            raise_term(t[2], amount, cutoff),
            raise_term(t[3], amount, cutoff + 2)]


def raise_formula(a, amount=1, cutoff=0):
    formula(a)
    if a[0] == '=':
        return ['=', raise_term(a[1], amount, cutoff),
                raise_term(a[2], amount, cutoff)]
    if a[0] == 'pi':
        return ['pi', raise_formula(a[1], amount, cutoff + 1),
                raise_formula(a[2], amount, cutoff + 1)]
    return ['ex', raise_formula(a[1], amount, cutoff + 1)]


def sub_term(t, replacements, delta, depth=0):
    term(t)
    if type(t) is int:
        if t < depth:
            return t
        offset = t - depth
        if offset < len(replacements):
            return raise_term(replacements[offset], depth)
        return t + delta
    if t[0] == 's':
        return ['s', sub_term(t[1], replacements, delta, depth)]
    return ['r', sub_term(t[1], replacements, delta, depth),
            sub_term(t[2], replacements, delta, depth),
            sub_term(t[3], replacements, delta, depth + 2)]


def sub_formula(a, replacements, delta, depth=0):
    formula(a)
    if a[0] == '=':
        return ['=', sub_term(a[1], replacements, delta, depth),
                sub_term(a[2], replacements, delta, depth)]
    if a[0] == 'pi':
        return ['pi', sub_formula(a[1], replacements, delta, depth + 1),
                sub_formula(a[2], replacements, delta, depth + 1)]
    return ['ex', sub_formula(a[1], replacements, delta, depth + 1)]


def raised_context(g):
    return [raise_formula(a) for a in g]


def nat_parts(a):
    formula(a)
    base = sub_formula(a, [-1], 0)
    successor = sub_formula(a, [['s', 0]], 0)
    guard = a if a[0] == '=' else base
    return base, successor, guard


def infer(p, g, mode='local'):
    if type(p) is not list:
        demand(type(p) in (int, bool))
        demand(-len(g) <= p < len(g))
        return g[p]
    demand(bool(p))
    if len(p) == 3 and p[0] == 'lam':
        guard = p[1]
        formula(guard)
        body = infer(p[2], raised_context(g) + [guard], mode)
        return ['pi', guard, body]
    if len(p) == 3 and p[0] == 'pack':
        witness = p[1]
        term(witness)
        guard = ['=', 0, raise_term(witness)]
        body = infer(p[2], raised_context(g) + [guard], mode)
        return ['ex', body]
    if p[0] == 'nat':
        if mode == 'local' and len(p) == 3:
            base, successor, guard = nat_parts(p[1])
            body = infer(p[2], raised_context(g) + [guard], mode)
            demand(body == successor)
            return ['pi', base, p[1]]
        if mode in ('axiom', 'parameter') and len(p) == 2:
            base, successor, guard = nat_parts(p[1])
            step = ['pi', guard, successor]
            conclusion = ['pi', base, p[1]]
            if mode == 'axiom':
                return ['pi', raise_formula(step), raise_formula(conclusion)]
            return ['pi', step, conclusion]
        raise Reject('wrong nat form')
    if len(p) == 4 and p[0] == 'r':
        term(p)
        counter, initial, update = p[1:]
        if counter == -1:
            rhs = initial
        else:
            demand(type(counter) is list and len(counter) == 2 and counter[0] == 's')
            previous = counter[1]
            recursion = ['r', previous, initial, update]
            rhs = sub_term(update, [recursion, previous], -2)
        return ['=', p, rhs]
    major = infer(p[0], g, mode)
    if major[0] == 'ex':
        demand(len(p) == 2)
        body = infer(p[1], raised_context(g) + [major[1]], mode)
        return sub_formula(body, [None], -1)
    demand(len(p) == 3)
    annotation, minor_proof = p[1:]
    if major[0] == 'pi':
        before = sub_formula(major[1], [annotation], -1)
        after = sub_formula(major[2], [annotation], -1)
    else:
        demand(major[0] == '=')
        before = sub_formula(annotation, [major[1]], -1)
        after = sub_formula(annotation, [major[2]], -1)
    demand(infer(minor_proof, g, mode) == before)
    return after


def check(data, mode='local'):
    demand(type(data) is list and len(data) == 3)
    g, a, p = data
    demand(type(g) is list)
    for item in g:
        formula(item)
    formula(a)
    demand(infer(p, g, mode) == a)
    return True
