"""Adversarial, independent-oracle comparison for the iPRA candidate."""
import argparse
import copy
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
import sys
from oracle import (check as oracle_check, infer as oracle_infer, raise_formula,
                    raise_term, sub_formula, term, nat_parts)

T = ['=', -1, -1]

def eq(a, b):
    return ['=', a, b]

def refl(t):
    r = ['r', -1, t, -1]
    return [r, ['=', 0, raise_term(t)], r]

def success(call):
    try:
        call()
        return True
    except Exception:
        return False

def paths(x, prefix=()):
    yield prefix
    if type(x) is list:
        for index, child in enumerate(x):
            yield from paths(child, prefix + (index,))

def replace(x, path, new):
    if not path:
        return copy.deepcopy(new)
    y = copy.deepcopy(x)
    target = y
    for index in path[:-1]:
        target = target[index]
    target[path[-1]] = copy.deepcopy(new)
    return y


def cases(mode):
    out = []
    def good(name, g, p, goal=None):
        if goal is None:
            goal = oracle_infer(p, g, mode)
        out.append((name, [g, goal, p], True))
    def bad(name, data):
        out.append((name, data, False))
    good('hypothesis_positive', [eq(0, 0)], 0, eq(0, 0))
    good('hypothesis_negative', [T, eq(0, 0)], -1, eq(0, 0))
    good('hypothesis_boolean_alias', [T, eq(0, 0)], True, eq(0, 0))
    good('lam', [], ['lam', eq(0, 0), 0], ['pi', eq(0, 0), eq(0, 0)])
    good('pack', [], ['pack', -1, 0], ['ex', eq(0, -1)])
    good('recursor_base', [], ['r', -1, 0, 1], eq(['r', -1, 0, 1], 0))
    good('recursor_successor', [], ['r', ['s', 0], -1, 0],
         eq(['r', ['s', 0], -1, 0], ['r', 0, -1, 0]))
    good('pi_use_external_witness', [['pi', T, eq(0, 0)], T], [0, ['s', 0], 1],
         eq(['s', 0], ['s', 0]))
    good('equality_template_with_parameter', [eq(0, 1), eq(0, 0)],
         [0, eq(1, 0), 1], eq(0, 1))
    good('equality_template_nested_rec', [eq(0, 1), eq(['r', -1, -1, 2], 0)],
         [0, eq(['r', -1, -1, 3], 0), 1], eq(['r', -1, -1, 2], 1))
    good('ex_use_constant_conclusion', [['ex', eq(0, 0)]], [0, refl(-1)], T)
    good('ex_use_retained_parameter', [['ex', eq(0, 0)], eq(0, 0)], [0, 1], eq(0, 0))
    good('ex_use_internal_pi_bound', [['ex', T]], [0, ['lam', T, refl(0)]],
         ['pi', T, eq(0, 0)])
    good('ex_use_internal_ex_bound', [['ex', T]], [0, ['pack', -1, -1]],
         ['ex', eq(0, -1)])
    good('ex_use_internal_rec_bounds', [['ex', T]],
         [0, refl(['r', -1, -1, 0])])
    matrices = [('equation', eq(0, 0)),
                ('compound_ex', ['ex', eq(0, 1)]),
                ('compound_pi', ['pi', T, eq(0, 0)]),
                ('parameter_equation', eq(0, 1)),
                ('two_parameters', eq(1, 2))]
    if mode == 'local':
        good('nat_equation_induction', [], ['nat', eq(0, 0), refl(['s', 0])])
        good('nat_compound_cases', [], ['nat', ['ex', eq(0, 1)],
                                      ['pack', ['s', 0], -1]])
        bad('nat_compound_false_induction_hypothesis',
            [[], ['pi', ['ex', eq(0, -1)], ['ex', eq(0, 1)]],
             ['nat', ['ex', eq(0, 1)], 0]])
        bad('nat_incorrect_equational_step',
            [[], ['pi', eq(-1, -1), eq(0, 0)], ['nat', eq(0, 0), 0]])
    else:
        for label, matrix in matrices:
            good('nat_axiom_' + label, [], ['nat', matrix])
        matrix = ['ex', eq(0, 1)]
        base, step, guard = nat_parts(matrix)
        incorrect = ['pi', ['pi', matrix, step], ['pi', base, matrix]]
        if mode == 'axiom':
            incorrect = ['pi', raise_formula(incorrect[1]), raise_formula(incorrect[2])]
        bad('nat_compound_false_induction_hypothesis', [[], incorrect, ['nat', matrix]])
        # Instantiate the new axiom with its valid universal step as a premise.
        matrix = eq(0, 0)
        base, successor, guard = nat_parts(matrix)
        step = ['pi', guard, successor]
        payload = raise_formula(matrix, cutoff=1) if mode == 'parameter' else matrix
        good('nat_axiom_eliminated', [step], [['nat', payload], -1, 0],
             ['pi', base, matrix])
    for i, annotation in enumerate([None, 'opaque', {'never': ['read']}, True, -1.0,
                                     ['bad', 0], [], ['s', 0, 1]]):
        good('unused_witness_' + str(i), [['pi', T, T], T], [0, annotation, 1], T)
        bad('used_witness_' + str(i), [[['pi', T, eq(0, 0)], T], T, [0, annotation, 1]])
    for label, branch in [
        ('direct', refl(0)),
        ('pi_consequent', ['lam', T, refl(1)]),
        ('pi_guard', ['lam', eq(1, 1), -1]),
        ('ex_matrix', ['pack', -1, refl(1)]),
        ('rec_body', refl(['r', -1, -1, 2]))]:
        bad('eigenvariable_escape_' + label, [[['ex', T]], T, [0, branch]])
    for i, counter in enumerate([0, True, -1.0, ['s', 0, 1], ['r', -1, -1, 0],
                                  ['bad', 0], ['ex', T], None]):
        bad('malformed_rec_counter_' + str(i), [[], T, ['r', counter, -1, -1]])
    for label, goal in [('float', eq(-1.0, -1)), ('boolean', eq(False, False)),
                        ('extra_field', ['=', -1, -1, -1]),
                        ('float_variable', eq(0.0, 0)),
                        ('boolean_variable', eq(True, 1))]:
        proof = refl(-1 if label == 'float' else 0 if label in ('boolean','float_variable') else 1)
        bad('invalid_goal_' + label, [[], goal, proof])
    bad('malformed_context_type', [{}, T, refl(-1)])
    bad('invalid_unused_context_formula', [[['bogus']], T, refl(-1)])
    bad('hypothesis_not_exact_goal', [[T], eq(0, 0), 0])
    bad('hypothesis_float_index', [[T], T, 0.0])
    bad('hypothesis_out_of_bounds', [[T], T, 1])
    bad('empty_proof', [[], T, []])
    bad('malformed_nat_matrix', [[], T, ['nat', ['=', -1.0, -1]]])
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('candidate', type=Path)
    parser.add_argument('--mode', choices=['local','axiom','parameter'], default='local')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    source = args.candidate.read_bytes()
    spec = importlib.util.spec_from_file_location('audited_candidate', args.candidate)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    arity = len(inspect.signature(module.check).parameters)
    def kernel(data):
        if arity == 1:
            module.check(data)
        else:
            module.check(*data)
    explicit = cases(args.mode)
    report = {'candidate': args.candidate.name, 'mode': args.mode,
              'sha256': hashlib.sha256(source).hexdigest(), 'explicit': [],
              'differential_mutations': 0, 'mutations_accepted': 0,
              'mutations_rejected': 0, 'mismatches': []}
    for name, data, expected in explicit:
        oracle = success(lambda: oracle_check(data, args.mode))
        actual = success(lambda: kernel(data))
        report['explicit'].append({'name': name, 'expected': expected,
                                  'oracle': oracle, 'candidate': actual})
        if oracle != expected or actual != expected:
            report['mismatches'].append({'name': name, 'data': data,
                                         'expected': expected, 'oracle': oracle, 'candidate': actual})
    alternatives = [None, True, False, -2, -1.0, 0.0, 0, -1, 1, '', 'pi', {}, [],
                    ['s'], ['s',-1,-1], ['=',-1,-1], ['ex',['=',-1,-1]],
                    ['r',-1,-1,2]]
    # These are semantic boundary mutations; some are valid certificates.
    for name, data, expected in explicit:
        if not expected:
            continue
        for path in paths(data):
            for alternative in alternatives:
                mutated = replace(data, path, alternative)
                oracle = success(lambda: oracle_check(mutated, args.mode))
                actual = success(lambda: kernel(mutated))
                report['differential_mutations'] += 1
                report['mutations_accepted' if actual else 'mutations_rejected'] += 1
                if oracle != actual:
                    report['mismatches'].append({'name': name, 'path': list(path),
                                                'replacement': alternative,
                                                'oracle': oracle, 'candidate': actual})
    report['explicit_count'] = len(explicit)
    report['explicit_positive'] = sum(row[2] for row in explicit)
    report['explicit_negative'] = len(explicit) - report['explicit_positive']
    report['source_unchanged_during_run'] = source == args.candidate.read_bytes()
    report['passed'] = not report['mismatches'] and report['source_unchanged_during_run']
    args.out.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({key: value for key, value in report.items()
                      if key not in ('explicit','mismatches')}, indent=2))
    if report['mismatches']:
        print(json.dumps(report['mismatches'][:5], indent=2))
    return 0 if report['passed'] else 1

if __name__ == '__main__':
    sys.exit(main())
