"""Untrusted structural proof translations; no checker imports this module.

Every public certificate conversion checks its source before traversing proof
positions. Witness/motive annotations are copied as JSON data, never executed.
Negative and Boolean hypothesis aliases are normalized to nonnegative indices.
"""
from collections import Counter


class Translator:
    def __init__(self, target):
        self.target = target
        self.events = Counter()

    def lift_context(self, context):
        return [self.target.subst(a) for a in context]

    def index(self, proof, context, formula_leaves=False):
        if formula_leaves:
            self.events['formula_hypotheses'] += 1
            return context.index(proof)
        if type(proof) not in (int, bool):
            raise ValueError('Not an indexed hypothesis')
        self.events['boolean_hypothesis_aliases'] += type(proof) is bool
        self.events['negative_hypothesis_aliases'] += proof < 0
        index = int(proof)
        if index < 0:
            index += len(context)
        if not 0 <= index < len(context):
            raise IndexError(index)
        return index

    def forward(self, proof, context, source, profile):
        """Accepted source derivation to the parameter-axiom calculus."""
        pi_intro, ex_intro = profile.get('intros', ['lam', 'pack'])
        if isinstance(proof, list):
            if len(proof) == 3 and proof[0] in (pi_intro, ex_intro):
                tag, a, q = proof
                is_pi = tag == pi_intro
                h = a if is_pi else ['=', 0, self.target.subst(a, formula=False)]
                return ['lam' if is_pi else 'pack', a,
                        self.forward(q, self.lift_context(context) + [h], source, profile)]
            if len(proof) == 4 and proof[0] == 'r':
                self.events['recursor_equations'] += 1
                return proof
            if len(proof) == 3 and proof[0] == 'nat':
                _, a, q = proof
                matrix = self.target.subst(a, (1,), 1)
                if profile.get('local_nat', False):
                    h = a if a[0] == '=' else self.target.subst(a, [-1, 0])
                    step = ['lam', h, self.forward(
                        q, self.lift_context(context) + [h], source, profile)]
                    self.events['local_numerical_rules'] += 1
                else:
                    step = self.forward(q, context, source, profile)
                    self.events['global_numerical_rules'] += 1
                return [['nat', matrix], -1, step]
            if profile.get('application', 'tagged') == 'bare' or (proof and proof[0] == 'use'):
                if profile.get('application', 'tagged') == 'bare':
                    major, *args = proof
                else:
                    _, major, *args = proof
                tag, *parts = source.infer(major, context)
                converted = self.forward(major, context, source, profile)
                if tag == 'ex':
                    if profile.get('explicit_ex', False):
                        _, q = args
                    else:
                        q, = args
                    self.events['existential_eliminations'] += 1
                    return [converted, self.forward(
                        q, self.lift_context(context) + parts, source, profile)]
                a, q = args
                if tag == 'pi':
                    try:
                        self.target.subst(a, formula=False)
                    except Exception:
                        self.events['opaque_unused_witnesses'] += 1
                self.events['equality_eliminations' if tag == '=' else 'guarded_applications'] += 1
                return [converted, a, self.forward(q, context, source, profile)]
        return self.index(proof, context, profile.get('formula_leaves', False))

    def backward(self, proof, context, local_nat=False):
        """Parameter-axiom proof to original demand or shared-transition syntax."""
        if isinstance(proof, list):
            if len(proof) == 3 and proof[0] in ('lam', 'pack'):
                tag, a, q = proof
                h = a if tag == 'lam' else ['=', 0, self.target.subst(a, formula=False)]
                return [tag, a, self.backward(
                    q, self.lift_context(context) + [h], local_nat)]
            if len(proof) == 4 and proof[0] == 'r':
                return proof
            if len(proof) == 2 and proof[0] == 'nat':
                _, a = proof
                base = self.target.subst(a, [-1, 0])
                h = a if a[0] == '=' else base
                step = ['pi', h, self.target.subst(a, [['s', 0], 0])]
                premise = ['use', len(context), 0, len(context) + 1] if local_nat else len(context)
                return ['lam', step, ['nat', a, premise]]
            major, *args = proof
            tag, *parts = self.target.infer(major, context)
            converted = self.backward(major, context, local_nat)
            if tag == 'ex':
                q, = args
                return ['use', converted, self.backward(
                    q, self.lift_context(context) + parts, local_nat)]
            a, q = args
            return ['use', converted, a, self.backward(q, context, local_nat)]
        return self.index(proof, context)


def unpack(data, profile):
    if profile.get('layout', 'context_goal_proof') == 'goal_proof_context':
        a, p, *g = data
        return g, a, p
    g, a, p = data
    return g, a, p


def source_check(module, profile, data):
    if profile.get('api', 'packed') == 'spread':
        module.check(*data)
    else:
        module.check(data)


def to_native(module, profile, target, data, translator=None):
    source_check(module, profile, data)
    g, a, p = unpack(data, profile)
    translator = translator or Translator(target)
    result = [g, a, translator.forward(p, g, module, profile)]
    target.check(*result)
    return result


def from_native(target, baseline, data, local_nat=False, translator=None):
    target.check(*data)
    g, a, p = data
    translator = translator or Translator(target)
    result = [g, a, translator.backward(p, g, local_nat)]
    baseline.check(result) if local_nat else baseline.check(*result)
    return result
