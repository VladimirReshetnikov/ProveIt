BIDIRECTIONAL CORPUS REPLAY FOR THE PARAMETERIZED iPRA AXIOM

Run from any working directory:

    python3 /absolute/path/to/roundtrip_validation/run.py

To check a separately delivered candidate instead of the frozen candidate:

    python3 /absolute/path/to/roundtrip_validation/run.py --target /absolute/path/to/checker.py

Only the Python standard library is required. The runner reads all checker
sources and corpus data; it writes results.json, record_results.jsonl and
native_corpus.jsonl beside itself. It does not modify any checker source and
disables Python bytecode-cache creation. No file in this validation directory
is imported by the trusted candidate checker.

CONTENTS

- manifest.json records exact source-checker SHA-256 identities, dialects,
  origin paths and the corpus hash. All sources were read from the six current
  supplied draft archives at repository commit
  0a86fcbd7c5e0d6a541291b4ac06c7dc77989161, except the new candidate.
- sources/ freezes those exact standalone checker bytes.
- corpus.jsonl freezes 1,833 labelled source records. The corpus selection
  follows the supplied manifests rather than filtering by candidate behavior.
- translations.py implements structural proof translations. Ordinary
  annotations are copied as data; only proof positions are traversed.
- run.py verifies all source hashes and expected labels, then checks every
  accepted source through both complete proof round trips.
- native_corpus.jsonl contains the 288 distinct resulting native certificates,
  their hashes, and all original record indices.
- record_results.jsonl records every origin and checked output hash.
- results.json gives counts, source hashes, per-cohort results and failures.

TRANSLATIONS

The primary old calculus is the original demand kernel, whose numerical rule
has a proof of the universally quantified step as its premise. Its rule node
['nat', A, p] becomes

    [['nat', lift_parameters(A)], -1, translate(p)]

where lift_parameters(A) = subst(A, (1,), 1), preserving induction variable
index 0 and inserting the new outer parameter at index 1. Conversely, the
new axiom ['nat', A] becomes

    ['lam', step(A), ['nat', A, m]]

in a context of length m: ordinary guarded introduction adds the step
assumption at index m, and the old numerical rule consumes that assumption.
Applications lose or gain their old 'use' tag.

The shared-transition calculus has the local fresh-number successor body as
its numerical premise. In its forward translation, that body is first
wrapped by ordinary guarded introduction. The reverse axiom proof is

    ['lam', step(A), ['nat', A, ['use', m, 0, m+1]]]

with the step and the local induction/base hypotheses at indices m and m+1.
The other supplied dialects differ only in these rule forms, introduction
names, presence of an explicit existential conclusion, and whether a
hypothesis is represented by its formula or by an index.

Negative and Boolean index aliases are normalized to the actual nonnegative
context position. Formula-leaf aliases resolve to the stored context formula.
Opaque unused universal witnesses remain opaque JSON data. They are never
interpreted as proof nodes or executed.

RESULTS

All 1,833 expected source labels agree: 1,262 positive records and 571 negative
source controls. Every positive record completes:

    source -> native -> original demand -> native
                     -> shared transition -> native

There are 8,143 checker invocations across these stages, with zero failures.
The positive origins contain duplicates. The resulting native corpus has
288 distinct certificates and 179 distinct context/conclusion judgments.
The forward cases include 45 with opaque unused witnesses, 8 with negative
hypothesis aliases, and 1 with a Boolean hypothesis alias.

The 571 negative controls verify the frozen sources' recorded labels; invalid
source derivations are not translated. Separate candidate rejection testing
belongs to the independent audit. These finite tests are supporting evidence,
not a substitute for the mathematical interpretation and translation proofs.
