"""Replay all frozen source labels and bidirectional native proof translations.

Usage: python3 run.py [--target /absolute/path/to/checker.py]
The target and all source checkers are standalone. This runner, the translator,
and frozen corpus are untrusted testing support and are not part of acceptance.
"""
from collections import Counter, defaultdict
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import time
import sys

sys.dont_write_bytecode = True

from translations import Translator, source_check, unpack

ROOT = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, separators=(',', ':'), sort_keys=True, ensure_ascii=True) + '\n'


def load(path, name, expected=None):
    digest = sha(path.read_bytes())
    if expected is not None and digest != expected:
        raise ValueError('Checker hash mismatch: ' + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module, digest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', type=Path)
    args = parser.parse_args()
    started = time.perf_counter()
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    raw = (ROOT / manifest['corpus_file']).read_bytes()
    if sha(raw) != manifest['corpus_sha256']:
        raise ValueError('Corpus hash mismatch')
    records = [json.loads(line) for line in raw.splitlines()]
    if len(records) != manifest['record_count']:
        raise ValueError('Corpus count mismatch')
    profiles = manifest['profiles']
    modules = {}
    source_hashes = {}
    for name, profile in profiles.items():
        path = ROOT / profile['file']
        modules[name], source_hashes[name] = load(path, 'frozen_' + name, profile['sha256'])
    target = modules['target']
    target_hash = source_hashes['target']
    if args.target is not None:
        target, target_hash = load(args.target.resolve(), 'tested_candidate')
    translator = Translator(target)
    counts = Counter()
    cohorts = defaultdict(Counter)
    feature_cases = Counter()
    failures = []
    details = []
    unique_sources = set()
    unique_judgments = set()
    native = {}
    demand = modules['demand']
    shared = modules['shared']
    for index, record in enumerate(records):
        name = record['profile']
        profile = profiles[name]
        module = target if name == 'target' else modules[name]
        data = record['data']
        detail = {'index': index, 'cohort': record['cohort'], 'origin': record['origin'],
                  'source_profile': name, 'expected': record['expected'],
                  'input_sha256': sha(canonical(data).encode())}
        unique_sources.add((source_hashes[name], detail['input_sha256']))
        accepted = True
        try:
            source_check(module, profile, data)
        except Exception as error:
            accepted = False
            detail['source_exception'] = type(error).__name__
        counts['source_checks'] += 1
        detail['source_accepted'] = accepted
        if accepted != record['expected']:
            failures.append({'index': index, 'stage': 'source_label', 'origin': record['origin'],
                             'expected': record['expected'], 'actual': accepted})
        cohort = cohorts[record['cohort']]
        cohort['source_positive' if accepted else 'source_negative'] += 1
        counts['source_positive' if accepted else 'source_negative'] += 1
        if not accepted:
            details.append(detail)
            continue
        stage = 'forward'
        try:
            g, a, p = unpack(data, profile)
            before = translator.events.copy()
            converted = p if name == 'target' else translator.forward(p, g, module, profile)
            observed = translator.events - before
            for feature in ('boolean_hypothesis_aliases', 'negative_hypothesis_aliases',
                            'opaque_unused_witnesses', 'formula_hypotheses',
                            'global_numerical_rules', 'local_numerical_rules',
                            'recursor_equations', 'existential_eliminations',
                            'equality_eliminations', 'guarded_applications'):
                feature_cases[feature] += observed[feature] > 0
            converted_data = [g, a, converted]
            target.check(*converted_data)
            counts['target_forward_checks'] += 1
            payload = canonical(converted_data)
            native_sha = sha(payload.encode())
            detail['native_sha256'] = native_sha
            if native_sha not in native:
                native[native_sha] = {'sha256': native_sha, 'data': converted_data, 'origins': []}
            native[native_sha]['origins'].append(index)
            unique_judgments.add(sha(canonical([g, a]).encode()))
            stage = 'backward_to_demand'
            back = translator.backward(converted, g)
            demand.check(g, a, back)
            counts['demand_backward_checks'] += 1
            detail['demand_roundtrip_sha256'] = sha(canonical([g, a, back]).encode())
            stage = 'forward_again_from_demand'
            again = translator.forward(back, g, demand, profiles['demand'])
            target.check(g, a, again)
            counts['target_demand_roundtrip_checks'] += 1
            stage = 'backward_to_shared'
            back_shared = translator.backward(converted, g, True)
            shared.check([g, a, back_shared])
            counts['shared_backward_checks'] += 1
            detail['shared_roundtrip_sha256'] = sha(canonical([g, a, back_shared]).encode())
            stage = 'forward_again_from_shared'
            again_shared = translator.forward(back_shared, g, shared, profiles['shared'])
            target.check(g, a, again_shared)
            counts['target_shared_roundtrip_checks'] += 1
            cohort['complete_roundtrips'] += 1
            counts['complete_roundtrips'] += 1
            detail['roundtrips_complete'] = True
        except Exception as error:
            failures.append({'index': index, 'stage': stage, 'origin': record['origin'],
                             'exception': type(error).__name__, 'message': str(error)[:200]})
            detail['roundtrips_complete'] = False
        details.append(detail)
    results = {'snapshot_commit': manifest['snapshot_commit'], 'target_sha256': target_hash,
               'source_checker_sha256': source_hashes, 'counts': dict(counts),
               'cohorts': {key: dict(value) for key, value in sorted(cohorts.items())},
               'unique_source_certificates': len(unique_sources),
               'unique_native_certificates': len(native), 'unique_native_judgments': len(unique_judgments),
               'forward_cases_with_features': dict(feature_cases),
               'translation_node_observations_including_roundtrips': dict(translator.events),
               'failures': failures, 'seconds': round(time.perf_counter() - started, 4),
               'qualification': 'Finite executable regression evidence only. The interpretation and translation theorems require the accompanying mathematical proof.'}
    (ROOT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    (ROOT / 'record_results.jsonl').write_text(''.join(canonical(row) for row in details))
    (ROOT / 'native_corpus.jsonl').write_text(''.join(canonical(native[key]) for key in sorted(native)))
    print(json.dumps({'counts': dict(counts), 'unique_native_certificates': len(native),
                      'unique_native_judgments': len(unique_judgments),
                      'failures': failures[:10], 'seconds': results['seconds']}, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
