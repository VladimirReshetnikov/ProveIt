"""Measure all frozen complete-checker sources without executing them.

Path independent: python3 /absolute/path/to/comparison/measure.py
Optional comparison: --candidate /absolute/path/to/checker.py --require-strict
Writes metrics.json and primary_table.tex beside this script unless overridden.
Only the Python standard library is required. Compared sources are parsed,
never imported or executed; their recorded SHA-256 identities are checked.
"""
import argparse
import ast
import hashlib
import io
import json
from pathlib import Path
import sys
import tokenize

ROOT = Path(__file__).resolve().parent
FIELDS = ('source_tokens', 'normalized_tokens', 'ast_nodes', 'normalized_bytes', 'raw_bytes')
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
LABELS = {
    'ipra_compact_kernel_2026-11-06(2).zip': 'Compact kernel (2)',
    'ipra_compact_kernel_2026-11-06.zip': 'Compact kernel',
    'ipra_inferred_elimination_2026-11-06.zip': 'Inferred elimination',
    'ipra_scope_inference_2026-11-06.zip': 'Scope inference',
    'ipra_smaller_checker_2026-11-06.zip': 'Smaller checker',
    'ipra_structural_checker_2026-11-06.zip': 'Structural checker',
}


def measure(path):
    raw = path.read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source, filename=str(path))
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                doc = node.body.pop(0)
                spans.append(((doc.lineno, doc.col_offset), (doc.end_lineno, doc.end_col_offset)))
    normalized = ast.unparse(tree) + '\n'
    def tokens(text, omitted=()):
        return sum(t.type not in IGNORED and not any(
            start <= t.start and t.end <= end for start, end in omitted
        ) for t in tokenize.generate_tokens(io.StringIO(text).readline))
    return {
        'sha256': hashlib.sha256(raw).hexdigest(),
        'raw_bytes': len(raw), 'normalized_bytes': len(normalized.encode('utf-8')),
        'source_tokens': tokens(source, spans), 'normalized_tokens': tokens(normalized),
        'ast_nodes': sum(1 for _ in ast.walk(tree)),
    }


def tex_table(primary, envelope, candidate):
    lines = [r'\begin{tabular}{@{}lrrrrr@{}}', r'\toprule',
             r'Complete checker & Source tok. & Norm. tok. & AST & Norm. bytes & Raw bytes \\',
             r'\midrule']
    for row in sorted(primary, key=lambda r: r['archive']):
        lines.append(LABELS[row['archive']] + ' & '
                     + ' & '.join(f'{row[field]:,}' for field in FIELDS) + r' \\')
    lines += [r'\midrule', 'Finite lower envelope & '
              + ' & '.join(f'{envelope[field]:,}' for field in FIELDS) + r' \\']
    if candidate:
        lines.append(r'\textbf{New checker} & '
                     + ' & '.join(r'\textbf{' + f'{candidate[field]:,}' + '}' for field in FIELDS)
                     + r' \\')
    return '\n'.join([*lines, r'\bottomrule', r'\end{tabular}', ''])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate', type=Path)
    parser.add_argument('--output', type=Path, default=ROOT / 'metrics.json')
    parser.add_argument('--table', type=Path, default=ROOT / 'primary_table.tex')
    parser.add_argument('--require-strict', action='store_true')
    args = parser.parse_args()
    manifest_path = ROOT / 'manifest.json'
    manifest_raw = manifest_path.read_bytes()
    manifest = json.loads(manifest_raw)
    rows = []
    primary = []
    for source in manifest['sources']:
        row = measure(ROOT / source['file'])
        if row['sha256'] != source['sha256']:
            raise ValueError('Modified comparator: ' + source['file'])
        row['file'] = source['file']
        row['origins'] = source['origins']
        row['agrees_with_recorded_metrics'] = all(
            row[field] == source['recorded_metrics'][field] for field in FIELDS)
        rows.append(row)
        for origin in source['origins']:
            if origin['role'] == 'primary':
                primary.append({'archive': origin['archive'], 'member': origin['member'],
                                **{field: row[field] for field in (*FIELDS, 'sha256')}})
    if len(rows) != manifest['unique_source_count']:
        raise ValueError('Comparator count mismatch')
    if len(primary) != manifest['archive_count']:
        raise ValueError('Primary checker count mismatch')
    envelope = {field: min(row[field] for row in rows) for field in FIELDS}
    candidate = measure(args.candidate.resolve()) if args.candidate else None
    result = {
        'python_version': sys.version.split()[0], 'snapshot_commit': manifest['snapshot_commit'],
        'manifest_sha256': hashlib.sha256(manifest_raw).hexdigest(),
        'archive_count': manifest['archive_count'], 'unique_source_count': len(rows),
        'source_occurrence_count': sum(len(row['origins']) for row in rows),
        'definitions': {
            'scope': manifest['selection']['accounting_boundary'],
            'source_tokens': 'Significant original-source tokens, excluding comments, structural whitespace and docstrings.',
            'normalized_tokens': 'Significant tokens of ast.unparse after module/function/class docstring removal.',
            'ast_nodes': 'Every ast.walk node after the same docstring removal.',
            'normalized_bytes': 'UTF-8 bytes of ast.unparse of the stripped AST plus one newline.',
            'raw_bytes': 'All original UTF-8 source bytes, including documentation.',
        },
        'primary': primary, 'envelope': envelope,
        'minimizers': {field: [row['sha256'] for row in rows if row[field] == envelope[field]]
                       for field in FIELDS},
        'candidate': candidate,
        'candidate_at_or_below': {field: candidate[field] <= envelope[field] for field in FIELDS}
                               if candidate else None,
        'candidate_strictly_below': {field: candidate[field] < envelope[field] for field in FIELDS}
                                  if candidate else None,
        'recorded_metrics_all_agree': all(row['agrees_with_recorded_metrics'] for row in rows),
        'qualification': manifest['qualification'], 'sources': rows,
    }
    args.output.resolve().write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    args.table.resolve().write_text(tex_table(primary, envelope, candidate), encoding='utf-8')
    print(json.dumps({key: result[key] for key in (
        'python_version', 'unique_source_count', 'source_occurrence_count', 'envelope',
        'candidate', 'candidate_strictly_below', 'recorded_metrics_all_agree')}, indent=2))
    if args.require_strict and (not candidate or not all(result['candidate_strictly_below'].values())):
        raise SystemExit('Strict improvement on every recorded axis was not established.')


if __name__ == '__main__':
    main()
