"""Reproduce the pinned whole-program comparison; no comparator is executed."""
import hashlib
import json
from pathlib import Path
import sys

from metric_reference import FIELDS, measure

ROOT = Path(__file__).resolve().parent


def main():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    rows = {}
    for source in manifest['sources']:
        row = measure(ROOT / source['file'])
        if row['sha256'] != source['sha256']:
            raise ValueError('Changed comparator: ' + source['file'])
        rows[source['sha256']] = row
    competitors = [rows[sha] for sha in manifest['standalone']]
    groups = []
    for group in manifest['historical_groups']:
        row = {field: sum(rows[sha][field] for sha in group['members'])
               for field in FIELDS}
        groups.append({'label': group['label'], 'members': group['members'], **row})
        competitors.append(row)
    envelope = {field: min(row[field] for row in competitors) for field in FIELDS}
    candidate = measure(ROOT.parent / 'checker.py')
    strict = {field: candidate[field] < envelope[field] for field in FIELDS}
    primary = [{**item, **rows[item['sha256']]} for item in manifest['primary']]
    result = {
        'python': sys.version.split()[0], 'commit': manifest['snapshot_commit'],
        'manifest_sha256': hashlib.sha256((ROOT / 'manifest.json').read_bytes()).hexdigest(),
        'boundary': manifest['boundary'], 'inventory': manifest['inventory'],
        'primary': primary, 'envelope': envelope, 'candidate': candidate,
        'strictly_below': strict, 'historical_groups': groups, 'sources': rows,
        'qualification': 'A finite source corpus under specified whole-program metrics, not an unrestricted minimality theorem.',
    }
    (ROOT / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    labels = {
        'ipra_demand_kernel_2026-11-06 (1).zip': 'Demand (1)',
        'ipra_demand_kernel_2026-11-06.zip': 'Demand',
        'ipra_local_kernel_2026-11-06.zip': 'Local',
        'ipra_scoped_rules_2026-11-06.zip': 'Scoped rules',
        'ipra_shared_transition_2026-11-06.zip': 'Shared transition',
        'ipra_uniform_kernel_2026-11-06.zip': 'Uniform',
    }
    selected = ('ast_nodes', 'normalized_tokens', 'normalized_bytes', 'raw_bytes')
    lines = [r'\begin{tabular}{@{}lrrrr@{}}', r'\toprule',
             r'Complete checker & AST nodes & Norm. tokens & Norm. bytes & Raw bytes \\',
             r'\midrule']
    for row in primary:
        lines.append(labels[row['archive']] + ' & ' + ' & '.join(
            f'{row[field]:,}' for field in selected) + r' \\')
    lines += [r'\midrule', 'Observed envelope & ' + ' & '.join(
        f'{envelope[field]:,}' for field in selected) + r' \\',
        r'\textbf{Parameterized axiom} & ' + ' & '.join(
            r'\textbf{' + f'{candidate[field]:,}' + '}' for field in selected) + r' \\',
        r'\bottomrule', r'\end{tabular}', '']
    (ROOT / 'table.tex').write_text('\n'.join(lines))
    numbers = {
        'CandidateAST': candidate['ast_nodes'],
        'CandidateNormTokens': candidate['normalized_tokens'],
        'CandidateNormBytes': candidate['normalized_bytes'],
        'EnvelopeAST': envelope['ast_nodes'],
        'EnvelopeNormTokens': envelope['normalized_tokens'],
        'EnvelopeNormBytes': envelope['normalized_bytes'],
        'StandaloneCount': len(manifest['standalone']),
        'GroupCount': len(manifest['historical_groups']),
    }
    (ROOT / 'numbers.tex').write_text('\n'.join(
        '\\newcommand{\\' + name + '}{' + f'{value:,}' + '}'
        for name, value in numbers.items()) + '\n')
    print(json.dumps({key: result[key] for key in
                     ('python', 'inventory', 'envelope', 'candidate', 'strictly_below')}, indent=2))
    if not all(strict.values()):
        raise SystemExit('Strict improvement failed.')


if __name__ == '__main__':
    main()
