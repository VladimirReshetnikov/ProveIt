# Affine computation supply for iPRA

Research prepared for Vladimir Reshetnikov, November 10, 2026.

## Result and limit

The selected complete checker is **597 normalized bytes, 275 tokens,
316 AST nodes, and 356 bytes under ordinary gzip level 9**. It beats the
current literal byte minimum of 616 and the stricter matched-driver
minimum of 601. Distinct companion profiles reach 263 tokens and 296 AST
nodes, against matched minima of 264 and 297. No one program attains all
three new minima.

**The requested significant new axiomatic breakthrough has not been
established.** The mathematical basis is inherited, with full attribution.
The new contribution is a small complete-checker synthesis, its exact raw
instruction simulation, direct zero-witness support, and a current
reproducible comparison. The whole-domain bi-interpretability and
equiconsistency proofs are included. No absolute minimality, literature-wide
priority, or proof-assistant certification is claimed.

## Open first

- `ipra_affine_supply.pdf`: complete report, explicit native rules, new
  checking argument, comparison, and attributed mathematical appendices.
- `ipra_affine_supply.tex`: independently compilable expanded LaTeX source.
- `report.tex`, `theory/`, `reference/*.tex`: modular authoring sources.
- `AXIOMS.txt`: compact inventory of all native schemas and inference rules.
- `code/checker.py`: the entire selected 597-byte checker.
- `code/readable_checker.py`: separately executable explanatory expansion.
- `CLAIMS.json`: precise scope of the claims and limitations.

## Run a certificate

```sh
python3 code/checker.py < tests/fixtures/I0_arbitrary_seed.json
```

Success means exit status zero and exactly `ACCEPT` on standard output.
An exception rejects with nonzero exit status. The proof is a JSON stack:
the last element is its closed goal, and earlier four-field records are
consumed backwards. An unused prefix is inert. Never infer acceptance
solely from arbitrary diagnostic text while ignoring process status.

`code/checker_portable.py` uses an explicit list predicate and otherwise
the same affine interface. The token and AST profiles use a different
arity encoding and their own saved fixtures. Their generic iterable
opening has documented aliases and relies on the finite CPython recursion
limit to reject malformed nonempty strings; the selected byte checker
does not have that qualification. See `code/FORMAT.txt` and the report.

## Reproduce

```sh
python3 reproduce.py
python3 build.py --check-standalone
```

Python verification needs only the standard library. Counts were recorded
with CPython 3.12.14 and zlib 1.3.2; AST normalization and compressed streams
can differ on other runtimes. Building needs PDFLaTeX and the ordinary
packages listed in `report.tex`, and uses no shell escape. Rebuilding can
change PDF metadata and hence its manifest hash; verify the distributed
manifest before rebuilding or use a working copy.

The package freezes all 370 distinct historical Python sources for offline
measurement. Historical source files are parsed, not executed. Their
archive/member provenance and hashes are in `evidence/current_corpus_metrics.json`.
The source census is pinned to ProveIt commit
`fb2dbd2a33c6b132671a54b029d0bf3cd98c633d`, containing thirteen direct ZIPs.
All direct Git blob identities were verified. Source sizes attained in a
finite corpus are upper bounds on an unknown optimum, not proved lower bounds.

## Validation boundary

The supplied positive, negative, malformed-input, alias, and mutation tests
check the actual public programs in ordinary and optimized Python.
An independent arithmetic audit checked 422,253 parameter valuations from
15,639 generated computation hypotheses with no counterexample and no
evaluation-budget skip. Finite tests are not proofs of universal soundness,
nonstandard-model claims, or bi-interpretability. The latter rely on the
written arguments and attributed proofs, independently reviewed by other
assistant instances rather than a proof assistant or external human review.

The immutable tuple context in the loop profiles is essential: the included
mutation control changes it to a shared mutable list and then accepts the
false equation `0=1`. Other controls exercise major-premise verification
and the equation-only induction restriction.

## Attribution and contents

The basis and numerical/logical appendices come from the current ProveIt
collection. The new code composes affine scopes, uniform predecessor
packets, the arity calculus, and an immutable-context loop. Parent source
identities, exact differences, and source licenses are retained.
The upstream MIT No Attribution license is in `reference/PROVEIT_LICENSE.txt`.

`source_corpus/` is static reference material. `tests/` contains untrusted
producers and validators. `evidence/` contains measurements, review notes,
test receipts, and compilation records. None is imported by a measured
checker. `MANIFEST.sha256` covers every packaged payload except itself.

No change has been made to the GitHub repository.
