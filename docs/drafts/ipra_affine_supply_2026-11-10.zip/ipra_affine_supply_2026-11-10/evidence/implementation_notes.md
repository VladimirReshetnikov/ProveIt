# Composing the current checker reductions

## Exact result and limits

These are new complete implementations of the **inherited** initialized
scalar-iterator Eq/Q/D presentation. They do not supply a new mathematical
foundation, an absolute minimum, or the requested significant breakthrough.
They combine previously separate reductions. All parser, scope, rule and
verdict source is counted. The standard Python/JSON runtime is the same
shared environment as the compared corpus.

| Source | Tokens | AST | Normalized bytes | Gzip-9 |
|---|---:|---:|---:|---:|
| checker_bytes.py | 275 | 316 | 597 | 356 |
| checker_tokens.py | 263 | 301 | 691 | 371 |
| checker_ast.py | 266 | 296 | 689 | 369 |
| checker_portable.py | 275 | 314 | 605 | 362 |

The new family envelope is 263 / 296 / 597; **no single source achieves this
triple**. All files were stored in their `ast.unparse` normalized spelling,
so raw and normalized sizes agree. Gzip uses level 9 and mtime 0 and is
informational. Measurements use Python 3.12.14 in this run.

The token and AST profiles inherit exception-based traversal. Successful
finite runs have the inherited sorted semantics, but malformed nonempty
strings rely on Python's finite recursion limit to reject. An ideal Python
with an unbounded stack could diverge there. The byte and portable profiles
recursively traverse only actual finite JSON arrays. The byte profile uses
`a * 0 == []`, which is equivalent to a list test on successful JSON values;
other unsupported types may fail earlier. The portable profile spells the
predicate explicitly. No claim of comparable total-input behavior is made
for the generic traversal profiles.

## Arithmetic branch: an exact simulation

The new affine byte profile uses the existing affine opener and the
existing uniform-predecessor packet convention. Given a computation packet

    [null, p, a, h]

it constructs

    [[p and [p], a, h], open(h, [p,a,h], 1) if p else a].

This is exactly the same raw generated hypothesis as the old affine packet

    [[], [p,a,h], p, 0].

The old empty-array tag and new null tag both make
`m or len(goal) % 2 == m` false, so the common tail opens with numerical zero
in both programs. This gives a direct simulation for arbitrary raw JSON
inputs whenever the calls succeed, not only standard numerals. Hence no
new informal numerical evaluator is being trusted.

The generated-assumption rule is sound because its zero instance is a
computation theorem. Substitute zero for the freshly allocated parameter
in the premise derivation, then cut the computation theorem. Actual old
rigid parameters remain unchanged. A computation assumption is not claimed
true for every value of the fresh parameter.

The null tag separates computation from paired introduction, including a
literal zero witness. The old affine checker required a truthy witness.
This is conservatively repaired by replacing zero with
`I(0,0;v.0)` and using its computation equality to zero. Under an old
premise assumption `B(I(0,0;v.0),z)`, equality transport reconstructs
`B(0,z)`, uses the new premise proof, and transports its conclusion back.
Case and literal-equation-progress modes are preserved. This is the
existing boxed-zero argument, composed with the affine representation;
it is not a new arithmetic theorem.

## Loop profiles

The token profile keeps the existing arity calculus and flat arithmetic
packets. It replaces tail recursion by a while loop with a tuple context.
The AST profile additionally uses the uniform predecessor packet above.
Its scalar opener and walrus initialization are inherited representations.

For a fixed interpreter without resource exhaustion, one while iteration
is precisely one previous recursive continuation. Major subproofs still
call the verifier recursively. The global fresh floor advances through
the same operations. Tuples are immutable: a major subproof cannot append
local assumptions to its caller's context. The loop and recursive versions
therefore have the same accepted finite canonical proof relation.

The tuple requirement has a concrete adversarial test. A case proof of
`D_xy(0=1)` is valid, since its conditional antecedent is itself `0=1`.
If loop contexts are mutable lists, this discharged false assumption leaks
back into the caller and proves `0=1`. The correct tuple version rejects
the supplied three-element false certificate. This is recorded in
`mutation_results.json`.

## Verification

`verify_family.py` regenerated named proof examples from the pinned source
producers and re-encoded them into the selected formats. All 332 complete
CLI expectations passed, in ordinary Python and `-O`. These include a
nonvacuous literal-zero witness, genuine contextual induction, nested
closures and state binding, malformed public input, future parameters,
forbidden compound progress and incorrect arithmetic endpoints.

One inherited negative packet becomes positive after canonical affine
translation: erasing binary numerical-zero aliases turns both its goal and
its packet into the valid I0 equation. The test explicitly renames this case
and states the reason; the original untranslated mismatch is separately
required to reject.

`verify_saved.py` reruns the saved fixtures and exact source/gzip
measurements without requiring the original archive tree. Its 268 fixture
process runs plus 64 malformed-input runs reproduce the same 332-run suite. `mutation_controls.py` adds 12 process runs,
all passing, for three unsafe changes: unverified major, compound induction,
and mutable-context leakage. The mutants admit false equations.
The separate alias suite adds 56 passing normal/optimized process checks;
the readable explanation passes its own 70 fixture process checks.

Finite tests are implementation checks. They are not a proof-assistant
formalization of soundness, completeness, or bi-interpretability. The
mathematical bridge is inherited and must remain fully attributed and
included in the final report.

## Attribution

`provenance.json` pins every used parent source to ProveIt commit
`fb2dbd2a33c6b132671a54b029d0bf3cd98c633d`, with archive/member path and
SHA-256. `reference/` contains those exact parent files; the three `.diff`
files show changes from the most direct parents. The affine arity,
arity calculus, uniform predecessor, and research-loop ideas all predate
this composition. The newly observed source-size combination is the
incremental contribution.
