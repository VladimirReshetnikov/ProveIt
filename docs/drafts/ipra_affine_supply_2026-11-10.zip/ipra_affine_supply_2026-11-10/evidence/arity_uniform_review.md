# Independent review: arity encoding with uniform predecessor packets

## Scope and status

This is a conditional mathematical audit of the synthesis described below, not a proof-assistant formalization. It checks the interaction between the arity-calculus decoder and uniform-predecessor computation packets. It does not re-prove the inherited scalar-iteration predecessor construction or its whole-domain iPRA bridge. An exact final implementation still needs comparison with these conditions.

## Pinned comparison

The thirteen direct draft ZIPs at ProveIt commit `fb2dbd2a33c6b132671a54b029d0bf3cd98c633d` contain twenty-eight distinct ZIP byte strings recursively, 1,383 Python member occurrences after ZIP-content deduplication, and 370 distinct Python source contents. The scan parses but does not execute historical Python sources. Thirty-seven source contents meet at least one preliminary boundary (269 tokens, 305 AST nodes, 628 normalized bytes). Eight are complete proof checkers; the remaining twenty-nine are build, measurement, retrieval, reproduction, or certificate-support utilities.

The literal-source complete-checker coordinate minima are 268 significant normalized Python tokens, 300 AST nodes, and 616 normalized UTF-8 bytes. They are attained by different programs. All live in `ipra_uniform_predecessor_2026-11-10.zip`:

- `ancillary/checker_ast.py`: 268 tokens, 300 AST nodes, 649 normalized bytes, 648 raw bytes, gzip-9 raw size 367. It uses generic try-iteration, admits noncanonical iterable aliases, and relies on finite Python recursion limits to reject some malformed strings.
- `ancillary/checker_bytes.py`: 269 tokens, 311 AST nodes, 616 normalized/raw bytes, gzip-9 size 366. Its `a*0 == []` predicate recognizes exactly standard-JSON lists on successful dispatch; it does not rely on malformed-string recursion.

The new driver convention in that package permits uncaught exceptions as rejection, retaining a successful `ACCEPT` line. For a stricter fair control, apply this same driver change to every new complete checker. The resulting *transformed*, rather than literally archived, comparison envelope is 264 tokens / 297 AST / 601 bytes: arity-calculus token profile, research loop profile, and affine-arity byte profile respectively. Any stronger claim should identify which envelope is being beaten.

These are attained upper bounds on an unknown optimum. They are not mathematical lower bounds.

## Intended synthesis

The numerical language is the inherited fixed-description scalar iterator:

`t ::= x | 0 | S(t) | I(n,a;v.h)`.

The nonlogical computations are `I(0,a;v.h)=a` and `I(Sn,a;v.h)=h[I(n,a;v.h)/v]`. The native formulas are equations, paired formulas `D_xy B`, and administrative closures `Q_y B`, with meanings

`Q_y B = B(0) -> forall y B(y)` and `D_xy B = exists x Q_y B`.

The arity encoding represents an equation by `[s,t]`, D by `[B]`, and canonical Q by `[B,B,B]`. Numerical zero is `[]` or coordinate zero; successor is unary and iteration ternary. At meaningful formula positions surplus arrays of arity at least four denote the fixed truth `0=0`; at numerical positions they denote zero. Binary numerical nodes denote zero. Ternary formula annotations in positions zero and one are ignored. Every ignored child may still be traversed and rejected, which does not threaten soundness.

The opener increment is `5-len(a)`. Formula roots under p protected numerical slots have depth `2p`; numerical roots have depth `3+2p`. Coordinates zero through two at numerical root denote zero. Each protected slot has two coordinate aliases. D adds two slots, Q adds one, equality changes from formula depth to numerical depth, successor adds two dummy-zero slots, and iteration adds one slot: dummy zero in its counter and initializer, actual state in its update.

## Conditions that must remain exact

1. No-image checking of a used numerical image must start at depth 3, not inherited depth 1.
2. Step expansion must call `i(t,[s,u,t],3)`, with the old parameter floor still in force.
3. Paired introduction must enforce unary goal shape. `i(*a,t,2)` does so through positional arity; replacing it by a permissive indexing operation can admit introduction at the wrong connective.
4. Equality transport must require exact endpoint matching. Closure specialization must require the old endpoint to be zero.
5. Progress introduction must remain restricted to even meaningful matrix roots. Equations are the only nonconstant even constructor; D and Q are odd. Surplus even roots denote truth, whose induction is harmless.
6. The original goal and all used witnesses must be checked before admitting the next eigenparameter.
7. A proved major must leave its caller's retained context unchanged. Shared mutable context updates can leak local assumptions from a side proof.
8. Arithmetic uses a null mode and direct predecessor s. The constructed left counter is `s and [s]`; its right side is `i(t,[s,u,t],3) if s else u`.
9. The common arithmetic continuation must zero-open its supplied equation. For the inherited guard `k if m or len(a)%2==m else 0`, null m always chooses zero.

## Arithmetic-supply argument

For a successful base packet, the raw predecessor is falsy. Under the exact-list profile its successful numerical meanings are zero (empty array or numerical zero aliases). Thus the supplied equation is an I0 instance after zero completion.

For a successful step packet the left counter is an internally constructed successor. If the update has a semantically relevant state occurrence, opening it calls the no-image numerical check of the complete source `[s,u,t]` at root depth 3 and at the old floor. In that source the update has one protected state slot, namely coordinates 3 and 4 at its immediate numerical depth. An additional escaping coordinate in the update is encountered again by the no-image source check and rejects. Likewise the counter and initializer must be closed relative to their one dummy-zero slot.

The constructed successor inserts two additional dummy-zero slots. A successfully closed predecessor cannot refer to those newly added outer slots. Its existing internal bound coordinates retain the same interpretation, and its free numerical parameters are rigid negative names. Consequently the predecessor used in the left successor and in the right recursive image denotes the same term. The supplied equation is IS.

If the update has no semantically relevant state occurrence, its value is independent of the preceding recursive state. Source validation is unnecessary for that value. The raw left predecessor and initializer still receive their final sorted checks, while the update's value is the same in its left occurrence and on the right. IS therefore holds again. An irrelevant annotation may happen to trigger additional checking; that can only reject an alias.

The current uniform null-mode completion uses zero as the opening image. New names admitted solely by the subsequent floor decrement either do not occur in a state-dependent recursive source already checked at the old floor, or appear only as arbitrary passive parameters of a state-independent IS instance. Thus the equation is a theorem uniformly in its admitted parameters. One need not transfer the older arity paper's weaker known-zero-instance supply rule as an additional principle.

## Logical argument

Hypothesis closure compares checked raw syntax with a retained context member. Raw equality of checked representations implies equality of their decoded formulas; the checker does not infer arithmetic equality merely because two terms have the same standard numerical value.

For an equality major `[s,u]`, matching the target with the template opened at u and replacing it by that template opened at s is ordinary equality transport. For a canonical Q major `[t,t,t]`, requiring the old image to be zero gives exactly Q elimination. The zero guard must not be removed.

Exporting `m*3` from a D major `[B]` produces `[B,B,B]`, the required fresh-witness closure. Exporting it from an equation, a closure, or a larger nonempty formula array produces arity at least six and hence truth. Therefore nonmatching endpoint attempts merely adjoin a theorem. Accepted scalar formula padding is also truth; its scalar export is truth.

For a unary D goal, `i(*a,t,2)` fills only its existential witness slot, leaving the universal slot exposed. The final successor opening produces B(w,Sz). The new local assumption is B(w,0) for case mode and B(w,z) for equation-progress mode. Its designated z is absent from the earlier context, conclusion, and used witness by the scope check. D and Q matrices have odd outer arity, so they always take case mode. Constant surplus aliases cannot introduce stronger induction.

## Canonical completeness

Encode a finite proof in the inherited native calculus using fresh negative integers for its eigenparameters. Hypothesis, equality transport, Q specialization, D introduction, and D elimination compile directly. Null-mode arithmetic admits literal-zero D witnesses independently of the witness field's truthiness.

A step packet cannot directly select successor mode with a falsy predecessor spelling. Box that predecessor as B(p)=I(0,p;v.0); I0 proves B(p)=p and its code is nonempty. Use IS at B(p) and equality transport through the template `I(Sw,a;v.h)=h[I(w,a;v.h)/v]`. This recovers every missing step equation, including p=0. The box is a finite proof transformation, not a claim that semantic aliases are interchangeable as raw certificates.

The resulting equivalence is with the complete inherited native consequence relation. Its proved bi-interpretation with ordinary iPRA then transfers. In the ordinary comparator both coverage `x=0 or exists y x=S(y)` and separation `(0=S0)->false` must be explicit; positive equations alone have a singleton ordinary model. The source-side and target-side numerical composites use the entire domain and actual equality, not only standard numerals.

## Local scope alternative and repeated checks

The local-scopes draft already implements `c(a,g,k=0)` with its opener as a lexical closure, and passes k into recursive calls. The invariant is k=-len(g). A side proof cannot change its caller's floor; private eigenparameters can be reused in disjoint branches by alpha-renaming. This is sound and complete but is not a new mathematical reduction here.

The final goal reopening cannot simply be removed: D introduction leaves B(w,y) with a free universal slot and needs to change it to B(w,Sz). The initial no-image check at checker entry also protects scope. Omitting it requires checking the public root and every raw major before they enter a recursive proof, otherwise a future-label conclusion can be accepted after that label is allocated.

## Important raw-input qualifications

At meaningful positions a closed no-image check rejects unsupported values or unallocated relevant names. Python-equal numerical aliases must receive equal decoded meanings. Fractional negative values can be treated as additional rigid fresh names in the interval admitted by a decrement; they must not silently be identified with its designated integer eigenparameter. Nonfinite values cannot survive meaningful closed numerical checking, though they may be template holes or ignored annotations.

The generic try-iteration profile requires a larger decoder than the exact-list profile. It traverses dictionary keys, ignores dictionary values, and maps some empty iterable aliases to empty or unary arrays. Nonempty strings may rely on the interpreter recursion limit to reject. A proof stated only for raw arrays and integers does not by itself establish full raw-JSON soundness of that profile. Prefer an explicit-list profile when the measured target permits it.

Finally, semantic opening is conditional on successful calls at meaningful sorted roots. It is not raw global idempotence: high-arity ignored nodes can create negative child depths and alter or reject annotations under reopening. Since their entire meaning is constant, this is compatible with the required semantic invariant.
