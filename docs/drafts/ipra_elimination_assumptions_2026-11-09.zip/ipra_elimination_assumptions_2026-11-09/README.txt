AN iPRA AXIOMATIZATION WITH ASSUMPTIONS USED ONLY FOR ELIMINATION
Prepared for Vladimir Reshetnikov, 9 November 2026 (Pacific date)
================================================================

EXACT RESULT
------------
The general hypothesis-conclusion rule is removed. A retained assumption
can be used directly only as an elimination major. Nevertheless every
Eq/D object assumption A can be recovered by an explicit structural
identity expansion with 4+3d(A) primitive rule nodes.

The complete native specification has numerical terms 0,S,I; two scalar
iterator computation schemas; object formulas s=t and D(x,y).B; internal
closure clauses Q(y).B; explicit major availability; and paired
introduction, closure specialization, paired elimination and transport.
Only literal equations admit the progress introduction choice.

The report derives the ordinary intuitionistic logical operations,
equation induction and numerical cases, and gives full-domain
bi-interpretability and equiconsistency with first-order iPRA. Actual
equality and both internal interpretation composites are retained.
The inherited arithmetic bridge is included and explicitly attributed.

COMPLETE CHECKER COMPARISON
--------------------------
                               Tokens    AST nodes    Normalized bytes
  Existing token profile          292          336                 865
  Existing structure profile      296          330                 882
  Existing byte profile           298          349                 762
  New kernel_tokens.py            291          339                 846
  New kernel_structure.py          298          329                 855
  New kernel_bytes.py              300          351                 745

  Existing separate minima: 292 / 330 / 762
  New separate minima:      291 / 329 / 745

Every designated coordinate improves strictly; the byte saving is
17 bytes (2.23%). Different programs attain the three minima. No single
program is below all three old coordinate minima. The programs measure
THIS new calculus, including parsing calls, scope, substitution, rule
dispatch, freshness, context access and the public verdict driver.
Only Python and its standard JSON parser are shared ambient assumptions.

This is a strict but modest improvement. Absolute simplestness and the
requested significant global breakthrough have not been established.
The corpus minima are measured upper bounds, not universal lower bounds.
Identity expansion is a known proof-theoretic method; the result here is
its specific application to this native iPRA interface and the measured
implementation. There is no claim of literature-wide priority.

START HERE
----------
ipra_elimination_assumptions_2026-11-09.pdf
    Complete compiled report with mathematical and implementation proofs.
ipra_elimination_assumptions_2026-11-09.tex
    Entire standalone editable source. It was compiled in an isolated
    directory without the rest of this package.
report.tex / proofs/
    Modular source and attributed arithmetic appendices.
code/kernel_bytes.py
    Primary 745-byte complete checker, printed in the report.
code/kernel_tokens.py / code/kernel_structure.py
    Independent complete profiles for the other two source measures.
code/FORMAT.txt
    Exact numerical/object syntax, internal clauses and JSON protocol.
code/compile_focused.py
    Untrusted compiler from inherited proofs; every output is rechecked.
code/source_cases.json / code/certificates.json
    Source proofs and 157 positive + 25 negative focused packets.
code/examples/
    Standalone computation, induction, retained-base and rejection inputs.
reference/
    Unchanged comparison programs and source normalizer.
code/reference/choice_checker.py
    Frozen reference kernel used to replay the translated proofs.
evidence/
    Repository identities, source measures, independent audits and receipts.
MANIFEST.json
    SHA-256 inventory of the distributed payload.

REPRODUCE
---------
From the extracted package directory:

    python3 verify.py

This checks the distributed manifest before regenerating evidence, then
remeasures all six full programs and reproduces the certificate/compiler,
negative-boundary, mutation and public CLI checks. The checkers need only
the Python standard library. Python 3.10+ is required for the structural
profile; exact reported normalization used CPython 3.12.14.

For a single positive or negative invocation:

    python3 code/kernel_bytes.py < code/examples/zero_computation.json
    python3 code/kernel_bytes.py < code/examples/canonical_false.json

The first prints ACCEPT and exits zero; the second prints REJECT and
exits nonzero. A traceback on stderr is allowed by the frozen interface.
There are no Python assert statements in the measured kernels, and
ordinary and optimized Python executions were checked.

    python3 build.py

This regenerates the standalone TeX source and PDF with an installed
pdfLaTeX distribution, shell escape disabled. It performs three passes
and records unresolved references and layout warnings. No network is
needed. Rebuilt PDF bytes may differ with the TeX version or PDF dates.
Verify the distributed manifest BEFORE rebuilding or intentionally
changing any file. Run python3 package.py to create a new manifest/ZIP
for an intentionally modified package.

EVIDENCE
--------
The final primary validation passed:
  * 157 deterministic positive compiler regenerations;
  * 546 in-process checks (182 cases across three profiles);
  * 157 independent replays through the frozen old kernel;
  * 628 mutated packets across all three profiles (1,884 executions);
  * 105 accepted mutants reserialized and checked by the old kernel;
  * 1,092 actual public CLI checks, ordinary and optimized Python.

A separate review replayed the 147 inherited translated positives on all
three final profiles, ordinary and optimized: 882 additional CLI runs.
These overlap with the primary positive suite; they are not 882 additional
distinct mathematical theorems. All recorded runs passed.

The universal proofs are written mathematical arguments, supported by
independent assistant reviews. They are not Lean/Rocq/Isabelle
formalizations or external human peer review. The compiler is untrusted.
Its source, tests and the report are not imported by the measured kernels.
Finite-resource Python can reject sufficiently deep or large valid proofs.

SOURCE SNAPSHOT
---------------
VladimirReshetnikov/ProveIt, commit
70feebabe24445912ae5eb336a6d7e9ba40a882b, docs/drafts.
Eleven direct ZIP files, all verified by Git blob identity.

https://github.com/VladimirReshetnikov/ProveIt/tree/70feebabe24445912ae5eb336a6d7e9ba40a882b/docs/drafts

No change to the source repository was made. The inherited material is
attributed in the report and evidence/inherited_sources.json. Its MIT No
Attribution license is retained in LICENSE.txt.
