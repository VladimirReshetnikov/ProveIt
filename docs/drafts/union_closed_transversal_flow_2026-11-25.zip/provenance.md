# Prior-work audit and claim boundary

Date: 2026-11-25.

## ProveIt repository

Accessed the `main` branch through the GitHub connector:
https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts

The directory listing showed 36 ZIP archives and `.gitkeep`. The following
nine archives were fetched as base64 and selected README/TeX abstract or
introductory excerpts decompressed and inspected:

- `union_closed_uniform_threshold_2026-11-25.zip`: closest antecedent; a
  complete uniform layer forcing threshold, asymptotic, and weighted-block
  extension. The present paper instead considers all multipartite transversals
  and a directed Boolean-cube flow relaxation. The full weighted-block
  extension was not inspected, so overlap cannot be ruled out.
- `union_closed_transversal_bounds.zip`: local hitting sets for partial
  intersections; not the complete multipartite transversal core used here.
- `union_closed_signature_interfaces_2026-11-25.zip`: marked generator
  signatures, interface rank and projection counts.
- `union_closed_rank_transport_2026-11-25.zip`: principal-filter entropy
  bounds and integer majorization.
- `union_closed_joint_laws_2026-11-25.zip`: conditional switching and
  fluctuation estimates in generator incidence models.
- `union_closed_dense_core_2026-11-25.zip`: marked points appearing in all
  but a bounded number of generators.
- `union_closed_antichain_shadows_2026-11-25.zip`: antichain shadows and
  entropy envelopes.
- `union_closed_redundant_core_2026-11-25.zip`: distinguished generator
  indices with uniform incidence types and redundancy.
- `union_closed_exact_obstruction_theorems_2026-11-25.zip`: robust marked
  pairs and obstruction size in missing-generator types.

This is a selective abstract-level review, not a complete audit of all
archives or every theorem inside the nine. No prior draft result is used as
an unproved premise. No GitHub changes were made.

## Public literature

- Poonen (1992), Union-closed families, JCTA 59, 253–268:
  https://doi.org/10.1016/0097-3165(92)90068-6
  Local forcing/FC framework; not claimed as new here.
- Bruhn and Schaudt (2015), The journey of the union-closed sets conjecture:
  https://arxiv.org/abs/1309.3297
- Pulaj and Wood (2025), Local Configurations in Union-Closed Families:
  https://doi.org/10.1080/10586458.2024.2410964
  Local configurations, finite FC results and extensions of Poonen's theorem.
- Reimer (2003), An Average Set Size Theorem:
  https://doi.org/10.1017/S0963548302005230
  Directed cube and upward-family edge-boundary identity.
- Kalai (2018), Frankl's Conjecture for Large Families: Ilan Karpas' Proof:
  https://gilkalai.wordpress.com/2018/03/09/frankls-conjecture-for-large-families-ilan-karpas-proof/
  Prior use of the at-most-one immediate predecessor condition and directional
  edge boundaries in union-closed-family analysis.
- Jiang (2026), Entropy bounds and global couplings for union-closed families:
  https://arxiv.org/abs/2609.08291
  Reports a universal computer-assisted bound of 0.38288525. The new paper
  makes no universal numerical improvement claim.

Searches included combinations of “Frankl”, “union-closed”, “complete
multipartite”, “transversals”, “FC families”, “edge boundary”, “Boolean cube”,
and “max-flow”. Relevant results included general FC theory and cube-boundary
methods. No matching threshold formulas or block-flow solution were located
in the sources and excerpts reviewed. This does not certify historical
priority. The candidate original part is the particular directed cut test,
its optimal block flow, one-step threshold bracket and quantitative/equality
consequences. Classical counting observations and max-flow/min-cut are
explicitly attributed or identified as standard.

## Verification limits

The universal mathematical claims are proved in `paper.tex`. Exact finite
verification is recorded in `verification.txt`; it is not a formal proof or
independent referee report. The unrestricted conjecture is open in this
work. For m>=2, no conclusion is asserted at k=K(m)+1. The flow criterion is
necessary and sufficient for the specified relaxation, not for local forcing.
The negative constructions concern rarity only on the marked points, not
rarity throughout the enlarged universe.
