# Complete multipartite transversals and Frankl's conjecture

Research note, 25 November 2026. Start with `paper.pdf`.

## Mathematical result

If a finite union-closed family contains every transversal of k disjoint m-point
blocks, write q=2^m-1. The mean frequency on the marked ground set is at least
one half when `(q+1)^k <= q^k + k*m*q^(k-1)`. If the inequality fails at k-1,
there is an explicit union-closed extension in which all marked points are rare.
The exact local forcing threshold is thus bracketed within one integer, with a
single unresolved boundary for each m>=2. The classical doubleton theorem
settles the boundary for m=1. This is not a counterexample to or a resolution of
the unrestricted conjecture. The optimal cube-flow constant, strictness and
stability estimate, asymptotics, and unequal-block network reduction are proved
in the paper.

## Files

- `paper.tex`: complete LaTeX source and proofs.
- `paper.pdf`: compiled manuscript (7 pages).
- `verify.py`: dependency-free exact rational/integer checks (Python 3.10+).
- `verification.txt`: actual verifier output.
- `thresholds.csv`: exact threshold brackets for block sizes 1 through 12.
- `witnesses.json`: exact sizes, marked frequencies and parameters of negative
  examples; also a full bitmask list of the small 39-member example.
- `provenance.md`: literature and repository audit scope and limitations.
- `Makefile`, `SHA256SUMS`: reproduction and integrity checks.

## Reproduce

```sh
sha256sum -c SHA256SUMS
python3 verify.py
make pdf
```

The verifier generates the CSV and JSON. The tests complement rather than
replace the general proofs. Large witness closure is proved symbolically in
the manuscript; for the materialized 153,671-set witness the program checks
all marked frequencies and 20,000 seeded random unions, not every pair.
No proof-assistant or independent human verification is claimed. PDF metadata
may change after rebuilding. No repository files were changed.
