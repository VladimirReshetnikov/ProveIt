#!/usr/bin/env python3
"""Exact finite audit; the general arguments are in paper.tex. Python >=3.10."""
from fractions import Fraction as Q
from math import comb, prod
from itertools import product
from collections import deque
import csv, json, random
from pathlib import Path

def check(condition, context):
    if not condition:
        raise AssertionError(context)

def good(m,k):
    q=2**m-1
    return (q+1)**k <= q**k+k*m*q**(k-1)

def threshold(m):
    lo,hi=1,2
    while good(m,hi): lo,hi=hi,2*hi
    while hi-lo>1:
        t=(lo+hi)//2
        if good(m,t): lo=t
        else: hi=t
    return lo

def blocks(sizes):
    out=[]; n=0
    for m in sizes: out.append(((1<<m)-1)<<n); n+=m
    return n,out

def high(s,B): return all(s&b for b in B)
def weight(G,n): return sum(2*a.bit_count()-n for a in G)
def uc(G): return all(a|b in G for a in G for b in G)
def compatible(G,C): return uc(G) and all(a|b in G for a in G for b in C)
def upclosure(G,n): return {b for b in range(1<<n) if any(a&b==a for a in G)}
def edges(n):
    for a in range(1<<n):
        for i in range(n):
            if not a>>i&1: yield a,a|(1<<i),i

def explicit_flow(m,k):
    n,B=blocks([m]*k);q=2**m-1
    R={k:Q(1,k)}
    for z in range(k-1,0,-1): R[z]=(1+(k-z)*R[z+1]/q)/z
    c=Q((q+1)**k-q**k,k*m*q**(k-1))
    check(R[1]/m==c,(m,k,'closed form'))
    check(all(R[z]>=R[z+1] for z in range(1,k)),(m,k,'monotonic'))
    div=[Q(0)]*(1<<n);maxedge=Q(0)
    rank_flow=[Q(sum(comb(m,t) for t in range(l+1,m+1)),q*comb(m,l)*(m-l)) for l in range(m)]
    count=0
    for a,b,i in edges(n):
        j=i//m;l=(a&B[j]).bit_count()
        z=1+sum(not (a&B[h]) for h in range(k) if h!=j)
        f=R[z]*rank_flow[l]
        div[a]+=f;div[b]-=f;maxedge=max(maxedge,f);count+=1
    for a,d in enumerate(div):
        check(d==1 if not high(a,B) else d<=0,(m,k,a,d))
    check(maxedge==c,(m,k,'optimal'))
    return count

class Network:
    def __init__(self,N): self.g=[{} for _ in range(N)]
    def add(self,a,b,c):
        self.g[a][b]=self.g[a].get(b,0)+c
        self.g[b].setdefault(a,0)
    def maxflow(self,s,t):
        ans=0
        while True:
            parent={s:None};queue=deque([s])
            while queue and t not in parent:
                a=queue.popleft()
                for b,c in self.g[a].items():
                    if c and b not in parent:
                        parent[b]=a;queue.append(b)
            if t not in parent: return ans
            v=t;path=[]
            while v!=s:
                u=parent[v];path.append((u,v));v=u
            d=min(self.g[u][v] for u,v in path)
            for u,v in path: self.g[u][v]-=d;self.g[v][u]+=d
            ans+=d

def cube_test(sizes):
    n,B=blocks(sizes);N=1<<n;s=N;t=N+1
    g=Network(N+2);L={a for a in range(N) if not high(a,B)}
    for a in range(N):
        if a in L:g.add(s,a,1)
        else:g.add(a,t,len(L)+1)
    for a,b,i in edges(n):g.add(a,b,1)
    return g.maxflow(s,t)==len(L)

def macro_test(sizes):
    k=len(sizes);N=1<<k;s=N;g=Network(N+1);q=[2**m-1 for m in sizes];total=0
    for Z in range(1,N):
        qZ=prod(q[i] for i in range(k) if not Z>>i&1)
        g.add(s,Z,qZ);total+=qZ
        for j,m in enumerate(sizes):
            if Z>>j&1:g.add(Z,Z^(1<<j),m*qZ)
    return g.maxflow(s,0)==total

def all_compatible(sizes):
    n,B=blocks(sizes);N=1<<n;C={a for a in range(N) if high(a,B)};ee=list(edges(n));cnt=0
    f=macro_test(sizes)
    for mask in range(1<<N):
        G={a for a in range(N) if mask>>a&1}
        if not compatible(G,C):continue
        H=upclosure(G,n)-G;down=sum(a in G and b not in G for a,b,_ in ee)
        out=sum(a in H and b not in H for a,b,_ in ee)
        check(H.isdisjoint(C),('holes',sizes,G))
        check(down<=len(H),('down',sizes,G))
        W=weight(G,n);check(W>=out-len(H),('boundary',sizes,G))
        if f:check(W>=0,('forcing',sizes,G))
        if len(set(sizes))==1:
            m=sizes[0];k=len(sizes);q=2**m-1
            c=Q((q+1)**k-q**k,k*m*q**(k-1))
            check(W>=(1/c-1)*len(H),('quantitative',sizes,G))
            if c<1 and W==0:check(not G or len(G)==N,('strictness',sizes,G))
        cnt+=1
    return cnt

def witness(m,k,materialize=False):
    n,B=blocks([m]*k);q=2**m-1
    D=2**(m-1)*((q+1)**(k-1)-q**(k-1)-(k-1)*m*q**(k-2))
    check(D>0,(m,k,'bad condition'))
    r=1+q**(k-1)//D;N=n*r
    Csize=q**k;Gsize=2**(n-1)+2**(m-1)*q**(k-1)
    Fsize=Csize+N*Gsize+2**n
    W=n*q**(k-1)-N*D
    check(W<0 and W%n==0,(m,k,'weight'))
    f=Q(Fsize+W//n,2);check(f.denominator==1 and 2*f<Fsize,(m,k,'frequency'))
    out={'m':m,'k':k,'n_marked':n,'copies_per_mark':r,'n_tags':N,'core_size':Csize,'fiber_size':Gsize,'family_size':Fsize,'frequency_each_mark':int(f),'signed_weight':W}
    if materialize:
        C={a for a in range(1<<n) if high(a,B)}
        G=[C|{a for a in range(1<<n) if not a>>x&1} for x in range(n)]
        check(len(C)==Csize and weight(C,n)==n*q**(k-1),'core')
        for gx in G:check(len(gx)==Gsize and weight(gx,n)==-D,'fiber formula')
        E=((1<<N)-1)<<n
        F=set(C)|{a|E for a in range(1<<n)}
        for x,gx in enumerate(G):
            for j in range(r):
                tag=E^(1<<(n+x*r+j));F.update(a|tag for a in gx)
        check(len(F)==Fsize,'actual count')
        check(all(sum(bool(a>>x&1) for a in F)==f for x in range(n)),'actual frequencies')
        if len(F)<1000:check(uc(F),'full closure')
        else:
            # Pairwise closure is proved symbolically by the tag rule; finite sample audit.
            rng=random.Random(27);Flist=sorted(F)
            check(all(rng.choice(Flist)|rng.choice(Flist) in F for _ in range(20000)),'sample closure')
        if n==3:out['set_masks']=sorted(F)
    return out

def main():
    ks=[threshold(m) for m in range(1,13)]
    check(ks[:8]==[1,5,15,36,84,186,400,847],'threshold table')
    for m,k in enumerate(ks,1):check(good(m,k) and not good(m,k+1),'bracket')
    with open('thresholds.csv','w',newline='') as f:
        w=csv.writer(f);w.writerow(['block_size','proved_through','boundary','local_failure_from'])
        w.writerows((m,k,k+1,k+2) for m,k in enumerate(ks,1))
    print('Exact threshold table, m=1..12:',ks)
    cases=[(m,k) for m in range(1,6) for k in range(1,8) if m*k<=12]
    total=sum(explicit_flow(m,k) for m,k in cases)
    print(f'Explicit rational flow: {len(cases)} cubes, {total} upward edges checked.')
    allcases=[]
    for k in range(1,6):
        for sizes in product(range(1,5),repeat=k):
            if sum(sizes)<=8 and tuple(sorted(sizes))==sizes:allcases.append(sizes)
    for sizes in allcases:
        c=cube_test(sizes);mac=macro_test(sizes)
        check(c==mac,('macro vs cube',sizes,c,mac))
        if len(set(sizes))==1:check(c==good(sizes[0],len(sizes)),('threshold',sizes))
    print(f'Full-cube versus compressed integer max-flow: {len(allcases)} cases.')
    small=[s for s in allcases if sum(s)<=4]
    count=sum(all_compatible(s) for s in small)
    print(f'Exhaustive compatible-family audit: {count} families across {len(small)} block partitions.')
    ws=[witness(1,3,True),witness(2,7,True),witness(3,17),witness(4,38)]
    Path('witnesses.json').write_text(json.dumps(ws,indent=2)+'\n')
    print('Negative constructions:',[(w['m'],w['k'],w['family_size'],w['frequency_each_mark']) for w in ws[:2]])
    print('All checks passed. No floating-point comparisons or third-party modules.')

if __name__=='__main__': main()
