# Binary-recursion compiler audit after full QFI

This note concerns the one-sorted theory with native equality, `0`, `S`,
all dependency-ordered binary symbols `R_h` for earlier terms `h(n,v)`,
their equations

    R_h(0,a)=a,   R_h(Sn,a)=h(n,R_h(n,a)),

separation `0 != S0`, and FULL quantifier-free induction, with arbitrary
fixed finite parameter tuples, already derived from the proposed normalized
induction schema. All arguments below are intuitionistic. There is no
parameter in an admitted update other than its counter and current value.

The existing binary draft's compiler is sound. The present reconstruction
is shorter because full QFI is available at the start: its residual
invariant can be a disjunction, and native equality reflection does not
need a separate Boolean compilation bootstrap. No multiplication, bounded
search, or hidden parameterized recursion is needed before pairing.

## 1. Legal elementary terms and successor laws

Use these finite abbreviations in dependency order:

    p(x)   = R_{n}(x,0),
    x+y    = R_{Sv}(y,x),
    d(x,y) = R_{p(v)}(y,x),
    Z(x,a) = R_0(x,a).

Their updates are respectively `n`, `Sv`, `p(v)`, and `0`, so all are
admitted binary symbols. Computation gives

    p0=0,  p(Sx)=x;
    x+0=x, x+Sy=S(x+y);
    d(x,0)=x, d(x,Sy)=p(d(x,y));
    Z(0,a)=a, Z(Sx,a)=0.

Applying p to Sx=Sy gives x=y. Applying p to Sx=0 gives x=0, whence
the original equality implies S0=0, contradicting separation. Thus S is
injective and has no zero value. QFI on `x=0 OR x=S(p(x))` gives
constructor coverage: its base is immediate and its successor case is a
computation equation independently of the induction hypothesis. In
particular `x=0 OR x!=0` is provable constructively; in the successor
branch nonzeroness gives the second disjunct.

## 2. Addition and subtraction identities, with induction variables

The following table specifies all needed preliminary inductions. Every
other free variable is held fixed.

| Equation | Induction variable | Base/step justification |
|---|---|---|
| `0+y=y` | y | Computation; apply S to the hypothesis. |
| `Sx+y=S(x+y)` | y | Computation; apply S to the hypothesis. |
| `x+y=y+x` | y | `0+x=x`; at the step use the preceding left-successor law. |
| `(x+y)+z=x+(y+z)` | z | Computation; apply S to the hypothesis. |
| `d(0,y)=0` | y | Computation and p0=0. |
| `d(Sx,Sy)=d(x,y)` | y | At zero p(Sx)=x; at the step apply p to the hypothesis. |
| `d(x+c,x)=c` | x | At zero 0+c=c; step rewrites Sx+c as S(x+c), then cancels the two successors in d. |
| `d(x+z,y+z)=d(x,y)` | z | Base is immediate; successor uses the joint-successor d identity. |

The cancellation equation gives `d(x,x)=0` at c=0 and
`d(Sx,x)=1` at c=1, with `1=S0` and x+1=Sx. Commutativity also gives
`d(x+y,y)=x`.

The ternary selector needed later is a composed term, not an introduced
ternary symbol:

    C(z,a,b) = Z(z,a) + Z(Z(z,1),b).

Its zero and successor equations are

    C(0,a,b)=a,   C(Sz,a,b)=b.

Indeed, the first reduces to a+0=a; the second to 0+b=b. Coverage
therefore makes this a genuine selector on the whole carrier.

## 3. Residual invariant, and a discrete linear order

Define `x <= y` to abbreviate the QF equation `d(x,y)=0`.

**Residual invariant.** QFI on n, with x fixed, proves

    d(x,n)=0 OR x=n+d(x,n).                         (R)

At n=0 the second branch is x=0+x. At a successor put r=d(x,n).
Coverage gives r=0 or r=Su. In the first case the next residual is
p0=0. In the second case the zero branch of the induction hypothesis
contradicts successor nonzeroness, so x=n+Su=Sn+u; the next residual is
p(Su)=u. This supplies the second branch at Sn. Every matrix used is QF.

**Successor order law.** One has

    x<=Sn  iff  x<=n OR x=Sn.                     (OS)

For the forward implication, `p(d(x,n))=0`. Coverage of d(x,n) gives
d(x,n)=0, or d(x,n)=Su with u=0, hence d(x,n)=1. In the latter case
(R) rules out its zero branch and yields x=n+1=Sn. The reverse implication
uses p0=0 or the diagonal d(Sn,Sn)=0. Also, directly,

    0<=x,   x<=0 iff x=0,   x<=x,   NOT(Sx<=x).

**Transitivity.** Fix x,y and apply QFI on z to

    (x<=y AND y<=z) -> x<=z.

At zero, y<=0 gives y=0. At Sz, apply (OS) to y<=Sz. If y<=z,
the induction hypothesis gives x<=z, and (OS) gives x<=Sz. If y=Sz,
the original x<=y already gives the conclusion.

**Antisymmetry (native equality).** Suppose x<=y and y<=x. Cover y.
For y=0, x=0. For y=Sv, (OS) gives x<=v or x=Sv. The second branch
is the result; the first, combined with Sv<=x and transitivity, gives
Sv<=v, contradicting d(Sv,v)=1 and separation. Thus

    x=y iff x<=y AND y<=x.                        (AS)

Since each zero test d(x,y)=0 is decidable by coverage, (AS) also proves
native equality decidable. This is derived; no global excluded middle
is assumed.

**Translation.** The last equation of the preceding table says exactly
that addition by a common summand preserves and reflects <=. It also
proves ordinary additive cancellation: apply d(-,z) to x+z=y+z and use
d(x+z,z)=x. Write `x<y` for `Sx<=y`. The identity
S(x+z)=Sx+z and the d-translation equation show that common addition
preserves and reflects < as well. Reflexivity and 0<=r give

    a<=a+r,   and   Sa<=Sa+r.                    (A+)

These are direct instances of order translation, with no further induction.

**Complement and linearity.** If NOT(x<=y), (R) gives x=y+r, where
r=d(x,y). Since r!=0, coverage gives r=Su. Hence
x=y+Su=Sy+u, so (A+) gives Sy<=x, that is y<x. Thus

    NOT(x<=y) -> y<x.                            (CO)

Deciding x<=y and using (CO) proves totality. If y<x then y<=x by
y<=Sy and transitivity. The conjunction x<=y and y<x is impossible,
because transitivity would give Sy<=y. Consequently (CO) is the exact
constructive complement law: NOT(x<=y) iff y<x.

**Difference decomposition.** If x<=y, split the decidable test y<=x.
If it holds, (AS) gives y=x and d(y,x)=0. If it fails, (R) with the
arguments reversed gives y=x+d(y,x). Thus in both cases

    x<=y -> y=x+d(y,x).                          (DD)

**Discrete gap.** If x<=y and x!=y, (DD) gives y=x+r with r=d(y,x).
If r=0 this contradicts x!=y. Coverage gives r=Su, hence y=Sx+u and
Sx<=y by (A+). Conversely Sx<=y implies x<=y, while x=y would contradict
NOT(Sx<=x). Thus

    x<y iff x<=y AND x!=y.                       (G)

Finally `x<Sy iff x<=y` follows directly from
d(Sx,Sy)=d(x,y). These facts supply all the order manipulations below.
They were derived without a parameter-changing induction or an induction
matrix containing quantifiers.

## 4. Triangular numbers and their inverse

The following updates use only their allowed counter n and value v:

    T(n) = R_{v+Sn}(n,0),
    V(n) = R_q(n,0),
    q(n,v) = C(d(T(Sv),Sn),Sv,v).

Thus T0=0, T(Sn)=T(n)+Sn, V0=0, and V(Sn)=q(n,V(n)).

For completeness:

* QFI on n proves n<=T(n): at the successor, Sn<=T(n)+Sn follows
  by translating 0<=T(n); the old induction hypothesis is not needed.
* Fix x and use QFI on k for T(x)<=T(x+k). The base is reflexivity.
  The step uses x+Sk=S(x+k), the computation equation for T, (A+),
  and transitivity. If x<=y, substitute k=d(y,x) into this theorem
  and use (DD). This proves monotonicity of T.
* T(x)<T(Sx): 0<Sx follows from 0<=x and successor cancellation of d;
  translate by T(x). If x<y, then Sx<=y; monotonicity and this strict
  successor increase give T(x)<T(y).

**Interval invariant.** QFI on n proves the conjunction

    T(V(n)) <= n < T(S(V(n))).                   (I)

At zero it is 0<=0<1. At the successor set v=V(n) and decide
T(Sv)<=Sn using its zero test. If true, the old strict upper bound means
Sn<=T(Sv), so antisymmetry gives T(Sv)=Sn. The selector chooses Sv.
Its lower bound is that equality; its upper bound is the strict increase
T(Sv)<T(SSv). If the test is false, (CO) gives Sn<T(Sv), the selector
retains v, and T(v)<=n<=Sn supplies the new lower bound.

**Uniqueness of an interval index.** Suppose
T(r)<=z<T(Sr) and T(t)<=z<T(St). Totality together with native equality
decidability and (G) yields r=t, r<t, or t<r. If r<t then Sr<=t;
monotonicity gives T(Sr)<=T(t)<=z, contradicting z<T(Sr). The other
strict case is symmetric. Thus r=t.

## 5. Pairing on every carrier element

Define the finite terms

    J(x,y) = T(x+y)+y,
    pi2(z) = d(z,T(V(z))),
    pi1(z) = d(V(z),pi2(z)).

Put t=x+y. By (A+) and commutativity y<=t, equivalently y<St.
Translate this strict inequality by T(t):

    T(t)<=J(x,y)<T(t)+St=T(St).

Interval uniqueness with (I) gives V(J(x,y))=t. Thus

    pi2(J(x,y)) = d(T(t)+y,T(t)) = y,
    pi1(J(x,y)) = d(x+y,y) = x.

Conversely set t=V(z), r=pi2(z). From the lower half of (I), (DD)
gives z=T(t)+r. Its upper half, strict order translation, and
`r<St iff r<=t` give r<=t. Apply (DD) to obtain
t=r+d(t,r)=r+pi1(z). Commutativity yields

    J(pi1(z),pi2(z)) = T(t)+r = z.

All three identities hold internally for arbitrary elements, not only
standard numerals. The last identity is useful for a genuine bijective
pairing; the ordinary-recursion compiler needs only the first two.

## 6. Eliminate every frozen parameter of ordinary recursion

For a fixed arity k define tuple-code terms externally:

    code_0=0,
    code_(j+1)(b_1,...,b_(j+1))=J(code_j(b_1,...,b_j), b_(j+1)).

For i from 1 to k the decoding term is `pi2 o pi1^(k-i)`. The exponent
means a fixed finite composition, not an added iteration operation.
Repeated application of the pair projection identities proves every
decoder returns its corresponding b_i.

Suppose earlier source terms G,H have already been compiled and an
ordinary PR descriptor F has equations

    F(0,b)=G(b),
    F(Sn,b)=H(n,b,F(n,b)).

Make the finite binary update

    h(n,z)=J(pi1(z), H*(n, decode_k(pi1(z)), pi2(z))).

Only n,z are free. Every frozen source input b_i has been replaced by a
term in pi1(z). Introduce the legal binary descriptor R_h, and set

    A(n,b)=R_h(n,J(code_k(b),G*(b))),
    F*(n,b)=pi2(A(n,b)).

QFI on the single equation `pi1(A(n,b))=code_k(b)`, with b fixed,
proves the parameter invariant. Its base follows from the first pair
identity; at the step pi1 of h(n,A(n,b)) is pi1(A(n,b)), which the
induction hypothesis identifies with code_k(b). Applying pi2 to the
two computation equations, and using this invariant and tuple decoding,
gives exactly the desired base and update equations for F*. The empty
tuple k=0 works unchanged: its code is 0 and the update calls H* with
no decoded parameter arguments. Projections are variables, composition
is term substitution. This is a full external structural recursion on
finite dependency descriptions, not only a list of sample PR functions.

## 7. Both identity round trips and the normalized schema

Let alpha map ordinary PRA into the binary theory by the preceding
compiler. Let beta map each binary R_h to ordinary primitive recursion
J_h(n,a) with frozen parameter a, base a, and update h^beta(n,v).
Both maps fix the whole carrier, native equality, 0,S, and all logical
connectives and quantifiers. The full derived QFI validates all alpha
translations. Ordinary PRA validates beta translations of computation,
separation, and the proposed normalized schema: its zero instance is a
logical theorem B->B, so ordinary QFI proves it from progress.

Ordinary recursion uniqueness is proved, in either theory, by QFI on
the equation U(n,c)=W(n,c), fixing all c. Identical bases supply the
base equality; the common update and equality congruence supply progress.
This remains valid under fixed hypotheses establishing the recurrences.

For each ordinary descriptor F, external induction over its earlier
dependencies identifies the already translated G,H with their originals.
The transported compiler theorem then says F^(alpha beta) has F's base
and update. Recursion uniqueness gives F^(alpha beta)=F everywhere.

For each binary descriptor R_h, transport J_h's defining equations by
alpha. Its binary round-trip term R_h^(beta alpha) has base a and update
h^(beta alpha)(n,v). External dependency induction has already identified
every earlier symbol in h, so this update equals h(n,v). Recursion
uniqueness, with a fixed, therefore gives

    R_h^(beta alpha)(n,a)=R_h(n,a).

This argument automatically handles extra pairing and tuple-code symbols
introduced by the compiler. It does NOT identify a round-trip description
syntactically with the original, and does NOT appeal only to agreement on
standard naturals. Every individual identity is an object-theory theorem.

The identity graph x=y is therefore a definable isomorphism for both
composites. Structural induction on arbitrary formulas extends the
pointwise term identities to quantified formulas. The two explicit term
translations can equally be adjoined in a joint language; their round-trip
identities make the resulting conservative definitional extensions coincide.
Each proof uses finitely many definitions, so an effective countable
signature causes no conservativity difficulty. Equiconsistency follows
by the two effective contradiction-preserving proof translations.

## Audit conclusion

The normalized schema proposed by root is sound and equivalent to full
QFI: for arbitrary F(n,c), use the admitted A(n,c)=F(0,c)->F(n,c).
Its zero substitution is literally B->B, where B=F(0,c). Assuming F's
progress proves A's progress intuitionistically. The normalized instance
gives all implications F(0,c)->F(n,c), and the assumed base yields F.
The schema's syntactic zero condition must be part of the specification
and counted/disclosed separately from its displayed formula length.
No excluded middle, equality reflection axiom, independent pairing
axiom, universal evaluator, or hidden frozen update variable is needed.
