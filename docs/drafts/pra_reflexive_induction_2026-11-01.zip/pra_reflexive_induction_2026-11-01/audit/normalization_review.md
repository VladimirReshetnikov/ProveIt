# Independent review: reflexive-base induction

## Result

The proposed normalized induction scheme is sound and complete for full
quantifier-free induction, in intuitionistic as well as classical first-order
logic. This is a purely logical theorem, valid over an arbitrary background
theory. It needs neither arithmetic equations nor equality decidability.

For every quantifier-free A(n,c), admit

    [forall n (A(n,c) -> A(Sn,c))] -> forall n A(n,c)

only when capture-free substitution A(0,c) has the literal syntax B -> B,
with the two B subtrees identical. Parameters c are universally closed.

## Forward implication to QFI

Fix an arbitrary QF formula F(n,c). Let A(n,c) = F(0,c) -> F(n,c).
Its zero substitution is literally F(0,c) -> F(0,c), hence it is admitted.
Under H = forall n (F(n,c) -> F(Sn,c)), suppose A(n,c) and then F(0,c).
Modus ponens gives F(n,c); H gives F(Sn,c); discharging F(0,c) gives
A(Sn,c). Thus H implies the stationarity premise required by NI.
NI yields forall n (F(0,c) -> F(n,c)). With F(0,c), deduce forall n F(n,c).
Discharge the hypotheses and universally close the parameters. This is QFI.

There is no appeal to the deduction theorem for an exotic induction *rule*:
NI is an implication axiom, and the argument is ordinary natural deduction.
In particular, all fixed assumptions remain fixed throughout.

## Converse

Assume QFI. For an admitted A, its zero instance B -> B is a logical theorem.
The premise forall n (A(n,c) -> A(Sn,c)) and this base satisfy the ordinary
induction axiom. Therefore forall n A(n,c). Discharge the premise.

## Translation and interpretation audit

Both interpretation compilers should fix 0, S, equality, logical connectives,
quantifiers, and all free variables. They should translate descriptions using a
deterministic memoized mapping, rather than choosing distinct symbol names for
two occurrences of the same source description. Then translation commutes
literally with zero substitution. An admitted source A has translated zero
instance B* -> B*, so its translated NI instance is admitted directly.

Even without literal admission preservation, interpreting into ordinary PRA
would still be sound because the translated initial formula is a logical
theorem and ordinary QFI applies. The stronger literal preservation statement
is straightforward to arrange and preferable for a syntax checker.

Formula metavariables can contain unused displayed variables. This is needed
both for normalizations with constant antecedents and for empty parameter
tuples. The distinguished counter must be chosen fresh for fixed surrounding
hypotheses when introducing its universal quantifier; the ordinary induction
schema has exactly the same discipline.

The earlier binary mixed-recursion theory uses h(n,v), with no frozen update
parameters. Its computation grammar should be retained exactly. NI plus
separation yields QFI, hence the prior zero-exception scheme; conversely the
prior theorem yields QFI, hence NI. Thus the new arithmetic basis and that
earlier binary theory prove exactly the same sentences in their common
language, and its full-carrier identity bi-interpretations transfer.

## Count audit

For q frozen induction parameters and no frozen computation parameters, the
two binary mixed-recursion computation templates total 18 AST nodes; the
expanded sentence (0=S0) -> bottom has 6. NI has 11+4q: three schematic A
applications account for 3q parameter leaves, and parameter closure adds q.
The total is therefore 35+4q. The fused existing QFI presentation has 37+5q.
The declared display saving is 2+q, including 39 versus 42 at q=1.

This count does not charge the new syntactic admission rule, so it cannot
establish a minimum for complete binary encodings of axiom generators. The
improvement should be described as a smaller displayed schema, a sharper
explicit admission discipline, and an inexpensive equivalence proof.

One illustration of the limitation: one could also admit the constant formula
A(n) = ((0=S0) -> bottom) as a special parser exception and thereby remove the
separate separation sentence from the display. That merely moves its content
into the parser; it is not an honest further arithmetic simplification.

## Prior-art audit in the current input archives

The fixed_zero_case, fixed_zero_induction, rooted_induction, one_equation,
coverage_equational, and fused_guarded_sink reports contain the same fixed-zero
equation schema and variants of the equality-reflection proof. The rooted
report already has the short residual-invariant proof.

PRA_bd7c_fresh_comparison_and_atomic_coverage/report.tex has an "Optional
syntactic-base normalization" subsection for *equation induction*. It requires
both zero-substituted terms to have root form R_h(0,0,u) and retains coverage.
This is conceptual prior art for the normalization technique and should be
credited. A search across all current TeX members found no occurrence of the
reflexive-implication B -> B admission condition for formula induction.

No historical novelty claim beyond this inspected snapshot is justified.

## Rejected or unproved explorations

Stationary-term constancy plus coverage has not been shown sufficient for
native equality reflection. The same missing step blocks a claimed reduction
to fixed-side zero-equation induction.

Classical disequality induction does imply coverage: fix a with a != 0 and
a != S(p(a)); induction on n != a applies because Sn=a would contradict the
second assumption. Its conclusion at n=a is impossible. Classical logic then
gives a=0 or a=S(p(a)). It also gives stationary constancy by choosing a fresh
probe equal to a desired function value. Neither observation proves all QFI.

Pure initialized iteration h(v), with no counter input, is extensionally
complete for PR functions by Gladstone's theorem (as stated in Severin's
primary-source survey). That standard-function theorem alone does not provide
the required internal equalities and round trips in arbitrary models. No
complete replacement proof was obtained in this review.
