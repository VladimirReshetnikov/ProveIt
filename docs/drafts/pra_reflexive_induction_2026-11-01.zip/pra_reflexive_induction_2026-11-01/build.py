#!/usr/bin/env python3
"""Rebuild the report and concrete checks; optionally rerun Lean 4.19.0."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
STEM = "pra_reflexive_induction"

def run(command, log_path, cwd=ROOT):
    completed = subprocess.run(command, cwd=cwd, text=True,
                               stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, check=False)
    log_path.write_text(completed.stdout, encoding="utf-8")
    if completed.returncode:
        raise RuntimeError(
            f"Command failed with status {completed.returncode}; see {log_path}")
    return completed.stdout

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--lean", help="Optional Lean 4.19.0 executable")
    args = parser.parse_args()
    build_dir = ROOT / "_build"
    audit = ROOT / "audit"
    build_dir.mkdir(exist_ok=True)
    audit.mkdir(exist_ok=True)
    run([sys.executable, str(ROOT / "artifacts/normalization_ast.py"),
         "--output", str(ROOT / "artifacts/normalization_results.json")],
        audit / "python-checks.log")
    report = {"python_checks": "PASS", "lean": "not rerun by this invocation"}
    if args.lean:
        lean_command = shutil.which(args.lean) or args.lean
        version = run([lean_command, "--version"], audit / "lean-version.txt")
        if "version 4.19.0" not in version:
            raise RuntimeError("This package pins Lean 4.19.0.")
        source = ROOT / "formal/ReflexiveInduction.lean"
        log = run([lean_command, str(source)], ROOT / "formal/lean-audit.txt")
        endpoints = re.findall(r"'([^']+)' does not depend on any axioms", log)
        if len(endpoints) != 10 or "sorryAx" in log:
            raise RuntimeError("Unexpected Lean endpoint audit.")
        formal = {
            "status": "PASS",
            "compiler_version": version.strip(),
            "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
            "endpoints": endpoints,
            "global_axiom_dependencies": [],
            "scope": "Syntax-and-semantics normalization kernel only; "
                     "not a full first-order compiler or bi-interpretation."
        }
        (ROOT / "formal/verification.json").write_text(
            json.dumps(formal, indent=2) + "\n", encoding="utf-8")
        report["lean"] = formal
    else:
        retained = ROOT / "formal/verification.json"
        source = ROOT / "formal/ReflexiveInduction.lean"
        if retained.exists():
            formal = json.loads(retained.read_text(encoding="utf-8"))
            digest = hashlib.sha256(source.read_bytes()).hexdigest()
            report["lean"] = {
                "status": "NOT_RERUN",
                "retained_verification": "formal/verification.json",
                "same_source_as_verified": digest == formal["source_sha256"]
            }

    latex = shutil.which("pdflatex")
    if not latex:
        raise RuntimeError("pdflatex is required.")
    for pass_number in range(1, 4):
        run([latex, "-no-shell-escape", "-interaction=nonstopmode",
             "-halt-on-error", "-file-line-error",
             "-output-directory", str(build_dir), STEM + ".tex"],
            audit / f"latex-pass-{pass_number}.log")
    log = (build_dir / f"{STEM}.log").read_text(errors="replace")
    diagnostics = [line for line in log.splitlines()
                   if re.search(r"Overfull|LaTeX Warning|Package .* Warning", line)]
    if re.search(r"undefined references|Reference .* undefined|Citation .* undefined",
                 log):
        raise RuntimeError("Unresolved LaTeX references.")
    if "Overfull" in log:
        raise RuntimeError("Overfull TeX boxes require layout correction.")
    target = ROOT / f"{STEM}.pdf"
    shutil.copyfile(build_dir / f"{STEM}.pdf", target)
    report.update({"latex": "PASS", "passes": 3,
                   "latex_diagnostics": diagnostics,
                   "pdf_bytes": target.stat().st_size,
                   "pdf_sha256": hashlib.sha256(target.read_bytes()).hexdigest()})
    (audit / "build.json").write_text(json.dumps(report, indent=2) + "\n",
                                     encoding="utf-8")
    print(json.dumps({"status": "PASS", "pdf": target.name,
                      "bytes": target.stat().st_size,
                      "latex_diagnostics": diagnostics,
                      "lean_checked": bool(args.lean)}, indent=2))

if __name__ == "__main__":
    main()

