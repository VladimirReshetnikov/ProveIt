REFLEXIVE-BASE NORMALIZATION: SYNTAX AND DISPLAY AUDIT

Run:
  python3 normalization_ast.py --output normalization_results.json

The actual QF syntax is equality between terms, falsehood, conjunction,
disjunction, and implication. There are no bound variables in these inputs.
The script performs literal simultaneous n:=0 substitution, with no
arithmetic or propositional simplification. It accepts A exactly when the
result has an outer implication whose two subtrees are identical. Function
symbol labels, including descriptor indices, are never substituted.
Quantified inputs and schematic formula placeholders are rejected.

For every QF formula F, the constructed formula
  N(F)(n,c) = F(0,c) -> F(n,c)
passes this check, since its zero substitution is literally F(0,c)->F(0,c).
The paper proves that induction for these admitted formulas, with an
automatic logical base, recovers all QF induction in intuitionistic logic.

DISPLAY LEDGER
The AST ledger counts one node per variable, constant, application, equality,
connective, falsity, and individual quantifier. Symbol names and binder names
are labels, not extra nodes. Repeated expressions are counted repeatedly.
An arbitrary schematic formula A(n,c) is counted as one application plus
its displayed argument terms, following the comparison drafts.

Binary recursion computation templates: 6+12 = 18 nodes.
Separate separation: 6 nodes.
Ordinary QFI: 14+5q nodes.
Fused separation/QFI: 19+5q nodes.
Normalized schema: 11+4q nodes.
Thus fused total = 37+5q, normalized total = 35+4q.
At q=1 these are 42 and 39.

The extra syntactic admission condition is a real additional cost and is
NOT included in this display ledger. The ledger is not complete binary
description length and does not establish absolute simplicity or optimality.

INSTANTIATION IS LONGER
Writing N(F) out in the normalized schema gives three copies of F(0,c),
two of F(n,c), and one of F(Sn,c): six schematic F occurrences in total.
Ordinary QFI has one F(0,c), two F(n,c), and one F(Sn,c): four occurrences.
The expanded normalized template costs 20+7q; its total with recursion and
separate separation is 44+7q, or 51 at q=1. Thus 39 is NOT a claim that the
concrete compiled induction instance is shorter than the fused 42 display.

For an actual QF AST F, zero substitution preserves AST size. The fully
expanded normalized instance exceeds ordinary QFI by exactly
  2 * AST_size(F) + 2
nodes, with the same parameters and the same successor substitution.
This identity is checked on the generated corpus.

VALIDATION SCOPE
The generated corpus and deliberately malformed controls verify this finite
implementation. They do not prove a theorem about every formula, do not
check first-order proofs, and do not establish bi-interpretability. The
mathematical structural argument and interpretation proofs are in the paper.
