#!/usr/bin/env python3
"""Finite syntax checks for reflexive-base normalization of QF induction.

This file certifies syntax and arithmetic in a disclosed AST ledger.  It is
not a proof checker for first-order logic and does not certify bi-interpretability.
The mathematical derivation of the normalized rule is given in the paper.

Run with Python 3.10 or later:
    python3 normalization_ast.py --output normalization_results.json

Only the Python standard library is used.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path
import re
from typing import Iterable


IDENTIFIER = re.compile(r"[A-Za-z_][A-Za-z_0-9]*\Z")
TERM_KINDS = frozenset({"var", "const", "app"})
FORMULA_KINDS = frozenset({"eq", "bot", "and", "or", "imp", "all", "pred"})


@dataclass(frozen=True, slots=True)
class Node:
    kind: str
    label: str = ""
    args: tuple["Node", ...] = ()

    def __post_init__(self) -> None:
        if self.kind not in TERM_KINDS | FORMULA_KINDS:
            raise ValueError(f"unknown syntax kind: {self.kind!r}")
        if not isinstance(self.args, tuple) or not all(isinstance(a, Node) for a in self.args):
            raise TypeError("args must be a tuple of syntax nodes")
        if self.kind in {"var", "const", "app", "pred", "all"}:
            if not isinstance(self.label, str) or not IDENTIFIER.fullmatch(self.label):
                raise ValueError("a symbol or binder must be a nonempty identifier")
        elif self.label:
            raise ValueError("logical connectives and equality have no symbol label")
        if self.kind in {"var", "const", "bot"} and self.args:
            raise ValueError("a leaf has no children")
        if self.kind in {"app", "pred"}:
            if not self.args or not all(a.kind in TERM_KINDS for a in self.args):
                raise ValueError("a nonnullary application has term children")
        if self.kind == "eq":
            if len(self.args) != 2 or not all(a.kind in TERM_KINDS for a in self.args):
                raise ValueError("equality has exactly two term children")
        if self.kind in {"and", "or", "imp"}:
            if len(self.args) != 2 or not all(a.kind in FORMULA_KINDS for a in self.args):
                raise ValueError("a binary connective has exactly two formula children")
        if self.kind == "all":
            if len(self.args) != 1 or self.args[0].kind not in FORMULA_KINDS:
                raise ValueError("a universal quantifier has one formula child")


def Var(name: str) -> Node:
    return Node("var", name)


def Const(name: str) -> Node:
    return Node("const", name)


def App(name: str, *arguments: Node) -> Node:
    return Node("app", name, arguments)


def Eq(left: Node, right: Node) -> Node:
    return Node("eq", args=(left, right))


def Bot() -> Node:
    return Node("bot")


def And(left: Node, right: Node) -> Node:
    return Node("and", args=(left, right))


def Or(left: Node, right: Node) -> Node:
    return Node("or", args=(left, right))


def Imp(left: Node, right: Node) -> Node:
    return Node("imp", args=(left, right))


def All(name: str, body: Node) -> Node:
    return Node("all", name, (body,))


def Pred(name: str, *arguments: Node) -> Node:
    """Schematic formula application, used ONLY in the display ledger."""
    return Node("pred", name, arguments)


ZERO = Const("zero")
N = Var("n")
A_SEED = Var("a")


def Succ(term: Node) -> Node:
    return App("S", term)


def size(node: Node) -> int:
    """One node per occurrence; symbol and binder labels cost no extra node."""
    return 1 + sum(size(a) for a in node.args)


def free_variables(node: Node) -> frozenset[str]:
    if node.kind == "var":
        return frozenset({node.label})
    result = frozenset().union(*(free_variables(a) for a in node.args))
    return result - {node.label} if node.kind == "all" else result


def is_qf(node: Node) -> bool:
    """Recognize actual QF equality formulas, not ledger placeholders."""
    if node.kind in {"eq", "bot"}:
        return True
    if node.kind in {"and", "or", "imp"}:
        return all(is_qf(a) for a in node.args)
    return False


def substitute_term(term: Node, variable: str, replacement: Node) -> Node:
    if term.kind not in TERM_KINDS or replacement.kind not in TERM_KINDS:
        raise TypeError("term substitution requires terms")
    if term.kind == "var" and term.label == variable:
        return replacement
    if not term.args:
        return term
    # Function-symbol labels, including descriptor indices, are immutable.
    return Node(term.kind, term.label,
                tuple(substitute_term(a, variable, replacement) for a in term.args))


def substitute_qf(formula: Node, variable: str, replacement: Node) -> Node:
    """Literal, simultaneous, capture-safe substitution in a QF formula.

    There are no binders in the admitted input grammar, hence no variable
    capture.  Quantified formulas and schematic predicate placeholders are
    rejected instead of being silently processed with a different convention.
    No equality, computation, or propositional simplification is performed.
    """
    if not is_qf(formula):
        raise ValueError("substitution input must be a quantifier-free equality formula")
    if replacement.kind not in TERM_KINDS:
        raise TypeError("replacement must be a term")
    if formula.kind == "bot":
        return formula
    if formula.kind == "eq":
        return Eq(*(substitute_term(a, variable, replacement) for a in formula.args))
    return Node(formula.kind, args=tuple(
        substitute_qf(a, variable, replacement) for a in formula.args))


def zero_instance(formula: Node, variable: str = "n") -> Node:
    return substitute_qf(formula, variable, ZERO)


def admitted(formula: Node, variable: str = "n") -> bool:
    """Accept exactly when A[0/n] is literally B -> B."""
    if not is_qf(formula):
        return False
    base = zero_instance(formula, variable)
    return base.kind == "imp" and base.args[0] == base.args[1]


def normalize(formula: Node, variable: str = "n") -> Node:
    """N(F)(n,c) := F(0,c) -> F(n,c)."""
    return Imp(zero_instance(formula, variable), formula)


def close(parameters: Iterable[str], body: Node) -> Node:
    result = body
    for parameter in reversed(tuple(parameters)):
        result = All(parameter, result)
    return result


def induction_instance(formula: Node, parameters: Iterable[str] = ()) -> Node:
    """Ordinary QFI instantiated with an actual QF formula."""
    base = zero_instance(formula)
    successor = substitute_qf(formula, "n", Succ(N))
    step = All("n", Imp(formula, successor))
    return close(parameters, Imp(And(base, step), All("n", formula)))


def normalized_instance(formula: Node, parameters: Iterable[str] = ()) -> Node:
    """The actual admitted NI instance used to derive induction for F."""
    wrapped = normalize(formula)
    successor = substitute_qf(wrapped, "n", Succ(N))
    return close(parameters, Imp(All("n", Imp(wrapped, successor)), All("n", wrapped)))


def computation_templates() -> tuple[Node, Node]:
    base = All("a", Eq(App("R_h", ZERO, A_SEED), A_SEED))
    step = All("n", All("a", Eq(
        App("R_h", Succ(N), A_SEED), App("h", N, App("R_h", N, A_SEED)))))
    return base, step


def display_ledger(parameter_count: int) -> dict[str, int]:
    if not isinstance(parameter_count, int) or parameter_count < 0:
        raise ValueError("parameter count must be a nonnegative integer")
    names = tuple(f"c{i}" for i in range(parameter_count))
    terms = tuple(Var(c) for c in names)
    a0, an, asn = (Pred("A", x, *terms) for x in (ZERO, N, Succ(N)))
    step = All("n", Imp(an, asn))
    conclusion = All("n", an)
    qfi = close(names, Imp(And(a0, step), conclusion))
    forbidden = Eq(ZERO, Succ(ZERO))
    separation = Imp(forbidden, Bot())
    fused = close(names, Imp(And(Or(a0, forbidden), step), conclusion))
    normalized = close(names, Imp(step, conclusion))

    f0, fn, fsn = (Pred("F", x, *terms) for x in (ZERO, N, Succ(N)))
    wrapped_n, wrapped_sn = Imp(f0, fn), Imp(f0, fsn)
    expanded = close(names, Imp(
        All("n", Imp(wrapped_n, wrapped_sn)), All("n", wrapped_n)))
    base, successor = computation_templates()
    computations = size(base) + size(successor)
    return {
        "q": parameter_count,
        "recursion_base": size(base),
        "recursion_step": size(successor),
        "separation": size(separation),
        "ordinary_qfi": size(qfi),
        "fused_qfi": size(fused),
        "normalized_schema": size(normalized),
        "expanded_normalized_instance_for_F": size(expanded),
        "ordinary_total": computations + size(separation) + size(qfi),
        "fused_total": computations + size(fused),
        "normalized_total": computations + size(separation) + size(normalized),
        "expanded_normalized_total": computations + size(separation) + size(expanded),
    }


def to_data(node: Node) -> dict:
    result: dict = {"kind": node.kind}
    if node.label:
        result["label"] = node.label
    if node.args:
        result["args"] = [to_data(a) for a in node.args]
    return result


def from_data(value: object) -> Node:
    if not isinstance(value, dict) or set(value) - {"kind", "label", "args"}:
        raise ValueError("syntax JSON must be an object with only kind, label, args")
    if "kind" not in value or not isinstance(value["kind"], str):
        raise ValueError("syntax JSON needs a string kind")
    children = value.get("args", [])
    if not isinstance(children, list):
        raise ValueError("syntax JSON args must be an array")
    return Node(value["kind"], value.get("label", ""),
                tuple(from_data(a) for a in children))


def pretty(node: Node) -> str:
    if node.kind == "const":
        return "0" if node.label == "zero" else node.label
    if node.kind == "var":
        return node.label
    if node.kind == "bot":
        return "false"
    if node.kind in {"app", "pred"}:
        return node.label + "(" + ", ".join(pretty(a) for a in node.args) + ")"
    if node.kind == "all":
        return f"forall {node.label}. ({pretty(node.args[0])})"
    symbol = {"eq": "=", "and": "and", "or": "or", "imp": "->"}[node.kind]
    return f"({pretty(node.args[0])} {symbol} {pretty(node.args[1])})"


def generated_corpus() -> list[Node]:
    """Deterministic bounded corpus; this is not an exhaustive syntax theorem."""
    leaves = [ZERO, N, Var("c0"), Var("c1")]
    terms = leaves + [Succ(t) for t in leaves]
    terms += [App(name, x, y) for name in ("R_zero", "R_counter", "R_successor")
              for x in leaves for y in leaves]
    atoms = [Bot()] + [Eq(x, y) for x in terms for y in terms]
    formulas = list(atoms)
    for index, left in enumerate(atoms):
        right = atoms[(index * 37 + 11) % len(atoms)]
        formulas.extend([And(left, right), Or(left, right), Imp(left, right)])
    for index in range(128):
        left = formulas[(index * 97 + 5) % len(formulas)]
        right = formulas[(index * 131 + 17) % len(formulas)]
        formulas.append(Imp(And(left, right), Or(right, left)))
    # Deduplicate syntax, preserving the deterministic construction order.
    return list(dict.fromkeys(formulas))


def expect_exception(action, expected=(ValueError, TypeError)) -> None:
    try:
        action()
    except expected:
        return
    raise AssertionError("malformed input was unexpectedly accepted")


def verify() -> dict:
    ledger = [display_ledger(q) for q in range(9)]
    for row in ledger:
        q = row["q"]
        assert row["recursion_base"] == 6
        assert row["recursion_step"] == 12
        assert row["separation"] == 6
        assert row["ordinary_qfi"] == 14 + 5 * q
        assert row["fused_qfi"] == 19 + 5 * q
        assert row["normalized_schema"] == 11 + 4 * q
        assert row["expanded_normalized_instance_for_F"] == 20 + 7 * q
        assert row["ordinary_total"] == 38 + 5 * q
        assert row["fused_total"] == 37 + 5 * q
        assert row["normalized_total"] == 35 + 4 * q
        assert row["expanded_normalized_total"] == 44 + 7 * q

    corpus = generated_corpus()
    originally_admitted = 0
    for formula in corpus:
        assert is_qf(formula)
        wrapped = normalize(formula)
        assert admitted(wrapped)
        base = zero_instance(formula)
        assert zero_instance(wrapped) == Imp(base, base)
        assert "n" not in free_variables(base)
        assert free_variables(base) == free_variables(formula) - {"n"}
        assert free_variables(wrapped) == free_variables(formula)
        assert size(base) == size(formula)
        assert from_data(to_data(formula)) == formula
        original = induction_instance(formula, ("c0", "c1"))
        normalized = normalized_instance(formula, ("c0", "c1"))
        assert size(normalized) - size(original) == 2 * size(formula) + 2
        originally_admitted += int(admitted(formula))

    negative_examples = [
        Eq(N, ZERO),                          # zero base true, wrong outer syntax
        Eq(N, N),                             # reflexive equation, not B -> B
        Imp(Eq(ZERO, ZERO), Eq(Succ(ZERO), ZERO)),
        Imp(Eq(ZERO, Succ(ZERO)), Eq(Succ(ZERO), ZERO)),
        And(Imp(Eq(N, ZERO), Eq(N, ZERO)), Eq(ZERO, ZERO)),
        All("n", Imp(Eq(N, ZERO), Eq(N, ZERO))),
        Pred("A", N),                        # ledger placeholders are not inputs
    ]
    for formula in negative_examples:
        assert not admitted(formula)
    positive_examples = [
        Imp(Eq(N, ZERO), Eq(ZERO, N)),
        Imp(Bot(), Bot()),
        Imp(Eq(App("R_counter", N, Var("c0")), ZERO),
            Eq(App("R_counter", ZERO, Var("c0")), ZERO)),
    ]
    for formula in positive_examples:
        assert admitted(formula)

    malformed = [
        {"kind": "unknown"},
        {"kind": "eq", "args": [{"kind": "bot"}]},
        {"kind": "var", "label": ""},
        {"kind": "var", "label": "n", "args": [{"kind": "bot"}]},
        {"kind": "imp", "args": [{"kind": "var", "label": "n"}, {"kind": "bot"}]},
        {"kind": "app", "label": "R", "args": []},
        {"kind": "bot", "extra": "silently ignored metadata"},
        {"kind": "bot", "args": "not an array"},
    ]
    for value in malformed:
        expect_exception(lambda value=value: from_data(value))
    expect_exception(lambda: normalize(All("n", Eq(N, N))))
    expect_exception(lambda: substitute_qf(Pred("A", N), "n", ZERO))
    expect_exception(lambda: display_ledger(-1))

    # Explicit simultaneous substitution and immutable descriptor-label check.
    term = App("n", N, Var("c0"))
    replacement = App("R_zero", N, ZERO)
    replaced = substitute_term(term, "n", replacement)
    assert replaced == App("n", replacement, Var("c0"))
    assert replaced.args[0] == replacement  # replacement was not recursively resubstituted
    equation = Eq(N, Var("c0"))
    assert substitute_qf(equation, "n", Var("c0")) == Eq(Var("c0"), Var("c0"))

    example = Imp(Eq(App("R_counter", N, Var("c0")), ZERO),
                  Or(Eq(N, Var("c0")), Eq(Var("c1"), ZERO)))
    return {
        "status": "PASS",
        "scope": "Finite syntax checks and exact representative AST counts; not a logic kernel.",
        "corpus": {
            "distinct_formulas": len(corpus),
            "originally_admitted": originally_admitted,
            "normalizations_checked": len(corpus),
            "zero_substitutions_checked": len(corpus),
            "serialization_round_trips_checked": len(corpus),
            "expanded_instance_size_identities_checked": len(corpus),
        },
        "controls": {
            "valid_but_not_admitted_or_other_rejected_examples": len(negative_examples),
            "independently_admitted_examples": len(positive_examples),
            "malformed_json_rejected": len(malformed),
            "additional_rejected_operations": 3,
            "simultaneous_substitution_and_symbol_labels": "PASS",
        },
        "ledger": ledger,
        "closed_forms": {
            "fused_total": "37 + 5q",
            "normalized_total": "35 + 4q",
            "display_saving_against_fused": "2 + q",
            "expanded_normalized_total": "44 + 7q",
            "expanded_overhead_against_fused": "7 + 2q",
            "expanded_NI_vs_ordinary_QFI_for_actual_F": "2 * AST_size(F) + 2",
        },
        "example": {
            "input": pretty(example),
            "normalized": pretty(normalize(example)),
            "literal_zero_instance": pretty(zero_instance(normalize(example))),
            "admitted": admitted(normalize(example)),
            "input_ast": to_data(example),
        },
        "limitations": [
            "No claim that normalized instantiated axioms or translated proofs are shorter.",
            "The additional admission test is excluded from the representative display ledger.",
            "The descriptor grammar, axiom enumerator, binding metadata and substitutions are not charged.",
            "The finite generated corpus does not replace the structural-induction proof.",
            "This script does not check first-order derivations or the mathematical bi-interpretation.",
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="write the complete audit as JSON")
    arguments = parser.parse_args()
    result = verify()
    encoded = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if arguments.output:
        arguments.output.write_text(encoded, encoding="utf-8")
    print(json.dumps({"status": result["status"], "corpus": result["corpus"],
                      "q1": result["ledger"][1], "controls": result["controls"]}, indent=2))


if __name__ == "__main__":
    main()
