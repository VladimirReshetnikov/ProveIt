/-
Copyright 2026. A new, self-contained syntax-level verification artifact.

This file proves the purely logical equivalence between quantifier-free
induction and its restriction to formulas whose zero substitution is literally
an implication B -> B. It does not formalize the recursion-description compiler
or a first-order proof calculus. No library beyond Lean's Init is imported.
-/

namespace ReflexiveInduction

inductive Term where
  | var : Nat -> Term
  | zero : Term
  | succ : Term -> Term
  | binary : Nat -> Term -> Term -> Term
  deriving DecidableEq, Repr

inductive Formula where
  | eq : Term -> Term -> Formula
  | bot : Formula
  | conj : Formula -> Formula -> Formula
  | disj : Formula -> Formula -> Formula
  | imp : Formula -> Formula -> Formula
  deriving DecidableEq, Repr

structure Interpretation (M : Type u) where
  zero : M
  succ : M -> M
  binary : Nat -> M -> M -> M

/-- Index zero is the induction variable; positive indices stay frozen. -/
def assignment (rho : Nat -> M) (n : M) : Nat -> M
  | 0 => n
  | k + 1 => rho (k + 1)

def Term.atZero : Term -> Term
  | .var 0 => .zero
  | .var (k + 1) => .var (k + 1)
  | .zero => .zero
  | .succ t => .succ t.atZero
  | .binary f t s => .binary f t.atZero s.atZero

def Formula.atZero : Formula -> Formula
  | .eq t s => .eq t.atZero s.atZero
  | .bot => .bot
  | .conj a b => .conj a.atZero b.atZero
  | .disj a b => .disj a.atZero b.atZero
  | .imp a b => .imp a.atZero b.atZero

def Term.eval (I : Interpretation M) (rho : Nat -> M) : Term -> M
  | .var k => rho k
  | .zero => I.zero
  | .succ t => I.succ (t.eval I rho)
  | .binary f t s => I.binary f (t.eval I rho) (s.eval I rho)

def Formula.eval (I : Interpretation M) (rho : Nat -> M) : Formula -> Prop
  | .eq t s => t.eval I rho = s.eval I rho
  | .bot => False
  | .conj a b => a.eval I rho /\ b.eval I rho
  | .disj a b => a.eval I rho \/ b.eval I rho
  | .imp a b => a.eval I rho -> b.eval I rho

def Formula.holdsAt (a : Formula) (I : Interpretation M)
    (rho : Nat -> M) (n : M) : Prop :=
  a.eval I (assignment rho n)

theorem Term.atZero_idempotent (t : Term) : t.atZero.atZero = t.atZero := by
  induction t with
  | var k => cases k <;> rfl
  | zero => rfl
  | succ t ih => exact congrArg Term.succ ih
  | binary f t s iht ihs =>
      change Term.binary f t.atZero.atZero s.atZero.atZero =
        Term.binary f t.atZero s.atZero
      rw [iht, ihs]

theorem Formula.atZero_idempotent (a : Formula) : a.atZero.atZero = a.atZero := by
  induction a with
  | eq t s =>
      change Formula.eq t.atZero.atZero s.atZero.atZero =
        Formula.eq t.atZero s.atZero
      rw [Term.atZero_idempotent, Term.atZero_idempotent]
  | bot => rfl
  | conj a b iha ihb =>
      change Formula.conj a.atZero.atZero b.atZero.atZero =
        Formula.conj a.atZero b.atZero
      rw [iha, ihb]
  | disj a b iha ihb =>
      change Formula.disj a.atZero.atZero b.atZero.atZero =
        Formula.disj a.atZero b.atZero
      rw [iha, ihb]
  | imp a b iha ihb =>
      change Formula.imp a.atZero.atZero b.atZero.atZero =
        Formula.imp a.atZero b.atZero
      rw [iha, ihb]

theorem Term.eval_atZero (t : Term) (I : Interpretation M)
    (rho : Nat -> M) (n : M) :
    t.atZero.eval I (assignment rho n) = t.eval I (assignment rho I.zero) := by
  induction t with
  | var k => cases k <;> rfl
  | zero => rfl
  | succ t ih => exact congrArg I.succ ih
  | binary f t s iht ihs =>
      change I.binary f (t.atZero.eval I (assignment rho n))
          (s.atZero.eval I (assignment rho n)) =
        I.binary f (t.eval I (assignment rho I.zero))
          (s.eval I (assignment rho I.zero))
      rw [iht, ihs]

theorem Formula.eval_atZero (a : Formula) (I : Interpretation M)
    (rho : Nat -> M) (n : M) :
    a.atZero.holdsAt I rho n <-> a.holdsAt I rho I.zero := by
  induction a with
  | eq t s =>
      change (t.atZero.eval I (assignment rho n) =
        s.atZero.eval I (assignment rho n)) <->
        (t.eval I (assignment rho I.zero) = s.eval I (assignment rho I.zero))
      rw [Term.eval_atZero, Term.eval_atZero]
  | bot => exact Iff.rfl
  | conj a b iha ihb =>
      exact and_congr iha ihb
  | disj a b iha ihb =>
      exact or_congr iha ihb
  | imp a b iha ihb =>
      constructor
      · intro h ha
        exact ihb.mp (h (iha.mpr ha))
      · intro h ha
        exact ihb.mpr (h (iha.mp ha))

/-- An exact finite syntax condition, not provability or arithmetic truth. -/
def Formula.Admissible (a : Formula) : Prop :=
  exists b : Formula, a.atZero = .imp b b

def Formula.isAdmissible (a : Formula) : Bool :=
  match a.atZero with
  | .imp b c => decide (b = c)
  | _ => false

theorem Formula.isAdmissible_correct (a : Formula) :
    a.isAdmissible = true <-> a.Admissible := by
  unfold Formula.isAdmissible Formula.Admissible
  cases a.atZero with
  | eq t s =>
      constructor
      · intro h
        cases h
      · intro h
        obtain ⟨b, hb⟩ := h
        cases hb
  | bot =>
      constructor
      · intro h
        cases h
      · intro h
        obtain ⟨b, hb⟩ := h
        cases hb
  | conj a b =>
      constructor
      · intro h
        cases h
      · intro h
        obtain ⟨c, hc⟩ := h
        cases hc
  | disj a b =>
      constructor
      · intro h
        cases h
      · intro h
        obtain ⟨c, hc⟩ := h
        cases hc
  | imp b c =>
      constructor
      · intro h
        have heq : b = c := of_decide_eq_true h
        cases heq
        exact Exists.intro b rfl
      · intro h
        obtain ⟨d, hd⟩ := h
        injection hd with hbd hcd
        exact decide_eq_true (hbd.trans hcd.symm)

def Formula.normalize (a : Formula) : Formula := .imp a.atZero a

theorem Formula.normalize_admissible (a : Formula) : a.normalize.Admissible := by
  refine Exists.intro a.atZero ?_
  change Formula.imp a.atZero.atZero a.atZero = Formula.imp a.atZero a.atZero
  rw [Formula.atZero_idempotent]

theorem Formula.admissible_base (a : Formula) (ha : a.Admissible)
    (I : Interpretation M) (rho : Nat -> M) : a.holdsAt I rho I.zero := by
  obtain ⟨b, hb⟩ := ha
  have hzero : a.atZero.holdsAt I rho I.zero := by
    rw [hb]
    exact fun h => h
  exact (a.eval_atZero I rho I.zero).mp hzero

def FullInduction (I : Interpretation M) : Prop :=
  forall (a : Formula) (rho : Nat -> M),
    a.holdsAt I rho I.zero ->
    (forall n, a.holdsAt I rho n -> a.holdsAt I rho (I.succ n)) ->
    forall n, a.holdsAt I rho n

def NormalizedInduction (I : Interpretation M) : Prop :=
  forall (a : Formula) (rho : Nat -> M),
    a.Admissible ->
    (forall n, a.holdsAt I rho n -> a.holdsAt I rho (I.succ n)) ->
    forall n, a.holdsAt I rho n

theorem full_to_normalized (I : Interpretation M) (full : FullInduction I) :
    NormalizedInduction I := by
  intro a rho ha step
  exact full a rho (a.admissible_base ha I rho) step

theorem normalized_to_full (I : Interpretation M) (norm : NormalizedInduction I) :
    FullInduction I := by
  intro a rho base step
  have normStep : forall n,
      a.normalize.holdsAt I rho n -> a.normalize.holdsAt I rho (I.succ n) := by
    intro n ih initialAtSuccessor
    have initialAtZero : a.holdsAt I rho I.zero :=
      (a.eval_atZero I rho (I.succ n)).mp initialAtSuccessor
    have initialAtCurrent : a.atZero.holdsAt I rho n :=
      (a.eval_atZero I rho n).mpr initialAtZero
    exact step n (ih initialAtCurrent)
  have allNormalized : forall n, a.normalize.holdsAt I rho n :=
    norm a.normalize rho a.normalize_admissible normStep
  intro n
  exact allNormalized n ((a.eval_atZero I rho n).mpr base)

theorem normalized_iff_full (I : Interpretation M) :
    NormalizedInduction I <-> FullInduction I :=
  Iff.intro (normalized_to_full I) (full_to_normalized I)

/-- The false constant matrix is correctly rejected by the parser condition. -/
theorem false_not_admissible : Not Formula.bot.Admissible := by
  intro h
  obtain ⟨b, hb⟩ := h
  cases hb

/-- Omitting the admission condition would make the principle inconsistent. -/
theorem unrestricted_base_free_impossible (I : Interpretation M)
    (bad : forall (a : Formula) (rho : Nat -> M),
      (forall n, a.holdsAt I rho n -> a.holdsAt I rho (I.succ n)) ->
      forall n, a.holdsAt I rho n) : False := by
  exact bad Formula.bot (fun _ => I.zero) (fun _ h => h) I.zero

-- Concrete syntax examples; these are independent of any carrier model.
example : (Formula.normalize (.eq (.var 0) (.var 1))).Admissible :=
  Formula.normalize_admissible _

example : Not (Formula.eq (.var 0) (.succ .zero)).Admissible := by
  intro h
  obtain ⟨b, hb⟩ := h
  cases hb

#print axioms Formula.atZero_idempotent
#print axioms Formula.eval_atZero
#print axioms Formula.isAdmissible_correct
#print axioms Formula.normalize_admissible
#print axioms Formula.admissible_base
#print axioms full_to_normalized
#print axioms normalized_to_full
#print axioms normalized_iff_full
#print axioms false_not_admissible
#print axioms unrestricted_base_free_impossible

end ReflexiveInduction
