# Scope of the Lean verification

`ReflexiveInduction.lean` is new code for this report. It uses Lean 4.19.0 and
only Lean's implicit `Init` import. It has no imported mathematical libraries.

## What is checked

The file defines finite syntax for terms with indexed individual variables,
zero, successor, and indexed binary function symbols. It defines finite
quantifier-free formula syntax with native equality, falsity, conjunction,
disjunction, and implication. Negation is implication to falsity.

Variable index zero is the distinguished induction variable. Positive indices
are interpreted by an arbitrary frozen parameter environment. Every finite
parameter profile is therefore included, as are unused parameters.

The kernel checks:

- idempotence of literal substitution of zero for variable zero;
- correctness of that substitution in every interpretation over every carrier;
- an executable Boolean test for the exact syntactic condition that the zero
  instance has shape `B -> B`, together with proof of its correctness;
- admissibility of the normalization `A(0) -> A(n)` for every formula;
- validity of the zero instance of every admitted formula;
- equivalence of normalized induction and full quantifier-free induction,
  quantified over all formula trees and all parameter environments;
- rejection of the constant false formula and of a raw false-at-zero equation;
- inconsistency of the base-free principle if its admission condition is removed.

The interpretation of every binary symbol is arbitrary. No defining recursion
equations, successor laws, coverage, equality decision procedure, or arithmetic
induction principle is assumed in the logical equivalence theorem. The relevant
induction schemes occur as explicit hypotheses and conclusions.

## Constructive status

The file contains no `sorry`, `admit`, or invocation of `Classical`. The ten
printed endpoint audits all report no global axiom dependencies. In particular,
the proofs do not depend on propositional extensionality, choice, or quotient
soundness. Explicit induction-scheme hypotheses are not global axioms and are
visible in the theorem types.

## What is outside this file

This is a syntax-and-semantics verification of the normalization kernel. It is
not a formalization of a full first-order proof calculus or syntactic proof
transport. It does not implement the finite recursive-description grammar,
the compiler from ordinary primitive recursion to binary mixed recursion, the
reverse compiler, or the full bi-interpretation and its round-trip isomorphisms.
Those layers are addressed by the written mathematical argument and the
explicitly credited source construction.

No claim of an end-to-end Lean formalization of bi-interpretability follows
from this file.

## Reproduction

From this directory, with Lean 4.19.0 on the executable search path:

```sh
lean ReflexiveInduction.lean
```

The command should exit with status zero and print the ten statements recorded
in `lean-audit.txt`. A nonzero exit status or a `sorryAx` dependency is a failed
check even if other endpoints printed successfully.
