PRA WITH INDUCTION FROM A SYNTACTIC TAUTOLOGY
Prepared for Vladimir Reshetnikov - 1 November 2026

MAIN RESULT
A new constructive normalization replaces ordinary quantifier-free
induction by its base-free implication schema, admitted only when the
zero instance is literally B -> B. For any F, use F(0) -> F(n) to recover
the usual induction axiom. Combining this with the existing binary
initialized-recursion language gives a theory definitionally equivalent
to matching-logic first-order PRA, hence bi-interpretable and equiconsistent.

READ FIRST
  pra_reflexive_induction.pdf    Complete paper.
  pra_reflexive_induction.tex    Main LaTeX source.
  AXIOMS.txt                    Exact standalone specification.
  sections/arithmetic.tex       Complete internal pairing/compiler proof.
  sections/verification.tex     Verification scope and reproduction notes.

VERIFICATION
  formal/ReflexiveInduction.lean  New Lean syntax-level normalization proof.
  formal/lean-toolchain          Lean 4.19.0 pin.
  formal/SCOPE.md                Exact formalization boundary.
  formal/lean-audit.txt           Ten audited endpoints.
  artifacts/normalization_ast.py  Executable finite syntax and metric checks.
  artifacts/normalization_results.json  Reproducible output.
  source_manifest.json           Pinned source snapshot and hashes.
  audit/                         Review and build records.
  SHA256SUMS.txt                 Deliverable checksums.

HONEST COMPARISON
The current repository snapshot has eight archives, including a 42-node
fused full-formula display and an already proved binary recursion basis.
The new displayed schema scores 39 under the same partial node convention
at one induction parameter. It adds a decidable syntactic admission test.
The concrete normalized induction instances are LONGER; the displayed
saving is not a shorter full encoding, shorter proof, or global minimum.
Read the section "Exactly what becomes smaller" for the exact accounting.

The attempted counter-free pure-iteration reduction is NOT used or claimed.
No new end-to-end Lean bi-interpretation formalization is claimed: Lean
checks the normalization syntax/semantics. The arithmetic compiler and
both internal interpretation round trips are proved in the paper.

BUILD
Requirements: Python 3; pdflatex and standard TeX Live packages.
From this directory:
  python3 build.py

Optional fresh formal verification with Lean 4.19.0:
  python3 build.py --lean lean
or supply an absolute path to the Lean 4.19.0 executable.

The Python checks require only the standard library.
The LaTeX build uses no shell escape.
The build directory _build is temporary and is not part of the archive.

PROVENANCE
GitHub snapshot:
9feae3a8c33b807fa347f82a9e5127b2e2049823
https://github.com/VladimirReshetnikov/ProveIt/tree/9feae3a8c33b807fa347f82a9e5127b2e2049823/docs/drafts

The binary recursion grammar/compiler and older syntactic-base concept
are credited to the supplied drafts. The reflexive-implication normalization,
Lean syntax proof, syntax checker, and assembled report are new to this
package. No original draft archives are redistributed here.

