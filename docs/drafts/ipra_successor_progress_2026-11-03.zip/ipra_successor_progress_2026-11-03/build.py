#!/usr/bin/env python3
"""Rebuild the symbolic receipts and PDF with Python 3.10+ and pdfLaTeX."""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def main() -> None:
    root = Path(__file__).resolve().parent
    subprocess.run([sys.executable, str(root / "artifacts" / "verify.py")],
                   cwd=root, check=True)
    executable = shutil.which("pdflatex")
    if not executable:
        raise SystemExit("pdfLaTeX is required. Install a standard TeX Live distribution.")
    environment = dict(os.environ)
    environment.setdefault("SOURCE_DATE_EPOCH", "1793664000")
    environment.setdefault("FORCE_SOURCE_DATE", "1")
    messages: list[str] = []
    with tempfile.TemporaryDirectory(prefix="ipra_build_") as directory:
        build = Path(directory)
        for index in range(1, 4):
            result = subprocess.run(
                [executable, "-interaction=nonstopmode", "-halt-on-error",
                 "-output-directory=" + str(build), str(root / "report.tex")],
                cwd=root, env=environment, capture_output=True, text=True)
            if result.returncode:
                sys.stderr.write(result.stdout + result.stderr)
                raise SystemExit(result.returncode)
            messages = [line for line in result.stdout.splitlines()
                        if any(token in line for token in
                               ("Warning", "Overfull", "Underfull", "!"))]
        if messages:
            raise SystemExit("Final LaTeX pass has unresolved issues:\n" +
                             "\n".join(messages))
        shutil.copyfile(build / "report.pdf", root / "report.pdf")
    receipt = {
        "status": "passed",
        "latex_passes": 3,
        "unresolved_warnings_or_box_diagnostics": messages,
        "symbolic_checks": "artifacts/verification_results.json",
        "pdf": "report.pdf",
        "scope": "Build and finite symbolic checks; not a proof-assistant verification."
    }
    (root / "artifacts" / "build_results.json").write_text(
        json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
