#!/usr/bin/env python3
"""Finite symbolic checks for the successor-progress iPRA presentation.

Run with Python 3.10+; only the standard library is used.  Results are written
beside this file.  Terms and formulas are immutable trees.  Recursor descriptors
are frozen syntax, and neither active substitution nor active rewriting enters
them.  A descriptor is evaluated only when instantiating its defining successor
equation or explicitly checking its update for computational identity.

These checks are not a formal verification of iPRA, normalization for every
descriptor, the interpretation metatheorems, or the complete source audit.
They check finite symbolic examples, exact syntax counts, and a replayable
equational derivation.  A reduction budget is a failure guard, never a rule for
accepting an incompletely normalized term.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Mapping, Union


# ---------- Immutable syntax and binding ----------

@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Succ:
    arg: Term


@dataclass(frozen=True)
class Descriptor:
    body: Term
    parameters: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if len(set(self.parameters)) != len(self.parameters):
            raise ValueError("Repeated descriptor parameter slot")
        if {"v", "w"}.intersection(self.parameters):
            raise ValueError("State/counter slots cannot be parameter slots")
        allowed = {"v", "w", *self.parameters}
        if not term_fv(self.body).issubset(allowed):
            raise ValueError("Undeclared active descriptor variable")


@dataclass(frozen=True)
class Call:
    descriptor: Descriptor
    args: tuple[Term, ...]

    def __post_init__(self) -> None:
        if len(self.args) != 2 + len(self.descriptor.parameters):
            raise ValueError("Wrong recursor arity")


Term = Union[Var, Zero, Succ, Call]


@dataclass(frozen=True)
class Eq:
    left: Term
    right: Term


@dataclass(frozen=True)
class Bottom:
    pass


@dataclass(frozen=True)
class And:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Or:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Imp:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Forall:
    variable: str
    body: Formula


@dataclass(frozen=True)
class Exists:
    variable: str
    body: Formula


Formula = Union[Eq, Bottom, And, Or, Imp, Forall, Exists]
ZERO = Zero()


def term_fv(t: Term) -> set[str]:
    """Only active variables: raw descriptor slots are locally bound metadata."""
    if isinstance(t, Var):
        return {t.name}
    if isinstance(t, Zero):
        return set()
    if isinstance(t, Succ):
        return term_fv(t.arg)
    if isinstance(t, Call):
        return set().union(*(term_fv(a) for a in t.args))
    raise TypeError(t)


def formula_fv(f: Formula) -> set[str]:
    if isinstance(f, Eq):
        return term_fv(f.left) | term_fv(f.right)
    if isinstance(f, Bottom):
        return set()
    if isinstance(f, (And, Or, Imp)):
        return formula_fv(f.left) | formula_fv(f.right)
    if isinstance(f, (Forall, Exists)):
        return formula_fv(f.body) - {f.variable}
    raise TypeError(f)


def active_names(f: Formula) -> set[str]:
    """Includes quantifier names, to choose transparently fresh alpha names."""
    if isinstance(f, (Eq, Bottom)):
        return formula_fv(f)
    if isinstance(f, (And, Or, Imp)):
        return active_names(f.left) | active_names(f.right)
    if isinstance(f, (Forall, Exists)):
        return {f.variable} | active_names(f.body)
    raise TypeError(f)


def substitute_term(t: Term, sigma: Mapping[str, Term]) -> Term:
    """Simultaneous, capture-free active substitution; inserted terms stay whole."""
    if isinstance(t, Var):
        return sigma.get(t.name, t)
    if isinstance(t, Zero):
        return t
    if isinstance(t, Succ):
        return Succ(substitute_term(t.arg, sigma))
    if isinstance(t, Call):
        return Call(t.descriptor, tuple(substitute_term(a, sigma) for a in t.args))
    raise TypeError(t)


def substitute_formula(f: Formula, sigma: Mapping[str, Term]) -> Formula:
    if isinstance(f, Eq):
        return Eq(substitute_term(f.left, sigma), substitute_term(f.right, sigma))
    if isinstance(f, Bottom):
        return f
    if isinstance(f, (And, Or, Imp)):
        return type(f)(substitute_formula(f.left, sigma),
                       substitute_formula(f.right, sigma))
    if isinstance(f, (Forall, Exists)):
        inner = {k: t for k, t in sigma.items() if k != f.variable}
        relevant = {k: t for k, t in inner.items() if k in formula_fv(f.body)}
        entering = set().union(*(term_fv(t) for t in relevant.values()))
        variable, body = f.variable, f.body
        if variable in entering:
            forbidden = active_names(body) | entering | set(inner)
            for i in range(len(forbidden) + 1):
                candidate = f"{variable}_{i}"
                if candidate not in forbidden:
                    variable = candidate
                    break
            else:
                raise AssertionError("Fresh-name generation failed")
            body = substitute_formula(body, {f.variable: Var(variable)})
        return type(f)(variable, substitute_formula(body, inner))
    raise TypeError(f)


def numeral(n: int) -> Term:
    if n < 0:
        raise ValueError("Negative numeral")
    t: Term = ZERO
    for _ in range(n):
        t = Succ(t)
    return t


def successors(n: int, t: Term) -> Term:
    if n < 0:
        raise ValueError("Negative successor count")
    for _ in range(n):
        t = Succ(t)
    return t


def universal_close(names: tuple[str, ...], f: Formula) -> Formula:
    for name in reversed(names):
        f = Forall(name, f)
    return f


# ---------- Counts charge each repeated occurrence, including raw labels ----------

def term_size(t: Term) -> int:
    if isinstance(t, (Var, Zero)):
        return 1
    if isinstance(t, Succ):
        return 1 + term_size(t.arg)
    if isinstance(t, Call):
        return 1 + term_size(t.descriptor.body) + sum(map(term_size, t.args))
    raise TypeError(t)


def formula_size(f: Formula) -> int:
    if isinstance(f, Eq):
        return 1 + term_size(f.left) + term_size(f.right)
    if isinstance(f, Bottom):
        return 1
    if isinstance(f, (And, Or, Imp)):
        return 1 + formula_size(f.left) + formula_size(f.right)
    if isinstance(f, (Forall, Exists)):
        return 1 + formula_size(f.body)
    raise TypeError(f)


def occurrences(t: Term, variable: str) -> int:
    if isinstance(t, Var):
        return int(t.name == variable)
    if isinstance(t, Zero):
        return 0
    if isinstance(t, Succ):
        return occurrences(t.arg, variable)
    if isinstance(t, Call):
        return sum(occurrences(a, variable) for a in t.args)
    raise TypeError(t)


# ---------- Ordinary defining-equation rewriting, in active contexts only ----------

class ReductionLimitExceeded(RuntimeError):
    pass


def root_contract(t: Term) -> tuple[str, Term] | None:
    if not isinstance(t, Call):
        return None
    counter, initial, *parameters = t.args
    if isinstance(counter, Zero):
        return "base", initial
    if isinstance(counter, Succ):
        lower = Call(t.descriptor, (counter.arg, initial, *parameters))
        sigma = {"v": lower, "w": counter.arg}
        sigma.update(zip(t.descriptor.parameters, parameters))
        return "successor", substitute_term(t.descriptor.body, sigma)
    return None


def children(t: Term) -> tuple[Term, ...]:
    if isinstance(t, Succ):
        return (t.arg,)
    if isinstance(t, Call):
        return t.args
    return ()


def at_path(t: Term, path: tuple[int, ...]) -> Term:
    for index in path:
        cs = children(t)
        if not 0 <= index < len(cs):
            raise AssertionError("Invalid active path")
        t = cs[index]
    return t


def replace_path(t: Term, path: tuple[int, ...], replacement: Term) -> Term:
    if not path:
        return replacement
    index, *tail = path
    cs = list(children(t))
    if not 0 <= index < len(cs):
        raise AssertionError("Invalid active replacement path")
    cs[index] = replace_path(cs[index], tuple(tail), replacement)
    if isinstance(t, Succ):
        return Succ(cs[0])
    if isinstance(t, Call):
        return Call(t.descriptor, tuple(cs))
    raise AssertionError("Leaf cannot contain active children")


def find_redex(t: Term, prefix: tuple[int, ...] = ()):
    contraction = root_contract(t)
    if contraction is not None:
        rule, result = contraction
        return prefix, rule, t, result
    for i, child in enumerate(children(t)):
        found = find_redex(child, prefix + (i,))
        if found is not None:
            return found
    return None


def normalize(t: Term, max_steps: int = 100_000) -> tuple[Term, list[dict]]:
    if max_steps < 0:
        raise ValueError("Negative reduction budget")
    trace: list[dict] = []
    while True:
        found = find_redex(t)
        if found is None:
            return t, trace
        if len(trace) == max_steps:
            raise ReductionLimitExceeded(
                f"Term still has a redex after {max_steps} permitted steps")
        path, rule, before, after = found
        changed = replace_path(t, path, after)
        trace.append({
            "path": list(path), "rule": rule,
            "redex_before": encode_term(before),
            "redex_after": encode_term(after),
            "whole_size_before": term_size(t),
            "whole_size_after": term_size(changed),
        })
        t = changed


@lru_cache(maxsize=None)
def computational_identity(d: Descriptor) -> bool:
    normal, _ = normalize(d.body)
    return normal == Var("v")


def erase_term(t: Term) -> Term:
    if isinstance(t, (Var, Zero)):
        return t
    if isinstance(t, Succ):
        return Succ(erase_term(t.arg))
    if isinstance(t, Call):
        if computational_identity(t.descriptor):
            return erase_term(t.args[1])
        return Call(t.descriptor, tuple(erase_term(a) for a in t.args))
    raise TypeError(t)


def erase_formula(f: Formula) -> Formula:
    if isinstance(f, Eq):
        return Eq(erase_term(f.left), erase_term(f.right))
    if isinstance(f, Bottom):
        return f
    if isinstance(f, (And, Or, Imp)):
        return type(f)(erase_formula(f.left), erase_formula(f.right))
    if isinstance(f, (Forall, Exists)):
        return type(f)(f.variable, erase_formula(f.body))
    raise TypeError(f)


# ---------- Machine-readable trees and an independent local trace checker ----------

def encode_term(t: Term):
    if isinstance(t, Var):
        return {"var": t.name}
    if isinstance(t, Zero):
        return {"zero": True}
    if isinstance(t, Succ):
        return {"successor": encode_term(t.arg)}
    if isinstance(t, Call):
        return {"recursor": {
            "parameters": list(t.descriptor.parameters),
            "raw_body": encode_term(t.descriptor.body)},
            "arguments": [encode_term(a) for a in t.args]}
    raise TypeError(t)


def decode_term(data) -> Term:
    if set(data) == {"var"}:
        return Var(data["var"])
    if set(data) == {"zero"} and data["zero"] is True:
        return ZERO
    if set(data) == {"successor"}:
        return Succ(decode_term(data["successor"]))
    if set(data) == {"recursor", "arguments"}:
        raw = data["recursor"]
        if set(raw) != {"parameters", "raw_body"}:
            raise ValueError("Malformed raw descriptor")
        d = Descriptor(decode_term(raw["raw_body"]), tuple(raw["parameters"]))
        return Call(d, tuple(decode_term(a) for a in data["arguments"]))
    raise ValueError("Malformed term")


def replay_instantiate(body: Term, slots: Mapping[str, Term]) -> Term:
    """Independent RHS instantiation: does not call the normalizer/substituter."""
    if type(body) is Var:
        return slots.get(body.name, body)
    if type(body) is Zero:
        return body
    if type(body) is Succ:
        return Succ(replay_instantiate(body.arg, slots))
    if type(body) is Call:
        values = tuple(replay_instantiate(a, slots) for a in body.args)
        return Call(body.descriptor, values)
    raise AssertionError("Unknown term in local proof checker")


def verify_reduction_trace(proof: dict) -> Term:
    """Check each displayed equation locally; never invoke normalization."""
    current = decode_term(proof["original"])
    for i, step in enumerate(proof["steps"]):
        path = tuple(step["path"])
        focus = at_path(current, path)
        if focus != decode_term(step["redex_before"]):
            raise AssertionError(f"Wrong recorded redex at step {i}")
        if not isinstance(focus, Call):
            raise AssertionError(f"Non-recursor redex at step {i}")
        counter, initial, *parameters = focus.args
        if step["rule"] == "base":
            if not isinstance(counter, Zero):
                raise AssertionError("Base equation applied at a nonzero syntax")
            expected = initial
        elif step["rule"] == "successor":
            if not isinstance(counter, Succ):
                raise AssertionError("Successor equation applied at wrong syntax")
            lower = Call(focus.descriptor, (counter.arg, initial, *parameters))
            slots = dict(zip(focus.descriptor.parameters, parameters))
            slots["v"], slots["w"] = lower, counter.arg
            expected = replay_instantiate(focus.descriptor.body, slots)
        else:
            raise AssertionError("Unknown equational rule")
        supplied = decode_term(step["redex_after"])
        if supplied != expected:
            raise AssertionError(f"Wrong defining-equation RHS at step {i}")
        if term_size(current) != step["whole_size_before"]:
            raise AssertionError("Wrong before-size")
        current = replace_path(current, path, supplied)
        if term_size(current) != step["whole_size_after"]:
            raise AssertionError("Wrong after-size")
    if current != decode_term(proof["result"]):
        raise AssertionError("Incorrect claimed final term")
    return current


def show_term(t: Term) -> str:
    if isinstance(t, Var):
        return t.name
    if isinstance(t, Zero):
        return "0"
    if isinstance(t, Succ):
        return "S(" + show_term(t.arg) + ")"
    if isinstance(t, Call):
        parameters = ",".join(t.descriptor.parameters)
        label = show_term(t.descriptor.body)
        args = ",".join(show_term(a) for a in t.args)
        return f"R[body={label};params=({parameters})]({args})"
    raise TypeError(t)


def show_formula(f: Formula) -> str:
    if isinstance(f, Eq):
        return f"({show_term(f.left)}={show_term(f.right)})"
    if isinstance(f, Bottom):
        return "FALSE"
    if isinstance(f, (And, Or, Imp)):
        op = {And: "AND", Or: "OR", Imp: "->"}[type(f)]
        return f"({show_formula(f.left)} {op} {show_formula(f.right)})"
    if isinstance(f, (Forall, Exists)):
        op = "forall" if isinstance(f, Forall) else "exists"
        return f"({op} {f.variable}. {show_formula(f.body)})"
    raise TypeError(f)


def computation_module(d: Descriptor) -> Formula:
    a, n = Var("a"), Var("n")
    names = tuple(f"c{i+1}" for i in range(len(d.parameters)))
    parameters = tuple(map(Var, names))
    lower = Call(d, (n, a, *parameters))
    sigma = {"v": lower, "w": n, **dict(zip(d.parameters, parameters))}
    return universal_close(("a", *names), And(
        Eq(Call(d, (ZERO, a, *parameters)), a),
        Forall("n", Eq(Call(d, (Succ(n), a, *parameters)),
                       substitute_term(d.body, sigma)))))


def closure_formulas(equation: Eq, parameters: tuple[str, ...]):
    x = Var("x")
    p = Or(Eq(x, ZERO), equation)
    next_equation = substitute_formula(equation, {"x": Succ(x)})
    old_step = Forall("x", Imp(p, Or(Eq(Succ(x), ZERO), next_equation)))
    new_step = Forall("x", Imp(p, next_equation))
    conclusion = Forall("x", p)
    return (universal_close(parameters, Imp(old_step, conclusion)),
            universal_close(parameters, Imp(new_step, conclusion)))


def expect_assertion(fn) -> None:
    try:
        fn()
    except AssertionError:
        return
    raise AssertionError("Invalid proof unexpectedly accepted")


def main() -> None:
    v, w = Var("v"), Var("w")
    q = Descriptor(w)
    addition = Descriptor(Succ(v))
    selector = Descriptor(Var("c1"), ("c1",))
    stride7 = Descriptor(successors(7, v))

    def predecessor(t: Term) -> Term:
        return Call(q, (t, ZERO))

    def block(k: int) -> Term:
        t: Term = Call(stride7, (numeral(k), v))
        for _ in range(7 * k):
            t = predecessor(t)
        return t

    controls = {
        "Q_counter_update": q,
        "A_successor_update": addition,
        "C_parameter_update": selector,
        "stride7_update": stride7,
        "zero_update": Descriptor(ZERO),
        "counter_only_successor": Descriptor(Succ(w)),
        "parameter_only_successor": Descriptor(Succ(Var("c1")), ("c1",)),
    }
    for name, d in controls.items():
        if computational_identity(d):
            raise AssertionError(f"Incorrectly erased support/control {name}")
    assert computational_identity(Descriptor(v))
    assert computational_identity(Descriptor(v, ("c1", "c2")))

    # Frozen descriptor redexes remain untouched in an active stuck application.
    frozen = Descriptor(Call(q, (Succ(v), ZERO)))
    stuck = Call(frozen, (Var("x"), Var("a")))
    stuck_nf, stuck_steps = normalize(stuck)
    assert stuck_nf == stuck and not stuck_steps
    assert isinstance(stuck_nf, Call) and stuck_nf.descriptor is frozen
    changed = substitute_term(stuck, {"x": Succ(Var("v")), "v": ZERO})
    assert changed.descriptor is frozen and changed.descriptor.body == frozen.body
    assert changed.args[0] == Succ(v)  # inserted v must not be substituted again
    assert normalize(frozen.body)[0] == v

    # A descriptor-local x is not the external x, and substitution is simultaneous.
    local_x = Descriptor(Var("x"), ("x",))
    term_with_local_x = Call(local_x, (Var("x"), ZERO, Var("a")))
    renamed = substitute_term(term_with_local_x, {"x": Var("y"), "a": Var("x")})
    assert renamed.descriptor is local_x
    assert renamed.args == (Var("y"), ZERO, Var("x"))
    assert occurrences(term_with_local_x, "x") == 1
    assert term_fv(term_with_local_x) == {"x", "a"}
    alpha_test = substitute_formula(Forall("y", Eq(Var("x"), Var("y"))),
                                    {"x": Var("y")})
    assert isinstance(alpha_test, Forall) and alpha_test.variable != "y"
    assert formula_fv(alpha_test) == {"y"}
    assert alpha_test.body == Eq(Var("y"), Var(alpha_test.variable))
    assert substitute_formula(Forall("x", Eq(Var("x"), Var("z"))),
                              {"x": ZERO}) == Forall("x", Eq(Var("x"), Var("z")))

    stride_rows = []
    replay_proof = None
    for k in range(2, 13):
        body = block(k)
        d = Descriptor(body)
        call = Call(d, (Var("n"), Var("a")))
        module = computation_module(d)
        image = erase_formula(module)
        normal, steps = normalize(body)
        assert normal == v and computational_identity(d)
        measured = {
            "body": term_size(body), "call": term_size(call),
            "ordinary_module": formula_size(module),
            "literal_image_module": formula_size(image),
        }
        expected = {"body": 22 * k + 11, "call": 22 * k + 14,
                    "ordinary_module": 88 * k + 59,
                    "literal_image_module": 22 * k + 19}
        assert measured == expected
        assert erase_term(call) == Var("a")
        # Check the residual clause is present, not silently discarded.
        residual = substitute_term(body, {"v": Var("a"), "w": Var("n")})
        explicit_image = Forall("a", And(Eq(Var("a"), Var("a")),
                                          Forall("n", Eq(Var("a"), residual))))
        assert image == explicit_image
        stride_rows.append({"k": k, "sizes": measured, "rewrite_steps": len(steps),
                            "normal_form": "v", "ordinary_module_saving": 66*k+40})
        if k == 2:
            replay_proof = {
                "format": "active-defining-equation-trace-v1",
                "description": "p^14(G7(S(S(0)),v)) = v; all labels are raw syntax",
                "rules": "R_h(0,a,c)=a; R_h(Sn,a,c)=h(R_h(n,a,c),n,c)",
                "path_convention": "0 is the child of S; recursor indices address actual arguments only",
                "original": encode_term(body), "result": encode_term(normal), "steps": steps,
            }

    assert replay_proof is not None
    assert verify_reduction_trace(replay_proof) == v
    bad_rhs = json.loads(json.dumps(replay_proof))
    bad_rhs["steps"][0]["redex_after"] = encode_term(ZERO)
    expect_assertion(lambda: verify_reduction_trace(bad_rhs))
    bad_result = json.loads(json.dumps(replay_proof))
    bad_result["result"] = encode_term(ZERO)
    expect_assertion(lambda: verify_reduction_trace(bad_result))
    truncated = json.loads(json.dumps(replay_proof))
    truncated["steps"].pop()
    expect_assertion(lambda: verify_reduction_trace(truncated))
    try:
        normalize(block(2), max_steps=0)
    except ReductionLimitExceeded:
        pass
    else:
        raise AssertionError("Reduction budget exhaustion was silently accepted")

    x, a, b = Var("x"), Var("a"), Var("b")
    equations = [
        ("reflexive", Eq(x, x)),
        ("probe_independent", Eq(ZERO, ZERO)),
        ("one_probe", Eq(x, ZERO)),
        ("one_parameter", Eq(Succ(x), a)),
        ("addition_and_two_probes", Eq(Call(addition, (x, a)), x)),
        ("two_parameters", Eq(Call(selector, (x, a, b)), Call(q, (x, ZERO)))),
        ("descriptor_local_x_is_frozen", Eq(term_with_local_x, a)),
        ("large_raw_descriptor_expression", Eq(substitute_term(block(2), {"v": x}), x)),
    ]
    formula_rows = []
    for name, equation in equations:
        for vacuous_count in (0, 1, 3):
            parameter_names = tuple(sorted(formula_fv(equation) - {"x"}))
            parameter_names += tuple(f"unused{i+1}" for i in range(vacuous_count))
            old, new = closure_formulas(equation, parameter_names)
            f = formula_size(equation)
            k = occurrences(equation.left, "x") + occurrences(equation.right, "x")
            p = len(parameter_names)
            assert not formula_fv(old) and not formula_fv(new)
            assert formula_size(substitute_formula(equation, {"x": Succ(x)})) == f+k
            assert formula_size(old) == 3*f+k+p+17
            assert formula_size(new) == 3*f+k+p+12
            assert formula_size(old)-formula_size(new) == 5
            formula_rows.append({
                "case": name, "parameters": parameter_names,
                "equation_size_F": f, "active_probe_occurrences_k": k,
                "parameter_count_p": p, "old_Z_size": formula_size(old),
                "successor_progress_ZE_size": formula_size(new), "saving": 5,
                "old_Z_closed": True, "ZE_closed": True,
                "equation": show_formula(equation),
                "old_Z": show_formula(old), "ZE": show_formula(new),
            })

    # Several nontrivial actual argument trees: erasure keeps only the initializer.
    argument_terms = [ZERO, v, successors(3, v), Call(addition, (v, numeral(2)))]
    erasure_samples = 0
    d2 = Descriptor(block(2))
    for counter in argument_terms:
        for initial in argument_terms:
            term = Call(d2, (counter, initial))
            assert term_size(erase_term(term)) <= term_size(term)
            assert erase_term(term) == erase_term(initial)
            erasure_samples += 1

    directory = Path(__file__).resolve().parent
    summary = {
        "status": "all finite checks passed",
        "scope": [
            "Finite symbolic defining-equation normalization for stride 7 and k=2,...,12.",
            "Exact occurrence counts on immutable ASTs, with repeated frozen labels charged in full.",
            "A local replay checker validates every equation step without calling the normalizer.",
            "24 fully universally closed old-Z/ZE formulas with arbitrary and vacuous parameters.",
            "Active substitution, alpha-renaming, descriptor freezing, and erasure negative controls.",
            "These checks are not a proof-assistant formalization or a proof of the general metatheorems.",
        ],
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "stride7_cases": stride_rows,
        "formula_count_cases": len(formula_rows),
        "five_node_saving_in_every_formula_case": True,
        "trace_replayed": True,
        "trace_steps_k2": len(replay_proof["steps"]),
        "invalid_trace_negative_controls": 3,
        "budget_exhaustion_raises": True,
        "constructor_and_nonidentity_controls_retained": list(controls),
        "identity_update_erased_with_and_without_unused_parameters": True,
        "descriptor_freeze_checks_passed": True,
        "capture_avoidance_checks_passed": True,
        "erasure_actual_argument_samples": erasure_samples,
    }
    outputs = {
        "verification_results.json": summary,
        "stride7_trace_k2.json": replay_proof,
        "formula_count_checks.json": {"counting_convention":
            "One node per variable, constant, application, equality, connective, individual quantifier; "
            "each recursor application also pays its entire raw descriptor body.",
            "old_Z_formula": "forall c ((forall x ((x=0 or E(x))->(Sx=0 or E(Sx)))) -> forall x (x=0 or E(x)))",
            "ZE_formula": "forall c ((forall x ((x=0 or E(x))->E(Sx))) -> forall x (x=0 or E(x)))",
            "cases": formula_rows},
    }
    for name, data in outputs.items():
        (directory / name).write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": summary["status"], "stride7_cases": len(stride_rows),
                      "formula_cases": len(formula_rows),
                      "replayed_steps_k2": len(replay_proof["steps"]),
                      "outputs": list(outputs)}, indent=2))


if __name__ == "__main__":
    main()
