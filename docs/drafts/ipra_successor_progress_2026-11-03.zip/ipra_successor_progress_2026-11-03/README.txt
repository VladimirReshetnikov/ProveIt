A SMALLER EXPLICIT PRESENTATION OF INTUITIONISTIC PRA
3 November 2026
===================================================

Read report.pdf for the complete report, or report.tex for its source.
SPECIFICATION.txt gives the standalone formal specification in plain text.

MAIN RESULTS

1. A complete intuitionistic first-order equality calculus is specified,
   including every logical rule, equality rule, and eigenvariable condition.

2. The readable arithmetic theory has one separation axiom, ordinary
   initialized recursion, and one successor-progress rule for equations:

       Gamma, z=0 OR E(z,c) |- E(Sz,c)
       --------------------------------
       Gamma |- u=0 OR E(u,c)

   z is fresh for Gamma, u, and the numerical parameter variables c.
   This is equivalent to the current equation-closure theory and removes
   exactly five nodes per expanded closure axiom. It derives coverage,
   full quantifier-free induction, and both iPRA identity round trips.

3. A uniform computation criterion erases R_h when the ordinary raw
   computation normal form of h(v,w,c) is literally v. The reduced
   standalone theory may omit erased recursion modules: their residual
   clauses have a purely equational derivation from retained lower-rank
   computation modules. This is proved, not assumed.

4. For each current generated-Q exact presentation, its exact axiom image under
   the same erasure is bi-interpretable and has no larger finite packets.
   All earlier source optimizations and paid notation remain in place.
   The comparison is source-relative; it is not a claim that one interface
   simultaneously achieves every componentwise minimum.

IMPORTANT SCOPE

The target is full first-order intuitionistic PRA, with genuine falsity,
all ordinary connectives and quantifiers, and quantifier-free induction
with arbitrary finite tuples of number parameters. It is not classical
PRA or just an equational fragment. Both carrier maps are the identity,
and the proofs apply to nonstandard elements.

No absolute shortestness result is claimed. The ordinary five-node
improvement does not uniformly dominate the drafts' compressed notation.
The full metatheoretic normalizer is externally computable; no uniform
primitive-recursive runtime or iPRA-internal totality is claimed. The
arithmetic identity in the stride-seven example was already covered by
the drafts' general block lemma; the new result is the uniform erasure
criterion and justified omission of residual modules.

REPRODUCING

  python3 artifacts/verify.py
  python3 build.py

The first command uses only Python 3.10+ and its standard library.
The second also needs pdfLaTeX with ordinary TeX Live packages, including
amsmath, amsthm, mathtools, lmodern, microtype, enumitem, mdframed, and
hyperref. It runs three LaTeX passes and rejects unresolved warnings or
box diagnostics. The supplied PDF was also rendered and visually reviewed.

ARTIFACTS

  report.tex / report.pdf       Full specification, proofs, comparisons,
                               limits, and further research questions.
  SPECIFICATION.txt             Exact standalone calculus and theories.
  artifacts/verify.py            Immutable AST checker and local proof replay.
  artifacts/verification_results.json
                               Symbolic checks and explicit scope.
  artifacts/formula_count_checks.json
                               Complete old/new formula-size checks.
  artifacts/stride7_trace_k2.json
                               Replayable 17-step equational certificate.
  artifacts/build_results.json  Compilation receipt.
  artifacts/validation.json     Final package validation and review scope.
  provenance/source_manifest.json
                               Pinned source names, Git blobs, byte hashes.
  provenance/audit.txt          Comparison decisions and exact claim scope.
  SHA256SUMS.txt                 Checksums of the delivered package files.

SOURCE SNAPSHOT

VladimirReshetnikov/ProveIt
5753b3f955eb6681b6f89f5d778fda2b7ec8f87a

The four archives actually present in docs/drafts at this commit are
equation_closure, inverse_iteration, retraction, and successor_transport,
all dated 2026-11-03. Every input ZIP's size and Git blob hash were verified.

The Python checks are finite symbolic diagnostics with independent local
trace replay. They are not a Lean/Rocq formalization of the entire
arithmetic reconstruction or interpretation metatheorem.
