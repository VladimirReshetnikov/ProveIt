#!/usr/bin/env python3
"""Finite syntax audit for counter recursion with a fixed-point probe.

Python 3.10+, standard library only. Run from any directory; results.json
and examples.txt are written beside this script.

PROVENANCE / REUSE
The immutable two-level syntax design, frozen-descriptor substitution,
capture avoidance, and malformed-input controls adapt the counter-recursion
draft's checks/check_schema.py, retrieved from VladimirReshetnikov/ProveIt
at commit 5ffc596c844086fc26509685c7833b548ebf25c3, archive
docs/drafts/pra_counter_recursion_2026-11-01.zip, Git blob
59dc49b0e805f5aa489a373485a67c0505678752. The new constructors, independent
active/inclusive counts, larger deterministic corpus, shared-cost ledger,
and orientation audit were written for the present comparison.

BOUNDARY
These are finite syntax and exact integer-accounting checks. They do not
prove consistency, the infinite schema's logical strength, the diagonal
lemma, or bi-interpretability. Those require the written mathematical proof.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import random


@dataclass(frozen=True)
class Term:
    kind: str
    children: tuple[Term, ...] = ()
    variable: str = ""
    descriptor: Term | None = None


@dataclass(frozen=True)
class Formula:
    kind: str
    children: tuple[Formula | Term, ...] = ()
    binder: str = ""


def variable(name):
    return Term("variable", variable=name)


ZERO = Term("zero")
N, A, V, W = (variable(x) for x in ("n", "a", "v", "w"))


def successor(term):
    return Term("successor", (term,))


ONE = successor(ZERO)


def recursor(body, counter, seed):
    return Term("recursor", (counter, seed), descriptor=body)


def substitute(term, replacements):
    """Simultaneous ACTIVE substitution; descriptor objects are retained."""
    if term.kind == "variable":
        return replacements.get(term.variable, term)
    return Term(term.kind,
                tuple(substitute(c, replacements) for c in term.children),
                term.variable, term.descriptor)


def free_term(term):
    if term.kind == "variable":
        return {term.variable}
    return set().union(*(free_term(c) for c in term.children))


def validate_term(term, allowed, active_path=None):
    """Reject bad arities, captured body variables, and cyclic syntax."""
    active_path = set() if active_path is None else active_path
    if id(term) in active_path:
        raise ValueError("Cyclic term or descriptor")
    active_path.add(id(term))
    try:
        arities = {"zero": 0, "variable": 0, "successor": 1, "recursor": 2}
        if term.kind not in arities or len(term.children) != arities[term.kind]:
            raise ValueError("Invalid constructor or arity")
        if term.kind == "variable" and term.variable not in allowed:
            raise ValueError("Illegal active variable")
        if term.kind == "recursor":
            if term.descriptor is None:
                raise ValueError("Missing descriptor")
            validate_term(term.descriptor, {"v", "w"}, active_path)
        elif term.descriptor is not None:
            raise ValueError("Descriptor attached to a primitive symbol")
        for child in term.children:
            validate_term(child, allowed, active_path)
    finally:
        active_path.remove(id(term))


def term_size(term, include_descriptors=False):
    count = 1 + sum(term_size(c, include_descriptors) for c in term.children)
    if include_descriptors and term.descriptor is not None:
        count += term_size(term.descriptor, True)
    return count


def occurrences(term, name):
    return int(term.kind == "variable" and term.variable == name) + sum(
        occurrences(c, name) for c in term.children)


def term_rank(term):
    ranks = [0, *(term_rank(c) for c in term.children)]
    if term.descriptor is not None:
        ranks.append(1 + term_rank(term.descriptor))
    return max(ranks)


def equal(left, right):
    return Formula("equal", (left, right))


def binary(kind, left, right):
    return Formula(kind, (left, right))


def forall(name, body):
    return Formula("forall", (body,), name)


FALSE = Formula("false")
SIGMA = binary("implies", equal(ZERO, ONE), FALSE)
# p(v)=R_w(v,0) is a term, not a new primitive function symbol.
PRED_BODY = recursor(W, V, ZERO)
DIAG_MATRIX = equal(recursor(PRED_BODY, N, successor(N)), ONE)
DIAG = forall("n", DIAG_MATRIX)


def formula_size(formula, include_descriptors=False):
    return 1 + sum(
        term_size(c, include_descriptors) if isinstance(c, Term)
        else formula_size(c, include_descriptors)
        for c in formula.children)


def free_formula(formula):
    names = set().union(*(
        free_term(c) if isinstance(c, Term) else free_formula(c)
        for c in formula.children))
    return names - {formula.binder} if formula.kind == "forall" else names


def active_names(formula):
    names = set().union(*(
        free_term(c) if isinstance(c, Term) else active_names(c)
        for c in formula.children))
    if formula.kind == "forall":
        names.add(formula.binder)
    return names


def substitute_formula(formula, replacements):
    """Capture-avoiding active substitution, respecting shadowed binders."""
    if formula.kind == "forall":
        body, bound = formula.children[0], formula.binder
        remaining = {key: value for key, value in replacements.items()
                     if key != bound}
        relevant = {key: value for key, value in remaining.items()
                    if key in free_formula(body)}
        if any(bound in free_term(value) for value in relevant.values()):
            used = active_names(body) | set(remaining)
            for value in remaining.values():
                used.update(free_term(value))
            index = 0
            while f"{bound}_{index}" in used:
                index += 1
            fresh = f"{bound}_{index}"
            body = substitute_formula(body, {bound: variable(fresh)})
            bound = fresh
        return forall(bound, substitute_formula(body, remaining))
    return Formula(formula.kind, tuple(
        substitute(c, replacements) if isinstance(c, Term)
        else substitute_formula(c, replacements)
        for c in formula.children), formula.binder)


def quantifier_profile(formula, nesting=0):
    here = int(formula.kind == "forall")
    depth = nesting + here
    count, maximum = here, depth
    for child in formula.children:
        if isinstance(child, Formula):
            child_count, child_depth = quantifier_profile(child, depth)
            count += child_count
            maximum = max(maximum, child_depth)
    return count, maximum


def formula_rank(formula):
    return max([0, *(term_rank(c) if isinstance(c, Term) else formula_rank(c)
                     for c in formula.children)])


def validate_formula(formula, bound=frozenset()):
    if formula.kind == "false":
        if formula.children:
            raise ValueError("False has no arguments")
    elif formula.kind == "equal":
        if len(formula.children) != 2:
            raise ValueError("Equality has two terms")
        for child in formula.children:
            if not isinstance(child, Term):
                raise ValueError("Equality argument is not a term")
            validate_term(child, bound)
    elif formula.kind == "forall":
        if len(formula.children) != 1 or not formula.binder:
            raise ValueError("Malformed quantifier")
        validate_formula(formula.children[0], bound | {formula.binder})
    elif formula.kind in {"and", "or", "implies"}:
        if len(formula.children) != 2:
            raise ValueError("Binary connective needs two arguments")
        for child in formula.children:
            if not isinstance(child, Formula):
                raise ValueError("Connective argument is not a formula")
            validate_formula(child, bound)
    else:
        raise ValueError("Unknown logical constructor")


def computation(term):
    body = substitute(term, {"n": V, "a": W})
    seed = equal(recursor(body, ZERO, A), A)
    step = equal(recursor(body, successor(N), A), substitute(
        term, {"n": recursor(body, N, A), "a": N}))
    return binary("and", seed, step)


def adjacent_fragments(term, swapped=False):
    if swapped:
        equation = equal(term, substitute(term, {"n": successor(N)}))
        root = binary("or", equal(A, ZERO), equation)
        next_equation = substitute_formula(equation, {"a": successor(A)})
        premise = forall("a", binary("implies", root, next_equation))
    else:
        equation = equal(term, substitute(term, {"a": successor(A)}))
        root = binary("or", equal(N, ZERO), equation)
        next_equation = substitute_formula(equation, {"n": successor(N)})
        premise = forall("n", binary("implies", root, next_equation))
    return root, premise


def fixedpoint_fragments(term):
    root = binary("or", equal(N, ZERO), equal(term, N))
    next_equation = equal(substitute(term, {"n": successor(N)}), successor(N))
    premise = forall("n", binary("implies", root, next_equation))
    return root, premise


def old_schema(term, factored=False, swapped=False):
    validate_term(term, {"n", "a"})
    payload = computation(term)
    if not factored:
        payload = binary("and", SIGMA, payload)
    root, premise = adjacent_fragments(term, swapped)
    return forall("a", forall("n", binary("and", payload,
        binary("implies", premise, root))))


def new_schema(term, factored=False):
    validate_term(term, {"n", "a"})
    payload = computation(term)
    if not factored:
        payload = binary("and", SIGMA, binary("and", DIAG_MATRIX, payload))
    root, premise = fixedpoint_fragments(term)
    return forall("a", forall("n", binary("and", payload,
        binary("implies", premise, root))))


def adaptive_schema(term):
    return old_schema(term, swapped=occurrences(term, "a") > occurrences(term, "n"))


def adaptive_padding(term):
    """Finite syntactic padding from the written orientation proof."""
    k = max(occurrences(term, "a") - occurrences(term, "n"), 0)
    seed = ZERO
    for _ in range(k):
        seed = recursor(W, successor(N), seed)
    return recursor(W, successor(term), seed), k


def counter_projection_step(term):
    """One exact instance of R_w(S(x),y)=x; not a semantic evaluator."""
    if (term.kind != "recursor" or term.descriptor != W
            or term.children[0].kind != "successor"):
        raise ValueError("Not an instance of the counter-projection step")
    return term.children[0].children[0]


def term_text(term):
    if term.kind == "variable":
        return term.variable
    if term.kind == "zero":
        return "0"
    if term.kind == "successor":
        return "S(" + term_text(term.children[0]) + ")"
    return ("R[" + term_text(term.descriptor) + "](" +
            ",".join(term_text(c) for c in term.children) + ")")


def formula_text(formula):
    if formula.kind == "false":
        return "false"
    if formula.kind == "equal":
        return "(" + "=".join(term_text(c) for c in formula.children) + ")"
    if formula.kind == "forall":
        return "forall " + formula.binder + " (" + formula_text(formula.children[0]) + ")"
    symbol = {"and": " AND ", "or": " OR ", "implies": " -> "}[formula.kind]
    return "(" + symbol.join(formula_text(c) for c in formula.children) + ")"


SIX_INPUTS = (ZERO, N, A, ONE, successor(N), successor(A))


def generate_inputs(target=5000):
    """Deterministic distinct corpus, including descriptors inside descriptors."""
    descriptors = [V, W, ZERO, successor(V), successor(W), PRED_BODY,
        recursor(W, V, W), recursor(successor(V), W, V),
        recursor(recursor(W, V, W), V, W),
        recursor(PRED_BODY, recursor(W, V, W), successor(V)),
        recursor(recursor(PRED_BODY, V, W), successor(W), V)]
    terms = dict.fromkeys(SIX_INPUTS)
    for descriptor in descriptors:
        for counter in SIX_INPUTS:
            for seed in SIX_INPUTS:
                terms[recursor(descriptor, counter, seed)] = None
    rng = random.Random(20261102)

    def generated(depth):
        if depth == 0 or rng.randrange(5) == 0:
            return rng.choice([ZERO, N, A])
        if rng.randrange(4) == 0:
            return successor(generated(depth - 1))
        return recursor(rng.choice(descriptors),
                        generated(depth - 1), generated(depth - 1))

    while len(terms) < target:
        terms[generated(rng.choice([3, 4, 5]))] = None
    return list(terms)


CHECKS = Counter()


def require(group, assertion):
    if not assertion:
        raise AssertionError(group)
    CHECKS[group] += 1


def reject(term):
    try:
        validate_term(term, {"n", "a"})
    except ValueError:
        require("malformed_terms_rejected", True)
    else:
        raise AssertionError("Malformed term admitted")


def record(term):
    m, i, j = term_size(term), occurrences(term, "n"), occurrences(term, "a")
    width = term_size(term, True)
    return {
        "term": term_text(term), "m": m, "i": i, "j": j, "W": width,
        "old_primary_active": formula_size(old_schema(term)),
        "new_primary_active": formula_size(new_schema(term)),
        "old_primary_inclusive": formula_size(old_schema(term), True),
        "new_primary_inclusive": formula_size(new_schema(term), True),
        "old_factored_active": formula_size(old_schema(term, True)),
        "new_factored_active": formula_size(new_schema(term, True)),
        "old_factored_inclusive": formula_size(old_schema(term, True), True),
        "new_factored_inclusive": formula_size(new_schema(term, True), True),
        "input_rank": term_rank(term),
        "new_primary_rank": formula_rank(new_schema(term)),
    }


def main():
    inputs = generate_inputs()
    savings = {name: [] for name in ["primary_active", "primary_inclusive",
                                    "factored_active", "factored_inclusive"]}
    max_input_rank = max_active = max_inclusive = 0
    adaptive_strict = 0
    for term in inputs:
        validate_term(term, {"n", "a"})
        m = term_size(term)
        width = term_size(term, True)
        i, j = occurrences(term, "n"), occurrences(term, "a")
        rank = term_rank(term)
        body = substitute(term, {"n": V, "a": W})
        validate_term(body, {"v", "w"})
        require("descriptor_rank_preserved", term_rank(body) == rank)
        require("descriptor_active_size_preserved", term_size(body) == m)
        require("descriptor_inclusive_size_preserved", term_size(body, True) == width)
        require("descriptor_has_two_allowed_slots", free_term(body) <= {"v", "w"})
        max_input_rank = max(max_input_rank, rank)
        max_active, max_inclusive = max(max_active, m), max(max_inclusive, width)

        formulas = {
            "old_primary": old_schema(term), "new_primary": new_schema(term),
            "old_factored": old_schema(term, True),
            "new_factored": new_schema(term, True),
        }
        expected = {
            "old_primary": (35 + 7*m + 4*i + 3*j,
                            35 + (9+i)*width + 4*i + 3*j),
            "new_primary": (47 + 4*m + 3*i, 51 + (6+i)*width + 3*i),
            "old_factored": (28 + 7*m + 4*i + 3*j,
                             28 + (9+i)*width + 4*i + 3*j),
            "new_factored": (32 + 4*m + 3*i, 32 + (6+i)*width + 3*i),
        }
        for name, formula in formulas.items():
            validate_formula(formula)
            active, inclusive = formula_size(formula), formula_size(formula, True)
            require(name + "_active_count", active == expected[name][0])
            require(name + "_inclusive_count", inclusive == expected[name][1])
            require("closed_formulas", not free_formula(formula))
            require("two_active_individual_names", active_names(formula) <= {"n", "a"})
            require("three_quantifiers_depth_three", quantifier_profile(formula) == (3, 3))
            expected_rank = max(rank + 1, 2) if name == "new_primary" else rank + 1
            require("finite_stage_exact", formula_rank(formula) == expected_rank)

        for factored in (False, True):
            variant = "factored" if factored else "primary"
            old, new = formulas["old_" + variant], formulas["new_" + variant]
            for inclusive in (False, True):
                metric = "inclusive" if inclusive else "active"
                difference = formula_size(old, inclusive) - formula_size(new, inclusive)
                input_size = width if inclusive else m
                overhead = 4 if factored else (16 if inclusive else 12)
                require("symbolic_saving_" + variant + "_" + metric,
                        difference == 3*input_size + i + 3*j - overhead)
                savings[variant + "_" + metric].append(difference)

        # This is a distinct optional same-language generator, NOT a claim
        # that its syntactic branch is simpler than a fixed formula.
        adaptive = adaptive_schema(term)
        validate_formula(adaptive)
        require("adaptive_active_count", formula_size(adaptive) ==
                35 + 7*m + 4*i + 3*j - max(j-i, 0))
        require("adaptive_inclusive_count", formula_size(adaptive, True) ==
                35 + (9+i)*width + 4*i + 3*j - max(j-i, 0))
        require("adaptive_profile", quantifier_profile(adaptive) == (3, 3))
        padded, k = adaptive_padding(term)
        validate_term(padded, {"n", "a"})
        require("adaptive_padding_occurrences",
                occurrences(padded, "n") == i+k and occurrences(padded, "a") == j)
        require("adaptive_padding_forces_normal_branch",
                occurrences(padded, "n") >= occurrences(padded, "a"))
        require("adaptive_padding_computes_input", counter_projection_step(padded) == term)
        require("adaptive_padding_is_finite", term_rank(padded) == max(rank, 1))
        for replacement in [{"n": N, "a": A}, {"n": N, "a": successor(A)},
                            {"n": successor(N), "a": A},
                            {"n": successor(N), "a": successor(A)}]:
            require("adaptive_padding_endpoint_reductions",
                    counter_projection_step(substitute(padded, replacement)) ==
                    substitute(term, replacement))
        adaptive_strict += int(j > i)

    require("sigma_active_size", formula_size(SIGMA) == 6)
    require("sigma_inclusive_size", formula_size(SIGMA, True) == 6)
    require("diag_matrix_active_size", formula_size(DIAG_MATRIX) == 7)
    require("diag_closed_active_size", formula_size(DIAG) == 8)
    require("diag_closed_inclusive_size", formula_size(DIAG, True) == 12)
    require("diag_extra_descriptor_cost", term_size(PRED_BODY, True) == 4)
    require("diag_stage_two", formula_rank(DIAG) == 2)
    validate_formula(DIAG)

    frozen_body = recursor(W, V, W)
    frozen_term = recursor(frozen_body, N, A)
    result = substitute(frozen_term, {"n": successor(A), "a": ZERO,
                                    "v": ONE, "w": ONE})
    require("frozen_descriptor_object_identity", result.descriptor is frozen_term.descriptor)
    require("simultaneous_substitution_not_recursive", result.children == (successor(A), ZERO))
    require("stored_variables_not_active", free_term(recursor(V, N, A)) == {"n", "a"})
    require("stored_occurrences_not_active", occurrences(recursor(V, N, A), "v") == 0)
    captured = substitute_formula(forall("a", equal(N, A)), {"n": A})
    require("capture_avoidance_renames_binder", captured.binder != "a")
    require("capture_avoidance_retains_free_variable", free_formula(captured) == {"a"})
    shadowed = forall("n", equal(N, A))
    require("shadowed_binder_protected", substitute_formula(shadowed, {"n": ZERO}) == shadowed)
    require("formal_count_input_rank_is_not_fixed", max_input_rank >= 4)

    for malformed in [variable("b"), recursor(variable("z"), N, A),
                      recursor(N, N, A), Term("recursor", (N, A)),
                      Term("successor", (N, A)), Term("zero", descriptor=V)]:
        reject(malformed)
    cyclic_descriptor = recursor(V, N, A)
    object.__setattr__(cyclic_descriptor, "descriptor", cyclic_descriptor)
    reject(cyclic_descriptor)
    cyclic_active = successor(N)
    object.__setattr__(cyclic_active, "children", (cyclic_active,))
    reject(cyclic_active)

    six = [record(term) for term in SIX_INPUTS]
    ledger = {}
    for inclusive in (False, True):
        metric = "inclusive" if inclusive else "active"
        old_total = sum(row["old_factored_" + metric] for row in six)
        new_total = sum(row["new_factored_" + metric] for row in six)
        diag_cost = formula_size(DIAG, inclusive)
        ledger[metric] = {
            "old_six_schema_instances": old_total,
            "new_six_schema_instances": new_total,
            "new_fixed_diag": diag_cost,
            "net_old_minus_new_excluding_common_sigma": old_total-new_total-diag_cost,
            "old_including_common_sigma": old_total + formula_size(SIGMA, inclusive),
            "new_including_common_sigma": new_total+diag_cost+formula_size(SIGMA, inclusive),
        }
    require("six_instance_active_net_saving_three",
            ledger["active"]["net_old_minus_new_excluding_common_sigma"] == 3)
    require("six_instance_inclusive_net_loss_one",
            ledger["inclusive"]["net_old_minus_new_excluding_common_sigma"] == -1)

    results = {
        "status": "passed",
        "scope": "Finite syntax, frozen substitution, ranks, binding and exact AST counts only; not a proof of the infinite theory or bi-interpretability.",
        "provenance": {
            "repository": "VladimirReshetnikov/ProveIt",
            "commit": "5ffc596c844086fc26509685c7833b548ebf25c3",
            "adapted_archive": "docs/drafts/pra_counter_recursion_2026-11-01.zip",
            "archive_git_blob": "59dc49b0e805f5aa489a373485a67c0505678752",
            "adapted_member": "pra_counter_recursion_2026-11-01/checks/check_schema.py",
            "reuse": "Immutable two-level syntax, substitution discipline and rejection-control architecture; present constructors and comparison checks are new.",
        },
        "deterministic_seed": 20261102,
        "distinct_input_terms": len(inputs),
        "main_formulas_checked": 4*len(inputs),
        "optional_adaptive_formulas_checked": len(inputs),
        "maximum_input_active_nodes": max_active,
        "maximum_input_inclusive_nodes": max_inclusive,
        "maximum_input_dependency_rank": max_input_rank,
        "metrics": {
            "active": "One node per variable, 0, S, R application, equality, connective, falsity and quantifier. Stored descriptor labels are atomic.",
            "inclusive": "The same tree count, adding the entire descriptor tree recursively at every R occurrence; no DAG sharing is credited.",
            "occurrences": "i and j count active n and a leaves only, excluding all stored descriptors.",
        },
        "exact_formulas": {
            "old_primary_active": "35+7*m+4*i+3*j",
            "new_primary_active": "47+4*m+3*i",
            "old_primary_inclusive": "35+(9+i)*W+4*i+3*j",
            "new_primary_inclusive": "51+(6+i)*W+3*i",
            "old_factored_active": "28+7*m+4*i+3*j",
            "new_factored_active": "32+4*m+3*i",
            "old_factored_inclusive": "28+(9+i)*W+4*i+3*j",
            "new_factored_inclusive": "32+(6+i)*W+3*i",
            "old_minus_new_factored_active": "3*m+i+3*j-4",
            "old_minus_new_factored_inclusive": "3*W+i+3*j-4",
            "new_fixed_diag_active": 8,
            "new_fixed_diag_inclusive": 12,
            "common_fixed_sigma": 6,
        },
        "quantifier_profile": {"all_four_main_templates": [3, 3], "fixed_diag": [1, 1]},
        "stage_bounds": {"new_primary": "max(rank(input)+1,2)",
                         "other_templates": "rank(input)+1"},
        "savings_corpus_summary": {
            name: {"minimum": min(values), "maximum": max(values),
                   "strict_savings": sum(v > 0 for v in values),
                   "ties": sum(v == 0 for v in values),
                   "losses": sum(v < 0 for v in values)}
            for name, values in savings.items()
        },
        "six_input_fair_factored_ledger": ledger,
        "six_input_rows": six,
        "six_input_warning": "The six-input package saves 3 active nodes but loses 1 descriptor-inclusive node after charging the new fixed diagonal once. It is not evidence of uniform per-instance domination.",
        "optional_adaptive_orientation": {
            "active_count": "35+7*m+4*i+3*j-max(j-i,0)",
            "inclusive_count": "35+(9+i)*W+4*i+3*j-max(j-i,0)",
            "strict_savings_in_corpus": adaptive_strict,
            "padding": "k=max(j-i,0); t_0=0; t_(r+1)=R_w(S(n),t_r); padded=R_w(S(u),t_k)",
            "padding_checks": "Finite counts force normal orientation; one literal counter-projection computation recovers u at all four adjacent-probe arguments.",
            "warning": "This is a separate generator with a syntactic occurrence-count branch. Its finite checks prove counts only, not same-language equivalence or a simplicity advantage.",
        },
        "checks_by_group": dict(sorted(CHECKS.items())),
        "total_assertions": sum(CHECKS.values()),
    }
    output = Path(__file__).resolve().parent
    results["checker_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (output / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    lines = [
        "FIXED-POINT COUNTER RECURSION: LITERAL FINITE AXIOMS",
        "R[body](counter,seed) stores a frozen binary descriptor.",
        "Descriptor variables v,w are not active free individuals.",
        "All abbreviations are expanded. False is a logical constant.",
        "FIXED SEPARATION: " + formula_text(SIGMA),
        "FIXED DIAGONAL: " + formula_text(DIAG), "",
    ]
    examples = [*SIX_INPUTS, recursor(W, N, A), recursor(PRED_BODY, N, A)]
    for term in examples:
        lines += ["INPUT: " + term_text(term),
                  "OLD PRIMARY: " + formula_text(old_schema(term)),
                  "NEW PRIMARY: " + formula_text(new_schema(term)),
                  "OLD FACTORED CORE: " + formula_text(old_schema(term, True)),
                  "NEW FACTORED CORE: " + formula_text(new_schema(term, True)), ""]
    (output / "examples.txt").write_text("\n".join(lines) + "\n")
    print(json.dumps({key: results[key] for key in ["status", "distinct_input_terms",
        "main_formulas_checked", "optional_adaptive_formulas_checked", "total_assertions",
        "six_input_fair_factored_ledger"]}, indent=2))


if __name__ == "__main__":
    main()
