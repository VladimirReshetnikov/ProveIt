A SMALLER REPEATED SCHEMA FOR PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov, 2 November 2026

START HERE
  report.pdf       Complete mathematical paper.
  report.tex       Main LaTeX source; sections/ contains the included sources.
  AXIOMS.txt       Exact standalone specification of the main theory.

RESULTS
  1. A four-occurrence moving-target schema with a fixed unit diagonal,
     in exactly the current counter-recursion language. The theory is
     definitionally equivalent to PRA, separately in classical and
     intuitionistic first-order logic, with full-carrier/native-equality
     identity round trips. It is also deductively equivalent in the same
     language to the current counter-recursion draft.

     All-in-one active sizes:
       old: 35+7m+4i+3j
       new: 47+4m+3i
     Saving: 3m+i+3j-12. The packaged new formula is smaller for every
     input of active size at least five, but larger for some tiny inputs.
     The recommended factored presentation pays its fixed laws once.
     The paper charges frozen descriptor trees as well as active syntax.

  2. A separate adaptive orientation of the existing counter schema
     never enlarges a same-input instance and saves max(j-i,0) nodes.
     It adds a syntactic occurrence-count branch to the schema generator.
     This is a separate optional variant, not part of the main theory.

  3. A symmetric finite-fiber countermodel rules out replacing native
     equality induction by zero tests. Even tests against any fixed
     standard numerals, all true universal fixed-numeral identities,
     arbitrary parameter lists, and positive successor coverage admit
     a model with a nontrivial involution. Hence that tempting reduction
     is not parameter-free bi-interpretable with PRA.

No absolute shortestness theorem is claimed. The fixed-point residual
argument is credited to the historical draft; the counter language,
pairing and compiler are adapted with attribution from the current draft.

VERIFICATION
  checks/check_schema.py : finite syntax/count checker; Python standard library.
  checks/results.json    : 5,000 inputs, 25,000 formulas, 215,025 assertions passed.
  formal/MovingTargetKernel.lean : local constructive bootstrap kernel.
  formal/lean-check.log   : actual successful Lean 4.19.0 run; 13 empty audits.
  formal/SCOPE.txt        : exact mechanization boundary.
  audit/                 : pinned source metadata, reviews, build/visual checks.
  SHA256SUMS.txt          : hashes of packaged files other than itself.

The full finite-descriptor calculus, pairing, primitive-recursive compiler,
bi-interpretation theorem and model-theoretic counterexample have written
proofs. They are not claimed as fully machine formalized. Empty Lean axiom
audits concern implications with explicitly stated hypotheses.

REBUILD
  python3 build.py
  python3 build.py --checks-only
  python3 build.py --pdf-only
  python3 build.py --lean /absolute/path/to/lean

Requirements: Python 3.10+, pdfLaTeX with standard packages used in report.tex.
Optional kernel recheck: Lean 4.19.0, Init only; no Mathlib or Lake needed.
The build script never downloads dependencies. Rebuilding changes derived
logs/PDF metadata, so regenerate checksums afterward if desired.

BASELINE
  VladimirReshetnikov/ProveIt, docs/drafts
  5ffc596c844086fc26509685c7833b548ebf25c3
  All six current ZIP archives were downloaded and their Git blob hashes verified.
  Historical source details are retained separately in audit/source_manifest.json.
  No external repository was modified.
