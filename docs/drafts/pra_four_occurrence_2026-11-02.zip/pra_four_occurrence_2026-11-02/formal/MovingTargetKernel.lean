import Init

/-!
# Constructive kernel for counter recursion with moving-target propagation

This file checks the new bootstrap over an arbitrary carrier `A`.
The functions below stand for the denotations of specified finite terms.
They are not function variables in the first-order theory's axiom schema.

In particular, `residualReconstruction` assumes fixed-point induction ONLY
for the explicitly displayed `ResidualTerm`. It does not assume induction
for every function on `A`. The term's legality, effective language,
descriptor substitution, primitive-recursive compiler, pairing, and full
bi-interpretation are addressed in the accompanying written proof and
syntax checker, not formalized in this file.

Checked here: the fixed-point rule from a specified propagation instance;
computational predecessor and selector; successor separation; coverage;
the zero diagonal; residual reconstruction; native equality reflection;
and transfer of a specified zero equation to moving-target propagation.

The residual argument is adapted, with attribution, from the historical
ProveIt moving-target draft `pra_one_term_one_schema_2026-11-01.zip` at
commit 68a3ae5951510d578157b8e22b3570a179bb24e7. Its predecessor and selector
are specialized here to scalar counter recursion.

No `axiom`, `sorry`, classical logic, or Mathlib import is used. All
mathematical assumptions occur as explicit theorem parameters. The final
`#print axioms` commands expose the kernel dependencies of every result.
-/

namespace MovingTargetKernel

universe u
variable {A : Type u}

def RootedFixed (zero : A) (term : A → A) (n : A) : Prop :=
  n = zero ∨ term n = n

def Propagation (zero : A) (succ : A → A) (term : A → A → A) : Prop :=
  ∀ a, (∀ n, RootedFixed zero (fun k => term k a) n →
    term (succ n) a = succ n) →
    ∀ n, RootedFixed zero (fun k => term k a) n

def FixedPointInduction (zero : A) (succ : A → A)
    (term : A → A → A) : Prop :=
  ∀ a, term zero a = zero →
    (∀ n, term n a = n → term (succ n) a = succ n) →
    ∀ n, term n a = n

theorem fixedPointFromPropagation
    (zero : A) (succ : A → A) (term : A → A → A)
    (schemaInstance : Propagation zero succ term) :
    FixedPointInduction zero succ term := by
  intro a base step
  have extract : ∀ n, RootedFixed zero (fun k => term k a) n →
      term n a = n := by
    intro n hypothesis
    cases hypothesis with
    | inl atZero => subst n; exact base
    | inr equation => exact equation
  have result := schemaInstance a (fun n hypothesis => step n (extract n hypothesis))
  intro n
  exact extract n (result n)

theorem computationalPredecessor
    (zero : A) (succ : A → A) (counter : A → A → A)
    (counterZero : ∀ a, counter zero a = a)
    (counterSucc : ∀ n a, counter (succ n) a = n) :
    counter zero zero = zero ∧ ∀ n, counter (succ n) zero = n := by
  exact ⟨counterZero zero, fun n => counterSucc n zero⟩

theorem successorInjective
    (succ pred : A → A) (predSucc : ∀ n, pred (succ n) = n) :
    ∀ x y, succ x = succ y → x = y := by
  intro x y equation
  have reflected := congrArg pred equation
  rw [predSucc, predSucc] at reflected
  exact reflected

theorem successorNonzero
    (zero : A) (succ pred : A → A)
    (separation : zero ≠ succ zero)
    (predZero : pred zero = zero) (predSucc : ∀ n, pred (succ n) = n) :
    ∀ n, succ n ≠ zero := by
  intro n equation
  have atZero := congrArg pred equation
  rw [predSucc, predZero] at atZero
  apply separation
  rw [atZero] at equation
  exact equation.symm

theorem coverageFromPropagation
    (zero : A) (succ pred : A → A)
    (predSucc : ∀ n, pred (succ n) = n)
    (schemaInstance : Propagation zero succ (fun n _ => succ (pred n))) :
    ∀ n, n = zero ∨ n = succ (pred n) := by
  have result := schemaInstance zero (by
    intro n _
    exact congrArg succ (predSucc n))
  intro n
  cases result n with
  | inl atZero => exact Or.inl atZero
  | inr equation => exact Or.inr equation.symm

def Select (zero : A) (succ : A → A) (counter zeroTest : A → A → A)
    (test left right : A) : A :=
  counter (zeroTest test (succ left)) (zeroTest (zeroTest test (succ zero)) right)

theorem computationalSelectorZero
    (zero : A) (succ : A → A) (counter zeroTest : A → A → A)
    (counterSucc : ∀ n a, counter (succ n) a = n)
    (testZero : ∀ a, zeroTest zero a = a)
    (testSucc : ∀ n a, zeroTest (succ n) a = zero) :
    ∀ x y, Select zero succ counter zeroTest zero x y = x := by
  intro x y
  unfold Select
  rw [testZero, testZero, testSucc, counterSucc]

theorem computationalSelectorSucc
    (zero : A) (succ : A → A) (counter zeroTest : A → A → A)
    (counterZero : ∀ a, counter zero a = a)
    (testZero : ∀ a, zeroTest zero a = a)
    (testSucc : ∀ n a, zeroTest (succ n) a = zero) :
    ∀ n x y, Select zero succ counter zeroTest (succ n) x y = y := by
  intro n x y
  unfold Select
  rw [testSucc, testSucc, testZero, counterZero]

theorem selectorSame
    (zero : A) (succ pred : A → A) (selector : A → A → A → A)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (selectZero : ∀ x y, selector zero x y = x)
    (selectSucc : ∀ n x y, selector (succ n) x y = y) :
    ∀ test value, selector test value value = value := by
  intro test value
  cases coverage test with
  | inl atZero => rw [atZero, selectZero]
  | inr atSucc => rw [atSucc, selectSucc]

theorem zeroDiagonal
    (zero : A) (succ pred : A → A) (difference : A → A → A)
    (predSucc : ∀ n, pred (succ n) = n)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (differenceZero : ∀ a, difference a zero = a)
    (differenceSucc : ∀ a n, difference a (succ n) = pred (difference a n))
    (diagonal : ∀ n, difference (succ n) n = succ zero) :
    ∀ a, difference a a = zero := by
  intro a
  cases coverage a with
  | inl atZero => rw [atZero, differenceZero]
  | inr atSucc => rw [atSucc, differenceSucc, diagonal, predSucc]

def ResidualTerm (selector : A → A → A → A) (difference : A → A → A)
    (n a : A) : A :=
  selector (difference a n) n (difference a (difference a n))

theorem residualReconstruction
    (zero : A) (succ pred : A → A) (selector : A → A → A → A)
    (difference : A → A → A)
    (separation : zero ≠ succ zero)
    (predZero : pred zero = zero) (predSucc : ∀ n, pred (succ n) = n)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (selectZero : ∀ x y, selector zero x y = x)
    (selectSucc : ∀ n x y, selector (succ n) x y = y)
    (differenceZero : ∀ a, difference a zero = a)
    (differenceSucc : ∀ a n, difference a (succ n) = pred (difference a n))
    (diagonal : ∀ n, difference (succ n) n = succ zero)
    (residualInduction :
      FixedPointInduction zero succ (ResidualTerm selector difference)) :
    ∀ a n, ResidualTerm selector difference n a = n := by
  have same := selectorSame zero succ pred selector coverage selectZero selectSucc
  have selfZero := zeroDiagonal zero succ pred difference predSucc coverage
    differenceZero differenceSucc diagonal
  intro a
  apply residualInduction a
  · unfold ResidualTerm
    rw [differenceZero, selfZero]
    exact same a zero
  · intro n inductionHypothesis
    unfold ResidualTerm at inductionHypothesis ⊢
    cases coverage (difference a n) with
    | inl residualZero =>
      rw [differenceSucc, residualZero, predZero, selectZero]
    | inr residualSucc =>
      let k := pred (difference a n)
      have residualValue : difference a n = succ k := residualSucc
      have previous : difference a (succ k) = n := by
        rw [residualValue, selectSucc] at inductionHypothesis
        exact inductionHypothesis
      have predValue : pred (difference a k) = n := by
        rw [differenceSucc] at previous
        exact previous
      have innerNonzero : difference a k ≠ zero := by
        intro innerZero
        have nZero : n = zero := by
          rw [innerZero, predZero] at predValue
          exact predValue.symm
        have aValue : a = succ k := by
          rw [nZero, differenceZero] at residualValue
          exact residualValue
        have innerOne : difference a k = succ zero := by
          rw [aValue, diagonal]
        exact separation (innerZero.symm.trans innerOne)
      have innerValue : difference a k = succ n := by
        cases coverage (difference a k) with
        | inl innerZero => exact False.elim (innerNonzero innerZero)
        | inr innerSucc =>
          exact innerSucc.trans (congrArg succ predValue)
      have nextValue : difference a (succ n) = k := by
        rw [differenceSucc, residualValue, predSucc]
      rw [nextValue, innerValue]
      exact same k (succ n)

theorem nativeEqualityReflection
    (zero : A) (succ pred : A → A) (selector : A → A → A → A)
    (difference : A → A → A)
    (predSucc : ∀ n, pred (succ n) = n)
    (selectSucc : ∀ n x y, selector (succ n) x y = y)
    (differenceZero : ∀ a, difference a zero = a)
    (differenceSucc : ∀ a n, difference a (succ n) = pred (difference a n))
    (diagonal : ∀ n, difference (succ n) n = succ zero)
    (residual : ∀ a n, ResidualTerm selector difference n a = n) :
    ∀ x y, difference (succ x) y = succ zero ↔ x = y := by
  intro x y
  constructor
  · intro value
    have reflected := residual (succ x) y
    unfold ResidualTerm at reflected
    rw [value, selectSucc, differenceSucc, differenceZero, predSucc] at reflected
    exact reflected
  · intro equation
    subst y
    exact diagonal x

theorem rootedZeroTransfer
    (zero : A) (succ pred : A → A) (zeroTest : A → A → A)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (testZero : ∀ a, zeroTest zero a = a)
    (testSucc : ∀ n a, zeroTest (succ n) a = zero)
    (value n : A) :
    (n = zero ∨ zeroTest value n = n) ↔ (n = zero ∨ value = zero) := by
  constructor
  · intro hypothesis
    cases hypothesis with
    | inl nZero => exact Or.inl nZero
    | inr equation =>
      cases coverage value with
      | inl valueZero => exact Or.inr valueZero
      | inr valueSucc =>
        rw [valueSucc, testSucc] at equation
        exact Or.inl equation.symm
  · intro hypothesis
    cases hypothesis with
    | inl nZero => exact Or.inl nZero
    | inr valueZero =>
      apply Or.inr
      rw [valueZero, testZero]

theorem zeroInductionFromPropagation
    (zero : A) (succ pred : A → A) (zeroTest : A → A → A)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (testZero : ∀ a, zeroTest zero a = a)
    (testSucc : ∀ n a, zeroTest (succ n) a = zero)
    (term : A → A → A)
    (schemaInstance : Propagation zero succ (fun n a => zeroTest (term n a) n))
    (a : A) (base : term zero a = zero)
    (step : ∀ n, term n a = zero → term (succ n) a = zero) :
    ∀ n, term n a = zero := by
  have extract : ∀ n, (n = zero ∨ term n a = zero) → term n a = zero := by
    intro n hypothesis
    cases hypothesis with
    | inl nZero => subst n; exact base
    | inr equation => exact equation
  have progress : ∀ n,
      RootedFixed zero (fun k => zeroTest (term k a) k) n →
      zeroTest (term (succ n) a) (succ n) = succ n := by
    intro n hypothesis
    have bridge := rootedZeroTransfer zero succ pred zeroTest coverage
      testZero testSucc (term n a) n
    have value := step n (extract n (bridge.mp hypothesis))
    rw [value, testZero]
  have result := schemaInstance a progress
  intro n
  have bridge := rootedZeroTransfer zero succ pred zeroTest coverage
    testZero testSucc (term n a) n
  exact extract n (bridge.mp (result n))

#print axioms fixedPointFromPropagation
#print axioms computationalPredecessor
#print axioms successorInjective
#print axioms successorNonzero
#print axioms coverageFromPropagation
#print axioms computationalSelectorZero
#print axioms computationalSelectorSucc
#print axioms selectorSame
#print axioms zeroDiagonal
#print axioms residualReconstruction
#print axioms nativeEqualityReflection
#print axioms rootedZeroTransfer
#print axioms zeroInductionFromPropagation

end MovingTargetKernel
