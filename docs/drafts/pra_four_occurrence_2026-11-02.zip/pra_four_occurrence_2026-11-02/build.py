#!/usr/bin/env python3
"""Rebuild the research package locally; never downloads dependencies."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checks-only", action="store_true")
    parser.add_argument("--pdf-only", action="store_true")
    parser.add_argument("--lean", help="Path to a Lean 4.19.0 executable")
    args = parser.parse_args()
    if args.checks_only and args.pdf_only:
        parser.error("--checks-only and --pdf-only are mutually exclusive")
    root = Path(__file__).resolve().parent
    results = {"syntax": "not rerun", "lean": "not rerun", "pdf": "not rerun"}
    if not args.pdf_only:
        subprocess.run([sys.executable, "checks/check_schema.py"],
                       cwd=root, check=True)
        results["syntax"] = "passed"
    if args.lean:
        lean = str(Path(args.lean).expanduser().resolve())
        version = subprocess.run([lean, "--version"], cwd=root, check=True,
                                 capture_output=True, text=True).stdout.strip()
        run = subprocess.run([lean, "formal/MovingTargetKernel.lean"],
                             cwd=root, capture_output=True, text=True)
        (root / "formal/lean-check.log").write_text(run.stdout + run.stderr)
        run.check_returncode()
        results["lean"] = {"version": version, "status": "passed"}
    if not args.checks_only:
        latex = shutil.which("pdflatex")
        if latex is None:
            raise SystemExit("pdfLaTeX is required to compile report.tex")
        logs = []
        for _ in range(3):
            run = subprocess.run(
                [latex, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
                cwd=root, capture_output=True, text=True)
            logs.append(run.stdout + run.stderr)
            (root / "audit/latex-build.log").write_text("\n".join(logs))
            run.check_returncode()
        results["pdf"] = "compiled; inspect rendered pages before delivery"
    (root / "audit/rebuild-results.json").write_text(
        json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
