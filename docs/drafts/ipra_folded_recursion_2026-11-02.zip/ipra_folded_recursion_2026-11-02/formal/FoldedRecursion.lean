/-
  Constructive local kernels for the folded-recursion presentation of iPRA.

  STATUS: REVIEWED SOURCE, UNCOMPILED IN THIS RUN.
  No Lean executable was found in the available environment.

  These are local equivalence and boundary lemmas.  They do not constitute a
  formalization of the primitive-recursive compiler, the full arithmetic
  reconstruction, or the bi-interpretability metatheorem in the report.

  All arithmetic assumptions are explicit theorem parameters.  This file
  contains no axiom declarations, sorry, admit, classical, or Classical calls.
  The intended dependency is Lean 4's core Init library only.
-/

import Init

universe u

namespace IPRAFolded

variable {α : Type u}

/-- The usual initialized primitive-recursion equations. -/
def StandardRecursion
    (zero : α) (succ : α → α) (h R : α → α → α) : Prop :=
  (∀ a, R zero a = a) ∧
  (∀ a n, R (succ n) a = h (R n a) n)

/-- One equation combines the initial and successor cases. -/
def FoldedRecursion
    (zero : α) (succ : α → α) (Q Z h R : α → α → α) : Prop :=
  ∀ a n,
    R n a =
      Q (Z n (succ a))
        (h (R (Q n zero) a) (Q n zero))

/--
The folded equation yields both defining equations without coverage,
separation, induction, or any decidability assumption.
-/
theorem folded_to_standard
    (zero : α) (succ : α → α) (Q Z h R : α → α → α)
    (q_zero : ∀ a, Q zero a = a)
    (q_succ : ∀ n a, Q (succ n) a = n)
    (z_zero : ∀ a, Z zero a = a)
    (z_succ : ∀ n a, Z (succ n) a = zero)
    (folded : FoldedRecursion zero succ Q Z h R) :
    StandardRecursion zero succ h R := by
  constructor
  · intro a
    simpa only [z_zero, q_succ] using folded a zero
  · intro a n
    simpa only [z_succ, q_succ, q_zero] using folded a (succ n)

/--
Coverage supplies the converse.  In particular, successor separation and
the absence of successor fixed points are not assumptions of this lemma.
-/
theorem standard_to_folded
    (zero : α) (succ : α → α) (Q Z h R : α → α → α)
    (q_zero : ∀ a, Q zero a = a)
    (q_succ : ∀ n a, Q (succ n) a = n)
    (z_zero : ∀ a, Z zero a = a)
    (z_succ : ∀ n a, Z (succ n) a = zero)
    (coverage : ∀ n, n = zero ∨ ∃ m, n = succ m)
    (standard : StandardRecursion zero succ h R) :
    FoldedRecursion zero succ Q Z h R := by
  intro a n
  cases coverage n with
  | inl hn =>
      cases hn
      simpa only [z_zero, q_succ] using standard.1 a
  | inr hm =>
      cases hm with
      | intro m hn =>
          cases hn
          simpa only [z_succ, q_succ, q_zero] using standard.2 a m

theorem folded_iff_standard
    (zero : α) (succ : α → α) (Q Z h R : α → α → α)
    (q_zero : ∀ a, Q zero a = a)
    (q_succ : ∀ n a, Q (succ n) a = n)
    (z_zero : ∀ a, Z zero a = a)
    (z_succ : ∀ n a, Z (succ n) a = zero)
    (coverage : ∀ n, n = zero ∨ ∃ m, n = succ m) :
    FoldedRecursion zero succ Q Z h R ↔
      StandardRecursion zero succ h R := by
  constructor
  · exact folded_to_standard zero succ Q Z h R
      q_zero q_succ z_zero z_succ
  · exact standard_to_folded zero succ Q Z h R
      q_zero q_succ z_zero z_succ coverage

/-- Ordinary equations when the update ignores its state argument. -/
def StateFreeStandard
    (zero : α) (succ : α → α) (g : α → α) (R : α → α → α) : Prop :=
  (∀ a, R zero a = a) ∧
  (∀ a n, R (succ n) a = g n)

/-- The state-free specialization of the folded equation. -/
def StateFreeFolded
    (zero : α) (succ : α → α) (Q Z : α → α → α)
    (g : α → α) (R : α → α → α) : Prop :=
  ∀ a n, R n a = Q (Z n (succ a)) (g (Q n zero))

/--
Binding the predecessor by a universally quantified equality avoids
duplicating its term at each occurrence in a state-free descriptor.
-/
def StateFreePredecessorBound
    (zero : α) (succ : α → α) (Q Z : α → α → α)
    (g : α → α) (R : α → α → α) : Prop :=
  ∀ a n p, Q n zero = p → R n a = Q (Z n (succ a)) (g p)

/-- Pure equality logic proves the equivalence of the two state-free forms. -/
theorem statefree_folded_iff_predecessor_bound
    (zero : α) (succ : α → α) (Q Z : α → α → α)
    (g : α → α) (R : α → α → α) :
    StateFreeFolded zero succ Q Z g R ↔
      StateFreePredecessorBound zero succ Q Z g R := by
  constructor
  · intro folded a n p hp
    simpa only [hp] using folded a n
  · intro bound a n
    exact bound a n (Q n zero) rfl

theorem statefree_folded_iff_standard
    (zero : α) (succ : α → α) (Q Z : α → α → α)
    (g : α → α) (R : α → α → α)
    (q_zero : ∀ a, Q zero a = a)
    (q_succ : ∀ n a, Q (succ n) a = n)
    (z_zero : ∀ a, Z zero a = a)
    (z_succ : ∀ n a, Z (succ n) a = zero)
    (coverage : ∀ n, n = zero ∨ ∃ m, n = succ m) :
    StateFreeFolded zero succ Q Z g R ↔
      StateFreeStandard zero succ g R := by
  constructor
  · intro folded
    constructor
    · intro a
      simpa only [z_zero, q_succ] using folded a zero
    · intro a n
      simpa only [z_succ, q_succ, q_zero] using folded a (succ n)
  · intro standard a n
    cases coverage n with
    | inl hn =>
        cases hn
        simpa only [z_zero, q_succ] using standard.1 a
    | inr hm =>
        cases hm with
        | intro m hn =>
            cases hn
            simpa only [z_succ, q_succ, q_zero] using standard.2 a m

theorem statefree_bound_iff_standard
    (zero : α) (succ : α → α) (Q Z : α → α → α)
    (g : α → α) (R : α → α → α)
    (q_zero : ∀ a, Q zero a = a)
    (q_succ : ∀ n a, Q (succ n) a = n)
    (z_zero : ∀ a, Z zero a = a)
    (z_succ : ∀ n a, Z (succ n) a = zero)
    (coverage : ∀ n, n = zero ∨ ∃ m, n = succ m) :
    StateFreePredecessorBound zero succ Q Z g R ↔
      StateFreeStandard zero succ g R := by
  have hbind := statefree_folded_iff_predecessor_bound
    zero succ Q Z g R
  have hstandard := statefree_folded_iff_standard
    zero succ Q Z g R q_zero q_succ z_zero z_succ coverage
  constructor
  · intro bound
    exact hstandard.1 (hbind.2 bound)
  · intro standard
    exact hbind.1 (hstandard.2 standard)

/-- The generic implication-chain connective used in the boundary. -/
def Chain (A B C : Prop) : Prop := (A → B) ∧ (B → C)

/-- A local instance of the covered boundary scheme. -/
def Boundary (succ : α → α) (E : α → Prop) : Prop :=
  ∀ n, ∃ b, ∀ x, Chain (succ x = b) (E x) (x = b → b = n)

/--
A boundary gives induction while retaining arbitrary surrounding proof
hypotheses.  E is arbitrary here: no equality decision is needed for this
direction.  The report's arithmetic axiom scheme supplies boundaries only
for its specified equations, not for arbitrary predicates.
-/
theorem boundary_implies_induction
    (zero : α) (succ : α → α) (E : α → Prop)
    (coverage : ∀ x, x = zero ∨ ∃ y, x = succ y)
    (boundary : Boundary succ E)
    (base : E zero)
    (step : ∀ x, E x → E (succ x)) :
    ∀ n, E n := by
  intro n
  cases boundary n with
  | intro b hb =>
      have eb : E b := by
        cases coverage b with
        | inl hz =>
            simpa only [hz] using base
        | inr hy =>
            cases hy with
            | intro y hsucc =>
                have ey : E y := (hb y).1 hsucc.symm
                simpa only [hsucc] using step y ey
      have hbn : b = n := (hb b).2 eb rfl
      exact hbn ▸ eb

/-- Pointwise equivalence transfers a boundary using the same witness. -/
theorem boundary_congruence
    (succ : α → α) (E F : α → Prop)
    (equivalent : ∀ x, E x ↔ F x)
    (boundary : Boundary succ E) :
    Boundary succ F := by
  intro n
  cases boundary n with
  | intro b hb =>
      refine ⟨b, ?_⟩
      intro x
      constructor
      · intro hsucc
        exact (equivalent x).1 ((hb x).1 hsucc)
      · intro fx
        exact (hb x).2 ((equivalent x).2 fx)

/-- Equation symmetry justifies retaining one syntactic orientation. -/
theorem equation_boundary_symmetry
    (succ : α → α) (s t : α → α) :
    Boundary succ (fun x => s x = t x) ↔
      Boundary succ (fun x => t x = s x) := by
  constructor
  · intro boundary
    apply boundary_congruence succ (fun x => s x = t x)
      (fun x => t x = s x)
    · intro x
      exact ⟨fun h => h.symm, fun h => h.symm⟩
    · exact boundary
  · intro boundary
    apply boundary_congruence succ (fun x => t x = s x)
      (fun x => s x = t x)
    · intro x
      exact ⟨fun h => h.symm, fun h => h.symm⟩
    · exact boundary

/-- An inhabited carrier permits deletion of an unused universal binder. -/
theorem unused_parameter (zero : α) (P : Prop) :
    (∀ _ : α, P) ↔ P := by
  constructor
  · intro h
    exact h zero
  · intro h _
    exact h

end IPRAFolded
