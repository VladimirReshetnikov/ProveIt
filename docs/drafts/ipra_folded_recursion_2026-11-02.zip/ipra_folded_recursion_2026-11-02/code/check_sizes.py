#!/usr/bin/env python3
"""Check literal formula sizes, charging frozen recursor descriptions in full.

This checks syntax and arithmetic accounting only.  It is not a proof of
intuitionistic equivalence, induction, or bi-interpretability.  Run without
arguments to write ../verification/syntax_checks.json.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path
import random
from typing import Iterable


@dataclass(frozen=True)
class Node:
    tag: str
    args: tuple["Node", ...] = ()
    name: str = ""
    descriptor: "Node | None" = None


TERM_TAGS = frozenset({"var", "zero", "S", "R"})


def var(name: str) -> Node:
    return Node("var", name=name)


ZERO = Node("zero")
FALSE = Node("false")
V, W = var("v"), var("w")
A, N, U, X, Y, B, P = map(var, ("a", "n", "u", "x", "y", "b", "p"))


def succ(t: Node) -> Node:
    return Node("S", (t,))


def rec(h: Node, n: Node, a: Node) -> Node:
    return Node("R", (n, a), descriptor=h)


def q(n: Node, a: Node) -> Node:
    return rec(W, n, a)


def z(n: Node, a: Node) -> Node:
    return rec(ZERO, n, a)


def eq(s: Node, t: Node) -> Node:
    return Node("=", (s, t))


def conjunction(s: Node, t: Node) -> Node:
    return Node("and", (s, t))


def disjunction(s: Node, t: Node) -> Node:
    return Node("or", (s, t))


def implies(s: Node, t: Node) -> Node:
    return Node("implies", (s, t))


def chain(s: Node, t: Node, u: Node) -> Node:
    return Node("K", (s, t, u))


def weak(s: Node, t: Node, u: Node) -> Node:
    return Node("J", (s, t, u))


def quant(kind: str, names: Iterable[str], body: Node) -> Node:
    result = body
    for name in reversed(tuple(names)):
        result = Node(kind, (result,), name=name)
    return result


def forall(names: Iterable[str], body: Node) -> Node:
    return quant("forall", names, body)


def exists(names: Iterable[str], body: Node) -> Node:
    return quant("exists", names, body)


def size(t: Node) -> int:
    """Each AST node costs one; each R also carries its entire frozen body."""
    return 1 + sum(map(size, t.args)) + (size(t.descriptor) if t.descriptor else 0)


def active_count(t: Node, name: str) -> int:
    """Descriptors are not active application arguments."""
    return int(t.tag == "var" and t.name == name) + sum(
        active_count(arg, name) for arg in t.args
    )


def active_names(t: Node) -> set[str]:
    out = {t.name} if t.tag == "var" else set()
    for arg in t.args:
        out.update(active_names(arg))
    return out


def substitute(t: Node, replacements: dict[str, Node]) -> Node:
    """Simultaneous active term substitution; frozen bodies are untouched."""
    if t.tag not in TERM_TAGS:
        raise ValueError("This function substitutes terms, not binders/formulas")
    if t.tag == "var":
        return replacements.get(t.name, t)
    return Node(
        t.tag,
        tuple(substitute(arg, replacements) for arg in t.args),
        name=t.name,
        descriptor=t.descriptor,
    )


def instantiate(h: Node, state: Node, counter: Node) -> Node:
    return substitute(h, {"v": state, "w": counter})


def valid_term(t: Node) -> bool:
    if t.tag not in TERM_TAGS:
        return False
    if t.tag in {"zero", "var"}:
        return not t.args and t.descriptor is None
    if t.tag == "S":
        return len(t.args) == 1 and t.descriptor is None and valid_term(t.args[0])
    return (
        len(t.args) == 2
        and t.descriptor is not None
        and valid_term(t.descriptor)
        and active_names(t.descriptor) <= {"v", "w"}
        and all(map(valid_term, t.args))
    )


def render(t: Node) -> str:
    if t.tag == "var":
        return t.name
    if t.tag == "zero":
        return "0"
    if t.tag == "false":
        return "false"
    if t.tag == "S":
        return "S(" + render(t.args[0]) + ")"
    if t.tag == "R":
        assert t.descriptor is not None
        return "R_{" + render(t.descriptor) + "}(" + ",".join(map(render, t.args)) + ")"
    if t.tag in {"forall", "exists"}:
        return t.tag + " " + t.name + ". " + render(t.args[0])
    return t.tag + "(" + ",".join(map(render, t.args)) + ")"


def iterate_s(t: Node, count: int) -> Node:
    for _ in range(count):
        t = succ(t)
    return t


def direct(h: Node) -> tuple[Node, Node]:
    return (
        forall(("a",), eq(rec(h, ZERO, A), A)),
        forall(("a", "n"), eq(rec(h, succ(N), A), instantiate(h, rec(h, N, A), N))),
    )


def graph_k(h: Node) -> Node:
    return forall(
        ("a", "n", "u"),
        chain(
            conjunction(eq(N, ZERO), eq(U, A)),
            eq(rec(h, N, A), U),
            eq(rec(h, succ(N), A), instantiate(h, U, N)),
        ),
    )


def endpoint_k(h: Node) -> Node:
    return forall(
        ("a", "n"),
        exists(
            ("u",),
            conjunction(
                implies(eq(N, ZERO), eq(U, A)),
                forall(
                    ("x", "y"),
                    chain(
                        conjunction(eq(X, N), eq(Y, U)),
                        eq(rec(h, X, A), Y),
                        implies(eq(X, succ(N)), eq(Y, instantiate(h, U, N))),
                    ),
                ),
            ),
        ),
    )


def statefree_k(h: Node) -> Node:
    if active_count(h, "v"):
        raise ValueError("V_K requires an absent active state slot")
    return forall(
        ("a", "x", "y"),
        chain(
            conjunction(eq(X, ZERO), eq(Y, A)),
            eq(rec(h, X, A), Y),
            forall(("n",), implies(eq(X, succ(N)), eq(Y, instantiate(h, ZERO, N)))),
        ),
    )


def folded(h: Node) -> Node:
    predecessor = q(N, ZERO)
    update = instantiate(h, rec(h, predecessor, A), predecessor)
    return forall(("a", "n"), eq(rec(h, N, A), q(z(N, succ(A)), update)))


def factored_statefree(h: Node) -> Node:
    if active_count(h, "v"):
        raise ValueError("F requires an absent active state slot")
    return forall(
        ("a", "n", "p"),
        implies(
            eq(q(N, ZERO), P),
            eq(rec(h, N, A), q(z(N, succ(A)), instantiate(h, ZERO, P))),
        ),
    )


def endpoint_j(h: Node) -> Node:
    """The current double-conditional W module; uses the J basis."""
    return forall(
        ("a", "n"),
        exists(
            ("u",),
            forall(
                ("x", "y"),
                weak(
                    eq(rec(h, X, A), Y),
                    implies(eq(N, ZERO), eq(U, A)),
                    weak(
                        eq(X, N),
                        implies(eq(X, succ(N)), eq(Y, instantiate(h, U, N))),
                        eq(Y, U),
                    ),
                ),
            ),
        ),
    )


def boundary(equation: Node, include_parameter: bool = True) -> Node:
    names = ("a", "n") if include_parameter else ("n",)
    if not include_parameter and active_count(equation, "a"):
        raise ValueError("Cannot omit an active parameter binder")
    return forall(
        names,
        exists(
            ("b",),
            forall(("x",), chain(eq(succ(X), B), equation, implies(eq(X, B), eq(B, N)))),
        ),
    )


def all_formulas(h: Node) -> dict[str, Node | tuple[Node, Node]]:
    out: dict[str, Node | tuple[Node, Node]] = {
        "D": direct(h),
        "G_K": graph_k(h),
        "T_K": endpoint_k(h),
        "W_J": endpoint_j(h),
        "M": folded(h),
    }
    if active_count(h, "v") == 0:
        out["V_K"] = statefree_k(h)
        out["F"] = factored_statefree(h)
    return out


def module_size(module: Node | tuple[Node, Node]) -> int:
    return sum(map(size, module)) if isinstance(module, tuple) else size(module)


def choose(costs: dict[str, int], names: tuple[str, ...], protected: bool) -> dict:
    if protected:
        return {"module": "D", "size": costs["D"], "protected_Q_or_Z": True}
    eligible = [name for name in names if name in costs]
    winner = min(eligible, key=lambda name: costs[name])
    return {"module": winner, "size": costs[winner], "protected_Q_or_Z": False}


def diagnostic(h: Node) -> dict:
    assert valid_term(h) and active_names(h) <= {"v", "w"}
    H, k, ell = size(h), active_count(h, "v"), active_count(h, "w")
    expected = {
        "D": 3 * H + 13 + k * (H + 2),
        "G_K": 3 * H + 21,
        "T_K": 2 * H + 33,
        "W_J": 2 * H + 32,
        "M": 2 * H + 13 + k * (H + 5) + 3 * ell,
    }
    if k == 0:
        expected.update(V_K=2 * H + 24, F=2 * H + 21)
    observed = {name: module_size(body) for name, body in all_formulas(h).items()}
    assert observed == expected, (render(h), observed, expected)
    protected = h in (ZERO, W)
    old_chain = choose(observed, ("D", "G_K", "T_K", "V_K"), False)
    new_chain = choose(observed, ("D", "G_K", "T_K", "M", "F"), protected)
    # The common envelope compares arithmetic-module counts only.  It does
    # not make the J and K definitions jointly available without their cost.
    old_common = choose(observed, ("D", "G_K", "T_K", "W_J", "V_K"), False)
    new_common = choose(observed, ("D", "G_K", "T_K", "W_J", "M", "F"), protected)
    assert new_chain["size"] <= old_chain["size"]
    assert new_common["size"] <= old_common["size"]
    return {
        "descriptor": render(h),
        "H": H,
        "k": k,
        "ell": ell,
        "counts": observed,
        "expected_counts": expected,
        "old_chain": old_chain,
        "new_chain": new_chain,
        "old_common_arithmetic_envelope": old_common,
        "new_common_arithmetic_envelope": new_common,
        "chain_saving": old_chain["size"] - new_chain["size"],
        "common_envelope_saving": old_common["size"] - new_common["size"],
    }


def generated_descriptors() -> list[Node]:
    """Finite reproducible examples, including genuinely frozen nested bodies."""
    seen: set[Node] = set()
    out: list[Node] = []

    def add(h: Node) -> None:
        if h not in seen:
            seen.add(h)
            out.append(h)

    for leaf in (ZERO, V, W):
        for depth in range(8):
            add(iterate_s(leaf, depth))
    first_stage = (ZERO, V, W, succ(V), succ(W))
    for frozen in first_stage:
        for left in (ZERO, V, W):
            for right in (ZERO, V, W):
                add(rec(frozen, left, right))
                add(succ(rec(frozen, left, right)))
    rng = random.Random(20261102)
    # Each new frozen body is chosen from an already constructed stage.
    for _ in range(300):
        earlier = tuple(out)
        frozen = rng.choice(earlier)
        left = rng.choice((ZERO, V, W, succ(V), succ(W)))
        right = rng.choice((ZERO, V, W, succ(V), succ(W)))
        new = rec(frozen, left, right)
        if rng.randrange(2):
            new = succ(new)
        add(new)
    return out


def run() -> dict:
    frozen_test = rec(V, V, W)
    substituted = substitute(frozen_test, {"v": succ(W), "w": ZERO})
    assert substituted.descriptor is frozen_test.descriptor
    assert substituted == rec(V, succ(W), ZERO)
    assert active_count(substituted, "v") == 0
    assert active_count(substituted, "w") == 1
    assert size(substituted) == 5

    descriptors = generated_descriptors()
    diagnostics = [diagnostic(h) for h in descriptors]
    named = {
        "Q = R_w": W,
        "Z = R_0": ZERO,
        "S^3(v)": iterate_s(V, 3),
        "S^5(v)": iterate_s(V, 5),
        "S^10(v)": iterate_s(V, 10),
        "S^12(v)": iterate_s(V, 12),
        "S^99(0)": iterate_s(ZERO, 99),
        "S^99(w)": iterate_s(W, 99),
        "R_w(w,w)": q(W, W),
        "S^20(R_w(w,w))": iterate_s(q(W, W), 20),
        "S^20(R_w(w,R_w(w,w)))": iterate_s(q(W, q(W, W)), 20),
    }
    named_rows = {name: diagnostic(h) for name, h in named.items()}

    boundary_rows = []
    for h in descriptors[:100]:
        for with_parameter in (False, True):
            e = eq(rec(h, X, A if with_parameter else ZERO), X)
            F = size(e)
            uniform = size(boundary(e, include_parameter=True))
            slim = size(boundary(e, include_parameter=with_parameter))
            assert uniform == F + 16
            assert slim == F + (16 if with_parameter else 15)
            boundary_rows.append({
                "equation": render(e), "F": F,
                "has_active_parameter": with_parameter,
                "uniform_boundary": uniform,
                "vacuous_binder_removed": slim,
            })

    formula_examples = {
        name: ([render(t) for t in body] if isinstance(body, tuple) else render(body))
        for name, body in all_formulas(iterate_s(V, 5)).items()
    }
    formula_examples["F_statefree_example"] = render(factored_statefree(q(W, W)))
    formula_examples["V_K_statefree_example"] = render(statefree_k(q(W, W)))
    return {
        "status": "PASS",
        "scope": [
            "Exact AST sizes and active-variable occurrence counts only.",
            "Every R application includes its recursively charged frozen descriptor.",
            "No primitive-recursive arithmetic or intuitionistic metatheorem is machine-proved by this script.",
            "Common envelopes omit logical-definition records; J and K are not supplied together for free.",
            "Q and Z use protected ordinary D modules in new selectors.",
        ],
        "script_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "generated_descriptor_count": len(descriptors),
        "formula_module_checks": sum(len(row["counts"]) for row in diagnostics),
        "boundary_checks": len(boundary_rows),
        "frozen_substitution_test": {
            "before": render(frozen_test), "after": render(substituted),
            "frozen_descriptor_identity_preserved": True,
        },
        "formulas": {
            "D": "3H+13+k(H+2)", "G_K": "3H+21", "T_K": "2H+33",
            "V_K": "2H+24 (k=0)", "W_J": "2H+32",
            "M": "2H+13+k(H+5)+3ell", "F": "2H+21 (k=0)",
        },
        "tie_order_new_chain": ["D", "G_K", "T_K", "M", "F"],
        "named_examples": named_rows,
        "formula_examples": formula_examples,
        "descriptor_diagnostics": diagnostics,
        "boundary_diagnostics": boundary_rows,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path,
        default=Path(__file__).resolve().parents[1] / "verification" / "syntax_checks.json",
    )
    args = parser.parse_args()
    result = run()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "generated_descriptors": result["generated_descriptor_count"],
        "formula_module_checks": result["formula_module_checks"],
        "boundary_checks": result["boundary_checks"],
        "output": str(args.output),
    }, indent=2))


if __name__ == "__main__":
    main()
