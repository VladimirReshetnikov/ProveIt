#!/usr/bin/env python3
"""A terminating, syntactic reducer for optional equation-boundary exports.

The reducer unfolds only ordinary recursor equations and only when full AST
size strictly decreases.  Frozen descriptors are never themselves rewritten.
It requires the complete theory's calibrated ordinary computation equations.
Finite example checks here do not prove arithmetic equivalence.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path

import check_sizes as ast


@dataclass(frozen=True)
class Rewrite:
    result: ast.Node
    path: tuple[int, ...]
    rule: str
    descriptor: ast.Node
    replaced: ast.Node
    replacement: ast.Node


def first_rewrite(term: ast.Node) -> Rewrite | None:
    """The first eligible active redex in leftmost preorder, if one exists."""
    if term.tag == "R":
        assert term.descriptor is not None
        counter, initial = term.args
        candidate = None
        rule = ""
        if counter.tag == "zero":
            candidate, rule = initial, "R0"
        elif counter.tag == "S":
            previous_counter = counter.args[0]
            candidate = ast.instantiate(
                term.descriptor,
                ast.rec(term.descriptor, previous_counter, initial),
                previous_counter,
            )
            rule = "RS"
        if candidate is not None and ast.size(candidate) < ast.size(term):
            return Rewrite(candidate, (), rule, term.descriptor, term, candidate)

    # Only active arguments are traversed.  In particular, descriptor is
    # copied by identity and is never passed recursively to this function.
    for i, argument in enumerate(term.args):
        inner = first_rewrite(argument)
        if inner is not None:
            args = list(term.args)
            args[i] = inner.result
            result = ast.Node(
                term.tag, tuple(args), name=term.name, descriptor=term.descriptor
            )
            return Rewrite(
                result, (i,) + inner.path, inner.rule, inner.descriptor,
                inner.replaced, inner.replacement,
            )
    return None


def normalize_term(term: ast.Node) -> tuple[ast.Node, list[dict]]:
    if not ast.valid_term(term):
        raise ValueError("Expected a legal finite recursor term")
    initial_size = ast.size(term)
    current = term
    trace = []
    while True:
        step = first_rewrite(current)
        if step is None:
            break
        before, after = ast.size(current), ast.size(step.result)
        assert after < before
        trace.append({
            "rule": step.rule,
            "active_path": list(step.path),
            "descriptor": ast.render(step.descriptor),
            "redex": ast.render(step.replaced),
            "replacement": ast.render(step.replacement),
            "term_before": ast.render(current),
            "term_after": ast.render(step.result),
            "size_before": before,
            "size_after": after,
        })
        current = step.result
        # This bound follows from strict descent of a positive integer.
        assert len(trace) <= initial_size - ast.size(current)
    return current, trace


def normalize_equation(equation: ast.Node) -> tuple[ast.Node, list[dict], bool]:
    if equation.tag != "=" or len(equation.args) != 2:
        raise ValueError("Expected an equation")
    if not ast.active_names(equation) <= {"x", "a"}:
        raise ValueError("Boundary equations permit only active variables x,a")
    left, trace_left = normalize_term(equation.args[0])
    right, trace_right = normalize_term(equation.args[1])
    trace = [dict(step, side="left") for step in trace_left]
    trace.extend(dict(step, side="right") for step in trace_right)
    swapped = ast.render(right) < ast.render(left)
    if swapped:
        left, right = right, left
    result = ast.eq(left, right)
    assert ast.size(result) <= ast.size(equation)
    return result, trace, swapped


def x_under_recursor(term: ast.Node) -> bool:
    """Whether an active occurrence of x lies beneath an R application."""
    if term.tag == "R" and any(ast.active_count(arg, "x") for arg in term.args):
        return True
    return any(x_under_recursor(arg) for arg in term.args)


def numeral(term: ast.Node) -> int | None:
    value = 0
    while term.tag == "S":
        value += 1
        term = term.args[0]
    return value if term.tag == "zero" else None


def omission_reason(equation: ast.Node) -> tuple[str | None, dict]:
    """A fixed priority order, with no proof search or semantic equality test."""
    if ast.active_count(equation, "x") == 0:
        return "induction_variable_absent", {}
    if equation.args[0] == equation.args[1]:
        return "literal_reflexivity", {}
    if not any(x_under_recursor(side) for side in equation.args):
        return "no_active_x_under_recursor", {}
    base_sides = [ast.substitute(side, {"x": ast.ZERO}) for side in equation.args]
    left, left_trace = normalize_term(base_sides[0])
    right, right_trace = normalize_term(base_sides[1])
    a, b = numeral(left), numeral(right)
    evidence = {
        "normalized_base": ast.render(ast.eq(left, right)),
        "left_numeral": a,
        "right_numeral": b,
        "base_normalization_trace": {
            "left": left_trace,
            "right": right_trace,
        },
    }
    if a is not None and b is not None and a != b:
        return "distinct_numerals_at_base", evidence
    return None, evidence


def reduce_equations(named_equations: list[tuple[str, ast.Node]]) -> dict:
    """Normalize, orient, deduplicate, and emit retained chain boundaries."""
    seen: dict[str, str] = {}
    records = []
    retained = []
    for label, original in named_equations:
        normalized, trace, swapped = normalize_equation(original)
        key = ast.render(normalized)
        row = {
            "label": label,
            "input_equation": ast.render(original),
            "input_equation_size": ast.size(original),
            "normalized_equation": key,
            "normalized_equation_size": ast.size(normalized),
            "orientation_swapped": swapped,
            "normalization_trace": trace,
        }
        if key in seen:
            row.update(status="omitted", reason="duplicate_normalized_equation", duplicate_of=seen[key])
            records.append(row)
            continue
        seen[key] = label
        reason, evidence = omission_reason(normalized)
        row.update(evidence)
        if reason is not None:
            row.update(status="omitted", reason=reason)
        else:
            has_parameter = ast.active_count(normalized, "a") > 0
            boundary = ast.boundary(normalized, include_parameter=has_parameter)
            expected = ast.size(normalized) + (16 if has_parameter else 15)
            assert ast.size(boundary) == expected
            row.update(
                status="retained",
                has_active_parameter=has_parameter,
                boundary=ast.render(boundary),
                boundary_size=ast.size(boundary),
            )
            retained.append({"label": label, "equation": key, "boundary": ast.render(boundary), "size": ast.size(boundary)})
        records.append(row)
    return {"records": records, "retained_boundaries": retained}


def examples() -> list[tuple[str, ast.Node]]:
    sx = ast.succ(ast.X)
    increment = ast.succ(ast.V)
    return [
        ("counter_reader_step", ast.eq(ast.q(sx, ast.A), ast.X)),
        ("symmetric_duplicate", ast.eq(ast.X, ast.q(sx, ast.A))),
        ("zero_update_step", ast.eq(ast.z(sx, ast.A), ast.ZERO)),
        ("base_unfolding_then_successor_omission", ast.eq(ast.rec(increment, ast.ZERO, ast.X), ast.A)),
        ("parameterized_retained", ast.eq(ast.rec(increment, ast.X, ast.A), ast.A)),
        ("parameter_free_retained", ast.eq(ast.rec(increment, ast.X, ast.ZERO), ast.X)),
        ("distinct_numerals_after_base_substitution", ast.eq(ast.rec(increment, ast.X, ast.ZERO), ast.succ(ast.ZERO))),
        ("exact_coverage", ast.eq(ast.X, ast.succ(ast.q(ast.X, ast.ZERO)))),
        ("recursor_independent_of_x", ast.eq(ast.succ(ast.X), ast.q(ast.A, ast.ZERO))),
        ("leftmost_preorder_two_steps", ast.eq(ast.q(ast.succ(ast.q(sx, ast.A)), ast.A), ast.X)),
        (
            "equal_size_step_is_blocked",
            ast.eq(ast.rec(increment, sx, ast.A), ast.succ(ast.rec(increment, ast.X, ast.A))),
        ),
        (
            "increasing_step_is_blocked",
            ast.eq(ast.rec(ast.q(ast.V, ast.V), sx, ast.ZERO), ast.ZERO),
        ),
        (
            "frozen_reducible_description_is_preserved",
            ast.eq(ast.rec(ast.q(ast.succ(ast.V), ast.W), ast.X, ast.ZERO), ast.X),
        ),
    ]


def run() -> dict:
    # Directly check that reducible syntax inside a stored description stays
    # frozen: no active redex exists in this whole term.
    frozen = ast.q(ast.succ(ast.V), ast.W)
    original = ast.rec(frozen, ast.X, ast.ZERO)
    unchanged, trace = normalize_term(original)
    assert unchanged == original and unchanged.descriptor is frozen and not trace

    # A size-preserving step and a size-increasing step must both be rejected.
    equal_term = ast.rec(ast.succ(ast.V), ast.succ(ast.X), ast.A)
    equal_rhs = ast.instantiate(ast.succ(ast.V), ast.rec(ast.succ(ast.V), ast.X, ast.A), ast.X)
    assert ast.size(equal_term) == ast.size(equal_rhs)
    assert first_rewrite(equal_term) is None
    growing_h = ast.q(ast.V, ast.V)
    growing_term = ast.rec(growing_h, ast.succ(ast.X), ast.ZERO)
    growing_rhs = ast.instantiate(growing_h, ast.rec(growing_h, ast.X, ast.ZERO), ast.X)
    assert ast.size(growing_rhs) > ast.size(growing_term)
    assert first_rewrite(growing_term) is None

    # The root redex must be taken before a reducible argument.
    root_first = ast.q(ast.succ(ast.q(ast.succ(ast.X), ast.A)), ast.A)
    normalized, root_trace = normalize_term(root_first)
    assert normalized == ast.X
    assert len(root_trace) == 2
    assert root_trace[0]["active_path"] == []

    result = reduce_equations(examples())
    rows = {row["label"]: row for row in result["records"]}
    assert rows["counter_reader_step"]["reason"] == "literal_reflexivity"
    assert rows["symmetric_duplicate"]["reason"] == "duplicate_normalized_equation"
    assert rows["distinct_numerals_after_base_substitution"]["reason"] == "distinct_numerals_at_base"
    assert rows["parameterized_retained"]["has_active_parameter"] is True
    assert rows["parameter_free_retained"]["has_active_parameter"] is False
    assert rows["exact_coverage"]["reason"] == "distinct_numerals_at_base"
    assert rows["recursor_independent_of_x"]["reason"] == "no_active_x_under_recursor"
    assert rows["frozen_reducible_description_is_preserved"]["normalization_trace"] == []
    for row in result["records"]:
        for step in row["normalization_trace"]:
            assert step["size_after"] < step["size_before"]

    result.update(
        status="PASS",
        script_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
        example_count=len(result["records"]),
        retained_count=len(result["retained_boundaries"]),
        omitted_count=sum(row["status"] == "omitted" for row in result["records"]),
        deterministic_strategy=[
            "Normalize the left side, then the right side.",
            "Within a term take the first strictly size-decreasing active redex in leftmost preorder, then restart.",
            "Only R0 and RS are rewrite rules; the folded equation M is not a rewrite rule.",
            "Orient the two normalized terms by lexical order of their unambiguous renderings.",
            "Discard later duplicates of that oriented equation.",
            "Apply omission tests in the order documented in omission_reason.",
            "Emit K boundary, universally binding a exactly when active.",
        ],
        support_and_scope=[
            "All ordinary recursor equations used in rewriting must already be recovered independently of these boundaries.",
            "Do not delete protected Q,Z computation support, separation, coverage, or other selected computation modules.",
            "The successor-only and unequal-numeral omissions require successor injectivity and separation; Q plus Sep supplies them.",
            "The old exact coverage equation is subsumed by the unequal-numeral base test, using Q and Sep.",
            "The program verifies deterministic syntax transformations and finite examples, not contextual logical equivalence or bi-interpretability.",
            "Termination follows mathematically from strict descent of positive full AST sizes; each recorded example confirms its own descent.",
        ],
        dedicated_checks={
            "frozen_descriptor_identity_preserved": True,
            "equal_size_rewrite_rejected": True,
            "increasing_size_rewrite_rejected": True,
            "root_before_active_argument": True,
        },
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path,
        default=Path(__file__).resolve().parents[1] / "verification" / "boundary_reduction.json",
    )
    args = parser.parse_args()
    result = run()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "examples": result["example_count"],
        "retained": result["retained_count"],
        "omitted": result["omitted_count"],
        "output": str(args.output),
    }, indent=2))


if __name__ == "__main__":
    main()
