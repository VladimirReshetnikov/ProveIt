#!/usr/bin/env python3
"""Rebuild the reproducible syntax results and the self-contained report."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
CHECKS = ("code/check_sizes.py", "code/reduce_boundaries.py")

def run(args: list[str], log: Path | None = None) -> None:
    result = subprocess.run(args, cwd=ROOT, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT)
    if log is not None:
        log.write_text(result.stdout)
    if result.returncode:
        print(result.stdout)
        raise SystemExit(result.returncode)

def main() -> None:
    verification = ROOT / "verification"
    verification.mkdir(exist_ok=True)
    for script in CHECKS:
        run([sys.executable, script], verification / (Path(script).stem + ".log"))
    for number in (1, 2, 3):
        run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
            verification / f"latex_pass_{number}.log")
    pdf = ROOT / "report.pdf"
    result = {
        "pdf": "report.pdf",
        "pdf_bytes": pdf.stat().st_size,
        "pdf_sha256": hashlib.sha256(pdf.read_bytes()).hexdigest(),
        "syntax_checks": "passed",
        "latex_passes": 3,
        "lean": "reviewed source; uncompiled in this run",
        "full_equivalence": "written mathematical proof; not fully mechanized",
        "visual_review": "not performed by this script; see delivered visual_review.json"
    }
    (verification / "build.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
