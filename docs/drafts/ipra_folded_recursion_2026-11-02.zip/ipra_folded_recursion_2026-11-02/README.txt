iPRA WITH A FOLDED RECURSION EQUATION
Prepared for Vladimir Reshetnikov -- 2 November 2026
=================================================

START HERE
  report.pdf       Complete report, exact theory, proofs, comparison, limits.
  report.tex       Main LaTeX source; sections/ contains all included sources.
  AXIOMS.txt       Standalone compact specification of the recommended theory.

NEW RESULT
With Q=R_w and Z=R_0 protected by their ordinary computation equations,
the complete initialized recursion pair can be replaced by

  forall a n,
  R_h(n,a) = Q(Z(n,S(a)), h(R_h(Q(n,0),a),Q(n,0))).

Its exact full-tree size is 2H+13+k(H+5)+3ell, where H counts every
frozen nested descriptor recursively, k counts active state occurrences,
and ell counts active counter occurrences. A state-independent version
binding Q(n,0) once has size 2H+21. Neither new form uses a new logical
connective. The report proves intuitionistic equivalence with the ordinary
equations and a full-carrier identity bi-interpretation with first-order iPRA.

All five current and six archived source packages were reviewed at commit
0593751362f559ccc52e269fe5ecac06a7d6e63c. Each current package survives the
package-level improvement filter. The source ZIPs themselves are not
redistributed; provenance/source_manifest.json contains their names, exact
Git blob SHAs, repository snapshot, and SHA-256 hashes.

FILES AND STATUS
  code/check_sizes.py
    Pure Python 3; AST construction and exact size accounting, with frozen
    descriptor substitution. The code calls the predecessor-binding module
    F; it is the module L in the mathematical report.
  code/reduce_boundaries.py
    Pure Python 3; the specified terminating size-decreasing normalizer,
    orientation/deduplication, omission tests, and unused-binder removal.
  verification/syntax_checks.json
    Reproducible syntax results: 409 descriptors, 2339 formula-module counts,
    200 boundary counts, plus a frozen-substitution check.
  verification/boundary_reduction.json
    Thirteen example reductions and additional normalization checks.
  formal/FoldedRecursion.lean
    Reviewed constructive Lean 4 SOURCE, UNCOMPILED in this run. Uses Init.
    Local equivalence/boundary kernels only; no full formalization of the
    arithmetic compiler or bi-interpretability theorem is claimed.
  formal/STATUS.txt
    Exact scope and compilation limitation of the optional Lean source.
  provenance/draft_audit.txt
    Detailed source comparison and prior-art notes.
  provenance/source_manifest.json
    Reproducible source identities.
  verification/build.json
    Build and rendering metadata for the delivered PDF.
  SHA256SUMS.txt
    Integrity hashes for all package files except this hash file itself.

REPRODUCE
  python3 build.py

This runs both syntax programs and pdflatex three times. Python 3.10 or newer and
a LaTeX installation with standard AMS, Latin Modern, geometry, microtype,
booktabs, fancyhdr, hyperref, bookmark, and enumitem packages are required.
The script does not download anything and does not run the Lean source.
To check that optional source in an installed Lean 4 environment:

  lean formal/FoldedRecursion.lean

IMPORTANT INTERPRETATION OF THE RESULT
This is a strict improvement of the disclosed, fully priced presentation
frontier. It is not an absolute shortest-axiomatization theorem over all
possible signatures or inference rules. Finite exports must charge missing
Q,Z,coverage and logical-definition support; the old export remains a
candidate when it is cheaper. Numerical examples in the report are complete
module sizes with common support, not proof-length bounds. All arithmetic
claims are specifically intuitionistic; classical equivalence is not used.

The complete deliverable is contained in this folder. No external source
package is needed to read the proofs or reproduce the checks and PDF.
