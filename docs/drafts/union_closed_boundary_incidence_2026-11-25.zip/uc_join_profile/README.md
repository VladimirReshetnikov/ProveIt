# Sharp boundary-incidence bounds for union-closed families

Research note for ProveIt, 25 November 2026. Start with **paper.pdf** (9 pages). The complete editable source is `paper.tex`.

## Main results

- A prescribed element of support E has frequency at least `mu/(1+mu)`, where mu is the fair-cube average number of distinct proper traces obtained from the internal support union family after adjoining a random union of boundary traces. The bound is sharp for every prescribed local profile, and holds conditional on every canonical exterior-only fibre.
- If a marked support has r generator indices, each in at most d crossing supports, and each crossing support meets at most ell marked indices, its frequency is at least `(1-delta)/(2-delta)`, `delta=(1-2^(-d))^(r/ell)`. Sharp when ell divides r. Approaches 1/2 exponentially for fixed d and ell.
- If the marked support partitions into internal support blocks, the score gives an explicit half-frequency certificate. Two equal blocks of size s with singleton crossing traces and at most d per index give `1-(2-(1-2^(-d))^s)^(-2)`; for s=2^d this exceeds 5/9. Connected examples have no private ground points, indispensable generators and unbounded minimum nonempty member size.
- The 12-generator example with 39 ground points has 3,120 distinct unions and a certified marked frequency at least 273/529; its actual marked frequency is 179/195.

## Contents and reproduction

- `paper.tex`, `paper.pdf`: self-contained mathematical proof and compiled manuscript.
- `verify.py`: standard-library exact finite audits, with checks that remain enabled under `python -O`.
- `verification.json`: actual full verification run, including exact counts and sharpness examples.
- `example_clique.json`: explicit 12-index example in the dual support format.
- `provenance.md`: repository and literature audit, attribution and limitations.
- `Makefile`, `SHA256SUMS`: build and integrity commands.

```sh
sha256sum -c SHA256SUMS
python3 verify.py > verification-new.json
diff -u verification.json verification-new.json
python3 verify.py --input example_clique.json
make pdf
```

Python 3.10+; a TeX Live installation with AMS, Latin Modern, geometry, microtype, booktabs, hyperref and xcolor. `--quick` runs a reduced audit. The input checker enumerates the actual family and is intended for small explicit examples; the profile itself can be computed without enumerating the full family, as explained in the manuscript. Recompiling the PDF can change its metadata and checksum.

The main results are proved mathematically, not inferred from finite experiments. The bound is sharp for the prescribed element, not the maximum frequency. The general conjecture and historical priority are not established. No independent human refereeing or proof-assistant formalization is claimed. No GitHub files were changed.
