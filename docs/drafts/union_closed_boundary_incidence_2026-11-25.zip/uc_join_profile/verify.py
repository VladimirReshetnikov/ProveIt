#!/usr/bin/env python3
"""Exact finite audits for the boundary-incidence theorem (Python 3.10+)."""
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import combinations
import argparse
import json
import random


def check(cond, msg):
    if not cond:
        raise AssertionError(msg)


def unions(edges):
    u = {0}
    for e in edges:
        u |= {x | e for x in u}
    return u


def inside(e, s):
    return e & s == e


def trim(edges, s):
    out = 0
    for e in edges:
        if inside(e, s):
            out |= e
    return out


def profile(edges, e):
    internal = [h for h in edges if inside(h, e)]
    boundary = [h for h in edges if h & e and h & ~e]
    exterior = [h for h in edges if not h & e]
    c = unions(internal)
    counts = Counter({0: 1})
    for h in boundary:
        nxt = counts.copy()
        for j, cnt in counts.items():
            nxt[j | (h & e)] += cnt
        counts = nxt
    score = lambda j: len({j | y for y in c}) - 1
    num = sum(cnt * score(j) for j, cnt in counts.items())
    den = 1 << len(boundary)
    check(sum(counts.values()) == den, 'profile mass')
    return Fraction(num, den), c, boundary, exterior, score


def audit(edges, e, u=None):
    if u is None:
        u = unions(edges)
    mu, _, _, _, _ = profile(edges, e)
    a = sum(inside(e, w) for w in u)
    p = len(u) - a
    check(a > 0 and Fraction(p, a) >= mu, ('main inequality', edges, e, p, a, mu))
    return Fraction(p, len(u)), mu / (1 + mu)


def subset_unions(seq):
    arr = [0]
    for e in seq:
        arr += [x | e for x in arr]
    return arr


def audit_fibres(edges, e):
    """Construct the canonical downsets, checking the key proof inequalities."""
    u = unions(edges)
    mu, c, boundary, exterior, score = profile(edges, e)
    bu = subset_unions(boundary)
    check(sum(score(z & e) for z in bu) == mu * len(bu), 'direct average')
    grouped = defaultdict(lambda: [set(), set()])
    for w in u:
        r = w & ~e
        t = trim(exterior, r)
        grouped[t][int(inside(e, w))].add(w)
    for t, (proper, full) in grouped.items():
        canon = {}
        for i, z in enumerate(bu):  # bitmask is a positive additive weight
            x = z & ~e & ~t
            if trim(exterior, t | x) == t:
                canon.setdefault(x, i)
        d = set(canon.values())
        check(full == {e | t | x for x in canon}, 'full-fibre characterization')
        for i in d:
            for k in range(len(boundary)):
                if i >> k & 1:
                    check(i ^ (1 << k) in d, 'canonical downset')
        total = sum(score(bu[i] & e) for i in d)
        check(Fraction(total, len(d)) >= mu, 'Harris comparison')
        constructed = {t | bu[i] | y for i in d for y in c if not inside(e, bu[i] | y)}
        check(len(constructed) == total and constructed <= proper, 'proper injection')
        check(len(proper) >= mu * len(full), 'conditional inequality')
    return len(grouped)


def primal_dual(edges, n):
    """Independently generate the original family from incidence columns."""
    gens = [sum(1 << i for i, h in enumerate(edges) if h >> v & 1) for v in range(n)]
    f = unions(gens)
    dual = unions(edges)
    absence_to_w = {a: trim([h for i, h in enumerate(edges) if not a >> i & 1], (1 << n)-1) for a in f}
    check(set(absence_to_w.values()) == dual and len(f) == len(dual), 'duality')
    for a, w in absence_to_w.items():
        check(all(bool(a >> i & 1) == (not inside(h, w)) for i, h in enumerate(edges)), 'frequency correspondence')
    return f, gens


def sharp_profile(r, internal, boundary_patterns):
    e = (1 << r) - 1
    edges = sorted(set(internal) | {e}) + [b | (1 << (r+i)) for i, b in enumerate(boundary_patterns)]
    p, bound = audit(edges, e)
    check(p == bound, 'profile sharpness')
    audit_fibres(edges, e)
    return p


def block_clique(d, s):
    r = 2*s
    e = (1 << r) - 1
    edges = [e, (1 << s)-1, e ^ ((1 << s)-1)]
    outside = list(range(r, r+r*d))
    edges.extend((1 << v) | (1 << outside[v*d+j]) for v in range(r) for j in range(d))
    edges.extend((1 << v) | (1 << w) for v,w in combinations(outside,2))
    return edges, e, r+len(outside)


def show(fr):
    return {'exact': str(fr), 'decimal': round(float(fr), 12)}


def threshold(d):
    s = 1
    while (2*(1 << (d*s)) - (2**d-1)**s)**2 < 2*(1 << (2*d*s)):
        s += 1
    p = 1 - Fraction(1, (2 - Fraction(2**d-1, 2**d)**s)**2)
    check(p >= Fraction(1,2), 'threshold')
    if s > 1:
        check((2-Fraction(2**d-1,2**d)**(s-1))**2 < 2, 'threshold minimality')
    return s, p


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--quick', action='store_true')
    ap.add_argument('--input', help='JSON with edges and marked as lists of nonnegative vertex labels')
    args = ap.parse_args()
    if args.input:
        with open(args.input) as fh:
            spec = json.load(fh)
        def mask(xs):
            check(all(isinstance(x,int) and x >= 0 for x in xs), 'vertex labels must be nonnegative integers')
            return sum(1 << x for x in set(xs))
        es = sorted({mask(x) for x in spec['edges']})
        e = mask(spec['marked'])
        check(0 not in es and e in es, 'nonempty supports and marked support required')
        p, bound = audit(es, e)
        print(json.dumps({'actual_frequency':show(p),'sharp_profile_bound':show(bound),'half_certificate':bound>=Fraction(1,2)},indent=2)); return
    rng = random.Random(20261125)
    graphs = marks = 0
    for n in range(1, 4 if args.quick else 5):
        for hmask in range(1, 1 << ((1 << n)-1)):
            edges = [e for e in range(1,1<<n) if hmask >> (e-1) & 1]
            u = unions(edges)
            graphs += 1
            for e in edges:
                audit(edges,e,u); marks += 1
    fibre_count = fibre_marks = 0
    for _ in range(70 if args.quick else 350):
        n = rng.randrange(4,10)
        edges = rng.sample(range(1,1<<n),rng.randrange(1,min(13,(1<<n)-1)+1))
        u = unions(edges)
        primal_dual(edges,n)
        for e in edges:
            audit(edges,e,u)
        e = rng.choice(edges)
        fibre_count += audit_fibres(edges,e); fibre_marks += 1
    sharp_cases = 0
    for _ in range(80 if args.quick else 400):
        r = rng.randrange(1,7)
        e = (1 << r)-1
        internal = rng.sample(range(1,e+1),rng.randrange(1,min(e,9)+1))
        pats = [rng.randrange(1,e+1) for _ in range(rng.randrange(0,9))]
        sharp_profile(r, internal, pats); sharp_cases += 1
    # Read-k equality: equal-size groups share exactly d boundary choices.
    read_k = []
    for ell,d,groups in [(1,2,3),(2,3,2),(3,2,4),(2,1,5),(4,2,2)]:
        r = ell*groups; e=(1<<r)-1
        pats = [((1<<ell)-1) << (ell*i) for i in range(groups) for _ in range(d)]
        p = sharp_profile(r,[e],pats)
        delta = (1-Fraction(1,2**d))**groups
        check(p == (1-delta)/(2-delta), 'read-k sharpness')
        read_k.append({'r':r,'ell':ell,'d':d,'frequency':show(p)})
    edges,e,n = block_clique(2,2)
    p,bound = audit(edges,e)
    f,gens = primal_dual(edges,n)
    check(all(h.bit_count()>=2 for h in edges), 'no private ground point')
    check(min(g.bit_count() for g in gens)==4, 'minimum generator size')
    check(all(not inside(g,h) for i,g in enumerate(gens) for j,h in enumerate(gens) if i!=j), 'generator incomparability')
    check(bound==Fraction(273,529), 'block certificate')
    # The profile extremizer with the same local profile and private exterior.
    sharp=sharp_profile(4,[3,12,15],[1,1,2,2,4,4,8,8])
    check(sharp==bound, 'block exact extremizer')
    result = {'exhaustive_hypergraphs':graphs,'exhaustive_marked_supports':marks,
              'random_fibre_marks':fibre_marks,'random_fibres':fibre_count,
              'random_sharp_profiles':sharp_cases,'read_k_sharpness':read_k,
              'block_clique':{'vertices':n,'supports':len(edges),'distinct_unions':len(f),
                              'marked_present':sum(bool(a&1) for a in f),'frequency':show(p),
                              'profile_bound':show(bound),'minimum_generator_size':4},
              'two_block_thresholds':[{'d':d,'minimum_s':s,'frequency':round(float(p),12)}
                                     for d in range(1,11) for s,p in [threshold(d)]],
              'status':'all checks passed'}
    print(json.dumps(result,indent=2))

if __name__ == '__main__':
    main()
