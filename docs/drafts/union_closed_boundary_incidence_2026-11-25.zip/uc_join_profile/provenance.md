# Provenance and novelty assessment

## Repository audit (25 November 2026)

The GitHub connector returned the directory listing for
https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts .
ZIP members were retrieved through the repository file endpoint in base64 and text members decoded. The following relevant README/abstract material was inspected (not an exhaustive line-by-line proof review). The blob IDs of the closest antecedents are included to help reproduce the comparison.

| Draft | Blob SHA | Relevant reported result |
|---|---|---|
| `union_closed_dense_core_2026-11-25.zip` | `b1c269b2ae1cdb03f91797a2bf840e96730c5934` | Robust fixed one- or two-mark certificate for every translate of a core with at most three omissions. |
| `union_closed_marked_abundance.zip` | `25495ddc85bae5c765322bf19546314aefa79619` | Small exceptional core, common weighting over all translates; graph and local-deletion results. |
| `union_closed_signature_interfaces_2026-11-25.zip` | `7d715274e013371d5d4156b461f970c50c1f9c00` | Separating signatures, projection counts and interface-rank bounds. |
| `union_closed_redundant_core_2026-11-25.zip` | `18cd1e26f63dee50486533964e3fbf085660af09` | Complete incidence cores, redundancy and sharp weighted frequency bounds. |
| `union_closed_exact_obstruction_theorems_2026-11-25.zip` | `a43404f7da75f9466787900b24363f9959c0f49c` | Minimal trace-obstruction sizes and robust marked-pair certificates. |
| `union_closed_sharp_trace_obstructions_2026-11-25.zip` | `bef1e8104a5bc31e1246f27867e88a73441a4423` | Robust marked-pair trace obstructions and weighted consequences. |
| `union_closed_lopsided_certificates_2026-11-25.zip` | `6a4907063eaf84961dcfacea3718ebf7741ff100` | Harris inequality and local-lemma improvement for support hypergraphs. |
| `union_closed_substitution.zip` | `ed07cbc73f2d66acf503b5d34206b7bfd65afad1` | Complete substitution, weighted base and product-fibre formula. |
| `union_closed_defective_substitution.zip` | `14d8202bb57108a1908e62bec65918ac030e7571` | Incomplete substitutions and local line conditions. |

Other inspected README/abstracts:

- `union_closed_antichain_shadows_2026-11-25.zip`
- `union_closed_rank_transport_2026-11-25.zip`
- `union_closed_local_abundance.zip`
- `union_closed_cycle_certificates.zip`
- `union_closed_transversal_bounds.zip`
- `union_closed_frequency_bounds.zip`
- `union_closed_extensions_2026-11-25.zip`
- `union_closed_extensions_2026-11-25(1).zip`
- `union_closed_refinements_2026-11-25.zip`
- `union_closed_advances_2026-11-25.zip`

The member listing of `union_closed_joint_laws_2026-11-25.zip` was inspected, but its proof text was not reviewed. `union_closed_structural_theorems.zip` was fetched but no README or TeX text was extracted by the ZIP-member parser; its content is not claimed to have been reviewed. Other archives were seen in the directory listing only. There was no repository write.

## Public literature

The problem statement and recent progress were checked at:

- https://en.wikipedia.org/wiki/Union-closed_sets_conjecture
- https://arxiv.org/abs/2610.02295 — Costa and Sadhu, October 1, 2026, unconditional reported bound 0.3828852549667978.
- https://arxiv.org/abs/2301.01331 — Pulaj and Wood, local configuration certificates extending Poonen's theorem.
- https://doi.org/10.1090/mcom/3461 — Pulaj's cutting-plane framework.
- https://www.sciencedirect.com/science/article/pii/0097316592900686 — Poonen's 1992 paper.
- https://mathworld.wolfram.com/Union-ClosedSetsConjecture.html — general context.

A more recent online claim of 0.38317525996679... was also surfaced at https://quantavane.com/major-results/union-closed-sets-conjecture/ ; it was not independently verified here and no ranking of current universal records is claimed. Targeted searches combined Frankl/union-closed sets with hypergraph supports, distinct unions, generator traces, local incidence, and Harris. The search did not locate the exact profile theorem, but cannot rule out equivalent statements in the literature. The supplied elementary proofs do not use these external results as premises.

## Specific candidate contribution

The closest distinction is the use of a hereditary minimum-weight transversal of the residual-union map, followed by Harris's inequality for a decreasing count of proper traces. This turns the worst-case translate requirement into a sharp mean certificate, without assuming that uniform generator selections give uniform distinct unions. The exact extremizer for *every* multiset of boundary traces and internal support system, the read-ell bound, and the block threshold are the specific proposed extensions. This is not a claim that all techniques (duality, Harris, generalized Holder) are new, nor that the examples evade all previous known FC criteria. The contribution is restricted; neither a new general frequency constant nor a proof of unrestricted Frankl is claimed. Historical novelty remains provisional, especially given the selective repository comparison and no independent expert review.
