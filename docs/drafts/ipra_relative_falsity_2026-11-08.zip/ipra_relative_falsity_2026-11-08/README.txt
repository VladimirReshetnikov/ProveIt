RELATIVE FALSITY, ZERO TESTS, AND THE iPRA MINIMIZATION PROBLEM
Prepared for Vladimir Reshetnikov — 8 November 2026 (Pacific date)

STATUS
The requested complete-checker reduction below the current comparison
envelope was not obtained. This archive does not claim a smallest theory,
a new complete kernel, or a positive proof-checker size record.

The paper proves two results new relative to the six inspected reports:
1. Relative-bottom Boolean gluing permits branch proofs using the falsity
   bridge and a larger conclusion grammar containing certain implications.
2. Zero-test induction does not recover equation induction even with actual
   numerical coverage, successor injectivity and separation. A tagged
   ultrapower countermodel also blocks finite-dimensional bi-interpretations
   with iPRA, including quotients and countably many parameters. Adding the
   single successor-clock equation still fails; adding arbitrary true
   zero-test sentences still fails.

An explicit ordinary scalar sequent calculus and standard partial cut
elimination are included. The complete inherited scalar arithmetic
equivalence and its internal interpretation composites are documented,
with the arithmetic foundation reproduced and attributed in the appendix.

MAIN FILES
report.pdf                 Compiled research paper.
report.tex                 Main LaTeX source.
sections/                  New exposition, proofs, and evidence discussion.
reference/                 Attributed inherited arithmetic foundation.
comparison/baselines/      Twelve unchanged complete comparator programs.
comparison/measure.py      Current-snapshot audit wrapper.
comparison/inherited_measure.py  Unchanged source-normalization implementation.
verification/              Symbolic fragment certificates and finite diagnostics.
results/                   Recomputed metrics and explicitly scoped test outputs.
provenance/                Input archive manifest, licenses, and attribution.
SHA256SUMS.txt              Distribution checksums, excluding this checksum file.

REPRODUCTION
Use Python 3.10 or newer. No nonstandard Python package is required.
The supplied source metrics were reproduced with Python 3.12.14.
    python3 reproduce.py
Compile with an installed pdflatex / TeX Live environment:
    python3 build.py

The twelve whole-program comparator sources measure to the coordinatewise
envelope 317 normalized tokens / 348 AST nodes / 885 normalized bytes.
Different programs attain these minima. These are empirical source metrics,
not a universal lower-bound theorem and not a correctness proof.

VERIFICATION LIMITS
The relative-collapse verifier checks two symbolic equations with free
variables. It assumes explicit selector equations whose derivations are
given in the paper. It is not a complete iPRA checker. The tagged-algebra
script checks finite precursor evaluations; it cannot verify an ultrapower,
an infinite induction schema, or the bi-interpretation obstruction.
Those results have written mathematical proofs and received separate
internal reviews during this investigation. No Lean or Rocq formalization
is claimed.

SOURCE BOUNDARY
Repository: VladimirReshetnikov/ProveIt
Commit: 9773e5e0376fdaf953567d0e1e6f19570d566bc6
Directory: docs/drafts
All six ZIP sizes and Git blob identities were verified. Their SHA-256
hashes and pinned URLs are in provenance/source_manifest.json.
No repository changes were made for this deliverable.
