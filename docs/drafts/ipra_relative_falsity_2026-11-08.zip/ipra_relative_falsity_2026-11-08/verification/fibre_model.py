#!/usr/bin/env python3
"""Finite diagnostics for the tagged scalar-iteration countermodel.

These computations check representative finite evaluations in the elementary
tagged algebra A.  They do not verify the ultrapower construction, induction
schema, or non-bi-interpretability theorem; those require the paper's proof.

Terms: a variable string, ('0',), ('S', term), or
('I', counter, initializer, bound_state_variable, update_body).
The update is a proper subtree; it may capture the ambient parameters.
"""

import argparse
import json
import random
from pathlib import Path


ZERO = ('0',)


def successor(term):
    return ('S', term)


def iterator(counter, initial, variable, body):
    return ('I', counter, initial, variable, body)


def numeral(n):
    term = ZERO
    for _ in range(n):
        term = successor(term)
    return term


def evaluate(term, environment, tagged, fuel=None, profile='basic'):
    """Literal finite-iteration semantics; tagged values are (height, tag)."""
    if fuel is None:
        fuel = [200000]
    fuel[0] -= 1
    if fuel[0] < 0:
        raise RuntimeError('Diagnostic evaluation fuel exhausted')
    if isinstance(term, str):
        return environment[term]
    if term[0] == '0':
        return (0, 0) if tagged else 0
    if term[0] == 'S':
        value = evaluate(term[1], environment, tagged, fuel, profile)
        return (value[0] + 1, value[1]) if tagged else value + 1
    if term[0] != 'I' or len(term) != 5:
        raise ValueError('Malformed diagnostic term')
    _, count, initial, variable, body = term
    count = evaluate(count, environment, tagged, fuel, profile)
    value = evaluate(initial, environment, tagged, fuel, profile)
    if tagged and profile == 'clock_repair' and count[1] != 0:
        if body == successor(variable):
            return (count[0] + value[0], count[1])
        if body == variable:
            return (value[0], 0)
    count = count[0] if tagged else count
    local = dict(environment)
    for _ in range(count):
        local[variable] = value
        value = evaluate(body, local, tagged, fuel, profile)
    return value


def permute(value):
    n, j = value
    return (n, 2 if j == 1 else 1 if j == 2 else j)


def canonical(value):
    return (value[0], 0)


def in_high_tag_subalgebra(value, bound):
    n, j = value
    return j == 0 or n > bound


def generated_term(rng, depth, variables):
    if depth == 0:
        return rng.choice([ZERO, numeral(1), *variables])
    choice = rng.randrange(4)
    if choice == 0:
        return rng.choice([ZERO, *variables])
    if choice == 1:
        return successor(generated_term(rng, depth - 1, variables))
    variable = 'u' + str(depth)
    # Small counters bound diagnostic cost without restricting the theorem.
    count = rng.choice([ZERO, numeral(1), numeral(2), 'x'])
    initial = generated_term(rng, depth - 1, variables)
    body = generated_term(rng, depth - 1, [*variables, variable])
    return iterator(count, initial, variable, body)


def run():
    rng = random.Random(20261108)
    nu = iterator('x', ZERO, 'u', successor('u'))
    zero_test = iterator('x', numeral(1), 'u', ZERO)
    addition = iterator('x', 'y', 'u', successor('u'))
    selector = iterator('x', 'y', 'u', 'z')
    identity_iteration = iterator('x', 'y', 'u', 'u')
    nested = iterator('x', 'y', 'u',
                      iterator(numeral(2), 'u', 'v', successor('v')))
    terms = [nu, zero_test, addition, selector, identity_iteration, nested]
    terms += [generated_term(rng, 4, ['x', 'y', 'z']) for _ in range(200)]

    projection_checks = 0
    zero_observation_checks = 0
    equivariance_checks = 0
    closure_checks = 0
    for term in terms:
        for _ in range(12):
            environment = {}
            for variable in ('x', 'y', 'z'):
                n = rng.randrange(5)
                environment[variable] = (n, 0 if n == 0 else rng.randrange(4))
            value = evaluate(term, environment, True)
            numerical = evaluate(term, {v: a[0] for v, a in environment.items()}, False)
            assert value[0] == numerical
            projection_checks += 1
            canonical_value = evaluate(term, {v: canonical(a) for v, a in environment.items()}, True)
            assert (value == (0, 0)) == (canonical_value == (0, 0))
            zero_observation_checks += 1
            permuted = evaluate(term, {v: permute(a) for v, a in environment.items()}, True)
            assert permuted == permute(value)
            equivariance_checks += 1
        for bound in (0, 1, 3):
            environment = {
                'x': (2, 0),
                'y': (bound + 1, 1),
                'z': (bound + 3, 2),
            }
            assert all(in_high_tag_subalgebra(a, bound) for a in environment.values())
            value = evaluate(term, environment, True)
            assert in_high_tag_subalgebra(value, bound)
            closure_checks += 1

    elements = [(0, 0)] + [(n, j) for n in range(1, 8) for j in range(4)]
    successors = [(n + 1, j) for n, j in elements]
    assert len(set(successors)) == len(elements)
    assert (0, 0) not in successors
    boolean_checks = 0
    retraction_checks = 0
    for a in elements:
        env = {'x': a}
        result = evaluate(zero_test, env, True)
        assert result == ((1, 0) if a == (0, 0) else (0, 0))
        boolean_checks += 1
        normal = evaluate(nu, env, True)
        assert normal == canonical(a)
        assert evaluate(nu, {'x': normal}, True) == normal
        assert evaluate(nu, {'x': (a[0] + 1, a[1])}, True) == (normal[0] + 1, 0)
        retraction_checks += 1

    witness = (4, 2)
    normal_witness = evaluate(nu, {'x': witness}, True)
    assert normal_witness != witness
    # Coverage genuinely fails in this finite-height algebra at (1, 2).
    # The paper moves every retained noncanonical tag beyond all standard
    # heights in a subalgebra of an ultrapower to repair coverage.
    for n in range(2, 8):
        for j in range(4):
            predecessor = (n - 1, j)
            assert (predecessor[0] + 1, predecessor[1]) == (n, j)

    repair_recurrence_checks = 0
    for n in elements:
        assert evaluate(nu, {'x': n}, True, profile='clock_repair') == n
        for a in elements:
            env = {'x': n, 'y': a}
            next_env = {'x': (n[0] + 1, n[1]), 'y': a}
            add_value = evaluate(addition, env, True, profile='clock_repair')
            add_next = evaluate(addition, next_env, True, profile='clock_repair')
            assert add_next == (add_value[0] + 1, add_value[1])
            assert add_value[0] == n[0] + a[0]
            id_value = evaluate(identity_iteration, env, True, profile='clock_repair')
            id_next = evaluate(identity_iteration, next_env, True, profile='clock_repair')
            assert id_value == id_next
            assert id_value[0] == a[0]
            repair_recurrence_checks += 2
    repair_witness_env = {'x': (4, 1), 'y': (3, 2)}
    repair_result = evaluate(identity_iteration, repair_witness_env, True, profile='clock_repair')
    assert repair_result == (3, 0) != repair_witness_env['y']

    return {
        'status': 'PASS',
        'scope': 'Finite diagnostics in A, not a formal verification of the ultrapower theorem',
        'seed': 20261108,
        'terms': len(terms),
        'projection_checks': projection_checks,
        'zero_observation_checks': zero_observation_checks,
        'tag_equivariance_checks': equivariance_checks,
        'high_tag_subalgebra_checks': closure_checks,
        'successor_injectivity_sample_size': len(elements),
        'boolean_range_checks': boolean_checks,
        'canonical_retraction_checks': retraction_checks,
        'eta_counterexample': {'input': witness, 'I_S_input_zero': normal_witness},
        'coverage_boundary_in_A': [1, 2],
        'clock_repair_variant': {
            'eta_checks': len(elements),
            'recurrence_checks': repair_recurrence_checks,
            'identity_iterator_counterexample': {
                'counter': repair_witness_env['x'],
                'initializer': repair_witness_env['y'],
                'value': repair_result,
            },
            'scope': 'Fixed staged descriptions; no primitive index extensionality',
        },
        'unverified_by_computation': [
            'Existence and properties of the nonprincipal ultrafilter',
            'Subalgebra intersection in the ultrapower',
            'All zero-test formula induction instances',
            'The finite-parameter automorphism and bi-interpretation obstruction',
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = run()
    text = json.dumps(result, indent=2) + '\n'
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding='utf-8')
    print(text, end='')


if __name__ == '__main__':
    main()
