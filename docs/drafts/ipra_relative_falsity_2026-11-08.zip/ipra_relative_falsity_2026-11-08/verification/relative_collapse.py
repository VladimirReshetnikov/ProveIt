#!/usr/bin/env python3
"""Symbolic equational certificates for the relative-bottom collapse lemma.

This is a small fragment verifier, NOT a complete iPRA checker.  It checks
q(s,0)=q(t,0) from q(0,0)=q(1,0), and the analogous right-factor statement.
The selector equations and centrality for C are explicit assumed schemas.
Their derivation from scalar arithmetic is a separate written proof.

The letters s,t remain free variables.  No finite numerical examples or
numerical evaluator are used.  Certificate production is separate from
verification: the kernel derives every line using the listed schemas and
ordinary hypothesis, reflexivity, symmetry, transitivity, and congruence.
"""

import copy
import json
from pathlib import Path


ARITY = {"C": 3, "q": 2}
AXIOMS = {
    "selector_zero": [["C", "0", "?a", "?b"], "?a"],
    "selector_one": [["C", "1", "?a", "?b"], "?b"],
    "central_selector": [
        ["C", ["q", "?x0", "?y0"], ["q", "?x1", "?y1"],
         ["q", "?x2", "?y2"]],
        ["q", ["C", "?x0", "?x1", "?x2"],
         ["C", "?y0", "?y1", "?y2"]],
    ],
}


class ProofError(ValueError):
    """A certificate fails its explicit equational contract."""


def require(condition, message):
    if not condition:
        raise ProofError(message)


def term_ok(term):
    if isinstance(term, str):
        return bool(term) and not term.startswith("?")
    return (type(term) is list and len(term) > 0
            and isinstance(term[0], str) and term[0] in ARITY
            and len(term) == ARITY[term[0]] + 1
            and all(term_ok(arg) for arg in term[1:]))


def schema_variables(term):
    if isinstance(term, str):
        return {term} if term.startswith("?") else set()
    return set().union(*(schema_variables(arg) for arg in term))


def instantiate(term, environment):
    if isinstance(term, str):
        return environment[term] if term.startswith("?") else term
    return [instantiate(arg, environment) for arg in term]


def verify(steps, assumptions, goal):
    """Verify steps against separately supplied assumptions and conclusion."""
    require(type(steps) is list, "The proof must be a list of steps")
    for equation in assumptions + [goal]:
        require(type(equation) is list and len(equation) == 2
                and all(term_ok(term) for term in equation), "Malformed equation")
    derived = []

    def previous(index):
        require(type(index) is int and 0 <= index < len(derived),
                "Proof reference is not an earlier line")
        return derived[index]

    for line, step in enumerate(steps):
        require(type(step) is dict and "rule" in step, "Malformed proof step")
        rule = step["rule"]
        if rule == "hyp":
            require(set(step) == {"rule", "index"}, "Malformed hypothesis")
            index = step["index"]
            require(type(index) is int and 0 <= index < len(assumptions),
                    "Unknown hypothesis")
            result = assumptions[index]
        elif rule == "axiom":
            require(set(step) == {"rule", "name", "environment"}, "Malformed axiom")
            name, environment = step["name"], step["environment"]
            require(isinstance(name, str) and name in AXIOMS, "Unknown axiom")
            schema = AXIOMS[name]
            require(type(environment) is dict
                    and set(environment) == schema_variables(schema)
                    and all(term_ok(value) for value in environment.values()),
                    "Incorrect axiom substitution")
            result = instantiate(schema, environment)
        elif rule == "refl":
            require(set(step) == {"rule", "term"} and term_ok(step["term"]),
                    "Malformed reflexivity")
            result = [step["term"], step["term"]]
        elif rule == "sym":
            require(set(step) == {"rule", "of"}, "Malformed symmetry")
            left, right = previous(step["of"])
            result = [right, left]
        elif rule == "trans":
            require(set(step) == {"rule", "left", "right"}, "Malformed transitivity")
            left, middle = previous(step["left"])
            other, right = previous(step["right"])
            require(middle == other, "Transitivity middle terms differ")
            result = [left, right]
        elif rule == "cong":
            require(set(step) == {"rule", "symbol", "arguments"}, "Malformed congruence")
            symbol, arguments = step["symbol"], step["arguments"]
            require(isinstance(symbol, str) and symbol in ARITY
                    and type(arguments) is list and len(arguments) == ARITY[symbol],
                    "Congruence arity mismatch")
            premises = [previous(index) for index in arguments]
            result = [[symbol] + [eq[0] for eq in premises],
                      [symbol] + [eq[1] for eq in premises]]
        else:
            raise ProofError("Unknown rule at line " + str(line))
        derived.append(result)
    require(bool(derived) and derived[-1] == goal, "Final equation differs from goal")
    return derived


def contract(side):
    require(side in ("left", "right"), "Unknown factor")

    def projection(term):
        return ["q", term, "0"] if side == "left" else ["q", "0", term]

    return [[projection("0"), projection("1")]], [projection("s"), projection("t")]


def produce(side):
    """Untrusted producer; the returned symbolic proof is checked by verify."""
    steps = []

    def add(rule, **fields):
        steps.append(dict(rule=rule, **fields))
        return len(steps) - 1

    assumptions, goal = contract(side)
    collapse = add("hyp", index=0)
    s_reflexive = add("refl", term=goal[0])
    t_reflexive = add("refl", term=goal[1])
    zero = add("axiom", name="selector_zero", environment={"?a": "0", "?b": "0"})

    def endpoint(value):
        varying = [value, "s", "t"]
        x = varying if side == "left" else ["0"] * 3
        y = ["0"] * 3 if side == "left" else varying
        environment = {"?x" + str(i): x[i] for i in range(3)}
        environment.update({"?y" + str(i): y[i] for i in range(3)})
        central = add("axiom", name="central_selector", environment=environment)
        selector = add("axiom", name="selector_zero" if value == "0" else "selector_one",
                       environment={"?a": "s", "?b": "t"})
        arguments = [selector, zero] if side == "left" else [zero, selector]
        reduction = add("cong", symbol="q", arguments=arguments)
        return add("trans", left=central, right=reduction)

    first = endpoint("0")
    second = endpoint("1")
    change = add("cong", symbol="C", arguments=[collapse, s_reflexive, t_reflexive])
    backwards = add("sym", of=first)
    partial = add("trans", left=backwards, right=change)
    add("trans", left=partial, right=second)
    return steps


def run():
    results, certificates = [], []
    for side in ("left", "right"):
        assumptions, goal = contract(side)
        proof = produce(side)
        lines = verify(proof, assumptions, goal)
        certificates.append({"factor": side, "assumptions": assumptions,
                             "goal": goal, "steps": proof, "derived_equations": lines})
        results.append({"test": side + " symbolic collapse", "passed": True,
                        "steps": len(proof), "free_variables": ["s", "t"]})

        mutations = []
        bad = copy.deepcopy(proof)
        bad[0]["index"] = 1
        mutations.append(("unknown hypothesis", bad, assumptions, goal))
        bad = copy.deepcopy(proof)
        bad[3]["name"] = "unproved_collapse"
        mutations.append(("unknown axiom", bad, assumptions, goal))
        bad = copy.deepcopy(proof)
        bad[-1]["right"] = bad[-1]["left"]
        mutations.append(("broken transitivity", bad, assumptions, goal))
        bad = copy.deepcopy(proof)
        bad[-1]["left"] = len(bad)
        mutations.append(("forward reference", bad, assumptions, goal))
        mutations.append(("wrong conclusion", proof, assumptions, ["s", "t"]))
        mutations.append(("weakened hypothesis", proof,
                          [[assumptions[0][0], assumptions[0][0]]], goal))
        for name, bad_proof, bad_assumptions, bad_goal in mutations:
            try:
                verify(bad_proof, bad_assumptions, bad_goal)
            except ProofError as error:
                results.append({"test": side + " rejects " + name,
                                "passed": True, "reason": str(error)})
            else:
                raise RuntimeError("Mutation was incorrectly accepted: " + side + " " + name)

    directory = Path(__file__).resolve().parent
    certificate_data = {
        "scope": "Symbolic equational fragment; centrality and selector endpoints are assumed.",
        "axiom_schemas": AXIOMS, "certificates": certificates,
    }
    summary = {"complete_ipra_checker": False, "numerical_samples_used": 0,
               "passed": len(results), "failed": 0, "tests": results}
    (directory / "relative_collapse_certificates.json").write_text(
        json.dumps(certificate_data, indent=2) + "\n", encoding="utf-8")
    result_directory = directory.parent / "results"
    result_directory.mkdir(exist_ok=True)
    (result_directory / "relative_collapse.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    run()
