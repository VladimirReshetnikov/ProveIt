RELATIVE-COLLAPSE SYMBOLIC CERTIFICATES

Run:
    python3 relative_collapse.py

The script verifies these two symbolic implications, with s,t free:

    q(0,0)=q(1,0)  implies  q(s,0)=q(t,0)
    q(0,0)=q(0,1)  implies  q(0,s)=q(0,t)

The assumed axiom schemas are printed in AXIOMS and in the emitted JSON:

    C(0,a,b)=a
    C(1,a,b)=b
    C(q(x0,y0),q(x1,y1),q(x2,y2))
      =q(C(x0,x1,x2),C(y0,y1,y2)).

In the paper q(x,y)=C(b,x,y), with B(b)=b. The third schema follows
there from endpoint equation induction. That arithmetic derivation is
not certified by this fragment verifier.

Each positive certificate has 16 steps. The kernel permits only the
listed axiom instances, separately supplied hypotheses, reflexivity,
symmetry, transitivity, and function congruence. It derives every line
and compares the final equation with the independently supplied goal.
There is no numerical evaluator and no instantiation of s,t by samples.

Six mutations per factor must reject: unknown hypothesis, unknown axiom,
broken transitivity, forward proof reference, altered conclusion, and
weakening the collapse hypothesis to a reflexive equality. Together with
the two positive proofs this gives 14 checks.

The emitted relative_collapse_certificates.json contains the proof steps,
assumptions, conclusions, axiom schemas, and recomputed intermediate
equations. The intermediate equations are for inspection; the kernel
does not trust a supplied list of claimed conclusions.
The test summary is written to ../results/relative_collapse.json.

This is an equational fragment artifact. It is not a complete iPRA
checker, a formalization of all first-order gluing cases, a verification
of the ultrapower countermodel, or a checker-size improvement.
