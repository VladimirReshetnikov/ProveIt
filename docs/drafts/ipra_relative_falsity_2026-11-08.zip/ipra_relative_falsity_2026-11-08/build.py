#!/usr/bin/env python3
"""Build the complete paper with an installed TeX Live/pdflatex runtime."""
from pathlib import Path
import shutil
import subprocess


def main():
    root = Path(__file__).resolve().parent
    if not shutil.which('pdflatex'):
        raise SystemExit('pdflatex is required. Install TeX Live with the packages named in report.tex.')
    logs = []
    for _ in range(3):
        run = subprocess.run(['pdflatex', '-interaction=nonstopmode',
                              '-halt-on-error', '-file-line-error', 'report.tex'],
                             cwd=root, text=True, stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT)
        logs.append(run.stdout)
        if run.returncode:
            (root / 'results' / 'latex_build.txt').write_text('\n'.join(logs))
            print(run.stdout[-10000:])
            raise SystemExit(run.returncode)
    (root / 'results' / 'latex_build.txt').write_text('\n'.join(logs))
    warnings = [line for line in logs[-1].splitlines()
                if any(key in line for key in ('Warning', 'Overfull', 'Underfull', 'undefined'))]
    (root / 'results' / 'latex_warnings.txt').write_text('\n'.join(warnings) + '\n')
    print('Built report.pdf')
    if warnings:
        print('\n'.join(warnings))


if __name__ == '__main__':
    main()
