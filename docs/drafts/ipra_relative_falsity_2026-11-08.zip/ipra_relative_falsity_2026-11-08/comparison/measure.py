#!/usr/bin/env python3
"""Measure the twelve unchanged comparator programs inside the current corpus.

The source normalizer is inherited unchanged from the Boolean-gluing archive.
This wrapper changes only inventory/provenance, since the current folder has
six reports carrying twelve historical comparator programs, not twelve new
root checkers. It never executes the comparator programs.
"""
import json
from pathlib import Path
import platform

from inherited_measure import metrics, profiles, CHECKER_SHA256, FIELDS


def main():
    root = Path(__file__).resolve().parents[1]
    rows = []
    for path in sorted((root / 'comparison' / 'baselines').glob('*.py')):
        family, filename = path.name.split('__', 1)
        historical_key = f'ipra_{family}_2026-11-08/{filename}'
        raw = path.read_bytes()
        measured = metrics(raw)
        if measured['sha256'] != CHECKER_SHA256[historical_key]:
            raise ValueError(f'Comparator hash mismatch: {path.name}')
        rows.append({'file': path.name, 'historical_key': historical_key,
                     **measured, 'controls': profiles(raw.decode())})
    if len(rows) != 12:
        raise ValueError('Expected exactly twelve frozen comparators')
    envelope = {key: min(row[key] for row in rows) for key in FIELDS}
    expected = dict(zip(FIELDS, (317, 348, 885)))
    if envelope != expected:
        raise ValueError(f'Unexpected envelope under this runtime: {envelope}')
    result = {
        'repository_commit': '9773e5e0376fdaf953567d0e1e6f19570d566bc6',
        'current_archives': 6,
        'frozen_comparators': 12,
        'python': platform.python_version(),
        'scope': 'whole-program source metrics; not a correctness proof',
        'envelope': envelope,
        'controls': {control: {key: min(row['controls'][control][key]
                                         for row in rows) for key in FIELDS}
                     for control in ('common_names', 'common_names_and_driver')},
        'programs': rows,
    }
    out = root / 'results' / 'baseline_metrics.json'
    out.write_text(json.dumps(result, indent=2) + '\n')
    labels = {
        'boolean_core': 'Boolean core',
        'boxed_witnesses': 'Boxed witnesses',
        'clausal_kernel': 'Clausal kernel',
        'context_blocks': 'Context blocks',
        'context_pairs': 'Context pairs',
        'fixed_contexts': 'Fixed contexts',
        'kernels_and_initializer_obstruction': 'Composed initializer',
        'normalized_elimination': 'Normalized elimination',
    }
    table = ['\\begin{tabular}{@{}lrrr@{}}', '\\toprule',
             'Frozen comparator & Tokens & AST & Bytes\\\\', '\\midrule']
    for row in rows:
        family, filename = row['file'].split('__', 1)
        suffix = filename.removeprefix('checker').removesuffix('.py')
        label = labels[family] + (', ' + suffix[1:].replace('_', ' ') if suffix else '')
        vals = [str(row[key]) for key in FIELDS]
        table.append(label + ' & ' + ' & '.join(vals) + '\\\\')
    table += ['\\midrule', 'Coordinatewise minima & 317 & 348 & 885\\\\',
              '\\bottomrule', '\\end{tabular}']
    (root / 'results' / 'baseline_table.tex').write_text('\n'.join(table) + '\n')
    print(json.dumps({'status': 'PASS', 'comparators': len(rows),
                      'envelope': envelope}, indent=2))


if __name__ == '__main__':
    main()
