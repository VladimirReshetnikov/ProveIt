#!/usr/bin/env python3
"""Recompute the baseline audit and the explicitly scoped verification evidence."""
from pathlib import Path
import subprocess
import sys
import json


def main():
    root = Path(__file__).resolve().parent
    commands = [
        [sys.executable, str(root / 'comparison' / 'measure.py')],
        [sys.executable, str(root / 'verification' / 'relative_collapse.py')],
        [sys.executable, str(root / 'verification' / 'fibre_model.py'),
         '--output', str(root / 'results' / 'fibre_model.json')],
    ]
    runs = []
    for command in commands:
        run = subprocess.run(command, cwd=root, text=True,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        runs.append({'program': Path(command[1]).name,
                     'exit_code': run.returncode, 'output': run.stdout})
        print(Path(command[1]).name + ': ' + ('PASS' if run.returncode == 0 else 'FAIL'))
        if run.returncode:
            print(run.stdout)
            (root / 'results' / 'reproduction.json').write_text(json.dumps(runs, indent=2) + '\n')
            raise SystemExit(run.returncode)
    (root / 'results' / 'reproduction.json').write_text(json.dumps(runs, indent=2) + '\n')
    print('All supplied checks passed. Full metatheorems are written proofs, not machine formalizations.')


if __name__ == '__main__':
    main()
