"""Independent audit of public falsity erasure and positive proof embedding.

The core inference program is compared structurally with the already audited
native kernel. This suite targets the changed JSON boundary and independently
written public proofs, including mixed falsity/clash annotations. No claim of
universal formal verification is made by these finite checks.
"""
from pathlib import Path
import argparse
import ast
import copy
import hashlib
import importlib
import itertools
import json
import random
import subprocess
import sys
import tempfile

HERE=Path(__file__).resolve().parent
DEFAULT=HERE.parent/'code'
Z=-1
F=['false']
D=['=',Z,['s',Z]]
T=['=',Z,Z]


def public_wf(a,formula=False):
    """Independent JSON grammar; genuine falsity is a public formula."""
    if type(a) is int:
        return not formula and a>=-1
    if type(a) is not list or not a or type(a[0]) is not str:
        return False
    if a[0]=='false':
        return formula and len(a)==1
    if a[0]=='s':
        return not formula and len(a)==2 and public_wf(a[1],False)
    if a[0]=='r':
        return not formula and len(a)==4 and all(public_wf(t,False) for t in a[1:])
    if a[0]=='=':
        return formula and len(a)==3 and all(public_wf(t,False) for t in a[1:])
    if a[0] in ('pi','sig'):
        return formula and len(a)==3 and all(public_wf(t,True) for t in a[1:])
    return False


def manual_erase(a):
    """Independent specification of the public encoding, producing JSON."""
    if type(a) is list:
        if a==['false']:
            return ['=',-1,['s',-1]]
        return [manual_erase(x) for x in a]
    if type(a) is dict:
        return {key:manual_erase(value) for key,value in a.items()}
    return a


def json_value(a):
    return json.loads(json.dumps(a))


def document(goal,proof,assumptions=()):
    return {'assumptions':list(assumptions),'goal':goal,'proof':proof}


def head(case):
    p=case.pattern
    if isinstance(p,ast.MatchSequence) and p.patterns:
        p=p.patterns[0]
        if isinstance(p,ast.MatchValue) and isinstance(p.value,ast.Constant):
            return p.value.value
    return None


def compare_core(direct_path,encoded_path):
    direct={n.name:n for n in ast.parse(direct_path.read_text()).body if isinstance(n,ast.FunctionDef)}
    encoded={n.name:n for n in ast.parse(encoded_path.read_text()).body if isinstance(n,ast.FunctionDef)}
    matched=[]
    for name in ('require','wf','walk','shift','subst','inst','infer'):
        left=copy.deepcopy(direct[name])
        if name in ('wf','infer'):
            unwanted='false' if name=='wf' else 'bridge'
            for node in ast.walk(left):
                if isinstance(node,ast.Match):
                    node.cases=[c for c in node.cases if head(c)!=unwanted]
        assert ast.dump(left,include_attributes=False)==ast.dump(encoded[name],include_attributes=False),name
        matched.append(name)
    return matched


def public_variants(data,limit=64):
    """Independently choose bottom or its equation at each clash occurrence."""
    base=manual_erase(json_value(data))
    def count(a):
        if type(a) is list:
            return 1 if a==D else sum(count(x) for x in a)
        if type(a) is dict:
            return sum(count(x) for x in a.values())
        return 0
    n=count(base)
    if n==0:
        return []
    choices=list(range(2**n)) if n<=6 else [0,(1<<n)-1,*[random.Random(20261106+j).getrandbits(n) for j in range(limit-2)]]
    results=[]
    for mask in dict.fromkeys(choices):
        serial=itertools.count()
        def change(a):
            if type(a) is list:
                if a==D:
                    return ['false'] if (mask>>next(serial))&1 else copy.deepcopy(D)
                return [change(x) for x in a]
            if type(a) is dict:
                return {key:change(value) for key,value in a.items()}
            return a
        results.append(change(base))
    return results


def run(directory):
    sys.path.insert(0,str(directory))
    encoded=importlib.import_module('checker')
    direct=importlib.import_module('native_checker')
    helper=importlib.import_module('encode')
    paths=[directory/name for name in ('checker.py','native_checker.py','encode.py')]
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    report={'source_sha256':hashes,'python':sys.version,'cases':[],'cli':[]}
    report['unchanged_core_ast']=compare_core(directory/'native_checker.py',directory/'checker.py')
    assert direct.ZERO==encoded.ZERO==Z
    assert direct.CLASH==encoded.CLASH
    positive=[]
    negative=[]
    def good(name,data): positive.append((name,json_value(data)))
    def bad(name,data): negative.append((name,json_value(data)))
    def refl(t):
        p=['rec',['r',Z,t,Z]]
        return ['use',p,['=',0,encoded.shift(encoded.freeze(json_value(t)))],p]
    def check(data):
        try:
            return encoded.check(json_value(data)) is True,None
        except (ValueError,TypeError,IndexError,KeyError,RecursionError,OSError) as e:
            return False,type(e).__name__
    def certify_positive(name,data):
        accepted,error=check(data)
        assert accepted,(name,error)
        # This reverse endpoint is required to verify arbitrary inputs, not
        # merely output produced by forward_direct_certificate.
        embedded=helper.positive_embedding(data)
        direct.check(embedded)
        expected=manual_erase(data)
        assert embedded==expected,(name,'embedding changed more than the documented erasure')
        assert all(public_wf(a,True) for a in data['assumptions']),name
        assert public_wf(data['goal'],True),name
        return embedded

    good('mixed_hypothesis_falsity_to_clash',document(D,['hyp',D],[F]))
    good('mixed_hypothesis_clash_to_falsity',document(F,['hyp',F],[D]))
    good('public_bottom_used_as_eq_principal',document(['=',['s',Z],Z],['use',['hyp',F],['=',0,Z],refl(Z)],[F]))
    good('public_bottom_used_as_closed_template',document(F,['use',['hyp',['=',0,1]],F,['hyp',D]],[['=',0,1],F]))
    good('mixed_pi_guard_and_hypothesis',document(['pi',F,D],['pi',F,['hyp',D]]))
    pi=['pi',F,['hyp',D]]
    good('mixed_pi_application',document(F,['use',pi,37,['hyp',F]],[D]))
    pair=['pair',9,['hyp',F],['hyp',D]]
    good('witness_pair_with_mixed_false_components',document(['sig',F,D],pair,[F]))
    good('mixed_sigma_elimination',document(F,['use',pair,F,['hyp',D]],[F]))
    # Exact closed numerical instance; this expected formula is handwritten.
    closed=['pi',['sig',D,['pi',D,D]],D]
    public_closed=['pi',['sig',F,['pi',D,F]],F]
    good('native_false_numerical_template',document(public_closed,['nat',F]))
    good('native_clash_numerical_template',document(closed,['nat',D]))
    nf=encoded.infer(encoded.freeze(['nat',F]),())
    nd=encoded.infer(encoded.freeze(['nat',D]),())
    direct_nf=encoded.freeze(json_value(direct.infer(('nat',direct.FALSE),())))
    assert nf==nd==direct_nf==encoded.freeze(closed)
    report['closed_numerical_falsity_commutation']=True
    # A composite template remains composite after erasure. All displayed
    # binders here are explicit; A(x)=forall y (y=x -> bottom).
    a=['pi',['=',0,1],F]
    base=['pi',['=',0,Z],F]
    step=['pi',base,['pi',['=',0,['s',1]],F]]
    composite_goal=['pi',['sig',base,step],a]
    good('composite_template_with_bottom',document(composite_goal,['nat',a]))
    good('stored_clash_normalizes_float_hypothesis_alias',document(F,['hyp',['=',-1.0,['s',-1.0]]],[F]))
    nested=['pi',F,['sig',['=',0,1],F]]
    good('nested_public_formula_hypothesis',document(nested,['hyp',nested],[nested]))
    good('pure_native_arithmetic_remains_available',document(['=',17,17],refl(17)))

    bad('no_unconditional_bottom_by_hypothesis',document(F,['hyp',F]))
    bad('numerical_falsity_schema_does_not_prove_bottom',document(F,['nat',F]))
    bad('bridge_is_not_an_encoded_proof_tag',document(F,['bridge',['hyp',D]],[D]))
    bad('bottom_is_not_a_numeric_witness',document(T,['pair',F,refl(0),refl(0)]))
    bad('bottom_is_not_a_pi_instantiation_term',document(F,['use',pi,F,['hyp',F]],[F]))
    bad('bottom_is_not_a_recursion_body',document(T,['rec',['r',['s',Z],Z,F]]))
    bad('bottom_is_not_a_recursion_counter',document(T,['rec',['r',F,Z,0]]))
    bad('bottom_is_not_an_equality_term',document(['=',F,F],['hyp',['=',F,F]],[['=',F,F]]))
    bad('float_clash_goal_does_not_become_wellformed',document(['=',-1.0,['s',-1.0]],['hyp',F],[F]))
    bad('old_zero_tag_is_not_repaired',document(['=',['z'],['z']],refl(Z)))
    bad('non_equation_induction_remains_forbidden',document(
        ['pi',['sig',base,['pi',a,['pi',['=',0,['s',1]],F]]],a],['nat',a]))
    bad('sigma_parameter_escape_under_erasure',document(['=',0,0],['use',['hyp',['sig',F,F]],['=',0,0],refl(0)],[['sig',F,F]]))
    bad('pi_capture_under_erasure',document(['pi',F,['=',0,0]],['pi',F,['hyp',['=',0,0]]],[['=',0,0]]))
    bad('false_node_cannot_serve_as_entire_proof',document(F,F,[F]))
    bad('false_node_with_extra_argument',document(['false',0],['hyp',['false',0]],[['false',0]]))
    bad('formula_as_numerical_template_sort',document(T,['nat',-1]))
    bad('empty_proof',document(T,[]))
    bad('falsity_string_goal',document('false',['hyp',F],[F]))
    bad('falsity_string_hypothesis',document(F,['hyp','false'],[F]))
    bad('assumptions_special_erasure_collision',{'assumptions':['false'],'goal':F,'proof':['hyp',F]})
    bad('assumptions_as_single_clash_formula',{'assumptions':D,'goal':F,'proof':['hyp',F]})
    bad('assumptions_as_dictionary',{'assumptions':{'false':F},'goal':F,'proof':['hyp',F]})
    bad('assumptions_as_null',{'assumptions':None,'goal':F,'proof':['hyp',F]})
    bad('extra_root_field',{'assumptions':[F],'goal':F,'proof':['hyp',F],'false':F})
    bad('missing_proof_root_field',{'assumptions':[F],'goal':F})
    bad('non_dictionary_root',F)
    bad('boolean_root',False)
    for i,malformed in enumerate([True,False,-2,-1.0,'-1',None,{},['false',False],['='],['=',Z],['pi',F],['s',F],['r',Z,Z,F]]):
        bad('malformed_goal_'+str(i),document(malformed,['hyp',malformed],[malformed]))

    embedded_count=0
    for name,data in positive:
        certify_positive(name,data)
        embedded_count+=1
        report['cases'].append({'name':name,'expected':'accept','observed':'accept'})
    for name,data in negative:
        accepted,error=check(data)
        assert not accepted,('unexpected acceptance',name)
        try:
            helper.positive_embedding(data)
        except (ValueError,TypeError,IndexError,KeyError,RecursionError,OSError):
            pass
        else:
            raise AssertionError(('embedding accepted invalid public certificate',name))
        report['cases'].append({'name':name,'expected':'reject','observed':'reject','error':error})
    variants=0
    for name,data in positive:
        for j,changed in enumerate(public_variants(data)):
            certify_positive(name+':variant:'+str(j),changed)
            variants+=1
    report['independent_positive_certificates']=len(positive)
    report['independent_negative_certificates']=len(negative)
    report['mixed_bottom_clash_variants']=variants
    report['arbitrary_positive_embedding_checks']=embedded_count+variants

    # Reflection is tested against an independent public JSON grammar, with
    # malformed constructors and false nodes at every kind of syntactic slot.
    atoms=[True,False,None,-2,-1,0,3,1000,-1.0,0.0,'false','=',[],{},F,D,T,['s',Z],['false',0]]
    samples=list(atoms)
    for x in atoms:
        samples.extend([['s',x],['=',x,Z],['=',Z,x],['pi',x,F],['sig',F,x],['r',x,Z,0],['r',Z,x,0],['r',Z,Z,x]])
    rng=random.Random(20261106)
    for _ in range(300):
        tag=rng.choice(['s','r','=','pi','sig','false','unknown',True,0,[],{}])
        arity=rng.randrange(5)
        children=[copy.deepcopy(rng.choice(samples)) for _ in range(arity)]
        samples.append([tag,*children])
    reflection=0
    root_context_checks=0
    root_goal_checks=0
    for x in samples:
        for is_formula in (False,True):
            expected=public_wf(x,is_formula)
            actual=bool(encoded.wf(encoded.freeze(copy.deepcopy(x)),is_formula))
            assert actual==expected,('syntax_reflection',x,is_formula,expected,actual)
            reflection+=1
        # Valid root statements can use hypotheses. Malformed statements must
        # not be repaired into valid ones by the public erasure.
        data=document(x,['hyp',x],[x])
        actual,_=check(data)
        assert actual==public_wf(x,True),('root_goal_reflection',x)
        root_goal_checks+=1
        if type(x) is list:
            expected=all(public_wf(y,True) for y in x)
            actual,_=check({'assumptions':x,'goal':T,'proof':refl(Z)})
            assert actual==expected,('root_context_reflection',x)
            root_context_checks+=1
    report['independent_public_syntax_reflection']={'objects':len(samples),'sort_checks':reflection,
             'root_goal_checks':root_goal_checks,'root_context_checks':root_context_checks,
             'grammar':'Independent recursive JSON grammar with genuine public falsity.'}

    # CLI tests exercise the changed trusted entry point, including a positive
    # proof never emitted by the official forward compiler.
    with tempfile.TemporaryDirectory() as temporary:
        for optimize in (False,True):
            for expected,name,data in [(True,'bottom_as_equality_principal',positive[2][1]),
                                       (False,'malformed_assumption_collision',negative[19][1]),
                                       (False,'illegal_encoded_bridge',negative[2][1]),
                                       (False,'invalid_json',None)]:
                path=Path(temporary)/(name+'.json')
                path.write_text('{ invalid json' if data is None else json.dumps(data))
                cmd=[sys.executable,*(['-O'] if optimize else []),str(directory/'checker.py'),str(path)]
                result=subprocess.run(cmd,capture_output=True,text=True,timeout=20)
                assert result.returncode==(0 if expected else 1),(name,result.returncode,result.stdout,result.stderr)
                assert result.stdout.strip()==('ACCEPT' if expected else 'REJECT'),(name,result.stdout)
                assert not result.stderr,(name,result.stderr)
                report['cli'].append({'case':name,'optimized':optimize,'expected':'accept' if expected else 'reject',
                                      'exit_code':result.returncode,'stdout':result.stdout.strip()})
    report['all_passed']=True
    report['converse_scope']='The helper produces direct proofs of erased sequents. Recovering original public formulas uses the written formula-bridge theorem, not a claimed root-restoring compiler.'
    report['scope']='Finite independent checks plus AST equality of the unchanged inference core; no universal formalization claim.'
    assert hashes=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'sources changed during audit'
    return report


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--candidate-dir',type=Path,default=DEFAULT)
    parser.add_argument('--output',type=Path,default=HERE/'encoded_independent_audit.json')
    args=parser.parse_args()
    report=run(args.candidate_dir.resolve())
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('cases','cli')},indent=2))

if __name__=='__main__':
    main()
