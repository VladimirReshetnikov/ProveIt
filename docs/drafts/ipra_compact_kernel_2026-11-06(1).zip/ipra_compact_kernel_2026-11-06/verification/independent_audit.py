"""Independent boundary, binding and translation audit of the paired kernel.

Only Python's standard library is used. Expected substitution/schema results
are calculated through a separate named-variable syntax, not the kernel's
walker. Finite tests supplement, and do not replace, the mathematical proof.
"""
from pathlib import Path
import argparse
import copy
import hashlib
import importlib
import itertools
import json
import random
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
DEFAULT = HERE.parent / 'code'
Z = -1
F = ('false',)
T = ('=', Z, Z)
E = lambda a,b: ('=', a,b)
S = lambda a: ('s', a)
PI = lambda a,b: ('pi', a,b)
SIG = lambda a,b: ('sig', a,b)
R = lambda n,a,h: ('r', n,a,h)


def named(a, namespace='n'):
    """Decode with a lexical environment and fresh names for each binder."""
    serial = itertools.count()
    def go(a, bound):
        if type(a) is int:
            if a == -1:
                return ('zero',)
            if a < len(bound):
                return ('var', bound[a])
            return ('var', 'p' + str(a-len(bound)))
        if a[0] == 's':
            return ('succ', go(a[1],bound))
        if a[0] == 'r':
            state, counter = namespace+':s'+str(next(serial)), namespace+':k'+str(next(serial))
            return ('rec', state,counter,go(a[1],bound),go(a[2],bound),go(a[3],(state,counter)+bound))
        if a[0] == '=':
            return ('eq',go(a[1],bound),go(a[2],bound))
        if a[0] == 'false':
            return ('bottom',)
        if a[0] in ('pi','sig'):
            x = namespace+':x'+str(next(serial))
            return (a[0],x,go(a[1],(x,)+bound),go(a[2],(x,)+bound))
        raise ValueError('not native syntax')
    return go(a,())


def alpha(a, bound=()):
    """Canonicalize only bound names; retain the names of free parameters."""
    tag = a[0]
    if tag == 'var':
        return ('bound',bound.index(a[1])) if a[1] in bound else ('free',a[1])
    if tag in ('zero','bottom'):
        return a
    if tag == 'rec':
        return ('rec',alpha(a[3],bound),alpha(a[4],bound),alpha(a[5],(a[1],a[2])+bound))
    if tag in ('pi','sig'):
        return (tag,alpha(a[2],(a[1],)+bound),alpha(a[3],(a[1],)+bound))
    return (tag,*(alpha(x,bound) for x in a[1:]))


def replace_free(a, env, bound=frozenset()):
    """Simultaneous capture-free substitution using disjoint fresh names."""
    tag = a[0]
    if tag == 'var':
        return a if a[1] in bound else env(a[1])
    if tag in ('zero','bottom'):
        return a
    if tag == 'rec':
        return ('rec',a[1],a[2],replace_free(a[3],env,bound),replace_free(a[4],env,bound),
                replace_free(a[5],env,bound | {a[1],a[2]}))
    if tag in ('pi','sig'):
        return (tag,a[1],replace_free(a[2],env,bound | {a[1]}),replace_free(a[3],env,bound | {a[1]}))
    return (tag,*(replace_free(x,env,bound) for x in a[1:]))


def named_instance(a,t):
    target = named(t,'witness')
    return replace_free(named(a,'template'),lambda x: target if x=='p0' else ('var','p'+str(int(x[1:])-1)))


def named_shift(a, amount, cutoff=0):
    return replace_free(named(a,'source'), lambda x: ('var','p'+str(int(x[1:])+amount if int(x[1:])>=cutoff else int(x[1:]))))


def named_schema(a):
    """Independent reading: forall x ((exists z (base and step)) -> A(x))."""
    q = 'slot'
    pattern = replace_free(named(a,'a'),lambda x: ('var',q) if x=='p0' else ('var','p'+str(int(x[1:])-1)))
    def at(term):
        return replace_free(pattern,lambda x: term if x==q else ('var',x))
    base = at(('zero',))
    guard = at(('var','step_y')) if a[0]=='=' else base
    step = ('pi','step_y',guard,at(('succ',('var','step_y'))))
    return ('pi','target_x',('sig','unused_z',base,step),at(('var','target_x')))


def named_rec_successor(r):
    _,n,a,h = r
    assert n[0]=='s'
    prior = named(R(n[1],a,h),'prior')
    counter = named(n[1],'counter')
    return replace_free(named(h,'body'),lambda x: prior if x=='p0' else counter if x=='p1' else ('var','p'+str(int(x[1:])-2)))


def thaw(a):
    return json.loads(json.dumps(a))


def cert(goal, proof, assumptions=()):
    return {'assumptions':list(assumptions),'goal':goal,'proof':proof}


def run(directory):
    sys.path.insert(0,str(directory))
    k=importlib.import_module('native_checker')
    tr=importlib.import_module('translate')
    paths=[directory/x for x in ('native_checker.py','translate.py','baseline.py')]
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    report={'source_sha256':hashes,'python':sys.version,'cases':[], 'oracle':{},'translation':{},'cli':[]}
    positive=[]
    negative=[]
    def good(name,data): positive.append((name,data))
    def bad(name,data): negative.append((name,data))
    def refl(t):
        p=('rec',R(Z,t,Z))
        return ('use',p,E(0,k.shift(t)),p)
    def check_case(name,data,expected):
        try:
            accepted=k.check(thaw(data)) is True
            error=None
        except (ValueError,TypeError,IndexError,KeyError,RecursionError,OSError) as e:
            accepted=False
            error=type(e).__name__
        assert accepted==expected,(name,expected,accepted,error)
        report['cases'].append({'name':name,'expected':'accept' if expected else 'reject','observed':'accept' if accepted else 'reject','error':error})

    # Valid nontrivial formulas with free parameters and nested binders.
    complex_term=R(S(2),3,R(1,0,S(R(3,2,S(0)))))
    good('reflexivity_nested_parameterized_recursion',cert(E(complex_term,complex_term),refl(complex_term)))
    good('genuine_false_to_clash',cert(k.CLASH,('bridge',('hyp',F)),[F]))
    good('genuine_clash_to_false',cert(F,('bridge',('hyp',k.CLASH)),[k.CLASH]))
    good('pi_keeps_outer_parameter_distinct',cert(PI(T,E(1,1)),('pi',T,('hyp',E(1,1))),[E(0,0)]))
    pair=('pair',2,('hyp',E(0,3)),('hyp',E(0,3)))
    pair_goal=SIG(E(0,3),E(0,3))
    good('dependent_witness_pair',cert(pair_goal,pair))
    transport=('use',('hyp',E(0,3)),E(0,4),('hyp',E(0,3)))
    good('witness_pair_consumed_by_shared_sigma',cert(E(2,2),('use',pair,E(2,2),transport)))
    nested_pair=('pair',2,('pi',E(0,0),('hyp',E(0,0))),('hyp',E(0,3)))
    nested_goal=SIG(PI(E(0,0),E(0,0)),E(0,3))
    good('witness_pair_with_nested_pi',cert(nested_goal,nested_pair))
    good('nested_pi_pair_consumed_by_shared_sigma',cert(E(2,2),('use',nested_pair,E(2,2),transport)))
    # A hypothesis annotation may compare equal by Python aliasing, but the
    # checker must return the original validated assumption, not the annotation.
    stored=E(1,1)
    annotation=E(True,1.0)
    assert k.infer(('hyp',annotation),(stored,)) is stored
    good('hyp_alias_returns_valid_stored_formula',cert(stored,('hyp',annotation),[stored]))
    good('duplicate_hypotheses_are_harmless',cert(E(5,5),('hyp',E(5,5)),[T,E(5,5),E(5,5)]))
    rec_goal=k.infer(('rec',complex_term),())
    assert alpha(named(rec_goal[2]))==alpha(named_rec_successor(complex_term))
    good('nested_rec_successor_computation',cert(rec_goal,('rec',complex_term)))
    good('witness_guard_zero_is_numeral',cert(SIG(E(0,Z),E(0,Z)),('pair',Z,('hyp',E(0,Z)),('hyp',E(0,Z)))))

    # Numerical axioms are compared to an independent named-variable reading.
    templates=[E(0,3),E(R(0,2,S(0)),R(0,2,S(0))),F,
               PI(E(0,1),F),SIG(E(0,1),PI(E(1,2),E(0,3))),
               E(R(0,2,R(1,0,S(2))),3),
               PI(E(R(1,3,S(0)),2),SIG(E(0,2),E(3,4)))]
    for i,a in enumerate(templates):
        goal=k.infer(('nat',a),())
        assert alpha(named(goal))==alpha(named_schema(a)),('schema',i)
        good('paired_numerical_schema_'+str(i),cert(goal,('nat',a),[E(17,17),PI(T,T)]))

    # A numerical schema with a dependency genuinely involving a parameter.
    a=E(0,3)
    schema=k.infer(('nat',a),())
    B=E(Z,2)
    Step=PI(E(0,3),E(S(0),3))
    g=[B,Step]
    # Build the untrusted ordinary Sigma proof adapter, then audit its claim.
    antecedent=k.inst(schema[1],7)
    premise=tr.witnessed(antecedent,Z,('hyp',B),('hyp',Step),tuple(g))
    applied=('use',('nat',a),7,premise)
    good('paired_schema_application_with_parameter',cert(E(7,2),applied,g))

    # Targeted soundness boundaries.
    bad('unconditional_false_is_unavailable',cert(F,('hyp',F)))
    bad('bridge_rejects_reflexive_equation',cert(F,('bridge',refl(Z))))
    bad('bridge_rejects_noncanonical_clash',cert(F,('bridge',('hyp',E(S(Z),Z))),[E(S(Z),Z)]))
    bad('native_false_not_silently_erased',cert(F,('hyp',k.CLASH),[k.CLASH]))
    bad('old_hypothesis_index_is_not_a_formula',cert(T,('hyp',0),[T]))
    bad('hyp_alias_cannot_forge_boolean_goal',cert(E(True,True),('hyp',annotation),[stored]))
    bad('pi_eigenvariable_capture',cert(PI(T,E(0,0)),('pi',T,('hyp',E(0,0))),[E(0,0)]))
    bad('sigma_witness_escape',cert(E(0,0),('use',('hyp',pair_goal),E(0,0),refl(0)),[pair_goal]))
    bad('sigma_branch_uses_unshifted_parameter',cert(E(2,2),('use',pair,E(2,2),refl(2))))
    bad('pair_guard_has_unshifted_witness',cert(pair_goal,('pair',2,('hyp',E(0,2)),('hyp',E(0,2)))))
    bad('shared_use_false_as_principal',cert(T,('use',('hyp',F),T,refl(Z)),[F]))
    bad('shared_use_eq_requires_formula_annotation',cert(T,('use',refl(Z),Z,refl(Z))))
    pi_goal=PI(T,T)
    bad('shared_use_pi_requires_term_annotation',cert(T,('use',('hyp',pi_goal),T,refl(Z)),[pi_goal]))
    bad('shared_use_sigma_requires_formula_annotation',cert(T,('use',pair,0,transport)))
    bad('rec_axiom_requires_zero_or_successor',cert(E(R(0,Z,Z),Z),('rec',R(0,Z,Z))))
    bad('rec_body_is_not_a_formula',cert(T,('rec',R(S(Z),Z,F))))
    bad('wrong_rec_successor_parameter',cert(E(complex_term,2),('rec',complex_term)))
    # Non-equation guards must be the fixed base, not an induction hypothesis.
    for i,a in enumerate([PI(E(0,1),F),SIG(E(0,1),E(2,3)),F]):
        normal=k.infer(('nat',a),())
        successor=k.subst(a,lambda j:S(0) if j==0 else j)
        wrong_step=PI(a,successor)
        wrong=PI(SIG(k.shift(k.inst(a,Z),2),k.shift(wrong_step,2)),a)
        if wrong!=normal:
            bad('forged_non_equation_induction_'+str(i),cert(wrong,('nat',a)))
    a=E(0,3)
    correct=k.infer(('nat',a),())
    wrong=PI(SIG(k.shift(k.inst(a,Z),1),correct[1][2]),a)
    bad('paired_schema_under_shifts_parameter',cert(wrong,('nat',a)))
    wrong=PI(correct[1],E(0,2))
    bad('paired_schema_captures_parameter_in_conclusion',cert(wrong,('nat',a)))
    bad('numerical_schema_rejects_term_template',cert(T,('nat',0)))
    bad('numerical_schema_rejects_malformed_formula_template',cert(T,('nat',('=',0))))
    bad('pair_rejects_formula_witness',cert(pair_goal,('pair',T,refl(0),refl(0))))
    for i,t in enumerate([True,False,-2,0.0,-1.0,'0',{'x':0},('z',),('s',),('s',0,1)]):
        bad('invalid_witness_'+str(i),cert(T,('pair',t,refl(0),refl(0))))
        bad('invalid_root_term_'+str(i),cert(E(t,t),('hyp',E(t,t)),[E(t,t)]))
    for i,f in enumerate([True,0,'false',{},('false',Z),('pi',T),('sig',T,T,T),('=',T,Z),('pi',0,T)]):
        bad('invalid_root_formula_'+str(i),cert(f,('hyp',f),[f]))
    bad('assumption_list_required',{'assumptions':{},'goal':T,'proof':refl(Z)})
    bad('extra_root_key',{'assumptions':[],'goal':T,'proof':refl(Z),'extra':1})
    bad('missing_root_key',{'assumptions':[],'goal':T})
    bad('root_must_be_dictionary',[])
    bad('proof_cannot_be_boolean',cert(T,True))
    bad('unknown_proof_tag',cert(T,('eval',T)))
    bad('malformed_eq_template',cert(T,('use',refl(Z),('=',True,True),refl(Z))))
    bad('malformed_pi_guard',cert(T,('pi',('=',-2,-2),('hyp',('=',-2,-2)))))
    bad('huge_variable_lookup_not_present',cert(E(1000000,1000000),('hyp',E(1000000,1000000)),[T]))

    for name,data in positive: check_case(name,data,True)
    for name,data in negative: check_case(name,data,False)

    # Deterministic independent binding oracle: formulas and terms contain
    # nested recursors and both numerical formula binders, plus high parameters.
    rng=random.Random(20261106)
    def term(depth):
        if depth<=0: return rng.choice([Z,0,1,2,7,100])
        tag=rng.randrange(4)
        if tag==0: return term(0)
        if tag==1: return S(term(depth-1))
        return R(term(depth-1),term(depth-1),term(depth-1))
    def formula(depth):
        if depth<=0: return F if rng.randrange(5)==0 else E(term(1),term(1))
        tag=rng.randrange(4)
        if tag==0: return F
        if tag==1: return E(term(2),term(2))
        return (('pi' if tag==2 else 'sig'),formula(depth-1),formula(depth-1))
    samples=[term(3) for _ in range(24)]+[formula(3) for _ in range(24)]
    operations=0
    for i,a in enumerate(samples):
        for amount in (0,1,3):
            assert alpha(named(k.shift(a,amount)))==alpha(named_shift(a,amount)),('shift',i,amount)
            operations+=1
        t=term(2)
        assert alpha(named(k.inst(a,t)))==alpha(named_instance(a,t)),('inst',i)
        operations+=1
        # General simultaneous substitution has a different index map from inst.
        def env(j): return R(S(j+1),Z,S(0))
        expected=replace_free(named(a,'base'),lambda x:named(env(int(x[1:])),'env'+x))
        assert alpha(named(k.subst(a,env)))==alpha(expected),('subst',i)
        operations+=1
    additional_schemas=[formula(3) for _ in range(24)]
    for i,a in enumerate(additional_schemas):
        assert alpha(named(k.infer(('nat',a),())))==alpha(named_schema(a)),('generated_schema',i)
    report['oracle']={'generated_syntax_objects':len(samples),'substitution_shift_comparisons':operations,
                      'numerical_schema_comparisons':len(templates)+len(additional_schemas),
                      'nested_rec_successor_comparisons':1,'deterministic_seed':20261106,
                      'method':'Independent lexical named syntax, capture-free simultaneous substitution, alpha normalization.'}

    # General compilers are checked on native, not inherited, interaction cases.
    roundtrips=0
    lifts=0
    for name,data in positive:
        back=tr.backward(thaw(data))
        forward=tr.forward(back)
        assert k.freeze(forward['goal'])==k.freeze(data['goal']),name
        assert k.freeze(forward['assumptions'])==k.freeze(data['assumptions']),name
        roundtrips+=1
        g=tuple(map(k.freeze,data['assumptions']))
        p=k.freeze(data['proof'])
        goal=k.freeze(data['goal'])
        for cut in (0,1,4):
            shifted_g=tuple(tr.insert(a,cut) for a in g)
            shifted_goal=tr.insert(goal,cut)
            assert alpha(named(shifted_goal))==alpha(named_shift(goal,1,cut)),('lift_goal',name,cut)
            lifted=tr.lift(p,g,cut)
            k.check(cert(shifted_goal,lifted,shifted_g))
            lifts+=1
    translator_rejections=0
    for name,data in negative:
        try:
            tr.backward(thaw(data))
        except (ValueError,TypeError,IndexError,KeyError,RecursionError,OSError):
            translator_rejections+=1
        else:
            raise AssertionError(('translator accepted invalid native proof',name))
    report['translation']={'native_to_baseline_to_native_cases':roundtrips,
                           'proof_lifts_at_three_cutoffs':lifts,
                           'invalid_native_inputs_rejected_before_translation':translator_rejections}

    # Actual JSON command-line acceptance is tested under both Python modes.
    with tempfile.TemporaryDirectory() as temporary:
        for optimized in (False,True):
            for expected,name,data in [(True,positive[5][0],positive[5][1]),
                                       (False,negative[7][0],negative[7][1]),
                                       (False,'invalid_json',None)]:
                f=Path(temporary)/(name+'.json')
                f.write_text('{ invalid json' if data is None else json.dumps(data))
                cmd=[sys.executable,*(['-O'] if optimized else []),str(directory/'native_checker.py'),str(f)]
                r=subprocess.run(cmd,capture_output=True,text=True,timeout=20)
                assert r.returncode==(0 if expected else 1),(name,r.returncode,r.stdout,r.stderr)
                assert r.stdout.strip()==('ACCEPT' if expected else 'REJECT'),(name,r.stdout)
                report['cli'].append({'case':name,'optimized':optimized,'expected':'accept' if expected else 'reject','exit_code':r.returncode,'stdout':r.stdout.strip()})
    report['positive_cases']=len(positive)
    report['negative_cases']=len(negative)
    report['all_passed']=True
    report['scope']='Finite independent regression checks; not a universal soundness or interpretation formalization.'
    assert hashes=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'source changed during audit'
    return report


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--candidate-dir',type=Path,default=DEFAULT)
    parser.add_argument('--output',type=Path,default=HERE/'independent_audit.json')
    args=parser.parse_args()
    result=run(args.candidate_dir.resolve())
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('cases','cli')},indent=2))

if __name__=='__main__':
    main()
