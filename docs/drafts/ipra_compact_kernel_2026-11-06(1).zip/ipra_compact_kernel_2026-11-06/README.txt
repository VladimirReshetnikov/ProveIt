A SMALLER COMPLETE AXIOMATIZATION AND CHECKER FOR iPRA
Prepared for Vladimir Reshetnikov, 6 November 2026
===================================================

START WITH report.pdf.

RESULT

The full public theory K is bi-interpretable and equiconsistent with
first-order intuitionistic primitive recursive arithmetic, with all finite
primitive-recursive descriptions and quantifier-free induction. Both
interpretations use the entire numerical carrier, and both composites are
internally identified with the identity. The paper specifies every logical
rule, arithmetic axiom/schema, and side condition.

The smallest delivered complete public checker is code/checker.py:
  1,004 significant original-source Python tokens
  1,004 normalized Python tokens
  1,065 executable AST nodes
  3,298 normalized executable bytes
  3,536 raw bytes, including its attribution header

The corresponding current-corpus coordinate minima are:
  1,089 / 1,089 / 1,154 / 3,486 / 3,817.
The new checker is strictly smaller in every column. All input decoding,
validation, binding operations, fixed data, inference rules, imports,
exception handling, and the JSON command-line boundary are counted.

A direct genuine-falsity checker, code/native_checker.py, is also supplied:
  1,040 original-source tokens; 1,041 normalized tokens; 1,101 AST nodes;
  3,440 normalized bytes; 3,677 raw bytes.
It too is below all current coordinate minima.

WHAT IS NEW

The implementation combines compatible reductions already proposed in the
six current drafts: shared elimination, witness-equation existential
introduction, a paired numerical axiom, a zero sentinel, stored-assumption
references, and counted public falsity encoding. Their mathematical
foundations are credited rather than presented as new discoveries.
The new contribution is the complete combined implementation, its current
comparison, exact specification, proof compilers, and independent audits.

THE THEORY

Terms: variables, zero, successor, and initialized primitive recursion.
Formulas: equality, genuine falsity, guarded Pi, and guarded Sigma.
Logic: six inference schemas, including witness-equation Sigma introduction.
Arithmetic: two computation schemas, a two-way fixed falsity bridge, and
one numerical axiom schema. The latter supplies an induction hypothesis
only to literal equations; other formulas receive ordinary number cases.
Full intuitionistic logic and quantifier-free induction are derived.

The smaller checker keeps genuine falsity in public assertions and encodes
it internally as 0=S0. The report proves exact sequent adequacy for arbitrary
assumptions and formulas. The bare positive first-order reduct is NOT the
ordinary theory claimed bi-interpretable with iPRA. The separate native
checker retains the falsity constructor and explicit bridge checks.

COMPARISON SNAPSHOT

Repository: https://github.com/VladimirReshetnikov/ProveIt
Directory: docs/drafts
Commit: 39c2b3c738e4cacbc0b2cb31f093c1eb4f976e75

All six current archives were downloaded and checked against their Git blob
identities. The comparison includes their six recommendations and 19
meaningful complete current variants in total. Exact selected sources are
included for offline remeasurement. The smaller minima quoted above are
from this current snapshot, not the older eleven-archive snapshot reviewed
inside those drafts. No global program-size minimum is claimed.

RUN (Python 3.10+; standard library only)

  python3 reproduce.py
  python3 code/checker.py code/encoded_certificates/legacy_reflexivity_derived.json
  python3 code/native_checker.py code/certificates/legacy_reflexivity_derived.json
  python3 measure.py

The checker prints ACCEPT with status 0, or REJECT with status 1.
Nonempty assumptions assert a sequent, not an unconditional theorem.
See FORMAT.txt for the complete JSON format and SPECIFICATION.txt for the
standalone mathematical axiomatization.

To compile the paper and rebuild the archive (requires pdflatex and Poppler):
  python3 build.py

To repackage already verified files without rerunning proofs or LaTeX:
  python3 build.py --package-only

PROOF TRANSLATIONS

  python3 code/translate.py forward OLD.json NATIVE.json
  python3 code/translate.py backward NATIVE.json OLD.json
  python3 code/encode.py forward NATIVE.json PUBLIC.json
  python3 code/encode.py positive PUBLIC.json POSITIVE_NATIVE.json

All translators validate their input and output. The last command produces
a native proof of the ERASED statement. It does not claim to produce a
certificate restored to the original public root; the written formula-bridge
theorem establishes that full converse. Proof trees expand and need not
round-trip identically; the first two commands preserve their statements
exactly after the zero-token conversion.

VERIFICATION

  191 predecessor/native statement round trips
  20 independent valid native cases and 62 rejected native cases
  240 independent named-variable shift/substitution comparisons
  31 independent numerical-schema comparisons
  60 proof lifts at three variable cutoffs
  170 native proofs compiled to public certificates
  14 independently written public proofs and 40 public rejection cases
  348 mixed falsity/clash variants; 362 arbitrary positive embeddings
  942 independent public sort-reflection comparisons
  471 root-goal checks and 458 root-context checks
  34 CLI executions, including ordinary and optimized Python

Counts refer to overlapping focused suites, not unique theorems. The
independent binding oracle uses separate named-variable syntax. The encoded
audit checks that its unchanged core matches the audited native source.
A defect found in the untrusted lift helper was repaired and regression
tested; no trusted-kernel defect was found in these audits.

These are written general proofs plus finite executable verification, not a
Lean/Rocq formalization of the universal metatheorems. Host resources and
parser/stack limits can prevent checking very large valid certificates.

CONTENTS

  report.tex, sections/, report.pdf      Complete mathematical paper
  SPECIFICATION.txt, FORMAT.txt         Exhaustive theory and proof format
  code/checker.py                       Recommended complete public checker
  code/native_checker.py                Direct genuine-falsity reference
  code/checker_lists.py                 Optional list representation control
  code/translate.py, code/encode.py      Untrusted proof compilers
  code/*certificates/                   Source and generated proof fixtures
  provenance/current_sources/           Verbatim current comparison sources
  provenance/controls/                  Six matched implementation controls
  provenance/NOTICE.txt                 Attribution and source identities
  verification/                         Audits, metrics, logs, and PDF review
  SHA256SUMS.txt                        Integrity hashes for packaged files

No repository write is required to use this package.
