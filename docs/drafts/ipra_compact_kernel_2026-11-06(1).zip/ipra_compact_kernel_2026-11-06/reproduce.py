"""Verify pinned fixtures, run every delivered suite, and recount the kernels."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def read(name):
    return json.loads((ROOT/'verification'/name).read_text())


def summarize():
    t = read('translation_results.json')['counts']
    e = read('encoded_results.json')['counts']
    n = read('independent_audit.json')
    p = read('encoded_independent_audit.json')
    assert n['all_passed'] and p['all_passed']
    native_roundtrips = sum(t[key] for key in t if 'forward_backward' in key
                            or 'backward_forward' in key)
    erased = (e['source_erasure_and_embedding']
              + e['nested_witness_erasure_and_embedding']
              + e['schema_erasure_and_embedding']
              + e['public_falsity_or_lookup_case'])
    rows = [
        ('Predecessor/native statement round trips', native_roundtrips),
        ('Independent native valid / rejected cases', f"{n['positive_cases']} / {n['negative_cases']}"),
        ('Independent named-variable shift/substitution comparisons', n['oracle']['substitution_shift_comparisons']),
        ('Independent numerical-schema comparisons', n['oracle']['numerical_schema_comparisons']),
        ('Native proof lifts at three cutoffs', n['translation']['proof_lifts_at_three_cutoffs']),
        ('Native proofs compiled to public certificates', erased),
        ('Independent public valid / rejected cases', f"{p['independent_positive_certificates']} / {p['independent_negative_certificates']}"),
        ('Mixed falsity/clash public variants', p['mixed_bottom_clash_variants']),
        ('Arbitrary public proofs embedded into the native checker', p['arbitrary_positive_embedding_checks']),
        ('Independent public sort-reflection comparisons', p['independent_public_syntax_reflection']['sort_checks']),
        ('Independent root-goal / root-context checks', f"{p['independent_public_syntax_reflection']['root_goal_checks']} / {p['independent_public_syntax_reflection']['root_context_checks']}"),
        ('CLI executions, including optimized Python',
         4*t['cli_roundtrip_normal_or_optimized']
         +4*e['cli_forward_encoded_positive_direct']+e['invalid_cli_rejected']
         +len(n['cli'])+len(p['cli'])),
    ]
    text = ['\\begin{center}', '\\small',
            '\\begin{tabular}{p{.77\\linewidth}r}', '\\toprule',
            'Delivered verification category & Passed\\\\', '\\midrule']
    text.extend(label+' & '+str(count)+'\\\\' for label, count in rows)
    text.extend(['\\bottomrule', '\\end{tabular}', '\\end{center}',
                 'These are counts of checks in distinct suites, with intentional',
                 'overlap between suites; they are not a count of unique theorems.'])
    (ROOT/'verification/validation_summary.tex').write_text('\n'.join(text)+'\n')
    (ROOT/'verification/summary.json').write_text(json.dumps({
        'all_suites_passed': True, 'categories': dict(rows),
        'native_sources': n['source_sha256'], 'public_sources': p['source_sha256'],
        'scope': 'Finite executable checks plus written general mathematical proofs.'}, indent=2)+'\n')
    return dict(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--summary-only', action='store_true')
    args = parser.parse_args()
    manifest = json.loads((ROOT/'provenance/baseline_manifest.json').read_text())
    if hashlib.sha256((ROOT/'code/baseline.py').read_bytes()).hexdigest() != manifest['baseline_sha256']:
        raise ValueError('Pinned predecessor source was modified')
    for name, expected in manifest['certificates'].items():
        if hashlib.sha256((ROOT/'code/source_certificates'/name).read_bytes()).hexdigest() != expected:
            raise ValueError('Pinned source certificate was modified: '+name)
    if not args.summary_only:
        for script in ['code/test_translation.py', 'code/test_encoded.py',
                       'verification/independent_audit.py',
                       'verification/encoded_independent_audit.py']:
            subprocess.run([sys.executable, str(ROOT/script)], cwd=ROOT, check=True)
    import measure
    measure.main()
    summary = summarize()
    print(json.dumps({'all_suites_passed': True, 'checks': summary}, indent=2))


if __name__ == '__main__':
    main()
