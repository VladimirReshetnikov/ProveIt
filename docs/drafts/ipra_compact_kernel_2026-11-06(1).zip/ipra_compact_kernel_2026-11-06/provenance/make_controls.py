"""Generate matched complete verifiers; changes are one design choice each.

Controls are read/compiled and measured, not imported by the primary verifier.
Their proof formats differ as documented in README.txt.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = (ROOT.parent/'code/native_checker.py').read_text()
OUT = ROOT/'controls'
OUT.mkdir(exist_ok=True)


def block(source, start, end, replacement):
    a, b = source.index(start), source.index(end, source.index(start))
    return source[:a] + replacement + source[b:]


controls = {}
controls['separate_eliminators'] = block(SOURCE, '        case ("use",', '        case ("pair",', '''        case ("app", p, t, q):
            a = infer(p, g)
            require(a[0] == "pi" and wf(t))
            require(infer(q, g) == inst(a[1], t))
            return inst(a[2], t)
        case ("let", p, c, q):
            a = infer(p, g)
            require(a[0] == "sig" and wf(c, True))
            require(infer(q, (*map(shift, g), a[1], a[2])) == shift(c))
            return c
        case ("eq", p, a, q):
            e = infer(p, g)
            require(e[0] == "=" and wf(a, True))
            require(infer(q, g) == inst(a, e[1]))
            return inst(a, e[2])
''')
controls['ordinary_sigma'] = block(SOURCE, '        case ("pair",', '        case ("bridge",', '''        case ("pair", a, t, p, q):
            require(wf(a, True) and a[0] == "sig" and wf(t))
            require(infer(p, g) == inst(a[1], t))
            require(infer(q, g) == inst(a[2], t))
            return a
''')
controls['curried_schema'] = block(SOURCE, '        case ("nat",', '        case _:', '''        case ("nat", a):
            require(wf(a, True))
            base = shift(inst(a, ZERO))
            h = a if a[0] == "=" else base
            successor = subst(a, lambda i: ("s", 0) if i == 0 else i)
            step = ("pi", h, successor)
            return ("pi", base, ("pi", shift(step, 2), shift(a)))
''')
controls['numerical_rule'] = block(SOURCE, '        case ("nat",', '        case _:', '''        case ("nat", a, t, p, q):
            require(wf(a, True) and wf(t))
            require(infer(p, g) == inst(a, ZERO))
            h = (a,) if a[0] == "=" else ()
            successor = subst(a, lambda i: ("s", 0) if i == 0 else i)
            require(infer(q, (*map(shift, g), *h)) == successor)
            return inst(a, t)
''')
controls['tagged_zero'] = SOURCE.replace('ZERO = -1', 'ZERO = ("z",)').replace(
    'return not formula and a >= -1\n',
    'return not formula and a >= 0\n        case ("z",):\n            return not formula\n')
controls['indexed_hypotheses'] = block(SOURCE, '        case ("hyp",', '        case ("pi",', '''        case ("hyp", i):
            require(type(i) is int and 0 <= i < len(g))
            return g[i]
''')
for name, source in controls.items():
    compile(source, name, 'exec')
    (OUT/(name+'.py')).write_text(source)
print('Generated', len(controls), 'matched controls')
