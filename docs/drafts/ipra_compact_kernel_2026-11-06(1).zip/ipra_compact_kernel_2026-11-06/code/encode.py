"""Untrusted bridge erasure and positive embedding for the encoded verifier.

forward_direct_certificate preserves the original public assertions and
removes direct bridge proof nodes; the trusted verifier performs the counted
public-falsity decoding. positive_embedding verifies an arbitrary encoded
certificate and returns a direct proof of its ERASED goal from its ERASED
assumptions. It does not reconstruct a direct certificate at the original
public root. The report's formula-bridge theorem supplies that converse.
"""
from pathlib import Path
import argparse
import json

import native_checker as direct
import checker as encoded


def json_value(data):
    """Use the same finite JSON values as the two public file interfaces."""
    return json.loads(json.dumps(data))


def remove_bridges(proof):
    if type(proof) is list:
        if len(proof) == 2 and proof[0] == 'bridge':
            return remove_bridges(proof[1])
        return list(map(remove_bridges, proof))
    return proof


def forward_direct_certificate(data):
    direct.check(data)
    result = json_value(data)
    result['proof'] = remove_bridges(result['proof'])
    encoded.check(result)
    return result


def positive_embedding(data):
    data = json_value(data)
    encoded.check(data)
    result = {key:encoded.freeze(data[key])
              for key in ('assumptions', 'goal', 'proof')}
    # Root assumptions must be a list at the direct checker's JSON boundary.
    result = json_value(result)
    direct.check(result)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('direction', choices=('forward', 'positive'))
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path, nargs='?')
    args = parser.parse_args()
    source = json.loads(args.input.read_text(encoding='utf-8'))
    action = forward_direct_certificate if args.direction == 'forward' else positive_embedding
    result = action(source)
    text = json.dumps(result, separators=(',', ':'))+'\n'
    if args.output:
        args.output.write_text(text, encoding='utf-8')
    else:
        print(text, end='')
