"""Focused compiler regression: bound variables, contexts, and statement round trips.

Both compilers independently validate both endpoints. These are finite checks;
the mathematical proof establishes the general translation theorem.
"""
from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys
import tempfile

import translate as tr

ROOT = Path(__file__).resolve().parent
new, old = tr.new, tr.old
counts = {}


def count(name):
    counts[name] = counts.get(name, 0)+1


def equivalent(left, right, kernel):
    assert kernel.freeze(left['goal']) == kernel.freeze(right['goal'])
    assert kernel.freeze(left['assumptions']) == kernel.freeze(right['assumptions'])


def forward_roundtrip(document, label):
    candidate = tr.forward(document)
    predecessor = tr.backward(candidate)
    equivalent(document, predecessor, old)
    count(label)
    return candidate


def backward_roundtrip(document, label):
    predecessor = tr.backward(document)
    candidate = tr.forward(predecessor)
    equivalent(document, candidate, new)
    count(label)


def rejected(thunk, label):
    try:
        thunk()
    except (ValueError, TypeError, IndexError, KeyError, RecursionError):
        count(label)
        return
    raise AssertionError('unexpected acceptance: '+label)


def dummy_pair(document):
    a = old.freeze(document['goal'])
    p = old.freeze(document['proof'])
    principal = ('sig', old.shift(a), old.shift(a))
    return {'assumptions':document['assumptions'], 'goal':principal,
            'proof':('pair', principal, old.ZERO, p, p)}


def native(g, p):
    g = tuple(g)
    return {'assumptions':list(g), 'goal':new.infer(p,g), 'proof':p}


sources = sorted((ROOT/'source_certificates').glob('*.json'))
assert len(sources) == 53
for path in sources:
    document = json.loads(path.read_text())
    forward_roundtrip(document, 'inherited_forward_backward')
    for _ in range(2):
        document = dummy_pair(document)
        forward_roundtrip(document, 'nested_witness_forward_backward')

# New numerical leaves exercise every syntactic category, parameters, and
# a recursion body that mentions both its two bound slots and free parameters.
templates = [
    ('=',0,('r',1,-1,('s',0))),
    new.FALSE,
    ('pi',('=',1,2),('=',0,2)),
    ('sig',new.FALSE,('=',0,1)),
    ('=',('r',0,1,('r',1,2,('s',0))),('r',2,-1,0)),
]
contexts = [(), (('=',0,1), ('pi',new.FALSE,('=',1,1)))]
for a in templates:
    for g in contexts:
        backward_roundtrip(native(g,('nat',a)), 'native_numerical_backward_forward')

# Entirely native witness derivations, including a dependent local Pi binder
# and a schema leaf underneath the witness equation.
terms = [-1, 0, 37, ('s',0), ('r',2,0,('r',1,2,('s',0)))]
for t in terms:
    for g in contexts:
        eq = ('=',0,new.shift(t))
        left = ('hyp',eq)
        right = ('pi',new.shift(eq),('hyp',new.shift(eq)))
        pair = ('pair',t,left,right)
        backward_roundtrip(native(g,pair), 'native_witness_backward_forward')
        pair2 = ('pair',t,('nat',new.shift(templates[-1])),left)
        backward_roundtrip(native(g,pair2), 'native_witness_schema_backward_forward')

# The assumption stored in the context, not the untrusted lookup key, is
# returned. Canonical true/false claims and typed data remain strict.
g = (('=',0,1),)
for key in [('=',False,True), ('=',0.0,1.0)]:
    d = native(g,('hyp',key))
    assert d['goal'] is g[0]
    backward_roundtrip(d, 'stored_hypothesis_alias_backward_forward')

# Endpoint validation must occur before translation; invalid certificates
# cannot acquire validity through serialization or context conversion.
bad = {'assumptions':[], 'goal':['false'], 'proof':['hyp',0]}
rejected(lambda: tr.forward(bad), 'invalid_source_rejected')
bad = {'assumptions':[], 'goal':['false'], 'proof':['hyp',['false']]}
rejected(lambda: tr.backward(bad), 'invalid_target_rejected')
bad = {'assumptions':[['=',False,0]], 'goal':['=',0,0], 'proof':['hyp',['=',0,0]]}
rejected(lambda: tr.backward(bad), 'invalid_target_context_rejected')
bad = native((),('nat',templates[2]))
bad = copy.deepcopy(bad)
bad['goal'] = ('pi',new.FALSE,new.FALSE)
rejected(lambda: tr.backward(bad), 'forged_schema_conclusion_rejected')

# Command-line paths exercise the same local import setup as the deliverable.
with tempfile.TemporaryDirectory() as temp:
    temp = Path(temp)
    source = sources[0]
    target, returned = temp/'target.json', temp/'returned.json'
    for optimized in (False, True):
        python = [sys.executable]+(['-O'] if optimized else [])
        subprocess.run([*python,str(ROOT/'translate.py'),'forward',str(source),str(target)],check=True,capture_output=True,text=True)
        subprocess.run([*python,str(ROOT/'native_checker.py'),str(target)],check=True,capture_output=True,text=True)
        subprocess.run([*python,str(ROOT/'translate.py'),'backward',str(target),str(returned)],check=True,capture_output=True,text=True)
        subprocess.run([*python,str(ROOT/'baseline.py'),str(returned)],check=True,capture_output=True,text=True)
        count('cli_roundtrip_normal_or_optimized')

result = {'python':sys.version, 'counts':counts,
          'source_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
          'scope':'finite proof tests; exact statement round trips; not a formalized soundness proof'}
(ROOT.parent/'verification/translation_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(counts,indent=2))
