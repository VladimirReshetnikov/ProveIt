"""Focused checks of the counted public decoder and positive-proof adequacy.

These finite tests supplement the structural erasure theorem. They do not
claim a machine formalization of the general metatheorem.
"""
from pathlib import Path
import copy
import json
import subprocess
import sys
import tempfile

import native_checker as direct
import checker as encoded
import checker_lists as listed
import encode as compiler
import translate as tr

ROOT = Path(__file__).resolve().parent
counts = {}


def tick(label):
    counts[label] = counts.get(label, 0)+1


def erase(a):
    return encoded.freeze(compiler.json_value(a))


def document(g, p):
    return {'assumptions':list(g), 'goal':direct.infer(p,tuple(g)), 'proof':p}


def verify(d, label):
    e = compiler.forward_direct_certificate(d)
    assert e['assumptions'] == compiler.json_value(d['assumptions'])
    assert e['goal'] == compiler.json_value(d['goal'])
    listed.check(e)
    embedded = compiler.positive_embedding(e)
    assert direct.freeze(embedded['goal']) == erase(d['goal'])
    assert direct.freeze(embedded['assumptions']) == erase(d['assumptions'])
    tick(label)
    return e


def reject(d, label):
    for checker in (encoded, listed):
        try:
            checker.check(compiler.json_value(d))
        except (ValueError, TypeError, IndexError, KeyError, RecursionError):
            pass
        else:
            raise AssertionError('unexpected acceptance '+label)
    tick(label)


for path in sorted((ROOT/'source_certificates').glob('*.json')):
    d = json.loads(path.read_text())
    verify(tr.forward(d),'source_erasure_and_embedding')
    for _ in range(2):
        a, p = tr.old.freeze(d['goal']), tr.old.freeze(d['proof'])
        sigma = ('sig',tr.old.shift(a),tr.old.shift(a))
        d = {'assumptions':d['assumptions'], 'goal':sigma,
             'proof':('pair',sigma,tr.old.ZERO,p,p)}
        verify(tr.forward(d),'nested_witness_erasure_and_embedding')

# Exact commutation of the numerical schema, particularly P = bottom.
templates = [direct.FALSE, direct.CLASH,
             ('=',0,('r',1,-1,('s',0))),
             ('pi',direct.FALSE,('=',0,1)),
             ('sig',('=',0,1),direct.FALSE)]
for a in templates:
    p = ('nat',a)
    d = document((),p)
    verify(d,'schema_erasure_and_embedding')
    positive = encoded.infer(erase(p),())
    assert positive == erase(d['goal'])
    tick('literal_schema_commutation')

# Context falsity, both bridge directions, and a bottom containing binder.
for g, p in [
    ((direct.FALSE,),('hyp',direct.FALSE)),
    ((direct.FALSE,),('bridge',('hyp',direct.FALSE))),
    ((direct.CLASH,),('bridge',('hyp',direct.CLASH))),
    ((direct.FALSE,),('pi',direct.FALSE,('hyp',direct.FALSE))),
    ((('=',0,1),),('hyp',('=',False,True))),
    ((('=',0,1),),('hyp',('=',0.0,1.0))),
]:
    verify(document(g,p),'public_falsity_or_lookup_case')

# Independently written encoded certificate, with the public false node
# present in both assertion and proof key. This is not compiler output.
raw = {'assumptions':[['false']], 'goal':['false'], 'proof':['hyp',['false']]}
encoded.check(raw)
listed.check(raw)
compiler.positive_embedding(raw)
tick('independent_encoded_public_certificate')

# Public syntax validity is reflected by erasure; a false node in a term
# position does not become a well-formed term after decoding.
atoms = [-2,-1,0,7,True,False,0.0,None,'false','=',[],{},['false'],['s',-1],
         ['=',0,1],['s',['false']],['=', ['false'],-1],['false',0]]
samples = list(atoms)
for a in atoms:
    samples.extend([['s',a],['=',a,-1],['pi',a,['false']],
                    ['sig',['false'],a],['r',0,-1,a]])
for a in samples:
    for formula in (False,True):
        assert bool(direct.wf(direct.freeze(a),formula)) == bool(encoded.wf(erase(a),formula))
        tick('public_syntax_reflection')

bad = [
    {'assumptions':['false'],'goal':['false'],'proof':['hyp',['false']]},
    {'assumptions':[],'goal':['=', ['false'],-1],'proof':['nat',['false']]},
    {'assumptions':[['=',False,0]],'goal':['=',0,0],'proof':['hyp',['=',0,0]]},
    {'assumptions':[['false']],'goal':'false','proof':['hyp',['false']]},
    {'assumptions':[['false']],'goal':['false'],'proof':['bridge',['hyp',['false']]]},
    {'assumptions':[['false']],'goal':['false'],'proof':['hyp',['false']],'extra':0},
    {'assumptions':[['=',0,0]],'goal':['=',-2,0],'proof':['hyp',['=',0,0]]},
]
for d in bad:
    reject(d,'malformed_public_certificate')

# A binder template stays a binder after erasure; the encoded schema cannot
# silently supply it with an unrestricted induction hypothesis.
a = ('pi',('=',0,0),('=',1,0))
base = direct.inst(a,-1)
strong_step = ('pi',a,direct.subst(a,lambda i:('s',0) if i==0 else i))
strong = ('pi',('sig',direct.shift(base,2),direct.shift(strong_step,2)),a)
reject({'assumptions':[],'goal':strong,'proof':('nat',a)},'forged_non_equation_induction')

with tempfile.TemporaryDirectory() as tmp:
    tmp = Path(tmp)
    source = ROOT/'certificates'/'bridge_false_to_clash.json'
    public, positive = tmp/'encoded.json', tmp/'positive.json'
    for optimize in (False, True):
        cmd = [sys.executable]+(['-O'] if optimize else [])
        subprocess.run([*cmd,str(ROOT/'encode.py'),'forward',str(source),str(public)],check=True,capture_output=True,text=True)
        subprocess.run([*cmd,str(ROOT/'checker.py'),str(public)],check=True,capture_output=True,text=True)
        subprocess.run([*cmd,str(ROOT/'encode.py'),'positive',str(public),str(positive)],check=True,capture_output=True,text=True)
        subprocess.run([*cmd,str(ROOT/'native_checker.py'),str(positive)],check=True,capture_output=True,text=True)
        tick('cli_forward_encoded_positive_direct')
        invalid = tmp/'invalid.json'
        invalid.write_text(json.dumps(bad[0]))
        for verifier in ('checker.py','checker_lists.py'):
            r=subprocess.run([*cmd,str(ROOT/verifier),str(invalid)],capture_output=True,text=True)
            assert r.returncode == 1 and r.stdout.strip() == 'REJECT' and not r.stderr
            tick('invalid_cli_rejected')

(ROOT.parent/'verification/encoded_results.json').write_text(json.dumps({'python':sys.version,'counts':counts,
    'converse_scope':'positive_embedding returns erased roots; original-root converse is the written formula-bridge theorem'},indent=2)+'\n')
print(json.dumps(counts,indent=2))
