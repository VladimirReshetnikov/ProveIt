"""Untrusted total-on-valid-proof compilers; both endpoints checked.

Source is the pinned K verifier included verbatim as baseline.py.
Target uses genuine false, a numerical axiom, shared use, witnessed Sigma,
and formula-valued hypotheses. No translator belongs to the trusted kernel.
"""
import baseline as old
import native_checker as new


def syntax(a, reverse=False):
    if reverse and a == -1:
        return old.ZERO
    if not reverse and a == old.ZERO:
        return new.ZERO
    if type(a) is int:
        return a
    return (a[0], *(syntax(b, reverse) for b in a[1:]))


def insert(a, protected=0):
    return new.walk(a, lambda i, d: i+d+1, protected)


def reflexivity(t, kernel=new, elimination='use'):
    p = ('rec', ('r', kernel.ZERO, t, kernel.ZERO))
    return (elimination, p, ('=', 0, kernel.shift(t)), p)


def lift(p, g, protected=0):
    """Insert a fresh number below local proof binders; hypotheses name formulas."""
    def sy(a, extra=0): return insert(a, protected+extra)
    def sub(q): return lift(q, g, protected)
    match p:
        case ('hyp', a): return ('hyp', sy(g[g.index(a)]))
        case ('pi', a, q):
            h = (*map(new.shift, g), a)
            return ('pi', sy(a, 1), lift(q, h, protected+1))
        case ('use', principal, a, q):
            e = new.infer(principal, g)
            h = (*map(new.shift, g), *e[1:]) if e[0]=='sig' else g
            return ('use', sub(principal), sy(a, e[0]=='='),
                    lift(q, h, protected+(e[0]=='sig')))
        case ('pair', t, p, q):
            h = (*map(new.shift, g), ('=', 0, new.shift(t)))
            return ('pair', sy(t), lift(p, h, protected+1), lift(q, h, protected+1))
        case ('bridge', q): return ('bridge', sub(q))
        case ('rec', r): return ('rec', sy(r))
        case ('nat', a): return ('nat', sy(a, 1))
        case _: raise ValueError('unknown target proof')


def witnessed(principal, t, p, q, g):
    equality = ('hyp', ('=', 0, new.shift(t)))
    backwards = ('use', equality, ('=', 0, 1), reflexivity(0))
    def branch(a, proof):
        return ('use', backwards, insert(a, 1), lift(proof, g))
    return ('pair', t, branch(principal[1], p), branch(principal[2], q))


def forward_proof(p, g):
    def sub(q): return forward_proof(q, g)
    match p:
        case ('hyp', i): return ('hyp', syntax(g[i]))
        case ('pi', a, q):
            return ('pi', syntax(a), forward_proof(q, (*map(old.shift, g), a)))
        case ('app'|'eq', principal, a, q):
            return ('use', sub(principal), syntax(a), sub(q))
        case ('let', principal, c, q):
            e = old.infer(principal, g)
            h = (*map(old.shift, g), *e[1:])
            return ('use', sub(principal), syntax(c), forward_proof(q,h))
        case ('pair', a, t, p, q):
            return witnessed(syntax(a), syntax(t), sub(p), sub(q), tuple(map(syntax,g)))
        case ('bridge', p): return ('bridge', sub(p))
        case ('rec', r): return ('rec', syntax(r))
        case ('nat', a, t, p, q):
            b=syntax(a)
            guard=b if a[0]=='=' else new.shift(new.inst(b,new.ZERO))
            h=(*map(old.shift,g), *((a,) if a[0]=='=' else ()))
            step=('pi',guard,forward_proof(q,h))
            schema=new.infer(('nat',b),tuple(map(syntax,g)))
            premise=new.inst(schema[1],syntax(t))
            pair=witnessed(premise,new.ZERO,sub(p),step,tuple(map(syntax,g)))
            return ('use',('nat',b),syntax(t),pair)
        case _: raise ValueError('unknown baseline proof')


def numerical_in_old(a, n):
    base=old.inst(a,old.ZERO)
    atomic=a[0]=='='
    guard=a if atomic else old.shift(base)
    successor=old.subst(a,lambda i: ('s',0) if i==0 else i)
    step=('pi',guard,successor)
    antecedent=('sig',old.shift(base,2),old.shift(step,2))
    template=old.subst(a,lambda i: 0 if i==0 else i+2)
    minor=n+3 if atomic else n+1
    q=('app',('hyp',n+2),0,('hyp',minor))
    p=('nat',template,1,('hyp',n+1),q)
    return ('pi',antecedent,('let',('hyp',n),a,p))


def backward_proof(p,g):
    def sub(q): return backward_proof(q,g)
    def sy(a): return syntax(a,True)
    match p:
        case ('hyp', a): return ('hyp',g.index(a))
        case ('pi', a, q):
            return ('pi',sy(a),backward_proof(q,(*map(new.shift,g),a)))
        case ('use', principal, a, q):
            e=new.infer(principal,g)
            tag={'=':'eq','pi':'app','sig':'let'}[e[0]]
            h=(*map(new.shift,g),*e[1:]) if e[0]=='sig' else g
            return (tag,sub(principal),sy(a),backward_proof(q,h))
        case ('pair', t, p, q):
            h=(*map(new.shift,g),('=',0,new.shift(t)))
            principal=('sig',new.infer(p,h),new.infer(q,h))
            witness=sy(t)
            guard=('=',0,old.shift(witness))
            def branch(r):
                return ('app',('pi',guard,backward_proof(r,h)),witness,
                        reflexivity(witness,old,'eq'))
            return ('pair',sy(principal),witness,branch(p),branch(q))
        case ('bridge', p): return ('bridge',sub(p))
        case ('rec', r): return ('rec',sy(r))
        case ('nat', a): return numerical_in_old(sy(a),len(g))
        case _: raise ValueError('unknown target proof')


def forward(data):
    old.check(data)
    g=tuple(map(old.freeze,data['assumptions']))
    result={'assumptions':list(map(syntax,g)), 'goal':syntax(old.freeze(data['goal'])),
            'proof':forward_proof(old.freeze(data['proof']),g)}
    new.check(result)
    return result


def backward(data):
    new.check(data)
    g=tuple(map(new.freeze,data['assumptions']))
    result={'assumptions':[syntax(a,True) for a in g],
            'goal':syntax(new.freeze(data['goal']),True),
            'proof':backward_proof(new.freeze(data['proof']),g)}
    old.check(result)
    return result


if __name__ == '__main__':
    import argparse
    import json
    from pathlib import Path
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('direction', choices=('forward', 'backward'))
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path, nargs='?')
    args = parser.parse_args()
    data = json.loads(args.input.read_text(encoding='utf-8'))
    result = (forward if args.direction == 'forward' else backward)(data)
    text = json.dumps(result, separators=(',', ':'))+'\n'
    if args.output:
        args.output.write_text(text, encoding='utf-8')
    else:
        print(text, end='')
