"""Reproduce verification, build the LaTeX paper, and package a checked ZIP."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent


def packaged_files():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and not any(part in ('build', '__pycache__', 'rendered')
                              for part in p.relative_to(ROOT).parts)
                  and p.suffix not in ('.pyc', '.pyo')
                  and p.name != 'SHA256SUMS.txt')


def package():
    if not (ROOT/'report.pdf').is_file():
        raise ValueError('Compile report.pdf before packaging')
    files = packaged_files()
    manifest = ROOT/'SHA256SUMS.txt'
    manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()
                               +'  '+str(p.relative_to(ROOT))+'\n' for p in files))
    destination = ROOT.parent/(ROOT.name+'.zip')
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in [*files, manifest]:
            archive.write(path, ROOT.name+'/'+str(path.relative_to(ROOT)))
    with zipfile.ZipFile(destination) as archive:
        assert archive.testzip() is None
        for line in manifest.read_text().splitlines():
            expected, name = line.split('  ', 1)
            assert hashlib.sha256(archive.read(ROOT.name+'/'+name)).hexdigest() == expected
    print(json.dumps({'archive': str(destination), 'files': len(files)+1,
                      'bytes': destination.stat().st_size,
                      'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--skip-checks', action='store_true')
    parser.add_argument('--package-only', action='store_true')
    args = parser.parse_args()
    if args.package_only:
        package()
        return
    if not args.skip_checks:
        subprocess.run([sys.executable, str(ROOT/'reproduce.py')], cwd=ROOT, check=True)
    build = ROOT/'build'
    build.mkdir(exist_ok=True)
    for number in range(1, 4):
        result = subprocess.run(['pdflatex', '-interaction=nonstopmode',
                                 '-halt-on-error', '-file-line-error',
                                 '-output-directory=build', 'report.tex'],
                                cwd=ROOT, text=True, capture_output=True)
        (build/f'pass_{number}.txt').write_text(result.stdout+result.stderr)
        if result.returncode:
            print(result.stdout[-12000:])
            raise RuntimeError('LaTeX compilation failed')
    log = (build/'report.log').read_text(errors='replace')
    defects = [line for line in log.splitlines()
               if 'Overfull ' in line or 'undefined' in line
               or 'Rerun to get' in line or 'LaTeX Error' in line]
    shutil.copy2(build/'report.log', ROOT/'verification/latex.log')
    if defects:
        print('\n'.join(defects))
        raise RuntimeError('Resolve the reported final LaTeX warnings')
    shutil.copy2(build/'report.pdf', ROOT/'report.pdf')
    info = subprocess.run(['pdfinfo', str(ROOT/'report.pdf')],
                          text=True, capture_output=True, check=True).stdout
    pages = int(re.search(r'^Pages:\s+(\d+)', info, re.M).group(1))
    (ROOT/'verification/compilation.json').write_text(json.dumps({
        'latex_passes': 3, 'pages': pages, 'overfull_boxes': 0,
        'undefined_references': 0, 'pdf_bytes': (ROOT/'report.pdf').stat().st_size,
        'visual_review': 'See pdf_inspection.json for the separately recorded rendered-page review.'}, indent=2)+'\n')
    package()


if __name__ == '__main__':
    main()
