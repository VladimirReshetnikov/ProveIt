"""Recount complete sources and verify every pinned comparison source hash.

This program reads Python source as data. It never imports or executes a
comparison checker. Standard Python and its standard library are the common
external runtime. All local source required by a checker must be counted.
"""
from pathlib import Path
import ast
import hashlib
import io
import json
import sys
import tokenize

ROOT = Path(__file__).resolve().parent
IGNORED = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.NEWLINE,
           tokenize.NL, tokenize.INDENT, tokenize.DEDENT, tokenize.COMMENT}


class RemoveDocstrings(ast.NodeTransformer):
    def strip(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body.pop(0)
        if not node.body and not isinstance(node, ast.Module):
            node.body.append(ast.Pass())
        return node

    visit_Module = strip
    visit_FunctionDef = strip
    visit_AsyncFunctionDef = strip
    visit_ClassDef = strip


def measure(path):
    raw = path.read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef,
                             ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                expr = node.body[0]
                spans.append(((expr.lineno, expr.col_offset),
                              (expr.end_lineno, expr.end_col_offset)))
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(source).readline)
              if t.type not in IGNORED
              and not any(a <= t.start and t.end <= b for a, b in spans)]
    clean = RemoveDocstrings().visit(tree)
    normalized = ast.unparse(clean) + '\n'
    normalized_tokens = [t for t in tokenize.generate_tokens(
        io.StringIO(normalized).readline) if t.type not in IGNORED]
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(a.name for a in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.append(node.module or '')
    if any(i.split('.')[0] not in sys.stdlib_module_names
           and i != '__future__' for i in imports):
        raise ValueError('Uncounted nonstandard dependency: ' + str(path))
    if '__main__' not in source or 'json.load' not in source:
        raise ValueError('Missing standalone JSON entry point: ' + str(path))
    return {
        'source': str(path.relative_to(ROOT)),
        'sha256': hashlib.sha256(raw).hexdigest(),
        'raw_utf8_bytes': len(raw),
        'normalized_utf8_bytes': len(normalized.encode('utf-8')),
        'significant_source_tokens': len(tokens),
        'normalized_tokens': len(normalized_tokens),
        'ast_nodes': sum(1 for _ in ast.walk(clean)),
        'standard_library_imports': sorted(set(imports)),
        'local_dependencies': [],
        'physical_lines': len(source.splitlines()),
    }


def main():
    manifest = json.loads((ROOT/'provenance/current_manifest.json').read_text())
    rows = []
    for old in manifest['variants']:
        row = measure(ROOT/old['saved_source'])
        if row['sha256'] != old['sha256']:
            raise ValueError('Pinned comparator hash mismatch: '+row['source'])
        row.update({k: old[k] for k in
                    ('archive', 'variant', 'primary', 'semantics', 'archive_entry')})
        rows.append(row)
    candidates = {}
    for name, relative in [('primary', 'code/checker.py'),
                           ('native', 'code/native_checker.py')]:
        if (ROOT/relative).exists():
            candidates[name] = measure(ROOT/relative)
    controls = [measure(p) for p in sorted((ROOT/'provenance/controls').glob('*.py'))]
    keys = ['raw_utf8_bytes', 'normalized_utf8_bytes',
            'significant_source_tokens', 'normalized_tokens', 'ast_nodes']
    minima = {key: min(row[key] for row in rows) for key in keys}
    for name, row in candidates.items():
        for key in keys:
            if row[key] >= minima[key]:
                raise ValueError(f'{name} does not beat {key}: {row[key]} >= {minima[key]}')
    result = {
        'python': sys.version,
        'source_snapshot': manifest['commit'],
        'conventions': {
            'raw_utf8_bytes': 'Complete original source, including comments and docstrings.',
            'significant_source_tokens': 'Original spelling; discard comments, layout tokens, and true docstrings.',
            'normalized_tokens': 'Tokens of ast.unparse after removing docstrings, with a final newline.',
            'normalized_utf8_bytes': 'UTF-8 length of that normalized source.',
            'ast_nodes': 'Every node in ast.walk after removing docstrings.',
        },
        'candidates': candidates,
        'current_sources': rows,
        'matched_controls': controls,
        'current_coordinate_minima': minima,
        'all_candidate_metrics_strictly_below_current_minima': True,
    }
    verification = ROOT/'verification'
    verification.mkdir(exist_ok=True)
    (verification/'metrics.json').write_text(json.dumps(result, indent=2)+'\n')
    p = candidates['primary']
    native = candidates.get('native', p)
    macros = {
        'CandidateTokens': p['significant_source_tokens'],
        'CandidateNormalizedTokens': p['normalized_tokens'],
        'CandidateAST': p['ast_nodes'],
        'CandidateRawBytes': p['raw_utf8_bytes'],
        'CandidateNormalizedBytes': p['normalized_utf8_bytes'],
        'NativeTokens': native['significant_source_tokens'],
        'NativeNormalizedTokens': native['normalized_tokens'],
        'NativeAST': native['ast_nodes'],
        'NativeRawBytes': native['raw_utf8_bytes'],
        'NativeNormalizedBytes': native['normalized_utf8_bytes'],
    }
    (verification/'metrics_macros.tex').write_text(''.join(
        '\\newcommand{\\'+name+'}{'+format(value, ',')+'}\n'
        for name, value in macros.items()))
    labels = {
        'arithmetic_falsity': 'Arithmetic falsity',
        'checked_presentation': 'Checked presentation',
        'premise_kernel': 'Premise kernel',
        'shared_eliminator': 'Shared eliminator',
        'universal_kernel': 'Universal kernel',
        'witness_kernel': 'Witness kernel',
    }
    table = ['\\begin{tabular}{lrrrrr}', '\\toprule',
             'Complete checker & Source & Normalized & AST & Exec. & Raw\\\\',
             ' & tokens & tokens & nodes & bytes & bytes\\\\', '\\midrule']
    for row in rows:
        if not row['primary']:
            continue
        label = row['archive'].removeprefix('ipra_').removesuffix('_2026-11-06.zip')
        values = [row[k] for k in ('significant_source_tokens', 'normalized_tokens',
                                   'ast_nodes', 'normalized_utf8_bytes', 'raw_utf8_bytes')]
        table.append(labels[label]+' & '+' & '.join(format(x, ',') for x in values)+'\\\\')
    table.extend(['\\midrule', 'Current coordinate minima & '+
                  ' & '.join(format(minima[k], ',') for k in
                     ('significant_source_tokens', 'normalized_tokens', 'ast_nodes',
                      'normalized_utf8_bytes', 'raw_utf8_bytes'))+'\\\\'])
    for name, row in candidates.items():
        label = 'New public checker' if name == 'primary' else 'New native checker'
        table.append('\\textbf{'+label+'} & '+
                     ' & '.join('\\textbf{'+format(row[k], ',')+'}' for k in
                        ('significant_source_tokens', 'normalized_tokens', 'ast_nodes',
                         'normalized_utf8_bytes', 'raw_utf8_bytes'))+'\\\\')
    table.extend(['\\bottomrule', '\\end{tabular}'])
    (verification/'comparison_table.tex').write_text('\n'.join(table)+'\n')
    labels2 = {
        'separate_eliminators': 'Separate elimination records',
        'ordinary_sigma': 'Ordinary existential introduction',
        'numerical_rule': 'Numerical inference rule',
        'curried_schema': 'Curried numerical schema',
        'tagged_zero': 'Tagged zero constructor',
        'indexed_hypotheses': 'Indexed hypothesis references',
    }
    table = ['\\begin{tabular}{lrrr}', '\\toprule',
             'Complete native implementation & Norm. tokens & AST nodes & Exec. bytes\\\\',
             '\\midrule', 'Combined native checker & '+
             ' & '.join(format(native[k], ',') for k in
                        ('normalized_tokens', 'ast_nodes', 'normalized_utf8_bytes'))+'\\\\']
    for row in controls:
        stem = Path(row['source']).stem
        table.append(labels2.get(stem, stem.replace('_', ' '))+' & '+
                     ' & '.join(format(row[k], ',') for k in
                                ('normalized_tokens', 'ast_nodes', 'normalized_utf8_bytes'))+'\\\\')
    table.extend(['\\bottomrule', '\\end{tabular}'])
    (verification/'controls_table.tex').write_text('\n'.join(table)+'\n')
    print(json.dumps({'candidates': candidates, 'current_minima': minima,
                      'comparison_variants': len(rows),
                      'matched_controls': len(controls)}, indent=2))
    return result


if __name__ == '__main__':
    main()
