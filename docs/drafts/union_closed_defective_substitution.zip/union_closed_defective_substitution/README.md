# Sharp abundance under defective substitutions

**Start with `paper.pdf`** (10 pages). This research note proves an elementary, sharp structural partial theorem for Frankl's union-closed sets conjecture. It does not prove the unrestricted conjecture or improve the unrestricted universal abundance constant.

A replacement block of `t` generators is a group of pairwise disjoint generators such that, after fixing all other incidence coordinates, each nonempty line of possible replacement patterns contains at least `m` of the `t` possibilities. If a ground point belongs to one generator from each of `r` disjoint such blocks, its frequency among distinct unions is strictly greater than

    1 - product_i q(t_i,m_i),
    q(t,m) = 2^(t-1) / (2^(t-1) + sum_{j=0}^{m-2} binom(t-1,j)).

In particular two blocks each retaining at least `ceil(t/2)+1` choices per nonempty line guarantee frequency strictly greater than 5/9. Three four-index blocks retaining three choices per line give >19/27. The theorem permits arbitrary exterior incidences respecting the local line conditions. The paper proves a stronger joint bound for arbitrary marked subsets, its conditional and limiting sharpness, and an unbounded connected family with incomplete substitutions. The explicit 48-point example has 3024 distinct unions and frequency 631/756 for every point.

## Contents

- `paper.tex`, `paper.pdf`: complete proofs and bibliography, source and compiled PDF.
- `verify.py`: standard-library Python exact checks. Keep assertions enabled.
- `verification.txt`, `verification.json`: actual executed checks; the JSON includes exact sharpness counts, the explicit example's hyperedge bitmasks, and rational threshold values.
- `provenance.md`: source inventory and priority limitations.
- `Makefile`: reproduction commands.
- `SHA256SUMS`: integrity manifest for the packaged files.

## Reproduce

With Python 3.10+ and standard TeX Live (AMS packages, geometry, microtype, booktabs, enumitem, hyperref, xcolor):

```sh
sha256sum -c SHA256SUMS
python3 verify.py
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
```

The Python program rewrites `verification.json`; redirect stdout to `verification.txt` to regenerate that record. The PDF may differ in metadata after rebuilding. The mathematical proofs do not depend on the finite checks. No Lean/Rocq formalization or independent human peer review is claimed. No repository changes were made. Priority is provisional; one large repository archive could not be inspected and the other full texts, except the closest substitution note, were not systematically reviewed.
