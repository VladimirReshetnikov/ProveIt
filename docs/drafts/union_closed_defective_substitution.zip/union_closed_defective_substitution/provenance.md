# Source and novelty audit

Date: 2026-11-25 (America/Los_Angeles). The linked repository was accessed using the GitHub connector, read-only. The returned main branch commit was `af74b43aa03c32924ba610ddd6820f8905e1186a`. The directory listing and branch lookup were separate reads; this is not a cryptographically pinned snapshot of every archive.

## Closest source

- [union_closed_substitution.zip](https://github.com/VladimirReshetnikov/ProveIt/blob/main/docs/drafts/union_closed_substitution.zip), blob `ed07cbc73f2d66acf503b5d34206b7bfd65afad1`, 292862 bytes. The full `paper.tex` was extracted and inspected. It proves exact factorization for complete hypergraph substitutions, the independent-clone factor `2^(t-1)/(2^t-1)`, exterior conditioning, joint laws, and marked sharpness. The present paper credits these results and the classical duality explicitly. Its new proposed extension is to nonempty replacement lines that retain only `m` of `t` possibilities, without any global factorization: the local fibre is a hitting family, the extremal binomial factor is exact, and the exterior-uniform bounds multiply. The complete case is recovered at `m=t`.

## Repository screening

The listing of [docs/drafts](https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts) contained 24 ZIP files. README summaries were extracted for the following 23; these were not all read in full.

- union-closed-abundance.zip
- union-closed-results.zip
- union_closed_abundance.zip
- union_closed_abundance_theorems.zip
- union_closed_advances_2026-11-25.zip
- union_closed_cycle_certificates.zip
- union_closed_dense_core_2026-11-25.zip
- union_closed_entropy_2026_11_25.zip
- union_closed_entropy_research_2026-11-25.zip
- union_closed_extensions_2026-11-25(1).zip
- union_closed_extensions_2026-11-25.zip
- union_closed_frequency_bounds.zip
- union_closed_joint_laws_2026-11-25.zip
- union_closed_local_abundance.zip
- union_closed_marked_abundance.zip
- union_closed_partial_results.zip
- union_closed_partial_theorems_2026-11-25.zip
- union_closed_rank_transport_2026-11-25.zip
- union_closed_refinements_2026-11-25.zip
- union_closed_substitution.zip
- union_closed_three_results.zip
- union_closed_trace_entropy_2026-11-25.zip
- union_closed_uniform_threshold_2026-11-25.zip

The remaining archive `union_closed_structural_theorems.zip` (4265422 bytes; blob `bba38e6abe6445578e551dfc16f678f4fdb4fa56`) returned an empty base64 content field in the GitHub connector. It could not be inspected. No complete claim about coverage of that archive or the other 22 full manuscripts is made.

## Literature consulted

- [Union-closed sets conjecture](https://en.wikipedia.org/wiki/Union-closed_sets_conjecture), problem statement and known cases.
- Emanuel Knill, [Graph generated union-closed families of sets](https://arxiv.org/abs/math/9409215) (1994). Classical duality and the case of maximum point incidence degree two.
- Henning Bruhn, Pierre Charbit, Oliver Schaudt and Jan Arne Telle, [The graph formulation of the union-closed sets conjecture](https://doi.org/10.1016/j.ejc.2014.08.030), EJC 43 (2015), 210–219. Graph formulation and known special classes; in particular the degree-two and subcubic discussions were inspected.
- Henning Bruhn and Oliver Schaudt, [The journey of the union-closed sets conjecture](https://www.uni-ulm.de/fileadmin/website_uni_ulm/mawi.inst.081/Henning/UCSurvey.pdf), Graphs and Combinatorics 31 (2015), 2043–2074. General background.

Targeted web searches included variants of `union closed sets conjecture hypergraph substitution cloning incomplete transversal generators local frequency`, `Frankl union closed sets conjecture hypergraph twins near twins neighborhood replacement maximal independent sets frequency missing edges`, and `uniform maximal independent sets bipartite graph almost twins rare vertex local neighborhood frequency bound`. No precise predecessor for the stated binomial bound and sharpness construction was found. This limited result is NOT a certification of publication priority. It is possible that a related result appears under different terminology, in the inaccessible repository archive, or in unscreened manuscripts. The proof is self-contained; it does not depend on any unpublished universal frequency estimate or the numerical claims in the literature search.
