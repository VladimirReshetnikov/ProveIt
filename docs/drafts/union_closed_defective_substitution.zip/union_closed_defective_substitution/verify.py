#!/usr/bin/env python3
"""Exact finite regression tests, standard library only; assertions required."""
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import combinations, product
from math import comb
from pathlib import Path
import json, random


def subs(mask):
    s=mask
    while True:
        yield s
        if not s: break
        s=(s-1)&mask


def C(n,j): return comb(n,j) if 0<=j<=n else 0


def bad(t,m,k):
    return sum(C(k,h)*sum(C(t-k,j) for j in range(m-h))
               for h in range(1,min(k,m-1)+1))


def Q(t,m,k=1):
    x=1<<(t-k)
    return Fraction(x,x+bad(t,m,k))


def unions(edges):
    out={0}
    for e in edges: out |= {s|e for s in out}
    return out


def line_size(edges,W):
    lines=defaultdict(set)
    for e in edges:
        x=e&W
        if x:
            if x&(x-1): return -1
            lines[e&~W].add(x)
    return min(map(len,lines.values()),default=W.bit_count())


def primal(edges,n):
    stars=[sum(1<<j for j,e in enumerate(edges) if e>>i&1) for i in range(n)]
    return unions(stars),stars


def dual_check(edges,n,fam):
    p,_=primal(edges,n)
    d={sum(1<<j for j,e in enumerate(edges) if e&s!=e) for s in fam}
    assert len(fam)==len(d) and d==p


def block_check(edges,fam,W,m,stats):
    t=W.bit_count(); assert line_size(edges,W)>=m
    fibres=defaultdict(list)
    for s in fam: fibres[s&~W].append(s&W)
    for B,f in fibres.items():
        A=0; demands=[]
        for e in edges:
            if e&W and e&~W&~B==0: A |= e&W
        for i in range(B.bit_length()):
            b=1<<i
            if not B&b: continue
            if any(e&b and not e&W and e&B==e for e in edges): continue
            D=0
            for e in edges:
                if e&b and e&W and e&~W&~B==0: D |= e&W
            assert D.bit_count()>=m
            demands.append(D)
        assert set(f)=={s for s in subs(A) if all(s&d for d in demands)}
        stats['exact_fibre_reconstructions']+=1
        for J in subs(W):
            if J:
                assert Fraction(sum(s&J==J for s in f),len(f))<=Q(t,m,J.bit_count())
                stats['conditional_mark_bounds']+=1
    for J in subs(W):
        if J:
            assert Fraction(sum(s&J==J for s in fam),len(fam))<Q(t,m,J.bit_count())
            stats['strict_unconditional_bounds']+=1


def joint_check(edges,fam,blocks,ms,stats):
    core=sum(blocks); assert core.bit_count()==sum(w.bit_count() for w in blocks)
    fibres=defaultdict(list)
    for s in fam: fibres[s&~core].append(s)
    for marks in product(*(list(subs(W)) for W in blocks)):
        J=sum(marks); bound=Fraction(1)
        if not J: continue
        for W,m,M in zip(blocks,ms,marks):
            if M: bound*=Q(W.bit_count(),m,M.bit_count())
        for f in fibres.values():
            assert Fraction(sum(s&J==J for s in f),len(f))<=bound
            stats['conditional_joint_bounds']+=1
        assert Fraction(sum(s&J==J for s in fam),len(fam))<bound
        stats['strict_joint_bounds']+=1


def hitting_checks(stats):
    for t in range(2,5):
        W=(1<<t)-1
        for m in range(2,t+1):
            possible=[s for s in subs(W) if s.bit_count()>=m]
            extrema={J:Fraction(0) for J in subs(W) if J}
            for code in range(1<<len(possible)):
                ds=[s for j,s in enumerate(possible) if code>>j&1]
                f=[s for s in subs(W) if all(s&d for d in ds)]
                stats['exhaustive_hitting_families']+=1
                for J in extrema:
                    p=Fraction(sum(s&J==J for s in f),len(f))
                    assert p<=Q(t,m,J.bit_count())
                    extrema[J]=max(extrema[J],p)
                    stats['hitting_mark_tests']+=1
            for J,p in extrema.items():
                assert p==Q(t,m,J.bit_count())
                stats['exact_hitting_extrema']+=1
    for t in range(2,21):
        for m in range(2,t+1):
            for k in range(1,t+1):
                if t<=9:
                    J=(1<<k)-1
                    assert bad(t,m,k)==sum(bool(D&J) and D.bit_count()<m for D in range(1<<t))
                    stats['direct_binomial_counts']+=1
                for a in range(max(m,k),t+1):
                    assert Q(a,m,k)<=Q(t,m,k)
                    stats['availability_monotonicity']+=1


def one_block_checks(stats):
    for t,b,m in [(2,2,2),(3,2,2),(3,2,3),(4,1,2),(4,2,3),(4,2,4)]:
        W=(1<<t)-1
        ext=list(range(1<<b)); opts=[0]+[s for s in subs(W) if s.bit_count()>=m]
        for lines in product(opts,repeat=len(ext)):
            be=[(R<<t)|(1<<i) for R,L in zip(ext,lines) for i in range(t) if L>>i&1]
            for code in range(1<<(len(ext)-1)):
                edges=tuple(sorted(be+[R<<t for j,R in enumerate(ext[1:]) if code>>j&1]))
                if not edges: continue
                f=unions(edges); block_check(edges,f,W,m,stats)
                stats['exhaustive_one_block_hypergraphs']+=1
                if stats['exhaustive_one_block_hypergraphs']%31==0:
                    dual_check(edges,t+b,f); stats['independent_primal_duality']+=1


def two_block_checks(stats):
    W1,W2=7,56; singles=[0,3,5,6,7]
    for code in range(1,1<<9):
        E=[(1<<i)|(1<<(j+3)) for i in range(3) for j in range(3) if code>>(3*i+j)&1]
        if min(line_size(E,W1),line_size(E,W2))<2: continue
        for s1,s2 in product(singles,repeat=2):
            edges=tuple(sorted(E+[1<<i for i in range(3) if s1>>i&1]+[1<<(i+3) for i in range(3) if s2>>i&1]))
            f=unions(edges); joint_check(edges,f,(W1,W2),(2,2),stats)
            stats['exhaustive_two_block_hypergraphs']+=1
            if stats['exhaustive_two_block_hypergraphs']%17==0:
                dual_check(edges,6,f); stats['independent_primal_duality']+=1
    rng=random.Random(20261125)
    for _ in range(150):
        edges=[]
        for ext in (0,64):
            while True:
                E=[(1<<i)|(1<<(j+3))|ext for i in range(3) for j in range(3) if rng.randrange(4)]
                if min(line_size(E,W1),line_size(E,W2))>=2: break
            edges.extend(E)
            for W in (W1,W2):
                choices=rng.choice([s for s in subs(W) if s.bit_count()!=1])
                edges.extend((1<<i)|ext for i in range(6) if choices>>i&1)
        if rng.randrange(2): edges.append(64)
        edges=tuple(sorted(set(edges))); f=unions(edges)
        block_check(edges,f,W1,2,stats); block_check(edges,f,W2,2,stats)
        joint_check(edges,f,(W1,W2),(2,2),stats); dual_check(edges,7,f)
        stats['random_exterior_cases']+=1; stats['independent_primal_duality']+=1


def types(t,m,k):
    return [s for s in range(1<<t) if s.bit_count()==m and s&((1<<k)-1)]


def petal_count(S,cs,L,central):
    hits=[S&c for c in cs if S&c]
    if central: return 1<<(L*len(hits))
    ways={0:1}
    for h in hits:
        new=ways.copy()
        for cov,count in ways.items():
            k=cov|h; new[k]=new.get(k,0)+count*((1<<L)-1)
        ways=new
    return ways.get(S,0)


def extremizer(params,L):
    css=[types(*p) for p in params]; total=good=0
    for S in product(*(range(1<<t) for t,m,k in params)):
        weight=1
        for s,cs in zip(S,css): weight*=petal_count(s,cs,L,all(S))
        total+=weight
        if all(s&((1<<k)-1)==(1<<k)-1 for s,(t,m,k) in zip(S,params)): good+=weight
    return total,good


def direct_extremizer(params,L):
    off=0; blocks=[]; edges=[]; J=0
    for t,m,k in params:
        blocks.append(((1<<t)-1)<<off); J|=((1<<k)-1)<<off; off+=t
    for choices in product(*[[1<<j for j in range(off) if W>>j&1] for W in blocks]): edges.append(sum(choices))
    for W,(t,m,k) in zip(blocks,params):
        shift=(W&-W).bit_length()-1
        for c in types(t,m,k):
            for _ in range(L):
                edges.extend((1<<off)|(1<<(shift+j)) for j in range(t) if c>>j&1)
                off+=1
    edges=tuple(sorted(edges)); f=unions(edges); exterior=((1<<off)-1)^sum(blocks)
    fib=[s for s in f if s&exterior==exterior]; bound=Fraction(1)
    for p in params: bound*=Q(*p)
    assert Fraction(sum(s&J==J for s in fib),len(fib))==bound
    return len(f),sum(s&J==J for s in f)


def sharpness_checks(stats):
    for ps in [[(2,2,1)]*2,[(3,2,1)]*2,[(3,2,2),(2,2,1)],[(2,2,1)]*3]:
        assert extremizer(ps,1)==direct_extremizer(ps,1)
        stats['direct_sharpness_constructions']+=1
    rows=[]
    for ps in [[(4,3,1)]*2,[(4,3,1)]*3,[(3,2,1)]*4,[(5,3,1)]*3,[(4,3,2),(3,2,1)]]:
        bound=Fraction(1); M=1
        for t,m,k in ps: bound*=Q(t,m,k); M*=(1<<(t-k))+bad(t,m,k)
        nt=sum(len(types(*p)) for p in ps); P=1<<sum(p[0] for p in ps)
        for L in (1,2,4,8,12):
            total,good=extremizer(ps,L); ratio=Fraction(good,total); eps=Fraction(1,1<<L)
            tv=((M*nt+P-M)*eps)/(M*(1-eps)**nt)
            assert 0<bound-ratio<=tv
            rows.append(dict(parameters=ps,petals_per_type=L,distinct_unions=str(total),marked_absence_count=str(good),
                             absence_probability=str(ratio),limit=str(bound),exact_gap=str(bound-ratio),decimal_gap=float(bound-ratio)))
            stats['weighted_sharpness_checks']+=1
    return rows


def example(stats):
    edges=tuple(sorted((1<<i)|(1<<(4+j))|(1<<(8+k)) for i,j,k in product(range(4),repeat=3) if (i+j+k)%4))
    W=(15,240,3840); assert len(edges)==48 and all(line_size(edges,w)==3 for w in W)
    f=unions(edges); direct=set()
    for s in range(1<<12):
        cov=0
        for e in edges:
            if e&s==e: cov|=e
        if cov==s: direct.add(s)
    assert f==direct
    p,stars=primal(edges,12); dual_check(edges,12,f)
    assert len(set(stars))==12 and all(s.bit_count()==12 for s in stars)
    assert all(not e or e.bit_count()>=12 for e in p)
    assert any((a&b).bit_count()==2 for a,b in combinations(edges,2))
    for i,j in combinations(range(12),2):
        if any(e>>i&1 and e>>j&1 for e in edges): continue
        assert any(e>>i&1 and ((e^(1<<i))|(1<<j)) not in edges for e in edges)
    counts=[sum(bool(s>>i&1) for s in p) for i in range(len(edges))]
    assert all(Fraction(c,len(p))>Fraction(19,27) for c in counts)
    # Single marked edges plus all mark subsets of two of the three blocks.
    joint_check(edges,f,W[:2],(3,3),stats)
    for w in W: block_check(edges,f,w,3,stats)
    return dict(ground_points=len(edges),generators=len(stars),generator_sizes=[s.bit_count() for s in stars],
                support_bitmasks=list(edges),distinct_unions=len(p),frequency_histogram=dict(Counter(map(str,counts))),
                min_frequency=str(Fraction(min(counts),len(p))),guaranteed_strict_lower_bound='19/27')


def table():
    rows=[]
    for t,m in [(2,2),(3,2),(3,3),(4,3),(5,3),(5,4),(6,3),(6,4),(8,5),(10,6),(12,7)]:
        q=Q(t,m); r=1
        while q**r>Fraction(1,2): r+=1
        rows.append(dict(t=t,m=m,d=t-m,q=str(q),minimum_blocks=r,lower_bound_at_minimum=str(1-q**r)))
    return rows


def main():
    stats=Counter(); hitting_checks(stats); one_block_checks(stats); two_block_checks(stats)
    sharp=sharpness_checks(stats); ex=example(stats)
    result=dict(status='PASS',scope='Exact finite checks; general proofs in paper.tex',counts=dict(sorted(stats.items())),
                thresholds=table(),latin_defect_example=ex,sharpness=sharp)
    Path(__file__).with_name('verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print('PASS: all assertions passed')
    for k,v in sorted(stats.items()): print(f'{k}: {v:,}')
    print('Latin-defect example:',{k:v for k,v in ex.items() if k!='support_bitmasks'})
    print('Threshold table:')
    for row in result['thresholds']: print(row)
    print('25 weighted sharpness comparisons; details in verification.json')

if __name__=='__main__': main()
