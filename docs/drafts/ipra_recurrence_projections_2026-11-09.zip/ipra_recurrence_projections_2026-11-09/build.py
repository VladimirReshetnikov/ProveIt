#!/usr/bin/env python3
"""Build the paper and expand its local section inputs; no network access."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent

def flatten(path):
    text = path.read_text(encoding="utf-8")
    def expand(match):
        child = (ROOT / match.group(1)).resolve()
        if not child.is_relative_to(ROOT):
            raise ValueError("section outside package")
        return "\n% BEGIN " + match.group(1) + "\n" + flatten(child) + "\n% END\n"
    return re.sub(r"\\input\{([^}]+)\}", expand, text)

def main():
    compiler = shutil.which("pdflatex")
    if not compiler:
        raise SystemExit("pdflatex is required; no compiler was found")
    (ROOT / "report_standalone.tex").write_text(flatten(ROOT / "report.tex"), encoding="utf-8")
    logs = []
    for _ in range(3):
        run = subprocess.run([compiler, "-no-shell-escape", "-interaction=nonstopmode",
                              "-halt-on-error", "report.tex"], cwd=ROOT,
                             text=True, capture_output=True)
        logs.append(run.stdout + run.stderr)
        if run.returncode:
            (ROOT / "evidence/build.log").write_text("\n".join(logs), encoding="utf-8")
            raise SystemExit("LaTeX compilation failed; see evidence/build.log")
    (ROOT / "evidence/build.log").write_text("\n".join(logs), encoding="utf-8")
    pdf = (ROOT / "report.pdf").read_bytes()
    final_log = (ROOT / "report.log").read_text(encoding="utf-8", errors="replace")
    receipt = {
        "passes": 3, "shell_escape": False, "returncode": 0,
        "pdf_bytes": len(pdf), "pdf_sha256": hashlib.sha256(pdf).hexdigest(),
        "undefined_references": "There were undefined references" in final_log,
        "overfull_boxes": final_log.count("Overfull "),
        "standalone_source_bytes": (ROOT / "report_standalone.tex").stat().st_size,
    }
    (ROOT / "evidence/build.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))
    if receipt["undefined_references"] or receipt["overfull_boxes"]:
        raise SystemExit("Document needs reference/layout review")

if __name__ == "__main__":
    main()
