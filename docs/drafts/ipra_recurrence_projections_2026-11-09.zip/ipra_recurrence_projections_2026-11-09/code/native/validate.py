"""Regression and boundary checks for the two complete native checkers.

This untrusted test driver is not imported by a measured acceptance program.
It executes the five local, inventoried checker sources. It never evaluates
certificate input as Python code.
"""
import ast
import copy
import hashlib
import json
import platform
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROGRAMS = (
    "reference/complete_309.py",
    "reference/lambda_307.py",
    "reference/iterable_306.py",
    "indexed_major.py",
    "padded_major.py",
)
STRICT = tuple(name for name in PROGRAMS if name != "reference/iterable_306.py")


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def trace(name, packet):
    # The final top-level try is the CLI. Retain all definitions and initial
    # state, then supply exactly the same packet-pop interface to the kernel.
    source = ROOT / name
    tree = ast.parse(source.read_text())
    require(isinstance(tree.body[-1], ast.Try), name + ": unexpected CLI shape")
    tree.body.pop()
    namespace = {}
    exec(compile(tree, str(source), "exec"), namespace)
    cells = copy.deepcopy(packet)
    namespace["q"] = cells.pop
    try:
        accepted = bool(namespace["c"](cells.pop(), []))
    except Exception:
        accepted = False
    return accepted, namespace["k"], cells


def cli(name, data, optimized):
    command = [sys.executable]
    if optimized:
        command.append("-O")
    command.append(str(ROOT / name))
    result = subprocess.run(command, input=data, text=True, capture_output=True, timeout=15)
    return {"exit": result.returncode, "stdout": result.stdout, "stderr": result.stderr}


def expected(accept):
    return {"exit": 0 if accept else 1, "stdout": "ACCEPT\n" if accept else "REJECT\n", "stderr": ""}


def main():
    manifest = json.loads((ROOT / "reference_manifest.json").read_text())
    for entry in manifest["files"]:
        data = (ROOT / entry["local_file"]).read_bytes()
        require(hashlib.sha256(data).hexdigest() == entry["sha256"], "Changed reference: " + entry["local_file"])
    fixtures = json.loads((ROOT / "reference/positive_fixtures.json").read_text())["records"]
    positive_receipts = []
    for item in fixtures:
        baseline = trace(PROGRAMS[0], item["packet"])
        require(baseline[0], "Baseline failed positive fixture " + item["id"])
        for name in PROGRAMS[1:]:
            require(trace(name, item["packet"]) == baseline, name + ": trace differs on " + item["id"])
        positive_receipts.append(item["id"])

    public = json.loads((ROOT / "reference/cli_cases.json").read_text())["cases"]
    cli_receipts = []
    for case in public:
        for optimized in (False, True):
            for name in PROGRAMS:
                result = cli(name, case["input_text"], optimized)
                require(result == expected(case["expected_accept"]), name + ": public case " + case["name"])
                cli_receipts.append({"case": case["name"], "program": name, "optimized": optimized, **result})

    # The first attack is the supplied finite 0=S0 counterexample to deleting
    # initial validation. Others test active malformed syntax and the exact
    # rejection of string/object aliases retained by the strict programs.
    bad_packets = {
        "initial_validation_attack": [[0, [0]], [[0, 0, [], [0]], 0], [[], [0]]],
        "bare_contradiction": [[0, 0], [[], [0]]],
        "active_empty_string_counter": [[0, 0], [["", 0, 0], 0]],
        "active_empty_object_counter": [[0, 0], [[{}, 0, 0], 0]],
        "active_empty_key_object_counter": [[0, 0], [[{"": 0}, 0, 0], 0]],
        "active_nonempty_string_counter": [[0, 0], [["x", 0, 0], 0]],
        "active_two_character_counter": [[0, 0], [["xy", 0, 0], 0]],
        "active_three_character_counter": [[0, 0], [["xyz", 0, 0], 0]],
        "overlong_iterator_node": [[0, 0], [[0, 0, 0, 0], 0]],
        "overlong_goal_node": [[0, 0], [0, 0, 0, 0]],
        "unbound_future_parameter": [[0, 0], [[0, -1, 0], -1]],
        "null_syntax": [[0, 0], [[0, None, 0], None]],
        "invalid_instruction_arity": [[0, 0, 0], [[0, 0, 0], 0]],
        "invalid_singleton_instruction": [[0], [[0, 0, 0], 0]],
    }
    malformed_text = {
        "truncated_json": "[[0,0]",
        "trailing_nonwhitespace": "[] junk",
        "scalar_root": "0",
        "string_root": '"packet"',
        "object_root": '{}',
    }
    controls = {**{name: json.dumps(packet) for name, packet in bad_packets.items()}, **malformed_text}
    boundary_receipts = []
    for case, data in controls.items():
        for optimized in (False, True):
            for name in STRICT:
                result = cli(name, data, optimized)
                require(result == expected(False), name + ": unexpectedly accepted " + case)
                boundary_receipts.append({"case": case, "program": name, "optimized": optimized, **result})

    # An unread prefix is deliberately inert in the inherited public format;
    # malformed-looking but unused annotations are not rejected by fiat.
    inert_prefix = [{"annotation": ["unused", None]}, [0, 0], [[0, 0, 0], 0]]
    inert_receipts = []
    for optimized in (False, True):
        for name in STRICT:
            result = cli(name, json.dumps(inert_prefix), optimized)
            require(result == expected(True), name + ": changed inert-prefix behavior")
            inert_receipts.append({"program": name, "optimized": optimized, **result})

    result = {
        "python": platform.python_version(),
        "reference_files_verified": len(manifest["files"]),
        "positive_fixtures": len(fixtures),
        "positive_trace_comparisons": len(fixtures) * (len(PROGRAMS) - 1),
        "public_cli_cases": len(public),
        "public_cli_runs": len(cli_receipts),
        "additional_rejection_cases": len(controls),
        "additional_rejection_runs": len(boundary_receipts),
        "inert_prefix_runs": len(inert_receipts),
        "failures": 0,
        "scope": "Finite evidence; the all-input equivalence and idealized termination arguments are in README.txt.",
        "public_receipts": cli_receipts,
        "boundary_receipts": boundary_receipts,
        "inert_prefix_receipts": inert_receipts,
    }
    (ROOT / "validation.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if not k.endswith("receipts")}, indent=2))


if __name__ == "__main__":
    main()
