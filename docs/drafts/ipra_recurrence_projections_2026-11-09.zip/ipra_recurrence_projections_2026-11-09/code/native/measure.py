"""Measure complete checker sources with the unchanged inherited normalizer."""
import importlib.util
import json
import platform
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCES = (
    "reference/complete_309.py",
    "reference/lambda_307.py",
    "reference/iterable_306.py",
    "indexed_major.py",
    "padded_major.py",
)


def main():
    spec = importlib.util.spec_from_file_location(
        "inherited_measure", ROOT / "reference/source_measure.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    rows = [{"file": name, **module.metrics(ROOT / name)} for name in SOURCES]
    result = {
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "scope": "Whole module; only comments and genuine docstrings are excluded.",
        "rows": rows,
    }
    (ROOT / "measurements.json").write_text(json.dumps(result, indent=2) + "\n")
    for row in rows:
        print(row["file"], row["normalized_tokens"], row["ast_nodes"], row["normalized_bytes"])


if __name__ == "__main__":
    main()
