TWO EXACT REFACTORINGS OF THE INHERITED COMPLETE NATIVE CHECKER
9 November 2026

Status and scope
----------------
These are small implementation results for the EXISTING native iPRA
certificate calculus. They do not implement the new recurrence theorem in
the accompanying research report, change the arithmetic axiomatization, or
constitute the requested major mathematical breakthrough. They preserve
the strict array/numeric input behavior of the supplied complete checker.

Neither new source beats every coordinate of the CURRENT draft frontier.
The new indexed-major source improves the normalized token count; the new
padded-major source improves literal normalized bytes. Their other costs
increase. These are implementation tradeoffs, not global minimality claims.

All measured programs contain their entire acceptance algorithm, imports,
JSON parsing, scope traversal, rule dispatch, rejection, printed verdicts,
and exit status. They import no local project file, theorem library,
compressed executable payload, proof producer, or numerical oracle. The
supporting measurement and validation programs are outside the trusted
acceptance code and are not imported by it.

Results under CPython 3.12.14
----------------------------
Whole normalized module, with only comments and genuine docstrings removed:

Source                             Tokens    AST nodes    Bytes
reference/complete_309.py             309        344        864
reference/lambda_307.py               307        347        839
reference/iterable_306.py             306        340        859
indexed_major.py                     305        345        860
padded_major.py                      311        352        820

The inspected current coordinate minima before these two changes are
306 tokens / 340 AST nodes / 839 bytes, attained by different sources.
indexed_major.py improves tokens by one. padded_major.py improves literal
bytes by nineteen. The strict original-array comparator frontier also has
a 308-token / 341-node / 894-byte source in the current repository; it is
documented in the main audit but not needed to reproduce either change.

The inherited byte metric does not normalize identifiers. The previously
supplied uniform interface-renaming control for compact_open.py measures
816 bytes. The new 820-byte source therefore does not improve that control.
The exact current measurements are implementation upper bounds and observed
finite-corpus minima, not mathematical lower-bound theorems.

The source reference/iterable_306.py has a different, explicitly enlarged
input syntax. At traversed syntax positions it admits certain empty-string
and object aliases. Nonempty strings reject through CPython's recursion
guard; an unrestricted-stack idealization can diverge on them. The two new
sources retain the strict array guard and do not inherit this qualification.

Run a checker
-------------
  python3 indexed_major.py < certificate.json
  python3 padded_major.py < certificate.json

The public input is one JSON array. The last element is the closed goal;
preceding elements are consumed from the end as proof instructions. An
unread prefix is inert, as in the inherited interface. On acceptance the
program prints ACCEPT and exits 0. On rejection it prints REJECT and exits
1. Whitespace, including multiline JSON input, is handled unchanged.

Reproduce all delivered evidence
--------------------------------
  python3 measure.py
  python3 validate.py

Only the Python standard library is needed. Exact AST/unparse measurements
use CPython 3.12.14. Validation does not use the network. The programs write
measurements.json and validation.json alongside this README.

What changed: indexed-major source
---------------------------------
Start from the supplied strict-array lambda_307.py. Its initial substitution
traversal validates every checked goal. Consequently an active successful
major premise is either a validated scalar or an array of at most three
entries. An array of length one is conditional closure, length two is an
equation, and length three is the paired binder.

The previous block was:

    if [] in (h := [0, m[2:]]):
        ... handle one or two entries ...

The new block is:

    try:
        h = [0, [m[2]]]
    except:
        ... the same one-or-two-entry handling ...

For an array of length three, index 2 exists and [0,[m[2]]] is exactly
[0,m[2:]]. For lengths one and two, that access fails without changing any
local needed by the unchanged closure/equality block. The same singleton
or pair unpacking then supplies the same source, image and motive. A scalar
major cannot provide either an indexed entry or a successful singleton/pair
unpack; both old and new programs reject that route. Active strings, maps,
null values and overlong arrays fail the unchanged strict syntax traversal
before they could exploit the new dispatcher.

No recursive checking call, scope floor, proof-cell consumption, hypothesis
context, numerical substitution or public protocol changes. Induction on
the ordinary finite evaluation trace gives the same verdict and final
state on every parsed JSON input. This statement abstracts from asynchronous
interruption, injected memory failures, tracing hooks and differences in
temporary exception allocation. Such resource equivalence is not claimed.

What changed: padded-major source
--------------------------------
This also starts from lambda_307.py. Replace the entire active-major
dispatcher by:

    try:
        s, u, t = m + [t] if m[1:] else [0, t] + m
    except:
        h = [0, m[2:]]
    else:
        return i(t, u) == a and c(i(t, s), g)

The checking function no longer needs its default parameter s=0, because
every route which uses s now assigns it in the successful triple unpack.
All calls already supplied exactly the first two function arguments.

Let t0 denote the incoming witness/motive field. There are three cases:

  Major [B]        produces [0,t0,B], assigning (s,u,t)=(0,t0,B).
  Major [s0,u0]    produces [s0,u0,t0], assigning (s,u,t)=(s0,u0,t0).
  Major [P,U,B]    produces a four-entry list, whose triple unpack fails.

The first two triples are exactly the old closure and equation branches.
In the third case Python completes the right-hand expression and detects
the unpacking failure before assigning any of the three targets. The
handler therefore constructs the identical old paired-binder context.
Validated scalar majors fail slicing here and in the old block; their
handler also fails slicing, so they cannot become accepted paired majors.
All other malformed active kinds were excluded by initial syntax traversal.

Again no recursive calls, freshness updates, contexts or consumed proof
cells change on a successful or ordinarily rejecting path. The same trace
induction proves all-input verdict/state equivalence, with the same resource
qualification as above. There is no interpretation change or theorem oracle.

Why the inherited lambda validator is equivalent
------------------------------------------------
The 309-token source attempts traversal through a+[] and falls back to
numeric handling on an exception. On values produced by the standard JSON
decoder, that traversal succeeds only for arrays. A failed child traversal
cannot convert its surrounding array into a valid numerical scalar: its
subsequent numeric comparison also raises an exception. The supplied lambda
variant uses an explicit isinstance(a,list) test instead, retaining the
same numerical fallback for all other values. Since traversal has no side
effects on the proof stack or freshness floor, the success values and final
public rejection behavior agree. This inherited change is credited rather
than claimed as a new result.

Totality and metatheory
----------------------
For finite parsed JSON values, the strict validator traverses only proper
array subtrees. Strings and objects are never traversed by characters or
keys. Every non-hypothesis checking call consumes a proof cell before its
recursive checking calls. An inserted numerical image is checked with no
further image; a used missing image rejects. The code constructs no cyclic
objects. These facts give idealized termination on arbitrary finite parsed
JSON. Actual recursion and memory limits may reject sufficiently large valid
proofs, as for the inherited checker; completeness is the usual adequate-
finite-resource claim for arbitrary finite canonical certificates.

Because accepted packets and their decoding are unchanged, both new sources
check exactly the inherited native calculus. Its full iPRA interpretation
and bi-interpretability proof are inherited, not newly formalized here.
The reference/native_basis.tex and reference/native_decoding.tex files are
unchanged attributed extracts explaining that calculus and its sorted
decoding. They use unshifted scalar iteration with passive parameters,
native equations, conditional closure and the paired binder. They are
distinct from the new recurrence presentation in the main research report.

Verification scope
------------------
The test driver compares all 147 inherited positive packets against the
309-token reference, including verdict, final freshness floor and remaining
proof stack. It checks the 13 inherited public CLI cases in ordinary and
optimized Python for all five supplied programs. It additionally tests the
known three-cell 0=S0 attack on deleted initial validation, active malformed
strings/objects, future parameters, malformed iterator and instruction
arities, malformed JSON, and inert unused-prefix behavior. The exact counts
and every CLI result are in validation.json.

These finite checks support the source-equivalence arguments above; they
are not a formal proof of Python, a Lean/Rocq formalization, or a new proof
of the underlying arithmetic compiler. No unvalidated semantic-extension
experiment is included in this directory.

Source and attribution
----------------------
Repository: https://github.com/VladimirReshetnikov/ProveIt
Pinned commit: 572c3ef372fb22e30951af30bf1041efcffc8b7d

The three reference executables, measurement utility, 147 fixtures,
13 CLI cases, and native-calculus extracts are copied unchanged from the
current archives. reference_manifest.json records their exact original
extracted paths, lengths and SHA-256 identities. The numerical/logical
theory and lambda guard are inherited. The two arity dispatch changes,
their source-equivalence arguments and this validation driver are the
present small implementation contributions. The original license is
retained in LICENSE-inherited.txt. Nothing was submitted to the repository.
