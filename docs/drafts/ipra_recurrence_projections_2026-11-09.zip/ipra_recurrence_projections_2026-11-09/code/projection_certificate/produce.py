#!/usr/bin/env python3
"""Produce an explicit certificate; this file is not used by the replayer."""

import json
from pathlib import Path


def V(name):
    return ("v", name)


def T(head, *children):
    return (head, *children)


Z = ("0",)


def R(n, a):
    return T("L", n, T("A", n, a))


def replace(value, assignments):
    if value[0] == "v":
        return assignments.get(value[1], value)
    return (value[0], *(replace(child, assignments) for child in value[1:]))


class Producer:
    def __init__(self):
        self.nodes = []
        self.equations = []
        self.reflexive = {}

    def add(self, rule, equation, **arguments):
        self.nodes.append({"rule": rule, **arguments, "conclusion": equation})
        self.equations.append(equation)
        return len(self.nodes) - 1

    def ax(self, name, **arguments):
        a = arguments["a"]
        if name == "L_zero":
            equation = (T("L", Z, a), a)
        elif name == "A_zero":
            equation = (T("A", Z, a), a)
        elif name == "L_successor":
            n = arguments["n"]
            equation = (T("L", T("S", n), a), T("h", T("L", n, a)))
        elif name == "A_successor":
            n = arguments["n"]
            equation = (T("A", T("S", n), a), T("j", T("A", n, a)))
        elif name == "section":
            equation = (T("h", T("j", a)), a)
        else:
            raise ValueError(name)
        return self.add("axiom", equation, name=name, substitution=arguments)

    def refl(self, value):
        if value not in self.reflexive:
            self.reflexive[value] = self.add("reflexivity", (value, value), term=value)
        return self.reflexive[value]

    def sym(self, reference):
        left, right = self.equations[reference]
        return self.add("symmetry", (right, left), premise=reference)

    def chain(self, *references, label=None):
        result = references[0]
        for reference in references[1:]:
            left, middle = self.equations[result]
            other, right = self.equations[reference]
            if middle != other:
                raise ValueError("producer constructed a discontinuous equality chain")
            result = self.add("transitivity", (left, right), first=result, second=reference)
        if label:
            self.nodes[result]["label"] = label
        return result

    def cong(self, head, *references):
        equations = [self.equations[ref] for ref in references]
        equation = (T(head, *(eq[0] for eq in equations)),
                    T(head, *(eq[1] for eq in equations)))
        return self.add("congruence", equation, head=head, premises=list(references))

    def inst(self, reference, **assignments):
        left, right = self.equations[reference]
        return self.add("instantiation", (replace(left, assignments), replace(right, assignments)),
                        premise=reference, substitution=assignments)

    def unique(self, template, step, target, label=None):
        equation = (replace(template, {"x": target}),
                    T("L", target, replace(template, {"x": Z})))
        result = self.add("uniqueness", equation, premise=step, placeholder="x",
                          eigenvariable="z", template=template, target=target)
        if label:
            self.nodes[result]["label"] = label
        return result


def produce():
    p = Producer()
    n, a, z, x, t = (V(name) for name in ("n", "a", "z", "x", "t"))

    # Rotation: h(L(n,a)) and L(n,h(a)) are trajectories with the same base.
    rotation_template = T("h", T("L", x, a))
    rotation_step = p.cong("h", p.ax("L_successor", n=z, a=a))
    rotation_unique = p.unique(rotation_template, rotation_step, n, "U_h for rotation")
    rotation_base = p.cong("h", p.ax("L_zero", a=a))
    rotation_base_lift = p.cong("L", p.refl(n), rotation_base)
    rotation = p.sym(p.chain(rotation_unique, rotation_base_lift))
    p.nodes[rotation]["label"] = "L(n,h(a)) = h(L(n,a))"

    # R_0(a)=a by two base computations.
    r_zero = p.chain(p.ax("L_zero", a=T("A", Z, a)),
                     p.ax("A_zero", a=a), label="R_0(a) = a")

    # R_(Sn)(a)=R_n(a), using rotation and the explicit right inverse j.
    as_eq = p.ax("A_successor", n=n, a=a)
    rs1 = p.cong("L", p.refl(T("S", n)), as_eq)
    rs2 = p.ax("L_successor", n=n, a=T("j", T("A", n, a)))
    rs3 = p.sym(p.inst(rotation, a=T("j", T("A", n, a))))
    rs4 = p.cong("L", p.refl(n), p.ax("section", a=T("A", n, a)))
    r_stationary = p.chain(rs1, rs2, rs3, rs4, label="R_(Sn)(a) = R_n(a)")
    rz_stationary = p.inst(r_stationary, n=z)

    # Strong observation identity: L_t F R_t = L_t F.
    invariant_template = T("L", x, T("F", R(x, a)))
    inv1 = p.cong("L", p.refl(T("S", z)), p.cong("F", rz_stationary))
    inv2 = p.ax("L_successor", n=z, a=T("F", R(z, a)))
    inv_step = p.chain(inv1, inv2, label="recurrence for L(n,F(R_n(a)))")
    inv_unique = p.unique(invariant_template, inv_step, t, "U_h for contextual invariance")
    inv_base = p.chain(p.ax("L_zero", a=T("F", R(Z, a))),
                       p.cong("F", r_zero))
    invariant = p.chain(inv_unique, p.cong("L", p.refl(t), inv_base),
                        label="L_t(F(R_t(a))) = L_t(F(a))")

    # Separate derivation: no rule for substituting a term context for F is trusted.
    absorb_template = T("L", x, T("A", t, T("F", R(x, a))))
    abs_inner = p.cong("A", p.refl(t), p.cong("F", rz_stationary))
    abs1 = p.cong("L", p.refl(T("S", z)), abs_inner)
    abs2 = p.ax("L_successor", n=z, a=T("A", t, T("F", R(z, a))))
    abs_step = p.chain(abs1, abs2, label="recurrence for L(n,A(t,F(R_n(a))))")
    abs_unique = p.unique(absorb_template, abs_step, t, "U_h for contextual absorption")
    abs_base = p.chain(p.ax("L_zero", a=T("A", t, T("F", R(Z, a)))),
                       p.cong("A", p.refl(t), p.cong("F", r_zero)))
    absorption = p.chain(abs_unique, p.cong("L", p.refl(t), abs_base),
                         label="R_t(F(R_t(a))) = R_t(F(a))")

    # Separate idempotence derivation, without an F-to-identity conversion rule.
    idem_template = T("L", x, T("A", t, R(x, a)))
    idem_inner = p.cong("A", p.refl(t), rz_stationary)
    idem1 = p.cong("L", p.refl(T("S", z)), idem_inner)
    idem2 = p.ax("L_successor", n=z, a=T("A", t, R(z, a)))
    idem_step = p.chain(idem1, idem2, label="recurrence for L(n,A(t,R_n(a)))")
    idem_unique = p.unique(idem_template, idem_step, t, "U_h for idempotence")
    idem_base = p.chain(p.ax("L_zero", a=T("A", t, R(Z, a))),
                        p.cong("A", p.refl(t), r_zero))
    idempotence = p.chain(idem_unique, p.cong("L", p.refl(t), idem_base),
                          label="R_t(R_t(a)) = R_t(a)")

    return {"format": "iterator-equations-v1", "nodes": p.nodes,
            "claims": {"rotation": rotation, "R_zero": r_zero,
                       "R_stationary": r_stationary, "context_invariance": invariant,
                       "context_absorption": absorption, "idempotence": idempotence}}


if __name__ == "__main__":
    destination = Path(__file__).with_name("projection_certificate.json")
    destination.write_text(json.dumps(produce(), indent=2) + "\n")
    print(destination.name)
