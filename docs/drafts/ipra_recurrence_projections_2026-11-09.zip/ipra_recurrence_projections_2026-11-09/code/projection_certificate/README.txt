SYMBOLIC CERTIFICATE FOR THE ITERATOR PROJECTION THEOREM
======================================================

Status and scope
----------------
This is an executable, independently replayable certificate for six
universal equations in a specified equational fragment. It is NOT a
complete proof checker for iPRA, and it is NOT a competitor in the
repository's complete-checker size comparison. It does not mechanize the
model-theoretic congruence characterization, the quotient model claims,
the W zero-test lemmas, or full bi-interpretability.

The replayer uses only Python's standard library. It does not import or
run the proof producer. It has no induction, reflection, normalization,
evaluation, model-checking, or general arithmetic oracle.

Files
-----
produce.py                    untrusted certificate generator
projection_certificate.json   explicit 58-node certificate
replay.py                     standalone scoped verifier
test_certificate.py           adversarial boundary tests of the verifier
validation_results.json       results of the bundled test run

Run from any working directory:

  python3 /absolute/path/to/replay.py /absolute/path/to/projection_certificate.json
  python3 /absolute/path/to/test_certificate.py

To regenerate the proof file, run produce.py. The output is deterministic.
Generation is not required for replay.

Numerical syntax and semantics
------------------------------
Terms are binder-free first-order trees. A variable is ["v", "name"].
The only other heads are 0 (arity zero), S,h,j,F (arity one), and L,A
(arity two). All are fixed function symbols. The symbol F represents an
arbitrary fixed unary numerical context in the handwritten schematic
theorem; it is not an object-level variable ranging over functions.

The explicit certificate works in the signature extended by this fixed
symbol F, with the uniqueness rule available for its displayed finite
templates. Replacing F by an admitted fixed source term context yields
the intended source instance after fresh renaming of eigenvariables and
holding its additional parameters passive. That external schematic
substitution argument is written mathematics, not an uncounted rule in
this replayer. Absorption and idempotence are generated separately, so
the verifier does not trust any function-context substitution operation.

The five trusted axiom schemas, instantiated only by variable-to-term
substitution, are exactly:

  L(0,a)   = a
  L(Sn,a)  = h(L(n,a))
  A(0,a)   = a
  A(Sn,a)  = j(A(n,a))
  h(j(a))  = a

No left-inverse equation j(h(a))=a is assumed.

The equality rules are reflexivity, symmetry, transitivity, congruence
for the listed fixed heads, and simultaneous variable substitution in a
previous universal equation. Substitution is one-pass: an inserted term
is not subsequently rewritten by another entry of the same mapping.

The one additional rule is U_h in EMPTY retained context:

  f(Sz) = h(f(z))
  ----------------------------
  f(t)  = L(t,f(0)).

A node explicitly specifies the single template f(x), its placeholder x,
the eigenvariable z, its target t, and the earlier recurrence proof.
The replayer checks the exact syntactic recurrence. It also checks that
z is different from x and absent from the template's passive data and
the target. Empty contexts are mandatory in this fragment, so there are
no hidden retained assumptions. An arbitrary first-order context is not
accepted or implemented.

Every node includes an asserted conclusion. The replayer independently
computes the conclusion and rejects a mismatch. Premise references must
be integer indices of earlier nodes. The six advertised final equations
are fixed in the verifier, so redirecting a claim to an irrelevant valid
equation is rejected.

The advertised equations
------------------------
Let R_n(a) abbreviate L(n,A(n,a)); this abbreviation is fully expanded in
the certificate. The six claims are:

  L(n,h(a))             = h(L(n,a))
  R_0(a)                = a
  R_(Sn)(a)             = R_n(a)
  L(t,F(R_t(a)))        = L(t,F(a))
  R_t(F(R_t(a)))        = R_t(F(a))
  R_t(R_t(a))           = R_t(a).

All variables in each node's equation are universally quantified.
Four U_h applications are explicit: rotation, context invariance,
context absorption, and idempotence. All base simplifications and the
use of h(j(a))=a are separate equality nodes.

Verification boundary
---------------------
Each accepted equality rule preserves universal validity in any algebra.
Each accepted U_h instance is exactly an instance of the stated assumed
rule. Induction on the finite node list therefore gives the elementary
soundness argument for replay. This argument and the implementation have
not been verified in Lean or Rocq. Passing the corruption tests is
evidence about the specified rejection paths, not a formal proof of
the verifier or a proof that an arbitrary source theory is consistent.

The tests include changes to the U_h step, template, target, eigenvariable,
placeholder, passive parameters, axiom orientation, term arity, premise
ordering, and theorem references. They also reject an added semantic
oracle field and an invented induction axiom. The public CLI is checked
to return exit 0 for ACCEPT and exit 1 for REJECT.
