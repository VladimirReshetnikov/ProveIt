#!/usr/bin/env python3
"""Reproduce the delivered symbolic and executable evidence offline."""
from pathlib import Path
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def run(relative, script):
    directory = ROOT / relative
    result = subprocess.run([sys.executable, script], cwd=directory,
                            capture_output=True, text=True)
    receipt = {"directory": relative, "script": script,
               "returncode": result.returncode, "stdout": result.stdout,
               "stderr": result.stderr}
    if result.returncode:
        print(json.dumps(receipt, indent=2))
        raise SystemExit(result.returncode)
    return receipt

def main():
    receipts = []
    for directory, script in [
        ("code/projection_certificate", "produce.py"),
        ("code/projection_certificate", "test_certificate.py"),
        ("code/native", "measure.py"),
        ("code/native", "validate.py"),
    ]:
        receipts.append(run(directory, script))
    result = {"python": sys.version, "all_commands_passed": True,
              "commands": receipts}
    (ROOT / "evidence/reproduction.json").write_text(json.dumps(result, indent=2) + "\n")
    summary = {
        "python": sys.version,
        "projection_certificate": json.loads((ROOT / "code/projection_certificate/validation_results.json").read_text()),
        "native_checkers": json.loads((ROOT / "code/native/validation.json").read_text()),
        "measurements": json.loads((ROOT / "code/native/measurements.json").read_text()),
        "scope": "Symbolic fragment and native code regressions; not a Lean/Rocq formalization of full bi-interpretability."
    }
    (ROOT / "evidence/validation_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print("All four reproduction commands passed; evidence/validation_summary.json updated.")

if __name__ == "__main__":
    main()
