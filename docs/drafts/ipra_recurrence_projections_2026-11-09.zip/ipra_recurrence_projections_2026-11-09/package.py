#!/usr/bin/env python3
"""Create a deterministic ZIP and verify every SHA-256 payload entry."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {".aux", ".toc", ".out", ".pyc", ".synctex.gz"}


def payload():
    result = []
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT)
        if any(part.startswith(".") or part == "__pycache__" for part in rel.parts):
            continue
        if path.suffix in EXCLUDED_SUFFIXES:
            continue
        if len(rel.parts) == 1 and (path.suffix == ".log" or path.name in {
            "MANIFEST.json", "report_standalone.pdf"
        }):
            continue
        result.append((path, rel.as_posix()))
    return result


def main():
    files = payload()
    rows = []
    for path, relative in files:
        body = path.read_bytes()
        rows.append({"path": relative, "bytes": len(body),
                     "sha256": hashlib.sha256(body).hexdigest()})
    manifest = {
        "format": "sha256-payload-v1",
        "scope": "All distributed payload files, excluding this manifest itself.",
        "repository_commit": "572c3ef372fb22e30951af30bf1041efcffc8b7d",
        "file_count": len(rows), "files": rows,
    }
    manifest_path = ROOT / "MANIFEST.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    files.append((manifest_path, "MANIFEST.json"))
    archive_path = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path, relative in sorted(files, key=lambda pair: pair[1]):
            entry = zipfile.ZipInfo(ROOT.name + "/" + relative,
                                    date_time=(2026, 11, 9, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED,
                             compresslevel=9)
    with zipfile.ZipFile(archive_path) as archive:
        if archive.testzip() is not None:
            raise SystemExit("ZIP CRC verification failed")
        if len(archive.namelist()) != len(files):
            raise SystemExit("ZIP file-count mismatch")
        for row in rows:
            body = archive.read(ROOT.name + "/" + row["path"])
            if len(body) != row["bytes"] or hashlib.sha256(body).hexdigest() != row["sha256"]:
                raise SystemExit("Manifest mismatch: " + row["path"])
    body = archive_path.read_bytes()
    receipt = {"archive": str(archive_path), "files": len(files), "bytes": len(body),
               "sha256": hashlib.sha256(body).hexdigest(),
               "crc_verified": True, "all_payload_hashes_verified": True}
    receipt_path = ROOT.parent / (ROOT.name + "_archive_receipt.json")
    receipt_path.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
