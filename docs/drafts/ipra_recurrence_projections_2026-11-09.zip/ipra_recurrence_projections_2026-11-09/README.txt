RECURRENCE PROJECTIONS AND THE iPRA AXIOMATIZATION FRONTIER
9 November 2026

START WITH report.pdf.

STATUS
======
The requested new complete axiomatization strictly below all current
proof-checker complexity minima has NOT been obtained. This package
reports a proved mathematical result and two modest checker refinements,
with the unmet requirement stated explicitly.

NEW MATHEMATICAL RESULT
=======================
Retain full fixed-description primitive-recursive equations, intuitionistic
equality logic, and a fixed recurrence uniqueness rule U_h. Suppose a fixed
term j satisfies h(j(a))=a. Write L=I_h, A=I_j and R_t(a)=L(t,A(t,a)).
Without induction, the source theory proves, for every fixed term context F,

  L_t F R_t = L_t F,       R_t F R_t = R_t F.

Consequently R_t is idempotent and ker(R_t) is exactly the largest algebra
congruence contained in ker(L_t). It has the explicit first-order definition
R_t(a)=R_t(b). Fixed finite compositions form a left regular band; their
kernels are the joins of the factor kernels. General syntactic-congruence
existence is standard; the explicit recurrence formula and U_h proof are
the contribution relative to the inspected corpus.

For the bouncing predecessor W(0)=1, W(Sa)=a, every standard numeral has
a singleton R_t fibre, and every term observation with a source-proved
range in a fixed finite set of standard numerals is unchanged by R_t.
These results do NOT prove R_t(a)=a on the entire
domain. Nor is a nontrivial projection asserted to exist in a full T_W model.
The induced algebra quotient preserves defining equations and boundary
axioms; preservation of contextual U_W remains a separate obligation.

COMPLETE REFERENCE AXIOMATIZATION
================================
The paper includes an inherited, fully explicit iPRA-equivalent native
presentation in the full PR language: Eq/D formulas, local clauses, every
computation schema, Use/DI/DE/transport, the derived intuitionistic logical
macros, and both whole-domain interpretation composites. Its arithmetic
completion proof is supplied in an attributed appendix. It is a complete
reference basis, not a newly smaller construction.

CHECKER RESULTS
===============
Current complete-source coordinate minima at the frozen commit:
  306 normalized tokens / 340 AST nodes / 839 normalized bytes.
The coordinates are attained by different programs.

  code/native/indexed_major.py: 305 / 345 / 860
  code/native/padded_major.py:  311 / 352 / 820

Both are total strict-array refinements of the existing native scalar
checker and preserve its complete public interface. Neither beats all
current coordinates. They do not implement the new projection theorem.
The previous identifier-renaming control reaches 816 bytes, so the
820-byte result is a literal-source improvement, not a naming-invariant one.

EVIDENCE AND REPRODUCTION
========================
  python3 reproduce.py
  python3 build.py
  python3 package.py

The first uses the Python standard library and no network. It verifies
the scoped symbolic projection certificate, its corruptions, native
checker regressions, and whole-source measurements. The second compiles
the paper with pdfLaTeX and shell escape disabled, and regenerates the
single-file report_standalone.tex. Exact metrics use CPython 3.12.14.
The third writes the SHA-256 payload manifest, creates a deterministic ZIP,
and verifies the archive CRCs and every manifested payload hash.

The symbolic projection certificate checks six universal equations in
58 proof nodes, including four U_h instances, from precisely the listed
iterator equations and equality rules. It is not a full iPRA verifier or
a Lean/Rocq formalization. Its complete trust boundary is in the local README.
The exact executed validation results are in evidence/validation_summary.json.

FILES
=====
report.pdf                    Compiled main research paper.
report.tex                    Editable main source with section inputs.
report_standalone.tex          Entire paper in one compilable LaTeX file.
sections/                     New theorem, inherited native basis, audit lemma.
reference/arithmetic_rotation.tex
                              Attributed inherited full arithmetic bridge.
reference/native_decoder.tex   Inherited raw-checker decoding and metatheory.
code/projection_certificate/   Independent producer, replayer, certificate,
                              and rejection controls for the new core theorem.
code/native/                  Two complete changed checkers, frozen sources,
                              fixtures, validation, and measurement utility.
evidence/                     Pinned source identities and actual receipts.
ATTRIBUTION.txt                Exact contribution/provenance boundary.
MANIFEST.json                 SHA-256 payload manifest.

SOURCE SNAPSHOT
===============
VladimirReshetnikov/ProveIt, commit
  572c3ef372fb22e30951af30bf1041efcffc8b7d
https://github.com/VladimirReshetnikov/ProveIt/tree/572c3ef372fb22e30951af30bf1041efcffc8b7d/docs/drafts

All twelve current archives were downloaded and verified against their
Git blob identities. No repository changes were made. See ATTRIBUTION.txt
for the precise prior results and source members retained in this package.
