"""Build a reproducible ZIP and SHA-256 manifest for this deliverable."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent


def included(path):
    parts = path.relative_to(ROOT).parts
    return (path.is_file() and '__pycache__' not in parts
            and not (parts[:2] == ('results', 'latex'))
            and path.suffix != '.pyc' and path.name != 'SHA256SUMS')


def main():
    files = sorted(p for p in ROOT.rglob('*') if included(p))
    if not (ROOT / 'report.pdf').is_file():
        raise SystemExit('Build report.pdf before packaging.')
    rows = [hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.relative_to(ROOT).as_posix()
            for p in files]
    manifest = ROOT / 'SHA256SUMS'
    manifest.write_text('\n'.join(rows) + '\n')
    files.append(manifest)
    target = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(files):
            name = ROOT.name + '/' + path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(target) as archive:
        if archive.testzip() is not None:
            raise SystemExit('ZIP integrity test failed.')
        for line in rows:
            digest, rel = line.split('  ', 1)
            actual = hashlib.sha256(archive.read(ROOT.name + '/' + rel)).hexdigest()
            if actual != digest:
                raise SystemExit('Archive hash mismatch: ' + rel)
    print(target)
    print(f'{len(files)} files; {target.stat().st_size} bytes')
    print('SHA-256: ' + hashlib.sha256(target.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
