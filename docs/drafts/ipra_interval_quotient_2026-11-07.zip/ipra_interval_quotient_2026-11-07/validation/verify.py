"""Offline, independent checks of the two array-first acceptance kernels.

Validation code is deliberately outside the measured trusted programs.
Finite checks supplement, and cannot replace, the soundness argument.
"""
import ast
import copy
import json
import math
from pathlib import Path
import random
import subprocess
import sys
import types

from semantic_oracle import Oracle
from source_measure import metrics

ROOT = Path(__file__).resolve().parent


def require(condition, *details):
    if not condition:
        raise AssertionError(details)


def load(path, replacements=()):
    source = path.read_text()
    for old, new in replacements:
        require(source.count(old) == 1, 'mutation target', old)
        source = source.replace(old, new)
    tree = ast.parse(source)
    # The public driver is tested separately in subprocesses.  Loading the
    # definitions avoids serializing every differential-oracle test.
    tree.body = tree.body[:next(i for i, n in enumerate(tree.body)
                               if isinstance(n, ast.Try))]
    module = types.ModuleType('acceptance_kernel')
    exec(compile(tree, str(path), 'exec'), module.__dict__)
    return module


def run(module, packet):
    module.k = 0
    stack = copy.deepcopy(packet)
    try:
        module.take = stack.pop
        accepted = bool(module.check(stack.pop(), []))
        return accepted, module.k, len(stack)
    except Exception:
        return False, module.k, None


def paths(tree, prefix=()):
    yield prefix
    if type(tree) is list:
        for i, child in enumerate(tree):
            yield from paths(child, (*prefix, i))


def replace_at(tree, path, value):
    if not path:
        return value
    result = copy.deepcopy(tree)
    parent = result
    for index in path[:-1]:
        parent = parent[index]
    parent[path[-1]] = value
    return result


def attacks():
    # Adapted from the truth-completion draft's opening_checks.py.
    truth = [0, 0]
    bad = [[1, 0, [0]], 0]
    closure = [bad]
    false_goal = [[[0], 0, [0]], 0]
    return {
        'unguarded_equation_introduction': [0, [[0], 0]],
        'wrong_elimination_matrix': [[], 0, [[bad, truth, truth], 0],
                                     [closure, [0]], false_goal],
        'wrong_introduction_matrix': [[], 0, [[truth, truth, bad], 0],
                                     [closure, [0]], false_goal],
    }


def to_float(value):
    if type(value) is int:
        return float(value)
    if type(value) is list:
        return [to_float(child) for child in value]
    return value


def numeric_opening_tests(module):
    # The finite-alias theorem is tested at both positive binder boundaries
    # and negative eigenparameter boundaries.  NaN/Infinity are holes.
    finite = [-100.5, -4.0, -3.5, -3, -2.5, -2, -1.5, -1, -.5,
              -0.0, False, 0, .5, True, 1, 1.5, 2, 2.5, 3.5,
              4, 4.5, 8.5, 1e100, -1e100]
    count = 0
    for lower in [0, -1, -3]:
        module.k = lower
        for depth in range(8):
            for value in finite:
                keep = lower <= value < depth
                require(keep == (lower <= math.floor(value) < depth),
                        'floor/interval equivalence', lower, depth, value)
                actual = module.inst(value, 0, depth)
                require(actual == (value if keep else 0),
                        'alias opening', lower, depth, value, actual)
                count += 1
            for value in [float('nan'), float('inf'), -float('inf')]:
                require(module.inst(value, 0, depth) == 0,
                        'nonfinite placeholder', value)
                try:
                    module.inst(value, d=depth)
                except (TypeError, ValueError):
                    pass
                else:
                    raise AssertionError(('nonfinite closed leaf', value))
                count += 1
    module.k = 0
    # All reject by finite dispatch, never by reaching a recursion limit.
    for value in [None, '', 'a', 'abc', {}, {'x': 0}, ['x'],
                  [[['abc']]], [[0, 'x']], [0, 0, {'x': 0}], [], [0]*4]:
        try:
            module.inst(value)
        except RecursionError as exc:
            raise AssertionError(('malformed syntax recursed', value)) from exc
        except (TypeError, ValueError, IndexError):
            pass
        else:
            raise AssertionError(('malformed syntax accepted', value))
        count += 1
    return count


def main():
    fixtures = json.loads((ROOT / 'fixtures.json').read_text())
    expected_metrics = {'checker.py': (356, 380, 1056),
                        'checker_full.py': (363, 386, 1068)}
    rng = random.Random(808202611)
    results = []
    atoms = [None, True, False, 0, 1, -1, -2, -99, 0.0, -0.0, .5,
             1.5, 2.5, -.5, -1.5, -99.5, 1e100, -1e100,
             float('inf'), -float('inf'), float('nan'), '', 'x', 'ab',
             'abc', {}, [], {'x': 0}]
    for width, mode, filename in [(1, 'scalar', 'checker.py'),
                                  (2, 'full', 'checker_full.py')]:
        path = ROOT.parent / filename
        module, oracle = load(path), Oracle(width)
        counts = {'canonical_fixtures': 0, 'all_float_fixtures': 0,
                  'mutations': 0, 'false_goal_probes': 0,
                  'numeric_and_malformed_openings': 0, 'cli_runs': 0,
                  'deliberate_bug_controls': 0}
        rule_coverage = set()

        def compare(packet, expected=None):
            got, ref = run(module, packet), oracle.run(packet)
            require(got[0] == ref['accepted'], mode, packet, got, ref)
            if expected is not None:
                require(got[0] == expected, mode, packet, expected, got)
            if got[0]:
                require(got[1:] == (ref['final_k'], ref['remaining']),
                        mode, 'accepted trace', got, ref)
                rule_coverage.update(ref['rules'])
            return got[0]

        packets = [item['packet'] for item in fixtures[mode]]
        for packet in packets:
            compare(packet, True)
            counts['canonical_fixtures'] += 1
            compare(to_float(packet), True)
            counts['all_float_fixtures'] += 1
            for _ in range(4):
                mutated = replace_at(packet, rng.choice(list(paths(packet))),
                                     copy.deepcopy(rng.choice(atoms)))
                compare(mutated)
                counts['mutations'] += 1
        # A genuine fractional zero alias can appear in accepted syntax.
        fractional = [[], [[0, .5, 1], .5]]
        compare(fractional, True)
        counts['numeric_and_malformed_openings'] = numeric_opening_tests(module)
        for packet in attacks().values():
            compare(packet, False)
        false_goals = [[0, [0]], [.5, [0]], [[0], .5],
                       [0, [[0]]], [[[0]], [0]]]
        for _ in range(150):
            packet = copy.deepcopy(rng.choice(packets))
            packet[-1] = copy.deepcopy(rng.choice(false_goals))
            compare(packet, False)
            counts['false_goal_probes'] += 1
        # Positive mutation controls demonstrate that the attack fixtures
        # detect the two soundness-critical third-matrix selectors.
        bad_intro = load(path, [('a[2]', 'a[0]')])
        bad_elim = load(path, [('h = [m[2:]]', 'h = [m[:1]]')])
        for mutant, name in [(bad_intro, 'unguarded_equation_introduction'),
                             (bad_intro, 'wrong_introduction_matrix'),
                             (bad_elim, 'wrong_elimination_matrix')]:
            require(run(mutant, attacks()[name])[0], 'control did not trigger', mode, name)
            counts['deliberate_bug_controls'] += 1
        cli_packets = packets[:3] + [fractional] + list(attacks().values())
        cli_packets += [[.5], ['abc'], [float('nan')], [float('inf')],
                        [None], {'x': 0}]
        for packet in cli_packets:
            expected = compare(packet)
            for flags in [[], ['-O']]:
                proc = subprocess.run([sys.executable, *flags, str(path)],
                                      input=json.dumps(packet), text=True,
                                      capture_output=True, timeout=10)
                require((proc.returncode, proc.stdout.strip(), proc.stderr) ==
                        ((0, 'ACCEPT', '') if expected else (1, 'REJECT', '')),
                        'public CLI', mode, packet, flags, proc)
                counts['cli_runs'] += 1
        for text in ['', '[', 'not-json', '[1,]']:
            proc = subprocess.run([sys.executable, str(path)], input=text,
                                  text=True, capture_output=True, timeout=10)
            require((proc.returncode, proc.stdout.strip(), proc.stderr) ==
                    (1, 'REJECT', ''), 'malformed JSON', text)
            counts['cli_runs'] += 1
        measured = metrics(path)
        require(tuple(measured[k] for k in ['normalized_tokens', 'ast_nodes',
                                           'normalized_bytes']) == expected_metrics[filename],
                filename, 'metrics changed', measured)
        require({'hypothesis', 'paired_elimination', 'closure_elimination',
                 'equality_transport', 'computation_zero',
                 'computation_successor', 'paired_introduction'} <= rule_coverage,
                mode, 'missing rule coverage', rule_coverage)
        results.append({'name': filename, 'status': 'PASS', **counts,
                        'rule_coverage': sorted(rule_coverage), 'metrics': measured})
    report = {'status': 'PASS', 'python': sys.version.split()[0],
              'interpretation': 'Ordered numeric leaf aliases; explicit array branch; matrix-last truth-completed native iPRA.',
              'limitation': 'Finite differential and adversarial tests are supporting evidence, not a formal soundness proof.',
              'results': results}
    (ROOT / 'validation_results.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
