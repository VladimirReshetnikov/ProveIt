"""Independent readable checker for the matrix-last truth encoding.

This is validation code only.  It does not import the production checker,
use its packed sort/depth index or its dispatch table, or share its matcher.
The mathematical interpretation of scalar formula leaves is truth.  The
opening implementation below preserves exact raw labels to check packet
agreement, while named logical rules are enforced explicitly.
"""
# Adaptation note: finite Python numeric leaves are coordinate aliases;
# NaN and infinity can occur only as external hole labels in a used tree.
# The inherited explicit term/formula recursion and named rules are unchanged.
# New leaf tests admit int, float and bool, and computation accepts numerical 0.
from copy import deepcopy


class Oracle:
    def __init__(self, recursion_width=1):
        if recursion_width not in (1,2): raise ValueError('recursion width')
        self.width=recursion_width
        self.lower=0
        self.rules={}

    def rule(self,name):
        self.rules[name]=self.rules.get(name,0)+1

    def leaf(self,value,image,protected,formula):
        # Formula leaves are semantically inert.  Their raw labels retain
        # the encoded interval convention, so this is not a total decoder.
        ceiling=2*protected+(0 if formula else 1)
        if self.lower<=value<ceiling:
            return value
        return self.term(image)

    def term(self,value,image=None,protected=0):
        if type(value) in (int, float, bool):
            return self.leaf(value,image,protected,False)
        if type(value) is not list: raise ValueError('term type')
        if len(value)==1:
            return [self.term(value[0],image,protected)]
        if len(value)==3:
            count,initial,update=value
            return [self.term(count,image,protected),
                    self.term(initial,image,protected),
                    self.term(update,image,protected+self.width)]
        raise ValueError('term arity')

    def formula(self,value,image=None,protected=0):
        if type(value) in (int, float, bool):
            return self.leaf(value,image,protected,True)
        if type(value) is not list: raise ValueError('formula type')
        if len(value)==1:
            return [self.formula(value[0],image,protected+1)]
        if len(value)==2:
            return [self.term(value[0],image,protected),
                    self.term(value[1],image,protected)]
        if len(value)==3:
            return [self.formula(child,image,protected+2) for child in value]
        raise ValueError('formula arity')

    def fresh(self):
        self.lower-=1
        return self.lower

    def check(self,goal,context):
        checked=self.formula(goal)
        if checked in context:
            self.rule('hypothesis')
            return True
        instruction=self.stack.pop()
        if type(instruction) is list and len(instruction)==2:
            major,annotation=instruction
            # Only an ordinary False return triggers fallthrough.  An
            # exception is fatal to the entire public proof attempt.
            if self.check(major,context):
                if type(major) is not list: raise ValueError('scalar major')
                if len(major)==3:
                    self.rule('paired_elimination')
                    eigen=self.fresh()
                    assumption=self.formula([major[2]],eigen)
                    return self.check(self.formula(goal,[eigen]),context+[assumption])
                if len(major)==1:
                    self.rule('closure_elimination')
                    matrix,left,right=major[0],0,annotation
                elif len(major)==2:
                    self.rule('equality_transport')
                    matrix=annotation
                    left,right=major
                else:
                    raise ValueError('major arity')
                if self.formula(matrix,right)!=goal: return False
                return self.check(self.formula(matrix,left),context)
            self.rule('failed_major_fallthrough')
        if type(instruction) is list and not instruction:
            if type(goal) is not list or len(goal)!=2:
                raise ValueError('computation requires equality')
            term,right=goal
            if type(term) is not list or len(term)!=3:
                raise ValueError('computation requires recursor')
            count,initial,update=term
            if type(count) in (int, float, bool) and count==0:
                expected=initial
                self.rule('computation_zero')
            elif type(count) is list and len(count)==1:
                smaller=[count[0],initial,update]
                body=(self.term(update,count[0],1) if self.width==2 else update)
                expected=self.term(body,smaller)
                self.rule('computation_successor')
            else:
                raise ValueError('counter shape')
            return right==expected
        if type(goal) is not list or len(goal)!=3:
            raise ValueError('primitive introduction requires paired goal')
        self.rule('paired_introduction')
        matrix=self.formula(goal[2],instruction,1)
        # Evaluate the base even if the induction hypothesis is absent,
        # as the acceptance program does.  A scalar root cannot be a
        # successful induction/cases matrix in this packet convention.
        base=self.formula(matrix,0)
        if type(matrix) is not list: raise ValueError('scalar introduction matrix')
        assumptions=([matrix,base] if len(matrix)==2 else [base])
        eigen=self.fresh()
        conclusion=self.formula(matrix,[eigen])
        opened=[self.formula(a,eigen) for a in assumptions]
        return self.check(conclusion,context+opened)

    def run(self,packet):
        self.lower=0;self.rules={};self.stack=deepcopy(packet)
        try:
            accepted=bool(self.check(self.stack.pop(),[]));error=None
        except Exception as exc:
            accepted=False;error=type(exc).__name__
        return {'accepted':accepted,'final_k':self.lower,
                'remaining':len(self.stack) if type(self.stack) is list else None,
                'rules':dict(self.rules),'error':error}
