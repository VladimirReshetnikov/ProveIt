"""Reproduce complete-program and identical-driver comparisons offline."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import tempfile

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('inherited_measure', ROOT / 'comparison/source_measure.py')
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
DRIVER = '''try:
    take = json.load(sys.stdin).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
'''


def common_source(source, filename=False):
    tree = ast.parse(source)
    start = next(i for i, node in enumerate(tree.body) if isinstance(node, ast.Try))
    assert all(isinstance(node, (ast.Try, ast.Expr)) for node in tree.body[start:])
    driver = DRIVER.replace('sys.stdin', 'open(sys.argv[1])') if filename else DRIVER
    tree.body[start:] = ast.parse(driver).body
    return ast.unparse(ast.fix_missing_locations(tree)) + '\n'


def text_metrics(source, folder, name):
    p = folder / name
    p.write_text(source)
    return measure.metrics(p)


def minimum(rows, field):
    return {key: min(row[field][key] for row in rows) for key in FIELDS}


def triple(row):
    return ' & '.join(f'{row[key]:,}' for key in FIELDS)


def main():
    manifest = json.loads((ROOT / 'source_manifest.json').read_text())
    with tempfile.TemporaryDirectory(prefix='ipra_measure_') as temporary:
        folder = Path(temporary)
        rows = []
        for item in manifest['programs']:
            path = ROOT / item['local_file']
            assert hashlib.sha256(path.read_bytes()).hexdigest() == item['sha256']
            rows.append({**item, 'delivered': measure.metrics(path),
                         'common_stdin': text_metrics(common_source(path.read_text()), folder, path.name),
                         'common_filename': text_metrics(common_source(path.read_text(), True), folder, path.name)})
        candidates = []
        for name in ['checker.py', 'checker_full.py']:
            path = ROOT / name
            candidates.append({'file': name, 'delivered': measure.metrics(path),
                               'common_stdin': text_metrics(common_source(path.read_text()), folder, name),
                               'common_filename': text_metrics(common_source(path.read_text(), True), folder, name)})
        old_truth = ROOT / 'comparison/current/ipra_truth_completion_2026-11-07__checker_scalar.py'
        intermediate = text_metrics(common_source(old_truth.read_text()), folder, 'truth_common.py')
    mins = {f: minimum(rows, f) for f in ('delivered', 'common_stdin', 'common_filename')}
    result = {'python': platform.python_version(), 'implementation': platform.python_implementation(),
              'commit': manifest['commit'], 'archive_count': len(manifest['files']),
              'root_program_count': len(rows),
              'distinct_source_count': len({r['sha256'] for r in rows}),
              'minima': mins, 'programs': rows, 'candidates': candidates,
              'inherited_truth_with_common_driver': intermediate}
    for c in candidates:
        c['strictly_below_delivered_minima'] = all(c['delivered'][k] < mins['delivered'][k] for k in FIELDS)
        c['strictly_below_common_driver_minima'] = all(c['common_stdin'][k] < mins['common_stdin'][k] for k in FIELDS)
    results = ROOT / 'results'
    results.mkdir(exist_ok=True)
    (results / 'measurements.json').write_text(json.dumps(result, indent=2) + '\n')
    macros = {}
    for prefix, row in [('Baseline', mins['delivered']), ('Common', mins['common_stdin']),
                        ('Scalar', candidates[0]['delivered']), ('Full', candidates[1]['delivered'])]:
        for suffix, key in [('Tokens', 'normalized_tokens'), ('Nodes', 'ast_nodes'), ('Bytes', 'normalized_bytes')]:
            macros[prefix + suffix] = str(row[key])
    (results / 'numbers.tex').write_text('\n'.join('\\newcommand{\\' + key + '}{' + value + '}' for key, value in macros.items()) + '\n')
    table = ['\\begin{center}', '\\begin{tabular}{@{}lrrr@{}}', '\\toprule',
             'Complete program & Tokens & AST nodes & Bytes\\\\', '\\midrule',
             'Current delivered minima & ' + triple(mins['delivered']) + '\\\\',
             'Delivered scalar checker & ' + triple(candidates[0]['delivered']) + '\\\\',
             'Delivered full-recursion checker & ' + triple(candidates[1]['delivered']) + '\\\\',
             '\\midrule',
             'Current minima, identical stdin driver & ' + triple(mins['common_stdin']) + '\\\\',
             'Scalar, identical stdin driver & ' + triple(candidates[0]['common_stdin']) + '\\\\',
             'Full recursion, identical stdin driver & ' + triple(candidates[1]['common_stdin']) + '\\\\',
             '\\bottomrule', '\\end{tabular}', '\\end{center}', '']
    (results / 'measurement_table.tex').write_text('\n'.join(table))
    lines = ['\\begin{center}', '\\small', '\\begin{tabular}{@{}lrrr@{}}', '\\toprule',
             'Current root program & Tokens & AST nodes & Bytes\\\\', '\\midrule']
    names = ['Direct/full', 'Direct/scalar', 'Integrated/scalar', 'Locality/scalar',
             'Opening/scalar', 'Opening/full', 'Reduction/scalar', 'Truth/full', 'Truth/scalar']
    for name, row in zip(names, rows):
        lines.append(name + ' & ' + triple(row['delivered']) + '\\\\')
    lines += ['\\bottomrule', '\\end{tabular}', '\\end{center}', '']
    (results / 'current_table.tex').write_text('\n'.join(lines))
    print(json.dumps({k: v for k, v in result.items() if k not in ('programs',)}, indent=2))


if __name__ == '__main__':
    main()
