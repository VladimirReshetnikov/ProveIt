A SMALLER COMPLETE PROOF CHECKER FOR iPRA
Prepared for Vladimir Reshetnikov, 7 November 2026
================================================

Read report.pdf. Its complete editable report.tex, section sources, and
mathematical appendices are included. The package is self-contained and
needs no network connection for verification or rebuilding.

RESULT

Complete delivered programs, normalized tokens / AST nodes / UTF-8 bytes:

  Current nine-root corpus minima:             367 / 392 / 1076
  checker.py, scalar iteration:                356 / 380 / 1056
  checker_full.py, full primitive recursion:   363 / 386 / 1068

With exactly the same standard-input/division driver substituted into
every current program, the old minima become 359 / 384 / 1060. The scalar
candidate still improves all three: 356 / 380 / 1056. The corresponding
common-filename comparison is 365 / 390 / 1068 versus 362 / 386 / 1064.

The structural improvement under a common driver is therefore THREE
normalized tokens, FOUR AST nodes, and FOUR normalized bytes. Reading
stdin contributes a separately disclosed six tokens, six nodes, and
eight bytes compared with filename input. The full-recursion companion
does not dominate the best scalar common-driver envelope.

The new validator recognizes arrays first, then lets the integer scope
interval classify numeric leaves. Finite fractional coordinate spellings
are interpreted by their floors. This removes a duplicate shape check
while preserving soundness and termination on malformed input. The
checker does not calculate floors, evaluate an external proof oracle,
or depend on an uncounted project library.

This is a modest reproducible implementation improvement. It is not a
new arithmetic foundation, a proof of absolute shortestness, or the
large conceptual breakthrough requested. The inherited foundation,
truth-completion representation, and prior implementation conventions
are explicitly credited. No historical-priority claim is made.

MATHEMATICAL CONTENT

The paper states all native logical and nonlogical rules, reconstructs
full intuitionistic first-order logic, derives the arithmetic, and gives
both ordinary whole-domain bi-interpretations with iPRA. The two composite
isomorphisms have graph x=y and are proved internally, including at
nonstandard arguments. Equiconsistency follows.

The main text uses a full two-variable recursor because predecessor and
the direct interpretation are short. The appendices give the entire
scalar predecessor, quantifier-free reflection, and pair-coding development
needed to justify the smallest implementation. Full formula transport
can also be restricted to a numerical left-term motive; its noncircular
derivation is included without claiming an extra code-size reduction.

The new interval proof includes a worked counterexample showing why
flooring a whole noncanonical packet need not preserve its execution.
Soundness uses semantic extraction of the successful trace, not that
incorrect packet-normalization claim.

QUICK START

Use Python 3.10 or later. Exact source measurements use CPython 3.12.14.
Both checkers read one JSON proof packet from standard input:

  python3 checker.py < examples/zero_computation.json
  python3 checker.py < examples/fractional_initializer.json
  python3 checker_full.py < examples/addition_2_3.json

Each prints ACCEPT and exits 0. This supplied attack prints REJECT and
exits 1 with either checker:

  python3 checker.py < examples/unguarded_equation_introduction.json

The same checking behavior holds under python3 -O. A rejected packet
does not say its intended formula is unprovable. FORMAT.txt describes
the exact input syntax, inference dispatch, and redundant spellings.

REPRODUCTION

  python3 reproduce.py

This verifies comparator identities, remeasures all nine current sources,
runs the portable independent oracle audit, and checks every public
example's specified verdict. It uses only Python's standard library.

  python3 build.py

This rebuilds the PDF with pdfLaTeX, Latin Modern, and the ordinary TeX
packages listed in report.tex. It refreshes measured tables, performs
three LaTeX passes, and rejects undefined references or overfull boxes.

  python3 package.py

This regenerates the archive and checksums after intentional changes.

VALIDATION

The final portable suite passed 202 canonical certificates, 202 exact-float
versions, 808 mutations, 300 false-equation probes, 1320 numeric-boundary
and malformed-opening checks, 60 command-line checks, and six deliberate
defect controls. Categories overlap. All seven named inference/computation
actions are exercised in both variants. Every supplied public example
was separately checked with its specified implementation(s).

These finite outcomes support the implementation argument. They do not
establish a universal metatheorem. The paper gives written mathematical
proofs, not a Lean or Rocq formalization of the calculus, interpretations,
or Python runtime. Real parser, call-stack, time, and memory limits can
reject sufficiently large valid certificates; canonical completeness is
the ordinary idealized adequate-finite-resource statement.

CONTENTS

  report.tex, report.pdf       Complete paper and compiled PDF
  sections/, appendices/      Editable mathematical sources
  checker.py                  Complete scalar acceptance program
  checker_full.py             Complete full-recursion acceptance program
  FORMAT.txt                  Certificate syntax and semantics
  examples/                   Runnable certificates and verdict index
  validation/                 Independent oracle, fixtures, audit, receipts
  comparison/current/         Nine unchanged current root checker files
  comparison/source_measure.py Unchanged inherited normalizer
  source_manifest.json        Pinned archive and source identities
  results/                    Measurements and build/reproduction receipts
  measure.py                  Offline comparison and common-driver controls
  reproduce.py, build.py       Reproduction entry points
  package.py, SHA256SUMS       Archive creation and integrity hashes
  ATTRIBUTION.txt              Exact inherited/new contribution boundary
  LICENSE-inherited.txt        Preserved inherited source license

The inherited metric emits a legacy field called core; this package does
not use that field as a separately proved trusted-kernel boundary. The
headline metrics always count complete programs or complete programs
with one identical driver.

PINNED COMPARISON

Repository: VladimirReshetnikov/ProveIt
Commit: ea1bd900ee0c8b3d4d108cfc3deb176bab9a039a
Directory: docs/drafts
https://github.com/VladimirReshetnikov/ProveIt/tree/ea1bd900ee0c8b3d4d108cfc3deb176bab9a039a/docs/drafts

There are six current archives, nine root checker files, and seven distinct
source hashes. Their own reports often quote an older 375/403/1117
envelope. That older envelope is not used as this iteration's target.
