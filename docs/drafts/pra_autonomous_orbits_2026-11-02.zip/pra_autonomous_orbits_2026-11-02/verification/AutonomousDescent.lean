import Std

/-!+# Named autonomous orbits: the arbitrary-carrier logical kernel

This file checks induction recovery using only one autonomous repaired orbit
for each seed and one frozen numerical parameter. The carrier is an arbitrary
type: no induction, well-foundedness, or identification with Nat is assumed.

The orbit R(n, a, c) retains its initial seed a and one parameter c. Its update
depends on the previous value, a, and c, but not on the current counter n.
Only the displayed no-descent instance for that orbit is assumed. We do not
assume no descent for every function on the carrier.

The predicate P and its zero-reflecting test are fixed. Their admissibility as
finite first-order terms, descriptor closure, compilation of all formulas,
parameter coding, and full theory bi-interpretability remain written proofs.

No axiom declaration, sorry, classical choice, or Nat induction occurs here.
-/

namespace NamedAutonomousDescent

universe u
variable {D : Type u}

/-- A zero recursor and its own orbit prohibition already force separation. -/
theorem separation_from_zero_orbit
    (zero : D) (succ : D → D) (Z : D → D → D)
    (base : ∀ a, Z zero a = a)
    (step : ∀ n a, Z (succ n) a = zero)
    (no_descent : ¬ ∀ n, Z n zero = succ (Z (succ n) zero)) :
    zero ≠ succ zero := by
  intro collapsed_zero
  have all_zero : ∀ a : D, a = zero := by
    intro a
    calc
      a = Z zero a := (base a).symm
      _ = Z (succ zero) a := congrArg (fun x => Z x a) collapsed_zero
      _ = zero := step zero a
  apply no_descent
  intro n
  exact (all_zero (Z n zero)).trans (all_zero (succ (Z (succ n) zero))).symm

theorem successor_injective
    (succ pred : D → D) (pred_succ : ∀ x, pred (succ x) = x) :
    ∀ x y, succ x = succ y → x = y := by
  intro x y h
  exact (pred_succ x).symm.trans ((congrArg pred h).trans (pred_succ y))

theorem successor_nonzero
    (zero : D) (succ pred : D → D)
    (separation : zero ≠ succ zero)
    (pred_zero : pred zero = zero)
    (pred_succ : ∀ x, pred (succ x) = x) :
    ∀ x, succ x ≠ zero := by
  intro x h
  have hx : x = zero :=
    (pred_succ x).symm.trans ((congrArg pred h).trans pred_zero)
  apply separation
  exact h.symm.trans (congrArg succ hx)

/--
A zero-reflecting numerical test need not itself have the range {0,1}.
Coverage and successor nonzeroness give the decision needed by the repair.
-/
theorem decision_from_zero_test
    (zero : D) (succ pred : D → D)
    (coverage : ∀ x, x = zero ∨ x = succ (pred x))
    (succ_nonzero : ∀ x, succ x ≠ zero)
    (P : D → D → Prop) (test : D → D → D)
    (test_correct : ∀ x c, test x c = zero ↔ P x c) :
    ∀ x c, P x c ∨ ¬ P x c := by
  intro x c
  rcases coverage (test x c) with hz | hs
  · exact Or.inl ((test_correct x c).mp hz)
  · apply Or.inr
    intro hP
    have hz : test x c = zero := (test_correct x c).mpr hP
    exact succ_nonzero (pred (test x c)) (hs.symm.trans hz)

/-- The explicit autonomous update retains seed a and numerical parameter c. -/
def repairedUpdate
    (pred : D → D) (select : D → D → D → D)
    (test : D → D → D) (state seed param : D) : D :=
  pred (select (test state param) seed state)

/--
One named autonomous orbit proves P at its own seed under local induction
hypotheses. The proof uses no induction on D and makes no range assumption
about arbitrary orbit values. Coverage is used at the recursion index and at
a bad state; this is the nonstandard-carrier point of the repair argument.
-/
theorem named_orbit_forces_seed
    (zero : D) (succ pred : D → D)
    (coverage : ∀ x, x = zero ∨ x = succ (pred x))
    (succ_nonzero : ∀ x, succ x ≠ zero)
    (select : D → D → D → D)
    (select_zero : ∀ b e, select zero b e = b)
    (select_succ : ∀ x b e, select (succ x) b e = e)
    (P : D → D → Prop) (test : D → D → D)
    (test_correct : ∀ x c, test x c = zero ↔ P x c)
    (param seed : D) (orbit : D → D)
    (orbit_zero : orbit zero = seed)
    (orbit_step : ∀ n,
      orbit (succ n) = repairedUpdate pred select test (orbit n) seed param)
    (no_descent : ¬ ∀ n, orbit n = succ (orbit (succ n)))
    (initial : P zero param)
    (progress : ∀ x, P x param → P (succ x) param) :
    P seed param := by
  rcases decision_from_zero_test zero succ pred coverage succ_nonzero
      P test test_correct seed param with seed_good | seed_bad
  · exact seed_good
  · have bad_is_successor : ∀ x, ¬ P x param → x = succ (pred x) := by
      intro x bad
      rcases coverage x with hz | hs
      · exact False.elim (bad (hz ▸ initial))
      · exact hs

    have predecessor_bad : ∀ x, ¬ P x param → ¬ P (pred x) param := by
      intro x bad predecessor_good
      have hs_good : P (succ (pred x)) param := progress (pred x) predecessor_good
      exact bad ((bad_is_successor x bad).symm ▸ hs_good)

    have selected_bad : ∀ x, ¬ P (select (test x param) seed x) param := by
      intro x
      rcases coverage (test x param) with hz | hs
      · simpa only [hz, select_zero] using seed_bad
      · have x_bad : ¬ P x param := by
          intro hP
          have hz : test x param = zero := (test_correct x param).mpr hP
          exact succ_nonzero (pred (test x param)) (hs.symm.trans hz)
        have hselected : select (test x param) seed x = x := by
          calc
            select (test x param) seed x =
                select (succ (pred (test x param))) seed x :=
              congrArg (fun t => select t seed x) hs
            _ = x := select_succ (pred (test x param)) seed x
        exact hselected.symm ▸ x_bad

    have next_bad : ∀ n, ¬ P (orbit (succ n)) param := by
      intro n
      rw [orbit_step n]
      exact predecessor_bad (select (test (orbit n) param) seed (orbit n))
        (selected_bad (orbit n))

    have all_bad : ∀ n, ¬ P (orbit n) param := by
      intro n
      rcases coverage n with hz | hs
      · simpa only [hz, orbit_zero] using seed_bad
      · rw [hs]
        exact next_bad (pred n)

    have repair_inactive : ∀ n,
        select (test (orbit n) param) seed (orbit n) = orbit n := by
      intro n
      rcases coverage (test (orbit n) param) with hz | hs
      · exact False.elim ((all_bad n) ((test_correct (orbit n) param).mp hz))
      · calc
          select (test (orbit n) param) seed (orbit n) =
              select (succ (pred (test (orbit n) param))) seed (orbit n) :=
            congrArg (fun t => select t seed (orbit n)) hs
          _ = orbit n := select_succ (pred (test (orbit n) param)) seed (orbit n)

    apply False.elim
    apply no_descent
    intro n
    calc
      orbit n = succ (pred (orbit n)) := bad_is_successor (orbit n) (all_bad n)
      _ = succ (orbit (succ n)) :=
        congrArg succ ((orbit_step n).trans (congrArg pred (repair_inactive n))).symm

/-- The fixed-predicate induction implication, with one frozen parameter. -/
theorem induction_from_named_autonomous_family
    (zero : D) (succ pred : D → D)
    (coverage : ∀ x, x = zero ∨ x = succ (pred x))
    (succ_nonzero : ∀ x, succ x ≠ zero)
    (select : D → D → D → D)
    (select_zero : ∀ b e, select zero b e = b)
    (select_succ : ∀ x b e, select (succ x) b e = e)
    (P : D → D → Prop) (test : D → D → D)
    (test_correct : ∀ x c, test x c = zero ↔ P x c)
    (R : D → D → D → D)
    (R_zero : ∀ a c, R zero a c = a)
    (R_step : ∀ n a c,
      R (succ n) a c = repairedUpdate pred select test (R n a c) a c)
    (no_descent : ∀ a c, ¬ ∀ n, R n a c = succ (R (succ n) a c)) :
    ∀ c, (P zero c ∧ (∀ x, P x c → P (succ x) c)) → ∀ a, P a c := by
  intro c hypotheses a
  exact named_orbit_forces_seed zero succ pred coverage succ_nonzero
    select select_zero select_succ P test test_correct c a (fun n => R n a c)
    (R_zero a c) (fun n => R_step n a c) (no_descent a c)
    hypotheses.1 hypotheses.2

/--
The weaker epsilon calibration suffices to construct an exact Boolean test,
although leaving epsilon itself arbitrary would obstruct the desired identity
round trip. This theorem is only a logical truth-compiler component.
-/
theorem booleanize_zero_reflector
    (zero : D) (succ pred : D → D)
    (coverage : ∀ x, x = zero ∨ x = succ (pred x))
    (succ_nonzero : ∀ x, succ x ≠ zero)
    (select : D → D → D → D)
    (select_zero : ∀ b e, select zero b e = b)
    (select_succ : ∀ x b e, select (succ x) b e = e)
    (epsilon : D → D → D)
    (diagonal : ∀ x, epsilon x x = zero)
    (reflects_zero : ∀ x y, epsilon x y = zero → x = y) :
    ∀ x y,
      (select (epsilon x y) zero (succ zero) = zero ↔ x = y) ∧
      (select (epsilon x y) zero (succ zero) = zero ∨
       select (epsilon x y) zero (succ zero) = succ zero) := by
  intro x y
  rcases coverage (epsilon x y) with hz | hs
  · have hxy : x = y := reflects_zero x y hz
    have hvalue : select (epsilon x y) zero (succ zero) = zero := by
      rw [hz, select_zero]
    exact ⟨⟨fun _ => hxy, fun _ => hvalue⟩, Or.inl hvalue⟩
  · have hvalue : select (epsilon x y) zero (succ zero) = succ zero := by
      rw [hs, select_succ]
    have hne : x ≠ y := by
      intro hxy
      have heq : epsilon x y = zero := by simpa only [hxy] using diagonal y
      exact succ_nonzero (pred (epsilon x y)) (hs.symm.trans heq)
    constructor
    · constructor
      · intro hzero
        exact False.elim (succ_nonzero zero (hvalue.symm.trans hzero))
      · intro hxy
        exact False.elim (hne hxy)
    · exact Or.inr hvalue

#print axioms separation_from_zero_orbit
#print axioms successor_injective
#print axioms successor_nonzero
#print axioms decision_from_zero_test
#print axioms named_orbit_forces_seed
#print axioms induction_from_named_autonomous_family
#print axioms booleanize_zero_reflector

end NamedAutonomousDescent
