#!/usr/bin/env python3
"""Actual-AST audit for the same-language adaptive PRA descent templates.

No third-party packages. This checks literal syntax costs and substitutions;
it is not a formal verification of the arithmetic equivalence theorem.
"""
from __future__ import annotations
import argparse
from dataclasses import dataclass
import json
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class Symbol:
    name: str
    arity: int
    descriptor: Optional['Node'] = None


@dataclass(frozen=True)
class Node:
    kind: str
    args: tuple['Node', ...] = ()
    name: str = ''
    symbol: Optional[Symbol] = None


def var(name: str) -> Node:
    return Node('var', name=name)


def app(symbol: Symbol, *args: Node) -> Node:
    if len(args) != symbol.arity:
        raise ValueError(f'arity mismatch for {symbol.name}')
    return Node('app', tuple(args), symbol=symbol)


ZERO_SYMBOL = Symbol('0', 0)
SUCCESSOR = Symbol('S', 1)
BIT = Symbol('e', 2)
ZERO = app(ZERO_SYMBOL)
FALSE = Node('false')


def succ(t: Node) -> Node:
    return app(SUCCESSOR, t)


def eq(s: Node, t: Node) -> Node:
    return Node('eq', (s, t))


def conjunction(s: Node, t: Node) -> Node:
    return Node('and', (s, t))


def disjunction(s: Node, t: Node) -> Node:
    return Node('or', (s, t))


def implies(s: Node, t: Node) -> Node:
    return Node('implies', (s, t))


def all_(name: str, body: Node) -> Node:
    return Node('all', (body,), name=name)


def quantify(names: list[str], matrix: Node) -> Node:
    for name in reversed(names):
        matrix = all_(name, matrix)
    return matrix


def count(node: Node, full: bool = False) -> int:
    """Tree count: repeated shared Node objects are charged each time."""
    total = 1 + sum(count(a, full) for a in node.args)
    if full and node.kind == 'app' and node.symbol.descriptor is not None:
        total += count(node.symbol.descriptor, True)
    return total


def occurrence(node: Node, name: str) -> int:
    """Only active occurrences; never enters a symbol descriptor."""
    return int(node.kind == 'var' and node.name == name) + sum(
        occurrence(a, name) for a in node.args)


def substitute(term: Node, replacements: dict[str, Node]) -> Node:
    """Simultaneous term substitution. Inserted terms are not resubstituted."""
    if term.kind == 'var':
        return replacements.get(term.name, term)
    if term.kind != 'app':
        raise TypeError('Only terms are accepted for active substitution')
    return Node('app', tuple(substitute(a, replacements) for a in term.args),
                symbol=term.symbol)


def quantifier_count(node: Node) -> int:
    return int(node.kind == 'all') + sum(quantifier_count(a) for a in node.args)


def quantifier_depth(node: Node) -> int:
    return int(node.kind == 'all') + max(
        (quantifier_depth(a) for a in node.args), default=0)


def symbols_of(term: Node) -> list[Symbol]:
    found = [term.symbol] if term.kind == 'app' else []
    for a in term.args:
        found.extend(symbols_of(a))
    return found


def rec_symbol(body: Node, k: int, name: str = 'R_h') -> Symbol:
    return Symbol(name, k + 2, body)


def construct_templates(body: Node, k: int) -> tuple[Node, Node]:
    """Construct expanded T and O in the original unbounded-parameter grammar."""
    n, a, j = var('n'), var('a'), var('j')
    zs = [var(f'z{q}') for q in range(k)]
    r = rec_symbol(body, k)
    base = eq(app(r, ZERO, a, *zs), a)
    replacements = {'v': app(r, n, a, *zs), 'w': n}
    step = eq(app(r, succ(n), a, *zs), substitute(body, replacements))
    computation = conjunction(base, step)
    test_j = substitute(body, {'v': j, 'w': a})
    test_sj = substitute(body, {'v': succ(j), 'w': a})
    term_descent = implies(all_('j', eq(test_j, succ(test_sj))), FALSE)
    orbit_descent = implies(all_('j', eq(
        app(r, j, a, *zs), succ(app(r, succ(j), a, *zs)))), FALSE)
    names = ['a'] + [f'z{q}' for q in range(k)] + ['n']
    return (quantify(names, conjunction(computation, term_descent)),
            quantify(names, conjunction(computation, orbit_descent)))


def expected(body: Node, k: int) -> dict:
    m, M, i = count(body), count(body, True), occurrence(body, 'v')
    return {
        'k': k, 'm': m, 'M': M, 'i': i,
        'T_active': 19 + 3*k + 3*m + (k+3)*i,
        'O_active': 26 + 5*k + m + (k+2)*i,
        'T_full': 19 + 3*k + (5+i)*M + (k+3)*i,
        'O_full': 26 + 5*k + (5+i)*M + (k+2)*i,
    }


def repeated_state(leaves: int) -> Node:
    if leaves == 1:
        return var('v')
    left = leaves // 2
    return app(BIT, repeated_state(left), repeated_state(leaves-left))


def representative_bodies(k: int) -> list[Node]:
    """Exhaustive shallow constructors plus explicit nested/large profiles."""
    terminals = [ZERO, var('v'), var('w')] + [var(f'z{q}') for q in range(k)]
    bodies = list(terminals)
    bodies.extend(succ(t) for t in terminals)
    bodies.extend(app(BIT, s, t) for s in terminals for t in terminals)
    # A modest exhaustive second layer over a fixed first-layer prefix.
    first = bodies[:min(len(bodies), 12)]
    bodies.extend(succ(t) for t in first)
    bodies.extend(app(BIT, s, t) for s in first for t in first)
    # Every full-metric threshold and its neighbors, plus high duplication.
    for i in range(1, 2*k + 13):
        bodies.append(repeated_state(i))
        bodies.append(succ(repeated_state(i)))
    # Genuine stored descriptors at two ranks, with their own v,w occurrences.
    zs = [var(f'z{q}') for q in range(k)]
    prior_body = app(BIT, var('v'), succ(var('w')))
    prior = rec_symbol(prior_body, k, 'R_prior')
    nested_body = app(prior, succ(var('v')), var('w'), *zs)
    nested = rec_symbol(nested_body, k, 'R_nested')
    for s in terminals:
        for t in terminals:
            bodies.append(app(prior, s, t, *zs))
            bodies.append(app(nested, s, t, *zs))
    # Large descriptor with a tiny active probe is important for tie tests.
    large = rec_symbol(repeated_state(17 + k), k, 'R_large')
    bodies.append(app(large, var('v'), var('w'), *zs))
    return list(dict.fromkeys(bodies))


def fixed_axioms() -> tuple[Node, Node]:
    x, y = var('x'), var('y')
    bit = quantify(['x', 'y'], conjunction(
        eq(app(BIT, x, x), ZERO),
        disjunction(eq(x, y), eq(app(BIT, x, y), succ(ZERO)))))
    q = rec_symbol(var('w'), 0, 'Q')
    cover = all_('x', disjunction(eq(x, ZERO),
                                eq(x, succ(app(q, x, ZERO)))))
    return bit, cover


def audit_case(body: Node, k: int) -> dict:
    record = expected(body, k)
    t, o = construct_templates(body, k)
    actual = {'T_active': count(t), 'O_active': count(o),
              'T_full': count(t, True), 'O_full': count(o, True)}
    for key, value in actual.items():
        assert value == record[key], (key, value, record)
    assert quantifier_count(t) == quantifier_count(o) == k+3
    assert quantifier_depth(t) == quantifier_depth(o) == k+3
    m, i, threshold = record['m'], record['i'], 7+2*k
    active_branch = 'T' if 2*m+i <= threshold else 'O'
    full_branch = 'T' if i <= threshold else 'O'
    joint_branch = 'T' if i < threshold else 'O'
    assert record[f'{active_branch}_active'] == min(record['T_active'], record['O_active'])
    assert record[f'{full_branch}_full'] == min(record['T_full'], record['O_full'])
    assert record[f'{joint_branch}_full'] == min(record['T_full'], record['O_full'])
    assert record[f'{joint_branch}_active'] <= record['T_active']
    assert record[f'{joint_branch}_full'] <= record['T_full']
    record.update(active_branch=active_branch, full_branch=full_branch,
                  joint_branch=joint_branch)
    return record


def run_audit() -> dict:
    reports = []
    all_records = []
    probe_records = []
    for k in [0, 1, 2, 3, 5]:
        bodies = representative_bodies(k)
        records = [audit_case(body, k) for body in bodies]
        # Verify the legal later probe for EVERY tested descriptor, not just a profile.
        for idx, body in enumerate(bodies):
            symbol = rec_symbol(body, k, f'R_probe_source_{idx}')
            zs = [var(f'z{q}') for q in range(k)]
            probe = app(symbol, var('v'), var('w'), *zs)
            pr = audit_case(probe, k)
            assert pr['m'] == 3+k and pr['i'] == 1
            assert 2*pr['m']+pr['i'] == 7+2*k
            assert all(pr[key] == 'T' for key in
                       ['active_branch', 'full_branch', 'joint_branch'])
            # Explicit check that simultaneous substitution does not enter labels.
            changed = substitute(probe, {'v': succ(var('w')), 'w': ZERO})
            assert changed.symbol is symbol
            assert changed.symbol.descriptor is body
            assert changed.args[0] == succ(var('w'))  # inserted w is not resubstituted
            assert changed.args[1] == ZERO
            probe_records.append(pr)
        reports.append({
            'k': k, 'body_cases': len(records), 'probe_cases': len(records),
            'max_active_body_size': max(r['m'] for r in records),
            'max_full_body_size': max(r['M'] for r in records),
            'max_state_occurrences': max(r['i'] for r in records),
            'joint_strict_active_cases': sum(r[r['joint_branch']+'_active'] < r['T_active'] for r in records),
            'joint_strict_full_cases': sum(r[r['joint_branch']+'_full'] < r['T_full'] for r in records),
        })
        all_records.extend(records)
    bit, cover = fixed_axioms()
    fixed = {'bit_active': count(bit), 'coverage_active': count(cover),
             'bit_full': count(bit, True), 'coverage_full': count(cover, True)}
    assert fixed == {'bit_active': 18, 'coverage_active': 11,
                     'bit_full': 18, 'coverage_full': 12}
    assert any(r['M'] > r['m'] for r in all_records)
    assert any(r['joint_branch'] == 'O' for r in all_records)
    # Record the genuine tradeoff of the active-only optimizer.
    active_full_regressions = sum(
        r[r['active_branch']+'_full'] > r['T_full'] for r in all_records)
    assert active_full_regressions > 0
    return {
        'status': 'PASS',
        'purpose': 'Actual syntax-tree size and simultaneous-substitution audit; not arithmetic proof verification',
        'source_commit': 'fc604391af372504e9163797c0722069ae49466e',
        'source_archive': 'pra_unit_descent_2026-11-02.zip',
        'grammar': 'Original unbounded immutable-parameter counter-recursion; no seed-aware change',
        'ordinary_body_cases': len(all_records),
        'probe_body_cases': len(probe_records),
        'formula_trees_checked': 2*(len(all_records)+len(probe_records)),
        'formulas_counted_in_both_metrics': True,
        'parameter_arities_checked': [0, 1, 2, 3, 5],
        'fixed_costs': fixed,
        'per_arity': reports,
        'checks': [
            'Actual AST counts equal all four closed forms',
            'Quantifier counts and depths equal k+3',
            'Active optimizer attains active pointwise minimum',
            'Both full optimizers attain expanded pointwise minimum',
            'Joint optimizer never increases either metric versus source',
            'Every later orbit probe selects term descent in all three selectors',
            'Substitution is simultaneous and leaves frozen descriptors unchanged',
            'Nested descriptor labels are charged at every occurrence in full metric',
            'Fixed axioms retain 29 active and 30 full nodes',
        ],
        'active_optimizer_full_regressions_observed': active_full_regressions,
        'joint_strict_active_cases': sum(r[r['joint_branch']+'_active'] < r['T_active'] for r in all_records),
        'joint_strict_full_cases': sum(r[r['joint_branch']+'_full'] < r['T_full'] for r in all_records),
        'max_active_saving_joint': max(r['T_active']-r[r['joint_branch']+'_active'] for r in all_records),
        'max_full_saving_joint': max(r['T_full']-r[r['joint_branch']+'_full'] for r in all_records),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path('schema_verification.json'))
    args = parser.parse_args()
    result = run_audit()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
