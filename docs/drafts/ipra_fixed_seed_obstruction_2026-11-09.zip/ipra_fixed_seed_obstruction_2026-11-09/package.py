"""Build and verify the ZIP and its payload hash manifest."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent


def payload_files():
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        if path.parent == ROOT and path.name in {
            "MANIFEST.json", "report.aux", "report.log", "report.out", "report.toc",
            "report.fls", "report.fdb_latexmk",
        }:
            continue
        yield path


def main():
    if not (ROOT / "report.tex").is_file() or not (ROOT / "report.pdf").is_file():
        raise SystemExit("Build report.tex and report.pdf before packaging.")
    entries = [{"path": str(path.relative_to(ROOT)), "bytes": path.stat().st_size,
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
               for path in payload_files()]
    manifest = {"package": ROOT.name, "manifest_excludes_itself": True,
                "files": entries}
    (ROOT / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
    target = ROOT.with_suffix(".zip")
    all_paths = [ROOT / item["path"] for item in entries] + [ROOT / "MANIFEST.json"]
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in all_paths:
            name = ROOT.name + "/" + str(path.relative_to(ROOT))
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 9, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())
    with zipfile.ZipFile(target) as archive:
        bad = archive.testzip()
        if bad is not None:
            raise RuntimeError("ZIP CRC failure: " + bad)
        for entry in entries:
            data = archive.read(ROOT.name + "/" + entry["path"])
            if len(data) != entry["bytes"] or hashlib.sha256(data).hexdigest() != entry["sha256"]:
                raise RuntimeError("Payload verification failed: " + entry["path"])
    print(json.dumps({"file": str(target), "payload_files": len(entries),
                      "archive_bytes": target.stat().st_size,
                      "sha256": hashlib.sha256(target.read_bytes()).hexdigest()}, indent=2))


if __name__ == "__main__":
    main()
