FIXED SEEDS AND THE iPRA PROOF-CHECKER FRONTIER
Research prepared for Vladimir Reshetnikov — 9 November 2026

STATUS FIRST
============
The requested new axiomatization below the current complete-checker frontier
has NOT been obtained. This package contains a precise mathematical result,
the complete inherited native basis, and reproducible evidence. It does not
claim absolute simplestness or a significant positive axiomatization
breakthrough.

MAIN MATHEMATICAL RESULT
=======================
Arbitrary iterator initialization cannot be eliminated by whole-domain term
translation into either of these languages built from zero, successor,
variables, composition, and scalar iteration with passive update parameters:

1. Positive numeral initializers only, even if EVERY positive numeral seed
   is available. No finite term defines addition or predecessor.
2. Zero initialization only. Every term's nonzero support is false or a
   conjunction of a subset of its input nonzeroness predicates. Addition,
   predecessor, and the zero indicator are not term-definable.

The positive case preserves R_K = (positive x positive) union [0,K]^2,
where K bounds the finite term's positive seeds. The universal proof uses
orbit alignment from a seed related to everything. It also gives a growth
bound: if t(0,...,0)=0, then t(a) <= max(K,a_1,...,a_r).

These are TERM-NONDEFINABILITY theorems. They do not rule out formula-defined
arithmetic, a different domain, arbitrary first-order bi-interpretations,
or the mixed grammar with both zero and positive seeds. They do not prove
a lower bound on checker size. Historical priority is not claimed.

START HERE
==========
report.pdf                  Main report with complete new proofs.
report.tex, sections/        Editable LaTeX source.
STATUS.json                 Machine-readable claim/status map.
code/seed_invariants.py      Scoped evaluator and exact support compiler.
code/test_seed_invariants.py Finite mathematical evidence.
code/audit_checkers.py       Frozen-source metrics and certificate replays.
reference/checkers/          Unchanged inherited complete checkers.
reference/theory/            Attributed inherited proof sources.
experiments/                 Clearly marked private-parameter experiments.
evidence/                    Actual validation and provenance receipts.

COMPARISON
==========
Pinned repository: VladimirReshetnikov/ProveIt
Commit: 08edc6964d8990d2230179a9d65355ac1eee7a9e
All 22 top-level docs/drafts ZIPs were downloaded and Git-blob verified.

Current coordinate envelope: 305 tokens / 340 AST nodes / 820 normalized bytes.
Different files attain these three minima. Excluding the iterable decoder
that relies on Python recursion guards for malformed strings raises the
AST minimum to 341. A historical identifier-renaming control reaches 816 bytes.
These are observed source-level implementation sizes, not mathematical
lower bounds.

An unregistered private-callable variant appears to save two bytes, but it
loses a legitimate fresh-parameter proof continuation. Its explicit registry
repair is larger than the inherited checker. The report gives the exact
scope of that failure and does not claim a global closed-theorem separation
without proof.

REPRODUCE
=========
Use CPython 3.12 for the recorded ast.unparse source measurements (actual
interpreter: 3.12.14). From this extracted directory:

    python3 reproduce.py
    python3 build.py
    python3 package.py

Evidence code uses only the Python standard library. PDF compilation needs
pdfLaTeX and standard packages listed in report.tex; shell escape is disabled.
No network access is needed to reproduce the evidence or build the paper.

Finite executable tests supplement the universal written proofs. The package
is not a Lean/Rocq formalization, and the inherited full iPRA interpretation
is not newly formally certified here. No repository write was performed.

See ATTRIBUTION.txt, reference/LICENSE-inherited.txt, and MANIFEST.json for
provenance, licensing, and payload integrity.
