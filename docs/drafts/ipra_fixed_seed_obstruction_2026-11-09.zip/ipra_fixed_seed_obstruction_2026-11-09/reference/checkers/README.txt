INHERITED COMPLETE CHECKERS

These six programs are copied byte-for-byte from four draft archives at
VladimirReshetnikov/ProveIt commit
08edc6964d8990d2230179a9d65355ac1eee7a9e.

provenance.json records each archive's exact repository path, pinned URL,
Git blob SHA-1, SHA-256, member path, and copied-file SHA-256. The assembly
step verified the archive Git blob identities before copying their members.
The archives themselves are not duplicated in this package.

Reproduce the whole-program measurements and fixture replays by running:

    python code/audit_checkers.py

The script works from any current directory when invoked by its actual path.
It writes evidence/measurements.csv and evidence/checker_validation.json.
It imports the metrics function from the unmodified source_measure.py helper.
The historical helper CLI also has a compatible manifest.json here, but only
the whole-program fields are used in this report; no core-only comparison is
claimed.

The iterable clock decoder has a smaller AST count but relies on CPython's
recursion limit for some noncanonical string inputs. It is excluded from the
strict structural-totality envelope. The other five comparison profiles use
strict array syntax. These are finite-corpus size comparisons, not proved
lower bounds for all possible theories or proof checkers.

See LICENSE-inherited.txt for the source license. The modified experiments
are separately identified under experiments/ and are not frontier successes.
