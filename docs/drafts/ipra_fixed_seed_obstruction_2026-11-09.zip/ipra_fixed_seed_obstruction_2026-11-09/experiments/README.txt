PRIVATE EIGENPARAMETER EXPERIMENTS — NO BELOW-FRONTIER CLAIM

private_unregistered_padded.py replaces numbered eigenparameters by fresh
private callable objects. An input packet cannot name those new objects.
That prevents the inherited canonical compiler from expressing later
equation majors and witnesses that use an already introduced parameter.
The program is diagnostic and is not claimed to be a complete proof checker.

The probe reference/fixtures/parameter_reflexivity_packet.json proves the
native theorem D_{x,y}(y=y). It contains five JSON cells: four instructions
(paired introduction, transport, and two computations) plus the goal.
The inherited checkers accept it; the unregistered program rejects it.

The local obstruction is precise. Paired introduction needs the step

    0=0, k=k |- S(k)=S(k)

for a private parameter k. The native proof uses I(0,S(k);0)=S(k) as both
premises of transport. JSON raw majors and payloads cannot contain k, so
their transport and closure-elimination conclusions cannot contain it.
The target is neither a hypothesis nor an iterator computation. Further
paired eliminations add only distinct new private parameters. Thus this
internal continuation cannot be certified by the unregistered program.
This establishes lost canonical proof translation; it does not by itself
prove that the closed theorem has no alternative global certificate.

private_registry_indexed.py and private_registry_padded.py repair the
representation by keeping an explicit list of allocated objects. The raw
name -j refers to allocation j-1; a reference to a future allocation fails.
They also normalize each incoming goal before comparing formulas, so numeric
references and private objects are not mixed in the same comparison.
Their registry, reference decoding, and normalization are included in every
reported whole-program measurement. Both repaired programs are larger than
the inherited frontier.

The audit replays the six original checkers and both registry repairs on
147 inherited positive packets, 13 inherited CLI cases, and the parameter
probe. It does this under both ordinary Python and python -O. The incomplete
unregistered program is run only on its specific rejection probe.
Finite replay is regression evidence, not a formal verification theorem.

Exact origin hashes and modifications are recorded in
reference/checkers/provenance.json. The inherited source license is in
reference/checkers/LICENSE-inherited.txt.
