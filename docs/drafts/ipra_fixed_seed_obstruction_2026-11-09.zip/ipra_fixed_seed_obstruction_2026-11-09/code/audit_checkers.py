#!/usr/bin/env python3
"""Measure whole checkers and replay their explicitly identified fixtures.

Run from any directory with Python 3.10 or later. No third-party packages are
needed. Measurements use the verbatim inherited source_measure.py helper;
only whole-program fields are used. No program is shortened before replay.
"""

import argparse
import ast
from concurrent.futures import ThreadPoolExecutor
import csv
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
PROVENANCE = ROOT / "reference/checkers/provenance.json"
METRIC_FIELDS = (
    "source_tokens", "normalized_tokens", "ast_nodes",
    "normalized_bytes", "raw_bytes", "sha256",
)
MODES = {"normal": (), "optimized": ("-O",)}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_measurement_helper():
    path = ROOT / "reference/checkers/source_measure.py"
    spec = importlib.util.spec_from_file_location("inherited_source_measure", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Cannot load the inherited measurement helper")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_copies(provenance):
    checked = []
    for item in provenance["programs"] + provenance["additional_files"]:
        path = ROOT / item["local_file"]
        actual = digest(path)
        if actual != item["sha256"]:
            raise ValueError("Changed evidence file: " + item["local_file"])
        checked.append({"file": item["local_file"], "sha256": actual})
    return checked


def measure_programs(provenance):
    helper = load_measurement_helper()
    rows = []
    for item in provenance["programs"]:
        path = ROOT / item["local_file"]
        metrics = helper.metrics(path)
        tree = ast.parse(path.read_text(encoding="utf-8"))
        rows.append({
            "label": item["label"],
            "kind": item["kind"],
            "file": item["local_file"],
            **{field: metrics[field] for field in METRIC_FIELDS},
            "assert_nodes": sum(isinstance(node, ast.Assert) for node in ast.walk(tree)),
        })
    return rows


def load_cases():
    fixtures = ROOT / "reference/fixtures"
    records = json.loads((fixtures / "positive_fixtures.json").read_text())["records"]
    positives = [{
        "name": "positive/" + row["id"] + "/" + row["name"],
        "group": "inherited_positive",
        "input": json.dumps(row["packet"], separators=(",", ":")),
        "native_expected_accept": True,
    } for row in records]
    rows = json.loads((fixtures / "cli_cases.json").read_text())["cases"]
    cli = [{
        "name": "cli/" + row["name"],
        "group": "inherited_cli",
        "input": row["input_text"],
        "native_expected_accept": row["expected_accept"],
    } for row in rows]
    probe_text = (fixtures / "parameter_reflexivity_packet.json").read_text()
    packet = json.loads(probe_text)
    probe = {
        "name": "probe/parameter_reflexivity",
        "group": "canonical_parameter_probe",
        "input": probe_text,
        "native_expected_accept": True,
    }
    return positives + cli + [probe], probe, {
        "inherited_positive": len(positives),
        "inherited_cli": len(cli),
        "parameter_probe_cells": len(packet),
        "parameter_probe_instructions": len(packet) - 1,
    }


def text_output(value):
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return value or ""


def run_case(task):
    program, mode, case, timeout = task
    diagnostic = program["kind"] == "diagnostic_incomplete"
    expected = False if diagnostic else case["native_expected_accept"]
    command = [sys.executable, *MODES[mode], str(ROOT / program["local_file"])]
    environment = os.environ.copy()
    environment["PYTHONHASHSEED"] = "0"
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    result = {
        "program": program["label"], "mode": mode,
        "case": case["name"], "group": case["group"],
        "expected_program_accept": expected,
        "native_expected_accept": case["native_expected_accept"],
    }
    try:
        completed = subprocess.run(
            command, input=case["input"], text=True, capture_output=True,
            cwd=ROOT, env=environment, timeout=timeout, check=False,
        )
        output = completed.stdout.strip()
        accepted = completed.returncode == 0 and output == "ACCEPT"
        rejected = completed.returncode == 1 and output == "REJECT"
        protocol = (accepted or rejected) and not completed.stderr
        result.update({
            "accepted": accepted, "exit_code": completed.returncode,
            "stdout": output, "stderr": completed.stderr[:2000],
            "protocol_valid": protocol,
            "matches_expected_verdict": protocol and accepted == expected,
        })
    except subprocess.TimeoutExpired as exc:
        result.update({
            "accepted": False, "exit_code": None, "timed_out": True,
            "stdout": text_output(exc.stdout)[:2000],
            "stderr": text_output(exc.stderr)[:2000],
            "protocol_valid": False, "matches_expected_verdict": False,
        })
    return result


def summarize_replays(programs, results):
    summaries = []
    for program in programs:
        for mode in MODES:
            selected = [r for r in results
                        if r["program"] == program["label"] and r["mode"] == mode]
            groups = {}
            for result in selected:
                group = groups.setdefault(result["group"], {"run": 0, "matched": 0})
                group["run"] += 1
                group["matched"] += int(result["matches_expected_verdict"])
            summaries.append({
                "program": program["label"], "mode": mode, "groups": groups,
                "cases_run": len(selected),
                "expected_verdict_matches": sum(r["matches_expected_verdict"] for r in selected),
                "failures": [r for r in selected if not r["matches_expected_verdict"]],
                "parameter_probe": next(
                    (r for r in selected if r["group"] == "canonical_parameter_probe"), None),
            })
    normal = {(r["program"], r["case"]): r for r in results if r["mode"] == "normal"}
    differences = []
    for result in results:
        if result["mode"] != "optimized":
            continue
        prior = normal[(result["program"], result["case"])]
        compared = ("accepted", "exit_code", "stdout", "stderr", "protocol_valid")
        if any(prior.get(key) != result.get(key) for key in compared):
            differences.append({"normal": prior, "optimized": result})
    return summaries, differences


def envelope(rows, strict=False):
    originals = [row for row in rows if row["kind"] == "original"
                 and not (strict and row["label"] == "clock_iterable_340")]
    fields = ("normalized_tokens", "ast_nodes", "normalized_bytes")
    minima = {field: min(row[field] for row in originals) for field in fields}
    return {
        "minima": minima,
        "attainers": {field: [row["label"] for row in originals
                              if row[field] == minima[field]] for field in fields},
        "interpretation": "Coordinatewise attained sizes in the selected inherited corpus; not an axiomatization lower bound.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--jobs", type=int, default=8,
                        help="Maximum independent checker subprocesses (default: 8)")
    parser.add_argument("--timeout", type=float, default=10.0,
                        help="Seconds allowed per checker/fixture execution (default: 10)")
    options = parser.parse_args()
    if options.jobs < 1 or options.timeout <= 0:
        parser.error("jobs and timeout must be positive")
    provenance = json.loads(PROVENANCE.read_text())
    verified = verify_copies(provenance)
    measurements = measure_programs(provenance)
    cases, probe, counts = load_cases()
    tasks = []
    for program in provenance["programs"]:
        selected = [probe] if program["kind"] == "diagnostic_incomplete" else cases
        for mode in MODES:
            tasks.extend((program, mode, case, options.timeout) for case in selected)
    with ThreadPoolExecutor(max_workers=options.jobs) as executor:
        results = list(executor.map(run_case, tasks))
    summaries, differences = summarize_replays(provenance["programs"], results)
    failures = [r for r in results if not r["matches_expected_verdict"]]
    evidence = ROOT / "evidence"
    evidence.mkdir(exist_ok=True)
    with (evidence / "measurements.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=measurements[0].keys())
        writer.writeheader()
        writer.writerows(measurements)
    report = {
        "format": "ipra-checker-validation-v1",
        "repository": provenance["repository"], "pinned_commit": provenance["commit"],
        "python": platform.python_version(), "implementation": platform.python_implementation(),
        "audit_script_sha256": digest(Path(__file__)),
        "measurement_boundary": "Every complete standalone checker module, including imports, JSON input, acceptance/rejection and process exit. Comments and genuine docstrings alone are removed for normalized metrics.",
        "measurement_helper_sha256": digest(ROOT / "reference/checkers/source_measure.py"),
        "execution_modes": {name: list(flags) for name, flags in MODES.items()},
        "case_counts": counts, "executions": len(results),
        "expected_verdict_matches": len(results) - len(failures),
        "unexpected_results": len(failures),
        "normal_optimized_differences": differences,
        "source_integrity": verified, "measurements": measurements,
        "inherited_coordinate_envelope": envelope(measurements),
        "strict_decoder_coordinate_envelope": envelope(measurements, strict=True),
        "replays": summaries,
        "interpretation_limits": [
            "Finite regression tests do not prove universal soundness, completeness, termination, or bi-interpretability.",
            "The iterable decoder relies on a CPython recursion bound for some noncanonical string inputs and is excluded from the strict structural-totality envelope.",
            "The unregistered private-object checker is run only on the parameter probe. Its expected rejection exhibits a lost canonical proof; it is not a complete-checker candidate.",
            "The registered repairs restore the tested proof translation but are larger than the inherited frontier. No below-frontier claim is made for any experiment.",
            "Normalized byte counts are interpreter- and identifier-dependent. No renaming or removal of parser/verdict code is performed.",
        ],
        "ok": not failures and not differences,
    }
    (evidence / "checker_validation.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({
        "ok": report["ok"], "executions": len(results),
        "unexpected_results": len(failures),
        "normal_optimized_differences": len(differences),
        "inherited_envelope": report["inherited_coordinate_envelope"]["minima"],
        "strict_envelope": report["strict_decoder_coordinate_envelope"]["minima"],
        "outputs": ["evidence/checker_validation.json", "evidence/measurements.csv"],
    }, indent=2))
    if not report["ok"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
