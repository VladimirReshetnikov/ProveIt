"""Finite, reproducible evidence for the fixed-initializer obstruction.

Run from any directory:
    python /absolute/path/to/code/test_seed_invariants.py

The default receipt is ../evidence/seed_validation.json. These tests are
finite evidence for the executable definitions and the orbit argument.
They are not a machine-checked proof of the theorem over all naturals.
"""

from __future__ import annotations

import argparse
from functools import lru_cache
import hashlib
import itertools
import json
from pathlib import Path
import platform
import sys
import time
import unittest

from seed_invariants import (
    Const, EvaluationLimit, GrammarError, Iterate, Succ, Var,
    evaluate, initializers, node_count, positive_seed_bound, related,
    support_holds, term_from_data, term_to_data, validate, zero_seed_support,
)


HERE = Path(__file__).resolve().parent
RECEIPT: dict = {}
CONSTANTS = (0, 1, 2)
ARITY = 2
INPUT_VALUES = tuple(range(4))
EVALUATION_BUDGET = 100_000


@lru_cache(maxsize=None)
def terms_of_size(size: int, arity: int, seeds: tuple[int, ...]) -> tuple:
    """Enumerate every well-scoped AST of exactly the stated node count.

    Constants are exactly 0, 1, 2; iterator initializers are metadata and
    do not add a separate AST node. The update gains one bound variable.
    """
    if size == 1:
        return tuple(Const(c) for c in CONSTANTS) + tuple(Var(i) for i in range(arity))
    if size < 1:
        return ()
    result = [Succ(term) for term in terms_of_size(size - 1, arity, seeds)]
    for count_size in range(1, size - 1):
        update_size = size - 1 - count_size
        for seed in seeds:
            for count in terms_of_size(count_size, arity, seeds):
                for update in terms_of_size(update_size, arity + 1, seeds):
                    result.append(Iterate(seed, count, update))
    return tuple(result)


def finite_orbit(function: tuple[int, ...], seed: int) -> tuple[int, ...]:
    """All states occurring in the orbit, stopping at its first repeat."""
    orbit = []
    value = seed
    while value not in orbit:
        orbit.append(value)
        value = function[value]
    return tuple(orbit)


class SeedInvariantTests(unittest.TestCase):
    def test_ast_semantics_and_roundtrip(self):
        # J_3(n; u.Su) = n + 3. Var(0) in the body is the state.
        clock = Iterate(3, Var(0), Succ(Var(0)))
        # Passive parameter x is body variable 1, so a positive count
        # replaces the state by x, without binding the counter variable.
        reset = Iterate(1, Var(1), Var(1))
        # Nested loop: at each outer step add two to the old state.
        # The inner update's variable 1 is the outer state; its variable
        # 0 is the inner state. This example exercises distinct binders.
        nested = Iterate(0, Var(0), Iterate(0, Const(1), Succ(Succ(Var(1)))))
        cases = []
        for n in range(9):
            cases.append((clock, (n,), n + 3))
            cases.append((nested, (n,), 2 * n))
            for x in range(5):
                cases.append((reset, (x, n), 1 if n == 0 else x))
        for term, inputs, expected in cases:
            self.assertEqual(evaluate(term, inputs, budget=EVALUATION_BUDGET), expected)
            self.assertEqual(term_from_data(term_to_data(term), len(inputs)), term)
        RECEIPT["ast_examples"] = {"evaluated_examples": len(cases), "roundtrips": len(cases)}

    def test_rejects_malformed_or_unbound_syntax(self):
        bad_terms = (
            Const(-1), Const(True), Var(2), Var(-1),
            Iterate(-1, Const(0), Const(0)),
            Iterate(0, Var(2), Const(0)),
            Iterate(0, Const(0), Var(3)),
            Succ("not a term"),
        )
        for term in bad_terms:
            with self.assertRaises(GrammarError):
                validate(term, 2)
        bad_data = (
            {}, [], ["const"], ["const", 0, 1], ["var", 1.0],
            ["unknown", 0], ["iter", 0, ["const", 0]],
            ["iter", True, ["const", 0], ["const", 0]],
        )
        for value in bad_data:
            with self.assertRaises(GrammarError):
                term_from_data(value, 2)
        RECEIPT["syntax_rejections"] = {"ast_cases": len(bad_terms), "serialized_cases": len(bad_data)}

    def test_evaluation_budget_is_explicit(self):
        term = Iterate(0, Const(1000), Succ(Var(0)))
        with self.assertRaises(EvaluationLimit):
            evaluate(term, (), budget=10)
        self.assertEqual(evaluate(term, (), budget=3000), 1000)
        with self.assertRaises(GrammarError):
            evaluate(Const(0), (), budget=True)
        RECEIPT["budget"] = {"small_budget_rejected": 10, "sufficient_budget": 3000, "exact_value": 1000}

    def test_initializer_metadata_and_grammar_separation(self):
        term = Iterate(2, Const(0), Iterate(7, Const(0), Const(99)))
        self.assertEqual(initializers(term), frozenset((2, 7)))
        self.assertEqual(positive_seed_bound(term), 7)
        self.assertEqual(positive_seed_bound(Const(10**20)), 1)
        mixed = Succ(Iterate(0, Const(0), Const(0)))
        with self.assertRaises(GrammarError):
            positive_seed_bound(mixed)
        with self.assertRaises(GrammarError):
            zero_seed_support(Succ(term), 0)
        RECEIPT["grammar_separation"] = {
            "positive_bound": 7,
            "constants_do_not_increase_seed_bound": True,
            "positive_checker_rejects_hidden_zero_seed": True,
            "zero_compiler_rejects_hidden_positive_seed": True,
        }

    def test_exhaustive_three_element_orbit_alignment(self):
        # Enumerate every relation with the chosen seed related both ways
        # to every element. Reflexivity or symmetry away from the seed is
        # not assumed: the orbit lemma works with two-sided centrality.
        universe = tuple(range(3))
        functions = tuple(itertools.product(universe, repeat=3))
        relation_cases = compatible_pairs = candidate_pairs = orbit_checks = 0
        nonsymmetric_cases = nonreflexive_cases = 0
        for seed in universe:
            required = {(seed, x) for x in universe} | {(x, seed) for x in universe}
            optional = tuple(pair for pair in itertools.product(universe, repeat=2) if pair not in required)
            for mask in range(1 << len(optional)):
                relation = required | {pair for bit, pair in enumerate(optional) if mask & (1 << bit)}
                relation_cases += 1
                nonsymmetric_cases += any((y, x) not in relation for x, y in relation)
                nonreflexive_cases += any((x, x) not in relation for x in universe)
                for left in functions:
                    for right in functions:
                        candidate_pairs += 1
                        if not all((left[x], right[y]) in relation for x, y in relation):
                            continue
                        compatible_pairs += 1
                        # A finite deterministic orbit has no new states
                        # after its first repeat. Thus these sets cover all
                        # iteration counts in this particular finite model.
                        for x in finite_orbit(left, seed):
                            for y in finite_orbit(right, seed):
                                orbit_checks += 1
                                self.assertIn((x, y), relation)
        self.assertEqual(relation_cases, 48)
        self.assertEqual(candidate_pairs, 48 * 27 * 27)
        RECEIPT["central_relation_orbits"] = {
            "universe_size": 3,
            "relation_seed_configurations": relation_cases,
            "nonsymmetric_configurations": nonsymmetric_cases,
            "nonreflexive_configurations": nonreflexive_cases,
            "unary_functions": len(functions),
            "function_pair_configurations_examined": candidate_pairs,
            "compatible_function_pair_configurations": compatible_pairs,
            "orbit_cross_pairs_checked": orbit_checks,
            "orbit_enumeration": "all distinct states through first repeat; all time indices covered in each finite model",
        }

    def test_exhaustive_zero_seed_support(self):
        environments = tuple(itertools.product(INPUT_VALUES, repeat=ARITY))
        counts_by_size = {}
        observed_supports = set()
        evaluations = 0
        for size in range(1, 6):
            terms = terms_of_size(size, ARITY, (0,))
            self.assertEqual(len(set(terms)), len(terms))
            counts_by_size[str(size)] = len(terms)
            for term in terms:
                self.assertEqual(node_count(term), size)
                support = zero_seed_support(term, ARITY)
                observed_supports.add(None if support is None else tuple(sorted(support)))
                for environment in environments:
                    value = evaluate(term, environment, budget=EVALUATION_BUDGET)
                    evaluations += 1
                    self.assertEqual(value != 0, support_holds(support, environment),
                                     (term_to_data(term), environment, value, support))
        self.assertEqual(observed_supports, {None, (), (0,), (1,), (0, 1)})
        RECEIPT["zero_seed_support"] = {
            "free_variables": ARITY,
            "constants": list(CONSTANTS),
            "initializers": [0],
            "maximum_ast_nodes": 5,
            "terms_by_exact_size": counts_by_size,
            "total_terms": sum(counts_by_size.values()),
            "input_values": list(INPUT_VALUES),
            "environments_per_term": len(environments),
            "evaluations": evaluations,
            "all_five_possible_supports_observed": True,
            "per_evaluation_ast_visit_budget": EVALUATION_BUDGET,
            "budget_exhaustions": 0,
        }

    def test_exhaustive_small_positive_terms_preserve_relation(self):
        environments = tuple(itertools.product(INPUT_VALUES, repeat=ARITY))
        counts_by_size = {}
        evaluations = relation_checks = zero_origin_bound_checks = 0
        # Five nodes includes nested iterations, not only flat updates.
        for size in range(1, 6):
            terms = terms_of_size(size, ARITY, (1, 2))
            self.assertEqual(len(set(terms)), len(terms))
            counts_by_size[str(size)] = len(terms)
            for term in terms:
                validate(term, ARITY)
                k = positive_seed_bound(term)
                values = {environment: evaluate(term, environment, budget=EVALUATION_BUDGET)
                          for environment in environments}
                evaluations += len(values)
                for left in environments:
                    for right in environments:
                        if all(related(k, x, y) for x, y in zip(left, right)):
                            relation_checks += 1
                            self.assertTrue(related(k, values[left], values[right]),
                                            (term_to_data(term), k, left, right, values))
                if values[(0, 0)] == 0:
                    for environment, value in values.items():
                        zero_origin_bound_checks += 1
                        self.assertLessEqual(value, max((k,) + environment))
        RECEIPT["positive_seed_preservation"] = {
            "free_variables": ARITY,
            "constants": list(CONSTANTS),
            "initializers": [1, 2],
            "maximum_ast_nodes": 5,
            "terms_by_exact_size": counts_by_size,
            "total_terms": sum(counts_by_size.values()),
            "input_values": list(INPUT_VALUES),
            "environments_per_term": len(environments),
            "evaluations": evaluations,
            "related_input_pair_checks": relation_checks,
            "zero_origin_quantitative_bound_checks": zero_origin_bound_checks,
            "per_evaluation_ast_visit_budget": EVALUATION_BUDGET,
            "budget_exhaustions": 0,
        }

    def test_addition_predecessor_and_support_witnesses(self):
        witnesses = []
        for k in range(1, 9):
            self.assertTrue(related(k, 0, k))
            self.assertFalse(related(k, 0, 2 * k))
            self.assertTrue(related(k, 1, k + 2))
            self.assertFalse(related(k, 0, k + 1))
            witnesses.append({
                "K": k,
                "addition": {"left_inputs": [0, 0], "right_inputs": [k, k],
                             "left_output": 0, "right_output": 2 * k},
                "predecessor": {"left_input": 1, "right_input": k + 2,
                                "left_output": 0, "right_output": k + 1},
            })
        boolean_inputs = tuple(itertools.product((0, 1), repeat=2))
        addition_support = tuple(x + y != 0 for x, y in boolean_inputs)
        permitted = (None, frozenset(), frozenset((0,)), frozenset((1,)), frozenset((0, 1)))
        for support in permitted:
            self.assertNotEqual(addition_support,
                                tuple(support_holds(support, values) for values in boolean_inputs))
        RECEIPT["negative_witnesses"] = {
            "positive_seed_bounds": list(range(1, 9)),
            "witnesses": witnesses,
            "zero_seed_addition_input_order": [list(values) for values in boolean_inputs],
            "addition_nonzero_support": list(addition_support),
            "excluded_conjunctive_supports": len(permitted),
            "zero_seed_predecessor_witness": {"inputs": [1, 2], "outputs": [0, 1],
                                              "same_input_nonzero_flag": True},
            "zero_seed_zero_indicator_witness": {"inputs": [0, 1], "outputs": [1, 0]},
        }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=HERE.parent / "evidence" / "seed_validation.json")
    args = parser.parse_args()
    started = time.perf_counter()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(SeedInvariantTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    receipt = {
        "status": "passed" if result.wasSuccessful() else "failed",
        "scope": "Finite executable evidence; universal theorem supplied by the written proof, not formally verified by these tests.",
        "python": platform.python_version(),
        "tests_run": result.testsRun,
        "failures": len(result.failures),
        "errors": len(result.errors),
        "elapsed_seconds": round(time.perf_counter() - started, 6),
        "source_sha256": {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest()
                          for name in ("seed_invariants.py", "test_seed_invariants.py")},
        "results": RECEIPT,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print(f"Receipt: {args.output}")
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(main())
