"""Executable definitions supporting the fixed-initializer obstruction.

This module is an AST evaluator and an exact zero-seed support compiler.
It is not an iPRA proof checker, a proof-search procedure, or a formal
verification of the universal theorem in the accompanying manuscript.

The grammar is:
    Const(c)                  a natural-number constant
    Var(i)                    the i-th value in the current environment
    Succ(t)                   successor
    Iterate(c, n, h)          iterate h, starting at numeral c, n times

Only h binds a variable. In h, Var(0) denotes the current state, and
Var(i + 1) denotes the i-th outer variable. The counter n is evaluated
in the unchanged outer environment. Thus parameters are passive.

The optional JSON representation uses arrays with tags "const", "var",
"succ", and "iter". No serialized input is executed as Python code.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TypeAlias


class GrammarError(ValueError):
    """The supplied value is not a well-scoped term of the requested grammar."""


class EvaluationLimit(RuntimeError):
    """The caller's explicitly supplied evaluation budget was exhausted."""


@dataclass(frozen=True)
class Const:
    value: int


@dataclass(frozen=True)
class Var:
    index: int


@dataclass(frozen=True)
class Succ:
    argument: Term


@dataclass(frozen=True)
class Iterate:
    seed: int
    counter: Term
    update: Term


Term: TypeAlias = Const | Var | Succ | Iterate
Support: TypeAlias = frozenset[int] | None


def _natural(value: object, label: str) -> int:
    # Boolean and floating-point aliases are deliberately excluded.
    if type(value) is not int or value < 0:
        raise GrammarError(f"{label} must be a nonnegative integer")
    return value


def validate(term: Term, arity: int) -> None:
    """Validate the entire AST, including branches irrelevant to support."""
    _natural(arity, "arity")
    if type(term) is Const:
        _natural(term.value, "constant")
    elif type(term) is Var:
        if _natural(term.index, "variable index") >= arity:
            raise GrammarError(f"variable {term.index} is outside arity {arity}")
    elif type(term) is Succ:
        validate(term.argument, arity)
    elif type(term) is Iterate:
        _natural(term.seed, "initializer")
        validate(term.counter, arity)
        validate(term.update, arity + 1)
    else:
        raise GrammarError("unknown AST constructor")


def node_count(term: Term) -> int:
    """Count AST constructors; the numeral seed is metadata of its node."""
    if type(term) in (Const, Var):
        return 1
    if type(term) is Succ:
        return 1 + node_count(term.argument)
    if type(term) is Iterate:
        return 1 + node_count(term.counter) + node_count(term.update)
    raise GrammarError("unknown AST constructor")


def initializers(term: Term) -> frozenset[int]:
    """Return every initializer occurring anywhere in the finite AST."""
    if type(term) is Const:
        _natural(term.value, "constant")
        return frozenset()
    if type(term) is Var:
        _natural(term.index, "variable index")
        return frozenset()
    if type(term) is Succ:
        return initializers(term.argument)
    if type(term) is Iterate:
        seed = _natural(term.seed, "initializer")
        return frozenset((seed,)) | initializers(term.counter) | initializers(term.update)
    raise GrammarError("unknown AST constructor")


def positive_seed_bound(term: Term) -> int:
    """Return a valid K >= 1, rejecting any zero-initialized iteration.

    Constants of arbitrary size are allowed. Only iterator initializers
    enter K, because every constant function preserves the relation R_K.
    This checks initializer metadata; use validate for variable scoping.
    """
    seeds = initializers(term)
    if 0 in seeds:
        raise GrammarError("a positive-seed term may not contain initializer zero")
    return max(seeds, default=1)


def evaluate(term: Term, environment: tuple[int, ...], *, budget: int | None = None) -> int:
    """Evaluate a well-scoped term with the exact natural-number semantics.

    If supplied, budget bounds visits to AST nodes and raises
    EvaluationLimit on exhaustion. It never returns an approximate result.
    Without a budget this is the ordinary terminating recursive semantics;
    ordinary Python recursion and memory limits still apply.
    """
    environment = tuple(environment)
    for value in environment:
        _natural(value, "environment value")
    validate(term, len(environment))
    if budget is not None:
        _natural(budget, "evaluation budget")
    remaining = budget

    def run(expression: Term, values: tuple[int, ...]) -> int:
        nonlocal remaining
        if remaining is not None:
            if remaining == 0:
                raise EvaluationLimit("AST-visit budget exhausted")
            remaining -= 1
        if type(expression) is Const:
            return expression.value
        if type(expression) is Var:
            return values[expression.index]
        if type(expression) is Succ:
            return run(expression.argument, values) + 1
        count = run(expression.counter, values)
        state = expression.seed
        for _ in range(count):
            state = run(expression.update, (state,) + values)
        return state

    return run(term, environment)


def zero_seed_support(term: Term, arity: int) -> Support:
    """Compile the exact predicate 'term != 0' for the zero-seed grammar.

    None denotes false. A frozenset A denotes the conjunction of x_i != 0
    for i in A; the empty frozenset denotes true. This compiler follows
    the manuscript's structural proof, including the update-state test.
    """
    validate(term, arity)
    if initializers(term) - {0}:
        raise GrammarError("the support compiler accepts only zero initializers")

    def conjunction(left: Support, right: Support) -> Support:
        if left is None or right is None:
            return None
        return left | right

    def compile_support(expression: Term) -> Support:
        if type(expression) is Const:
            return frozenset() if expression.value else None
        if type(expression) is Var:
            return frozenset((expression.index,))
        if type(expression) is Succ:
            return frozenset()
        count_support = compile_support(expression.counter)
        update_support = compile_support(expression.update)
        # Set the bound state variable to zero. A required state conjunct
        # makes the first update zero, after which the orbit stays zero.
        if update_support is None or 0 in update_support:
            initial_update_support = None
        else:
            initial_update_support = frozenset(i - 1 for i in update_support)
        return conjunction(count_support, initial_update_support)

    return compile_support(term)


def support_holds(support: Support, environment: tuple[int, ...]) -> bool:
    for value in environment:
        _natural(value, "environment value")
    if support is None:
        return False
    for index in support:
        if _natural(index, "support index") >= len(environment):
            raise GrammarError("support refers to a missing variable")
    return all(environment[index] != 0 for index in support)


def related(k: int, left: int, right: int) -> bool:
    """R_K = (positive x positive) union ([0,K] x [0,K])."""
    if _natural(k, "relation bound") == 0:
        raise GrammarError("R_K requires K >= 1")
    _natural(left, "left relation argument")
    _natural(right, "right relation argument")
    return (left > 0 and right > 0) or (left <= k and right <= k)


def term_to_data(term: Term) -> list:
    """Encode an AST using the documented JSON-compatible array grammar."""
    if type(term) is Const:
        return ["const", term.value]
    if type(term) is Var:
        return ["var", term.index]
    if type(term) is Succ:
        return ["succ", term_to_data(term.argument)]
    if type(term) is Iterate:
        return ["iter", term.seed, term_to_data(term.counter), term_to_data(term.update)]
    raise GrammarError("unknown AST constructor")


def term_from_data(data: object, arity: int) -> Term:
    """Decode arrays and validate the complete result, without evaluation."""
    def decode(value: object) -> Term:
        if type(value) is not list or not value or type(value[0]) is not str:
            raise GrammarError("each AST node must be a tagged array")
        if value[0] == "const" and len(value) == 2:
            return Const(value[1])
        if value[0] == "var" and len(value) == 2:
            return Var(value[1])
        if value[0] == "succ" and len(value) == 2:
            return Succ(decode(value[1]))
        if value[0] == "iter" and len(value) == 4:
            return Iterate(value[1], decode(value[2]), decode(value[3]))
        raise GrammarError("unknown tag or wrong node arity")

    term = decode(data)
    validate(term, arity)
    return term
