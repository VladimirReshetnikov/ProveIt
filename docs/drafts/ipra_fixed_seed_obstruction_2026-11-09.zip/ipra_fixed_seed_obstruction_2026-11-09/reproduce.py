"""Run the finite evidence and frozen-source comparisons, without network access."""
from pathlib import Path
import json
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    runs = []
    for relative in ("code/test_seed_invariants.py", "code/audit_checkers.py"):
        result = subprocess.run(
            [sys.executable, str(ROOT / relative)],
            cwd=ROOT, text=True, capture_output=True,
        )
        runs.append({"script": relative, "returncode": result.returncode,
                     "stdout": result.stdout, "stderr": result.stderr})
        print(relative, "PASS" if result.returncode == 0 else "FAIL", flush=True)
        if result.returncode:
            print(result.stdout)
            print(result.stderr, file=sys.stderr)
            break
    receipt = {"python": platform.python_version(), "runs": runs,
               "passed": len(runs) == 2 and all(r["returncode"] == 0 for r in runs)}
    (ROOT / "evidence/reproduction.json").write_text(
        json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    if not receipt["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
