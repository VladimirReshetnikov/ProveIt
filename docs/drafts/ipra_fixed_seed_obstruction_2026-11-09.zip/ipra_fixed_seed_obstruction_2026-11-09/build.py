"""Compile the report in a temporary directory, with shell escape disabled."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def main():
    executable = shutil.which("pdflatex")
    if executable is None:
        raise SystemExit("pdflatex is required; the compiled report.pdf is supplied.")
    runs = []
    with tempfile.TemporaryDirectory(prefix="ipra-latex-") as temporary:
        command = [executable, "-no-shell-escape", "-interaction=nonstopmode",
                   "-halt-on-error", "-file-line-error", "-output-directory",
                   temporary, "report.tex"]
        for number in range(1, 4):
            result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
            runs.append({"pass": number, "returncode": result.returncode})
            (ROOT / "evidence/build.log").write_text(result.stdout + result.stderr)
            if result.returncode:
                print(result.stdout[-8000:])
                raise SystemExit(result.returncode)
        final_log = (Path(temporary) / "report.log").read_text(errors="replace")
        (ROOT / "evidence/build.log").write_text(final_log)
        pdf = (Path(temporary) / "report.pdf").read_bytes()
        (ROOT / "report.pdf").write_bytes(pdf)
    warnings = [line for line in final_log.splitlines()
                if "Warning" in line or "Overfull" in line or "Underfull" in line]
    receipt = {"runs": runs, "shell_escape": False,
               "pdf_bytes": len(pdf), "pdf_sha256": hashlib.sha256(pdf).hexdigest(),
               "warnings": warnings}
    (ROOT / "evidence/build.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
