FROZEN SOURCE COMPARISON
========================

The six current main sources and their ten direct packaged controls were
read from VladimirReshetnikov/ProveIt at commit
9e338a5c51a26ac6ae90f2d8f563a44c3879ba68.

current/ contains the six complete main acceptance programs, byte-for-byte.
current_controls/ contains the ten direct control programs, byte-for-byte.
provenance.json identifies each archive, Git blob SHA, archive SHA-256,
member path, and copied source SHA-256. snapshot.json records the fetched
directory listing. The original archive bytes were verified against their
Git blob identities before extraction.

Run from any working directory:

    python3 /path/to/package/measure.py

No comparator is executed by the measurement program. It parses each
complete source, checks its digest, removes only actual docstrings,
comments, and layout for the relevant measures, and records the result.
It includes validation, substitution, schema generation, imports, input
handling, and CLI rejection logic. No local checker dependencies are
silently excluded. Python and its standard library are the common runtime.

results/metrics.json gives all source measures and coordinate minima.
results/comparison_table.tex gives the six-main-source table plus the new
checker. The ten direct controls do not lower any coordinate minimum.
results/metrics_macros.tex supplies the report's measured values.

Original significant tokens and ast.unparse-normalized tokens are both
reported because optional Python punctuation can affect the first count.
Raw bytes include comments and original formatting; normalized bytes use
the docstring-stripped ast.unparse output plus a trailing newline. Source
line counts count physical lines touched by significant lexical tokens.
The recorded run uses Python 3.12.14. A different Python release may format
normalized source differently; source hashes and original token counts
identify exactly what is being compared.

These are implementation upper bounds and finite comparisons. They are
not an absolute mathematical lower bound on all proof checkers.

The historical independent checker used for executable cross-checks is
separately frozen in validation/baseline_checker.py and identified in
provenance.json. It is not mislabeled as a current main proposal.
