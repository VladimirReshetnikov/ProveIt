"""Build the report with pdfLaTeX through latexmk; no network is needed."""

from pathlib import Path
import hashlib
import json
import shutil
import subprocess


ROOT = Path(__file__).resolve().parent


def main():
    build = ROOT / "build"
    build.mkdir(exist_ok=True)
    command = ["latexmk", "-pdf", "-interaction=nonstopmode",
               "-halt-on-error", "-outdir=build", "report.tex"]
    process = subprocess.run(command, cwd=ROOT, text=True,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (build / "build_output.txt").write_text(process.stdout, encoding="utf-8")
    if process.returncode:
        print(process.stdout[-12000:])
        raise SystemExit(process.returncode)
    source = build / "report.pdf"
    if not source.is_file():
        raise SystemExit("The LaTeX build did not produce report.pdf")
    destination = ROOT / "report.pdf"
    shutil.copyfile(source, destination)
    log = (build / "report.log").read_text(encoding="utf-8", errors="replace")
    warnings = [line for line in log.splitlines()
                if "Overfull" in line or "LaTeX Warning" in line]
    result = {"status": "passed", "pdf": "report.pdf",
              "bytes": destination.stat().st_size,
              "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
              "warnings": warnings}
    (ROOT / "results" / "build.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
