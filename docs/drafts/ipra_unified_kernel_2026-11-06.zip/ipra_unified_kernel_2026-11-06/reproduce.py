"""Reproduce the size measurements, proof checks, audits, and optional PDF."""

import argparse
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--no-pdf", action="store_true",
                        help="Run all code checks without invoking LaTeX.")
    args = parser.parse_args()
    jobs = [
        ["measure.py"],
        ["validation/run_all.py"],
        ["arithmetic/verify.py", "--checker", "checker.py"],
        ["independent_audit/audit.py", "--candidate", "checker.py",
         "--reference", "comparison/current/unary_existential.py",
         "--output", "independent_audit/results.json"],
    ]
    if not args.no_pdf:
        jobs.append(["build.py"])
    for command in jobs:
        print("Running " + " ".join(command), flush=True)
        subprocess.run([sys.executable, *command], cwd=ROOT, check=True)
    print("PASS: all requested reproduction stages completed.", flush=True)


if __name__ == "__main__":
    main()
