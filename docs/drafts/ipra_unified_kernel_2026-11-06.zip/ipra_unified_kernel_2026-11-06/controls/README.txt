COMPLETE IMPLEMENTATION CONTROL
================================

typed_prefix_unary.py implements the same unary calculus, public-falsity
conversion, direct numerical-base substitution, and certificate format as
checker.py. Its validating traversal uses a constructor-index table and
explicit binder-position tests in place of the shared SCOPES table.

The entire file is an alternative acceptance program. It imports only
json and sys. It is measured independently by measure.py and replays all
177 package certificates with the same expected outcomes in
validation/run_all.py. It is not imported by the recommended checker.

This control has fewer normalized bytes than the recommended source but
more tokens and AST nodes. It is included to make that implementation
tradeoff visible. Both are below the corresponding current-draft minima.
