#!/usr/bin/env python3
"""Independent adversarial audit of the typed-traversal iPRA kernel.

This is untrusted test code, not part of the acceptance program.  Its
substitution oracle converts to uniquely named bound variables, substitutes
free names, then converts back.  It does not call either checker's syntax,
substitution, inference, or falsity-conversion helpers to compute expected
answers.  The only checker methods called are the operations under test.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import json
import random
import subprocess
import sys
import tempfile
from pathlib import Path

Z = -1
T = ["=", Z, Z]
D = ["=", Z, ["s", Z]]
FALSE = ["false"]
EXPECTED_REJECTIONS = (ValueError, TypeError, IndexError, KeyError,
                       RecursionError, OSError)


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


def shape(a, formula):
    """Separate declarative grammar; no scopes-table implementation."""
    if formula:
        if a == FALSE:
            return copy.deepcopy(D)
        if type(a) is not list or not a:
            raise ValueError("not a formula")
        if a[0] == "=" and len(a) == 3:
            return ["=", shape(a[1], False), shape(a[2], False)]
        if a[0] == "pi" and len(a) == 3:
            return ["pi", shape(a[1], True), shape(a[2], True)]
        if a[0] == "ex" and len(a) == 2:
            return ["ex", shape(a[1], True)]
        raise ValueError("not a formula constructor")
    if type(a) is int and a >= -1:
        return a
    if type(a) is not list or not a:
        raise ValueError("not a term")
    if a[0] == "s" and len(a) == 2:
        return ["s", shape(a[1], False)]
    if a[0] == "r" and len(a) == 4:
        return ["r", shape(a[1], False), shape(a[2], False),
                shape(a[3], False)]
    raise ValueError("not a term constructor")


def named(a, stack=(), label="main", path=()):
    """Encode already checked syntax with explicit free and bound names."""
    if type(a) is int:
        if a == Z:
            return ("zero",)
        if a < len(stack):
            return ("bound", stack[a])
        return ("free", a - len(stack))
    tag = a[0]
    if tag == "s":
        return ("s", named(a[1], stack, label, path + (0,)))
    if tag == "=":
        return ("=", named(a[1], stack, label, path + (0,)),
                named(a[2], stack, label, path + (1,)))
    if tag == "r":
        state = (label, path, "state")
        counter = (label, path, "counter")
        return ("r", named(a[1], stack, label, path + (0,)),
                named(a[2], stack, label, path + (1,)), state, counter,
                named(a[3], (state, counter) + stack, label, path + (2,)))
    if tag == "pi":
        var = (label, path, "pi")
        return ("pi", var,
                named(a[1], (var,) + stack, label, path + (0,)),
                named(a[2], (var,) + stack, label, path + (1,)))
    if tag == "ex":
        var = (label, path, "ex")
        return ("ex", var, named(a[1], (var,) + stack, label, path + (0,)))
    raise AssertionError("oracle was given unvalidated syntax")


def replace_free(a, replacements, shift):
    tag = a[0]
    if tag in ("zero", "bound"):
        return a
    if tag == "free":
        j = a[1]
        return replacements[j] if j < len(replacements) else ("free", j + shift)
    if tag == "s":
        return ("s", replace_free(a[1], replacements, shift))
    if tag == "=":
        return ("=", replace_free(a[1], replacements, shift),
                replace_free(a[2], replacements, shift))
    if tag == "r":
        return ("r", replace_free(a[1], replacements, shift),
                replace_free(a[2], replacements, shift), a[3], a[4],
                replace_free(a[5], replacements, shift))
    if tag == "pi":
        return ("pi", a[1], replace_free(a[2], replacements, shift),
                replace_free(a[3], replacements, shift))
    if tag == "ex":
        return ("ex", a[1], replace_free(a[2], replacements, shift))
    raise AssertionError(tag)


def indexed(a, stack=()):
    tag = a[0]
    if tag == "zero":
        return Z
    if tag == "bound":
        return stack.index(a[1])
    if tag == "free":
        assert a[1] >= 0
        return a[1] + len(stack)
    if tag == "s":
        return ["s", indexed(a[1], stack)]
    if tag == "=":
        return ["=", indexed(a[1], stack), indexed(a[2], stack)]
    if tag == "r":
        return ["r", indexed(a[1], stack), indexed(a[2], stack),
                indexed(a[5], (a[3], a[4]) + stack)]
    if tag == "pi":
        return ["pi", indexed(a[2], (a[1],) + stack),
                indexed(a[3], (a[1],) + stack)]
    if tag == "ex":
        return ["ex", indexed(a[2], (a[1],) + stack)]
    raise AssertionError(tag)


def oracle(a, env=(0,), depth=0, formula=True):
    checked = shape(a, formula)
    outer = tuple(("outer", i) for i in range(depth))
    replacements = tuple(named(shape(t, False), label=("replacement", i))
                         for i, t in enumerate(env[:-1]))
    abstract = named(checked, outer)
    replaced = replace_free(abstract, replacements, env[-1])
    return indexed(replaced, outer)


def lift(a, k=1, formula=True):
    return oracle(a, (k,), formula=formula)


def num_axiom(a, induction=None):
    a = shape(a, True)
    base = oracle(a, [Z, 0])
    if induction is None:
        induction = a[0] == "="
    guard = a if induction else base
    step = ["pi", guard, oracle(a, [["s", 0], 0])]
    return ["pi", base, ["pi", lift(step, 2), lift(a)]]


def reflexivity(t=Z):
    r = ["r", Z, t, Z]
    p = ["rec", r]
    return ["use", p, ["=", 0, lift(t, formula=False)], p]


def hypothesis(a):
    return ["hyp", a]


def outcome(module, data):
    try:
        value = module.check(copy.deepcopy(data))
        return "ACCEPT" if value is True else "OTHER_RETURN"
    except EXPECTED_REJECTIONS:
        return "REJECT"
    except Exception as e:
        return "UNCAUGHT_" + type(e).__name__


def term(rng, depth):
    if depth <= 0 or rng.randrange(4) == 0:
        return rng.choice([Z, 0, 1, 2, 3, 5, 9, 31])
    if rng.randrange(2):
        return ["s", term(rng, depth - 1)]
    return ["r", term(rng, depth - 1), term(rng, depth - 1),
            term(rng, depth - 1)]


def formula(rng, depth, public=False):
    if depth <= 0 or rng.randrange(3) == 0:
        if public and rng.randrange(5) == 0:
            return copy.deepcopy(FALSE)
        return ["=", term(rng, min(depth, 2)), term(rng, min(depth, 2))]
    if rng.randrange(2):
        return ["pi", formula(rng, depth - 1, public),
                formula(rng, depth - 1, public)]
    return ["ex", formula(rng, depth - 1, public)]


def targeted_cases():
    out = []
    def add(name, data, expected="ACCEPT", old=None):
        out.append((name, data, expected, expected if old is None else old))

    add("closed_reflexivity", [[], T, reflexivity()])
    add("parameter_reflexivity", [[], ["=", 0, 0], reflexivity(0)])
    atom = ["=", 0, 0]
    add("pi_identity", [[], ["pi", atom, atom], ["pi", atom, hypothesis(atom)]])
    add("existential_witness_zero", [[], ["ex", ["=", 0, Z]],
        ["pack", Z, hypothesis(["=", 0, Z])]])
    add("existential_witness_parameter", [[], ["ex", ["=", 0, 1]],
        ["pack", 0, hypothesis(["=", 0, 1])]])
    ex = ["ex", ["=", 0, 1]]
    opened = ["=", 0, 1]
    branch = ["use", hypothesis(opened), ["=", 0, 2], hypothesis(opened)]
    add("existential_elimination_retained_parameter", [[ex], ["=", 0, 0],
        ["use", hypothesis(ex), ["=", 0, 0], branch]])
    exzero = ["ex", ["=", 0, Z]]
    add("reject_existential_witness_escape", [[exzero], ["=", 0, Z],
        ["use", hypothesis(exzero), ["=", 0, Z], hypothesis(["=", 0, Z])]], "REJECT")
    oldzero = ["=", 0, Z]
    exref = ["ex", ["=", 0, 0]]
    add("reject_existential_context_capture", [[oldzero, exref], oldzero,
        ["use", hypothesis(exref), oldzero, hypothesis(oldzero)]], "REJECT")
    add("reject_pack_context_capture", [[oldzero], ["ex", ["=", 0, Z]],
        ["pack", 0, hypothesis(oldzero)]], "REJECT")
    add("pi_retained_context_lift", [[oldzero], ["pi", T, ["=", 1, Z]],
        ["pi", T, hypothesis(["=", 1, Z])]])
    add("reject_pi_context_capture", [[oldzero], ["pi", T, oldzero],
        ["pi", T, hypothesis(oldzero)]], "REJECT")

    for name, a in [("atomic", ["=", 0, ["s", 1]]),
                    ("existential", ["ex", ["=", 0, 1]]),
                    ("universal", ["pi", ["=", 0, Z], ["=", 1, Z]])]:
        add("numerical_" + name, [[], num_axiom(a), ["nat", a]])
        if name != "atomic":
            add("reject_quantified_induction_" + name,
                [[], num_axiom(a, True), ["nat", a]], "REJECT")

    add("false_top_and_hypothesis", [[FALSE], FALSE, hypothesis(FALSE)])
    add("false_key_core_context", [[D], D, hypothesis(FALSE)])
    add("false_context_core_key", [[FALSE], FALSE, hypothesis(D)])
    add("false_pi_annotation_and_key", [[], ["pi", FALSE, FALSE],
        ["pi", FALSE, hypothesis(FALSE)]])
    add("false_nested_hypothesis_key", [[["ex", ["pi", T, FALSE]]],
        ["ex", ["pi", T, D]], hypothesis(["ex", ["pi", T, FALSE]])])
    add("false_equality_template", [[FALSE], FALSE,
        ["use", reflexivity(), FALSE, hypothesis(FALSE)]])
    exfalse = ["ex", FALSE]
    add("false_existential_goal_annotation", [[exfalse], FALSE,
        ["use", hypothesis(exfalse), FALSE, hypothesis(FALSE)]])
    add("false_numerical_annotation", [[], num_axiom(FALSE), ["nat", FALSE]])
    add("false_in_successor_numerical_body", [[], num_axiom(["pi", FALSE, ["=", 0, Z]]),
        ["nat", ["pi", FALSE, ["=", 0, Z]]]])
    add("false_in_pack_body_proof", [[FALSE], ["ex", FALSE],
        ["pack", Z, hypothesis(FALSE)]])

    invalid_terms = [False, True, 0.0, -1.0, -2, "0", None, [],
                     ["s"], ["s", Z, Z], ["r", Z, Z],
                     ["r", Z, Z, Z, Z], ["=" , Z, Z], FALSE,
                     ["s", FALSE], ["unknown", Z], [[], Z],
                     ["r", Z, Z, ["pi", T, T]]]
    pi_constant = ["pi", T, reflexivity()]
    for i, bad in enumerate(invalid_terms):
        add(f"reject_unused_pack_witness_{i}", [[], ["ex", T],
            ["pack", bad, reflexivity()]], "REJECT")
        add(f"reject_unused_pi_witness_{i}", [[], T,
            ["use", pi_constant, bad, reflexivity()]], "REJECT")
        for position in ("body", "initializer"):
            r = (["r", Z, Z, bad] if position == "body"
                 else ["r", ["s", Z], bad, Z])
            p = ["rec", r]
            add(f"reject_unused_rec_{position}_{i}", [[], T,
                ["use", p, ["=", 0, Z], p]], "REJECT")
    for i, bad in enumerate([False, -1.0, -2, ["r", Z, Z, Z], 0]):
        r = ["r", bad, Z, Z]
        p = ["rec", r]
        add(f"reject_bad_rec_counter_{i}", [[], T,
            ["use", p, ["=", 0, Z], p]], "REJECT")

    for label, context, key in [
        ("boolean_zero", ["=", 0, 0], ["=", False, False]),
        ("boolean_one", ["=", 1, 1], ["=", True, True]),
        ("floating_zero", ["=", 0, 0], ["=", 0.0, 0.0]),
        ("floating_constant", T, ["=", -1.0, -1.0]),
        ("nested_boolean", ["ex", ["=", 0, ["s", 1]]],
         ["ex", ["=", False, ["s", True]]]),
    ]:
        add("tightened_hypothesis_key_" + label,
            [[context], context, hypothesis(key)], "REJECT", old="ACCEPT")
    add("reject_bad_numeric_context", [[["=", False, False]], T,
        reflexivity()], "REJECT")
    add("reject_bad_numeric_conclusion", [[], ["=", -1.0, -1.0],
        reflexivity()], "REJECT")
    add("reject_false_as_term", [[], ["=", FALSE, Z], reflexivity()], "REJECT")
    for i, bad in enumerate([None, False, 0, [], {}, [[], T], [[], T, reflexivity(), 7],
                             ["not_context", T, reflexivity()], [[], T, []],
                             [[], T, ["unknown"]], [[], T, ["hyp", T, 0]]]):
        add(f"reject_bad_record_{i}", bad, "REJECT")
    return out


def replace_at(tree, path, value):
    if not path:
        return copy.deepcopy(value)
    result = copy.deepcopy(tree)
    ref = result
    for j in path[:-1]:
        ref = ref[j]
    ref[path[-1]] = copy.deepcopy(value)
    return result


def paths(tree, prefix=()):
    yield prefix
    if type(tree) is list:
        for i, child in enumerate(tree):
            yield from paths(child, prefix + (i,))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("results.json"))
    args = parser.parse_args()
    candidate = load(args.candidate.resolve(), "audit_candidate")
    reference = load(args.reference.resolve(), "audit_reference")
    result = {"candidate_sha256": hashlib.sha256(args.candidate.read_bytes()).hexdigest(),
              "reference_sha256": hashlib.sha256(args.reference.read_bytes()).hexdigest(),
              "seed": 202611061427, "failures": []}
    rng = random.Random(result["seed"])
    targeted = targeted_cases()
    rows = []
    for name, data, expected, old_expected in targeted:
        actual = outcome(candidate, data)
        old = outcome(reference, data)
        rows.append({"name": name, "expected": expected, "candidate": actual,
                     "reference_expected": old_expected, "reference": old})
        if actual != expected or old != old_expected:
            result["failures"].append({"kind": "targeted", "name": name,
                "data": data, "expected": expected, "actual": actual,
                "reference_expected": old_expected, "reference": old})
    result["targeted"] = rows

    # Fresh independent binding tests; every expectation is computed via names.
    binding_count = 2400
    for i in range(binding_count):
        kind = bool(rng.randrange(2))
        tree = formula(rng, 4, True) if kind else term(rng, 4)
        d = rng.randrange(5)
        choices = [(0,), (1,), (2,), (7,), [Z, 0], [Z, -1],
                   [["s", 0], 0], [term(rng, 3), -1],
                   [term(rng, 3), term(rng, 3), -2],
                   [term(rng, 2), term(rng, 2), 1]]
        env = rng.choice(choices)
        expected = oracle(tree, env, d, kind)
        actual = candidate.walk(copy.deepcopy(tree), copy.deepcopy(env), d, kind)
        if actual != expected:
            result["failures"].append({"kind": "named_binding", "i": i,
                "tree": tree, "env": env, "depth": d,
                "expected": expected, "actual": actual})
            break
    result["named_binding_cases"] = binding_count

    direct_count = 500
    for i in range(direct_count):
        a = formula(rng, 5, True)
        direct = candidate.walk(copy.deepcopy(a), [Z, 0], formula=True)
        composed = candidate.walk(candidate.walk(copy.deepcopy(a), [Z, -1], formula=True))
        expected = oracle(a, [Z, 0])
        if direct != composed or direct != expected:
            result["failures"].append({"kind": "direct_base", "i": i,
                "tree": a, "direct": direct, "composed": composed, "expected": expected})
            break
    result["direct_base_cases"] = direct_count

    # Type/arity grammar tests do not consult the implementation's SCOPES map.
    malformed = [None, True, False, 0.0, -1.0, -2, "s", [], {},
        ["false", 0], ["s"], ["s", Z, Z], ["="], ["=", Z], ["=", Z, Z, Z],
        ["r"], ["r", Z, Z], ["r", Z, Z, Z, Z], ["pi"], ["pi", T],
        ["pi", T, T, T], ["ex"], ["ex", T, T], [[], Z], [{}, Z], ["bad", Z],
        ["=", T, Z], ["s", T], ["r", Z, Z, FALSE], ["pi", Z, T], ["ex", Z]]
    valid = [Z, 0, 1, ["s", Z], ["r", Z, 0, ["r", 1, 2, 3]], T, D,
             FALSE, ["ex", ["pi", ["=", 0, 1], FALSE]],
             ["pi", ["=", ["r", 0, 1, 2], 3], ["ex", ["=", 0, 2]]]]
    formation_count = 0
    for value in malformed + valid:
        for kind in (False, True):
            formation_count += 1
            try:
                expected = oracle(value, (0,), formula=kind)
                expected_accept = True
            except ValueError:
                expected_accept = False
            try:
                actual = candidate.walk(copy.deepcopy(value), (0,), formula=kind)
                actual_accept = True
            except EXPECTED_REJECTIONS:
                actual_accept = False
            if actual_accept != expected_accept or (actual_accept and actual != expected):
                result["failures"].append({"kind": "formation", "input": value,
                    "formula": kind, "expected_accept": expected_accept,
                    "actual_accept": actual_accept})
    result["formation_cases"] = formation_count

    # Replay independent randomly generated axiom/hypothesis certificates.
    generated_count = 500
    for i in range(generated_count):
        a = formula(rng, 4)
        data = [[a], a, hypothesis(a)] if i % 2 else [[], num_axiom(a), ["nat", a]]
        new, old = outcome(candidate, data), outcome(reference, data)
        if new != "ACCEPT" or old != "ACCEPT":
            result["failures"].append({"kind": "generated_valid", "i": i,
                "data": data, "candidate": new, "reference": old})
    result["generated_valid_cases"] = generated_count

    # Random malformed JSON cannot be required to reject categorically: some
    # mutations still describe a valid proof.  Require matching acceptance on
    # these ordinary mutations, and no uncaught exception.  Deliberate numeric
    # hypothesis-key tightening is isolated above, not silently discarded.
    mutation_count = 1800
    bases = [data for _, data, expected, old_expected in targeted
             if expected == old_expected == "ACCEPT"]
    replacements = [None, False, True, -3, -1.0, 0.0, "bad", [], {},
                    ["false"], ["s"], ["="], ["pi", T, T], 99999]
    discrepancies = []
    caught_crashes = []
    for i in range(mutation_count):
        base = rng.choice(bases)
        path = rng.choice(list(paths(base)))
        bad = replace_at(base, path, rng.choice(replacements))
        new, old = outcome(candidate, bad), outcome(reference, bad)
        if new.startswith("UNCAUGHT"):
            caught_crashes.append({"i": i, "outcome": new, "data": bad})
        if new != old:
            discrepancies.append({"i": i, "candidate": new, "reference": old, "data": bad})
    # For all disagreements, a malformed hypothesis key must account for the
    # old acceptance.  Canonical numeric aliasing is detected declaratively.
    def bad_hyp_key(p):
        if type(p) is not list:
            return False
        if len(p) == 2 and p[0] == "hyp":
            try:
                shape(p[1], True)
            except ValueError:
                return True
        return any(bad_hyp_key(q) for q in p)
    for row in discrepancies:
        if not (row["candidate"] == "REJECT" and row["reference"] == "ACCEPT"
                and bad_hyp_key(row["data"])):
            result["failures"].append({"kind": "mutation_discrepancy", **row})
    result["mutation_cases"] = mutation_count
    result["mutation_tightening_discrepancies"] = discrepancies
    result["failures"].extend({"kind": "uncaught_exception", **r} for r in caught_crashes)

    # Exercise the actual JSON/CLI interface on meaningful representative data.
    cli_names = {"closed_reflexivity", "existential_elimination_retained_parameter",
        "reject_existential_witness_escape", "reject_quantified_induction_existential",
        "false_pi_annotation_and_key", "false_equality_template",
        "false_existential_goal_annotation", "false_numerical_annotation",
        "reject_unused_pack_witness_0", "reject_unused_rec_body_0",
        "reject_unused_rec_initializer_13", "tightened_hypothesis_key_floating_zero",
        "reject_bad_record_0", "reject_bad_record_6", "reject_bad_record_9"}
    cli_rows = []
    with tempfile.TemporaryDirectory(prefix="ipra_independent_audit_") as tmp:
        for name, data, expected, _ in targeted:
            if name not in cli_names:
                continue
            file = Path(tmp) / (name + ".json")
            file.write_text(json.dumps(data), encoding="utf-8")
            proc = subprocess.run([sys.executable, str(args.candidate.resolve()), str(file)],
                                  capture_output=True, text=True)
            actual = proc.stdout.strip()
            code = 0 if expected == "ACCEPT" else 1
            cli_rows.append({"name": name, "stdout": actual, "exit_code": proc.returncode,
                             "stderr": proc.stderr})
            if actual != expected or proc.returncode != code or proc.stderr:
                result["failures"].append({"kind": "cli", "name": name,
                    "expected": expected, "actual": actual, "code": proc.returncode,
                    "stderr": proc.stderr})
        for i, raw in enumerate(["[", '{"x":', "[[],null,0] trailing", "not JSON"]):
            file = Path(tmp) / f"invalid_json_{i}.json"
            file.write_text(raw, encoding="utf-8")
            proc = subprocess.run([sys.executable, str(args.candidate.resolve()), str(file)],
                                  capture_output=True, text=True)
            cli_rows.append({"name": f"invalid_json_text_{i}",
                             "stdout": proc.stdout.strip(), "exit_code": proc.returncode,
                             "stderr": proc.stderr})
            if proc.stdout.strip() != "REJECT" or proc.returncode != 1 or proc.stderr:
                result["failures"].append({"kind": "invalid_json_cli", "i": i,
                    "stdout": proc.stdout, "code": proc.returncode, "stderr": proc.stderr})
    result["cli"] = cli_rows
    result["passed"] = not result["failures"]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items()
        if k not in ("targeted", "cli", "mutation_tightening_discrepancies")}, indent=2))
    print(f"Targeted certificates: {len(rows)}; CLI cases: {len(cli_rows)}; "
          f"documented mutation tightenings: {len(discrepancies)}")
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
