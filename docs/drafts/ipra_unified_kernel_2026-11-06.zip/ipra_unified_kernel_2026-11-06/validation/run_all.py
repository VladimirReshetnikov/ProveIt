"""Run the reproducible validation package and refresh its compact summary.

Use --summarize to aggregate already completed results without rerunning
them. The whole acceptance path is checker.py; none of this file is trusted.
"""

import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]


def control_replay(certificates):
    path = ROOT / "controls/typed_prefix_unary.py"
    spec = importlib.util.spec_from_file_location("index_control", path)
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    for record in certificates:
        data = json.loads((ROOT / "validation" / record["file"]).read_text())
        try:
            checker.check(data)
            accepted = True
        except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
            accepted = False
        if accepted != record["accepted"]:
            raise AssertionError("Control disagrees on " + record["name"])
    return {"file": str(path.relative_to(ROOT)),
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "fixtures": len(certificates), "mismatches": 0}


def summarize():
    proofs = json.loads((ROOT / "validation/certificate_results.json").read_text())
    binding = json.loads((ROOT / "validation/binding_results.json").read_text())
    digest = hashlib.sha256((ROOT / "checker.py").read_bytes()).hexdigest()
    if proofs["checker_sha256"] != digest or binding["checker_sha256"] != digest:
        raise ValueError("Validation results belong to a different checker")
    control = control_replay(proofs["certificates"])
    result = {
        "status": "passed", "checker_sha256": digest,
        "positive_certificates": proofs["positive_certificates"],
        "negative_certificates": proofs["negative_certificates"],
        "positive_independent_expansions_accepted": proofs["positive_independent_expansions_accepted"],
        "independent_checker_sha256": proofs["independent_checker_sha256"],
        "inherited_replay": proofs["inherited_replay"],
        "cli_audit": proofs["cli_audit"],
        "binding": binding, "control_replay": control,
        "categories": proofs["categories"],
        "qualification": "These are finite executable checks, separate from the written metatheorems. No formal verification of Python semantics is asserted.",
    }
    (ROOT / "results/validation_summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


def main():
    if sys.argv[1:] not in ([], ["--summarize"]):
        raise SystemExit("usage: run_all.py [--summarize]")
    if not sys.argv[1:]:
        for script in ("validate.py", "independent_binding.py"):
            subprocess.run([sys.executable, str(ROOT / "validation" / script)],
                           cwd=ROOT, check=True)
    summarize()


if __name__ == "__main__":
    main()
