REPRODUCIBLE EXECUTABLE EVIDENCE
==============================

Run from any working directory, using Python 3.10 or later:

    python3 /path/to/package/validation/run_all.py

To update source measurements as well:

    python3 /path/to/package/measure.py

The validation scripts use only the standard library and the files in this
package. They do not fetch a repository or require an installed theorem
prover. checker.py is the complete trusted acceptance program; none of
the builders, translations, fixtures, or tests is imported by that file.

validate.py generates 177 named certificates: 116 expected acceptances
and 61 expected rejections. It verifies their independently planned
sequents, expands all 116 positive proofs into the separately implemented
historical compact checker, and checks each certificate through both
normal and optimized (-O) Python CLI execution. Four malformed JSON files
also reject. This makes 358 CLI invocations.

The examples cover formula-amalgamation endpoints, derived conjunction
and disjunction, dependent contexts, equation induction with a real use
of its induction hypothesis, recursion equations, equality transport
under binders, genuine falsity, witness freshness, and malformed input.

inherited_manifest.json records the original unary draft's 176 fixtures.
The adapted generator reproduces every original fixture byte-for-byte.
All 115 well-formed original positive spellings still accept and all 60
original negatives reject. The one remaining old positive used a Boolean
leaf in a hypothesis lookup key; it is now deliberately rejected.
stored_hypothesis_canonical_repair.json proves the identical sequent with
the stored canonical formula as its lookup key. This is the 177th fixture.

independent_binding.py uses unique named bound symbols, substitution of
free symbols, and re-encoding to check the typed de Bruijn traversal. It
performs 5,000 comparisons on 1,000 deterministic nested trees: shifts,
single instantiation, simultaneous recursion substitution, successor
replacement, and general finite prefixes. It also checks 500 instances
of the direct numerical-base identity against both the old composite
operation and the named-variable semantics. All comparisons pass.

run_all.py aggregates fresh results in results/validation_summary.json
and also checks the complete alternative implementation on all fixtures.
It refuses to aggregate proof/binding results for a different checker
SHA-256. The --summarize option uses already completed matching results.

SOURCE_PROVENANCE.json identifies the four adapted validation sources
and the unchanged historical baseline checker. builder.py implements
untrusted named proof macros. translate.py is an untrusted unary-to-binary
proof expansion that checks its input and output. These executable checks
supplement the written soundness and bi-interpretability proofs; they are
not a formal verification of the metatheory or of Python's semantics.
