"""Untrusted independent-checker expansion of unary certificates.

E_x A becomes Sigma_x(0=0,A). Every accepted canonical certificate is checked
again by the separately implemented, unmodified compact draft checker. This
does not replace the mathematical soundness/bi-interpretability proof.

Adapted from the supplied ipra_unary_existential_2026-11-06 draft;
see SOURCE_PROVENANCE.json for exact original identities and modifications.
"""

from pathlib import Path
import importlib.util
from builder import kernel


_baseline = Path(__file__).resolve().with_name("baseline_checker.py")
_spec = importlib.util.spec_from_file_location("compact_baseline", _baseline)
old = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(old)
TRUE = ["=", -1, -1]


def syntax(a):
    if type(a) is int:
        return a
    if a[0] == "ex":
        return ["sig", TRUE, syntax(a[1])]
    return [a[0], *(syntax(b) for b in a[1:])]


def reflexivity(t):
    computation = ["rec", ["r", -1, t, -1]]
    return ["use", computation, ["=", 0, old.shift(t)], computation]


def proof(p, g):
    match p:
        case ["hyp", key]:
            return ["hyp", syntax(g[g.index(key)])]
        case ["pi", a, q]:
            return ["pi", syntax(a), proof(q, [*map(kernel.walk, g), a])]
        case ["pack", t, q]:
            local = [*map(kernel.walk, g), ["=", 0, kernel.walk(t)]]
            return ["pair", syntax(t), reflexivity(-1), proof(q, local)]
        case ["use", p, a, q]:
            e = kernel.infer(p, g)
            local = [*map(kernel.walk, g), *e[1:]] if e[0] == "ex" else g
            return ["use", proof(p, g), syntax(a), proof(q, local)]
        case [("rec" | "nat") as tag, a]:
            return [tag, syntax(a)]
        case _:
            raise ValueError("Unknown proof node in untrusted translation")


def canonical_data(a):
    """Untrusted public-falsity expansion, including formula annotations."""
    if a == ["false"]:
        return ["=", -1, ["s", -1]]
    return [canonical_data(b) for b in a] if type(a) is list else a


def certificate(data):
    kernel.check(data)
    g, a, p = canonical_data(data)
    result = {"assumptions": [syntax(b) for b in g], "goal": syntax(a), "proof": proof(p, g)}
    old.check(result)
    return result


if __name__ == "__main__":
    import json
    import sys
    if len(sys.argv) not in (2, 3):
        raise SystemExit("usage: translate.py INPUT.json [OUTPUT.json]")
    result = certificate(json.loads(Path(sys.argv[1]).read_text()))
    text = json.dumps(result, separators=(",", ":")) + "\n"
    if len(sys.argv) == 3:
        Path(sys.argv[2]).write_text(text)
    else:
        print(text, end="")
