"""Untrusted named proof constructors for the six-record unary iPRA kernel.

Every exported certificate is an ordinary finite JSON proof checked by the
separate checker. Names, proof macros, formula amalgamation, and all arithmetic
constructions below are outside the trusted implementation.

Adapted from the supplied ipra_unary_existential_2026-11-06 draft;
see SOURCE_PROVENANCE.json for exact original identities and modifications.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import count
import importlib.util
from pathlib import Path


_root = Path(__file__).resolve().parents[1]
_checker = _root / "checker.py"
_spec = importlib.util.spec_from_file_location("unary_kernel", _checker)
kernel = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(kernel)
_ids = count()


@dataclass(frozen=True)
class Var:
    uid: int
    label: str


def fresh(label="x"):
    return Var(next(_ids), label)


Z = -1


def S(t):
    return ("s", t)


def Eq(s, t):
    return ("=", s, t)


T = Eq(Z, Z)
D = Eq(Z, S(Z))


def Pi(x, a, b):
    return ("pi", x, a, b)


def Ex(x, a):
    return ("ex", x, a)


def R(n, a, u, v, h):
    return ("r", n, a, u, v, h)


def selector(n, a, b):
    return R(n, a, fresh("u"), fresh("v"), b)


def Imp(a, b):
    return Pi(fresh("unused"), a, b)


def All(x, a):
    return Pi(x, T, a)


def free(a):
    if isinstance(a, Var):
        return {a}
    if type(a) is int:
        return set()
    if a[0] == "r":
        return free(a[1]) | free(a[2]) | (free(a[5]) - {a[3], a[4]})
    if a[0] in ("pi", "ex"):
        return set().union(*(free(b) for b in a[2:])) - {a[1]}
    return set().union(*(free(b) for b in a[1:]))


def sub(a, env):
    """Capture-avoiding simultaneous substitution in named syntax."""
    if isinstance(a, Var):
        return env.get(a, a)
    if type(a) is int:
        return a
    if a[0] == "r":
        n, init, u, v, body = a[1:]
        local = {k: t for k, t in env.items() if k not in (u, v)}
        capture = set().union(*(free(t) for t in local.values()))
        renaming = {x: fresh(x.label) for x in (u, v) if x in capture}
        body = sub(body, renaming)
        return R(sub(n, env), sub(init, env), renaming.get(u, u),
                 renaming.get(v, v), sub(body, local))
    if a[0] in ("pi", "ex"):
        x = a[1]
        local = {k: t for k, t in env.items() if k != x}
        capture = set().union(*(free(t) for t in local.values()))
        y = fresh(x.label) if x in capture else x
        children = [sub(sub(b, {x: y}) if y != x else b, local) for b in a[2:]]
        return (a[0], y, *children)
    return (a[0], *(sub(b, env) for b in a[1:]))


def encode(a, scope):
    if isinstance(a, Var):
        return scope.index(a)
    if type(a) is int:
        assert a == Z
        return a
    if a[0] == "r":
        return ["r", encode(a[1], scope), encode(a[2], scope),
                encode(a[5], [a[3], a[4], *scope])]
    if a[0] in ("pi", "ex"):
        return [a[0], *(encode(b, [a[1], *scope]) for b in a[2:])]
    return [a[0], *(encode(b, scope) for b in a[1:])]


def same(a, b):
    scope = sorted(free(a) | free(b), key=lambda v: v.uid)
    return encode(a, scope) == encode(b, scope)


@dataclass
class Proof:
    goal: object
    node: tuple


def as_goal(p, goal):
    assert same(p.goal, goal), ("macro conclusion mismatch", p.goal, goal)
    return Proof(goal, p.node)


def hyp(a):
    return Proof(a, ("hyp", a))


def pi_intro(x, guard, body):
    return Proof(Pi(x, guard, body.goal), ("pi", x, guard, body))


def pi_elim(principal, witness, minor):
    tag, x, a, b = principal.goal
    assert tag == "pi" and same(minor.goal, sub(a, {x: witness}))
    return Proof(sub(b, {x: witness}), ("app", principal, witness, minor))


def imp_intro(a, body):
    return pi_intro(fresh("unused"), a, body(hyp(a)))


def imp_elim(principal, minor):
    return pi_elim(principal, Z, minor)


def rewrite(equality, x, template, minor):
    _, s, t = equality.goal
    assert same(minor.goal, sub(template, {x: s})), (
        "transport source mismatch", minor.goal, sub(template, {x: s}))
    return Proof(sub(template, {x: t}), ("eq", equality, x, template, minor))


def compute(r):
    _, n, a, u, v, h = r
    if n == Z:
        b = a
    else:
        assert isinstance(n, tuple) and n[0] == "s"
        b = sub(h, {u: R(n[1], a, u, v, h), v: n[1]})
    return Proof(Eq(r, b), ("rec", r))


def refl(t):
    p = compute(R(Z, t, fresh("u"), fresh("v"), Z))
    x = fresh("transport")
    return rewrite(p, x, Eq(x, t), p)


def sym(p):
    _, s, _ = p.goal
    x = fresh("transport")
    return rewrite(p, x, Eq(x, s), refl(s))


def trans(p, q):
    _, s, t = p.goal
    assert same(t, q.goal[1])
    x = fresh("transport")
    return rewrite(q, x, Eq(s, x), p)


def congr(p, x, context):
    s = sub(context, {x: p.goal[1]})
    return rewrite(p, x, Eq(s, context), refl(s))


def pack(witness, y, body):
    return Proof(Ex(y, body.goal), ("pack", witness, y, body))


def exists_intro(existential, witness, premise):
    _, x, body = existential
    assert same(premise.goal, sub(body, {x: witness}))
    y, z = fresh("witness"), fresh("transport")
    equation = Eq(y, witness)
    template = sub(body, {x: z})
    branch = rewrite(sym(hyp(equation)), z, template, premise)
    return as_goal(pack(witness, y, branch), existential)


def exists_elim(principal, y, body, goal=None):
    assert principal.goal[0] == "ex"
    result = body.goal if goal is None else goal
    assert y not in free(result)
    return Proof(result, ("let", principal, y, body))


def nat_axiom(x, a):
    base = sub(a, {x: Z})
    y = fresh("step")
    guard = sub(a, {x: y}) if a[0] == "=" else base
    step = Pi(y, guard, sub(a, {x: S(y)}))
    return Proof(Pi(x, base, Imp(step, a)), ("nat", x, a))


def numerical(x, a, target, base, successor):
    """Use equation induction, or cases for a non-equation matrix.

    successor(y, hypothesis) constructs the successor proof. For a compound
    matrix that hypothesis is its fixed base, not an induction hypothesis.
    """
    assert same(base.goal, sub(a, {x: Z}))
    y = fresh("step")
    guard = sub(a, {x: y}) if a[0] == "=" else sub(a, {x: Z})
    body = successor(y, hyp(guard))
    assert same(body.goal, sub(a, {x: S(y)}))
    step = pi_intro(y, guard, body)
    return imp_elim(pi_elim(nat_axiom(x, a), target, base), step)


def collapse(clash, a, b):
    """Derive arbitrary a=b from the designated arithmetic clash."""
    assert same(clash.goal, D)
    c0, c1 = selector(Z, a, b), selector(S(Z), a, b)
    x = fresh("transport")
    changed = rewrite(clash, x, Eq(selector(x, a, b), a), compute(c0))
    return trans(sym(as_goal(changed, Eq(c1, a))), compute(c1))


def explode(clash, formula):
    if formula[0] == "=":
        return collapse(clash, formula[1], formula[2])
    if formula[0] == "pi":
        _, x, a, b = formula
        return pi_intro(x, a, explode(clash, b))
    _, x, a = formula
    return pack(Z, x, explode(clash, a))


def separation(equality):
    """Convert 0=S(t), or its reverse, into 0=S(0)."""
    if equality.goal[1] != Z:
        equality = sym(equality)
    _, zero, sn = equality.goal
    assert zero == Z and sn[0] == "s"
    x = fresh("transport")
    changed = rewrite(equality, x, Eq(selector(x, Z, S(Z)), Z),
                      compute(selector(Z, Z, S(Z))))
    return trans(sym(changed), compute(selector(sn, Z, S(Z))))


@dataclass
class Mix:
    selector: Var
    left: object
    right: object
    formula: object
    kind: str
    binder: Var | None = None
    children: tuple = ()
    left_parts: tuple = ()
    right_parts: tuple = ()


def amalgamate(z, a, b):
    """General finite formula amalgamation, with Pi priority over Ex."""
    assert z not in free(a) | free(b)
    if a[0] == "pi" or b[0] == "pi":
        x = fresh("mix_number")

        def parts(f):
            return tuple(sub(t, {f[1]: x}) for t in f[2:]) if f[0] == "pi" else (T, f)

        aa, bb = parts(a), parts(b)
        left = amalgamate(z, aa[0], bb[0])
        right = amalgamate(z, aa[1], bb[1])
        return Mix(z, a, b, Pi(x, left.formula, right.formula), "pi", x,
                   (left, right), aa, bb)
    if a[0] == "ex" or b[0] == "ex":
        x = fresh("mix_number")

        def body(f):
            return sub(f[2], {f[1]: x}) if f[0] == "ex" else f

        aa, bb = body(a), body(b)
        child = amalgamate(z, aa, bb)
        return Mix(z, a, b, Ex(x, child.formula), "ex", x, (child,), (aa,), (bb,))
    assert a[0] == b[0] == "="
    formula = Eq(selector(z, a[1], b[1]), selector(z, a[2], b[2]))
    return Mix(z, a, b, formula, "=")


def endpoint(plan, side, premise, to_part=True, predecessor=None):
    """Compile M(0)<->A or M(S(n))<->B for every finite formula pair.

    `to_part` converts a proof of M to the selected formula. In the reverse
    direction it converts a proof of that formula to M. Pi antecedents use
    the reversed endpoint conversion; consequents use the forward one.
    """
    assert side in (0, 1)
    if predecessor is None:
        predecessor = Z
    witness = Z if side == 0 else S(predecessor)
    selected = plan.left if side == 0 else plan.right
    mixed = sub(plan.formula, {plan.selector: witness})
    assert same(premise.goal, mixed if to_part else selected)

    def recurse(child, p, direction):
        return endpoint(child, side, p, direction, predecessor)

    if plan.kind == "=":
        lhs, rhs = mixed[1:]
        lp, rp = compute(lhs), compute(rhs)
        x = fresh("transport")
        if to_part:
            result = rewrite(lp, x, Eq(x, rhs), premise)
            result = rewrite(rp, x, Eq(selected[1], x), result)
        else:
            result = rewrite(sym(lp), x, Eq(x, selected[2]), premise)
            result = rewrite(sym(rp), x, Eq(lhs, x), result)
    elif plan.kind == "pi":
        x = plan.binder
        guard, body = (plan.left_parts if side == 0 else plan.right_parts)
        mix_guard = sub(plan.children[0].formula, {plan.selector: witness})
        if to_part:
            converted_guard = recurse(plan.children[0], hyp(guard), False)
            mixed_body = pi_elim(premise, x, converted_guard)
            result = pi_intro(x, guard, recurse(plan.children[1], mixed_body, True))
            if selected[0] != "pi":
                result = pi_elim(result, Z, refl(Z))
        else:
            principal = premise if selected[0] == "pi" else pi_intro(x, T, premise)
            converted_guard = recurse(plan.children[0], hyp(mix_guard), True)
            selected_body = pi_elim(principal, x, converted_guard)
            result = pi_intro(x, mix_guard, recurse(plan.children[1], selected_body, False))
    else:
        x = plan.binder
        child = plan.children[0]
        selected_body = (plan.left_parts if side == 0 else plan.right_parts)[0]
        mixed_body = sub(child.formula, {plan.selector: witness})
        if to_part:
            converted = recurse(child, hyp(mixed_body), True)
            branch = exists_intro(selected, x, converted) if selected[0] == "ex" else converted
            result = exists_elim(premise, x, branch, selected)
        elif selected[0] == "ex":
            converted = recurse(child, hyp(selected_body), False)
            branch = exists_intro(mixed, x, converted)
            result = exists_elim(premise, x, branch, mixed)
        else:
            # Vacuous existential padding: the conversion is pointwise in x.
            # The temporary witness equation x=0 may be ignored.
            result = pack(Z, x, recurse(child, premise, False))
    return as_goal(result, selected if to_part else mixed)


def conjunction(a, b):
    z = fresh("tag")
    plan = amalgamate(z, a, b)
    return All(z, plan.formula), plan


def conjunction_intro(plan, pa, pb):
    z = plan.selector
    base = endpoint(plan, 0, pa, False)
    body = numerical(z, plan.formula, z, base,
                     lambda y, unused: endpoint(plan, 1, pb, False, y))
    return pi_intro(z, T, body)


def conjunction_elim(plan, principal, side):
    witness = Z if side == 0 else S(Z)
    mixed = pi_elim(principal, witness, refl(Z))
    return endpoint(plan, side, mixed, True)


def disjunction(a, b):
    z = fresh("tag")
    plan = amalgamate(z, a, b)
    return Ex(z, plan.formula), plan


def disjunction_intro(plan, premise, side):
    witness = Z if side == 0 else S(Z)
    mixed = endpoint(plan, side, premise, False)
    return exists_intro(Ex(plan.selector, plan.formula), witness, mixed)


def disjunction_elim(plan, principal, goal, left_branch, right_branch):
    z = plan.selector
    assert z not in free(goal)
    matrix = Imp(plan.formula, goal)
    m0 = sub(plan.formula, {z: Z})
    base = imp_intro(m0, lambda p: left_branch(endpoint(plan, 0, p)))

    def successor(y, unused):
        ms = sub(plan.formula, {z: S(y)})
        return imp_intro(ms, lambda p: right_branch(endpoint(plan, 1, p, True, y)))

    implication = numerical(z, matrix, z, base, successor)
    branch = imp_elim(implication, hyp(plan.formula))
    return exists_elim(principal, z, branch, goal)


def encode_proof(proof, scope):
    n = proof.node
    if n[0] == "hyp":
        return ["hyp", encode(n[1], scope)]
    if n[0] == "pi":
        _, x, guard, body = n
        local = [x, *scope]
        return ["pi", encode(guard, local), encode_proof(body, local)]
    if n[0] == "app":
        return ["use", encode_proof(n[1], scope), encode(n[2], scope), encode_proof(n[3], scope)]
    if n[0] == "eq":
        _, p, x, template, q = n
        return ["use", encode_proof(p, scope), encode(template, [x, *scope]), encode_proof(q, scope)]
    if n[0] == "let":
        _, p, x, q = n
        return ["use", encode_proof(p, scope), encode(proof.goal, scope), encode_proof(q, [x, *scope])]
    if n[0] == "pack":
        _, t, x, p = n
        return ["pack", encode(t, scope), encode_proof(p, [x, *scope])]
    if n[0] == "rec":
        return ["rec", encode(n[1], scope)]
    if n[0] == "nat":
        return ["nat", encode(n[2], [n[1], *scope])]
    raise ValueError(n[0])


def certificate(context, proof, parameters=None):
    if parameters is None:
        variables = set().union(free(proof.goal), *(free(a) for a in context))
        parameters = sorted(variables, key=lambda v: v.uid)
    result = [[encode(a, parameters) for a in context], encode(proof.goal, parameters),
              encode_proof(proof, parameters)]
    kernel.check(result)
    return result
