A SMALLER COMPLETE iPRA CHECKER
Unary existence and typed finite substitutions
6 November 2026

Start with report.pdf. Complete LaTeX source is report.tex plus sections/
and the generated result tables under results/.

RESULT

This package specifies a complete presentation of full first-order
intuitionistic primitive recursive arithmetic, with explicit logical rules,
arithmetic axioms, and schemas. It proves equiconsistency and ordinary
whole-domain bi-interpretability through an explicit first-order realization.
Both interpretation composites are internally isomorphic to the identity.

Native numerical terms use zero, successor, and initialized primitive
recursion with a finite body. Native formulas use equations, the guarded
universal binder Pi_x(A;B), and unary existence E_x A. Public genuine falsity
has the explicit representation 0=S0. Conjunction and disjunction are
derived by formula amalgamation. The numerical schema gives induction only
for literal equations and numerical cases for other formulas.

The complete final checker has:
  845 significant original and normalized Python tokens;
  872 executable AST nodes;
  2,645 normalized executable bytes;
  2,896 raw source bytes;
  73 noncomment code lines.

The corresponding current coordinate minima are:
  863 original tokens, 864 normalized tokens, 915 AST nodes,
  2,730 normalized bytes, 3,088 raw bytes, 76 code lines.

The comparison is pinned to ProveIt commit:
9e338a5c51a26ac6ae90f2d8f563a44c3879ba68

Six current main programs and ten direct current controls are frozen and
hashed. This is a reproducible finite implementation comparison, not an
absolute shortest-program theorem.

The mathematical basis, including unary existence and formula amalgamation,
is inherited from the supplied drafts and attributed in the report. The new
implementation combines their compatible binding reductions into one typed
finite-substitution traversal, including public-falsity conversion. Its direct
numerical-base operation also avoids a redundant traversal.

The optional complete variant controls/typed_prefix_unary.py has 848
normalized tokens, 883 AST nodes, and 2,623 normalized bytes. It is slightly
smaller in normalized bytes/lines but larger in tokens/AST nodes. The
table-driven checker.py is the recommended version.

REPRODUCTION

Python 3.10+ and its standard library are sufficient for the code checks.
No network access or external repository is required.
The PDF build also needs latexmk, pdfLaTeX, and the packages in report.tex.

From this directory:

  python3 reproduce.py

Without a TeX installation:

  python3 reproduce.py --no-pdf

Individual stages:

  python3 measure.py
  python3 validation/run_all.py
  python3 arithmetic/verify.py --checker checker.py
  python3 independent_audit/audit.py --candidate checker.py --reference comparison/current/unary_existential.py --output independent_audit/results.json
  python3 build.py

Check an explicit arithmetic theorem:

  python3 checker.py arithmetic/certificates/residual.json

This prints ACCEPT. A certificate with a nonempty assumptions list proves
only the indicated sequent, not an unconditional theorem.

The eleven extra arithmetic certificates can be regenerated with:

  python3 arithmetic/generate.py --checker checker.py
  python3 arithmetic/verify.py --checker checker.py --save-expanded

EVIDENCE

  - 116 accepted and 61 rejected logical/binding certificates.
  - All 116 accepted proofs expanded into an unchanged independent checker.
  - 358 CLI checks, including normal and optimized Python.
  - 5,000 independent named-variable binding checks and 500 base identities.
  - 11 new, self-contained arithmetic certificates, totaling 51,043 bytes.
    They include the residual identity and both directions of the exact
    equality zero-test. Each passes the final checker, the frozen unary
    checker, and the independently implemented compact checker.
  - Independent adversarial audit: 122 targeted cases, 2,400 binding cases,
    500 base identities, 82 formation checks, 500 generated valid proofs,
    1,800 mutations, and 19 CLI cases; no failures.

The old unary checker allowed malformed hypothesis lookup keys exploiting
Python's Boolean/integer and float/integer equality. It returned a stored
valid formula, so this was not an unsoundness. This checker validates keys,
rejects those spellings, and accepts canonical repairs of the same sequents.

The general soundness, completeness, and bi-interpretability claims are
proved mathematically in the report. They are not claimed to be formalized
in Lean or Rocq. The test evidence is finite and does not verify the Python
runtime. Ordinary finite resource limits may reject very large proofs.

FILES

checker.py                  Entire trusted acceptance program.
report.tex, sections/       Complete report source.
report.pdf                  Compiled report.
measure.py                  Reproducible whole-program measurements.
comparison/                 Frozen current sources and provenance.
controls/                   Optional complete implementation variant.
validation/                 Untrusted proof builders, logical fixtures,
                            independent expansion, and binding oracle.
arithmetic/                 New arithmetic generators, complete certificates,
                            independent expansions, and three-checker results.
independent_audit/           Separately written adversarial/binding audit.
results/                    Measurement, validation, and build records.
build.py                    PDF build helper.
reproduce.py                End-to-end reproduction.
SHA256SUMS.txt               Packaged file hashes, excluding this manifest.

All generators, translators, test suites, and frozen comparison programs are
outside the final checker's acceptance path. It imports only json and sys.
The hash manifest describes the delivered files; rerunning scripts may
update output path and timing metadata.
