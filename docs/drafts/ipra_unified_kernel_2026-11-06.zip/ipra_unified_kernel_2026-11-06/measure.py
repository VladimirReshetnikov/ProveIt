"""Reproduce full-program source measures without executing comparators.

Adapted from the supplied prefix-kernel draft's compare.py. All current
main programs and direct controls are included byte-for-byte, with hashes
in comparison/provenance.json. No metric excludes input validation or CLI.
"""

import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import sys
import tokenize


ROOT = Path(__file__).resolve().parent
LAYOUT = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL,
          tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
          tokenize.ENDMARKER}
METRICS = ("significant_tokens", "normalized_tokens", "ast_nodes",
           "normalized_bytes", "raw_bytes", "noncomment_code_lines")


def measure(raw):
    source = raw.decode("utf-8")
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef,
                             ast.AsyncFunctionDef)) and node.body:
            first = node.body[0]
            if (isinstance(first, ast.Expr)
                    and isinstance(first.value, ast.Constant)
                    and isinstance(first.value.value, str)):
                spans.append(((first.lineno, first.col_offset),
                              (first.end_lineno, first.end_col_offset)))
                del node.body[0]

    def significant(text, excluded=()):
        return [t for t in tokenize.generate_tokens(io.StringIO(text).readline)
                if t.type not in LAYOUT
                and not any(a <= t.start and t.end <= b for a, b in excluded)]

    tokens = significant(source, spans)
    lines = {n for t in tokens for n in range(t.start[0], t.end[0] + 1)}
    normalized = ast.unparse(tree) + "\n"
    imports = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.update(x.name.split(".")[0] for x in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.add("." * node.level + (node.module or ""))
    if imports - sys.stdlib_module_names:
        raise ValueError("An acceptance source has unaccounted local imports")
    return {
        "sha256": hashlib.sha256(raw).hexdigest(),
        "significant_tokens": len(tokens),
        "normalized_tokens": len(significant(normalized)),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "normalized_bytes": len(normalized.encode("utf-8")),
        "raw_bytes": len(raw),
        "noncomment_code_lines": len(lines),
        "imports": sorted(imports),
    }


def minima(rows):
    return {key: min(row[key] for row in rows) for key in METRICS}


def latex_table(rows, candidate, frontier):
    text = [r"\begin{center}", r"\small",
            r"\begin{tabular}{lrrrrrr}", r"\toprule",
            r"Program & Tokens & Norm. & AST & Norm. B & Raw B & Lines \\",
            r"\midrule"]
    for row in rows:
        text.append(row["label"] + " & " + " & ".join(
            str(row[key]) for key in METRICS) + r" \\")
    text.append(r"\midrule")
    text.append("Current minima & " + " & ".join(
        str(frontier[key]) for key in METRICS) + r" \\")
    text.append(r"\textbf{" + candidate["label"] + "} & " + " & ".join(
        r"\textbf{" + str(candidate[key]) + "}" for key in METRICS) + r" \\")
    text.extend([r"\bottomrule", r"\end{tabular}", r"\end{center}"])
    return "\n".join(text) + "\n"


def main():
    provenance = json.loads((ROOT / "comparison/provenance.json").read_text())
    rows = []
    for record in provenance["programs"]:
        raw = (ROOT / record["local_path"]).read_bytes()
        result = measure(raw)
        if result["sha256"] != record["source_sha256"]:
            raise ValueError("Frozen source hash mismatch: " + record["local_path"])
        rows.append({**record, **result})
    mains = [r for r in rows if r["kind"] == "main"]
    if len(mains) != 6:
        raise ValueError("The pinned comparison requires six main programs")
    candidate = {"id": "candidate", "label": "Unified unary checker",
                 "local_path": "checker.py",
                 **measure((ROOT / "checker.py").read_bytes())}
    controls = [{"id": "typed_prefix", "label": "Constructor-index control",
                 "local_path": "controls/typed_prefix_unary.py",
                 **measure((ROOT / "controls/typed_prefix_unary.py").read_bytes())}]
    frontier = minima(rows)
    result = {
        "python_version": platform.python_version(),
        "repository": provenance["repository"], "commit": provenance["commit"],
        "comparison_scope": "Six current main programs and ten direct packaged controls; complete source files are frozen here.",
        "current_main_count": len(mains), "current_program_count": len(rows),
        "candidate": candidate, "new_controls": controls, "programs": rows,
        "current_main_coordinate_minima": minima(mains),
        "current_all_coordinate_minima": frontier,
        "candidate_below_every_coordinate": all(candidate[k] < frontier[k] for k in METRICS),
        "definition": {
            "tokens": "All Python lexical tokens except layout, comments, and actual docstrings.",
            "normalized": "ast.unparse after removing docstrings, followed by one newline.",
            "ast": "All nodes in the docstring-stripped executable ast.Module tree, including imports and CLI.",
            "lines": "Physical source lines touched by significant tokens.",
            "runtime": "Python and its standard library are the shared runtime; no local acceptance imports are omitted.",
        },
        "qualification": "A reproducible finite implementation comparison, not an absolute shortest-program lower-bound theorem.",
    }
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results/metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    macros = {
        "CandidateSourceTokens": candidate["significant_tokens"],
        "CandidateTokens": candidate["normalized_tokens"],
        "CandidateAST": candidate["ast_nodes"],
        "CandidateBytes": candidate["normalized_bytes"],
        "CandidateRawBytes": candidate["raw_bytes"],
        "CandidateLines": candidate["noncomment_code_lines"],
        "MinimumSourceTokens": frontier["significant_tokens"],
        "MinimumTokens": frontier["normalized_tokens"],
        "MinimumAST": frontier["ast_nodes"],
        "MinimumBytes": frontier["normalized_bytes"],
        "MinimumRawBytes": frontier["raw_bytes"],
        "MinimumLines": frontier["noncomment_code_lines"],
    }
    (ROOT / "results/metrics_macros.tex").write_text("".join(
        "\\newcommand{\\" + name + "}{" + str(value) + "}\n"
        for name, value in macros.items()))
    (ROOT / "results/comparison_table.tex").write_text(latex_table(mains, candidate, frontier))
    print(json.dumps({"candidate": candidate, "coordinate_minima": frontier,
                      "strictly_below": result["candidate_below_every_coordinate"]}, indent=2))


if __name__ == "__main__":
    main()
