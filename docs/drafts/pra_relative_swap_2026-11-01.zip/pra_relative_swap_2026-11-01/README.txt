PRA from initialized swap recursion and relative constancy
1 November 2026

RESULT
A common nonlogical basis, separately bi-interpretable and equiconsistent
with classical and intuitionistic first-order PRA. The two interpretation
domains are the full carrier; native equality and both identity round trips
are proved internally, including for nonstandard arguments.

IMPROVEMENT OVER THE CURRENT SEVEN-DRAFT SNAPSHOT
Pinned ProveIt commit: c5a6a6a4087c9a3a2e9ce4f4ad8ad6a79e466ef7
Displayed formula-tree nodes: 52 -> 50 against initialized_swap.
Selected program-body nodes: 13 -> 8.
Partial combined ledger: 65 -> 58.
The comparator update is C(D(a,n),n,a), with six nodes. It is locally
minimum in the explicitly fixed update vocabulary, not globally minimum
among all possible axiomatizations. The report includes all counting and
logic conventions, including the classical biconditional caveat.

MAIN CONTENTS
report.pdf                      Complete research report
report.tex and section *.tex     Complete rebuildable LaTeX source
axioms.txt                      Exact language, axioms, and translations
build.sh                        PDF rebuild command (TeX Live)
source_manifest.json            Pinned sources and exact archive hashes
artifacts/verify.py              Syntax, symbolic rewrite and compiler checks
artifacts/search_t_update.py     Exhaustive local update search
artifacts/*.json                Reproduced results and rejection witnesses
formal/InitializedProbe.lean     Checked constructive arithmetic kernel
formal/README.txt                Precise formal scope and replay instructions
formal/lean-verification.txt     Successful Lean 4.19.0 verification output
audit/                          Source, proof and PDF review records
SHA256SUMS                      Hashes of final payload files

REPRODUCE
  python3 artifacts/verify.py --json artifacts/verification_results.json
  python3 artifacts/search_t_update.py --json artifacts/update_search_witnesses.json
  sh build.sh
Optional formal replay, using Lean 4.19.0:
  cd formal
  lean InitializedProbe.lean

PROOF SCOPE
The manuscript proves the full theorem. The Lean file checks the generic-
carrier constructive kernel through quantifier-free induction, but does not
formalize effective syntax, term admissibility, the first-order derivation
system, the reverse compiler, or the interpretation round trips. Its schema
interface uses semantic functions; this is documented in full. Finite tests
are diagnostics and are not substituted for universal proofs.

The repository was read only. The seven source ZIPs were not executed and
are not duplicated inside this package; exact provenance is in the manifest.
