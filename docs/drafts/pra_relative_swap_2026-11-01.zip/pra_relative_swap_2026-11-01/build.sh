#!/bin/sh
set -eu
cd "$(dirname "$0")"
pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error report.tex
pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error report.tex
pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error report.tex
