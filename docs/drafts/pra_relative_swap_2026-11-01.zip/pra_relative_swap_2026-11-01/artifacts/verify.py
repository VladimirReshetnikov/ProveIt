#!/usr/bin/env python3
"""Reproduce syntax counts and finite compiler diagnostics.

No downloaded source is executed. This is not a formal proof of the
first-order bi-interpretation theorem; see report.pdf and formal/README.txt.
"""
from __future__ import annotations
import argparse
from functools import lru_cache
import json
from pathlib import Path


def node(op, *args):
    return (op, *args)


def count(t):
    return 1 if isinstance(t, str) else 1 + sum(map(count, t[1:]))


def all_(variables, formula):
    for var in reversed(variables):
        # Binder names are metadata, not additional variable occurrences.
        formula = node('forall:' + var, formula)
    return formula


def syntax_metrics(m):
    b = tuple('b' + str(i) for i in range(m - 1))
    passive = ('a', *b)
    S = lambda x: node('S', x)
    R = lambda x, y: node('R', x, y, *b)
    f = lambda x: node('f', x, *passive)
    eq = lambda x, y: node('=', x, y)
    neq = lambda x, y: node('->', eq(x, y), 'bottom')
    base = all_(passive, eq(R('0', 'a'), 'a'))
    step = all_(('n', *passive), eq(
        R(S('n'), 'a'), node('h', 'n', 'a', *b, R('a', 'n'))))
    premise = all_(('n',), eq(f(S('n')), f('n')))
    rc = all_(passive, node('->', premise, all_(('n',), node('or',
        eq(node('T', f('0'), 'a'), 'a'), eq(f('n'), 'a')))))
    sep = neq('0', S('0'))
    old_off = all_(('x', 'y'), node('or',
        eq(node('T', 'x', 'y'), 'y'), eq('x', 'y')))
    old_ss = all_(passive, node('->', premise, all_(('n',),
        neq(S(f('n')), f('0')))))
    inline = all_(passive, node('->', premise, all_(('n',), node('or',
        eq(node('C', node('D', 'a', f('0')), f('0'), 'a'), 'a'),
        eq(S(f('n')), 'a')))))
    values = dict(base=count(base), step=count(step), rc=count(rc),
                  sep=count(sep), old_off=count(old_off), old_ss=count(old_ss),
                  inline_schema=count(inline))
    values['new_total'] = values['base'] + values['step'] + values['rc'] + values['sep']
    values['old_swap_total'] = values['base'] + values['step'] + values['old_off'] + values['old_ss']
    values['inline_total'] = values['base'] + values['step'] + values['inline_schema'] + values['sep']
    assert values['base'] == 2*m + 4
    assert values['step'] == 4*m + 9
    assert values['rc'] == 5*m + 20
    assert values['new_total'] == 11*m + 39
    assert values['old_swap_total'] == 11*m + 41
    return values


def select(z, u, w):
    return u if z == 0 else w


def near(x, y):
    return y-x if x <= y else x-y-1


def swap_function(update, frozen):
    @lru_cache(maxsize=None)
    def f(x, y):
        return y if x == 0 else update(x-1, y, frozen, f(y, x-1))
    return f


def reverse_value(update, x, y, frozen):
    d, e, m = max(x-y, 0), max(y-x, 0), min(x, y)
    value = e if d == 0 else update(d-1, 0, frozen, d-1)
    for j in range(m):
        value = update(d+j, e+j+1, frozen,
                       update(e+j, d+j, frozen, value))
    return value


def compiler_checks():
    profiles = {
        'zero': lambda n, a, b, v: 0,
        'counter': lambda n, a, b, v: n,
        'active': lambda n, a, b, v: a,
        'recursive': lambda n, a, b, v: v,
        'linear': lambda n, a, b, v: v+n+a+sum(b),
        'affine': lambda n, a, b, v: 2*v+a+sum(b)+1,
        'selector': lambda n, a, b, v: select(v, n+sum(b), a),
        'near': lambda n, a, b, v: near(v+a, n+sum(b)),
    }
    frozen_sets = ((), (2,), (1, 3))
    reverse_count = 0
    for name, update in profiles.items():
        for b in frozen_sets:
            literal = swap_function(update, b)
            for x in range(19):
                for y in range(19):
                    actual = reverse_value(update, x, y, b)
                    assert actual == literal(x, y), (name, b, x, y)
                    reverse_count += 1
    ordinary_profiles = {
        'add_counter': lambda n, b, v: v+n+sum(b),
        'double': lambda n, b, v: 2*v+sum(b),
        'counter': lambda n, b, v: n,
        'constant': lambda n, b, v: sum(b)+1,
        'selector': lambda n, b, v: select(n, 0, v+2),
        'near': lambda n, b, v: near(v+n, sum(b)),
    }
    forward_count = 0
    for name, H in ordinary_profiles.items():
        for b in frozen_sets:
            G = sum(b)+2
            def update(n, a, frozen, v):
                return select(near(n, a), v,
                              select(n, G, H(max(n-1, 0), frozen, v)))
            literal = swap_function(update, b)
            ordinary = G
            for n in range(21):
                assert literal(n+1, n+1) == ordinary, (name, b, n)
                forward_count += 1
                ordinary = H(n, b, ordinary)
    return {'reverse_pairs': reverse_count, 'reverse_updates': len(profiles),
            'forward_values': forward_count, 'forward_updates': len(ordinary_profiles),
            'frozen_tuples': [list(b) for b in frozen_sets]}


def rewrite(t, derived=False):
    if isinstance(t, str):
        return t
    t = (t[0], *(rewrite(c, derived) for c in t[1:]))
    op, *a = t
    result = t
    if op == 'C':
        if a[0] == '0': result = a[1]
        elif isinstance(a[0], tuple) and a[0][0] == 'S': result = a[2]
    elif op in ('D', 'T'):
        x, y = a
        if x == '0': result = y
        elif isinstance(x, tuple) and x[0] == 'S':
            n = x[1]
            result = node('D', y, n) if op == 'D' else node('C', node('D', y, n), n, y)
        elif derived and op == 'D' and x == y:
            result = '0'
        elif derived and op == 'D' and y == node('S', x):
            result = node('S', '0')
    return t if result == t else rewrite(result, derived)


def symbolic_checks():
    S = lambda t: node('S', t)
    D = lambda x, y: node('D', x, y)
    T = lambda x, y: node('T', x, y)
    C = lambda x, y, z: node('C', x, y, z)
    tests = [
        ('predecessor zero', D('0', '0'), '0', False),
        ('predecessor successor', D(S('n'), '0'), 'n', False),
        ('T11', T(S('0'), S('0')), '0', False),
        ('stationary D diagonal', D(S('n'), S('n')), D('n', 'n'), False),
        ('stationary D adjacent', D(S('n'), S(S('n'))), D('n', S('n')), False),
        ('T positive diagonal', T(S('n'), S('n')), 'n', True),
        ('equality bit equal branch', C(D('y', T(S('y'), S('y'))), S('0'), '0'), S('0'), True),
        ('equality bit unequal branch', C(D('y', S('y')), S('0'), '0'), '0', True),
    ]
    for name, term, expected, derived in tests:
        assert rewrite(term, derived) == expected, name
    return {'passed': len(tests), 'names': [t[0] for t in tests],
            'scope': 'Derived diagonal rules enabled only in last three checks; not an induction proof.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--json', type=Path)
    args = parser.parse_args()
    old_T = node('C', node('D', 'a', 'n'),
                 node('C', node('D', 'n', 'a'), 'a', '0'), 'a')
    new_T = node('C', node('D', 'a', 'n'), 'n', 'a')
    result = {
        'status': 'pass',
        'scope': 'Finite diagnostics and syntax metrics, not full proof-assistant verification.',
        'metrics_by_passive_arity': {str(m): syntax_metrics(m) for m in range(1, 7)},
        'selected_body_nodes': {'old_C': 1, 'old_D': 1, 'old_T': count(old_T),
                                'new_C': 1, 'new_D': 1, 'new_T': count(new_T)},
        'symbolic_rewrites': symbolic_checks(),
        'compiler_checks': compiler_checks(),
    }
    assert count(old_T) == 11 and count(new_T) == 6
    if args.json:
        args.json.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
