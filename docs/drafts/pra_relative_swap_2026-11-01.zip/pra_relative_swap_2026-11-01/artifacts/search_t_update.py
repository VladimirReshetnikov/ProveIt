#!/usr/bin/env python3
"""Exhaustive local update-term check for the initialized-swap PRA basis.

This is a finite diagnostic, not a formalization of PRA or its interpretations.
It exhausts all raw syntax trees of at most five nodes in the fixed grammar

    t ::= 0 | n | a | v | S(t) | D(t,t) | C(t,t,t).

Every symbol occurrence is one node.  There is no semantic pruning.
In the standard natural numbers,
    D(x,y) = y-x if x <= y, and x-y-1 otherwise,
    C(z,u,w) = u if z == 0, and w otherwise.

For a candidate initialized-swap program T_h, the required off-diagonal law
T_h(x,y)=y for x!=y and separation T_h(1,1)!=1 entail four constraints:
    h(0,0,0)=0, h(1,0,1)=0, h(0,1,0)!=1, h(0,2,0)=2.
The first two come from T_h(1,0) and T_h(2,0); using them, the next two
come from T_h(1,1) and T_h(1,2).  Failure of a necessary constraint therefore
refutes that candidate, independently of any unbounded search.

All 628 raw trees of size <=5 fail one of these necessary constraints.
The six-node update C(D(a,n),n,a) passes and is checked numerically below.
The accompanying manuscript supplies the unbounded mathematical proof.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter
from functools import lru_cache
from pathlib import Path


ATOMS = ("0", "n", "a", "v")
CONSTRAINTS = (
    ("T(1,0)=0", (0, 0, 0), "eq", 0),
    ("T(2,0)=0", (1, 0, 1), "eq", 0),
    ("T(1,1)!=1", (0, 1, 0), "ne", 1),
    ("T(1,2)=2", (0, 2, 0), "eq", 2),
)
NEW_UPDATE = ("C", ("D", "a", "n"), "n", "a")


@lru_cache(maxsize=None)
def terms(size: int) -> tuple:
    """All raw ordered ASTs of exactly size nodes, without deduplication."""
    if size < 1:
        return ()
    if size == 1:
        return ATOMS
    output = [("S", x) for x in terms(size - 1)]
    for i in range(1, size - 1):
        j = size - 1 - i
        output.extend(("D", x, y) for x in terms(i) for y in terms(j))
    for i in range(1, size - 2):
        for j in range(1, size - 1 - i):
            k = size - 1 - i - j
            output.extend(
                ("C", x, y, z)
                for x in terms(i)
                for y in terms(j)
                for z in terms(k)
            )
    return tuple(output)


def node_count(term) -> int:
    if isinstance(term, str):
        return 1
    return 1 + sum(node_count(child) for child in term[1:])


def pretty(term) -> str:
    if isinstance(term, str):
        return term
    return term[0] + "(" + ",".join(map(pretty, term[1:])) + ")"


def distance(x: int, y: int) -> int:
    return y - x if x <= y else x - y - 1


def evaluate(term, n: int, a: int, v: int) -> int:
    if isinstance(term, str):
        return {"0": 0, "n": n, "a": a, "v": v}[term]
    op = term[0]
    if op == "S":
        return evaluate(term[1], n, a, v) + 1
    if op == "D":
        return distance(
            evaluate(term[1], n, a, v), evaluate(term[2], n, a, v)
        )
    if op == "C":
        test = evaluate(term[1], n, a, v)
        branch = term[2] if test == 0 else term[3]
        return evaluate(branch, n, a, v)
    raise AssertionError(op)


def first_failure(term):
    for label, arguments, relation, expected in CONSTRAINTS:
        actual = evaluate(term, *arguments)
        valid = actual == expected if relation == "eq" else actual != expected
        if not valid:
            return {
                "constraint": label,
                "arguments": list(arguments),
                "actual": actual,
                "required_relation": relation,
                "comparison_value": expected,
            }
    return None


def numerical_checks(sum_bound: int) -> dict:
    """Evaluate actual swap recurrences by their decreasing argument sum."""
    d_values = {}
    t_values = {}
    count = 0
    for total in range(sum_bound + 1):
        for x in range(total + 1):
            y = total - x
            if x == 0:
                d_value = y
                t_value = y
            else:
                d_value = d_values[y, x - 1]
                t_value = evaluate(NEW_UPDATE, x - 1, y, t_values[y, x - 1])
            d_values[x, y] = d_value
            t_values[x, y] = t_value
            assert d_value == distance(x, y), (x, y, d_value)
            expected = y - 1 if x == y and y > 0 else y
            assert t_value == expected, (x, y, t_value, expected)
            assert t_value == y or x == y
            count += 1
    assert t_values[1, 1] == 0
    # Check the derived equality term, using the proved numerical D/T values.
    bit_count = 0
    for x in range(sum_bound):
        for y in range(sum_bound - x - 1):
            value = t_values[x + 1, y + 1]
            bit = 1 if distance(y, value) == 0 else 0
            assert bit == int(x == y), (x, y, bit)
            bit_count += 1
    return {
        "maximum_argument_sum": sum_bound,
        "recurrence_pairs_checked": count,
        "equality_bit_pairs_checked": bit_count,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", type=Path, help="Write all 628 rejection witnesses.")
    parser.add_argument("--sum-bound", type=int, default=64)
    args = parser.parse_args()
    if args.sum_bound < 2:
        parser.error("--sum-bound must be at least 2")
    by_size = {}
    failures = Counter()
    witnesses = []
    for size in range(1, 6):
        candidates = terms(size)
        assert len(candidates) == len(set(candidates)), "Raw ASTs duplicated"
        by_size[size] = len(candidates)
        for term in candidates:
            assert node_count(term) == size
            failure = first_failure(term)
            assert failure is not None, ("Unexpected survivor", pretty(term))
            failures[failure["constraint"]] += 1
            witnesses.append({"term": pretty(term), "size": size, **failure})
    assert by_size == {1: 4, 2: 4, 3: 20, 4: 116, 5: 484}
    assert node_count(NEW_UPDATE) == 6
    assert first_failure(NEW_UPDATE) is None
    summary = {
        "scope": "Fixed update grammar only; no global axiomatization minimum claimed",
        "raw_terms_by_size": by_size,
        "raw_terms_total": len(witnesses),
        "survivors_through_size_five": 0,
        "first_failure_counts": dict(failures),
        "selected_update": pretty(NEW_UPDATE),
        "selected_update_nodes": node_count(NEW_UPDATE),
        "numerical_checks": numerical_checks(args.sum_bound),
    }
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(
            json.dumps({"summary": summary, "witnesses": witnesses}, indent=2) + "\n",
            encoding="utf-8",
        )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
