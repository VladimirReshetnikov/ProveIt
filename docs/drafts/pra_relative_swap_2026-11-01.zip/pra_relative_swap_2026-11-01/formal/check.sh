#!/bin/sh
set -eu
PRA_LEAN_BIN="${PRA_LEAN_BIN:-lean}"
PRA_FORMAL_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
"$PRA_LEAN_BIN" --version
"$PRA_LEAN_BIN" "$PRA_FORMAL_DIR/InitializedProbe.lean"
