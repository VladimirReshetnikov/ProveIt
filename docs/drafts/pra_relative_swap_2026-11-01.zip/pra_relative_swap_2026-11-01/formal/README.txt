LEAN VERIFICATION: INITIALIZED PROBE BASIS, T6
=============================================

Checked with Lean 4.19.0, official Linux x86_64 release.
Lean commit: 6caaee842e94.
Toolchain download provenance and observed SHA-256 are recorded in
toolchain-provenance.json; the large toolchain itself is not included.
Toolchain URL:
https://github.com/leanprover/lean4/releases/tag/v4.19.0

Replay:
  lean InitializedProbe.lean
or:
  PRA_LEAN_BIN=/absolute/path/to/lean sh check.sh

No imports or external Lean packages are required. This file uses only
Lean's core prelude and kernel. lean-verification.txt contains the successful
output (exit status 0) from the delivered source. The 18 printed endpoints
have no additional kernel axioms: no classical choice, propositional
extensionality, quotient soundness, or admitted proof is used. The arithmetic
assumptions are explicit structure fields; the dependency report does NOT
mean those arithmetic hypotheses have been proved from pure logic.

THE EXACT VERIFIED BASIS
------------------------
An arbitrary carrier alpha with 0, S, C, D, T is supplied. Assumptions:
  C(0,a,b)=a; C(Sn,a,b)=b;
  D(0,a)=a; D(Sn,a)=D(a,n);
  T(0,a)=a; T(Sn,a)=C(D(a,n),n,a);
  0 != S0;
  for stationary f, T(f(0),a)=a OR f(n)=a.
The predecessor abbreviation is D(x,0). The functions C,D,T are precisely
the selected swap descriptions in the report; the file takes their resulting
computation instances as fields rather than formalizing language generation.

WHAT IS CHECKED
---------------
- Successor injectivity and nonzero successors.
- The off-diagonal alternative from the constant probe instance.
- Stationary preservation of one and zero.
- D(n,n)=0 and D(n,Sn)=1, hence Sn!=n.
- T(Sn,Sn)=n.
- Exact zero classification and a computed native-equality test.
- General contextual constancy directly from the probe.
- Ordinary recursion from the raw C,D swap compiler.
- A latch argument for Boolean-coded induction.
- Structural compilation of quantifier-free formulas, including implication.
- Quantifier-free induction, end-to-end from one explicitly specified swap
  program for the required latch.

SCOPE LIMITS
------------
The probe field uses a semantic function interface, which is stronger in
form than the first-order scheme over finite terms. Every instance used in
the proofs is term-shaped and is described in the source and report; the
finite-term restriction and its enumeration are not formalized here.
Formula atoms similarly carry semantic functions standing for specified
finite terms with fixed parameters. Structural induction is on this finite
formula syntax, never on the arbitrary arithmetic carrier.

The final induction theorem takes the exact seed and update equations for
one swap-program instance. It does not assume an induction principle on the
carrier. The computation grammar guarantees that instance in the paper.

This file does NOT formalize the reverse ordinary-PRA compiler, the full
first-order proof translation, effective description enumeration, or the
bi-interpretation round trips. Those are written mathematical proofs in
the report. A successful replay must not be described as complete formal
verification of the report's bi-interpretability theorem.

PROVENANCE
----------
The previous InitializedSwap.lean kernel supplied in the user's
pra_initialized_swap_2026-10-31 archive was used as a starting point.
The basis, bootstrap, native equality normalization, direct constancy,
ordinary-recursion compiler, and final composed induction endpoint were
updated for this report. The formula compiler and latch arguments reuse
that constructive proof pattern with the new basis.
