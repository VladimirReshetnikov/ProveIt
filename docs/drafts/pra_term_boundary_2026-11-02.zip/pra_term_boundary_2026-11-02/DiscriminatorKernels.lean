/- Local proof kernels for the 0,D initialized-recursion presentation.
Successor is literally D(x,x); no separate diagonal axiom is assumed.
This does not formalize the complete finite-syntax compiler or the
bi-interpretation of theories. -/
namespace PRADiscriminator

universe u

section ExplicitNoFix

variable {B : Type u} (zero : B) (d : B → B → B)

/-- Nontriviality and the designated Q computation equations imply the
usual separation sentence, without induction. -/
theorem nontrivial_sep (q : B → B → B)
    (q_zero : ∀ a, q zero a = a)
    (q_succ : ∀ n a, q (d n n) a = n)
    (nontrivial : ∃ u, u ≠ zero) : zero ≠ d zero zero := by
  intro h
  have collapse : ∀ a, a = zero := by
    intro a
    calc
      a = q zero a := (q_zero a).symm
      _ = q (d zero zero) a := congrArg (fun r => q r a) h
      _ = zero := q_succ zero a
  obtain ⟨u, hu⟩ := nontrivial
  exact hu (collapse u)

/-- The alternative fixed axiom supplies separation at zero directly. -/
theorem noFix_sep (noFix : ∀ x, d x x ≠ x) : zero ≠ d zero zero := by
  intro h
  exact noFix zero h.symm

/-- The successor nonzeroness used by the compact proof follows from
Q and separation; it is not a new independent arithmetic axiom. -/
theorem successor_nonzero_from_q (q : B → B → B)
    (q_zero : ∀ a, q zero a = a)
    (q_succ : ∀ n a, q (d n n) a = n)
    (sep : zero ≠ d zero zero) : ∀ x, d x x ≠ zero := by
  intro x h
  have hx := congrArg (fun r => q r zero) h
  change q (d x x) zero = q zero zero at hx
  rw [q_succ, q_zero] at hx
  subst x
  exact sep h.symm

variable (z : B → B → B)

def CompactSchema (t : B → B) : Prop :=
  ∀ n, ∃ b, ∀ x, (x = b ∨ (x = d b b ∧ b ≠ n)) →
    z (t x) x = z (d x b) x

/-- This certificate matches the fixed-NoFix presentation literally:
there is no flip function or flip step anywhere in its type. The tail
may take arbitrary successor values, matching the written compiler. -/
theorem compactNoFix_induction (t : B → B)
    (off : ∀ x y, x = y ∨ d x y = zero)
    (noFix : ∀ x, d x x ≠ x)
    (succ_nonzero : ∀ x, d x x ≠ zero)
    (z_zero : ∀ a, z zero a = a)
    (z_succ : ∀ x a, z (d x x) a = zero)
    (schema : CompactSchema d z t)
    (range : ∀ x, t x = zero ∨ ∃ y, t x = d y y)
    (base : t zero ≠ zero)
    (step : ∀ x, t x ≠ zero → t (d x x) ≠ zero) :
    ∀ n, t n ≠ zero := by
  intro n
  obtain ⟨b, hb⟩ := schema n
  have at_b := hb b (Or.inl rfl)
  rw [z_succ] at at_b
  have tb : t b ≠ zero := by
    intro ht
    rw [ht, z_zero] at at_b
    subst b
    exact base ht
  have tsb := step b tb
  rcases off b n with hbn | hdzero
  · simpa only [hbn] using tb
  · have hne : b ≠ n := by
      intro hbn
      subst n
      exact succ_nonzero b hdzero
    have at_sb := hb (d b b) (Or.inr ⟨rfl, hne⟩)
    have hd : d (d b b) b = zero := by
      rcases off (d b b) b with hfixed | hz
      · exact False.elim (noFix b hfixed)
      · exact hz
    have hleft : z (t (d b b)) (d b b) = zero := by
      rcases range (d b b) with ht | ⟨v, ht⟩
      · exact False.elim (tsb ht)
      · rw [ht, z_succ]
    rw [hleft, hd, z_zero] at at_sb
    exact False.elim (succ_nonzero b at_sb.symm)

/-- The reverse boundary verification for raw terms, also with an
explicit NoFix premise instead of any auxiliary flip computation. -/
theorem boundary_to_compactNoFix (t : B → B)
    (off : ∀ x y, x = y ∨ d x y = zero)
    (noFix : ∀ x, d x x ≠ x)
    (succ_nonzero : ∀ x, d x x ≠ zero)
    (z_zero : ∀ a, z zero a = a)
    (z_succ : ∀ x a, z (d x x) a = zero)
    (range : ∀ x, t x = zero ∨ ∃ y, t x = d y y)
    (boundary : ∀ n, ∃ b,
      (b = zero ∨ t b ≠ zero) ∧ (t (d b b) ≠ zero → b = n)) :
    CompactSchema d z t := by
  intro n
  obtain ⟨b, hb, hn⟩ := boundary n
  refine ⟨b, ?_⟩
  intro x hx
  rcases hx with hxb | ⟨hxsb, hbn⟩
  · subst x
    rw [z_succ]
    rcases range b with ht | ⟨v, ht⟩
    · rw [ht, z_zero]
      rcases hb with hb0 | hbne
      · exact hb0
      · exact False.elim (hbne ht)
    · rw [ht, z_succ]
  · subst x
    have ht : t (d b b) = zero := by
      rcases off (t (d b b)) zero with ht | hz
      · exact ht
      · have hne : t (d b b) ≠ zero := by
          intro h0
          rw [h0] at hz
          exact succ_nonzero zero hz
        exact False.elim (hbn (hn hne))
    have hd : d (d b b) b = zero := by
      rcases off (d b b) b with heq | hz
      · exact False.elim (noFix b heq)
      · exact hz
    rw [ht, hd]

end ExplicitNoFix

structure Kernel (A : Type u) where
  zero : A
  d : A → A → A
  z : A → A → A
  pred : A → A
  flip : A → A
  sep : zero ≠ d zero zero
  off : ∀ x y, x = y ∨ d x y = zero
  z_zero : ∀ a, z zero a = a
  z_succ : ∀ x a, z (d x x) a = zero
  pred_zero : pred zero = zero
  pred_succ : ∀ x, pred (d x x) = x
  flip_step : ∀ n, flip (d n n) = d (flip n) zero

variable {A : Type u} (k : Kernel A)

theorem succ_ne_zero (x : A) : k.d x x ≠ k.zero := by
  intro h
  have hp := congrArg k.pred h
  rw [k.pred_succ, k.pred_zero] at hp
  subst x
  exact k.sep h.symm

theorem succ_injective {x y : A} (h : k.d x x = k.d y y) : x = y := by
  have hp := congrArg k.pred h
  simpa only [k.pred_succ] using hp

theorem d_zero_iff (x y : A) : k.d x y = k.zero ↔ x ≠ y := by
  constructor
  · intro hz hxy
    subst y
    exact succ_ne_zero k x hz
  · intro hne
    rcases k.off x y with heq | hz
    · exact False.elim (hne heq)
    · exact hz

/-- The flip descriptor is D(v,0), an ordinary finite earlier term. -/
theorem no_fixed_point (n : A) : k.d n n ≠ n := by
  intro hs
  have hf := k.flip_step n
  rw [hs] at hf
  rcases k.off (k.flip n) k.zero with hz | hc
  · rw [hz] at hf
    exact k.sep hf
  · have hz : k.flip n = k.zero := hf.trans hc
    rw [hz] at hc
    exact k.sep hc.symm

def BooleanTail (t : A → A) : Prop :=
  ∀ x, t x = k.zero ∨ t x = k.d k.zero k.zero

def Boundary (t : A → A) (n b : A) : Prop :=
  (b = k.zero ∨ t b ≠ k.zero) ∧ (t (k.d b b) ≠ k.zero → b = n)

def TwoCopySchema (t : A → A) : Prop :=
  ∀ n, ∃ b, k.z (t b) b = k.zero ∧ (t (k.d b b) = k.zero ∨ b = n)

theorem twoCopy_induction (t : A → A)
    (schema : TwoCopySchema k t)
    (boolean : BooleanTail k t)
    (base : t k.zero = k.d k.zero k.zero)
    (step : ∀ x, t x = k.d k.zero k.zero → t (k.d x x) = k.d k.zero k.zero) :
    ∀ n, t n = k.d k.zero k.zero := by
  intro n
  obtain ⟨b, hb, hn⟩ := schema n
  have tb : t b = k.d k.zero k.zero := by
    rcases boolean b with hz | ho
    · rw [hz, k.z_zero] at hb
      simpa only [hb] using base
    · exact ho
  rcases hn with hs | hbn
  · exact False.elim (k.sep (hs.symm.trans (step b tb)))
  · simpa only [hbn] using tb

def OneCopySchema (t : A → A) : Prop :=
  ∀ n, ∃ b, ∀ x, (x = b ∨ (x = k.d b b ∧ b ≠ n)) →
    k.z (t x) x = k.z (k.d x b) x

theorem oneCopy_induction (t : A → A)
    (schema : OneCopySchema k t)
    (boolean : BooleanTail k t)
    (base : t k.zero = k.d k.zero k.zero)
    (step : ∀ x, t x = k.d k.zero k.zero → t (k.d x x) = k.d k.zero k.zero) :
    ∀ n, t n = k.d k.zero k.zero := by
  intro n
  obtain ⟨b, hb⟩ := schema n
  have at_b := hb b (Or.inl rfl)
  rw [k.z_succ] at at_b
  have tb : t b = k.d k.zero k.zero := by
    rcases boolean b with hz | ho
    · rw [hz, k.z_zero] at at_b
      simpa only [at_b] using base
    · exact ho
  have tsb := step b tb
  rcases k.off b n with hbn | hzero
  · simpa only [hbn] using tb
  · have hne := (d_zero_iff k b n).mp hzero
    have at_sb := hb (k.d b b) (Or.inr ⟨rfl, hne⟩)
    have hd := (d_zero_iff k (k.d b b) b).mpr (no_fixed_point k b)
    rw [tsb, k.z_succ, hd, k.z_zero] at at_sb
    exact False.elim (succ_ne_zero k b at_sb.symm)

theorem boundary_to_twoCopy (t : A → A)
    (range : ∀ x, t x = k.zero ∨ ∃ y, t x = k.d y y)
    (boundary : ∀ n, ∃ b, Boundary k t n b) :
    TwoCopySchema k t := by
  intro n
  obtain ⟨b, hb, hn⟩ := boundary n
  refine ⟨b, ?_, ?_⟩
  · rcases range b with ht | ⟨y, ht⟩
    · rw [ht, k.z_zero]
      rcases hb with hb0 | hbne
      · exact hb0
      · exact False.elim (hbne ht)
    · rw [ht, k.z_succ]
  · rcases k.off (t (k.d b b)) k.zero with h0 | hz
    · exact Or.inl h0
    · exact Or.inr (hn ((d_zero_iff k _ _).mp hz))

theorem boundary_to_oneCopy (t : A → A)
    (range : ∀ x, t x = k.zero ∨ ∃ y, t x = k.d y y)
    (boundary : ∀ n, ∃ b, Boundary k t n b) :
    OneCopySchema k t := by
  intro n
  obtain ⟨b, hb, hn⟩ := boundary n
  refine ⟨b, ?_⟩
  intro x hx
  rcases hx with hxb | ⟨hxsb, hbn⟩
  · subst x
    rw [k.z_succ]
    rcases range b with ht | ⟨y, ht⟩
    · rw [ht, k.z_zero]
      rcases hb with hb0 | hbne
      · exact hb0
      · exact False.elim (hbne ht)
    · rw [ht, k.z_succ]
  · subst x
    have ht : t (k.d b b) = k.zero := by
      rcases k.off (t (k.d b b)) k.zero with ht | hz
      · exact ht
      · exact False.elim (hbn (hn ((d_zero_iff k _ _).mp hz)))
    have hd := (d_zero_iff k (k.d b b) b).mpr (no_fixed_point k b)
    rw [ht, hd]

def SharedTwoCopySchema (t : A → A) : Prop :=
  ∀ n, ∃ b, ∃ c, c = k.d b b ∧
    k.z (t b) b = k.zero ∧ (t c = k.zero ∨ b = n)

theorem sharedTwoCopy_iff (t : A → A) :
    SharedTwoCopySchema k t ↔ TwoCopySchema k t := by
  constructor
  · intro h n
    obtain ⟨b, c, hc, hb, hn⟩ := h n
    subst c
    exact ⟨b, hb, hn⟩
  · intro h n
    obtain ⟨b, hb, hn⟩ := h n
    exact ⟨b, k.d b b, rfl, hb, hn⟩

#print axioms no_fixed_point
#print axioms nontrivial_sep
#print axioms noFix_sep
#print axioms successor_nonzero_from_q
#print axioms compactNoFix_induction
#print axioms boundary_to_compactNoFix
#print axioms twoCopy_induction
#print axioms oneCopy_induction
#print axioms boundary_to_twoCopy
#print axioms boundary_to_oneCopy
#print axioms sharedTwoCopy_iff

end PRADiscriminator
