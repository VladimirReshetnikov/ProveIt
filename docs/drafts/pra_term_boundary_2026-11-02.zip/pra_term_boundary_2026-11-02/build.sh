#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
mkdir -p verification
python3 check_sizes.py --output verification/size_results.json
python3 check_witnesses.py --output verification/witness_results.json
pra_lean_bin="${PRA_LEAN:-lean}"
if command -v "$pra_lean_bin" >/dev/null 2>&1; then
  "$pra_lean_bin" --version > verification/lean_version.txt
  "$pra_lean_bin" BoundaryKernels.lean > verification/lean_boundary.txt
  "$pra_lean_bin" DiscriminatorKernels.lean > verification/lean_discriminator.txt
else
  echo 'Lean is unavailable; Python and PDF checks continue. Set PRA_LEAN to run Lean.'
fi
for pra_pass in 1 2 3; do
  pdflatex -interaction=nonstopmode -halt-on-error pra_term_boundary.tex > "verification/latex_pass_${pra_pass}.txt"
done
echo 'Build and available checks completed.'
