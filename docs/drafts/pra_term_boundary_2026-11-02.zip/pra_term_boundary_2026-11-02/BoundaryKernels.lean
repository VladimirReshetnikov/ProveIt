/-
Logical kernels for the proposed one-occurrence PRA induction schemata.
This file checks the local arithmetic/logic argument, not a syntax-level
formalization of all of PRA or of its bi-interpretation.
-/
namespace PRAOneOccurrence

universe u

section AtomicBoundary

variable {B : Type u} (zero : B) (succ : B → B)

def AtomicBoundary (f g : B → B) : Prop :=
  ∀ n, ∃ b, (b = zero ∨ f b = g b) ∧ (f (succ b) = g (succ b) → b = n)

/-- Atomic boundary gives induction for the very same equation. -/
theorem atomicBoundary_induction (f g : B → B)
    (boundary : AtomicBoundary zero succ f g)
    (base : f zero = g zero)
    (step : ∀ x, f x = g x → f (succ x) = g (succ x)) :
    ∀ n, f n = g n := by
  intro n
  obtain ⟨b, hb, hn⟩ := boundary n
  have heq : f b = g b := by
    rcases hb with hb0 | heq
    · simpa only [hb0] using base
    · exact heq
  have hbn := hn (step b heq)
  simpa only [hbn] using heq

/-- One atomic boundary instance yields predecessor coverage directly;
the base of x = S(p(x)) is not required to hold. -/
theorem atomicBoundary_coverage (pred : B → B)
    (pred_succ : ∀ x, pred (succ x) = x)
    (boundary : AtomicBoundary zero succ (fun x => x) (fun x => succ (pred x))) :
    ∀ n, n = zero ∨ n = succ (pred n) := by
  intro n
  obtain ⟨b, hb, hn⟩ := boundary n
  have hnext : succ b = succ (pred (succ b)) := by rw [pred_succ]
  have hbn := hn hnext
  simpa only [hbn] using hb

/-- Once a fixed formula has an exact finite characteristic term, its
induction instance is just an atomic equation instance. -/
theorem atomicInduction_transport (one : B) (P : B → Prop) (f : B → B)
    (exact_bit : ∀ x, P x ↔ f x = one)
    (ind : f zero = one →
      (∀ x, f x = one → f (succ x) = one) → ∀ x, f x = one)
    (base : P zero) (step : ∀ x, P x → P (succ x)) : ∀ x, P x := by
  have hbase := (exact_bit zero).mp base
  have hstep : ∀ x, f x = one → f (succ x) = one := by
    intro x hx
    exact (exact_bit (succ x)).mp (step x ((exact_bit x).mpr hx))
  intro x
  exact (exact_bit x).mpr (ind hbase hstep x)

end AtomicBoundary

section TableBoundary

variable {B : Type u} (zero : B) (succ : B → B) (z : B → B → B)

def TableSchema (t : B → B) : Prop :=
  ∀ n, ∃ b, ∀ x y,
    ((x = b ∧ y = zero) ∨ (x = succ b ∧ y = x ∧ b ≠ n)) →
      z (t x) x = y

/-- One-copy table induction uses no flip function or no-fixed-point
lemma. Its explicit premises are valid in both the S and D bases. -/
theorem table_induction (one : B) (t : B → B)
    (z_zero : ∀ x, z zero x = x)
    (z_one : ∀ x, z one x = zero)
    (succ_nonzero : ∀ x, succ x ≠ zero)
    (eq_cases : ∀ x y : B, x = y ∨ x ≠ y)
    (schema : TableSchema zero succ z t)
    (boolean : ∀ x, t x = zero ∨ t x = one)
    (base : t zero = one)
    (step : ∀ x, t x = one → t (succ x) = one) : ∀ n, t n = one := by
  intro n
  obtain ⟨b, hb⟩ := schema n
  have at_b := hb b zero (Or.inl ⟨rfl, rfl⟩)
  have tb : t b = one := by
    rcases boolean b with hz | ho
    · rw [hz, z_zero] at at_b
      simpa only [at_b] using base
    · exact ho
  rcases eq_cases b n with hbn | hne
  · simpa only [hbn] using tb
  · have at_sb := hb (succ b) (succ b) (Or.inr ⟨rfl, rfl, hne⟩)
    rw [step b tb, z_one] at at_sb
    exact False.elim (succ_nonzero b at_sb.symm)

/-- PRA's raw-term coverage and bounded boundary witness verify every
row of the universal table; again, no fixed-point premise is present. -/
theorem boundary_to_table (t : B → B)
    (z_zero : ∀ x, z zero x = x)
    (z_succ : ∀ y x, z (succ y) x = zero)
    (eq_cases : ∀ x y : B, x = y ∨ x ≠ y)
    (range : ∀ x, t x = zero ∨ ∃ y, t x = succ y)
    (boundary : ∀ n, ∃ b,
      (b = zero ∨ t b ≠ zero) ∧ (t (succ b) ≠ zero → b = n)) :
    TableSchema zero succ z t := by
  intro n
  obtain ⟨b, hb, hn⟩ := boundary n
  refine ⟨b, ?_⟩
  intro x y hrow
  rcases hrow with ⟨hxb, hy0⟩ | ⟨hxsb, hyx, hbn⟩
  · subst x
    subst y
    rcases range b with ht | ⟨v, ht⟩
    · rw [ht, z_zero]
      rcases hb with hb0 | hbne
      · exact hb0
      · exact False.elim (hbne ht)
    · rw [ht, z_succ]
  · subst x
    subst y
    have ht : t (succ b) = zero := by
      rcases eq_cases (t (succ b)) zero with ht | hne
      · exact ht
      · exact False.elim (hbn (hn hne))
    rw [ht, z_zero]

end TableBoundary

structure Kernel (A : Type u) where
  zero : A
  succ : A → A
  chi : A → A → A
  z : A → A → A
  pred : A → A
  flip : A → A
  sep : zero ≠ succ zero
  diag : ∀ x, chi x x = succ zero
  off : ∀ x y, x = y ∨ chi x y = zero
  z_zero : ∀ a, z zero a = a
  z_succ : ∀ x a, z (succ x) a = zero
  pred_zero : pred zero = zero
  pred_succ : ∀ x, pred (succ x) = x
  flip_step : ∀ n, flip (succ n) = chi (flip n) zero

variable {A : Type u} (k : Kernel A)

theorem chi_one_iff (x y : A) :
    k.chi x y = k.succ k.zero ↔ x = y := by
  constructor
  · intro h
    rcases k.off x y with hxy | hz
    · exact hxy
    · exact False.elim (k.sep (hz.symm.trans h))
  · intro h
    subst y
    exact k.diag x

theorem chi_zero_iff (x y : A) :
    k.chi x y = k.zero ↔ x ≠ y := by
  constructor
  · intro hz hxy
    subst y
    exact k.sep (hz.symm.trans (k.diag x))
  · intro hne
    rcases k.off x y with heq | hz
    · exact False.elim (hne heq)
    · exact hz

theorem succ_ne_zero (x : A) : k.succ x ≠ k.zero := by
  intro h
  have hp := congrArg k.pred h
  rw [k.pred_succ, k.pred_zero] at hp
  subst x
  exact k.sep h.symm

theorem succ_injective {x y : A} (h : k.succ x = k.succ y) : x = y := by
  have hp := congrArg k.pred h
  simpa only [k.pred_succ] using hp

/-- A single initialized-recursion step rules out successor fixed points.
No induction or predecessor coverage is assumed. -/
theorem no_fixed_point (n : A) : k.succ n ≠ n := by
  intro hs
  have hf := k.flip_step n
  rw [hs] at hf
  rcases k.off (k.flip n) k.zero with hz | hc
  · rw [hz, k.diag] at hf
    exact k.sep hf
  · have hz : k.flip n = k.zero := hf.trans hc
    rw [hz, k.diag] at hc
    exact k.sep hc.symm

def ZeroTailSchema (t : A → A) : Prop :=
  ∀ n, ∃ b, ∀ x, (x = b ∨ x = k.succ b) →
    (b = k.z (k.chi x b) n ∨
      k.chi (t x) k.zero = k.chi x b)

/-- The disjunctive-exception schema gives induction for t(x)=0,
with no range assumption on t. -/
theorem zeroTail_induction (t : A → A)
    (schema : ZeroTailSchema k t)
    (base : t k.zero = k.zero)
    (step : ∀ x, t x = k.zero → t (k.succ x) = k.zero) :
    ∀ n, t n = k.zero := by
  intro n
  obtain ⟨b, hb⟩ := schema n
  have at_b := hb b (Or.inl rfl)
  rw [k.diag, k.z_succ] at at_b
  have tb : t b = k.zero := by
    rcases at_b with h0 | ht
    · simpa only [h0] using base
    · exact (chi_one_iff k (t b) k.zero).mp ht
  have tsb := step b tb
  have at_sb := hb (k.succ b) (Or.inr rfl)
  have hchi := (chi_zero_iff k (k.succ b) b).mpr (no_fixed_point k b)
  rw [hchi, k.z_zero, tsb, k.diag] at at_sb
  rcases at_sb with hbn | impossible
  · simpa only [hbn] using tb
  · exact False.elim (k.sep impossible.symm)

def BoundaryZero (t : A → A) (n b : A) : Prop :=
  (b = k.zero ∨ t b = k.zero) ∧ (t (k.succ b) = k.zero → b = n)

/-- A boundary witness verifies every instance of the one-occurrence
zero-tail matrix, including all arbitrary x. -/
theorem boundaryZero_to_schema (t : A → A)
    (boundary : ∀ n, ∃ b, BoundaryZero k t n b) :
    ZeroTailSchema k t := by
  intro n
  obtain ⟨b, hb, hn⟩ := boundary n
  refine ⟨b, ?_⟩
  intro x hx
  rcases hx with hxb | hxsb
  · subst x
    rw [k.diag, k.z_succ]
    rcases hb with h0 | ht
    · exact Or.inl h0
    · exact Or.inr ((chi_one_iff k (t b) k.zero).mpr ht)
  · subst x
    have hc := (chi_zero_iff k (k.succ b) b).mpr (no_fixed_point k b)
    rw [hc, k.z_zero]
    rcases k.off b n with hbn | hzero
    · exact Or.inl hbn
    · right
      apply (chi_zero_iff k (t (k.succ b)) k.zero).mpr
      intro ht
      exact (chi_zero_iff k b n).mp hzero (hn ht)

def NonzeroTailSchema (t : A → A) : Prop :=
  ∀ n, ∃ b, ∀ x, (x = b ∨ (x = k.succ b ∧ b ≠ n)) →
    k.chi (k.z (t x) x) k.zero = k.chi x b

def BooleanTail (t : A → A) : Prop :=
  ∀ x, t x = k.zero ∨ t x = k.succ k.zero

/-- The alternative numeric matrix gives induction on a Boolean tail.
Its forward proof does not assume coverage for arbitrary elements. -/
theorem nonzeroTail_induction (t : A → A)
    (schema : NonzeroTailSchema k t)
    (boolean : BooleanTail k t)
    (base : t k.zero = k.succ k.zero)
    (step : ∀ x, t x = k.succ k.zero → t (k.succ x) = k.succ k.zero) :
    ∀ n, t n = k.succ k.zero := by
  intro n
  obtain ⟨b, hb⟩ := schema n
  have at_b := hb b (Or.inl rfl)
  rw [k.diag] at at_b
  have tb : t b = k.succ k.zero := by
    rcases boolean b with hz | ho
    · rw [hz, k.z_zero] at at_b
      have h0 := (chi_one_iff k b k.zero).mp at_b
      simpa only [h0] using base
    · exact ho
  have tsb := step b tb
  rcases k.off b n with hbn | hzero
  · simpa only [hbn] using tb
  · have hne := (chi_zero_iff k b n).mp hzero
    have at_sb := hb (k.succ b) (Or.inr ⟨rfl, hne⟩)
    have hc := (chi_zero_iff k (k.succ b) b).mpr (no_fixed_point k b)
    rw [tsb, k.z_succ, k.diag, hc] at at_sb
    exact False.elim (k.sep at_sb.symm)

def BoundaryNonzero (t : A → A) (n b : A) : Prop :=
  (b = k.zero ∨ t b ≠ k.zero) ∧ (t (k.succ b) ≠ k.zero → b = n)

/-- In PRA, coverage supplies the range premise for every raw term.
Together with a boundary witness it verifies the alternative schema. -/
theorem boundaryNonzero_to_schema (t : A → A)
    (range : ∀ x, t x = k.zero ∨ ∃ y, t x = k.succ y)
    (boundary : ∀ n, ∃ b, BoundaryNonzero k t n b) :
    NonzeroTailSchema k t := by
  intro n
  obtain ⟨b, hb, hn⟩ := boundary n
  refine ⟨b, ?_⟩
  intro x hx
  rcases hx with hxb | ⟨hxsb, hbn⟩
  · subst x
    have hz : k.z (t b) b = k.zero := by
      rcases range b with ht | ⟨y, ht⟩
      · rw [ht, k.z_zero]
        rcases hb with hb0 | hbne
        · exact hb0
        · exact False.elim (hbne ht)
      · rw [ht, k.z_succ]
    rw [hz, k.diag, k.diag]
  · subst x
    have ht : t (k.succ b) = k.zero := by
      rcases k.off (t (k.succ b)) k.zero with ht | hz
      · exact ht
      · exact False.elim (hbn (hn ((chi_zero_iff k _ _).mp hz)))
    rw [ht, k.z_zero]
    have hc0 := (chi_zero_iff k (k.succ b) k.zero).mpr (succ_ne_zero k b)
    have hcb := (chi_zero_iff k (k.succ b) b).mpr (no_fixed_point k b)
    rw [hc0, hcb]

def boundaryWitness (p : Nat → Bool) : Nat → Nat
  | 0 => 0
  | n + 1 => if p (boundaryWitness p n + 1) = true then n + 1 else boundaryWitness p n

def TwoCopySchema (t : A → A) : Prop :=
  ∀ n, ∃ b, k.z (t b) b = k.zero ∧ (t (k.succ b) = k.zero ∨ b = n)

/-- The direct two-occurrence numeric schema needs neither a successor
fixed-point argument nor coverage for its forward Boolean-tail proof. -/
theorem twoCopy_induction (t : A → A)
    (schema : TwoCopySchema k t)
    (boolean : BooleanTail k t)
    (base : t k.zero = k.succ k.zero)
    (step : ∀ x, t x = k.succ k.zero → t (k.succ x) = k.succ k.zero) :
    ∀ n, t n = k.succ k.zero := by
  intro n
  obtain ⟨b, hb, hn⟩ := schema n
  have tb : t b = k.succ k.zero := by
    rcases boolean b with hz | ho
    · rw [hz, k.z_zero] at hb
      simpa only [hb] using base
    · exact ho
  rcases hn with hs | hbn
  · exact False.elim (k.sep (hs.symm.trans (step b tb)))
  · simpa only [hbn] using tb

/-- The reverse verification for arbitrary raw terms uses exactly
the PRA coverage/range lemma and its finite boundary witness. -/
theorem boundaryNonzero_to_twoCopy (t : A → A)
    (range : ∀ x, t x = k.zero ∨ ∃ y, t x = k.succ y)
    (boundary : ∀ n, ∃ b, BoundaryNonzero k t n b) :
    TwoCopySchema k t := by
  intro n
  obtain ⟨b, hb, hn⟩ := boundary n
  refine ⟨b, ?_, ?_⟩
  · rcases range b with ht | ⟨y, ht⟩
    · rw [ht, k.z_zero]
      rcases hb with hb0 | hbne
      · exact hb0
      · exact False.elim (hbne ht)
    · rw [ht, k.z_succ]
  · rcases k.off (t (k.succ b)) k.zero with h0 | hz
    · exact Or.inl h0
    · exact Or.inr (hn ((chi_zero_iff k _ _).mp hz))

def SharedTwoCopySchema (t : A → A) : Prop :=
  ∀ n, ∃ b, ∃ c, c = k.succ b ∧
    k.z (t b) b = k.zero ∧ (t c = k.zero ∨ b = n)

theorem sharedTwoCopy_iff (t : A → A) :
    SharedTwoCopySchema k t ↔ TwoCopySchema k t := by
  constructor
  · intro h n
    obtain ⟨b, c, hc, hb, hn⟩ := h n
    subst c
    exact ⟨b, hb, hn⟩
  · intro h n
    obtain ⟨b, hb, hn⟩ := h n
    exact ⟨b, k.succ b, rfl, hb, hn⟩

/-- The bounded primitive-recursive witness invariant used by the
reverse interpretation. The proof uses only induction on this QF invariant. -/
theorem boundaryWitness_spec (p : Nat → Bool) (n : Nat) :
    (boundaryWitness p n = 0 ∨ p (boundaryWitness p n) = true) ∧
    (p (boundaryWitness p n + 1) = true → boundaryWitness p n = n) := by
  induction n with
  | zero =>
      constructor
      · exact Or.inl rfl
      · intro _
        rfl
  | succ n ih =>
      cases hp : p (boundaryWitness p n + 1) with
      | false =>
          have hd : boundaryWitness p (n + 1) = boundaryWitness p n := by
            simp only [boundaryWitness, hp, Bool.false_eq_true, ↓reduceIte]
          rw [hd]
          constructor
          · exact ih.1
          · intro h
            rw [hp] at h
            cases h
      | true =>
          have hbn := ih.2 hp
          have hd : boundaryWitness p (n + 1) = n + 1 := by
            simp only [boundaryWitness, hp, ↓reduceIte]
          rw [hd]
          constructor
          · right
            simpa only [hbn] using hp
          · intro _
            rfl

#print axioms no_fixed_point
#print axioms atomicBoundary_induction
#print axioms atomicBoundary_coverage
#print axioms atomicInduction_transport
#print axioms table_induction
#print axioms boundary_to_table
#print axioms zeroTail_induction
#print axioms boundaryZero_to_schema
#print axioms nonzeroTail_induction
#print axioms boundaryNonzero_to_schema
#print axioms twoCopy_induction
#print axioms boundaryNonzero_to_twoCopy
#print axioms sharedTwoCopy_iff
#print axioms boundaryWitness_spec

end PRAOneOccurrence
