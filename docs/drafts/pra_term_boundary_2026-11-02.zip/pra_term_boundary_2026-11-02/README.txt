PRA FROM EQUATIONS AND DIRECT TERM BOUNDARIES
Research archive prepared for Vladimir Reshetnikov, 2 November 2026

READ FIRST

pra_term_boundary.pdf is the complete report; pra_term_boundary.tex is its
editable source. AXIOMS.txt gives every symbol constructor and nonlogical
axiom of the principal presentations. The report includes complete written
proofs, a comparison with all seven current and six archived proposals,
exact size accounting, and Further research questions.

MAIN RESULTS

1. Native equation-boundary core: initial 0,S, one initialized binary
   recursor constructor, 0!=S0, and a boundary schema indexed by two terms.
   Coverage is derived directly from one atomic instance; equation
   induction then supplies the arithmetic bootstrap and all QF induction.

2. Direct numerical boundary: eliminates the extra equality-bit packing
   in the current fused boundary. In the common primitive-successor
   vocabulary it costs 2T+i+15 full nodes instead of 2T+i+17.

3. A one-occurrence output table costs T+33 full nodes (T+34 after merging
   successor into D). It needs no toggle/fixed-point prelude. The current
   optional fused table costs T+43 in the matched primitive-S vocabulary.

4. In the 0,D branch, the new 17-node seed plus a direct/shared module
   saves 5, 4, or 3 full nodes against the best current fixed-plus-one-module
   envelope, depending on the active input occurrence count. A complete
   19-node NoFix basis permits the still smaller compact T+30 table without
   hidden support; even its direct/shared alternatives retain savings of
   3, 2, or 1 nodes. Exact workloads and limits are stated in the report.

CALIBRATION

Bi-interpretability is proved for the usual first-order presentation of
PRA (all first-order formulas, induction only for quantifier-free formulas).
The report distinguishes this from the traditional quantifier-free
calculus. Both interpretations use the whole carrier; both round trips
are internally the identity. Each statement holds separately classically
and intuitionistically. No uniform primitive-recursive evaluator or
standard-model assumption is used.

FILES

  pra_term_boundary.tex / .pdf   Full report and compiled document
  AXIOMS.txt                     Complete specifications
  BoundaryKernels.lean           Generic and primitive-S local kernels
  DiscriminatorKernels.lean      0,D local kernels
  check_sizes.py                 Exact AST and frozen-description counts
  check_witnesses.py             Exhaustive finite witness sanity checks
  build.sh                       Rebuild/check driver
  provenance/                    Exact input inventories and hashes
  verification/                  Check outputs and PDF build/QA summaries
  MANIFEST.sha256                Hashes of archive members (except itself)

REPRODUCING CHECKS

Requires Python 3.10+, a standard TeX Live installation, and optionally
Lean 4.19.0 (no mathlib dependency). From this directory:

  python3 check_sizes.py --output verification/size_results.json
  python3 check_witnesses.py --output verification/witness_results.json
  lean BoundaryKernels.lean
  lean DiscriminatorKernels.lean
  pdflatex -interaction=nonstopmode -halt-on-error pra_term_boundary.tex
  pdflatex -interaction=nonstopmode -halt-on-error pra_term_boundary.tex
  pdflatex -interaction=nonstopmode -halt-on-error pra_term_boundary.tex

Or run: bash build.sh
Set the task-specific PRA_LEAN executable path if lean is not on PATH.

VERIFICATION LIMIT

The Lean files verify local implications and the explicit natural-number
boundary witness. They do not formalize the entire syntax, arithmetic
compiler, or bi-interpretation. Abstract kernel results use no axioms;
the concrete Nat witness uses propext through simplification. Python
finite checks are supporting experiments, not substitutes for the proofs.

SOURCE SNAPSHOT

  356163ca545206e31dd6b634f9c9bfc1596b3cac
  https://github.com/VladimirReshetnikov/ProveIt/tree/356163ca545206e31dd6b634f9c9bfc1596b3cac/docs/drafts

All thirteen ZIPs were checked against their Git blob hashes. Their
source bytes are not duplicated in this archive; immutable URLs and
SHA-256 hashes make the audit reproducible. No repository changes were
made. The result is a research deliverable, not an absolute shortestness
theorem across arbitrary languages or metrics.
