VERIFICATION RECORD

The final two Lean source files compile with Lean 4.19.0 without mathlib.
Their captured outputs list the axioms used by each reported theorem.
The abstract kernels report no axioms. The Nat witness proof reports
propext, arising from simplification. Neither file declares new axioms
or uses sorry. These files are local kernel checks, not a mechanization
of the complete bi-interpretation.

size_results.json comes from check_sizes.py: it constructs literal ASTs,
charges frozen descriptions recursively at every occurrence, tests active
substitution without capture, checks the displayed identities, and records
exceptions to invalid per-module comparisons with the old covered branch.
The identities also have written derivations in the report.

witness_results.json comes from check_witnesses.py: 66,407 finite
obligations were checked, over Boolean and three-valued raw tails.
These are sanity checks; the report proves the invariant in PRA.

latex_pass_1.txt through latex_pass_3.txt record the final PDF build.
pdf_review.json records visual inspection of all nineteen rendered pages
and text-box geometry. There are no final LaTeX warnings, overfull boxes,
or unresolved references.

The manuscript and its mathematical dependencies were independently
reviewed, including the coverage bootstrap, pairing, parameter compiler,
reverse witnesses, identity round trips, and the NoFix basis substitution.
No claim of an encoding-independent global minimum is made.
