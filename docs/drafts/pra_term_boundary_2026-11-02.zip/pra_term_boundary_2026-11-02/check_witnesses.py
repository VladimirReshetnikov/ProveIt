#!/usr/bin/env python3
"""Exhaustive finite sanity checks for the boundary certificate.

This is not a proof in PRA. The report supplies that proof through a
quantifier-free invariant, and BoundaryKernels.lean checks its Nat kernel.
No external dependencies. Run with --output verification/witness_results.json.
"""
import argparse
import itertools
import json
from pathlib import Path


def z(test, value):
    return value if test == 0 else 0


def d(x, y):
    return x + 1 if x == y else 0


def candidate(values, n):
    b = 0
    assert b == 0 or values[b] != 0
    for k in range(n):
        if values[b + 1] != 0:
            b = k + 1
        assert b == 0 or values[b] != 0
        assert values[b + 1] == 0 or b == k + 1
    return b


def check(values, n):
    b = candidate(values, n)
    assert 0 <= b <= n
    # Full direct certificate, with arbitrary numerical (not just Boolean) tail.
    assert z(values[b], b) == 0
    assert values[b + 1] == 0 or b == n
    # Every possible active row of the universally quantified table.
    for x, y in [(b, 0), (b + 1, b + 1)]:
        guard = (x == b and y == 0) or (x == b + 1 and y == x and b != n)
        assert not guard or z(values[x], x) == y
    # Compact D form, whose extra no-fixed-point requirement holds in Nat.
    for x in {b, b + 1}:
        guard = x == b or (x == b + 1 and b != n)
        assert not guard or z(values[x], x) == z(d(x, b), x)
    return b


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output')
    args = ap.parse_args()
    totals = []
    for alphabet, length in [((0, 1), 11), ((0, 1, 2), 8)]:
        sequences = obligations = stopped = reached = 0
        for values in itertools.product(alphabet, repeat=length):
            sequences += 1
            for n in range(length - 1):
                b = check(values, n)
                obligations += 1
                stopped += b != n
                reached += b == n
        totals.append({
            'alphabet': alphabet, 'length': length, 'sequences': sequences,
            'obligations': obligations, 'stopped_before_target': stopped,
            'reached_target': reached,
        })
    # Explicit examples of the two witness behaviors, plus an all-zero tail.
    examples = []
    for values, n in [([1, 1, 1, 0, 2, 1, 1], 5), ([0, 1, 2, 1, 2, 1, 0], 5),
                      ([0] * 7, 5)]:
        examples.append({'tail': values, 'target': n, 'witness': check(values, n)})
    report = {
        'status': 'PASS',
        'scope': 'Finite sanity checks only; mathematical validity is proved separately.',
        'cases': totals,
        'total_obligations': sum(row['obligations'] for row in totals),
        'examples': examples,
        'table_scope': 'The guard is false away from its two listed rows, so those rows exhaust the universal obligation for each chosen witness.',
    }
    out = json.dumps(report, indent=2) + '\n'
    if args.output:
        Path(args.output).write_text(out)
        print(json.dumps({'status': 'PASS', 'obligations': report['total_obligations'],
                          'output': args.output}))
    else:
        print(out, end='')


if __name__ == '__main__':
    main()
