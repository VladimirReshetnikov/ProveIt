SOURCE AUDIT

All seven current and six archived ZIPs were fetched from the exact commit
356163ca545206e31dd6b634f9c9bfc1596b3cac.

source_inventory.json preserves the GitHub metadata used for discovery.
Its main-branch URLs describe the discovery response; use the immutable
URLs in source_manifest.json or source_hashes.csv for reproduction.

source_manifest.json gives exact ZIP byte lengths, Git blob SHA-1 values,
SHA-256 values, and every top-level extracted TeX member hash. The Git
blob check is SHA1(b"blob " + str(length).encode() + b"\0" + bytes).
The original source archives are not duplicated in this deliverable.

The report, Section 1, records each current package's improvement over
the archived iteration. Sections 8 and 9 compare the surviving options,
including optional one-copy tables, fixed support, covered alternatives,
and the distinct active-only measure. None of the seven current packages
was discarded wholesale; several individual options are dominated.
