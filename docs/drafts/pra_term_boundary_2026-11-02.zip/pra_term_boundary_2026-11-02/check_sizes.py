#!/usr/bin/env python3
"""Independent AST size audit for the proposed PRA boundary schemas.

Counts one node per variable, constant, application, equality, connective,
falsity, and quantifier. Full size additionally counts each generated
symbol's complete frozen descriptor at every occurrence, recursively.
Negation is implication to falsity. No external dependencies.

This audits syntax and stated inequalities, not mathematical equivalence.
Sample admissibility flags distinguish the two initial signatures. Applying
a counting template to a payload from the other signature is only a
syntactic profile calculation, never a free cross-language translation.
Run `python3 check_sizes.py` for a JSON report, or use --output PATH.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path
import random


@dataclass(frozen=True)
class Symbol:
    name: str
    arity: int
    descriptor: Expr | None = None


@dataclass(frozen=True)
class Expr:
    tag: str
    args: tuple[Expr, ...] = ()
    name: str = ""
    symbol: Symbol | None = None


def var(name):
    return Expr("var", name=name)


def app(symbol, *args):
    assert len(args) == symbol.arity
    return Expr("app", tuple(args), symbol=symbol)


def eq(a, b):
    return Expr("eq", (a, b))


def AND(a, b):
    return Expr("and", (a, b))


def OR(a, b):
    return Expr("or", (a, b))


def IMP(a, b):
    return Expr("imp", (a, b))


def neq(a, b):
    return IMP(eq(a, b), Expr("false"))


def bind(prefix, body):
    for kind, name in reversed(prefix):
        body = Expr(kind, (body,), name=name)
    return body


def size(e, full=False):
    n = 1 + sum(size(c, full) for c in e.args)
    if full and e.tag == "app" and e.symbol.descriptor is not None:
        n += size(e.symbol.descriptor, True)
    return n


def fv(e):
    if e.tag == "var":
        return {e.name}
    names = set().union(*(fv(c) for c in e.args))
    if e.tag in ("forall", "exists"):
        names.discard(e.name)
    return names


def all_names(e):
    names = fv(e)
    if e.tag in ("forall", "exists"):
        names.add(e.name)
    for c in e.args:
        names |= all_names(c)
    return names


def subst(e, mapping):
    """Capture-avoiding active substitution; never visits descriptors."""
    if e.tag == "var":
        return mapping.get(e.name, e)
    if e.tag in ("forall", "exists"):
        name = e.name
        body = e.args[0]
        active = {k: v for k, v in mapping.items() if k != name}
        incoming = set().union(*(fv(v) for v in active.values()))
        if name in incoming:
            used = all_names(body) | incoming | set(active)
            k = 0
            while f"{name}_{k}" in used:
                k += 1
            fresh = f"{name}_{k}"
            body = subst(body, {name: var(fresh)})
            name = fresh
        return Expr(e.tag, (subst(body, active),), name=name)
    return Expr(e.tag, tuple(subst(c, mapping) for c in e.args), e.name, e.symbol)


def occurrences(e, name):
    if e.tag == "var":
        return int(e.name == name)
    if e.tag in ("forall", "exists") and e.name == name:
        return 0
    return sum(occurrences(c, name) for c in e.args)


def primitive_names(e):
    names = set()
    if e.tag == "app":
        if e.symbol.descriptor is None:
            names.add(e.symbol.name)
        else:
            names |= primitive_names(e.symbol.descriptor)
    for child in e.args:
        names |= primitive_names(child)
    return names


ZERO = Symbol("0", 0)
SUCC = Symbol("S", 1)
CHI = Symbol("chi", 2)
DISC = Symbol("D", 2)
zero = app(ZERO)
x, a, n, b, c, d, r, s, u, v, w, y = map(var, "x a n b c d r s u v w y".split())
QSYM = Symbol("R_w", 2, w)
ZSYM = Symbol("R_0", 2, zero)


def Q(a, b):
    return app(QSYM, a, b)


def Z(a, b):
    return app(ZSYM, a, b)


def chi(a, b):
    return app(CHI, a, b)


def D(a, b):
    return app(DISC, a, b)


def S(a, merged=False):
    return D(a, a) if merged else app(SUCC, a)


def at(t, arg):
    assert fv(t) <= {"x", "a"}
    return subst(t, {"x": arg})


PREFIX = (("forall", "a"), ("forall", "n"), ("exists", "b"))


def new_two(t, merged=False, shared=False):
    source = d if shared else S(b, merged)
    core = AND(eq(Z(at(t, b), b), zero), OR(eq(at(t, source), zero), eq(b, n)))
    if shared:
        return bind(PREFIX + (("exists", "d"),), AND(eq(d, S(b, merged)), core))
    return bind(PREFIX, core)


def new_one(t, merged=False, algebraic_guard=False):
    if algebraic_guard:
        assert merged
        guard = eq(x, Q(D(x, b), Q(D(b, n), D(b, b))))
    else:
        guard = OR(eq(x, b), AND(eq(x, S(b, merged)), neq(b, n)))
    if merged:
        matrix = eq(Z(t, x), Z(D(x, b), x))
    else:
        matrix = eq(chi(Z(t, x), zero), chi(x, b))
    return bind(PREFIX + (("forall", "x"),), IMP(guard, matrix))


def new_no_flip_table(t, merged=False):
    first_row = AND(eq(x, b), eq(y, zero))
    second_row = AND(eq(x, S(b, merged)), AND(eq(y, x), neq(b, n)))
    guard = OR(first_row, second_row)
    matrix = eq(Z(t, x), y)
    return bind(PREFIX + (("forall", "x"), ("forall", "y")), IMP(guard, matrix))


def toggle_step(merged=False):
    h = D(v, zero) if merged else chi(v, zero)
    rec = Symbol("R", 2, h)
    left = app(rec, S(n, merged), a)
    value = app(rec, n, a)
    right = D(value, zero) if merged else chi(value, zero)
    return bind((("forall", "a"), ("forall", "n")), eq(left, right))


def old_factored(t, merged=False, shifted=True, shared=False):
    source = d if shared else (S(b, merged) if shifted else b)
    core = AND(eq(c, Q(Z(at(t, source), source), n)), eq(Z(at(t, c), c), zero))
    if shared:
        return bind(PREFIX + (("exists", "d"), ("exists", "c")), AND(eq(d, S(b, merged)), core))
    return bind(PREFIX + (("exists", "c"),), core)


def old_fused(t, shared=False):
    source = d if shared else S(b)
    core = eq(chi(b, Q(Z(at(t, source), source), n)), S(Z(at(t, b), b)))
    if shared:
        return bind(PREFIX + (("exists", "d"),), AND(eq(d, S(b)), core))
    return bind(PREFIX, core)


def old_fused_table(t):
    K = eq(chi(b, Q(Z(r, S(b)), n)), S(Z(s, b)))
    guard = OR(AND(eq(x, b), eq(y, s)), AND(eq(x, S(b)), eq(y, r)))
    table = bind((("forall", "x"), ("forall", "y")), IMP(guard, eq(t, y)))
    return bind(PREFIX + (("exists", "r"), ("exists", "s")), AND(K, table))


def old_mask_fused(t, shifted=False):
    mask = Symbol("M_t", 2, t)
    def M(x):
        return app(mask, x, a)
    definition = eq(M(n), Z(at(t, n), n))
    witness = eq(M(Q(M(S(b) if shifted else b), n)), zero)
    return bind(PREFIX, AND(definition, witness))


def native_boundary_raw(t):
    P = neq(t, zero)
    body = AND(OR(eq(b, zero), at(P, b)), IMP(at(P, S(b)), eq(b, n)))
    return bind(PREFIX, body)


def pair(e):
    return {"active": size(e), "full": size(e, True)}


def pretty(e):
    if e.tag == "var":
        return e.name
    if e.tag == "app":
        name = e.symbol.name
        if e.symbol.descriptor is not None and name not in ("R_w", "R_0"):
            name += "_{" + pretty(e.symbol.descriptor) + "}"
        return name + ("(" + ",".join(map(pretty, e.args)) + ")" if e.args else "")
    if e.tag in ("forall", "exists"):
        return f"{e.tag} {e.name}." + pretty(e.args[0])
    if e.tag == "false":
        return "false"
    return e.tag + "(" + ",".join(map(pretty, e.args)) + ")"


def check_one(t):
    m, T, i = size(t), size(t, True), occurrences(t, "x")
    assert T >= m >= 1 and 2*i <= m+1
    entries = {
        "new_S_two": (new_two(t), (2*m+i+14, 2*T+i+15)),
        "new_S_shared": (new_two(t, shared=True), (2*m+20, 2*T+21)),
        "new_S_one": (new_one(t), (m+27, T+28)),
        "new_D_two": (new_two(t, merged=True), (2*m+2*i+14, 2*T+2*i+15)),
        "new_D_shared": (new_two(t, merged=True, shared=True), (2*m+21, 2*T+22)),
        "new_D_one": (new_one(t, merged=True), (m+28, T+30)),
        "new_D_one_algebraic": (new_one(t, merged=True, algebraic_guard=True), (m+26, T+30)),
        "new_S_no_flip_table": (new_no_flip_table(t), (m+32, T+33)),
        "new_D_no_flip_table": (new_no_flip_table(t, merged=True), (m+33, T+34)),
        "old_S_factored": (old_factored(t), (2*m+i+16, 2*T+i+19)),
        "old_D_factored": (old_factored(t, merged=True), (2*m+2*i+17, 2*T+2*i+20)),
        "old_D_shared": (old_factored(t, merged=True, shared=True), (2*m+22, 2*T+25)),
        "old_covered_factored": (old_factored(t, shifted=False), (2*m+15, 2*T+18)),
        "old_fused": (old_fused(t), (2*m+i+14, 2*T+i+17)),
        "old_fused_shared": (old_fused(t, shared=True), (2*m+19, 2*T+22)),
        "old_fused_table": (old_fused_table(t), (m+40, T+43)),
        "old_mask_fused12": (old_mask_fused(t), (m+19, 4*T+21)),
        "old_mask_fused13": (old_mask_fused(t, shifted=True), (m+20, 4*T+22)),
        "old_native_raw": (native_boundary_raw(t), (2*m+i+20, 2*T+i+20)),
    }
    actual = {}
    for name, (tree, expected) in entries.items():
        measured = (size(tree), size(tree, True))
        assert measured == expected, (name, pretty(t), measured, expected)
        assert fv(tree) == set(), (name, fv(tree))
        actual[name] = {"active": measured[0], "full": measured[1]}
    primitives = primitive_names(t)
    return {"tail": pretty(t), "m": m, "T": T, "i": i,
            "admissible_S_chi": primitives <= {"0", "S", "chi"},
            "admissible_D": primitives <= {"0", "D"},
            "counts": actual}


def samples():
    nested_body = Q(app(SUCC, v), Z(w, v))
    rec1 = Symbol("R", 2, nested_body)
    rec2 = Symbol("R", 2, app(rec1, v, Q(w, v)))
    selected = [
        zero, x, a, chi(x, a), D(x, a),
        chi(x, chi(x, chi(x, x))),
        D(x, D(x, D(x, D(x, x)))),
        app(rec2, S(x), a),
    ]
    rng = random.Random(20261102)
    def make(depth):
        if not depth or rng.randrange(4) == 0:
            return rng.choice([x, a, zero])
        sym = rng.choice([SUCC, CHI, DISC, QSYM, ZSYM, rec1, rec2])
        return app(sym, *(make(depth-1) for _ in range(sym.arity)))
    return selected, [make(rng.randrange(1, 6)) for _ in range(256)]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output")
    args = parser.parse_args()
    # Explicitly test frozen descriptors and capture avoidance.
    desc = Q(v, w)
    sym = Symbol("R", 2, desc)
    frozen = subst(app(sym, v, a), {"v": S(b)})
    assert frozen.symbol.descriptor is desc
    assert frozen.args[0] == S(b)
    captured = subst(bind((("forall", "b"),), eq(x, b)), {"x": b})
    assert fv(captured) == {"b"} and captured.name != "b"

    off = bind((("forall", "x"), ("forall", "y")), OR(eq(x, y), eq(D(x, y), zero)))
    nontriv = bind((("exists", "x"),), neq(x, zero))
    nofix_S = bind((("forall", "x"),), neq(S(x), x))
    nofix_D = bind((("forall", "x"),), neq(D(x, x), x))
    assert pair(off) == {"active": 11, "full": 11}
    assert pair(nontriv) == {"active": 6, "full": 6}
    assert pair(nofix_S) == {"active": 7, "full": 7}
    assert pair(nofix_D) == {"active": 8, "full": 8}
    assert pair(toggle_step()) == {"active": 12, "full": 18}
    assert pair(toggle_step(merged=True)) == {"active": 13, "full": 19}
    selected, random_terms = samples()
    selected_results = [check_one(t) for t in selected]
    for t in random_terms:
        check_one(t)

    failed_local_S = []
    failed_local_D = []
    verified_points = 0
    for T in range(1, 513):
        for i in range((T+1)//2 + 1):
            verified_points += 1
            ns = min(2*T+i+15, 2*T+21, T+28)
            nd = min(2*T+2*i+15, 2*T+22, T+30)
            ns_no_flip = min(2*T+i+15, 2*T+21, T+33)
            nd_no_flip = min(2*T+2*i+15, 2*T+22, T+34)
            oldS_without_covered = min(2*T+i+17, 2*T+22, T+43, 4*T+21)
            # New S always improves the fused-boundary/mask full envelope.
            assert ns < oldS_without_covered
            assert ns_no_flip < oldS_without_covered
            # D candidates improve the old seed17 factored branch locally.
            assert nd < min(2*T+2*i+20, 2*T+25, 4*T+21)
            assert nd_no_flip < min(2*T+2*i+20, 2*T+25, 4*T+21)
            if ns > 2*T+18:
                failed_local_S.append({"T": T, "i": i, "new": ns, "covered_old": 2*T+18})
            if nd > 2*T+18:
                failed_local_D.append({"T": T, "i": i, "new": nd, "covered_old": 2*T+18})
            # Compare a single D module including its honest seed17 vs seed24.
            assert 17+nd < 24+2*T+18
            # Stronger honest one-module theorem needing no one-copy toggle:
            new_D_two_support = 17+min(2*T+2*i+15, 2*T+22)
            actual_old_D_support = min(37+2*T+2*i, 42+2*T)
            expected_saving = 5 if i <= 2 else (4 if i == 3 else 3)
            assert actual_old_D_support-new_D_two_support == expected_saving
            # Optional replacement seeds: NoFix replaces, rather than adds to,
            # Sep in S/chi or Nontriv in D. This pays for the compact table.
            assert 25+ns <= 24+oldS_without_covered
            assert 19+nd < actual_old_D_support
            assert actual_old_D_support-(19+min(2*T+2*i+15, 2*T+22)) == expected_saving-2

    report = {
        "status": "PASS: AST counts and the explicitly asserted inequalities",
        "scope": "Syntax audit only; neither a semantic proof nor an unqualified domination claim.",
        "signature_matching": "Every sample reports admissibility separately in 0,S,chi,R and 0,D,R. Other-branch counts are abstract profiles; no equal-cost translation between unlike primitive vocabularies is claimed.",
        "metric": "One node per AST occurrence; full size recursively charges frozen descriptions at each generated-symbol occurrence; negation expands to implication/falsity.",
        "frozen_substitution_and_capture_avoidance": "PASS",
        "seed_D": {"off": pair(off), "nontriviality": pair(nontriv), "total": 17},
        "one_copy_additional_finite_support": {
            "S_toggle_step": pair(toggle_step()),
            "D_toggle_step": pair(toggle_step(merged=True)),
            "warning": "The compact T+28/T+30 one-copy tables need the toggle recursion STEP once unless explicitly common earlier background. The two-copy schemas and the newer no-flip T+33/T+34 tables need no such step.",
            "S_old_fused_table_comparison": "The one-copy schema saves 15 full nodes per use; two uses save 30, covering the 18-node new toggle step with 12 nodes remaining.",
        },
        "optional_replacement_seed": {
            "S_no_fixed_point_axiom": pair(nofix_S),
            "D_no_fixed_point_axiom": pair(nofix_D),
            "S_total_with_existing_bit_axiom": 25,
            "D_total_with_off_axiom": 19,
            "description": "Replace Sep6 by NoFix7 in S/chi, or Nontriv6 by NoFix8 in D. At x=0 NoFix implies the replaced premise. Compact one-copy schemas then need no toggle step. This is a separate fixed-versus-recurring tradeoff, not an uncharged strengthening.",
        },
        "samples": selected_results,
        "additional_random_tails": len(random_terms),
        "profile_grid": {"T_max": 512, "points": verified_points},
        "identities_verified": {
            "new_S_two": "active 2m+i+14; full 2T+i+15",
            "new_S_shared": "active 2m+20; full 2T+21",
            "new_S_one": "active m+27; full T+28",
            "new_D_two": "active 2m+2i+14; full 2T+2i+15",
            "new_D_shared": "active 2m+21; full 2T+22",
            "new_D_one": "active m+28; full T+30",
            "new_D_one_algebraic": "active m+26; full T+30",
            "new_S_no_flip_table": "active m+32; full T+33",
            "new_D_no_flip_table": "active m+33; full T+34",
        },
        "verified_comparisons": [
            "min(2T+i+15,2T+21,T+28) < min(2T+i+17,2T+22,T+43,4T+21)",
            "min(2T+i+15,2T+21,T+33) < min(2T+i+17,2T+22,T+43,4T+21), requiring no toggle support",
            "min(2T+2i+15,2T+22,T+30) < min(2T+2i+20,2T+25,4T+21)",
            "min(2T+2i+15,2T+22,T+34) < min(2T+2i+20,2T+25,4T+21), requiring no toggle support",
            "17+min(2T+2i+15,2T+22,T+30) < 24+(2T+18)",
            "min(37+2T+2i,42+2T) - [17+min(2T+2i+15,2T+22)] = 5 (i<=2), 4 (i=3), or 3 (i>=4)",
            "25+min(2T+i+15,2T+21,T+28) <= 24+min(2T+i+17,2T+22,T+43,4T+21) with explicit S NoFix replacement seed",
            "min(37+2T+2i,42+2T) - [19+min(2T+2i+15,2T+22)] = 3 (i<=2), 2 (i=3), or 1 (i>=4) with explicit D NoFix replacement seed",
        ],
        "local_comparison_exceptions_to_covered_old": {
            "S": failed_local_S,
            "D": failed_local_D,
            "warning": "Old covered 2T+18 is not uniformly dominated per-module; seed differences repair the one-module D support comparison but cannot be silently reused for arbitrary sums.",
        },
        "proof_dependency": "The compact T+28/T+30 one-copy kernels need S(b)!=b and its toggle step. The newer T+33/T+34 output-table kernel instead instantiates (x,y)=(b,0) and (S(b),S(b)); progress plus S(b)!=0 suffice, even without an independent S(b)!=b theorem.",
    }
    output = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        Path(args.output).write_text(output)
        print(json.dumps({"status": report["status"], "output": args.output, "sample_count": len(selected_results), "random_count": len(random_terms), "profile_points": verified_points, "S_local_exceptions": len(failed_local_S), "D_local_exceptions": len(failed_local_D)}))
    else:
        print(output, end="")


if __name__ == "__main__":
    main()
