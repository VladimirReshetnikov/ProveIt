#!/usr/bin/env bash
set -eo pipefail
task_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$task_dir"
mkdir -p check-output
python3 artifacts/schema_metrics.py > check-output/schema_metrics.log
python3 artifacts/check_constructions.py > check-output/construction_checks.log
lean_cmd="$LEAN_BIN"
if [[ -z "$lean_cmd" ]]; then
  lean_cmd=lean
fi
"$lean_cmd" --version
"$lean_cmd" formal/StationaryComparison.lean > check-output/lean.log
cat check-output/lean.log
python3 - <<'PY'
import json
from pathlib import Path
checks = json.loads(Path("artifacts/construction_checks.json").read_text())
print("Formula-tree accounting passed.")
print("Finite construction diagnostics:", checks["total_checks"], "passed.")
print("Lean kernel completed successfully; see check-output/lean.log.")
PY
