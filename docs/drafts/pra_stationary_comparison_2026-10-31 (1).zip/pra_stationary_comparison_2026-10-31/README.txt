PRA FROM STATIONARY COMPARISON
=============================
Prepared for Vladimir Reshetnikov, 31 October 2026.

MAIN RESULT
One fixed sentence, 0!=S0, and one stationary-comparison schema suffice
beyond the two computation templates. The same nonlogical basis works in
classical and intuitionistic first-order logic. In each matching logic it
has a common conservative definitional extension with ordinary PRA, so
both bi-interpretability and equiconsistency are proved.

WHAT IS SIMPLER
- In exactly the previous substitution-descent language, the representative
  formula display decreases from 54 to 52 nodes.
- The direct equality-diagonal proof needs only SC on e(n,n).
- The recommended language fixes the changing-parameter operation to p,
  eliminating the arbitrary third recursion descriptor k.
- Its three designated programs p,C,e have 13 stored body nodes, versus
  19 for all stored inputs of the prior selected P,B,e descriptions.
These measures do not establish absolute shortestness. The manuscript
discloses arity, tuple, descriptor, and dummy-argument costs.

START HERE
  pra_stationary_comparison.pdf   Complete report, proofs, and comparison.
  pra_stationary_comparison.tex   Exact LaTeX source of the report.
  AXIOMS.txt                     Standalone effective specification.

REPRODUCIBILITY
  build.sh                       Build the PDF with latexmk/pdflatex.
  check.sh                       Run Python diagnostics and the Lean kernel.
  artifacts/schema_metrics.py    Reconstruct formula trees and body counts.
  artifacts/schema_metrics.json  Recorded counts.
  artifacts/check_constructions.py
                                 Finite compiler/guard/comparison checks.
  artifacts/construction_checks.json
                                 Recorded diagnostic results.
  formal/StationaryComparison.lean
                                 Constructive local proof kernel.
  formal/README.txt              Exact verification boundary and attribution.
  formal/StationaryComparison.log
                                 Successful compiler axiom audits.
  formal/lean-version.txt        Verified Lean toolchain.
  audit/source_manifest.json     Six exact draft sources, hashes, snapshot.
  audit/proof_review.txt         Independent mathematical review.
  audit/verification_summary.json
                                 Final build and diagnostic summary.
  SHA256SUMS.txt                 Integrity hashes of included files.

BUILD
  bash build.sh

CHECK
  bash check.sh

If Lean is not on PATH:
  LEAN_BIN=/absolute/path/to/lean bash check.sh

Python checks use the standard library. The formal kernel uses Lean
4.19.0 without Mathlib. The report uses common TeX Live packages listed
in its preamble. Build intermediates are written under build/ and
temporary verification output under check-output/.

VERIFICATION LIMITS
The full equivalence proof is a written mathematical proof.
Lean verifies computation corners, constructive equality/constancy,
the finite logical formula compiler, and the shifted-latch induction
argument. The formal interface supplies SC semantically over functions;
the manuscript explicitly lists its legal finite-term instances.
The description grammar, compiler in a formal first-order calculus,
and both round trips are not claimed to be fully formalized.
Finite numerical diagnostics are not proofs about nonstandard models.

SOURCES
All six current drafts were reviewed at ProveIt commit
392757d09455930d2b090b26bd1537799451c91a.
The incoming inventory and complete README were also inspected.
The closest predecessor is pra_substitution_descent_2026-10-31.zip.
The report attributes inherited constructions and distinguishes the new
schema, fixed-predecessor restriction, and equational guard proofs.
No files were committed to the repository.
