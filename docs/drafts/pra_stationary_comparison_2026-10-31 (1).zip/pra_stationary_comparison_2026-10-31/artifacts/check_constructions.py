#!/usr/bin/env python3
"""Finite diagnostics for the fixed-predecessor PRA presentation.

Run with Python 3; only the standard library is used. The output is written
next to this script as construction_checks.json, or to --output PATH.

These tests concern standard natural-number computations on finite grids.
They are not a proof about nonstandard models, all schema instances,
intuitionistic derivability, or the full bi-interpretation theorem.
"""

from __future__ import annotations

import argparse
from collections import Counter
from functools import lru_cache
from itertools import product
import json
from pathlib import Path
import random
from typing import Callable


SEED = 20261031
COUNTS: Counter[str] = Counter()


def check(name: str, condition: bool, **context: object) -> None:
    COUNTS[name] += 1
    if not condition:
        raise AssertionError({"check": name, **context})


def p(a: int) -> int:
    return max(a - 1, 0)


def z(a: int) -> int:
    """Convenient abbreviation C(a,1,0), not a designated source program."""
    return c(a, 1, 0)


def c(a: int, u: int, v: int) -> int:
    return u if a == 0 else v


def add(a: int, b: int) -> int:
    return a + b


def m(t: int, a: int) -> int:
    return max(a - t, 0)


def d(a: int, b: int) -> int:
    return m(b, a)


def guard(n: int, j: int) -> bool:
    """G_n(j) is literally an equation, without an order primitive."""
    return add(j, d(n, j)) == n


@lru_cache(maxsize=None)
def equality_program(n: int, a: int) -> int:
    if n == 0:
        return c(a, 1, 0)
    # This is exactly C(a, 0, e(n-1,p(a))).
    return c(a, 0, equality_program(n - 1, p(a)))


Frozen = tuple[int, ...]
Base = Callable[[int, Frozen], int]
Step = Callable[[int, int, Frozen, int], int]


def make_direct(g: Base, h: Step) -> Callable[[int, int, Frozen], int]:
    @lru_cache(maxsize=None)
    def direct(n: int, a: int, frozen: Frozen) -> int:
        if n == 0:
            return g(a, frozen)
        return h(n - 1, a, frozen, direct(n - 1, p(a), frozen))

    return direct


def fold_u(j: int, n: int, a: int, frozen: Frozen, g: Base, h: Step) -> int:
    value = g(m(n, a), frozen)
    for k in range(j):
        value = h(k, m(d(n, k + 1), a), frozen, value)
    return value


def compiled(n: int, a: int, frozen: Frozen, g: Base, h: Step) -> int:
    return fold_u(n, n, a, frozen, g, h)


def check_elementary_arithmetic() -> None:
    for a, b in product(range(33), repeat=2):
        ctx = {"a": a, "b": b}
        check("constructor_coverage", a == 0 or a == p(a) + 1, **ctx)
        check("addition_zero", add(a, 0) == a, **ctx)
        check("addition_successor", add(a, b + 1) == add(a, b) + 1, **ctx)
        check("subtraction_synchronized", d(a + 1, b + 1) == d(a, b), **ctx)
        check("subtraction_cancellation", d(add(a, b), a) == b, **ctx)
        check("predecessor_iteration_commutes", m(a, p(b)) == p(m(a, b)), **ctx)
    for n in range(41):
        check("guard_endpoints", guard(n, 0) and guard(n, n), n=n)
        for j in range(46):
            check("guard_has_expected_standard_values", guard(n, j) == (j <= n), n=n, j=j)
            if guard(n, j + 1):
                check("guard_downward", guard(n, j), n=n, j=j)
                check("guard_countdown", d(n, j) == d(n, j + 1) + 1, n=n, j=j)
            if guard(n, j):
                check("guard_head_shift", d(n + 1, j) == d(n, j) + 1, n=n, j=j)


def check_equality() -> None:
    for x, y in product(range(65), repeat=2):
        value = equality_program(x, y)
        check("comparison_grid", value == int(x == y), x=x, y=y)
        check("comparison_synchronized", equality_program(x + 1, y + 1) == value, x=x, y=y)
        check("comparison_boolean", value in (0, 1), x=x, y=y)
        check("comparison_off_diagonal", value == 0 or x == y, x=x, y=y)
    for n in range(41):
        for a in range(41):
            for j in range(n + 1):
                argument = m(d(n, j), a)
                check(
                    "comparison_antidiagonal_invariant",
                    equality_program(j, argument) == 0 or j == argument,
                    n=n, a=a, j=j,
                )


# A small, explicit language of PR expressions. The fixed modulus is
# used only to keep diagnostic values small; every operation is PR.
Expr = tuple


def literal(value: int) -> Expr:
    return ("constant", value)


def variable(name: str) -> Expr:
    return ("variable", name)


def evaluate(expr: Expr, env: dict[str, int]) -> int:
    op = expr[0]
    if op == "constant":
        return expr[1]
    if op == "variable":
        return env[expr[1]]
    values = [evaluate(child, env) for child in expr[1:]]
    if op == "add":
        return values[0] + values[1]
    if op == "multiply":
        return values[0] * values[1]
    if op == "monus":
        return max(values[0] - values[1], 0)
    if op == "minimum":
        return min(values)
    if op == "maximum":
        return max(values)
    if op == "zero":
        return z(values[0])
    if op == "selector":
        return c(values[0], values[1], values[2])
    if op == "mod101":
        return values[0] % 101
    raise ValueError(f"Unknown expression operation {op!r}")


def expression(rng: random.Random, variables: tuple[str, ...], depth: int) -> Expr:
    if depth == 0 or rng.randrange(5) == 0:
        if rng.randrange(3):
            return variable(rng.choice(variables))
        return literal(rng.randrange(5))
    op = rng.choice(("add", "multiply", "monus", "minimum", "maximum", "zero", "selector"))
    arity = 1 if op == "zero" else 3 if op == "selector" else 2
    return (op, *(expression(rng, variables, depth - 1) for _ in range(arity)))


def expressions_to_program(g_expr: Expr, h_expr: Expr) -> tuple[Base, Step]:
    def g(a: int, frozen: Frozen) -> int:
        return evaluate(g_expr, {"a": a, "b0": frozen[0], "b1": frozen[1]})

    def h(n: int, a: int, frozen: Frozen, value: int) -> int:
        return evaluate(h_expr, {"n": n, "a": a, "v": value, "b0": frozen[0], "b1": frozen[1]})

    return g, h


def check_one_program(name: str, g: Base, h: Step, frozen_values: tuple[Frozen, ...]) -> None:
    direct = make_direct(g, h)
    for n, a, frozen in product(range(11), range(12), frozen_values):
        ctx = {"program": name, "n": n, "a": a, "frozen": frozen}
        expected = direct(n, a, frozen)
        check("direct_equals_fold", expected == compiled(n, a, frozen, g, h), **ctx)
        check(
            "compiled_recursion_equation",
            compiled(n + 1, a, frozen, g, h)
            == h(n, a, frozen, compiled(n, p(a), frozen, g, h)),
            **ctx,
        )
        for j in range(n + 1):
            check(
                "internal_uniqueness_trace",
                direct(j, m(d(n, j), a), frozen) == fold_u(j, n, a, frozen, g, h),
                j=j, **ctx,
            )
            check(
                "compiler_head_shift_trace",
                fold_u(j, n + 1, a, frozen, g, h)
                == fold_u(j, n, p(a), frozen, g, h),
                j=j, **ctx,
            )


def check_compiler(rng: random.Random) -> list[dict[str, object]]:
    examples: list[tuple[str, Base, Step, tuple[Frozen, ...]]] = [
        ("active_parameter_sum", lambda a, b: a,
         lambda n, a, b, v: a + v, ((),)),
        ("nonautonomous_counter_and_seed", lambda a, b: a * a,
         lambda n, a, b, v: (n + 1) * a + v, ((),)),
        ("frozen_parameter_product", lambda a, b: a + b[0],
         lambda n, a, b, v: (a + 1) * v + b[0], ((0,), (1,), (3,))),
        ("zero_selector_branching", lambda a, b: c(a, b[0], b[1]),
         lambda n, a, b, v: c(a, n + b[0], v + b[1]), ((0, 1), (2, 4))),
        ("equality_program", lambda a, b: z(a),
         lambda n, a, b, v: c(a, 0, v), ((),)),
    ]
    for name, g, h, frozen_values in examples:
        check_one_program(name, g, h, frozen_values)
    descriptors: list[dict[str, object]] = []
    for index in range(24):
        g_expr = ("mod101", expression(rng, ("a", "b0", "b1"), 3))
        h_expr = ("mod101", expression(rng, ("n", "a", "v", "b0", "b1"), 3))
        g, h = expressions_to_program(g_expr, h_expr)
        name = f"seeded_{index:02d}"
        check_one_program(name, g, h, ((0, 0), (1, 3), (4, 2)))
        descriptors.append({"name": name, "base": g_expr, "step": h_expr})
    return descriptors


def check_dummy_parameter_embedding(rng: random.Random) -> None:
    # The source's first parameter is descending; actual ordinary-PR
    # parameters are frozen and passed after it. These descriptors ignore
    # the descending parameter completely.
    examples: list[tuple[str, Callable[[Frozen], int], Callable[[int, Frozen, int], int], tuple[Frozen, ...]]] = [
        ("addition", lambda b: b[0], lambda n, b, v: v + 1, ((0,), (1,), (7,))),
        ("multiplication", lambda b: 0, lambda n, b, v: v + b[0], ((0,), (2,), (5,))),
        ("power", lambda b: 1, lambda n, b, v: v * b[0], ((0,), (2,), (3,))),
        ("factorial", lambda b: 1, lambda n, b, v: (n + 1) * v, ((),)),
    ]
    for name, base, step, frozen_values in examples:
        source = make_direct(lambda a, b: base(b), lambda n, a, b, v: step(n, b, v))
        for n, frozen in product(range(13), frozen_values):
            ordinary = base(frozen)
            for k in range(n):
                ordinary = step(k, frozen, ordinary)
            check("dummy_ordinary_embedding", source(n, 0, frozen) == ordinary,
                  program=name, n=n, frozen=frozen)
    for index in range(16):
        g_expr = ("mod101", expression(rng, ("b0", "b1"), 3))
        h_expr = ("mod101", expression(rng, ("n", "v", "b0", "b1"), 3))
        g, h = expressions_to_program(g_expr, h_expr)
        source = make_direct(g, h)
        for n, frozen in product(range(13), ((0, 0), (2, 4), (5, 1))):
            ordinary = g(0, frozen)
            for k in range(n):
                ordinary = h(k, 0, frozen, ordinary)
            check("dummy_seeded_embedding", source(n, 0, frozen) == ordinary,
                  program=index, n=n, frozen=frozen)


def check_formula_compiler_and_latch() -> None:
    for a, b in product((0, 1), repeat=2):
        check("truth_and", c(a, 0, b) == int(bool(a) and bool(b)), a=a, b=b)
        check("truth_or", c(a, b, 1) == int(bool(a) or bool(b)), a=a, b=b)
        check("truth_implication", c(a, 1, b) == int(not bool(a) or bool(b)), a=a, b=b)
    for a in (0, 1):
        check("truth_negation", c(a, 1, 0) == int(not bool(a)), a=a)
    for current, following, old in product((0, 1), (0, 1), (0, 1, 2, 7)):
        if current == 0 or following == 1:
            first = c(current, 0, old)
            second = c(following, 0, first)
            check("local_shifted_latch_stationarity", first == second,
                  current=current, following=following, old=old)
    for bits in product((0, 1), repeat=9):
        progressive = all(not bits[i] or bits[i + 1] for i in range(len(bits) - 1))
        if not progressive:
            continue
        latch = [1]
        for bit in bits:
            latch.append(c(bit, 0, latch[-1]))
        check("finite_shifted_latch", len(set(latch[1:])) == 1, bits=bits)
        if bits[0] == 1:
            check("finite_latch_induction_consequence", all(bits), bits=bits)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("construction_checks.json"))
    args = parser.parse_args()
    rng = random.Random(SEED)
    check_elementary_arithmetic()
    check_equality()
    descriptors = check_compiler(rng)
    check_dummy_parameter_embedding(rng)
    check_formula_compiler_and_latch()
    result = {
        "status": "all finite diagnostics passed",
        "scope": "Finite standard-natural-number diagnostics; not a proof of the axiomatization, schema, nonstandard-model behavior, or bi-interpretation theorem.",
        "seed": SEED,
        "total_checks": sum(COUNTS.values()),
        "checks_by_name": dict(sorted(COUNTS.items())),
        "compiler_named_programs": 5,
        "compiler_seeded_programs": len(descriptors),
        "compiler_grid": {"n": [0, 10], "active_parameter": [0, 11], "trace_indices": "0 through n", "frozen_parameters": "0, 1, or 2; explicit values in source"},
        "equality_grid": {"left": [0, 64], "right": [0, 64]},
        "seeded_program_descriptors": descriptors,
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "total_checks": result["total_checks"], "output": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
