#!/usr/bin/env python3
"""Reproduce the report's formula-tree and selected-description counts.

Python 3.10+, standard library only.  This is syntactic accounting, not a
verification of PRA equivalence or a claim of globally shortest encoding.
Run from any directory; JSON is written beside this script by default.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path


@dataclass(frozen=True)
class Node:
    label: str
    children: tuple["Node", ...] = ()

    def size(self) -> int:
        return 1 + sum(child.size() for child in self.children)

    def sexpr(self) -> str:
        if not self.children:
            return self.label
        return "(" + self.label + " " + " ".join(c.sexpr() for c in self.children) + ")"


def call(label: str, *children: Node) -> Node:
    return Node(label, children)


def forall(variables: tuple[Node, ...], body: Node) -> Node:
    for variable in reversed(variables):
        body = call("forall " + variable.label, body)
    return body


def eq(left: Node, right: Node) -> Node:
    return call("=", left, right)


def neq(left: Node, right: Node) -> Node:
    return call("implies", eq(left, right), BOTTOM)


def succ(value: Node) -> Node:
    return call("S", value)


ZERO, BOTTOM = Node("0"), Node("bottom")
ONE = succ(ZERO)
N, A, X, Y, V, U = (Node(s) for s in ("n", "a", "x", "y", "v", "u"))


def parameters(count: int) -> tuple[Node, ...]:
    return tuple(Node("a" if i == 0 else f"b{i}") for i in range(count))


def computations(count: int, mode: str) -> tuple[Node, Node]:
    """mode='ordinary', 'general_k', or 'fixed_p'; count is descriptor arity-1."""
    args = parameters(count)
    changed = args
    if args and mode in {"general_k", "fixed_p"}:
        changed = (call("k" if mode == "general_k" else "p", args[0]), *args[1:])
    base = forall(args, eq(call("R", ZERO, *args), call("g", *args)))
    step = forall((N, *args), eq(
        call("R", succ(N), *args),
        call("h", N, *args, call("R", N, *changed)),
    ))
    return base, step


def binary_computations() -> tuple[Node, Node]:
    return (
        forall((A,), eq(call("I", ZERO, A), A)),
        forall((N, A), eq(call("I", succ(N), A), call("h", N, call("I", N, A)))),
    )


def schema(count: int, kind: str) -> Node:
    args = parameters(count)
    f = lambda t: call("f", t, *args)
    if kind == "PC":
        premise = forall((N,), eq(f(succ(succ(N))), f(succ(N))))
        conclusion = forall((N,), call("or", eq(N, ZERO), eq(f(N), f(ONE))))
    else:
        premise = forall((N,), eq(f(succ(N)), f(N)))
        if kind == "SS":
            conclusion = forall((N,), neq(succ(f(N)), f(ZERO)))
        elif kind == "SZ":
            conclusion = call("or", forall((N,), eq(f(N), ZERO)), eq(call("Z", f(ZERO)), ZERO))
        elif kind == "CE":
            if not args:
                raise ValueError("CE requires a distinguished comparison parameter")
            conclusion = forall((N,), call("or", eq(f(N), args[0]), eq(call("e", f(ZERO), args[0]), ZERO)))
        else:
            raise ValueError(kind)
    return forall(args, call("implies", premise, conclusion))


def describe(tree: Node) -> dict:
    return {"nodes": tree.size(), "tree": tree.sexpr()}


def descriptor_bodies() -> dict:
    # Only stored finite terms are counted.  Recursive calls shown in
    # defining equations are represented by the update variable v here.
    primary = {
        "p": (ZERO, N),
        "C": (U, V),
        "e": (call("C", Y, ONE, ZERO), call("C", Y, ZERO, V)),
    }
    with_Z = {
        "p": (ZERO, N),
        "Z": (ONE, ZERO),
        "C": (U, V),
        "e": (call("Z", Y), call("C", Y, ZERO, V)),
    }
    # Exactly the existing substitution-descent grammar and its spelling:
    # p(y)=P(y,0), C(y,0,v)=P(B(y,S0),v).  P and B each store an
    # identity substitution descriptor a in the old three-input grammar.
    old_nontrivial = {
        "P_base": A, "P_update": N,
        "B_base": A, "B_update": ZERO,
        "e_base": call("B", Y, ONE),
        "e_update_expanded_C": call("P", call("B", Y, ONE), V),
        "e_substitution_expanded_p": call("P", Y, ZERO),
    }
    old_identity_descriptors = {"P_identity_k": A, "B_identity_k": A}
    primary_counts = {name: sum(t.size() for t in bodies) for name, bodies in primary.items()}
    old_counts = {name: term.size() for name, term in old_nontrivial.items()}
    old_identity_counts = {name: term.size() for name, term in old_identity_descriptors.items()}
    with_Z_counts = {name: sum(t.size() for t in bodies) for name, bodies in with_Z.items()}
    assert primary_counts == {"p": 2, "C": 2, "e": 9}
    assert with_Z_counts == {"p": 2, "Z": 3, "C": 2, "e": 6}
    assert sum(primary_counts.values()) == 13
    assert sum(old_counts.values()) == 17
    assert sum(old_counts.values()) + sum(old_identity_counts.values()) == 19
    return {
        "fixed_p_without_Z": {
            "descriptions": {name: [describe(t) for t in bodies] for name, bodies in primary.items()},
            "body_subtotals": primary_counts,
            "designated_description_count": 3,
            "total": 13,
            "recommended": True,
            "excluded": "The fixed vector transformer, names, arities, binders, and grammar implementation are not counted as body nodes.",
        },
        "fixed_p_with_Z_variant": {
            "descriptions": {name: [describe(t) for t in bodies] for name, bodies in with_Z.items()},
            "body_subtotals": with_Z_counts,
            "designated_description_count": 4,
            "total": sum(with_Z_counts.values()),
            "recommended": False,
            "qualification": "Same body subtotal, but the recommended version removes the separate Z description by using C(y,1,0) in the comparator base.",
        },
        "existing_general_k_comparator": {
            "selected_nonidentity_bodies": {name: describe(t) for name, t in old_nontrivial.items()},
            "selected_nonidentity_subtotal": 17,
            "identity_substitution_bodies": {name: describe(t) for name, t in old_identity_descriptors.items()},
            "all_stored_descriptor_inputs_total": 19,
            "qualification": "17 omits the one-node identity k descriptors of P and B. Counting all three stored inputs for every old description gives 19. Neither number is a byte-level complete-language cost.",
        },
    }


def results() -> dict:
    sep = neq(ZERO, ONE)
    inv = forall((X, Y), eq(call("R", call("R", X, Y), Y), X))
    off = forall((X, Y), call("or", eq(call("e", X, Y), ZERO), eq(X, Y)))
    assert (sep.size(), inv.size(), off.size()) == (6, 9, 11)
    ordinary = sum(t.size() for t in computations(1, "ordinary"))
    changed = sum(t.size() for t in computations(1, "general_k"))
    fixed_p = sum(t.size() for t in computations(1, "fixed_p"))
    binary = sum(t.size() for t in binary_computations())
    assert (ordinary, changed, fixed_p, binary) == (20, 21, 21, 18)
    pc, sz, ss, ce = (schema(1, kind).size() for kind in ("PC", "SZ", "SS", "CE"))
    assert (pc, sz, ss, ce) == (26, 24, 22, 25)
    rows = [
        ("pra_anchored_involution", ordinary, pc, sep.size() + inv.size(), "ordinary PR; arbitrary finite parameters"),
        ("pra_bounded_reflection", ordinary, pc, sep.size() + inv.size(), "ordinary PR; arbitrary finite parameters"),
        ("pra_involutive_difference", binary, pc, sep.size() + inv.size(), "initialized binary recursion; PC has at most one passive parameter"),
        ("pra_stationary_zero", ordinary, sz, sep.size() + inv.size(), "ordinary PR; arbitrary finite parameters"),
        ("pra_substitution_descent", changed, ss, off.size(), "general unary parameter substitution; arbitrary finite frozen parameters"),
        ("pra_transposition_constancy", ordinary, pc, sep.size() + inv.size(), "ordinary PR; arbitrary finite parameters"),
        ("new_CE_same_general_k_grammar", changed, ce, sep.size(), "same computation grammar as substitution descent"),
        ("new_CE_fixed_predecessor", fixed_p, ce, sep.size(), "fixed predecessor transformer; arbitrary finite frozen parameters"),
    ]
    table = [dict(name=name, computation=d, schema=s, fixed=f, total=d+s+f, grammar=grammar)
             for name, d, s, f, grammar in rows]
    assert [row["total"] for row in table] == [61, 61, 59, 59, 54, 61, 52, 52]
    uniform = []
    for m in range(1, 9):
        d = {mode: sum(t.size() for t in computations(m, mode)) for mode in ("ordinary", "general_k", "fixed_p")}
        s = {kind: schema(m, kind).size() for kind in ("PC", "SZ", "SS", "CE")}
        assert d["ordinary"] == 7*m + 13
        assert d["general_k"] == d["fixed_p"] == 7*m + 14
        assert s == {"PC": 5*m+21, "SZ": 5*m+19, "SS": 5*m+17, "CE": 5*m+20}
        totals = {
            "full_PC_Sep_Inv": d["ordinary"]+s["PC"]+15,
            "full_SZ_Sep_Inv": d["ordinary"]+s["SZ"]+15,
            "general_k_SS_Off": d["general_k"]+s["SS"]+11,
            "general_k_CE_Sep": d["general_k"]+s["CE"]+6,
            "fixed_p_CE_Sep": d["fixed_p"]+s["CE"]+6,
        }
        assert totals["general_k_SS_Off"]-totals["general_k_CE_Sep"] == 2
        uniform.append({"passive_parameters": m, "computation": d, "schemas": s, "totals": totals})
    nullary = {
        "ordinary_computation": sum(t.size() for t in computations(0, "ordinary")),
        "fixed_p_computation": sum(t.size() for t in computations(0, "fixed_p")),
        "CE": "Not admitted at m=0; an unused comparison parameter is added.",
    }
    assert nullary["ordinary_computation"] == nullary["fixed_p_computation"] == 13
    return {
        "metric": {
            "charge": "One per variable/constant occurrence, function application, equality, connective, falsity, and individual quantifier.",
            "expansions": ["1=S(0)", "not A=(A implies bottom)"],
            "schematic_calls": "Shown arguments count; bodies substituted for schematic f,g,h are not expanded.",
            "separate_sentences": "Their sizes are added without a conjunction joining the presentation.",
            "limitation": "Formula displays, selected descriptor bodies, and the effective language generator are different costs. No complete encoding or minimum is asserted.",
        },
        "fixed_axioms": {"Sep": describe(sep), "Inv": describe(inv), "Off": describe(off)},
        "one_parameter_schemas": {kind: describe(schema(1, kind)) for kind in ("PC", "SZ", "SS", "CE")},
        "one_parameter_computations": {mode: [describe(t) for t in computations(1, mode)] for mode in ("ordinary", "general_k", "fixed_p")},
        "one_parameter_comparison": table,
        "uniform_parameter_checks": uniform,
        "zero_passive_parameter_case": nullary,
        "uniform_formulas": {
            "ordinary_D": "7m+13", "substitution_D_m_ge_1": "7m+14",
            "PC": "5m+21", "SZ": "5m+19", "SS": "5m+17", "CE_m_ge_1": "5m+20",
            "old_substitution_total": "12m+42", "new_substitution_total": "12m+40",
        },
        "binary_scope_warning": "The involutive-difference 59-node theorem is a strict binary grammar with one schema parameter. It is not assigned fictitious m>1 rows; its full-language variant instead has ordinary D and total 12m+49.",
        "selected_descriptors": descriptor_bodies(),
        "verification_scope": "All assertions check independently constructed syntax trees and arithmetic totals. They do not prove the mathematical theorems.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_suffix(".json"))
    args = parser.parse_args()
    data = results()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "output": str(args.output.resolve()),
        "one_parameter_totals": {row["name"]: row["total"] for row in data["one_parameter_comparison"]},
        "uniform_m_checked": [1,2,3,4,5,6,7,8],
        "primary_selected_bodies": 13,
        "primary_designated_description_count": 3,
        "old_selected_nonidentity_bodies": 17,
        "old_all_descriptor_inputs": 19,
        "all_checks": "passed",
    }, indent=2))


if __name__ == "__main__":
    main()
