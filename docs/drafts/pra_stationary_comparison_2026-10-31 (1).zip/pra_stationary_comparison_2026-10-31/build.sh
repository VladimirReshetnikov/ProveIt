#!/usr/bin/env bash
set -euo pipefail
task_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$task_dir"
mkdir -p build
latexmk -pdf -interaction=nonstopmode -halt-on-error \
  -outdir=build pra_stationary_comparison.tex
cp build/pra_stationary_comparison.pdf pra_stationary_comparison.pdf
