/-
Constructive local kernel for PRA from stationary comparison.

Adapted in part from Bootstrap.lean in the supplied archive
pra_substitution_descent_2026-10-31, by replacing its off-diagonal and
stationary-separation hypotheses with separation and stationary comparison.

The carrier has no assumed induction principle.  All computation laws and
the CE interface are explicit hypotheses.  CE is a semantic interface
quantified over functions; it is NOT a formalization of the first-order
term schema.  Every use is a finite-term instance in the manuscript.
The formalized finite formula syntax below treats arithmetic terms via a
supplied valuation; it does not formalize the PR descriptor grammar.

No Classical, choice, sorry, global axioms, or carrier induction is used.
The manuscript calls the comparison schema SC; CE is its alternative
working name.  The `comparison` field is exactly the same local principle.
-/

universe u v

namespace PRAStationaryComparison

structure Kernel (α : Type u) where
  zero : α
  succ : α → α
  eqtest : α → α → α
  one_ne_zero : succ zero ≠ zero
  eqtest_diagonal_base : eqtest zero zero = succ zero
  eqtest_diagonal_step : ∀ n, eqtest (succ n) (succ n) = eqtest n n
  comparison : ∀ (f : α → α) (a : α),
    (∀ n, f (succ n) = f n) → ∀ n,
      f n = a ∨ eqtest (f zero) a = zero

/- These two lemmas verify the composite selector used by the actual
   finite descriptions; they use only literal P and B equations. -/
theorem composite_selector_zero {α : Type u}
    (zero : α) (succ : α → α) (P B : α → α → α)
    (P_succ : ∀ n a, P (succ n) a = n)
    (B_zero : ∀ a, B zero a = a) (u v : α) :
    P (B zero (succ u)) v = u := by
  exact (congrArg (fun z => P z v) (B_zero (succ u))).trans (P_succ u v)

theorem composite_selector_succ {α : Type u}
    (zero : α) (succ : α → α) (P B : α → α → α)
    (P_zero : ∀ a, P zero a = a)
    (B_succ : ∀ n a, B (succ n) a = zero) (n u v : α) :
    P (B (succ n) (succ u)) v = v := by
  exact (congrArg (fun z => P z v) (B_succ n (succ u))).trans (P_zero v)

def ofSubstitutionEquations {α : Type u}
    (zero : α) (succ pred : α → α)
    (branch eqtest : α → α → α) (select : α → α → α → α)
    (separation : succ zero ≠ zero)
    (pred_succ : ∀ n, pred (succ n) = n)
    (branch_zero : ∀ a, branch zero a = a)
    (select_succ : ∀ n u v, select (succ n) u v = v)
    (eqtest_base : ∀ y, eqtest zero y = branch y (succ zero))
    (eqtest_step : ∀ n y,
      eqtest (succ n) y = select y zero (eqtest n (pred y)))
    (comparison : ∀ (f : α → α) (a : α),
      (∀ n, f (succ n) = f n) → ∀ n,
        f n = a ∨ eqtest (f zero) a = zero) : Kernel α where
  zero := zero
  succ := succ
  eqtest := eqtest
  one_ne_zero := separation
  eqtest_diagonal_base := (eqtest_base zero).trans (branch_zero (succ zero))
  eqtest_diagonal_step := by
    intro n
    calc
      eqtest (succ n) (succ n) =
          select (succ n) zero (eqtest n (pred (succ n))) := eqtest_step n (succ n)
      _ = eqtest n (pred (succ n)) := select_succ n zero (eqtest n (pred (succ n)))
      _ = eqtest n n := congrArg (eqtest n) (pred_succ n)
  comparison := comparison

/- The p,Z,C presentation is retained as a convenient intermediate
   constructor. The primary manuscript now inlines Z(y)=C(y,1,0), using
   only p,C,e; ofSelectorEquations below matches that presentation.
   The preceding P/B constructor remains for the general-k comparison. -/
def ofFixedPredecessorEquations {α : Type u}
    (zero : α) (succ pred Z : α → α)
    (eqtest : α → α → α) (select : α → α → α → α)
    (separation : succ zero ≠ zero)
    (pred_succ : ∀ n, pred (succ n) = n)
    (Z_zero : Z zero = succ zero)
    (select_succ : ∀ n u v, select (succ n) u v = v)
    (eqtest_base : ∀ y, eqtest zero y = Z y)
    (eqtest_step : ∀ n y,
      eqtest (succ n) y = select y zero (eqtest n (pred y)))
    (comparison : ∀ (f : α → α) (a : α),
      (∀ n, f (succ n) = f n) → ∀ n,
        f n = a ∨ eqtest (f zero) a = zero) : Kernel α where
  zero := zero
  succ := succ
  eqtest := eqtest
  one_ne_zero := separation
  eqtest_diagonal_base := (eqtest_base zero).trans Z_zero
  eqtest_diagonal_step := by
    intro n
    calc
      eqtest (succ n) (succ n) =
          select (succ n) zero (eqtest n (pred (succ n))) := eqtest_step n (succ n)
      _ = eqtest n (pred (succ n)) := select_succ n zero (eqtest n (pred (succ n)))
      _ = eqtest n n := congrArg (eqtest n) (pred_succ n)
  comparison := comparison

theorem selector_test_corners {α : Type u}
    (zero : α) (succ : α → α) (select : α → α → α → α)
    (select_zero : ∀ u v, select zero u v = u)
    (select_succ : ∀ n u v, select (succ n) u v = v) :
    select zero (succ zero) zero = succ zero ∧
      ∀ n, select (succ n) (succ zero) zero = zero :=
  ⟨select_zero (succ zero) zero, fun n => select_succ n (succ zero) zero⟩

def ofSelectorEquations {α : Type u}
    (zero : α) (succ pred : α → α)
    (eqtest : α → α → α) (select : α → α → α → α)
    (separation : succ zero ≠ zero)
    (pred_succ : ∀ n, pred (succ n) = n)
    (select_zero : ∀ u v, select zero u v = u)
    (select_succ : ∀ n u v, select (succ n) u v = v)
    (eqtest_base : ∀ y, eqtest zero y = select y (succ zero) zero)
    (eqtest_step : ∀ n y,
      eqtest (succ n) y = select y zero (eqtest n (pred y)))
    (comparison : ∀ (f : α → α) (a : α),
      (∀ n, f (succ n) = f n) → ∀ n,
        f n = a ∨ eqtest (f zero) a = zero) : Kernel α :=
  ofFixedPredecessorEquations zero succ pred (fun y => select y (succ zero) zero)
    eqtest select separation pred_succ
    (selector_test_corners zero succ select select_zero select_succ).left
    select_succ eqtest_base eqtest_step comparison

theorem eqtest_zero_succ {α : Type u}
    (zero : α) (succ Z : α → α) (eqtest : α → α → α)
    (Z_succ : ∀ n, Z (succ n) = zero)
    (eqtest_base : ∀ y, eqtest zero y = Z y) (y : α) :
    eqtest zero (succ y) = zero :=
  (eqtest_base (succ y)).trans (Z_succ y)

theorem eqtest_succ_zero {α : Type u}
    (zero : α) (succ pred : α → α)
    (eqtest : α → α → α) (select : α → α → α → α)
    (select_zero : ∀ u v, select zero u v = u)
    (eqtest_step : ∀ n y,
      eqtest (succ n) y = select y zero (eqtest n (pred y))) (x : α) :
    eqtest (succ x) zero = zero :=
  (eqtest_step x zero).trans (select_zero zero (eqtest x (pred zero)))

theorem eqtest_succ_succ {α : Type u}
    (zero : α) (succ pred : α → α)
    (eqtest : α → α → α) (select : α → α → α → α)
    (pred_succ : ∀ n, pred (succ n) = n)
    (select_succ : ∀ n u v, select (succ n) u v = v)
    (eqtest_step : ∀ n y,
      eqtest (succ n) y = select y zero (eqtest n (pred y))) (x y : α) :
    eqtest (succ x) (succ y) = eqtest x y := by
  calc
    eqtest (succ x) (succ y) =
        select (succ y) zero (eqtest x (pred (succ y))) := eqtest_step x (succ y)
    _ = eqtest x (pred (succ y)) := select_succ y zero (eqtest x (pred (succ y)))
    _ = eqtest x y := congrArg (eqtest x) (pred_succ y)

namespace Kernel

variable {α : Type u} (D : Kernel α)

abbrev one : α := D.succ D.zero

theorem zero_ne_one : D.zero ≠ D.one := by
  intro h
  exact D.one_ne_zero h.symm

theorem successor_injective (pred : α → α)
    (pred_succ : ∀ n, pred (D.succ n) = n) {x y : α}
    (h : D.succ x = D.succ y) : x = y :=
  (pred_succ x).symm.trans ((congrArg pred h).trans (pred_succ y))

theorem successor_ne_zero (pred : α → α)
    (pred_zero : pred D.zero = D.zero)
    (pred_succ : ∀ n, pred (D.succ n) = n) (x : α) :
    D.succ x ≠ D.zero := by
  intro h
  have hx : x = D.zero :=
    (pred_succ x).symm.trans ((congrArg pred h).trans pred_zero)
  exact D.one_ne_zero ((congrArg D.succ hx).symm.trans h)

theorem off (x y : α) : D.eqtest x y = D.zero ∨ x = y := by
  cases D.comparison (fun _ => x) y (fun _ => rfl) D.zero with
  | inl h => exact Or.inr h
  | inr h => exact Or.inl h

theorem eqtest_diagonal_one (x : α) : D.eqtest x x = D.one := by
  have e11 : D.eqtest D.one D.one = D.one :=
    (D.eqtest_diagonal_step D.zero).trans D.eqtest_diagonal_base
  cases D.comparison (fun n => D.eqtest n n) D.one
      D.eqtest_diagonal_step x with
  | inl h => exact h
  | inr h =>
    have hzero : D.one = D.zero := by
      calc
        D.one = D.eqtest D.one D.one := e11.symm
        _ = D.eqtest (D.eqtest D.zero D.zero) D.one :=
          congrArg (fun z => D.eqtest z D.one) D.eqtest_diagonal_base.symm
        _ = D.zero := h
    exact False.elim (D.one_ne_zero hzero)

theorem eqtest_bits (x y : α) :
    D.eqtest x y = D.zero ∨ D.eqtest x y = D.one := by
  cases D.off x y with
  | inl hz => exact Or.inl hz
  | inr hxy =>
    cases hxy
    exact Or.inr (D.eqtest_diagonal_one x)

theorem eqtest_one_iff (x y : α) :
    D.eqtest x y = D.one ↔ x = y := by
  constructor
  · intro h
    cases D.off x y with
    | inl hz => exact False.elim (D.one_ne_zero (h.symm.trans hz))
    | inr hxy => exact hxy
  · intro hxy
    cases hxy
    exact D.eqtest_diagonal_one x

theorem eqtest_zero_iff (x y : α) :
    D.eqtest x y = D.zero ↔ x ≠ y := by
  constructor
  · intro h hxy
    cases hxy
    exact D.one_ne_zero ((D.eqtest_diagonal_one x).symm.trans h)
  · intro hxy
    cases D.off x y with
    | inl hz => exact hz
    | inr heq => exact False.elim (hxy heq)

include D in
theorem equality_decision (x y : α) : x = y ∨ x ≠ y := by
  cases D.off x y with
  | inl hz => exact Or.inr ((D.eqtest_zero_iff x y).mp hz)
  | inr hxy => exact Or.inl hxy

theorem constancy (t : α → α)
    (stationary : ∀ n, t (D.succ n) = t n) :
    ∀ n, t n = t D.zero := by
  intro n
  cases D.comparison t (t D.zero) stationary n with
  | inl h => exact h
  | inr h =>
    exact False.elim (D.one_ne_zero ((D.eqtest_diagonal_one (t D.zero)).symm.trans h))

/- Concrete finite quantifier-free formula syntax.  Arithmetic term syntax
   is a parameter τ and its valuation is supplied separately. -/
inductive Formula (τ : Type v) : Type v where
  | atom : τ → τ → Formula τ
  | falsum : Formula τ
  | verum : Formula τ
  | conj : Formula τ → Formula τ → Formula τ
  | disj : Formula τ → Formula τ → Formula τ
  | impl : Formula τ → Formula τ → Formula τ

def Formula.Holds {τ : Type v} (val : τ → α) : Formula τ → Prop
  | .atom s t => val s = val t
  | .falsum => False
  | .verum => True
  | .conj A B => A.Holds val ∧ B.Holds val
  | .disj A B => A.Holds val ∨ B.Holds val
  | .impl A B => A.Holds val → B.Holds val

def Formula.bit {τ : Type v} (select : α → α → α → α)
    (val : τ → α) : Formula τ → α
  | .atom s t => D.eqtest (val s) (val t)
  | .falsum => D.zero
  | .verum => D.one
  | .conj A B => select (A.bit select val) D.zero (B.bit select val)
  | .disj A B => select (A.bit select val) (B.bit select val) D.one
  | .impl A B => select (A.bit select val) D.one (B.bit select val)

/- Truth-bit packages avoid invoking proposition extensionality. -/
structure TruthBit (P : Prop) (b : α) : Prop where
  bits : b = D.zero ∨ b = D.one
  truth : P ↔ b = D.one

theorem false_of_zero {P : Prop} {b : α} (hb : D.TruthBit P b)
    (hz : b = D.zero) : ¬ P := by
  intro hp
  exact D.one_ne_zero ((hb.truth.mp hp).symm.trans hz)

theorem truthBit_conj
    (select : α → α → α → α)
    (select_zero : ∀ u v, select D.zero u v = u)
    (select_one : ∀ u v, select D.one u v = v)
    {P Q : Prop} {b c : α} (hb : D.TruthBit P b) (hc : D.TruthBit Q c) :
    D.TruthBit (P ∧ Q) (select b D.zero c) := by
  cases hb.bits with
  | inl hz =>
    have hv : select b D.zero c = D.zero := hz ▸ select_zero D.zero c
    refine ⟨Or.inl hv, ?_⟩
    constructor
    · intro hpq
      exact False.elim (D.false_of_zero hb hz hpq.left)
    · intro hone
      exact False.elim (D.one_ne_zero (hone.symm.trans hv))
  | inr ho =>
    have hv : select b D.zero c = c := ho ▸ select_one D.zero c
    refine ⟨?_, ?_⟩
    · cases hc.bits with
      | inl hz => exact Or.inl (hv.trans hz)
      | inr ho => exact Or.inr (hv.trans ho)
    · constructor
      · intro hpq
        exact hv.trans (hc.truth.mp hpq.right)
      · intro hone
        exact ⟨hb.truth.mpr ho, hc.truth.mpr (hv.symm.trans hone)⟩

theorem truthBit_disj
    (select : α → α → α → α)
    (select_zero : ∀ u v, select D.zero u v = u)
    (select_one : ∀ u v, select D.one u v = v)
    {P Q : Prop} {b c : α} (hb : D.TruthBit P b) (hc : D.TruthBit Q c) :
    D.TruthBit (P ∨ Q) (select b c D.one) := by
  cases hb.bits with
  | inl hz =>
    have hv : select b c D.one = c := hz ▸ select_zero c D.one
    refine ⟨?_, ?_⟩
    · cases hc.bits with
      | inl hz => exact Or.inl (hv.trans hz)
      | inr ho => exact Or.inr (hv.trans ho)
    · constructor
      · intro hpq
        cases hpq with
        | inl hp => exact False.elim (D.false_of_zero hb hz hp)
        | inr hq => exact hv.trans (hc.truth.mp hq)
      · intro hone
        exact Or.inr (hc.truth.mpr (hv.symm.trans hone))
  | inr ho =>
    have hv : select b c D.one = D.one := ho ▸ select_one c D.one
    refine ⟨Or.inr hv, ?_⟩
    constructor
    · intro _
      exact hv
    · intro _
      exact Or.inl (hb.truth.mpr ho)

theorem truthBit_impl
    (select : α → α → α → α)
    (select_zero : ∀ u v, select D.zero u v = u)
    (select_one : ∀ u v, select D.one u v = v)
    {P Q : Prop} {b c : α} (hb : D.TruthBit P b) (hc : D.TruthBit Q c) :
    D.TruthBit (P → Q) (select b D.one c) := by
  cases hb.bits with
  | inl hz =>
    have hv : select b D.one c = D.one := hz ▸ select_zero D.one c
    refine ⟨Or.inr hv, ?_⟩
    constructor
    · intro _
      exact hv
    · intro _ hp
      exact False.elim (D.false_of_zero hb hz hp)
  | inr ho =>
    have hv : select b D.one c = c := ho ▸ select_one D.one c
    refine ⟨?_, ?_⟩
    · cases hc.bits with
      | inl hz => exact Or.inl (hv.trans hz)
      | inr ho => exact Or.inr (hv.trans ho)
    · constructor
      · intro hpq
        exact hv.trans (hc.truth.mp (hpq (hb.truth.mpr ho)))
      · intro hone _
        exact hc.truth.mpr (hv.symm.trans hone)

theorem formula_compiler {τ : Type v}
    (select : α → α → α → α)
    (select_zero : ∀ u v, select D.zero u v = u)
    (select_one : ∀ u v, select D.one u v = v)
    (val : τ → α) (F : Formula τ) :
    D.TruthBit (F.Holds val) (F.bit D select val) := by
  induction F with
  | atom s t => exact ⟨D.eqtest_bits (val s) (val t),
      (D.eqtest_one_iff (val s) (val t)).symm⟩
  | falsum =>
    refine ⟨Or.inl rfl, ?_⟩
    constructor
    · intro h
      exact False.elim h
    · intro h
      exact D.zero_ne_one h
  | verum =>
    refine ⟨Or.inr rfl, ?_⟩
    constructor
    · intro _
      rfl
    · intro _
      exact True.intro
  | conj A B ha hb => exact D.truthBit_conj select select_zero select_one ha hb
  | disj A B ha hb => exact D.truthBit_disj select select_zero select_one ha hb
  | impl A B ha hb => exact D.truthBit_impl select select_zero select_one ha hb

/- The latch is supplied with its literal recurrence.  In the full-tuple
grammar it is directly available by ordinary primitive recursion. -/
theorem shifted_latch_induction
    (select : α → α → α → α)
    (select_zero : ∀ u v, select D.zero u v = u)
    (select_one : ∀ u v, select D.one u v = v)
    (P : α → Prop) (b r : α → α)
    (bits : ∀ n, b n = D.zero ∨ b n = D.one)
    (truth : ∀ n, P n ↔ b n = D.one)
    (rbase : r D.zero = D.one)
    (rstep : ∀ n, r (D.succ n) = select (b n) D.zero (r n))
    (base : P D.zero) (step : ∀ n, P n → P (D.succ n)) :
    ∀ n, P n := by
  have select_same (z : α) (hz : z = D.zero ∨ z = D.one) :
      select z D.zero D.zero = D.zero := by
    cases hz with
    | inl h => exact h ▸ select_zero D.zero D.zero
    | inr h => exact h ▸ select_one D.zero D.zero
  have bbase : b D.zero = D.one := (truth D.zero).mp base
  have shifted_base : r (D.succ D.zero) = D.one := by
    calc
      r (D.succ D.zero) = select (b D.zero) D.zero (r D.zero) := rstep D.zero
      _ = select D.one D.zero (r D.zero) := congrArg (fun z =>
        select z D.zero (r D.zero)) bbase
      _ = r D.zero := select_one D.zero (r D.zero)
      _ = D.one := rbase
  have shifted_step : ∀ n, r (D.succ (D.succ n)) = r (D.succ n) := by
    intro n
    cases bits n with
    | inl hz =>
      have hn : r (D.succ n) = D.zero := by
        calc
          r (D.succ n) = select (b n) D.zero (r n) := rstep n
          _ = select D.zero D.zero (r n) := congrArg
            (fun z => select z D.zero (r n)) hz
          _ = D.zero := select_zero D.zero (r n)
      calc
        r (D.succ (D.succ n)) =
            select (b (D.succ n)) D.zero (r (D.succ n)) := rstep (D.succ n)
        _ = select (b (D.succ n)) D.zero D.zero := congrArg
          (fun z => select (b (D.succ n)) D.zero z) hn
        _ = D.zero := select_same (b (D.succ n)) (bits (D.succ n))
        _ = r (D.succ n) := hn.symm
    | inr hone =>
      have hnext : b (D.succ n) = D.one :=
        (truth (D.succ n)).mp (step n ((truth n).mpr hone))
      calc
        r (D.succ (D.succ n)) =
            select (b (D.succ n)) D.zero (r (D.succ n)) := rstep (D.succ n)
        _ = select D.one D.zero (r (D.succ n)) := congrArg
          (fun z => select z D.zero (r (D.succ n))) hnext
        _ = r (D.succ n) := select_one D.zero (r (D.succ n))
  have shifted_one : ∀ n, r (D.succ n) = D.one := by
    intro n
    exact (D.constancy (fun j => r (D.succ j)) shifted_step n).trans shifted_base
  intro n
  apply (truth n).mpr
  cases bits n with
  | inl hz =>
    have hn : r (D.succ n) = D.zero := by
      calc
        r (D.succ n) = select (b n) D.zero (r n) := rstep n
        _ = select D.zero D.zero (r n) := congrArg
          (fun z => select z D.zero (r n)) hz
        _ = D.zero := select_zero D.zero (r n)
    exact False.elim (D.one_ne_zero ((shifted_one n).symm.trans hn))
  | inr hone => exact hone


/- Combining finite formula compilation with the checked latch. -/
theorem quantifier_free_induction {τ : Type v}
    (select : α → α → α → α)
    (select_zero : ∀ u v, select D.zero u v = u)
    (select_one : ∀ u v, select D.one u v = v)
    (val : α → τ → α) (F : Formula τ) (r : α → α)
    (rbase : r D.zero = D.one)
    (rstep : ∀ n, r (D.succ n) =
      select (F.bit D select (val n)) D.zero (r n))
    (base : F.Holds (val D.zero))
    (step : ∀ n, F.Holds (val n) → F.Holds (val (D.succ n))) :
    ∀ n, F.Holds (val n) := by
  exact D.shifted_latch_induction select select_zero select_one
    (fun n => F.Holds (val n)) (fun n => F.bit D select (val n)) r
    (fun n => (D.formula_compiler select select_zero select_one (val n) F).bits)
    (fun n => (D.formula_compiler select select_zero select_one (val n) F).truth)
    rbase rstep base step

#print axioms composite_selector_zero
#print axioms composite_selector_succ
#print axioms ofSubstitutionEquations
#print axioms ofFixedPredecessorEquations
#print axioms ofSelectorEquations
#print axioms eqtest_zero_succ
#print axioms eqtest_succ_zero
#print axioms eqtest_succ_succ
#print axioms successor_injective
#print axioms successor_ne_zero
#print axioms off
#print axioms eqtest_diagonal_one
#print axioms eqtest_bits
#print axioms eqtest_one_iff
#print axioms eqtest_zero_iff
#print axioms equality_decision
#print axioms constancy
#print axioms formula_compiler
#print axioms shifted_latch_induction
#print axioms quantifier_free_induction

end Kernel
end PRAStationaryComparison
