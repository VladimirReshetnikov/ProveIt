FORMAL VERIFICATION SCOPE
=========================

StationaryComparison.lean checks a constructive proof kernel over an
arbitrary carrier alpha. It imports no library and assumes no induction
principle on that carrier. All computation laws, separation, and the
stationary-comparison interface are explicit theorem hypotheses or
structure fields. There are no global axiom declarations.

The manuscript calls the comparison schema SC. CE was its working name;
the Lean field named comparison represents the same local principle:

  If f(Sn)=f(n) for every n, then for every n,
    f(n)=a or e(f(0),a)=0.

Verified results
----------------
1. The concrete predecessor, selector, and equality-test equations give
   all four corner equations. The primary constructor ofSelectorEquations
   matches the report's three-description p,C,e presentation, with
   e(0,y)=C(y,one,zero). It derives the temporary selector test Z(y) as
   C(y,one,zero), checks its zero and successor values, and uses the
   intermediate ofFixedPredecessorEquations constructor. Z is not an
   additional designated program or axiom in the primary report.
2. Composite selectors from the predecessor draft's P and B descriptions
   satisfy their zero and successor equations. The alternate constructor
   ofSubstitutionEquations supports the same-grammar general-k variant.
3. Separation and predecessor equations give successor injectivity and
   successor nonzeroness.
4. SC on constant terms yields e(x,y)=0 or x=y.
5. SC directly on d(n)=e(n,n), with comparison target one, proves
   e(n,n)=one. This does not assume arithmetic induction or a prior
   equality decision.
6. The equality test is an exact Boolean code for native equality and
   native equality is constructively decidable.
7. SC with comparison target t(0) gives contextual constancy.
8. An explicit finite syntax of quantifier-free formulas has a verified
   Boolean compiler for equality, falsity, truth, conjunction, disjunction,
   and implication. Negation can be expressed as implication to falsity.
9. The shifted latch proves induction for a proposition family supplied
   with its truth bit and literal latch recurrence. The final theorem
   quantifier_free_induction combines this with the formula compiler.

What the formal interface means
-------------------------------
The semantic SC interface quantifies over functions alpha -> alpha. This
is a convenient theorem interface, not a claim that the first-order
axiomatization quantifies over all set-theoretic functions. Each function
used in the manuscript is an explicitly constructed finite term. Fixed
numerical parameters are held in its closure. In particular, deriving
constancy requires a fresh comparison parameter in addition to the
original fixed parameters; the schema allows arbitrary finite tuples.

The finite formula syntax is formalized. Its arithmetic terms form an
abstract type tau with a supplied valuation. Thus the compiler checks all
finite logical connectives and the equality-to-bit step, while leaving
the recursive arithmetic term grammar and its admissibility to the paper.
The latch is supplied by its recurrence; its availability from the stated
description grammar is proved in the paper.

Not formalized
--------------
The full finite PR-description syntax, fixed-predecessor/general-k
recursion compiler, internal PRA converse proof, first-order proof
calculus, and the bi-interpretation round trips remain written
mathematical proofs. This is not a machine-checked theorem of the entire
first-order bi-interpretability claim.

Verification and reproduction
-----------------------------
Lean 4.19.0 (commit 6caaee842e94, Release) was used:

    lean StationaryComparison.lean

The process exited with status 0. StationaryComparison.log records 20
axiom audits; every audited declaration reports no global axioms. In
particular there is no sorryAx, Classical.choice, or propext dependency.
This audit does not remove the explicitly supplied mathematical
hypotheses from each theorem's statement.

Attribution
-----------
The exact-bit and shifted-latch proofs are adapted from Bootstrap.lean in
the supplied pra_substitution_descent_2026-10-31 archive. The SC bootstrap,
direct constancy proof, fixed-predecessor and selector constructors, corner-equation
lemmas, and finite formula compiler are new to this artifact.
