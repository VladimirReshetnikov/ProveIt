#!/usr/bin/env python3
"""Integer-only audit of cycle-abundance identities; no third-party dependencies."""
import argparse
from itertools import combinations, product
from random import Random


def bits(s):
    while s:
        b = s & -s
        yield b.bit_length()-1
        s ^= b


def adjacency(n, arcs):
    ins, outs = [0]*n, [0]*n
    for a,b in arcs:
        assert a!=b and not ((outs[b] >> a)&1)
        outs[a] |= 1<<b
        ins[b] |= 1<<a
    return ins, outs


def analyze(ins, outs):
    n=len(ins); full=(1<<n)-1
    F=[]; defects={}; cycles=[]; cnt=[0]*n
    P=[0]*n; delta=[0]*n
    for s in range(1<<n):
        src=[v for v in bits(s) if not ins[v]&s]
        snk=[v for v in bits(s) if not outs[v]&s]
        roots=set(src+snk)
        if not roots:
            F.append(s)
            for v in bits(s): cnt[v]+=1
            if s and all((ins[v]&s).bit_count()==1 and (outs[v]&s).bit_count()==1 for v in bits(s)):
                start=s&-s; seen=start; u=start
                while True:
                    u=outs[u.bit_length()-1]&s
                    if seen&u: break
                    seen|=u
                if seen==s: cycles.append(s)
        else:
            K=full
            for v in src: K&=ins[v]
            for v in snk: K&=outs[v]
            for v in bits(K):
                delta[v]+=1
                if len(roots)>=2:P[v]+=1
            if len(roots)==1:delta[next(iter(roots))]-=1
            defects[s]=(src,snk,K)
    m=len(F)
    d=[2*c-m for c in cnt]
    assert d==delta, ('cube identity',ins,outs,d,delta)
    Z=[int(s not in defects) for s in range(1<<n)]
    core=[s if s not in defects else 0 for s in range(1<<n)]
    # Boolean zeta transforms: count and union of all feasible submasks.
    for i in range(n):
        for s in range(1<<n):
            if s>>i&1:
                Z[s]+=Z[s^(1<<i)]
                core[s]|=core[s^(1<<i)]
    N0=[full & ~(ins[v]|outs[v]|(1<<v)) for v in range(n)]
    z=[Z[t] for t in N0]
    for u in F:
        assert sum(d[v] for v in bits(u))>=sum(P[v]-z[v] for v in bits(u))
    c=[0]*n; B=[0]*n
    q_by_cycle={}
    for C in cycles:
        for v in bits(C):
            c[v]+=1
            R=C^(1<<v)
            a=(outs[v]&C).bit_length()-1
            b=(ins[v]&C).bit_length()-1
            Q=full&~(C|ins[a]|outs[b]); q_by_cycle[C,v]=Q
            A=full&~C
            for u in bits(R): A&=~(ins[u]|outs[u])
            B[v]+=Z[A]
            # Verify each safe extension directly, independently of the total bound.
            for t in F:
                if t&~Q:continue
                s=R|t
                src,snk,K=defects[s]
                assert src==[a] and snk==[b] and K>>v&1
    assert all(P[v]>=B[v] for v in range(n))
    good=[]; local_core=[]
    for C in cycles:
        L=[]; qgood=True
        for v in bits(C):
            Q=q_by_cycle[C,v]
            assert P[v]>=c[v]+Z[Q]-1
            L.append(max(B[v],c[v]+Z[Q]-1)-z[v])
            qgood &= not (core[N0[v]]&~Q)
        score=sum(L)
        actual=sum(d[v] for v in bits(C))
        assert actual>=score
        if score>=0:good.append(C)
        if qgood:
            assert actual>=0
            local_core.append(C)
    if all(zv==1 for zv in z):
        for u in F:
            if u:
                assert any(C&~u==0 for C in good)
                assert any(C&~u==0 for C in cycles)
    return {'members':m,'frequencies':cnt,'cycles':len(cycles),'certified_cycles':len(good),
            'core_certified_cycles':len(local_core),'acyclic_nonneighbors':all(x==1 for x in z),
            'max_frequency':max(cnt,default=0),'P':P,'z':z,'c':c,'B':B}


def example(t):
    # Two blow-ups of directed 4-cycles, then a middle vertex; complete bipartite.
    groups=[]; n=0
    for _ in range(2):
        block=[]
        for sz in (t,1,1,1):
            block.append(list(range(n,n+sz)));n+=sz
        groups.append(block)
    A,B=groups; v=n; n+=1
    arcs=[]
    for block in groups:
        for k in range(4):
            arcs.extend((x,y) for x in block[k] for y in block[(k+1)%4])
    for i in range(4):
        for j in range(4):
            if i%2!=j%2:arcs.extend((x,y) for x in A[i] for y in B[j])
    for j in (1,3):
        arcs.extend((x,v) for x in A[j]); arcs.extend((v,y) for y in B[j])
    return adjacency(n,arcs)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--exhaustive',type=int,default=5);ap.add_argument('--random',type=int,default=300);a=ap.parse_args()
    totals=0
    for n in range(1,a.exhaustive+1):
        pairs=list(combinations(range(n),2)); nontrivial=0; acyclic_non=0; cert=0
        for state in product(range(3),repeat=len(pairs)):
            arcs=[(i,j) if e==1 else (j,i) for (i,j),e in zip(pairs,state) if e]
            z=analyze(*adjacency(n,arcs));nontrivial+=z['members']>1
            acyclic_non+=z['acyclic_nonneighbors'] and z['members']>1
            cert+=z['certified_cycles']>0; totals+=1
        print(f'n={n}: {3**len(pairs)} graphs; nontrivial={nontrivial}; nontrivial with acyclic nonneighbors={acyclic_non}; score-certified={cert}',flush=True)
    rng=Random(20261125)
    for i in range(a.random):
        n=rng.randrange(6,11);parts=[rng.randrange(3) for _ in range(n)]
        arcs=[]
        for x,y in combinations(range(n),2):
            if (i%2==0 and parts[x]==parts[y]) or (i%2==1 and rng.random()<.35):continue
            arcs.append((x,y) if rng.randrange(2) else (y,x))
        z=analyze(*adjacency(n,arcs))
        if i%2==0:assert z['acyclic_nonneighbors']
    print(f'PASS: {totals} exhaustive labeled oriented graphs; {a.random} seeded random graphs.',flush=True)
    # Safe exterior example: triangles 0->1->2->0 and 3->4->5->3; 1->D->2.
    D=adjacency(6,[(0,1),(1,2),(2,0),(3,4),(4,5),(5,3)]+[(1,x) for x in (3,4,5)]+[(x,2) for x in (3,4,5)])
    r=analyze(*D);assert r['z'][0]==2 and r['core_certified_cycles']>=2
    print('Connected safe-exterior example:',r,flush=True)
    for t in (1,2,3):
        r=analyze(*example(t));assert r['members']==2**(2*t)+(2**t-1)**2
        print(f'Bipartite example t={t}:',r,flush=True)

if __name__=='__main__':main()
