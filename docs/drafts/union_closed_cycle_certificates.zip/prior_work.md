# Prior-work screening

Repository: https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts (main, inspected 25 November 2026). The archive contents were retrieved using the GitHub connector's base64 file access and decoded to inspect source section/theorem headings. This was a targeted screen, not a complete audit of every proof in every archive.

## Archives screened

| Archive | Topics visible in source headings |
|---|---|
| union-closed-abundance.zip | structured generators, marked four-sets, rare triples |
| union-closed-results.zip | overlapping triples, translates, circles, marked four-sets |
| union_closed_abundance.zip | dense deletion thresholds, translates |
| union_closed_abundance_theorems.zip | block cliques, line unions, rare triples |
| union_closed_advances_2026-11-25.zip | entropy recursion, structured generators, ranked frequencies |
| union_closed_entropy_2026_11_25.zip | finite-size entropy refinements |
| union_closed_entropy_research_2026-11-25.zip | entropy extremizers and approximate closure |
| union_closed_extensions_2026-11-25(1).zip | local-fibre extensions, generator bounds |
| union_closed_extensions_2026-11-25.zip | generator entropy, multi-union entropy, principal filters |
| union_closed_frequency_bounds.zip | Horn identity, tournaments, matching condition, other bounds |
| union_closed_joint_laws_2026-11-25.zip | joint generator laws, conditioning, concentration, CLT |
| union_closed_local_abundance.zip | exterior-conditioned tree messages and separated points |
| union_closed_marked_abundance.zip | marked edges and local deletion thresholds |
| union_closed_partial_results.zip | rare triples, sparse generators, switching |
| union_closed_partial_theorems_2026-11-25.zip | regular linear generators and high-girth graphs |
| union_closed_refinements_2026-11-25.zip | entropy deficit, approximate closure |
| union_closed_three_results.zip | finite-size entropy, edge frequency, five exceptional generators |

`union_closed_structural_theorems.zip` was listed but its contents could not be decoded via the connector. Thus priority relative to this archive could not be checked.

## Direct antecedent

`union_closed_frequency_bounds.zip` (blob SHA `2c2534514f2afd2fead5cbbc22c2ffea3962ccc9`), source `union_closed_frequency_bounds/horn_section.tex`. The full relevant section was read. It includes the general exact sum over violated rules, a stronger local average theorem for tournament families, and an ordered matching condition. The present paper re-proves the exact identity in the oriented-graph setting and explicitly credits it. The cycle repair budget, exterior windows, combined score, polynomial core test and multipartite corollary are the extensions investigated here. The tournament theorem is not a new claim of this paper.

## Public comparison

- Bruhn and Schaudt, survey: https://arxiv.org/abs/1309.3297
- Lozin and Zamaraev (2024), Horn functions and dependency condition: https://doi.org/10.1016/j.jcta.2023.105818
- Bruhn, Charbit, Schaudt and Telle (2015), graph formulation via maximal stable sets and small-generator classes: https://arxiv.org/abs/1212.4175
- Knill (1994), graph-generated families (different construction): https://arxiv.org/abs/math/9409215
- Costa and Sadhu (2026), general entropy bound: https://arxiv.org/abs/2610.02295
- Jiang (2026), global couplings: https://arxiv.org/abs/2609.08291
- A more recent computer-assisted bound of approximately 0.383175 is claimed at https://quantavane.com/major-results/union-closed-sets-conjecture/; the current paper neither relies on nor adjudicates that claim.

Searches combined `union-closed`, `Frankl`, `complete multipartite`, `bipartite tournament`, `directed cycle`, `source`, `sink`, `Horn`, and related phrases. No directly matching extension was located. This is not an exhaustive priority search and should not be interpreted as proof of novelty.
