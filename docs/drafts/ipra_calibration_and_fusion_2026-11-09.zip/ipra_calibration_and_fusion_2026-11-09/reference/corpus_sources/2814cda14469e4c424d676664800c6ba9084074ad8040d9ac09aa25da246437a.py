#!/usr/bin/env python3
"""Independent exact case checks for the comparison-feedback calibration.

This file imports no proof checker or proof producer. Source checks enumerate
only the independently available Boolean values of sign terms; they do not
assume that the primitive raw comparison e is Boolean or detects equality.

The numerical counterexamples use an exact finite partition of all n >= 0,
not a bounded search. None of these checks is a full symbolic FR derivation,
a proof of the bi-interpretation, or a Lean/Rocq formalization.
"""
import argparse
import itertools
import json
from dataclasses import dataclass
from pathlib import Path


BOOLEANS = (0, 1)


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def choose(test, when_zero, when_positive):
    return when_zero if test == 0 else when_positive


def sign(value):
    return 0 if value == 0 else 1


def predecessor(value):
    return max(value - 1, 0)


def spike_current(q, r):
    """H(z), where q=sigma(Pz), r=sigma(P^2z); a,b are formal labels."""
    return choose(choose(q, 1, r), "b", "a")


def spike_next(s, q):
    """H(Sz), from P(Sz)=z; s=sigma(z), q=sigma(Pz)."""
    return choose(choose(s, 1, q), "b", "a")


def diagonal_checks(endpoint_one="a", corrupt_successor=False):
    rows = []
    for q, r, s, e_ba, v_aa, v_ba in itertools.product(BOOLEANS, repeat=6):
        current = spike_current(q, r)
        successor = spike_next(s, q)
        if corrupt_successor and current == "b":
            successor = "b"
        # E(a,a)=1 is the retained hypothesis. E(b,a), V(a,a), V(b,a)
        # are entirely arbitrary Boolean values here.
        guard = 1 if current == "a" else e_ba
        fallback = v_aa if current == "a" else v_ba
        result = successor if guard == 0 else ("a" if fallback == 0 else endpoint_one)
        rows.append({"q": q, "r": r, "sigma_z": s, "E_ba": e_ba,
                     "V_aa": v_aa, "V_ba": v_ba, "H_z": current,
                     "H_Sz": successor, "reset_value": result,
                     "premise_holds": result == "a"})
    return rows


def reflection_checks():
    rows = []
    for s, v_ab, v_bb in itertools.product(BOOLEANS, repeat=3):
        current = choose(s, "a", "b")
        # E(a,b)=0 is retained; E(b,b)=0 is the previously proved diagonal.
        guard = {"a": 0, "b": 0}[current]
        fallback = v_ab if current == "a" else v_bb
        result = "b" if guard == 0 else choose(fallback, "a", "b")
        rows.append({"sigma_z": s, "V_ab": v_ab, "V_bb": v_bb,
                     "F_z": current, "reset_value": result,
                     "premise_holds": result == "b"})
    return rows


def failed_destination_checks(constant_zero=False):
    rows = []
    for s, v_bb in itertools.product(BOOLEANS, repeat=2):
        current = choose(s, "a", "b")
        # Retained E(a,b)=1,V(a,b)=1, and previously proved E(b,b)=0.
        guard = 1 if current == "a" else 0
        fallback = 0 if constant_zero else (1 if current == "a" else v_bb)
        result = "b" if guard == 0 else choose(fallback, "a", "b")
        rows.append({"sigma_z": s, "V_bb": v_bb, "F_z": current,
                     "reset_value": result, "premise_holds": result == "b"})
    return rows


@dataclass(frozen=True)
class FiniteSupportFunction:
    default: int
    exceptions: dict

    def value(self, n):
        return self.exceptions.get(n, self.default)


def exact_rule_analysis(function, comparison, anchor, target, old_constant_zero=False):
    """Analyze all n by the exact partition where f(n) or f(n+1) changes.

    Every exceptional integer and its nonnegative predecessor is a singleton
    region. On the complementary (possibly disconnected, infinite) region,
    f(n)=f(n+1)=default. The reset either advances one step or lands at the
    fixed integer 0 or 1, so this partition determines the premise exactly.
    """
    support = {n for n, value in function.exceptions.items() if value != function.default}
    require(all(type(n) is int and n >= 0 for n in support), "Invalid support")
    critical = sorted(support | {n - 1 for n in support if n > 0})
    regions = []

    def region_record(label, current, next_value):
        raw = comparison(current, anchor)
        require(type(raw) is int and raw >= 0, "Comparison must return a natural")
        guard = sign(raw)
        fallback = 0 if old_constant_zero else sign(predecessor(raw))
        value = next_value if guard == 0 else function.value(fallback)
        return {"region": label, "f_n": current, "f_Sn": next_value,
                "raw_comparison": raw, "guard": guard, "fallback": fallback,
                "reset_mode": "successor" if guard == 0 else "constant",
                "f_reset": value, "premise_holds": value == anchor}

    for n in critical:
        regions.append(region_record({"singleton": n}, function.value(n), function.value(n + 1)))
    regions.append(region_record({"all_other_naturals": critical}, function.default, function.default))
    return {"function": {"default": function.default, "exceptions": function.exceptions},
            "anchor": anchor, "target": target, "regions": regions,
            "premise_for_every_natural": all(row["premise_holds"] for row in regions),
            "conclusion": function.value(target) == anchor,
            "partition_justification": "Outside the listed singletons, neither n nor n+1 belongs to the finite support."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parents[1] / "calibration_cases.json")
    args = parser.parse_args()

    local = []
    for q, r, s in itertools.product(BOOLEANS, repeat=3):
        current, following = spike_current(q, r), spike_next(s, q)
        require(current != "b" or following == "a", "Exceptional spike must be followed by anchor")
        local.append({"q": q, "r": r, "sigma_z": s,
                      "H_z": current, "H_Sz": following})

    endpoints = {}
    for n in (0, 1, 2):
        endpoints[str(n)] = spike_current(sign(predecessor(n)), sign(predecessor(predecessor(n))))
    require(endpoints == {"0": "a", "1": "a", "2": "b"}, "Incorrect spike endpoints")

    diagonal = diagonal_checks()
    reflection = reflection_checks()
    failure = failed_destination_checks()
    for label, rows in (("diagonal", diagonal), ("reflection", reflection), ("failure", failure)):
        require(all(row["premise_holds"] for row in rows), label + " premise failed")

    negative_controls = {
        "changing_H_1_to_b_is_detected": not all(r["premise_holds"] for r in diagonal_checks(endpoint_one="b")),
        "breaking_exceptional_successor_is_detected": not all(r["premise_holds"] for r in diagonal_checks(corrupt_successor=True)),
        "old_constant_zero_cannot_run_new_failure_calibration": not all(r["premise_holds"] for r in failed_destination_checks(constant_zero=True)),
    }
    require(all(negative_controls.values()), "A targeted negative control was not detected")

    ramp = FiniteSupportFunction(default=1, exceptions={0: 0})
    spike = FiniteSupportFunction(default=0, exceptions={2: 1})
    zero = lambda a, b: 0
    one = lambda a, b: 1
    two_label = lambda a, b: 0 if a == b else 2
    canonical = lambda a, b: 0 if a == b else 1
    bad = {
        "always_zero": exact_rule_analysis(ramp, zero, anchor=1, target=0),
        "always_one": exact_rule_analysis(spike, one, anchor=0, target=2),
        "zero_if_equal_else_two": exact_rule_analysis(ramp, two_label, anchor=1, target=0),
    }
    require(all(result["premise_for_every_natural"] and not result["conclusion"]
                for result in bad.values()), "A bad comparison was not refuted exactly")

    canonical_controls = {
        "ramp": exact_rule_analysis(ramp, canonical, anchor=1, target=0),
        "spike": exact_rule_analysis(spike, canonical, anchor=0, target=2),
    }
    require(all(not r["premise_for_every_natural"] for r in canonical_controls.values()),
            "Canonical comparison incorrectly satisfies a counterexample premise")
    old_two = exact_rule_analysis(ramp, two_label, anchor=1, target=0, old_constant_zero=True)
    require(not old_two["premise_for_every_natural"], "Old reset unexpectedly rejects the two-label model by this ramp")

    result = {
        "status": "passed",
        "scope": {
            "source_case_assumptions": "Only Boolean range of sign terms, fixed P/C/sign computations, and the explicitly retained E/V hypotheses. No raw e range or equality meaning is assumed.",
            "exact_numerical_scope": "Counterexample premises are verified on an exact finite partition covering every natural number, not by bounded sampling.",
            "not_claimed": ["Full symbolic derivation using FR", "Correctness proof for the complete checker",
                            "Formal verification of bi-interpretation", "Lean or Rocq formalization"],
            "rule_application_boundary": "The source cases verify premises for the manuscript's FR uses. Applying FR and later equality/Boolean arguments remain manuscript proof steps.",
        },
        "source_cases": {"local_spike": local, "spike_endpoints": endpoints,
                         "diagonal": diagonal, "reflection": reflection, "failed_destination": failure},
        "source_case_counts": {"local_spike": len(local), "diagonal": len(diagonal),
                               "reflection": len(reflection), "failed_destination": len(failure)},
        "negative_controls": negative_controls,
        "exact_bad_comparison_counterexamples": bad,
        "canonical_comparison_controls": canonical_controls,
        "old_constant_zero_control": old_two,
        "old_rule_nonuniqueness_argument": {
            "model": "Standard natural numbers with e(a,a)=0 and arbitrary positive values e(a,b) for a!=b.",
            "reason": "The old guard sign(e) still tests actual equality. A universally true reset premise gives the base at n=0 and the successor step; external ordinary induction gives the conclusion for every finite relative description.",
            "logical_consequence": "The old rule cannot force the raw comparison to have Boolean range. This is a manuscript model argument, not a machine-checked theorem.",
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "source_case_counts": result["source_case_counts"],
                      "negative_controls": len(negative_controls), "exact_counterexamples": len(bad),
                      "receipt": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
