#!/usr/bin/env python3
"""Compile the standalone report without shell escape or network access."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
engine = shutil.which("pdflatex")
if engine is None:
    raise SystemExit("pdfLaTeX is required; install a standard TeX distribution.")
build = ROOT / "build"
build.mkdir(exist_ok=True)
command = [
    engine, "-no-shell-escape", "-halt-on-error", "-file-line-error",
    "-interaction=nonstopmode", "-output-directory=" + str(build),
    str(ROOT / "ipra_feedback.tex"),
]
for _ in range(3):
    result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
    (build / "console.txt").write_text(result.stdout + result.stderr)
    if result.returncode:
        print((result.stdout + result.stderr)[-7000:])
        raise SystemExit(result.returncode)
shutil.copyfile(build / "ipra_feedback.pdf", ROOT / "ipra_feedback.pdf")
print("Built", ROOT / "ipra_feedback.pdf")

