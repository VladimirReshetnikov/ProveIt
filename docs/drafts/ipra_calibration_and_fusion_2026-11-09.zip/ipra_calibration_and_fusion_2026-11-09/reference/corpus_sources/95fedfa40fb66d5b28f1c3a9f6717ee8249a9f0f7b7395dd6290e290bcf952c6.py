#!/usr/bin/env python3
"""Run the packaged offline checks from a relocatable package directory."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
scripts = [
    "code/validate_feedback.py",
    "code/validate_anchored.py",
    "code/check_calibration.py",
    "code/measure_frontier.py",
]
for relative in scripts:
    result = subprocess.run(
        [sys.executable, str(ROOT / relative)], cwd=ROOT,
        text=True, capture_output=True
    )
    if result.returncode:
        print(result.stdout, end="")
        print(result.stderr, end="", file=sys.stderr)
        raise SystemExit(result.returncode)
    print("PASS", relative)
print("All packaged checks passed. Detailed receipts are in the package root.")

