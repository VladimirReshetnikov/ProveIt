#!/usr/bin/env python3
"""Untrusted validation for the same-base unbounded predecessor reset.

The checker imports neither this producer nor its shared decoder test support.
All expected reset formulas below explicitly use the raw predecessor failure
term. A previous sign-normalized failure term is tested as an invalid schema.
"""
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

import test_decoder_checker as d


ROOT = Path(__file__).resolve().parent.parent
CHECKER = ROOT / "code" / "unbounded_checker.py"
u = d.u


def reset(value, anchor, index):
    comparison = u.call(d.COMPARE, value, anchor)
    return u.select(u.sign(comparison), u.s(index), u.call(u.PRED, comparison))


def fixtures():
    inherited_positive, inherited_negative = d.fixtures()
    positive = {k: v for k, v in inherited_positive.items()
                if not (u.used_rules(v["proof"]) & {"FR", "Cov"})}
    excluded = {"removed_boolean_range_rule", "coverage_wrong_claim", "coverage_unbound_argument"}
    negative = {k: v for k, v in inherited_negative.items() if k not in excluded}
    A, z = u.e(u.ZERO, u.ZERO), u.v("z")
    positive["boolean_range"] = u.packet(
        u.forall(["x"], ["or", u.e(u.sign(u.v("x")), u.ZERO),
                                u.e(u.sign(u.v("x")), u.ONE)]),
        u.generalize(["x"], u.node("BR", term=u.v("x"))))
    positive["constant_unbounded_reset"] = u.packet(
        A, u.node("FR", u.refl(u.ZERO), var="z", template=u.ZERO, at=u.TWO))
    positive["passive_parameter_reset"] = u.packet(
        u.forall(["a", "t"], u.e(u.v("a"), u.v("a"))),
        u.generalize(["a", "t"], u.node("FR", u.refl(u.v("a")),
                                        var="z", template=u.v("a"), at=u.v("t"))))
    positive["identity_reset_schema"] = d.schema(z, u.v("t"), ["t"], reset)
    positive["successor_reset_schema"] = d.schema(u.s(z), u.v("t"), ["t"], reset)
    positive["comparison_template_schema"] = d.schema(
        u.call(d.COMPARE, z, u.v("a")), u.v("t"), ["a", "t"], reset)
    positive["nested_template_schema"] = d.schema(
        u.call(d.DECODER, u.call(d.COMPARE, z, u.v("a")), u.s(z)),
        u.call(d.DECODER, u.ZERO, u.v("t")), ["a", "t"], reset)
    quantified = u.forall(["x"], ["ex", "y", u.e(u.v("x"), u.v("y"))])
    body = u.node("FR", u.refl(u.ZERO), var="z", template=u.ZERO, at=u.ONE)
    positive["arbitrary_quantified_retained_context"] = u.packet(
        ["imp", quantified, A], u.node("imp_i", body, assume=quantified))

    negative["no_coverage_instruction"] = u.packet(A, u.node("Cov", term=u.ZERO))
    negative["range_unbound_argument"] = u.packet(A, u.node("BR", term=u.v("x")))
    negative["range_wrong_claim"] = u.packet(
        ["or", u.e(u.ZERO, u.ZERO), u.e(u.ZERO, u.ONE)], u.node("BR", term=u.ZERO))
    negative["old_decoder_reset_schema"] = d.schema(z, u.v("t"), ["t"])
    negative["old_sign_normalized_failure"] = d.schema(z, u.v("t"), ["t"],
        lambda value, anchor, index: u.select(u.sign(u.call(d.COMPARE, value, anchor)),
            u.s(index), u.sign(u.call(u.PRED, u.call(d.COMPARE, value, anchor)))))
    negative["failure_uses_compare_instead_of_predecessor"] = d.schema(z, u.v("t"), ["t"],
        lambda value, anchor, index: u.select(u.sign(u.call(d.COMPARE, value, anchor)),
            u.s(index), u.call(d.COMPARE, value, anchor)))
    negative["unbounded_reversed_comparison"] = d.schema(u.s(z), u.v("t"), ["t"],
        lambda value, anchor, index: reset(anchor, value, index))
    negative["unbounded_wrong_zero_test"] = d.schema(z, u.v("t"), ["t"],
        lambda value, anchor, index: u.select(u.call(d.COMPARE, value, anchor),
            u.s(index), u.call(u.PRED, u.call(d.COMPARE, value, anchor))))
    negative["unbounded_wrong_anchor"] = d.schema(u.s(z), u.v("t"), ["t"],
        lambda value, anchor, index: reset(value, u.ONE, index))
    return positive, negative


def main():
    checker = d.load(CHECKER, "unbounded_checker_under_test")
    positive, negative = fixtures()
    out = ROOT / "code" / "unbounded_fixtures"
    out.mkdir(exist_ok=True)
    failures, api_runs, runs, coverage = [], [], [], set()
    for expected, group in ((True, positive), (False, negative)):
        for label, packet in group.items():
            (out / (label + ".json")).write_text(json.dumps(packet, indent=2) + "\n")
            if expected:
                coverage |= u.used_rules(packet["proof"])
            try:
                actual = checker.verify(packet) is True
            except (ValueError, TypeError, KeyError, IndexError, RecursionError):
                actual = False
            api_ok = actual == expected
            api_runs.append({"case": label, "expected": expected, "passed": api_ok})
            if not api_ok:
                failures.append(label + ": API verdict mismatch")
            for flags in ([], ["-O"]):
                process = subprocess.run([sys.executable, *flags, str(CHECKER)],
                    input=json.dumps(packet), text=True, capture_output=True, timeout=15)
                accepted = process.returncode == 0 and process.stdout == "ACCEPT\n" and not process.stderr
                rejected = process.returncode == 1 and not process.stdout and process.stderr.startswith("REJECT:")
                passed = accepted if expected else rejected
                runs.append({"case": label, "expected": expected,
                             "optimized": bool(flags), "passed": passed})
                if not passed:
                    failures.append(label + ": CLI mismatch " + repr(flags) + ": " + process.stderr[:180])
    if coverage != set(checker.RULES):
        failures.append("Incomplete rule coverage: " + repr(coverage ^ set(checker.RULES)))
    malformed = ["{", "[]", '{"goal":0,"goal":1,"proof":null}',
                 '{"goal":NaN,"proof":null}', '{"goal":Infinity,"proof":null}',
                 '{"goal":-Infinity,"proof":null}', '{} {}']
    for i, raw in enumerate(malformed):
        for flags in ([], ["-O"]):
            process = subprocess.run([sys.executable, *flags, str(CHECKER)],
                input=raw, text=True, capture_output=True, timeout=15)
            passed = process.returncode == 1 and not process.stdout and process.stderr.startswith("REJECT:")
            runs.append({"case": "malformed_json_" + str(i), "expected": False,
                         "optimized": bool(flags), "passed": passed})
            if not passed:
                failures.append("Malformed JSON case " + str(i))
    receipt = {
        "scope": "Finite public-interface validation. The finite-pulse calibration, derived coverage and induction, and bi-interpretability metatheorems are not mechanized here.",
        "python": platform.python_version(), "checker": "code/unbounded_checker.py",
        "checker_sha256": hashlib.sha256(CHECKER.read_bytes()).hexdigest(),
        "accepted_packets": len(positive), "rejected_packets": len(negative),
        "malformed_json_cases": len(malformed), "api_runs": len(api_runs),
        "public_cli_runs": len(runs), "rule_coverage": sorted(coverage),
        "failures": failures, "api_receipts": api_runs, "cli_receipts": runs,
    }
    (ROOT / "evidence" / "unbounded_checker_validation.json").write_text(
        json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({k: v for k, v in receipt.items()
                      if k not in {"api_receipts", "cli_receipts"}}, indent=2))
    return bool(failures)


if __name__ == "__main__":
    raise SystemExit(main())
