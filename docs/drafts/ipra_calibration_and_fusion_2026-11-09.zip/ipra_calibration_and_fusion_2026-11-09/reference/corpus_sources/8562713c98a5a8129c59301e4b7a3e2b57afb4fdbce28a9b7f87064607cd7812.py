#!/usr/bin/env python3
"""Compile the standalone report twice with shell escape disabled."""
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    build = ROOT / 'build'
    build.mkdir(exist_ok=True)
    engine = shutil.which('pdflatex')
    if engine is None:
        raise SystemExit('pdflatex is required to compile this report.')
    command = [engine, '-no-shell-escape', '-interaction=nonstopmode',
               '-halt-on-error', '-file-line-error', '-output-directory', str(build),
               str(ROOT / 'ipra_finite_escape.tex')]
    logs = []
    for run in range(2):
        result = subprocess.run(command, cwd=ROOT, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        logs.append(result.stdout)
        if result.returncode:
            (ROOT / 'evidence/latex_build.txt').write_text('\n'.join(logs))
            raise SystemExit('LaTeX compilation failed; see evidence/latex_build.txt.')
    shutil.copyfile(build / 'ipra_finite_escape.pdf', ROOT / 'ipra_finite_escape.pdf')
    (ROOT / 'evidence/latex_build.txt').write_text('\n'.join(logs))
    print('Compiled ipra_finite_escape.pdf')


if __name__ == '__main__':
    main()
