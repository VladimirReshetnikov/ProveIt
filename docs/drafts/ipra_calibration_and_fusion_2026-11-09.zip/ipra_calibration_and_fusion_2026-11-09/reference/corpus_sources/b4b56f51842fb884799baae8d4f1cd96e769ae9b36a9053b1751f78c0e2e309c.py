#!/usr/bin/env python3
"""Verify the original archive payload before refreshing evidence files."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / 'MANIFEST.json').read_text())
for item in manifest['files']:
    path = ROOT / item['path']
    data = path.read_bytes()
    if len(data) != item['bytes'] or hashlib.sha256(data).hexdigest() != item['sha256']:
        raise SystemExit('Manifest mismatch: ' + item['path'])
print('Verified ' + str(len(manifest['files'])) + ' payload files.')
