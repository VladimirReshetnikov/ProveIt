#!/usr/bin/env python3
"""Exact finite abstraction of the new pulse lemma, not a proof of iPRA equivalence.

q[j] represents sign(P^j(z)).  Boolean range is assumed, as in T_U.
Every assignment is checked, including assignments not realized in N.
The scalar checker and this independent evidence program do not import each other.
"""
import itertools
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CHOICES = (2, 3, 4)


def pulse(m, q):
    return int(all(q[j] == 1 for j in range(1, m)) and q[m] == 0)


def numeric_pulse(m, n):
    q = [int(max(n - j, 0) != 0) for j in range(5)]
    return pulse(m, q)


def require(condition, description):
    if not condition:
        raise ValueError(description)


def main():
    patterns = list(itertools.product((0, 1), repeat=5))
    pulse_vectors = []
    successor_checks = 0
    for q in patterns:
        values = tuple(pulse(m, q) for m in CHOICES)
        require(sum(values) <= 1, 'Pulse supports overlap')
        pulse_vectors.append(values)
        # P(Sz)=z shifts the observations; the last entry is never used.
        shifted = [None, q[0], q[1], q[2], q[3]]
        for m in CHOICES:
            require(not pulse(m, q) or not pulse(m, shifted),
                    'A pulse contains an input and its successor')
            successor_checks += 1
    escape_checks = 0
    for u, v in itertools.product(pulse_vectors, repeat=2):
        candidates = [m for j, m in enumerate(CHOICES) if u[j] == v[j] == 0]
        require(bool(candidates), 'Two inputs hit all three disjoint supports')
        escape_checks += 1
    for m in CHOICES:
        require(numeric_pulse(m, 0) == numeric_pulse(m, 1) == 0,
                'Bad anchor endpoint')
        require(numeric_pulse(m, m) == 1, 'Missing spike endpoint')
    # Diagonal: under E(a,a)=1, the ordinary branch fails to a point
    # off the chosen support; the exceptional branch either advances
    # off the support or fails to a second point off it.
    diagonal_branches = []
    for exceptional, guard_b in itertools.product((False, True), (0, 1)):
        destination_case = ('fallback_a' if not exceptional else
                            'successor' if guard_b == 0 else 'fallback_b')
        diagonal_branches.append({'exceptional_input': exceptional,
            'E_b_a': guard_b, 'destination': destination_case, 'spike_value': 'a'})
    result = {'boolean_patterns': len(patterns),
              'possible_pulse_vectors': [list(v) for v in sorted(set(pulse_vectors))],
              'successor_implications_checked': successor_checks,
              'ordered_escape_checks': escape_checks,
              'anchors_and_spikes': {str(m): [numeric_pulse(m, n) for n in range(6)]
                                    for m in CHOICES},
              'diagonal_branches': diagonal_branches, 'passed': True,
              'scope': 'Exhaustive exact check of finite Boolean identities and escape '
                       'selection. The universal reset applications, calibration, '
                       'interpretations and description uniqueness are written proofs.'}
    (ROOT / 'evidence/finite_escape.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
