#!/usr/bin/env python3
"""Untrusted public-interface tests for the standalone decoder checker.

Expected equations are constructed independently of the production inference
functions. The inherited support supplies ordinary logical/syntax fixtures;
the production checker imports neither it nor this test producer. This is
finite implementation evidence, not a formalization of the calibration proof.
"""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys


ROOT = Path(__file__).resolve().parent.parent
CHECKER = ROOT / "code" / "decoder_checker.py"
SUPPORT = ROOT / "references" / "upstream_fixtures.py"


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


u = load(SUPPORT, "inherited_fixture_support")
DECODER = ["rec", ["succ"], ["proj", 3, 0]]
COMPARE = ["compare"]


def reset(value, anchor, index):
    return u.call(DECODER, u.call(COMPARE, value, anchor), index)


def schema(template, target, parameters, reset_builder=reset):
    x = "z"
    anchor = u.replace_term(template, x, u.ONE)
    rho = reset_builder(template, anchor, u.v(x))
    body = u.e(u.replace_term(template, x, rho), anchor)
    assumption = ["all", x, body]
    application = u.node("FR", u.node("all_e", u.hyp(0), term=u.v(x)),
                         var=x, template=template, at=target)
    goal = ["imp", assumption, u.e(u.replace_term(template, x, target), anchor)]
    return u.packet(u.forall(parameters, goal),
                    u.generalize(parameters,
                                 u.node("imp_i", application, assume=assumption)))


def equality_chain(left, middle, right, first, second):
    return u.node("transport", second, first, var="_chain",
                  body=u.e(left, u.v("_chain")))


def two_step_computation(description, arguments, intermediate, result):
    first = u.node("compute", description=description, arguments=arguments)
    second = u.node("compute", description=intermediate[1], arguments=intermediate[2])
    return equality_chain(u.call(description, *arguments), intermediate, result, first, second)


def fixtures():
    inherited_positive, inherited_negative = u.fixtures()
    removed = {"SR", "BR", "Sep", "bot_e"}
    keep = lambda packet: not (u.used_rules(packet["proof"]) & removed)
    positive = {"inherited_" + k: v for k, v in inherited_positive.items() if keep(v)}
    negative = {"inherited_" + k: v for k, v in inherited_negative.items() if keep(v)}
    A = u.e(u.ZERO, u.ZERO)
    x, y, z = u.v("x"), u.v("y"), u.v("z")

    # Coverage is the exact whole-domain disjunction, not merely Boolean range.
    positive["numerical_coverage"] = u.packet(
        u.forall(["x"], ["or", u.e(x, u.ZERO), u.e(x, u.s(u.call(u.PRED, x)))]),
        u.generalize(["x"], u.node("Cov", term=x)))

    # D(0,z)=Sz and D(Su,z)=u each require two real computation nodes.
    middle = u.call(["succ"], z)
    proof = two_step_computation(DECODER, [u.ZERO, z], middle, u.s(z))
    positive["decoder_zero_equation"] = u.packet(
        u.forall(["z"], u.e(u.call(DECODER, u.ZERO, z), u.s(z))),
        u.generalize(["z"], proof))
    middle = u.call(["proj", 3, 0], x, u.call(DECODER, x, z), z)
    proof = two_step_computation(DECODER, [u.s(x), z], middle, x)
    positive["decoder_successor_equation"] = u.packet(
        u.forall(["x", "z"], u.e(u.call(DECODER, u.s(x), z), x)),
        u.generalize(["x", "z"], proof))

    positive["constant_decoder_reset"] = u.packet(
        A, u.node("FR", u.refl(u.ZERO), var="z", template=u.ZERO, at=u.TWO))
    positive["passive_parameter_reset"] = u.packet(
        u.forall(["a", "t"], u.e(u.v("a"), u.v("a"))),
        u.generalize(["a", "t"], u.node("FR", u.refl(u.v("a")),
                                        var="z", template=u.v("a"), at=u.v("t"))))
    positive["identity_reset_schema"] = schema(z, u.v("t"), ["t"])
    positive["successor_reset_schema"] = schema(u.s(z), u.v("t"), ["t"])
    positive["comparison_template_schema"] = schema(
        u.call(COMPARE, z, u.v("a")), u.v("t"), ["a", "t"])
    positive["nested_template_schema"] = schema(
        u.call(DECODER, u.call(COMPARE, z, u.v("a")), u.s(z)),
        u.call(DECODER, u.ZERO, u.v("t")), ["a", "t"])

    quantified = u.forall(["x"], ["ex", "y", u.e(x, y)])
    body = u.node("FR", u.refl(u.ZERO), var="z", template=u.ZERO, at=u.ONE)
    positive["arbitrary_quantified_retained_context"] = u.packet(
        ["imp", quantified, A], u.node("imp_i", body, assume=quantified))

    compare = u.call(COMPARE, x, y)
    positive["comparison_term_reflexivity"] = u.packet(
        u.forall(["x", "y"], u.e(compare, compare)),
        u.generalize(["x", "y"], u.refl(compare)))
    desc = ["comp", 1, COMPARE, [["proj", 1, 0], ["zero", 1]]]
    right = u.call(COMPARE, u.call(["proj", 1, 0], u.ONE),
                   u.call(["zero", 1], u.ONE))
    positive["comparison_in_composition"] = u.packet(
        u.e(u.call(desc, u.ONE), right),
        u.node("compute", description=desc, arguments=[u.ONE]))
    desc = ["rec", ["zero", 0], COMPARE]
    positive["comparison_in_recursion"] = u.packet(
        u.e(u.call(desc, u.ONE), u.call(COMPARE, u.ZERO, u.call(desc, u.ZERO))),
        u.node("compute", description=desc, arguments=[u.ONE]))

    # A genuine derived collapse certificate: 0=1 entails x=y using the
    # ordinary selector's defining equations and equality transport only.
    C0, C1 = u.call(u.COND, u.ZERO, x, y), u.call(u.COND, u.ONE, x, y)
    c0proof = two_step_computation(u.COND, [u.ZERO, x, y],
                                  u.call(["proj", 2, 0], x, y), x)
    c1proof = two_step_computation(u.COND, [u.ONE, x, y],
                                  u.call(["proj", 4, 3], u.ZERO, C0, x, y), y)
    symmetry = u.node("transport", c0proof, u.refl(C0), var="_sym",
                      body=u.e(u.v("_sym"), C0))
    changed = u.node("transport", u.hyp(0), symmetry, var="_arg",
                     body=u.e(x, u.call(u.COND, u.v("_arg"), x, y)))
    collapsed = u.node("transport", c1proof, changed, var="_out",
                       body=u.e(x, u.v("_out")))
    positive["derived_equational_explosion"] = u.packet(
        u.forall(["x", "y"], ["imp", u.e(u.ZERO, u.ONE), u.e(x, y)]),
        u.generalize(["x", "y"],
                     u.node("imp_i", collapsed, assume=u.e(u.ZERO, u.ONE))))

    negative["compare_has_no_equation"] = u.packet(
        u.e(u.call(COMPARE, u.ZERO, u.ZERO), u.ZERO),
        u.node("compute", description=COMPARE, arguments=[u.ZERO, u.ZERO]))
    negative["compare_wrong_arity"] = u.packet(A, u.refl(u.call(COMPARE, u.ZERO)))
    negative["compare_extra_tag_data"] = u.packet(
        A, u.refl(u.call(["compare", 2], u.ZERO, u.ZERO)))
    negative["unproved_comparison_diagonal"] = u.packet(
        u.e(u.call(COMPARE, u.ZERO, u.ZERO), u.ZERO), u.refl(u.ZERO))
    negative["reset_wrong_premise"] = u.packet(
        A, u.node("FR", u.refl(u.ZERO), var="z", template=z, at=u.ZERO))
    negative["reset_target_escape"] = u.packet(
        A, u.node("FR", u.refl(u.ZERO), var="z", template=u.ZERO, at=z))
    negative["reset_template_unbound_parameter"] = u.packet(
        A, u.node("FR", u.refl(u.ZERO), var="z", template=u.v("a"), at=u.ZERO))
    negative["reset_ambient_eigenvariable"] = u.packet(
        u.forall(["z"], A), u.generalize(["z"],
            u.node("FR", u.refl(u.ZERO), var="z", template=u.ZERO, at=u.ZERO)))
    negative["reset_hidden_local_assumption"] = u.packet(
        A, u.node("FR", u.hyp(0), var="z", template=u.ZERO, at=u.ZERO))
    negative["reset_extra_premise"] = u.packet(
        A, u.node("FR", u.refl(u.ZERO), u.refl(u.ZERO),
                  var="z", template=u.ZERO, at=u.ZERO))
    negative["reset_arbitrary_anchor_field"] = u.packet(
        A, u.node("FR", u.refl(u.ZERO), var="z", template=u.ZERO,
                  at=u.ZERO, anchor=u.ZERO))
    negative["reset_malformed_target_even_if_unused"] = u.packet(
        A, u.node("FR", u.refl(u.ZERO), var="z", template=u.ZERO,
                  at=["bad_term"]))
    negative["reset_wrong_decoder_projection"] = schema(z, u.v("t"), ["t"],
        lambda value, anchor, index: u.call(["rec", ["succ"], ["proj", 3, 1]],
                                            u.call(COMPARE, value, anchor), index))
    negative["reset_reversed_comparison"] = schema(u.s(z), u.v("t"), ["t"],
        lambda value, anchor, index: u.call(DECODER, u.call(COMPARE, anchor, value), index))
    negative["reset_previous_feedback"] = schema(z, u.v("t"), ["t"],
        lambda value, anchor, index: u.select(u.sign(u.call(COMPARE, value, anchor)),
                       u.s(index), u.sign(u.call(u.PRED, u.call(COMPARE, value, anchor)))))
    negative["reset_zero_fallback"] = schema(z, u.v("t"), ["t"],
        lambda value, anchor, index: u.select(u.call(COMPARE, value, anchor), u.s(index), u.ZERO))
    negative["reset_wrong_anchor_one_not_template_one"] = schema(u.s(z), u.v("t"), ["t"],
        lambda value, anchor, index: u.call(DECODER, u.call(COMPARE, value, u.ONE), index))

    negative["removed_boolean_range_rule"] = u.packet(A, u.node("BR", term=u.ZERO))
    negative["removed_separation_rule"] = u.packet(A, u.node("Sep"))
    negative["removed_primitive_falsity"] = u.packet(
        ["imp", ["bot"], ["bot"]], u.node("imp_i", u.hyp(0), assume=["bot"]))
    negative["removed_falsity_elimination"] = u.packet(
        A, u.node("bot_e", u.refl(u.ZERO), **{"as": A}))
    negative["coverage_wrong_claim"] = u.packet(
        ["or", u.e(u.ZERO, u.ZERO), u.e(u.ZERO, u.ONE)], u.node("Cov", term=u.ZERO))
    negative["coverage_unbound_argument"] = u.packet(A, u.node("Cov", term=x))

    # Input strictness matters even when an otherwise valid proof is supplied.
    negative["packet_extra_field"] = copy.deepcopy(positive["inherited_reflexivity"])
    negative["packet_extra_field"]["accepted"] = True
    negative["proof_extra_field"] = copy.deepcopy(positive["inherited_reflexivity"])
    negative["proof_extra_field"]["proof"]["oracle"] = True
    return positive, negative


def main():
    checker = load(CHECKER, "decoder_checker_under_test")
    positive, negative = fixtures()
    fixtures_path = ROOT / "code" / "fixtures"
    fixtures_path.mkdir(exist_ok=True)
    failures, runs, api_runs = [], [], []
    coverage = set()
    for expected, group in ((True, positive), (False, negative)):
        for label, packet in group.items():
            (fixtures_path / (label + ".json")).write_text(json.dumps(packet, indent=2) + "\n")
            if expected:
                coverage |= u.used_rules(packet["proof"])
            try:
                actual = checker.verify(packet) is True
            except (ValueError, TypeError, KeyError, IndexError, RecursionError):
                actual = False
            api_ok = actual == expected
            api_runs.append({"case": label, "expected": expected, "passed": api_ok})
            if not api_ok:
                failures.append(label + ": API verdict mismatch")
            for flags in ([], ["-O"]):
                process = subprocess.run([sys.executable, *flags, str(CHECKER)],
                    input=json.dumps(packet), text=True, capture_output=True, timeout=15)
                accepted = process.returncode == 0 and process.stdout == "ACCEPT\n" and not process.stderr
                rejected = process.returncode == 1 and not process.stdout and process.stderr.startswith("REJECT:")
                passed = accepted if expected else rejected
                runs.append({"case": label, "expected": expected,
                             "optimized": bool(flags), "passed": passed})
                if not passed:
                    failures.append(label + ": CLI mismatch " + repr(flags) + ": " + process.stderr[:180])
    if coverage != set(checker.RULES):
        failures.append("Incomplete rule coverage: " + repr(coverage ^ set(checker.RULES)))
    malformed = ["{", "[]", '{"goal":0,"goal":1,"proof":null}',
                 '{"goal":NaN,"proof":null}', '{"goal":Infinity,"proof":null}',
                 '{"goal":-Infinity,"proof":null}', '{} {}']
    for i, raw in enumerate(malformed):
        for flags in ([], ["-O"]):
            process = subprocess.run([sys.executable, *flags, str(CHECKER)],
                input=raw, text=True, capture_output=True, timeout=15)
            passed = process.returncode == 1 and not process.stdout and process.stderr.startswith("REJECT:")
            runs.append({"case": "malformed_json_" + str(i), "expected": False,
                         "optimized": bool(flags), "passed": passed})
            if not passed:
                failures.append("Malformed JSON case " + str(i))
    receipt = {
        "scope": "Finite public-interface validation. The handwritten self-calibration, induction recovery, and bi-interpretability metatheorems are not mechanized here.",
        "python": platform.python_version(),
        "checker": "code/decoder_checker.py",
        "checker_sha256": hashlib.sha256(CHECKER.read_bytes()).hexdigest(),
        "accepted_packets": len(positive), "rejected_packets": len(negative),
        "malformed_json_cases": len(malformed), "api_runs": len(api_runs),
        "public_cli_runs": len(runs), "rule_coverage": sorted(coverage),
        "failures": failures, "api_receipts": api_runs, "cli_receipts": runs,
    }
    destination = ROOT / "evidence" / "checker_validation.json"
    destination.parent.mkdir(exist_ok=True)
    destination.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({k: v for k, v in receipt.items()
                      if k not in {"api_receipts", "cli_receipts"}}, indent=2))
    return bool(failures)


if __name__ == "__main__":
    raise SystemExit(main())
