#!/usr/bin/env python3
"""Remeasure the unchanged complete comparator sources without executing them."""
import hashlib
import json
from pathlib import Path
import platform

import upstream_fixtures as u

ROOT = Path(__file__).resolve().parent.parent
manifest = json.loads((ROOT / "reference/frontier_manifest.json").read_text())
rows = []
for item in manifest["programs"]:
    path = ROOT / item["file"]
    if hashlib.sha256(path.read_bytes()).hexdigest() != item["sha256"]:
        raise ValueError("Changed frozen comparator: " + item["file"])
    rows.append({**item, **u.measure(path)})
fields = ("normalized_tokens", "ast_nodes", "normalized_bytes")
minimum = {key: min(row[key] for row in rows) for key in fields}
result = {"python": platform.python_version(), "snapshot": manifest["snapshot"],
          "source_boundary": "Whole module; genuine docstrings removed; corpus AST-unparse measure.",
          "program_count": len(rows), "coordinate_envelope": minimum,
          "attainers": {key: [row["file"] for row in rows if row[key] == value]
                        for key, value in minimum.items()}, "programs": rows,
          "feedback": u.measure(ROOT / "code/feedback_checker.py"),
          "feedback_anchored": u.measure(ROOT / "code/feedback_anchored_checker.py"),
          "raw_reset_baseline": u.measure(ROOT / "code/baseline_raw_reset.py")}
(ROOT / "frontier_metrics.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({key: value for key, value in result.items() if key != "programs"}, indent=2))
