#!/usr/bin/env python3
"""Reproduce finite checks and whole-source metrics using the standard library."""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

for script in ('code/test_unbounded_checker.py', 'code/test_decoder_checker.py',
               'code/check_finite_escape.py', 'code/measure_sources.py'):
    print('Running ' + script, flush=True)
    subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)

print('All reproduction steps passed.')
