#!/usr/bin/env python3
"""Whole-source measurements; no compared checker is imported or executed."""
import ast
import hashlib
import io
import json
import platform
import tokenize
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(path):
    raw = path.read_bytes()
    return measure_bytes(raw)


def measure_bytes(raw):
    tree = ast.fix_missing_locations(StripDocstrings().visit(ast.parse(raw.decode())))
    text = ast.unparse(tree) + '\n'
    return {'normalized_tokens': sum(t.type not in IGNORED for t in
                tokenize.generate_tokens(io.StringIO(text).readline)),
            'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'normalized_bytes': len(text.encode()),
            'sha256': hashlib.sha256(raw).hexdigest(), 'raw_bytes': len(raw)}


def main():
    manifest = json.loads((ROOT / 'references/native_manifest.json').read_text())
    native = []
    for item in manifest['programs']:
        row = {'file': item['file'], **measure(ROOT / item['file'])}
        if row['sha256'] != item['sha256']:
            raise ValueError('Changed frozen comparator: ' + item['file'])
        native.append(row)
    names = ['references/feedback_checker.py', 'references/feedback_anchored_checker.py',
             'code/unbounded_checker.py', 'code/decoder_checker.py']
    candidates = [{'file': name, **measure(ROOT / name)} for name in names]
    raw_unbounded = (ROOT / 'code/unbounded_checker.py').read_text()
    old = 'return choose(sign(comparison), successor(index), predecessor(comparison))'
    new = 'return choose(sign(comparison), successor(index), sign(predecessor(comparison)))'
    if raw_unbounded.count(old) != 1:
        raise ValueError('Unbounded reset spelling changed; review isolated control')
    clamped = measure_bytes(raw_unbounded.replace(old, new).encode())
    unclamped = measure(ROOT / 'code/unbounded_checker.py')
    fields = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
    envelope = {key: min(r[key] for r in native) for key in fields}
    result = {'python': platform.python_version(), 'snapshot': manifest['snapshot'],
        'method': 'Complete modules; only genuine docstrings and comments removed; '
                  'ast.unparse normalization; no renaming or omission of input handling.',
        'native_coordinate_envelope': envelope,
        'attainers': {k: [r['file'] for r in native if r[k] == v]
                     for k, v in envelope.items()},
        'native_comparators': native, 'matched_and_new_checkers': candidates,
        'isolated_clamp_control': {
            'description': 'Deterministic whole-source control: restore only the outer '
                           'sign on the failure argument; keep all other source bytes fixed.',
            'clamped_control': clamped,
            'new_unbounded': unclamped,
            'savings': {k: clamped[k] - unclamped[k] for k in fields}},
        'qualification': 'This is a measured corpus envelope, not a complexity lower bound. '
                         'Input contracts differ; measurements alone do not certify correctness.'}
    (ROOT / 'evidence/source_metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
