#!/usr/bin/env python3
"""Verify every payload named by the package SHA-256 manifest."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / "MANIFEST.json").read_text())
failures = []
for entry in manifest["files"]:
    path = ROOT / entry["path"]
    if not path.is_file():
        failures.append(entry["path"] + ": missing")
        continue
    data = path.read_bytes()
    if len(data) != entry["size"] or hashlib.sha256(data).hexdigest() != entry["sha256"]:
        failures.append(entry["path"] + ": changed")
if failures:
    print("\n".join(failures))
    raise SystemExit(1)
print("Verified", len(manifest["files"]), "payload files.")

