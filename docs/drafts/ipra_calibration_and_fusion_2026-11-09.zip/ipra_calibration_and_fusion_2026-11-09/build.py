"""Build the supplied editable LaTeX report; no shell escape or network."""
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent


def flatten(path):
    source = path.read_text()
    def include(match):
        child = ROOT / match.group(1)
        if not child.suffix:
            child = child.with_suffix('.tex')
        return '\n% Begin included source: ' + str(child.relative_to(ROOT)) + '\n' + flatten(child) + '\n% End included source\n'
    source = re.sub(r'\\input\{([^}]+)\}', include, source)
    def listing(match):
        options, name = match.groups()
        first = re.search(r'firstline=(\d+)', options or '')
        start = int(first.group(1)) - 1 if first else 0
        lines = (ROOT / name).read_text().splitlines()
        clean = re.sub(r',?firstline=\d+,?', '', options or '').strip(',')
        return '\\begin{lstlisting}' + ('[' + clean + ']' if clean else '') + '\n' + '\n'.join(lines[start:]) + '\n\\end{lstlisting}'
    return re.sub(r'\\lstinputlisting(?:\[([^]]*)\])?\{([^}]+)\}', listing, source)


def main():
    standalone = ROOT / 'ipra_calibration_and_fusion_2026-11-09.tex'
    standalone.write_text(flatten(ROOT / 'report.tex'))
    logs = []
    for _ in range(3):
        result = subprocess.run(['pdflatex', '-no-shell-escape',
            '-interaction=nonstopmode', '-halt-on-error', 'report.tex'],
            cwd=ROOT, text=True, capture_output=True)
        logs.append(result.stdout + result.stderr)
        if result.returncode:
            (ROOT / 'evidence/build_console.txt').write_text('\n'.join(logs))
            raise RuntimeError('PDFLaTeX failed; see evidence/build_console.txt')
    (ROOT / 'evidence/build_console.txt').write_text('\n'.join(logs))
    final = ROOT / 'ipra_calibration_and_fusion_2026-11-09.pdf'
    final.write_bytes((ROOT / 'report.pdf').read_bytes())
    print(final.name)


if __name__ == '__main__':
    main()
