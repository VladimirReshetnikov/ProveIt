FINITE CALIBRATION AND FUSED ITERATION FOR iPRA
==============================================
Prepared for Vladimir Reshetnikov, 9 November 2026 (Pacific date).

STATUS
------
The requested new complete axiomatization below the supplied proof-checker
frontier has NOT been obtained. The report gives two structural research
results and a complementary bounded-clock obstruction, a complete inherited
reference basis, and reproducible evidence. It does not claim a significant
minimization breakthrough, an absolute minimum, or Lean/Rocq formalization.

MAIN RESULTS
------------
1. No finite set of native formula axioms repairs the deterministic
   atomic-progress/compound-case reduction to the old Eq/Q/D consequence
   relation. The proof handles arbitrary finite nested native axioms and
   numerical parameters. It extends earlier flexible-closure countermodels
   using a primitive-recursive diagonal over finitely many matrix families.
   It does not exclude unrelated bi-interpretations or new schematic rules.

2. Terms using zero, successor, predecessor, and J_h(n)=h^c(n)(n), with
   c(2k)=0 and c(2k+1)=k+1, define every primitive-recursive function.
   Explicit terms derive halving, doubling, selectors, and arbitrary
   initialized iteration. A full fixed-description compiler is included.
   This is a functional-completeness result under stipulated semantics;
   a small independent source axiom scheme and its bi-interpretations
   remain unestablished.

3. Uniformly bounded coupled clocks preserve finite unary alternatives,
   even over all unary PR and globally bounded multivariate PR primitives.
   A counting argument excludes addition and injective pairing. An
   unbounded zero-clock fibre alone therefore does not ensure completeness.

FILES TO OPEN
-------------
ipra_calibration_and_fusion_2026-11-09.pdf : complete compiled report.
ipra_calibration_and_fusion_2026-11-09.tex : standalone editable source.
report.tex and sections/                 : modular editable source.
code/fusion_terms.py                     : term compiler and finite checks.
code/fusion_scope_audit.py               : independent binding checks.
code/reproduce.py                        : source audit and proof replays.
reference/choice/                        : unchanged complete checkers.
reference/arithmetic/                    : attributed arithmetic proofs.
reference/corpus_sources/                : all 302 distinct Python sources.
evidence/                               : manifests, measurements, receipts.

REPRODUCE
---------
Python standard library, preferably CPython 3.12.14 for exact metrics:
    python3 code/reproduce.py
    python3 code/fusion_scope_audit.py

PDFLaTeX from a normal TeX Live or MiKTeX installation:
    python3 build.py

The standalone TeX can also be compiled directly with PDFLaTeX three times.
No network, external bibliography processor, or shell escape is needed.

EVIDENCE SCOPE
--------------
The corpus contains 30 pinned ZIP archives: 809 direct Python occurrences,
302 distinct sources. Complete reference programs attain 299 tokens,
340 AST nodes, and 815 normalized bytes, in different programs. All
parser, rule, data, and verdict code is counted. A one-token local
refactoring reaches 298/347/893 and is explicitly not treated as the
requested overall improvement.

676 command-line certificate replays passed across three unchanged
reference checkers and that minor refactoring. 369 fused-term checks
and 1,800 independent scope comparisons passed. The generic PR-recursion
compiler through pairing and scans is supplied but is not included in
finite end-to-end execution coverage; its expansion is large. Universal
and nonstandard claims rest on the written proofs, not finite tests.

SOURCES
-------
Repository: https://github.com/VladimirReshetnikov/ProveIt
Pinned commit: aac8216be66b1a6f043fed87a8d515bc5b5d0790
Directory: docs/drafts
Historical reflection source commit:
89fd4b4c5cd158259b1f2846f63e3d98f053553c

See ATTRIBUTION.txt and the bibliography for inherited versus new work.
No repository write was performed. Source identities are recorded so
the package can be reviewed without downloading the corpus again.
