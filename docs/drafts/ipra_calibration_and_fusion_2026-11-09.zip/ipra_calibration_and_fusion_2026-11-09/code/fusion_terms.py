"""Untrusted compiler for the alternating-clock fusion theorem.

Primitive terms are zero, successor, truncated predecessor, variables,
and J(counter, state_body).  J_h(n) starts at n, takes no steps at even n,
and takes (n+1)//2 steps at odd n.  Bodies bind de Bruijn variable 0;
ambient variables shift by one.  None of the derived term bodies contains
a primitive selector, parity, addition, doubling, halving, or initialized
iteration.  The evaluator implements J's stipulated STANDARD semantics;
it is not an iPRA proof checker or a source-theory verification.
"""

from dataclasses import dataclass
from functools import cache
import json
from pathlib import Path


@dataclass(frozen=True, eq=False)
class Term:
    op: str
    args: tuple


@cache
def node(op, *args):
    return Term(op, args)


def V(i):
    assert type(i) is int and i >= 0
    return node("v", i)


Z = node("z")


def S(t):
    return node("s", t)


def P(t):
    return node("p", t)


def J(counter, body):
    return node("j", counter, body)


def successors(t, n=1):
    for _ in range(n):
        t = S(t)
    return t


def predecessors(t, n=1):
    for _ in range(n):
        t = P(t)
    return t


@cache
def shift(t, amount=1, cutoff=0):
    if t.op == "v":
        i = t.args[0]
        return V(i + amount) if i >= cutoff else t
    if t.op == "z":
        return t
    if t.op in ("s", "p"):
        return node(t.op, shift(t.args[0], amount, cutoff))
    n, body = t.args
    return J(shift(n, amount, cutoff), shift(body, amount, cutoff + 1))


@cache
def replace(t, index, replacement):
    """Replace one FREE variable, preserving all other variable indices."""
    if t.op == "v":
        return replacement if t.args[0] == index else t
    if t.op == "z":
        return t
    if t.op in ("s", "p"):
        return node(t.op, replace(t.args[0], index, replacement))
    n, body = t.args
    return J(replace(n, index, replacement),
             replace(body, index + 1, shift(replacement)))


def Jconst(n, a):
    return J(n, shift(a))


def even_ceiling(n):
    return Jconst(n, S(n))


def odd_floor_plus_one(n):
    return P(even_ceiling(S(n)))


def half(n):
    return J(odd_floor_plus_one(n), P(V(0)))


def even_data_choice(u, a, b):
    """Return a at odd u, b at even u, PROVIDED a is even."""
    return predecessors(Jconst(S(Jconst(u, S(a))), successors(b, 2)), 2)


def phase_clock(n):
    return J(odd_floor_plus_one(n), successors(V(0), 2))


def double(n):
    k = phase_clock(n)
    return even_data_choice(n, P(k), predecessors(k, 3))


def odd_choice(u, a, b):
    """Return a at odd u and b at even u, with unrestricted data."""
    return half(even_data_choice(u, double(a), double(b)))


def zero_marker(n):
    return S(P(double(n)))


def zero_choice(n, a, b):
    return odd_choice(zero_marker(n), a, b)


def zero_test(n):
    return zero_choice(n, S(Z), Z)


def positive_test(n):
    return zero_choice(n, Z, S(Z))


def iterate(counter, initializer, body):
    """Compile h^counter(initializer), with state variable 0 in body."""
    update = odd_choice(
        V(0),
        double(shift(initializer)),
        double(replace(body, 0, half(V(0)))),
    )
    return half(J(S(double(counter)), update))


def add(a, b):
    return iterate(b, a, S(V(0)))


def multiply(a, b):
    return iterate(b, Z, add(V(0), shift(a)))


def subtract(a, b):
    return iterate(b, a, P(V(0)))


def power_two(n):
    return iterate(n, S(Z), double(V(0)))


def least_bounded(bound, predicate_body):
    """First positive-predicate index, or bound when none below bound."""
    step = zero_choice(predicate_body, S(V(0)), V(0))
    return iterate(bound, Z, step)


def quotient(n, d):
    predicate = positive_test(subtract(multiply(shift(d), S(V(0))), shift(n)))
    search = least_bounded(S(n), predicate)
    return zero_choice(d, Z, search)


def pair(a, b):
    return P(multiply(power_two(a), S(double(b))))


def left(code):
    n = S(code)
    predicate = odd_choice(quotient(shift(n), power_two(V(0))), S(Z), Z)
    return least_bounded(S(n), predicate)


def right(code):
    return half(P(quotient(S(code), power_two(left(code)))))


def compile_pr(description, arguments):
    """Compile the ordinary finite PR-description grammar to primitive J terms.

    ('zero', arity); ('succ',); ('proj', arity, index);
    ('comp', outer, tuple(inner_descriptions)); ('rec', base, step).
    A recursor has arguments (counter, *parameters), and its step has
    arguments (index, previous_value, *parameters).  The caller supplies
    a well-formed PR description; this untrusted compiler is not a validator.
    """
    tag, *data = description
    if tag == "zero":
        return Z
    if tag == "succ":
        return S(arguments[0])
    if tag == "proj":
        return arguments[data[1]]
    if tag == "comp":
        outer, inners = data
        return compile_pr(outer, tuple(compile_pr(f, arguments) for f in inners))
    if tag == "rec":
        base, step = data
        counter, *parameters = arguments
        initial = pair(Z, compile_pr(base, tuple(parameters)))
        n, y = left(V(0)), right(V(0))
        value = compile_pr(step, (n, y, *(shift(p) for p in parameters)))
        update = pair(S(n), value)
        return right(iterate(counter, initial, update))
    raise ValueError("Unknown PR-description tag")


def validate(t, arity):
    """Check that a graph contains ONLY the advertised primitive grammar."""
    seen = set()

    def walk(t, arity):
        key = (t, arity)
        if key in seen:
            return
        seen.add(key)
        assert isinstance(t, Term)
        if t.op == "v":
            assert len(t.args) == 1 and type(t.args[0]) is int
            assert 0 <= t.args[0] < arity
        elif t.op == "z":
            assert not t.args
        elif t.op in ("s", "p"):
            assert len(t.args) == 1
            walk(t.args[0], arity)
        else:
            assert t.op == "j" and len(t.args) == 2
            walk(t.args[0], arity)
            walk(t.args[1], arity + 1)

    walk(t, arity)
    return len(seen)


@cache
def free_variables(t):
    if t.op == "v":
        return frozenset(t.args)
    if t.op == "z":
        return frozenset()
    if t.op in ("s", "p"):
        return free_variables(t.args[0])
    return (free_variables(t.args[0]) |
            frozenset(i - 1 for i in free_variables(t.args[1]) if i))


def evaluator(limit=5_000_000, max_steps=100_000):
    """A cache is an optimization only; every uncached step uses primitive AST."""
    work = 0

    def evaluate(t, environment=()):
        # Omit irrelevant environmental values from the memoization key.
        # This changes no numerical semantics and introduces no term macro.
        fv = free_variables(t)
        normalized = tuple(environment[i] if i in fv else 0
                           for i in range(1 + max(fv, default=-1)))
        return cached_evaluate(t, normalized)

    @cache
    def cached_evaluate(t, environment=()):
        nonlocal work
        work += 1
        if work > limit:
            raise RuntimeError("Finite evaluation budget exceeded")
        if t.op == "v":
            return environment[t.args[0]]
        if t.op == "z":
            return 0
        if t.op == "s":
            return evaluate(t.args[0], environment) + 1
        if t.op == "p":
            return max(0, evaluate(t.args[0], environment) - 1)
        n = evaluate(t.args[0], environment)
        steps = 0 if n % 2 == 0 else (n + 1) // 2
        if steps > max_steps:
            raise RuntimeError("Iteration budget exceeded")
        if steps and 0 not in free_variables(t.args[1]):
            # A syntactically constant update has its value after one step.
            return evaluate(t.args[1], (0,) + environment)
        state = n
        for _ in range(steps):
            state = evaluate(t.args[1], (state,) + environment)
        return state

    evaluate.cache_info = cached_evaluate.cache_info
    return evaluate


def dag_json(terms):
    nodes, identifiers = [], {}

    def visit(t):
        if t in identifiers:
            return identifiers[t]
        args = list(t.args) if t.op == "v" else [visit(x) for x in t.args]
        i = len(nodes)
        identifiers[t] = i
        nodes.append([t.op, *args])
        return i

    roots = {name: visit(t) for name, t in terms.items()}
    return {"scope": "untrusted term compiler, not proof certificates",
            "primitive_operations": ["v", "z", "s", "p", "j"],
            "roots": roots, "nodes": nodes}


def run_tests(output_directory=None):
    import itertools
    import sys
    sys.setrecursionlimit(20000)
    evaluate = evaluator()
    checks = []
    unary = {
        "even_ceiling": (even_ceiling(V(0)), lambda n: n + n % 2),
        "odd_floor_plus_one": (odd_floor_plus_one(V(0)), lambda n: 2 * (n // 2) + 1),
        "half": (half(V(0)), lambda n: n // 2),
        "phase_clock": (phase_clock(V(0)), lambda n: 4 * (n // 2) + 3),
        "double": (double(V(0)), lambda n: 2 * n),
        "zero_marker": (zero_marker(V(0)), lambda n: 1 if n == 0 else 2 * n),
        "zero_test": (zero_test(V(0)), lambda n: int(n == 0)),
    }
    roots = {name: t for name, (t, _) in unary.items()}
    for name, (term, expected) in unary.items():
        validate(term, 1)
        for n in range(10):
            assert evaluate(term, (n,)) == expected(n), (name, n)
            checks.append(name)
    choices = {
        "even_data_choice": even_data_choice(V(0), V(1), V(2)),
        "odd_choice": odd_choice(V(0), V(1), V(2)),
        "zero_choice": zero_choice(V(0), V(1), V(2)),
    }
    roots.update(choices)
    for name, term in choices.items():
        validate(term, 3)
        for u, a, b in itertools.product(range(4), repeat=3):
            if name == "even_data_choice" and a % 2:
                continue
            condition = u == 0 if name == "zero_choice" else u % 2 == 1
            assert evaluate(term, (u, a, b)) == (a if condition else b), (name, u, a, b)
            checks.append(name)
    # The even-data restriction is essential, not an implicit total selector.
    bad = choices["even_data_choice"]
    assert evaluate(bad, (1, 1, 0)) != 1
    checks.append("negative_control_odd_data")
    iterations = {
        "successor": (S(V(0)), lambda z, p: z + 1),
        "predecessor": (P(V(0)), lambda z, p: max(0, z - 1)),
        "constant_parameter": (V(3), lambda z, p: p),
        "state_parity_choice": (odd_choice(V(0), V(3), S(V(0))),
                                lambda z, p: p if z % 2 else z + 1),
    }
    for name, (body, step) in iterations.items():
        term = iterate(V(0), V(1), body)
        roots["iteration_" + name] = term
        validate(term, 3)
        for n, a, p in itertools.product(range(3), repeat=3):
            expected = a
            for _ in range(n):
                expected = step(expected, p)
            assert evaluate(term, (n, a, p)) == expected, (name, n, a, p)
            checks.append("iteration_" + name)
    arithmetic = {
        "addition": (add(V(0), V(1)), lambda a, b: a + b),
        "subtraction": (subtract(V(0), V(1)), lambda a, b: max(0, a - b)),
        "multiplication": (multiply(V(0), V(1)), lambda a, b: a * b),
    }
    for name, (term, expected) in arithmetic.items():
        roots[name] = term
        validate(term, 2)
        for a, b in itertools.product(range(3), repeat=2):
            assert evaluate(term, (a, b)) == expected(a, b), (name, a, b)
            checks.append(name)
    # Check the ordinary PR-description front end on initial functions and
    # composition.  Fully expanding the general recursor via pair/scan
    # encodings is mathematically finite but grows extremely rapidly; it is
    # supplied as an untrusted algorithm and is NOT claimed to be covered by
    # these finite tests.  The initialized-iteration compiler itself is
    # exercised above with state-dependent and passive-parameter updates.
    description = ("comp", ("succ",), (("proj", 2, 1),))
    generic = compile_pr(description, (V(0), V(1)))
    generic_nodes = validate(generic, 2)
    roots["PR_composition_successor_second"] = generic
    generic_cases = []
    for args in ((0, 0), (0, 1), (1, 2)):
        got = evaluate(generic, args)
        assert got == args[1] + 1, ("PR composition", args, got)
        generic_cases.append({"arguments": list(args), "result": got})
        checks.append("PR_composition")
    result = {
        "status": "PASS",
        "scope": "finite standard-semantics term evaluations; no source theory or proof checker",
        "checks": len(checks),
        "counts": {name: checks.count(name) for name in sorted(set(checks))},
        "PR_composition_cases": generic_cases,
        "PR_composition_scope_nodes": generic_nodes,
        "general_PR_recursion_scope": "algorithm supplied; generic pair/scan expansion not included in finite regression suite",
        "cache": evaluate.cache_info()._asdict(),
    }
    if output_directory:
        destination = Path(output_directory)
        destination.mkdir(exist_ok=True, parents=True)
        (destination / "fusion_test_results.json").write_text(json.dumps(result, indent=2) + "\n")
        (destination / "primitive_terms.json").write_text(json.dumps(dag_json(roots), separators=(",", ":")) + "\n")
    return result


if __name__ == "__main__":
    print(json.dumps(run_tests(Path(__file__).parent), indent=2))
