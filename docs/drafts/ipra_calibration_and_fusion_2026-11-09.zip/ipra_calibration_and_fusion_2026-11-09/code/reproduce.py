"""Reproduce measurements and concrete evidence, not the universal metatheory.

All frozen Python sources are parsed and measured without executing them.
Only the three identified standalone Choice checkers and the explicitly
identified one-token refactoring are executed against preserved fixtures.
The fusion tests evaluate primitive terms under their stipulated semantics.
"""
import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import subprocess
import sys
import tokenize

ROOT = Path(__file__).resolve().parents[1]
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL,
           tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
           tokenize.ENDMARKER}


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node
    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(path):
    raw = path.read_bytes()
    tree = ast.fix_missing_locations(StripDocstrings().visit(ast.parse(raw)))
    normalized = ast.unparse(tree) + "\n"
    return {
        "sha256": hashlib.sha256(raw).hexdigest(),
        "normalized_tokens": sum(t.type not in IGNORED for t in
                                 tokenize.generate_tokens(io.StringIO(normalized).readline)),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "normalized_bytes": len(normalized.encode()),
        "raw_bytes": len(raw),
    }


def run_checker(path, packet, expected, name):
    result = subprocess.run([sys.executable, str(path)],
                            input=json.dumps(packet), text=True,
                            capture_output=True, timeout=20)
    accepted = result.returncode == 0 and result.stdout.strip() == "ACCEPT"
    rejected = result.returncode != 0 and result.stdout.strip() == "REJECT"
    if not ((expected and accepted) or (not expected and rejected)):
        raise AssertionError((path.name, name, expected, result.returncode,
                              result.stdout, result.stderr))


def main():
    source_map = json.loads((ROOT / "evidence/source_map.json").read_text())
    by_hash = {}
    for entry in source_map:
        sha = entry["sha256"]
        if sha not in by_hash:
            metric = measure(ROOT / entry["local_file"])
            if metric["sha256"] != sha:
                raise ValueError("Changed frozen source " + entry["local_file"])
            by_hash[sha] = metric
    comparison = ROOT / "reference/choice"
    winners = {name: measure(comparison / (name + ".py"))
               for name in ("tokens", "structure", "bytes")}
    keys = ("normalized_tokens", "ast_nodes", "normalized_bytes")
    envelope = {key: min(v[key] for v in winners.values()) for key in keys}
    expected = {"normalized_tokens": 299, "ast_nodes": 340,
                "normalized_bytes": 815}
    if envelope != expected:
        raise AssertionError(("Changed reference envelope", envelope))
    old_audit = json.loads((ROOT / "evidence/frontier_reproduction.json").read_text())
    classifications = {row["sha256"]: row for row in
        old_audit["smaller_sources_requiring_role_classification"]}
    smaller = [sha for sha, m in by_hash.items()
               if any(m[k] < envelope[k] for k in keys)]
    for sha in smaller:
        if classifications[sha]["classification"] != "not_complete_checker":
            raise AssertionError("Unclassified lower-coordinate source " + sha)
    programs = [comparison / (n + ".py") for n in winners]
    variant = ROOT / "code/experimental_298_tokens.py"
    programs.append(variant)
    positive = json.loads((comparison / "converted_inherited_certificates.json").read_text())["records"]
    focused = json.loads((comparison / "focused_certificates.json").read_text())["cases"]
    invalid_counter = json.loads((ROOT / "evidence/omitted_validation_counterexample.json").read_text())
    replay_count = 0
    for program in programs:
        for row in positive:
            run_checker(program, row["packet"], True, row["name"])
            replay_count += 1
        for row in focused:
            run_checker(program, row["packet"], row["accept"], row["name"])
            replay_count += 1
        run_checker(program, invalid_counter, False, "malformed_counter")
        replay_count += 1
    import fusion_terms
    fusion = fusion_terms.run_tests(ROOT / "evidence")
    receipt = {
        "status": "PASS",
        "python": platform.python_version(),
        "source_occurrences": len(source_map),
        "distinct_frozen_sources": len(by_hash),
        "whole_program_boundary": True,
        "reference_coordinate_envelope": envelope,
        "reference_programs": winners,
        "smaller_nonchecker_sources": len(smaller),
        "experimental_one_token_refactoring": measure(variant),
        "positive_packets_per_program": len(positive),
        "focused_packets_per_program": len(focused),
        "additional_invalid_counter_packets_per_program": 1,
        "program_count": len(programs),
        "cli_replays": replay_count,
        "fusion": fusion,
        "limits": [
            "No new smaller complete axiomatization is asserted.",
            "The experimental variant changes no mathematics and worsens AST/bytes.",
            "Finite checks do not formalize universal soundness or bi-interpretability.",
            "The fused constructor has stipulated semantics, not a new source axiom system.",
        ],
    }
    (ROOT / "evidence/reproduction_results.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
