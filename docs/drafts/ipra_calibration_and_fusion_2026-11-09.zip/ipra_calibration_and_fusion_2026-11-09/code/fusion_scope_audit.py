"""Independent finite binding checks for the untrusted fusion term compiler.

These check primitive-AST substitution, not a source arithmetic theory.
The evaluator below does not use the compiler's evaluator or free-variable
analysis. The universal claim still relies on structural induction.
"""
import importlib.util
import json
from pathlib import Path
import random
import sys

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('fusion_terms_audit', ROOT / 'code/fusion_terms.py')
F = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = F
SPEC.loader.exec_module(F)


def evaluate(term, environment):
    if term.op == 'v':
        return environment[term.args[0]]
    if term.op == 'z':
        return 0
    if term.op == 's':
        return evaluate(term.args[0], environment) + 1
    if term.op == 'p':
        return max(0, evaluate(term.args[0], environment) - 1)
    counter, body = term.args
    value = evaluate(counter, environment)
    count = (value + 1) // 2 if value % 2 else 0
    for _ in range(count):
        value = evaluate(body, (value,) + environment)
    return value


def main():
    rng = random.Random(20261109)

    def make(depth, arity):
        if depth == 0:
            return F.Z if rng.randrange(arity + 1) == arity else F.V(rng.randrange(arity))
        tag = rng.randrange(5)
        if tag == 0:
            return F.Z
        if tag == 1:
            return F.V(rng.randrange(arity))
        if tag == 2:
            return F.S(make(depth - 1, arity))
        if tag == 3:
            return F.P(make(depth - 1, arity))
        return F.J(make(depth - 1, arity), make(depth - 1, arity + 1))

    checks = 0
    terms = [make(4, 3) for _ in range(150)]
    replacements = [F.V(2), F.S(F.V(0)), F.J(F.V(1), F.S(F.V(0)))]
    for term in terms:
        F.validate(term, 3)
        for env in ((0, 1, 2), (2, 0, 1), (1, 2, 0)):
            shifted = F.shift(term)
            F.validate(shifted, 4)
            assert evaluate(shifted, (3,) + env) == evaluate(term, env)
            checks += 1
            for index, replacement in enumerate(replacements):
                substituted = F.replace(term, index, replacement)
                F.validate(substituted, 3)
                values = list(env)
                values[index] = evaluate(replacement, env)
                assert evaluate(substituted, env) == evaluate(term, tuple(values))
                checks += 1
    result = {'status': 'PASS', 'terms': len(terms), 'checks': checks,
              'scope': 'finite primitive-AST capture-avoidance checks with independent evaluator; not proof-checker verification'}
    (ROOT / 'evidence/fusion_scope_audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
