PRA FROM STATIONARY ZERO TESTS AND AN INVOLUTION
==============================================
Research report prepared for Vladimir Reshetnikov
31 October 2026

MAIN RESULT
-----------
In the ordinary effective language of finite primitive-recursive
descriptions, keep the defining equations and add:

  (Sep)  0 != 1, where 1=S(0).
  (Inv)  forall x,a, F(F(x,a),a)=x.
  (SZ)   For each finite term f(n,parameters), universally close:

         [forall n, f(Sn,parameters)=f(n,parameters)] ->
         [(forall n, f(n,parameters)=0) or Z(f(0,parameters))=0].

Z is the specific PR description Z(0)=1, Z(Sn)=0.
F is the specific PR description

  F(0,a)=a,
  F(Sn,a)=C(M(a,Sn),M(Sn,a),Sn),

where p(0)=0, p(Sn)=n, M(0,a)=a, M(Sn,a)=p(M(n,a)),
and C(0,u,v)=u, C(Sn,u,v)=v.

With classical logic this theory has exactly the same theorems as
classical first-order PRA. With intuitionistic logic it has exactly
the same theorems as intuitionistic first-order PRA. The domain,
equality, and all symbols are fixed by the interpretations, so both
bi-interpretations and their round trips are identities. Equiconsistency
follows. The paper also proves the alternative SZ+Sep+Min basis.

READ FIRST
----------
pra_stationary_zero.pdf     Complete 15-page report (page count may change
                           after a local rebuild with different fonts).
pra_stationary_zero.tex     Main source, including axioms and proofs.
sections/converse_arithmetic.tex
                           Full internal PRA verification of Inv and Min.

SUPPORTING ARTIFACTS
-------------------
formal/StationaryZero.lean  Checked constructive local kernel, Lean 4.19.0.
formal/README.txt          Exact scope and limitations of that certificate.
formal/check.log           Twelve empty axiom-dependency reports; exit 0.
formal/lean-version.txt    Compiler version used.
artifacts/schema_metrics.py / schema_metrics.json
                           Reproducible formula AST counts and program costs.
artifacts/check_constructions.py / construction_checks.json
                           Finite standard-model and concrete product checks.
artifacts/README_scope.txt Verification boundaries for executable checks.
audit/SOURCES.json         Pinned repository inventory and source digests.
audit/proof_review.txt     Proof review and verification summary.
audit/pdf_build_summary.txt
                           Final build and layout verification summary.
SHA256SUMS.txt             Integrity hashes for the archive's other files.

REPRODUCE
---------
From this directory:

  latexmk -pdf -interaction=nonstopmode -halt-on-error pra_stationary_zero.tex
  python3 artifacts/schema_metrics.py
  python3 artifacts/check_constructions.py
  lean formal/StationaryZero.lean

The LaTeX source uses standard TeX Live packages. The Python programs use
only the standard library. The Lean file imports only Init, not mathlib.
The compiled PDF is included, so rebuilding is optional.

WHAT IS AND IS NOT CLAIMED
-------------------------
The manuscript contains complete mathematical proofs. The Lean file checks
the local constructive core; it is not a formalization of first-order
syntax or of the full bi-interpretation theorem. Finite Python checks are
not proofs about nonstandard models or arbitrary schema instances.

The main arithmetic display has 39 nodes under the stated convention.
With the full-PR computation templates at one displayed parameter, the
total is 59. The inspected strict-binary flat-meet alternative totals 57;
the paper does not claim a global minimum. Helper descriptions, arities,
and the distinction between full PR and restricted binary grammar are
reported explicitly. A matched full-PR replacement retaining Min saves
two recurring-display nodes; the involution variant saves six arithmetic
display nodes relative to PC+Sep+Min.

SOURCE SNAPSHOT
---------------
VladimirReshetnikov/ProveIt
Commit: 3af028c8eb45b393331630537c5a94939c536341
Six current docs/drafts ZIPs inspected; docs/incoming inventory and full
README inspected. No repository files were changed by this research.
