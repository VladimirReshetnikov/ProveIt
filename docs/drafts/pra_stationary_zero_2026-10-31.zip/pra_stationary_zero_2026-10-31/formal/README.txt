SCOPE OF THE LEAN CERTIFICATE
=============================

File: StationaryZero.lean
Compiler: Lean 4.19.0; exact version in lean-version.txt.
Dependencies: Lean's Init only. No mathlib or external packages.
Reproduce: lean StationaryZero.lean

The final run exited successfully. check.log records all twelve requested
axiom-dependency reports. Every listed theorem reports that it does not
depend on any axioms. In particular the checked proof terms do not use
Classical.choice, propositional extensionality, or sorryAx. There are no
axiom declarations and no admitted proof obligations in the source.

WHAT IS CHECKED
---------------

The mathematical carrier is an arbitrary type A. There is no arithmetic
induction on A and it is not identified with Lean's natural numbers.

1. ZeroCore.zero_cover derives a=0 or Z(a)=0 from the single syntactic
   SZ instance for the constant-in-n term f(n,a)=a.
2. ZeroCore.zero_or_ne derives constructive decision of equality to zero.
3. The selector J(z,u,v)=C(Z(z),v,u) has its intended zero/nonzero laws.
4. ZeroCore.preserves_zero derives constancy at zero from one specified
   stationary-zero instance and a zero initial value.
5. ZeroCore.shifted_latch_stationary checks the local latch calculation
   q(SSn)=q(Sn), under an arbitrary fixed zero-test induction step.
6. ZeroCore.shifted_latch_zero_induction derives the induction conclusion
   for an arbitrary fixed error term e from the recurrence for its latch
   q and the one observer instance r(n)=Z(q(Sn)). This proof uses neither
   the involution nor an arbitrary native-equality decision principle.
7. FlipCore.equality_reflection derives F(x,a)=0 iff x=a from
   F(0,a)=a and F(F(x,a),a)=x.
8. FlipCore.equality_or_ne derives native equality decision.
9. FlipCore.native_constancy derives constancy of a fixed stationary term
   t using precisely the observer instance F(t(n),t(0)).
10. MinimumCore checks the alternative minimum-identity bridge: diagonal
    monus vanishing, equality reflection from two zero remainders, and
    the correctness of the single selector-based equality error term.

SCHEMA SCOPE
------------

StationaryZero(succ,zero,Z,f) is a proposition ABOUT ONE FIXED FUNCTION f.
The file does NOT postulate that SZ holds for every function A -> A.
Each local theorem takes only its required instance as a hypothesis:

* sz_constant is the universally closed first-order instance f(n,a)=a;
* sz_observer in the latch theorem is the instance Z(q(Sn));
* sz_observer in native_constancy is the instance F(t(n),t(0)).

The function parameters e, q, and t stand for interpretations of fixed
finite descriptions, with any numerical parameters held fixed. Abstract
universal quantification in the surrounding Lean theorem is not an
additional second-order axiom of the proposed arithmetic theory.

EXPLICIT LIMITATIONS
--------------------

This is a kernel-checked local mathematical certificate. It does not
formalize first-order proof syntax, the descriptor grammar, effective
term construction, or the final bi-interpretations. In particular:

* Computational equations for Z, C, F and q are explicit hypotheses.
* The bounded-reflection description F(0,a)=a and
  F(Sn,a)=C(M(a,Sn),M(Sn,a),Sn), and its involution law in ordinary
  PRA, are verified in the accompanying paper, not by this Lean file.
* Existence and admissibility of the latch q and its observer term are
  justified by the paper's primitive-recursion grammar.
* MinimumCore takes M(x,0)=0 as an explicit hypothesis. The paper derives
  it using zero-test induction and predecessor computation; that
  instantiation is not hidden in a Lean tactic.
* Formula-to-error compilation, the converse interpretation, identity
  round trips, and syntactic consistency translations are not encoded.

Thus the certificate supports the constructive bootstrap and the exact
local dependencies stated above; it is not a claim of a complete Lean
formalization of the equivalence with PRA.
