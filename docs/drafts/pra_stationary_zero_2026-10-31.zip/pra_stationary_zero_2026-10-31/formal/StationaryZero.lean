import Init

/-!
Constructive local certificate for the stationary-zero proposal.

The carrier is an arbitrary type A, not Lean's Nat.  No induction on A is
available.  StationaryZero is a proposition about ONE fixed function f.
Each theorem receives only the particular schema instance that its proof
uses.  There is no assumption that the first-order schema applies to all
set-theoretic functions.  Parameters of a fixed term may be held fixed
when applying these theorems.

This file checks the local bootstrap, equality reflection, and latch
arguments.  It does not formalize the syntax of primitive-recursive
descriptions, the admissibility of their instances, or the bi-interpretation.
-/

set_option autoImplicit false

namespace StationaryZeroCertificate

universe u

def Stationary {A : Type u} (succ : A → A) (f : A → A) : Prop :=
  ∀ n, f (succ n) = f n

def StationaryZero {A : Type u} (succ : A → A) (zero : A)
    (z : A → A) (f : A → A) : Prop :=
  Stationary succ f → (∀ n, f n = zero) ∨ z (f zero) = zero

/-- Computational data and the single constant-term SZ instance. -/
structure ZeroCore (A : Type u) where
  zero : A
  one : A
  succ : A → A
  z : A → A
  choose : A → A → A → A
  separate : zero ≠ one
  z_zero : z zero = one
  choose_zero : ∀ v w, choose zero v w = v
  choose_one : ∀ v w, choose one v w = w
  sz_constant : ∀ a, StationaryZero succ zero z (fun _ => a)

namespace ZeroCore

variable {A : Type u} (c : ZeroCore A)

theorem zero_cover (a : A) : a = c.zero ∨ c.z a = c.zero := by
  cases c.sz_constant a (fun _ => rfl) with
  | inl h => exact Or.inl (h c.zero)
  | inr h => exact Or.inr h

theorem z_zero_ne_zero : c.z c.zero ≠ c.zero := by
  intro h
  exact c.separate (h.symm.trans c.z_zero)

theorem zero_or_ne (a : A) : a = c.zero ∨ a ≠ c.zero := by
  cases c.zero_cover a with
  | inl h => exact Or.inl h
  | inr h =>
      apply Or.inr
      intro ha
      have hz : c.z c.zero = c.zero := by
        calc
          c.z c.zero = c.z a := congrArg c.z ha.symm
          _ = c.zero := h
      exact c.z_zero_ne_zero hz

theorem z_of_ne_zero (a : A) (ha : a ≠ c.zero) : c.z a = c.zero := by
  cases c.zero_cover a with
  | inl h => exact False.elim (ha h)
  | inr h => exact h

theorem z_one : c.z c.one = c.zero := by
  apply c.z_of_ne_zero
  intro h
  exact c.separate h.symm

/-- J(z,u,v) selects u at zero and v away from zero. -/
def gate (a v w : A) : A := c.choose (c.z a) w v

theorem gate_zero (v w : A) : c.gate c.zero v w = v := by
  unfold gate
  rw [c.z_zero, c.choose_one]

theorem gate_of_ne_zero (a v w : A) (ha : a ≠ c.zero) :
    c.gate a v w = w := by
  unfold gate
  rw [c.z_of_ne_zero a ha, c.choose_zero]

theorem gate_same (a v : A) : c.gate a v v = v := by
  cases c.zero_or_ne a with
  | inl h =>
      rw [h]
      exact c.gate_zero v v
  | inr h => exact c.gate_of_ne_zero a v v h

/-- One given SZ instance preserves a zero initial value. -/
theorem preserves_zero (f : A → A)
    (sz_f : StationaryZero c.succ c.zero c.z f)
    (stationary_f : Stationary c.succ f)
    (initial_zero : f c.zero = c.zero) :
    ∀ n, f n = c.zero := by
  cases sz_f stationary_f with
  | inl h => exact h
  | inr h =>
      have bad : c.z c.zero = c.zero := by
        calc
          c.z c.zero = c.z (f c.zero) := congrArg c.z initial_zero.symm
          _ = c.zero := h
      exact False.elim (c.z_zero_ne_zero bad)

/-- The shifted latch is stationary under a zero-test induction step. -/
theorem shifted_latch_stationary (e q : A → A)
    (q_step : ∀ n, q (c.succ n) = c.gate (e n) (q n) c.zero)
    (error_step : ∀ n, e n = c.zero → e (c.succ n) = c.zero) :
    Stationary c.succ (fun n => q (c.succ n)) := by
  intro n
  cases c.zero_or_ne (e n) with
  | inl h =>
      calc
        q (c.succ (c.succ n)) =
            c.gate (e (c.succ n)) (q (c.succ n)) c.zero := q_step (c.succ n)
        _ = c.gate c.zero (q (c.succ n)) c.zero := by rw [error_step n h]
        _ = q (c.succ n) := c.gate_zero (q (c.succ n)) c.zero
  | inr h =>
      have qn : q (c.succ n) = c.zero := by
        calc
          q (c.succ n) = c.gate (e n) (q n) c.zero := q_step n
          _ = c.zero := c.gate_of_ne_zero (e n) (q n) c.zero h
      calc
        q (c.succ (c.succ n)) =
            c.gate (e (c.succ n)) (q (c.succ n)) c.zero := q_step (c.succ n)
        _ = c.gate (e (c.succ n)) c.zero c.zero := by rw [qn]
        _ = c.zero := c.gate_same (e (c.succ n)) c.zero
        _ = q (c.succ n) := qn.symm

/--
Zero-test induction from just the zero core and one observer instance.
No involution, arbitrary equality test, or native term-constancy is used.
-/
theorem shifted_latch_zero_induction (e q : A → A)
    (q_zero : q c.zero = c.one)
    (q_step : ∀ n, q (c.succ n) = c.gate (e n) (q n) c.zero)
    (error_zero : e c.zero = c.zero)
    (error_step : ∀ n, e n = c.zero → e (c.succ n) = c.zero)
    (sz_observer : StationaryZero c.succ c.zero c.z
      (fun n => c.z (q (c.succ n)))) :
    ∀ n, e n = c.zero := by
  have q_one : q (c.succ c.zero) = c.one := by
    calc
      q (c.succ c.zero) = c.gate (e c.zero) (q c.zero) c.zero := q_step c.zero
      _ = c.gate c.zero c.one c.zero := by rw [error_zero, q_zero]
      _ = c.one := c.gate_zero c.one c.zero
  have stationary_q := c.shifted_latch_stationary e q q_step error_step
  have stationary_r : Stationary c.succ (fun n => c.z (q (c.succ n))) := by
    intro n
    exact congrArg c.z (stationary_q n)
  have r_zero : c.z (q (c.succ c.zero)) = c.zero := by
    calc
      c.z (q (c.succ c.zero)) = c.z c.one := congrArg c.z q_one
      _ = c.zero := c.z_one
  have all_r := c.preserves_zero (fun n => c.z (q (c.succ n)))
    sz_observer stationary_r r_zero
  intro n
  cases c.zero_or_ne (e n) with
  | inl h => exact h
  | inr h =>
      have qn : q (c.succ n) = c.zero := by
        calc
          q (c.succ n) = c.gate (e n) (q n) c.zero := q_step n
          _ = c.zero := c.gate_of_ne_zero (e n) (q n) c.zero h
      have bad : c.z c.zero = c.zero := by
        calc
          c.z c.zero = c.z (q (c.succ n)) := congrArg c.z qn.symm
          _ = c.zero := all_r n
      exact False.elim (c.z_zero_ne_zero bad)

end ZeroCore

/-- An explicitly specified operation, not a universally quantified evaluator. -/
structure FlipCore (A : Type u) extends ZeroCore A where
  flip : A → A → A
  flip_zero : ∀ a, flip zero a = a
  flip_involutive : ∀ x a, flip (flip x a) a = x

namespace FlipCore

variable {A : Type u} (c : FlipCore A)

theorem flip_diagonal (a : A) : c.flip a a = c.zero := by
  have h := c.flip_involutive c.zero a
  rw [c.flip_zero] at h
  exact h

theorem equality_reflection (x a : A) : c.flip x a = c.zero ↔ x = a := by
  constructor
  · intro h
    calc
      x = c.flip (c.flip x a) a := (c.flip_involutive x a).symm
      _ = c.flip c.zero a := congrArg (fun v => c.flip v a) h
      _ = a := c.flip_zero a
  · intro h
    rw [h]
    exact c.flip_diagonal a

include c in
theorem equality_or_ne (x a : A) : x = a ∨ x ≠ a := by
  cases c.toZeroCore.zero_or_ne (c.flip x a) with
  | inl h => exact Or.inl ((c.equality_reflection x a).mp h)
  | inr h =>
      apply Or.inr
      intro hxa
      exact h ((c.equality_reflection x a).mpr hxa)

/-- Native constancy for one fixed term, using just its observer SZ instance. -/
theorem native_constancy (t : A → A)
    (stationary_t : Stationary c.succ t)
    (sz_observer : StationaryZero c.succ c.zero c.z
      (fun n => c.flip (t n) (t c.zero))) :
    ∀ n, t n = t c.zero := by
  have stationary_observer : Stationary c.succ
      (fun n => c.flip (t n) (t c.zero)) := by
    intro n
    exact congrArg (fun v => c.flip v (t c.zero)) (stationary_t n)
  have all_zero := c.toZeroCore.preserves_zero
    (fun n => c.flip (t n) (t c.zero)) sz_observer stationary_observer
    (c.flip_diagonal (t c.zero))
  intro n
  exact (c.equality_reflection (t n) (t c.zero)).mp (all_zero n)

end FlipCore

/--
Alternative minimum-identity bridge.  The right-zero law is an explicit
input: in the paper it is derived by the already checked zero-test
induction argument, using predecessor computation.
-/
structure MinimumCore (A : Type u) extends ZeroCore A where
  monus : A → A → A
  monus_zero : ∀ a, monus zero a = a
  monus_right_zero : ∀ x, monus x zero = zero
  minimum_symmetry : ∀ x y,
    monus (monus x y) y = monus (monus y x) x

namespace MinimumCore

variable {A : Type u} (c : MinimumCore A)

theorem monus_diagonal (x : A) : c.monus x x = c.zero := by
  have h := c.minimum_symmetry x c.zero
  rw [c.monus_right_zero, c.monus_zero] at h
  exact h.symm

theorem equality_reflection (x y : A) :
    (c.monus x y = c.zero ∧ c.monus y x = c.zero) ↔ x = y := by
  constructor
  · intro h
    have hm := c.minimum_symmetry x y
    rw [h.1, h.2, c.monus_zero, c.monus_zero] at hm
    exact hm.symm
  · intro h
    rw [h]
    exact And.intro (c.monus_diagonal y) (c.monus_diagonal y)

def error (x y : A) : A :=
  c.toZeroCore.gate (c.monus x y) (c.monus y x) c.one

theorem error_reflection (x y : A) : c.error x y = c.zero ↔ x = y := by
  constructor
  · intro h
    cases c.toZeroCore.zero_or_ne (c.monus x y) with
    | inl hxy =>
        have hyx : c.monus y x = c.zero := by
          calc
            c.monus y x = c.toZeroCore.gate c.zero (c.monus y x) c.one :=
              (c.toZeroCore.gate_zero (c.monus y x) c.one).symm
            _ = c.error x y := by unfold error; rw [hxy]
            _ = c.zero := h
        exact (c.equality_reflection x y).mp (And.intro hxy hyx)
    | inr hxy =>
        have he : c.error x y = c.one :=
          c.toZeroCore.gate_of_ne_zero (c.monus x y) (c.monus y x) c.one hxy
        exact False.elim (c.separate (h.symm.trans he))
  · intro h
    unfold error
    rw [h, c.monus_diagonal]
    exact c.toZeroCore.gate_zero c.zero c.one

end MinimumCore

#print axioms ZeroCore.zero_cover
#print axioms ZeroCore.zero_or_ne
#print axioms ZeroCore.gate_same
#print axioms ZeroCore.preserves_zero
#print axioms ZeroCore.shifted_latch_stationary
#print axioms ZeroCore.shifted_latch_zero_induction
#print axioms FlipCore.equality_reflection
#print axioms FlipCore.equality_or_ne
#print axioms FlipCore.native_constancy
#print axioms MinimumCore.monus_diagonal
#print axioms MinimumCore.equality_reflection
#print axioms MinimumCore.error_reflection

end StationaryZeroCertificate
