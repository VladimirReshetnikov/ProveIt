#!/usr/bin/env python3
"""Finite transcription and construction checks for the accompanying proof.

This program does NOT verify a first-order proof, induction over arbitrary
models, consistency, or bi-interpretability.  It evaluates the explicitly
specified PR programs on standard natural numbers, checks a separately
implemented formula compiler, and exhibits the concrete product witness
explained in the paper.  All randomness has a fixed seed.
"""

from __future__ import annotations

import itertools
import json
import random
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Callable


def primitive_recursion(base: Callable, step: Callable, n: int, *parameters: int) -> int:
    assert isinstance(n, int) and n >= 0
    value = base(*parameters)
    for k in range(n):
        value = step(k, value, *parameters)
    return value


@lru_cache(maxsize=None)
def p(n: int) -> int:
    return primitive_recursion(lambda: 0, lambda k, previous: k, n)


@lru_cache(maxsize=None)
def A(n: int, a: int) -> int:
    return primitive_recursion(lambda a: a, lambda k, previous, a: previous + 1, n, a)


@lru_cache(maxsize=None)
def M(n: int, a: int) -> int:
    # Counter is the FIRST argument: M(n,a) is max(a-n,0).
    return primitive_recursion(lambda a: a, lambda k, previous, a: p(previous), n, a)


@lru_cache(maxsize=None)
def C(n: int, u: int, v: int) -> int:
    return primitive_recursion(lambda u, v: u, lambda k, previous, u, v: v, n, u, v)


@lru_cache(maxsize=None)
def Z(n: int) -> int:
    return primitive_recursion(lambda: 1, lambda k, previous: 0, n)


@lru_cache(maxsize=None)
def F(n: int, a: int) -> int:
    # The step ignores the previous output, but remains an ordinary legal
    # primitive-recursion description with the frozen parameter a.
    return primitive_recursion(
        lambda a: a,
        lambda k, previous, a: C(M(a, k + 1), M(k + 1, a), k + 1),
        n,
        a,
    )


def select_zero(z: int, u: int, v: int) -> int:
    # Only C at the globally known bit Z(z) is needed in the weak theory.
    return C(Z(z), v, u)


@dataclass(frozen=True)
class Term:
    tag: str
    children: tuple["Term", ...] = ()

    def evaluate(self, environment: dict[str, int]) -> int:
        if self.tag in environment:
            return environment[self.tag]
        if self.tag == "0":
            return 0
        values = [child.evaluate(environment) for child in self.children]
        operations = {"S": lambda n: n + 1, "p": p, "A": A, "M": M,
                      "C": C, "Z": Z, "F": F}
        return operations[self.tag](*values)

    def display(self) -> str:
        if not self.children:
            return self.tag
        return self.tag + "(" + ",".join(c.display() for c in self.children) + ")"


def term(tag: str, *children: Term) -> Term:
    return Term(tag, children)


ZERO = term("0")
ONE = term("S", ZERO)


@dataclass(frozen=True)
class Formula:
    tag: str
    children: tuple[object, ...] = ()

    def evaluate(self, environment: dict[str, int]) -> bool:
        """Independent ordinary truth evaluation over standard integers."""
        if self.tag == "eq":
            left, right = self.children
            return left.evaluate(environment) == right.evaluate(environment)
        if self.tag == "top":
            return True
        if self.tag == "bottom":
            return False
        if self.tag == "not":
            return not self.children[0].evaluate(environment)
        left, right = (child.evaluate(environment) for child in self.children)
        if self.tag == "and":
            return left and right
        if self.tag == "or":
            return left or right
        if self.tag == "implies":
            return (not left) or right
        raise ValueError(self.tag)

    def display(self) -> str:
        if not self.children:
            return self.tag
        return self.tag + "(" + ",".join(c.display() for c in self.children) + ")"


def formula(tag: str, *children: object) -> Formula:
    return Formula(tag, children)


def truth_bit(source: Formula, equality_implementation: str = "reflection") -> Term:
    """Compile to an arithmetic term, never to Python equality tests.

    Both variants are useful: one uses the bounded reflection F; the other
    uses the two monus tests from the Min presentation.
    """
    if source.tag == "eq":
        left, right = source.children
        if equality_implementation == "reflection":
            error = term("F", left, right)
        elif equality_implementation == "minimum":
            error = term("C", term("M", left, right), term("M", right, left), ONE)
        else:
            raise ValueError(equality_implementation)
        return term("Z", error)
    if source.tag == "top":
        return ONE
    if source.tag == "bottom":
        return ZERO
    if source.tag == "not":
        return term("Z", truth_bit(source.children[0], equality_implementation))
    left, right = (truth_bit(child, equality_implementation) for child in source.children)
    if source.tag == "and":
        return term("C", left, ZERO, right)
    if source.tag == "or":
        return term("C", left, right, ONE)
    if source.tag == "implies":
        return term("C", left, ONE, right)
    raise ValueError(source.tag)


def error_term(source: Formula, equality_implementation: str = "reflection") -> Term:
    """Compile the paper's exact table, with truth represented by zero.

    J(z,u,v) is expanded literally as C(Z(z),v,u).  This keeps the
    construction distinct from negating a previously compiled truth bit.
    """
    def J(z: Term, u: Term, v: Term) -> Term:
        return term("C", term("Z", z), v, u)

    if source.tag == "eq":
        left, right = source.children
        if equality_implementation == "reflection":
            return term("F", left, right)
        if equality_implementation == "minimum":
            return J(term("M", left, right), term("M", right, left), ONE)
        raise ValueError(equality_implementation)
    if source.tag == "top":
        return ZERO
    if source.tag == "bottom":
        return ONE
    if source.tag == "not":
        return J(error_term(source.children[0], equality_implementation), ONE, ZERO)
    left, right = (error_term(child, equality_implementation) for child in source.children)
    if source.tag == "and":
        return J(left, right, ONE)
    if source.tag == "or":
        return J(left, ZERO, right)
    if source.tag == "implies":
        return J(left, right, ZERO)
    raise ValueError(source.tag)


def random_term(generator: random.Random, depth: int) -> Term:
    if depth == 0 or generator.random() < 0.30:
        return generator.choice([ZERO, ONE, term("n"), term("a"), term("b")])
    operation = generator.choice(["S", "p", "A", "M", "Z", "F", "C"])
    arity = {"S": 1, "p": 1, "A": 2, "M": 2, "Z": 1, "F": 2, "C": 3}[operation]
    return term(operation, *(random_term(generator, depth - 1) for _ in range(arity)))


def random_formula(generator: random.Random, depth: int) -> Formula:
    if depth == 0 or generator.random() < 0.35:
        if generator.random() < 0.10:
            return formula(generator.choice(["top", "bottom"]))
        return formula("eq", random_term(generator, 2), random_term(generator, 2))
    operation = generator.choice(["not", "and", "or", "implies"])
    arity = 1 if operation == "not" else 2
    return formula(operation, *(random_formula(generator, depth - 1) for _ in range(arity)))


def latch(bits: tuple[int, ...]) -> list[int]:
    values = [1]
    for bit in bits:
        values.append(C(bit, 0, values[-1]))
    return values


def coordinatewise(function: Callable, *arguments: tuple[int, int]) -> tuple[int, int]:
    return (function(*(a[0] for a in arguments)), function(*(a[1] for a in arguments)))


def main() -> None:
    assertions: dict[str, int] = {}

    def check(category: str, claim: bool) -> None:
        assertions[category] = assertions.get(category, 0) + 1
        if not claim:
            raise AssertionError(f"Failed {category} check #{assertions[category]}")

    bound = 80
    for n in range(bound + 1):
        check("primitive_definitions", p(n) == max(n - 1, 0))
        check("primitive_definitions", Z(n) == int(n == 0))
        for a in range(bound + 1):
            check("primitive_definitions", M(n, a) == max(a - n, 0))
            check("primitive_definitions", A(n, a) == n + a)
            check("reflection_program", F(n, a) == (a - n if n <= a else n))
            check("reflection_program", F(F(n, a), a) == n)
            check("native_equality_reflection", (F(n, a) == 0) == (n == a))
            check("minimum_bridge", M(M(n, a), a) == M(M(a, n), n))
            check("minimum_bridge", (M(n, a) == 0 and M(a, n) == 0) == (n == a))
            check("zero_and_selector", (n == 0) or (Z(n) == 0))
            check("zero_and_selector", select_zero(n, a, a + 3) == (a if n == 0 else a + 3))
    for a in range(bound + 1):
        check("reflection_program", F(0, a) == a)
        check("reflection_program", F(a, a) == 0)

    generator = random.Random(20261031)
    formula_count = 600
    environments_per_formula = 12
    samples = []
    for index in range(formula_count):
        source = random_formula(generator, 3)
        compiled_f = truth_bit(source, "reflection")
        compiled_m = truth_bit(source, "minimum")
        error_f = error_term(source, "reflection")
        error_m = error_term(source, "minimum")
        for _ in range(environments_per_formula):
            environment = {name: generator.randrange(12) for name in ("n", "a", "b")}
            expected = int(source.evaluate(environment))
            check("formula_compiler_reflection", compiled_f.evaluate(environment) == expected)
            check("formula_compiler_minimum", compiled_m.evaluate(environment) == expected)
            check("error_compiler_reflection", (error_f.evaluate(environment) == 0) == bool(expected))
            check("error_compiler_minimum", (error_m.evaluate(environment) == 0) == bool(expected))
        if index < 4:
            samples.append({"formula": source.display(), "reflection_bit": compiled_f.display(),
                            "minimum_bit": compiled_m.display(),
                            "reflection_error": error_f.display(), "minimum_error": error_m.display()})

    # Exhaustive short sequences exercise failures as well as successful
    # induction hypotheses, and expose the reason for the observer q(Sn).
    sequence_count = 0
    progressing_count = 0
    for length in range(1, 11):
        for bits in itertools.product((0, 1), repeat=length):
            sequence_count += 1
            values = latch(bits)
            running = 1
            for i, bit in enumerate(bits):
                running *= bit
                check("latch_all_sequences", values[i + 1] == running)
                check("latch_current_test", values[i + 1] != 1 or bit == 1)
            progress = all((not bits[i]) or bits[i + 1] for i in range(length - 1))
            if progress:
                progressing_count += 1
                shifted = values[1:]
                check("latch_progression", len(set(shifted)) == 1)
                if bits[0] == 1:
                    check("latch_base_and_progression", all(value == 1 for value in shifted))
                    observed_zeros = [Z(value) for value in shifted]
                    check("SZ_zero_induction_observer", all(value == 0 for value in observed_zeros))
    check("off_by_one_witness", latch((0,))[0] == 1 and latch((0,))[1] == 0)

    # Test the literal finite-window SZ conclusion, without pretending that
    # a finite window verifies the universal axiom schema.
    stationary_sequences = 0
    for length in range(1, 7):
        for values in itertools.product(range(3), repeat=length):
            if len(set(values)) == 1:
                stationary_sequences += 1
                uniform = all(value == 0 for value in values) or Z(values[0]) == 0
                pointwise = all(value == 0 or Z(values[0]) == 0 for value in values)
                check("finite_SZ_instances", uniform and pointwise)

    # Infinite-product witness: all functions are interpreted coordinatewise
    # on N^2, and equality is literal pair equality.  The finite loops below
    # evaluate selected identities IN that infinite structure; they are not
    # a finite-domain model search and do not truncate successor.
    product_zero = (0, 0)
    mixed = (0, 1)
    product_one = (1, 1)
    product_z = coordinatewise(Z, mixed)
    product_p = coordinatewise(p, mixed)
    successor_pred = (product_p[0] + 1, product_p[1] + 1)
    check("product_counterexample", product_zero != product_one)
    check("product_counterexample", mixed != product_zero)
    check("product_counterexample", product_z != product_zero)
    check("product_counterexample", successor_pred != mixed)
    check("product_counterexample", not (mixed == product_zero or product_z == product_zero))
    product_points = list(itertools.product(range(5), repeat=2))
    for left in product_points:
        for right in product_points:
            reflected = coordinatewise(F, left, right)
            check("product_Inv_instances", coordinatewise(F, reflected, right) == left)
            min_left = coordinatewise(M, coordinatewise(M, left, right), right)
            min_right = coordinatewise(M, coordinatewise(M, right, left), left)
            check("product_Min_instances", min_left == min_right)
    # Constant trajectories are enough to refute SZ at the mixed parameter.
    constant_values = [mixed for _ in range(7)]
    check("product_counterexample", len(set(constant_values)) == 1)
    check("product_counterexample", all(value == constant_values[0] for value in constant_values))
    zero_constancy_implication = (constant_values[0] != product_zero) or all(
        value == product_zero for value in constant_values
    )
    check("product_counterexample", zero_constancy_implication)

    result = {
        "status": "PASS",
        "scope": "Finite standard-model checks and concrete witnesses, not a proof certificate for PRA equivalence.",
        "assertions_by_category": assertions,
        "total_assertions": sum(assertions.values()),
        "standard_grid": {"inclusive_bound": bound, "ordered_pairs": (bound + 1) ** 2},
        "programs": {
            "p": "p(0)=0; p(Sk)=k",
            "A": "A(0,a)=a; A(Sk,a)=S A(k,a)",
            "M": "M(0,a)=a; M(Sk,a)=p(M(k,a))",
            "C": "C(0,u,v)=u; C(Sk,u,v)=v",
            "Z": "Z(0)=1; Z(Sk)=0",
            "F": "F(0,a)=a; F(Sk,a)=C(M(a,Sk),M(Sk,a),Sk)",
            "F_standard_description": "Reflect [0,a] by x -> a-x and fix x>a.",
        },
        "formula_compiler": {
            "seed": 20261031,
            "random_formulas": formula_count,
            "environments_per_formula": environments_per_formula,
            "truth_bit_compilers": {
                "truth_convention": "The result is 1 exactly when the formula is true, and 0 otherwise.",
                "equality_implementations": ["Z(F(s,t))", "Z(C(M(s,t),M(t,s),1))"],
                "checks": 2 * formula_count * environments_per_formula,
            },
            "paper_error_compilers": {
                "truth_convention": "The result is zero exactly when the formula is true; a false formula need not have error 1.",
                "J_definition": "J(z,u,v)=C(Z(z),v,u)",
                "atomic_equality_implementations": ["F(s,t)", "J(M(s,t),M(t,s),1)"],
                "table": {"top": "0", "bottom": "1", "not A": "J(eA,1,0)",
                          "A and B": "J(eA,eB,1)", "A or B": "J(eA,0,eB)",
                          "A implies B": "J(eA,eB,0)"},
                "checks": 2 * formula_count * environments_per_formula,
            },
            "examples": samples,
            "interpretation_limit": "Boolean evaluations of decidable standard arithmetic formulas do not verify intuitionistic derivations in arbitrary models.",
        },
        "latch": {"all_bit_sequences_through_length": 10,
                  "sequences_checked": sequence_count,
                  "sequences_with_progression": progressing_count,
                  "finite_stationary_sequences": stationary_sequences,
                  "off_by_one_witness": {"input_bit": 0, "q_at_zero": 1, "q_at_one": 0}},
        "product_countermodel_witness": {
            "carrier": "N x N (infinite)",
            "interpretation": "Every described function is evaluated coordinatewise; equality is literal pair equality.",
            "zero": product_zero,
            "one": product_one,
            "parameter_a": mixed,
            "Z_of_a": product_z,
            "S_p_of_a": successor_pred,
            "f": "f(n,a)=a",
            "SZ_premise": True,
            "SZ_uniform_conclusion": False,
            "PRA_constructor_coverage_at_a": False,
            "ordinary_constancy_at_this_witness": True,
            "zero_constancy_implication_at_this_witness": True,
            "general_argument_in_scope_file": "D, Sep, Inv, Min, and every ordinary constancy instance hold on this product; constructor coverage and SZ fail. The explanation for all constancy instances is mathematical, not established by these loops.",
        },
        "claims_not_checked": ["soundness/completeness of a first-order calculus", "all instances of a schema",
                               "arbitrary or nonstandard models", "equiconsistency", "bi-interpretability",
                               "global minimality of an axiomatization"],
    }
    output = Path(__file__).with_name("construction_checks.json")
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "output": str(output),
                      "assertions": result["total_assertions"], "grid_bound": bound,
                      "truth_bit_formula_checks": 2 * formula_count * environments_per_formula,
                      "paper_error_formula_checks": 2 * formula_count * environments_per_formula,
                      "bit_sequences": sequence_count}, indent=2))


if __name__ == "__main__":
    main()
