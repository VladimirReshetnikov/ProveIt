SUPPORTING ARTIFACTS: SCOPE AND REPRODUCTION
==========================================

Requirements: Python 3.10 or later, standard library only.

Run from any working directory:

  python3 /absolute/path/to/artifacts/schema_metrics.py
  python3 /absolute/path/to/artifacts/check_constructions.py

Each program writes its JSON report beside itself and prints a short result.
The scripts do not access the network, install packages, or modify source files.

schema_metrics.py
-----------------
Reconstructs exact abstract syntax trees for the proposed SZ schema, its
pointwise spelling, separation, the bounded-reflection identity, and the
comparison displays from all six inspected archives.  Negation is expanded
to implication and falsehood, and 1 is expanded to S(0).  Bound variable
names label quantifier nodes; they do not count as separate children.

The full primitive-recursion grammar is kept distinct from the older binary
iterator grammar.  At one frozen parameter its two computation templates
have 7 and 13 nodes, totalling 20; the binary templates have 6 and 12,
totalling 18.  For m frozen parameters, the full-PR sum is 13+7m.

The new arithmetic total is 24+6+9=39.  With the full-PR computation display
it is 59.  The existing strict-binary flat-meet presentation has total 57,
and the generic delayed uniqueness benchmark has a still smaller display
before its separately discussed program transform.  No shortestness record
or encoding-independent minimum is claimed.

SZ + Sep + Min has 24+6+13=43 arithmetic nodes, against 26+6+13=45 for
PC + Sep + Min when both are written in the same full-PR language with a
genuine unary Z description.  If Z(t) is instead expanded as I_zero(t,S0),
SZ costs 26; this is why the report does not claim a new strict-binary result.

The fixed programs are not concealed behind their names: their base and
step bodies, arities, parameters, and body sizes are reported.  The bounded
reflection program F has a one-node base and an eleven-node step.  Including
p, M, C and Z gives 22 supporting body nodes.  These figures do not include
name encodings, declaration syntax, all binders, or the effective grammar;
adding them to display sizes is not a canonical description-length measure.

check_constructions.py
----------------------
Executes p, addition, monus M, selector C, zero indicator Z, and bounded
reflection F through their stated ordinary primitive-recursion definitions.
It checks their standard values and the reflection and minimum identities
on an 81 by 81 grid.  F reflects the interval [0,a] and fixes every x>a.

A separate formula AST is evaluated by ordinary Python truth semantics and
also compiled to arithmetic terms in four ways.  Two truth-bit compilers use
either Z(F(s,t)) or the minimum/monus-based equality bit.  Two independently
constructed error-term compilers use the paper's exact table, with zero
meaning true: atomic F(s,t), or J(M(s,t),M(t,s),1); falsehood 1; truth 0;
conjunction J(eA,eB,1); disjunction J(eA,0,eB); implication J(eA,eB,0);
and negation J(eA,1,0).  Here J(z,u,v) is expanded as C(Z(z),v,u).
False formulas can have errors larger than 1, so error checks test precisely
whether the result is zero, rather than assuming Boolean range.

Six hundred deterministically generated formulas, each in twelve environments,
exercise equality, falsehood, truth, negation, conjunction, disjunction and
implication.  There are 14,400 truth-bit evaluations and 14,400 error-term
evaluations.  These checks do not verify an intuitionistic derivation.  The
written proof supplies the constructive case splits using internally decidable
zero tests.  The final report contains 126,403 assertions in total.

All 2,046 nonempty bit sequences through length ten are checked against the
running latch.  This includes non-inductive sequences, not just successes.
It verifies that q(n+1), rather than q(n), has incorporated the current
truth bit.  Its explicit failure witness has q(0)=1 but the current bit 0;
q(1)=0 correctly records that failed test.

PRODUCT OBSTRUCTION: MATHEMATICAL ARGUMENT AND FINITE WITNESS
-----------------------------------------------------------
Consider the infinite structure N x N with all described PR functions
interpreted coordinatewise and literal pair equality.  Every computation
equation holds coordinatewise.  Sep holds because (0,0)!=(1,1).  Inv and
Min are equations true in each coordinate, so they hold in the product.

Every ordinary constancy instance also holds.  Fix a tuple of pair parameters.
A term t((i,j),parameters) has components t_1(i) and t_2(j).  If the product
premise t(Sn)=t(n) holds for every pair n, then t_1(i+1)=t_1(i) for every i
and t_2(j+1)=t_2(j) for every j.  Ordinary external induction on the standard
coordinates yields t_1(i)=t_1(0), t_2(j)=t_2(0).  Thus t is constant.  In
particular the weaker conditional zero-constancy principle holds as well.

Nevertheless, take a=(0,1) and the stationary term f(n,a)=a.  Neither a=0
nor Z(a)=0 holds, since the two relevant values are (0,1) and (1,0).
The SZ conclusion is false.  Also a is neither 0 nor S(p(a))=(1,1), whereas
PRA proves that constructor-coverage disjunction.  Consequently replacing
SZ by ordinary constancy, or by only conditional zero constancy, does not
give the claimed same-domain theory even when Inv or Min is retained.

The program displays this witness and checks finitely many product Inv and
Min instances.  It does NOT turn a finite grid into a closed arithmetic
model.  The all-instance argument above is the reason the infinite product
satisfies the indicated weakened theories.

LIMITS
------
Neither script is a proof assistant.  They do not prove consistency,
bi-interpretability, the first-order completeness theorem in the report,
claims about nonstandard models, or global minimality.  They are reproducible
checks against definition, compiler, index-shift and size-accounting errors.
