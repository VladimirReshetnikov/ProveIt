#!/usr/bin/env python3
"""Reproduce displayed-template sizes; these are not encoding lower bounds.

Run with Python 3, without third-party packages.  The full-PR and binary
computation grammars are deliberately kept separate.  Every comparison
formula is reconstructed below; no previous JSON count is trusted as input.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Node:
    tag: str
    children: tuple["Node", ...] = ()

    def count(self) -> int:
        return 1 + sum(child.count() for child in self.children)

    def equalities(self) -> int:
        return (self.tag == "=") + sum(c.equalities() for c in self.children)

    def display(self) -> str:
        if not self.children:
            return self.tag
        return self.tag + "(" + ",".join(c.display() for c in self.children) + ")"


def node(tag: str, *children: Node) -> Node:
    return Node(tag, children)


def app(name: str, *args: Node) -> Node:
    return node(name, *args)


def eq(left: Node, right: Node) -> Node:
    return node("=", left, right)


def implies(left: Node, right: Node) -> Node:
    return node("implies", left, right)


def neg(formula: Node) -> Node:
    return implies(formula, node("false"))


def both(left: Node, right: Node) -> Node:
    return node("and", left, right)


def either(left: Node, right: Node) -> Node:
    return node("or", left, right)


def forall(names: tuple[str, ...], formula: Node) -> Node:
    for name in reversed(names):
        formula = node("forall " + name, formula)
    return formula


zero, n, a, x, y, k, state, u, w = (
    node(name) for name in ("0", "n", "a", "x", "y", "k", "v", "u", "w")
)


def successor(term: Node) -> Node:
    return app("S", term)


one = successor(zero)


def f(term: Node) -> Node:
    return app("$f", term, a)


def g(term: Node) -> Node:
    return app("$g", term, a)


def p_binary(term: Node) -> Node:
    """The older binary papers expand predecessor to I_counter(term,0)."""
    return app("I_counter", term, zero)


def m(left: Node, right: Node) -> Node:
    return app("M", left, right)


def add(left: Node, right: Node) -> Node:
    return app("A", left, right)


def zero_test(term: Node) -> Node:
    # A genuine unary PR description in the proposed full-PR language.
    return app("Z", term)


def reflection(left: Node, right: Node) -> Node:
    return app("F", left, right)


def computation_full(parameter_count: int) -> tuple[Node, Node]:
    names = tuple(f"a{i + 1}" for i in range(parameter_count))
    params = tuple(node(name) for name in names)
    base = forall(names, eq(app("R_g_h", zero, *params), app("$g", *params)))
    step = forall(
        ("n",) + names,
        eq(
            app("R_g_h", successor(n), *params),
            app("$h", n, app("R_g_h", n, *params), *params),
        ),
    )
    return base, step


def build_formulas() -> dict[str, Node]:
    stationary = forall(("n",), eq(f(successor(n)), f(n)))
    positive_stationary = forall(
        ("n",), eq(f(successor(successor(n))), f(successor(n)))
    )
    separation = neg(eq(zero, one))
    constancy = forall(
        ("a",), implies(stationary, forall(("n",), eq(f(n), f(zero))))
    )
    sz = forall(
        ("a",),
        implies(
            stationary,
            either(forall(("n",), eq(f(n), zero)), eq(zero_test(f(zero)), zero)),
        ),
    )
    sz_pointwise = forall(
        ("a",),
        implies(
            stationary,
            forall(("n",), either(eq(f(n), zero), eq(zero_test(f(zero)), zero))),
        ),
    )
    sz_binary_spelling = forall(
        ("a",),
        implies(
            stationary,
            either(
                forall(("n",), eq(f(n), zero)),
                eq(app("I_zero", f(zero), one), zero),
            ),
        ),
    )
    pc = forall(
        ("a",),
        implies(
            positive_stationary,
            forall(("n",), either(eq(n, zero), eq(f(n), f(one)))),
        ),
    )
    inv = forall(("x", "y"), eq(reflection(reflection(x, y), y), x))
    minimum = forall(("x", "y"), eq(m(m(x, y), y), m(m(y, x), x)))
    shift = forall(("n", "a"), eq(m(successor(n), successor(a)), m(n, a)))
    retract = forall(("n", "a"), eq(m(n, add(n, a)), a))
    pi = forall(
        ("a",),
        implies(
            forall(
                ("n",),
                implies(
                    either(eq(n, zero), eq(f(n), g(n))),
                    eq(f(successor(n)), g(successor(n))),
                ),
            ),
            forall(("n",), either(eq(n, zero), eq(f(n), g(n)))),
        ),
    )
    ss = forall(
        ("a",),
        implies(stationary, forall(("n",), neg(eq(successor(f(n)), f(zero))))),
    )
    equality_bit = forall(
        ("x", "y"),
        both(
            eq(app("e", x, x), one),
            either(eq(app("e", x, y), zero), eq(x, y)),
        ),
    )
    flat = forall(
        ("x", "y"),
        both(
            eq(app("flat", x, x), x),
            either(eq(app("flat", x, y), zero), eq(x, y)),
        ),
    )
    rho = lambda term: app("$rho", term)
    au = forall(
        ("a",),
        implies(
            forall(("n",), eq(f(successor(n)), rho(f(n)))),
            both(
                separation,
                forall(
                    ("n",),
                    either(eq(n, zero), eq(f(n), app("I_rho", p_binary(n), f(one)))),
                ),
            ),
        ),
    )
    du = forall(
        ("a",),
        implies(
            forall(("n",), eq(f(successor(n)), rho(f(n)))),
            both(
                separation,
                forall(
                    ("n",),
                    either(eq(n, zero), eq(f(n), rho(app("D_rho", n, f(zero))))),
                ),
            ),
        ),
    )
    successor_uniqueness = forall(
        ("a",),
        implies(
            forall(("n",), eq(f(successor(n)), successor(f(n)))),
            both(
                separation,
                forall(
                    ("n",),
                    either(
                        eq(n, zero),
                        eq(f(n), successor(add(p_binary(n), f(zero)))),
                    ),
                ),
            ),
        ),
    )
    delayed_successor = forall(
        ("a",),
        implies(
            forall(("n",), eq(f(successor(n)), successor(f(n)))),
            both(
                separation,
                forall(
                    ("n",),
                    either(eq(n, zero), eq(f(n), successor(app("L", n, f(zero))))),
                ),
            ),
        ),
    )

    def eta(left: Node, right: Node) -> Node:
        return app("I_zero", add(m(left, right), m(right, left)), one)

    ec = forall(
        ("x", "y"),
        both(neg(eq(eta(x, x), zero)), either(eq(eta(x, y), zero), eq(x, y))),
    )
    er = forall(
        ("x", "y"),
        both(
            implies(eq(x, y), neg(eq(eta(x, y), zero))),
            implies(neg(eq(eta(x, y), zero)), eq(x, y)),
        ),
    )
    binary_base = forall(("a",), eq(app("I_h", zero, a), a))
    binary_step = forall(
        ("n", "a"),
        eq(app("I_h", successor(n), a), app("$h", n, app("I_h", n, a))),
    )
    full_base, full_step = computation_full(1)
    return {
        "D_binary_base": binary_base,
        "D_binary_step": binary_step,
        "D_full_PR_base_one_parameter": full_base,
        "D_full_PR_step_one_parameter": full_step,
        "SZ_uniform": sz,
        "SZ_pointwise": sz_pointwise,
        "SZ_binary_spelling_only": sz_binary_spelling,
        "Sep": separation,
        "Inv": inv,
        "Min": minimum,
        "PC": pc,
        "Const": constancy,
        "PI": pi,
        "SS": ss,
        "E_native_bit": equality_bit,
        "Flat_native_operation": flat,
        "AU_generic": au,
        "DU_generic": du,
        "PS_successor_direct": successor_uniqueness,
        "PS_successor_delayed": delayed_successor,
        "Shift": shift,
        "Ret": retract,
        "EC_expanded_computed_test": ec,
        "ER_expanded_computed_test": er,
    }


def descriptors() -> list[dict[str, object]]:
    # Each entry is an actual ordinary-PR declaration.  v denotes the previous
    # output; frozen numerical parameters are listed explicitly.
    declarations = [
        ("p", (), zero, k),
        ("M", ("a",), a, app("p", state)),
        ("C", ("u", "w"), u, w),
        ("Z", (), one, zero),
        (
            "F",
            ("a",),
            a,
            app("C", m(a, successor(k)), m(successor(k), a), successor(k)),
        ),
    ]
    return [
        {
            "name": name,
            "recursion_counter": "k",
            "previous_state_variable": "v",
            "frozen_parameters": list(parameters),
            "function_arity": 1 + len(parameters),
            "base_body": base.display(),
            "step_body": step.display(),
            "base_body_nodes": base.count(),
            "step_body_nodes": step.count(),
            "body_nodes_total": base.count() + step.count(),
            "previous_state_used": "v" in step.display(),
        }
        for name, parameters, base, step in declarations
    ]


def main() -> None:
    formulas = build_formulas()
    measured = {
        name: {
            "nodes": formula.count(),
            "equality_occurrences": formula.equalities(),
            "formula": formula.display(),
        }
        for name, formula in formulas.items()
    }
    expected = {
        "D_binary_base": 6,
        "D_binary_step": 12,
        "D_full_PR_base_one_parameter": 7,
        "D_full_PR_step_one_parameter": 13,
        "SZ_uniform": 24,
        "SZ_pointwise": 24,
        "SZ_binary_spelling_only": 26,
        "Sep": 6,
        "Inv": 9,
        "Min": 13,
        "PC": 26,
        "Const": 19,
        "PI": 36,
        "SS": 22,
        "E_native_bit": 18,
        "Flat_native_operation": 17,
        "AU_generic": 36,
        "DU_generic": 34,
        "PS_successor_direct": 36,
        "PS_successor_delayed": 34,
        "Shift": 11,
        "Ret": 9,
        "EC_expanded_computed_test": 33,
        "ER_expanded_computed_test": 39,
    }
    assert {name: result["nodes"] for name, result in measured.items()} == expected

    def total(*names: str) -> int:
        return sum(formulas[name].count() for name in names)

    comparison_specs = [
        ("new SZ + Sep + Inv", "full PR", ("SZ_uniform", "Sep", "Inv"),
         "Main bounded-reflection presentation; F is a specified PR program, not a primitive oracle."),
        ("new SZ + Sep + Min", "full PR", ("SZ_uniform", "Sep", "Min"),
         "Same-language two-node reduction of the PC + Sep + Min arithmetic display."),
        ("minimum_symmetry: PC + Sep + Min", "binary", ("PC", "Sep", "Min"),
         "The current draft's binary presentation. The full-PR comparison uses the same arithmetic formula and adds 20, not 18, computation nodes."),
        ("positive_equation_induction: PI + Sep", "full PR", ("PI", "Sep"),
         "Main full-PR presentation; the draft also discusses a binary realization."),
        ("retraction: direct PS + Ret", "full PR", ("PS_successor_direct", "Ret"),
         "Current main retraction display."),
        ("retraction: delayed PS + Ret", "full PR", ("PS_successor_delayed", "Ret"),
         "Optional delayed presentation; its descriptor transform is an additional, separately disclosed cost."),
        ("simpler_bases: Const + EC", "binary", ("Const", "EC_expanded_computed_test"),
         "One alternative in this archive. Its two-update delayed alternative uses the generic DU display below."),
        ("simpler_bases: delayed successor + Shift", "binary", ("PS_successor_delayed", "Shift"),
         "Single successor-update alternative."),
        ("stationary_separation: SS + E", "binary", ("SS", "E_native_bit"),
         "Adds a primitive binary equality-bit operation."),
        ("stationary_separation: SS + Flat", "binary", ("SS", "Flat_native_operation"),
         "Its shorter flat-meet variant also adds a primitive binary operation."),
        ("successor_shift: delayed successor + Shift", "binary", ("PS_successor_delayed", "Shift"),
         "Main current successor-shift display."),
        ("retained delayed uniqueness benchmark", "binary", ("DU_generic",),
         "A generic update metavariable is displayed once; update choices or a restricted update-tag family and the delayed-descriptor compiler are not charged as numerical arguments."),
    ]
    comparisons = []
    for label, grammar, pieces, caveat in comparison_specs:
        computation = 20 if grammar == "full PR" else 18
        arithmetic = total(*pieces)
        comparisons.append({
            "basis": label,
            "grammar": grammar,
            "arithmetic_components": list(pieces),
            "arithmetic_nodes_one_parameter": arithmetic,
            "computation_nodes_one_parameter": computation,
            "sum_of_display_templates": arithmetic + computation,
            "qualification": caveat,
        })
    ds = descriptors()
    assert [item["body_nodes_total"] for item in ds] == [2, 3, 2, 3, 12]
    full_grammar = []
    for count in range(5):
        base, step = computation_full(count)
        assert base.count() == 4 + 3 * count
        assert step.count() == 9 + 4 * count
        full_grammar.append({"parameters": count, "base": base.count(),
                             "step": step.count(), "sum": base.count() + step.count()})
    result = {
        "status": "PASS",
        "source_snapshot": "3af028c8eb45b393331630537c5a94939c536341",
        "metric": {
            "one_node_each": ["variable", "zero", "application", "equality",
                              "connective", "falsehood", "individual quantifier"],
            "expanded": ["1 is S(0)", "negation is implication to falsehood",
                         "old binary predecessor p(t) is I_counter(t,0)"],
            "genuine_symbols": "Z and F in the new full-PR language are explicitly specified descriptions; their application is a function-symbol node plus its arguments.",
            "quantifier_names": "Bound names label quantifier nodes; they are not extra children.",
            "schematic_terms": "Displayed arguments count; arbitrary substituted term bodies do not.",
            "not_included": ["encodings of function names and program indices", "declaration delimiters",
                             "the effective grammar itself", "the infinite list of axiom instances",
                             "all programs used in a completeness proof"],
        },
        "formulas": measured,
        "full_PR_computation_by_parameter_count": full_grammar,
        "full_PR_computation_formula": "13 + 7*m",
        "comparisons": comparisons,
        "matched_full_PR_comparisons": {
            "PC_Sep_Min": {"arithmetic": 45, "computation": 20, "sum": 65},
            "SZ_Sep_Min": {"arithmetic": 43, "computation": 20, "sum": 63},
            "SZ_Sep_Inv": {"arithmetic": 39, "computation": 20, "sum": 59},
            "SS_Flat": {"arithmetic": 39, "computation": 20, "sum": 59},
        },
        "fixed_PR_descriptions_in_dependency_order": ds,
        "fixed_descriptor_body_sums": {
            "p_M_C_Z_F": sum(item["body_nodes_total"] for item in ds),
            "p_M_Z_for_main_Min_display": 8,
            "p_M_for_old_PC_Min_display": 5,
            "warning": "These supporting-body sums omit binders, arities, names and the language grammar. Adding them to formula-template sizes does not give a canonical complete description length.",
        },
        "conclusions": [
            "SZ has 24 nodes with genuine unary Z, while PC has 26.",
            "SZ + Sep + Min saves two displayed arithmetic nodes in the same full-PR language.",
            "SZ + Sep + Inv totals 39 arithmetic nodes, tying the existing SS + Flat arithmetic display.",
            "The strict-binary SS + Flat total is 57, below the new full-PR total 59.",
            "Simply spelling Z as I_zero(t,S0) costs two additional nodes; no strict-binary record is asserted.",
            "The new presentation has a simpler direct completeness proof, but these counts do not establish an absolute shortest axiomatization.",
        ],
    }
    output = Path(__file__).with_name("schema_metrics.json")
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "output": str(output),
                      "new_arithmetic_nodes": 39, "new_full_PR_total": 59,
                      "matched_Min_improvement": "45 -> 43",
                      "fixed_descriptor_body_sum": 22}, indent=2))


if __name__ == "__main__":
    main()
