# Rank transport in union-closed families

Research note, 2026-11-25. Two new candidate extensions of the ProveIt entropy drafts: a layered principal-filter correction and optimized row-wise bound; a sharp third extremum for independent two-sample union entropy, with a majorization catalogue and collision corollary.

## Files

- `paper.tex` — complete LaTeX manuscript, mathematical proofs, discussion, references.
- `paper.pdf` — compiled manuscript.
- `verify.py` — standard-library Python verifier (exact rational/ integer certificates; exhaustive small-family tests; independent slow DP comparator).
- `verification.txt` — output of the full verifier run.
- `certificates.csv` — five finite-size abundance comparisons (decimal displays; the comparisons are exact in the verifier).
- `sources.md` — inspected drafts, identifiers, and novelty limitations.
- `SHA256SUMS` — checksums for all preceding files.

## Reproduction

Run from this directory:

```sh
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
python3 verify.py
```

`python3 verify.py --quick` skips exhaustive and random tests. Python 3.10+ is recommended; no third-party modules are needed. The finite numerical proof uses exact fractions, certified logarithm enclosures, and integer comparisons. The optimized dynamic program uses exact integer arithmetic for the rounded cut weights. The general theorems are established by the manuscript's mathematical arguments; tests do not constitute a formal proof assistant verification.

## Scope

The full conjecture remains open in this work. The manuscript does not claim a new universal limiting abundance constant. The numerical comparisons are with the earlier principal-filter inequality in a specific ProveIt draft, not with all existing finite-size results. No repository changes were made. Novelty is provisional pending independent expert review and a fuller literature/priority search.
