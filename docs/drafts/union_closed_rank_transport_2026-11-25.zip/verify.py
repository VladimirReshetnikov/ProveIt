#!/usr/bin/env python3
"""Exact integer/rational checks; no third-party dependencies.
This checks finite certificates and small families, not the general proofs.
"""
from fractions import Fraction as Q
from math import isqrt
from collections import deque, Counter
from itertools import combinations
from functools import lru_cache
import random, csv, argparse

SCALE = 10**18
TERMS = 36

def series_bounds(z):
    """Enclose 2*atanh(z), 0<=z<=1/3, by rational numbers."""
    assert 0 <= z <= Q(1,3)
    z2 = z*z
    power = z
    value = Q(0)
    for j in range(TERMS):
        value += 2*power/(2*j+1)
        power *= z2
    return value, value + 2*power/((2*TERMS+1)*(1-z2))

LOG2 = series_bounds(Q(1,3))

@lru_cache(maxsize=None)
def log_scaled(a,b=1):
    """Integer L,U with L/SCALE <= log(a/b) <= U/SCALE."""
    r=Q(a,b); e=0
    assert r>0
    while r<1: r*=2; e-=1
    while r>=2: r/=2; e+=1
    lo,hi=series_bounds((r-1)/(r+1))
    if e>=0: lo+=e*LOG2[0]; hi+=e*LOG2[1]
    else: lo+=e*LOG2[1]; hi+=e*LOG2[0]
    return (lo*SCALE).__floor__(), (hi*SCALE).__ceil__()

def weights(N,side):
    return [0]+[log_scaled(2*j+1,2*j-1)[side] for j in range(1,N)]

def chain_deficit(N,side):
    return Q(sum((2*j-1)*log_scaled(2*j-1,N)[side] for j in range(1,N+1)),SCALE*N*N)

def layer_sum(N,b,eps,w,all_layers=True):
    tails=[0]*(N+1)
    for j in range(N-1,0,-1):tails[j]=tails[j+1]+w[j]
    pref=[0]*(N+2)
    for j in range(1,N+1):pref[j+1]=pref[j]+tails[j]
    a=eps+1+b-1; total=0
    while a<N:
        total += pref[N]-pref[a]
        if not all_layers:break
        a+=b-1
    return total

def gap_dp(N,b,w):
    """Minimize every row with at most b-1 gaps, using exact integer CHT.
    w[k] is integer weight on cut k. Index 0 is unused.
    Returns array dp[i] for i=1..N.
    """
    W=[0]*N; M=[0]*N
    for k in range(1,N):W[k]=W[k-1]+w[k]; M[k]=M[k-1]+k*w[k]
    prev=[None]*(N+1); prev[N]=0
    for s in range(1,b):
        cur=[None]*(N+1); cur[N]=0; hull=deque()
        for i in range(N-1,0,-1):
            t=i+1
            if prev[t] is not None:
                m=-W[t-1]; z=prev[t]+M[t-1]
                # All w are positive, hence slopes strictly increase.
                while len(hull)>=2:
                    m1,z1=hull[-2]; m2,z2=hull[-1]
                    if (z1-z2)*(m-m2) <= (z2-z)*(m2-m1):hull.pop()
                    else:break
                hull.append((m,z))
            if hull:
                while len(hull)>=2 and hull[0][0]*i+hull[0][1]>=hull[1][0]*i+hull[1][1]:hull.popleft()
                m,z=hull[0];cur[i]=-M[i]+i*W[i]+m*i+z
        prev=cur
    return prev

def gap_dp_slow(N,b,w):
    prev=[None]*(N+1);prev[N]=0
    for _ in range(b-1):
        cur=[None]*(N+1);cur[N]=0
        for i in range(1,N):
            vals=[sum((k-i)*w[k] for k in range(i+1,t))+prev[t] for t in range(i+1,N+1) if prev[t] is not None]
            cur[i]=min(vals) if vals else None
        prev=cur
    return prev

@lru_cache(maxsize=None)
def corrections(N,b,eps,side):
    w=weights(N,side)
    old=layer_sum(N,b,eps,w,False)
    layered=layer_sum(N,b,eps,w,True)
    dp=gap_dp(N,b,w)
    optimal=sum(dp[eps+1:N+1])
    assert old<=layered<=optimal
    return tuple(Q(2*a,SCALE*N*N) for a in (old,layered,optimal))

phi_floor=isqrt(5*SCALE*SCALE)
PHI=(Q(phi_floor-SCALE,2*SCALE),Q(phi_floor+1-SCALE,2*SCALE))

@lru_cache(maxsize=None)
def rhs_intervals(N,b,eps=1):
    bounds=[]
    for side in (0,1):
        E=chain_deficit(N,side)
        lnN=Q(log_scaled(N)[1-side],SCALE)
        ph=PHI[1-side]
        # The relevant expression is 1-phi*(1-E/log N).
        rs=[E+t for t in corrections(N,b,eps,side)]
        assert all(0<=a<=lnN for a in rs)
        bounds.append(tuple(1-ph+ph*a/lnN for a in rs))
    assert all(a<=b for a,b in zip(*bounds))
    return tuple(zip(*bounds))

def fp(x):return f'{float(x):.15f}'

def example_certificates():
    # A few sizes discovered by comparing the preceding explicit bound.
    cases=[(403,162),(609,244),(1027,410),(1519,605),(1716,683)]
    print('RATIONAL CERTIFICATES (epsilon=1, valid also if empty set is absent)')
    rows=[]
    for N,K in cases:
        old,layered,dp=rhs_intervals(N,K)
        target=Q(K,N)
        assert old[1]<target<layered[0]<=dp[0]
        print(f'N={N}, K={K}, K/N={fp(target)}, old upper={fp(old[1])}, layered lower={fp(layered[0])}, DP lower={fp(dp[0])}, guaranteed >= {K+1}')
        rows.append((N,K,fp(target),fp(old[1]),fp(layered[0]),fp(dp[0]),K+1))
    return rows

def entropy_product(vec):
    # Sum r log r is exactly log(product r^r); no floating-point ranking.
    p=1
    for x in vec:p*=x**x
    return p

def chain(N):return list(range(1,2*N,2))

def diamond(N,j):
    c=chain(N); c[j-1]-=2;c[j]+=2;return c

def overlap(N,j):
    c=chain(N);c[j-1]-=4;c[j]+=4;return c

def double(N,j,k):
    assert k-j>=3
    c=diamond(N,j);c[k-1]-=2;c[k]+=2;return c

def candidate(N):
    vals=[overlap(N,N-1)]
    if N>=6:vals.append(double(N,N-4,N-1))
    return min(vals,key=entropy_product)

def catalogue(N):
    for j in range(3,N):yield overlap(N,j)
    for j in range(2,N):
        for k in range(j+3,N):yield double(N,j,k)

def majorizes(x,y):
    a=b=0
    for u,v in zip(sorted(x),sorted(y)):
        a+=u;b+=v
        if a>b:return False
    return a==b

def check_family(f):
    N=len(f)
    if N<4:return False
    r=Counter({x:1 for x in f}); I=0
    for a,b in combinations(f,2):
        c=a|b
        if c not in r:return False
        r[c]+=2; I+=int(c!=a and c!=b)
    if I<2:return False
    v=list(r.values())
    assert any(majorizes(v,z) for z in catalogue(N)),(f,v)
    # entropy comparison equivalent to exact integer products
    assert entropy_product(v)>=entropy_product(candidate(N)),(f,v)
    diff=sum(x*x for x in v)-sum(x*x for x in chain(N))
    assert diff>=(48 if N<6 else 32)
    # Verify the row gap and layer inequalities in an explicit linear extension.
    order=sorted(f,key=lambda x:(x.bit_count(),x));pos={x:i+1 for i,x in enumerate(order)}
    eps=int(0 in f);b=max((sum(x|y==y for y in f) for x in f if x),default=1)
    if b>=2:
        w=[0]+[N-j for j in range(1,N)] # test positive decreasing cut weights
        dp=gap_dp(N,b,w)
        actual=0
        for i in range(1+eps,N+1):
            a=order[i-1];row=0
            for j in range(i+1,N+1):
                u=pos[a|order[j-1]]
                row+=sum(w[j:u])
            assert row>=dp[i]
            actual+=row
        assert actual>=sum(dp[1+eps:N+1])
        # The layered formula also works with this arbitrary decreasing w.
        assert sum(dp[1+eps:N+1])>=layer_sum(N,b,eps,w,True)
    return True

def exhaustive():
    count=0
    for mask in range(1,1<<16):
        f=[x for x in range(16) if mask>>x&1]
        count+=check_family(f)
    print(f'Exhaustive: {count} union-closed families on a labelled four-point ground set with >=2 incomparable pairs.')
    rng=random.Random(20261125);count=0
    for _ in range(400):
        f={0}
        for g in rng.sample(range(1,1<<7),rng.randrange(2,12)):
            f|={g|a for a in f}
        if rng.randrange(2):f.discard(0)
        count+=check_family(sorted(f))
    print(f'Random generated families: {count} qualifying tests.')

def test_dp():
    rng=random.Random(17)
    for N in range(3,22):
        for b in range(2,N+1):
            w=[0]+[rng.randint(1,100) for _ in range(N-1)]
            assert gap_dp(N,b,w)==gap_dp_slow(N,b,w)
    print('Fast gap DP agrees with independent cubic recurrence for 209 small parameter pairs.')

def extrema_checks():
    for N in range(4,31):
        best=entropy_product(candidate(N))
        assert best==min(map(entropy_product,catalogue(N)))
        if N>=6:
            B=entropy_product(overlap(N,N-1)); C=entropy_product(double(N,N-4,N-1))
            assert (B<C) if N in (6,7) else (C<B)
            intervals={6:(562,563),7:(987,989),8:(1162,1163)}
            if N in intervals:
                lo,hi=intervals[N]
                assert lo*C<1000*B<hi*C
    print('Exact entropy-product comparison: overlap wins N=6,7; double diamond wins N=8..30.')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--quick',action='store_true');parser.add_argument('--csv',default='certificates.csv');args=parser.parse_args()
    test_dp();extrema_checks()
    if not args.quick:exhaustive()
    rows=example_certificates()
    with open(args.csv,'w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['N','K','K/N','old_upper_display','layered_lower_display','dp_lower_display','guaranteed_degree']);writer.writerows(rows)
    print('ALL CHECKS PASSED')
