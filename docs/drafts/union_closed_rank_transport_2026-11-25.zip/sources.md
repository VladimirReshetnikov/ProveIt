# Source and novelty audit

## Repository inspection

Repository: https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts

The GitHub connector listed 18 ZIP archives. Source entries were extracted in memory from the connector's base64 responses using a ZIP/DEFLATE reader; no repository changes were made. The listing and selected theorem/section excerpts were inspected; not every theorem and proof in every archive was audited in full. The connector did not yield a readable ZIP central directory for `union_closed_structural_theorems.zip` (empty/unusable bytes in the retrieval). The other retrieved archives yielded readable source entries. The direct antecedents below were inspected more closely:

| Draft archive | Git blob SHA | Relevant result |
|---|---|---|
| `union_closed_extensions_2026-11-25.zip` | `2b814e8557ebd25e065d10b35d10033b31c60ee1` | `sections/principal_filters.tex`: one-layer principal-filter correction (F1–F3). Read in full. `sections/multi_union.tex`: sharp second entropy maximum for multiple samples, including the three-sample case. Theorem statements inspected. |
| `union_closed_refinements_2026-11-25.zip` | `6477927e6fa8d36b4696f74d46a2591001d809a7` | Rank-transport deficit identity and sharp second entropy extrema, including Rényi orders. |
| `union_closed_entropy_2026_11_25.zip` | `55bd6a17f733f6ecc98438c0f1c2a1bde320a898` | Chain maximization, finite-size frequency consequence, exact deficit identity, nonchain extremum. |
| `union_closed_entropy_research_2026-11-25.zip` | `7dc1bb231d80709abab006c9e567356600d57786` | `second_extremal.tex`: sharp second entropy and collision extrema. |

The new candidate contributions here are: all-height gap cost instead of counting each missing superset once; exact row-wise optimization with monotone convex hull; third extremum and majorization catalogue for at least two incomparable pairs, including the change at N=8 and sharp collision formula. The earlier chain bound, rank transport identity, and independent-union analytic inequality are credited and not claimed as new.

## Public literature checked

- Justin Gilmer, *A constant lower bound for the union-closed sets conjecture* (2022): https://arxiv.org/abs/2211.09055
- Zachary Chase and Shachar Lovett, *Approximate union closed conjecture* (2022): https://arxiv.org/abs/2211.11689 — Claim 4.1 and Corollary 3.2 are the known analytic input.
- Simone Costa and Ankan Sadhu, *Beyond Liu's 0.382709 threshold for the union-closed sets conjecture* (2026): https://arxiv.org/abs/2610.02295 — reports 0.3828852549667978.
- Yunjiang Jiang, *Entropy bounds and global couplings for union-closed families* (2026): https://arxiv.org/abs/2609.08291 — finite-size frequency improvements by a different global coupling method.
- Andrew Moffat, *The ceiling of the single-letter entropy method for the union-closed sets conjecture, and a protocol that reaches it* (2026): https://github.com/moffatstudio/union-closed-constant — context on limitations of existing entropy methods.
- Quantavane, November 2026, https://quantavane.com/major-results/union-closed-sets-conjecture/ — reports 0.38317525996679… using a computer-assisted proof. We have not independently audited the proof or established its publication/review status.
- https://en.wikipedia.org/wiki/Union-closed_sets_conjecture — problem background; its bound was less current than the primary preprint above.

Targeted public searches on entropy of independent unions, chain and nonchain extremizers, principal filters, and incomparable-pair rank deficits did not identify the specific new statements in this manuscript. This is not a comprehensive literature survey, and the priority of a mathematical result cannot be established by unsuccessful searches alone. The draft should be independently checked before submission/publication. The full Frankl conjecture, new record asymptotic frequency bounds, and compatibility of the row-wise minimizing paths are not solved here.
