"""Create or verify the payload manifest; optionally build its ZIP archive."""
import hashlib
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED = {'.aux', '.log', '.out', '.toc', '.synctex', '.pyc'}


def payload():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and p.name != 'MANIFEST.sha256' and p.suffix not in EXCLUDED
                  and '__pycache__' not in p.parts)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run():
    manifest = ROOT / 'MANIFEST.sha256'
    actual = ''.join(digest(p) + '  ' + p.relative_to(ROOT).as_posix() + '\n'
                     for p in payload())
    if '--verify' in sys.argv:
        if manifest.read_text() != actual:
            raise SystemExit('Manifest mismatch')
        print('Manifest verified')
        return
    manifest.write_text(actual)
    archive = ROOT.with_suffix('.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
        for p in payload() + [manifest]:
            target.write(p, ROOT.name + '/' + p.relative_to(ROOT).as_posix())
    print(archive)


if __name__ == '__main__':
    run()
