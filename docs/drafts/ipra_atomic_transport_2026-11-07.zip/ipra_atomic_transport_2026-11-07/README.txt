ATOMIC TRANSPORT AND A SMALLER COMPLETE PRESENTATION OF iPRA
==========================================================
Prepared for Vladimir Reshetnikov, 7 November 2026 (Pacific date).

START HERE
----------
report.pdf is the compiled, self-contained mathematical article.
report.tex is its editable source. It includes the actual primary checker
as a listing, so keep checker.py beside it when recompiling.

RESULT
------
The main complete checker is strictly below the CURRENT six-archive
frontier in all three inherited normalized measures:

                                Tokens    AST nodes    Normalized bytes
Current root-program envelope      427          436                1246
checker.py                         416          431                1223
checker_direct.py                  417          429                1225

Counts include the entire source, imports, JSON parser interface, syntax
validation, substitution, proof rules, fresh parameters, and verdict wrapper.
The raw main source is 1285 bytes; normalized and raw bytes are different.
The old core envelope is 367 / 373 / 979. The main core is 356 / 366 / 963.
All measurements use the exact inherited metric under CPython 3.12.14.

Pinned repository:
https://github.com/VladimirReshetnikov/ProveIt/tree/5c4724e5550a1b19347ac62c9b02857a7e3fbd19/docs/drafts

All ten complete current root programs are frozen in comparison/sources.
The 444 / 457 / 1313 frontier quoted inside several supplied reports belongs
to their previous comparison snapshot and is not today's benchmark.

WHAT CHANGED
------------
The checker combines the fused-binder draft's five-rule calculus with
argument-based opening, validated-arity tail dispatch, and parity selection
of the local induction assumptions. The direct-depth companion enters a
protected matrix directly instead of wrapping and unpacking a temporary
closure formula. Both keep the closed-goal packet interface unchanged.

The stated native axiomatization has primitive equality transport only for
equation motives. The report proves arbitrary quantified-motive transport
admissible by structural induction. The checker directly implements this
admissible rule; no external proof compiler is trusted. The schema
restriction and checker-size reduction are separate results.

Every logical and nonlogical primitive rule is stated in the article.
It derives ordinary intuitionistic logic, all primitive recursive defining
equations, and quantifier-free induction. The ordinary realization T_cov
is bi-interpretable with iPRA on the entire numerical domain. Both composite
isomorphisms have graph x=y. The article includes the essential falsity
bridge and the internal recursion-uniqueness argument for nonstandard
counters.

CLAIM LIMITS
------------
This is a strict implementation reduction below a pinned finite comparison
frontier. It is not a global shortestness theorem. The principal arithmetic
and logical constructions are inherited and credited. The investigation
did not establish the broader mathematical breakthrough requested.
The equality-transport restriction is not presented as historically new.
The mathematical metatheory and kernel correctness have written proofs,
not Lean or Rocq formalizations. Finite tests are implementation evidence.

RUN AND REPRODUCE
-----------------
From this directory:

  python3 package.py --verify
  python3 reproduce.py
  python3 build.py

The first command verifies the delivered payload manifest. The second
verifies that the root checkers match their tested copies, recomputes all
measurements, and replays validation. The third recompiles the PDF and
requires pdfLaTeX and the packages in report.tex. The supplied PDF needs
no build step. Python 3.10+ supports the checker; exact reported source
normalization uses CPython 3.12.14.

To check one public packet:

  python3 checker.py examples/reflexivity_zero.json
  python3 checker.py examples/recursion_zero.json
  python3 checker.py examples/false_equation.json

The first two print ACCEPT and exit 0; the last prints REJECT and exits 1.
FORMAT.txt gives the exact public certificate syntax. As with the source
programs, very large inputs may exceed Python's recursion, parser, or
memory resources.

VALIDATION
----------
The portable validation bundle contains 100 labelled entries representing
90 DISTINCT packets: 58 accepted and 32 rejected. The labelled cohorts
overlap; their sum must not be represented as a distinct theorem count.

The frozen source checker and both candidates agree on the full recorded
execution summary of all packets. The separate named-variable oracle
agrees on outcomes and on successful traces. All three actual CLIs pass
under normal Python and -O: 540 runs = 90 packets x 3 programs x 2 modes.
An inherited opening audit passes 3672 cases per implementation:
2110 valid substitutions/formations and 1562 invalid cases.

Adversarial cases cover variable capture, future-parameter references,
eigenparameter escape, malformed syntax, Boolean/float aliases, and an
attempt to use induction for a compound formula. See validation/AUDIT.txt
and validation/results.json for exact boundaries and outcomes.

PACKAGE CONTENTS
----------------
report.pdf, report.tex       Complete article and editable source
checker.py                  Entire primary trusted acceptance program
checker_direct.py           Smaller-AST alternative, same packet interface
FORMAT.txt                  Complete concrete syntax and rule instructions
examples/                   Two tiny accepted packets and one rejected packet
comparison/                 Pinned sources, metric, source identities
results/                    Recomputed metrics and comparison CSV
validation/                 Portable fixtures, independent oracle, replay/results
research/                   Detailed transport proof and implementation ablations
ATTRIBUTION.txt              Contribution and provenance boundary
LICENSE_SOURCE.txt          Preserved inherited MIT-0 license
reproduce.py, measure.py     Offline verification and measurement
build.py, package.py         PDF build and payload manifest/ZIP tools
MANIFEST.sha256              SHA-256 identity of every delivered payload file

No repository write or publication was performed.
