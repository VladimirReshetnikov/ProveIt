"""Recompute the pinned whole-program comparison without changing its metric."""
import csv
import hashlib
import importlib.util
import json
import platform
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def run():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    metric_path = ROOT / 'comparison/source_measure.py'
    if hashlib.sha256(metric_path.read_bytes()).hexdigest() != manifest['measurement_source']['sha256']:
        raise ValueError('Changed measurement routine')
    spec = importlib.util.spec_from_file_location('frozen_metric', metric_path)
    metric = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(metric)
    rows = []
    for entry in manifest['programs']:
        result = metric.metrics(ROOT / 'comparison' / entry['local_file'])
        if result['sha256'] != entry['sha256']:
            raise ValueError('Changed comparison source: ' + entry['label'])
        rows.append({**entry, **result})
    envelope = {key: min(row[key] for row in rows) for key in FIELDS}
    core_envelope = {key: min(row['core'][key] for row in rows) for key in FIELDS}
    candidates = [{'label': name, **metric.metrics(ROOT / name)}
                  for name in ('checker.py', 'checker_direct.py')]
    for candidate in candidates:
        if not all(candidate[key] < envelope[key] for key in FIELDS):
            raise ValueError('Candidate fails a whole-program comparison')
        if not all(candidate['core'][key] < core_envelope[key] for key in FIELDS):
            raise ValueError('Candidate fails a core comparison')
    result = {'python': platform.python_version(), 'implementation': platform.python_implementation(),
              'commit': manifest['commit'], 'archive_count': len(manifest['archives']),
              'root_program_count': len(rows), 'envelope': envelope,
              'core_envelope': core_envelope, 'programs': rows,
              'candidates': candidates, 'strict_improvement': True,
              'metric_sha256': manifest['measurement_source']['sha256']}
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results/metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    with (ROOT / 'results/comparison.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, ('label', *FIELDS, 'sha256'), extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows + candidates)
    print(json.dumps({key: result[key] for key in ('python', 'archive_count', 'root_program_count',
                                                  'envelope', 'core_envelope', 'candidates',
                                                  'strict_improvement')}, indent=2))
    return result


if __name__ == '__main__':
    run()
