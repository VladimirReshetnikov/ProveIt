PORTABLE FUSED-BINDER FALLBACK VALIDATION
=======================================

Run from any working directory:
  python3 /path/to/validation_bundle/verify.py

Python 3.10+ is required by the frozen acceptance programs' match syntax.
The only dependencies are the Python standard library and this directory.
No network access, other repository checkout, absolute evidence path,
proof-assistant installation, or LaTeX installation is required.

Contents
  verify.py             Focused replay, CLI checks, and opening API adapter.
  fixtures.json         100 labelled cases represented by 90 unique packets.
  named_oracle.py       Unchanged independent named-binder rule interpreter.
  opening_audit.py      Unchanged inherited opening audit with narrow imports.
  kernels/              Frozen source checker and both complete candidates.
  provenance.json       Source snapshot, archive and source identities.
  results.json          Results from the supplied verification run.
  ATTRIBUTION.txt        Exact inherited/new boundary.
  LICENSE_SOURCE.txt    License supplied with the inherited source archive.

The candidate parity checker measures 416 normalized tokens, 431 AST nodes,
and 1223 normalized bytes. The direct-depth variant measures 417/429/1225.
They share the same closed-sentence certificate interface and five-rule
fused calculus as source_fused_closed.py. The comparison measures the whole
acceptance program; this validation directory is outside the trusted kernel.

The 100 labelled cases consist of 43 closed specializations, 2 alias
regressions, 29 semantic boundary controls, and 26 closed scope controls.
Ten labels repeat an already represented packet, leaving 90 unique packets:
58 intended acceptances and 32 intended rejections. An intended rejection
concerns that proof packet; its displayed conclusion may be provable by a
different proof. These counts are not numbers of independent theorems.

Each unique packet is checked in-process by the source and both candidates,
with equality of acceptance, consumed-stream remainder, final freshness
floor, and exception type. The named oracle checks intended outcomes and,
on acceptances, the stream remainder and final floor. Every packet is also
run through all three actual CLIs, both normally and with Python -O:
90 packets x 3 programs x 2 modes = 540 CLI runs.

Separately, the unchanged inherited opening audit compares each implementation
with the named-binder opening oracle on 3672 cases. There are 2110 valid
and 1562 invalid cases per implementation. The candidate adapter changes
only inst(value, images, d) to inst(value, *images, d=d).

This is focused finite executable evidence. The general acceptance-equivalence
argument and arithmetic metatheory are written mathematical arguments,
not conclusions justified by a test count. No broad random fuzz campaign
or new arithmetic theorem search is included.
