"""Unchanged opening audit function from the pinned fused-binder archive.
See ATTRIBUTION.txt. This module is untrusted test support.
"""
from collections import Counter
from copy import deepcopy
from named_oracle import opening


def audit_opening(closed):
    """Compare explicit named parsing with the production packed opening."""
    atoms = [-3, -2, -1, 0, 1, 2, 3, 4, 5, 6, True, None, {}]
    terms = [*atoms, [], [0], [1], [5], [0, 0], [0, 0, 1], [0, 0, 3],
             [0, 0, 5], [1, 0, [0, 3, 7]], [0, 0, [0, 1, 9]]]
    formulas = [[t, 0] for t in terms]
    formulas += [[[t, 0]] for t in (-2, 0, 1, 2, 3, 4, 5)]
    formulas += [[[t, 0], [1, 2], [3, 4]] for t in (-2, 0, 1, 2, 3, 4, 5, 6)]
    formulas += [[], None, {}, [True], [[0, 0], [5, 5], [0, 0]],
                 [[[5, 1]], [[3, 4]], [[1, 2]]],
                 [[[[0, 0, 9], 5]], [0, 0], [0, 0]]]
    environments = [(), (0,), (-1,), (-3,), (1,), ([0],), ([0, 0, 3],),
                    ([0, 0, 5],), (0, [0])]
    counts = Counter()
    for formula, values in ((True, formulas), (False, terms)):
        for value in values:
            for depth in (0, 1, 2):
                for lower in (0, -2):
                    for images in environments:
                        closed.k = lower
                        try:
                            actual = closed.inst(deepcopy(value), deepcopy(images),
                                                 2 * depth + (not formula))
                            valid = True
                        except Exception:
                            actual, valid = None, False
                        try:
                            expected = opening(deepcopy(value), deepcopy(images),
                                               formula=formula, depth=depth, lower=lower)
                            valid_expected = True
                        except Exception:
                            expected, valid_expected = None, False
                        assert valid == valid_expected and (not valid or actual == expected), \
                            (value, images, formula, depth, lower, actual, expected)
                        counts['valid' if valid else 'invalid'] += 1
    return dict(counts)
