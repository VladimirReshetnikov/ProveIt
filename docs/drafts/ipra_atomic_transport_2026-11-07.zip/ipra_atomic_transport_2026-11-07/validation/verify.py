"""Portable focused replay of both fused-binder/argument-opening candidates.

This is untrusted test support. The three complete acceptance programs are
in kernels/. Only the Python standard library and this directory are used.
"""
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
from named_oracle import Oracle
from opening_audit import audit_opening

ROOT = Path(__file__).resolve().parent
KERNELS = {'source': ROOT / 'kernels/source_fused_closed.py',
           'parity': ROOT / 'kernels/candidate_parity.py',
           'direct': ROOT / 'kernels/candidate_direct.py'}


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(module, packet):
    stream = deepcopy(packet)
    module.k, module.take = 0, stream.pop
    try:
        accepted, error = bool(module.check(stream.pop(), [])), None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    return dict(accepted=accepted, remaining=len(stream), final_k=module.k, error=error)


class OpeningAdapter:
    def __init__(self, module):
        self.module = module

    @property
    def k(self):
        return self.module.k

    @k.setter
    def k(self, value):
        self.module.k = value

    def inst(self, value, images=(), d=0):
        return self.module.inst(value, *images, d=d)


def main():
    fixtures = json.loads((ROOT / 'fixtures.json').read_text())
    modules = {key: load(path, 'kernel_' + key) for key, path in KERNELS.items()}
    cases, packets = fixtures['cases'], fixtures['packets']
    if len({p['packet_sha256'] for p in packets}) != len(packets):
        raise AssertionError('duplicate packet record')
    labels = {p['packet_sha256']: [] for p in packets}
    for case in cases:
        labels[case['packet_sha256']].append(case['group'] + '/' + case['case'])
    cli_counts, rules, records = Counter(), Counter(), []
    with tempfile.TemporaryDirectory(prefix='ipra-fused-verify-') as directory:
        certificate = Path(directory) / 'certificate.json'
        for entry in packets:
            value, expected, key = entry['packet'], entry['expected'], entry['packet_sha256']
            serialized = json.dumps(value, sort_keys=True, separators=(',', ':')).encode()
            if sha256(serialized).hexdigest() != key:
                raise AssertionError(('fixture hash mismatch', key))
            runs = {name: run(module, value) for name, module in modules.items()}
            if any(actual != runs['source'] for actual in runs.values()):
                raise AssertionError(('execution mismatch', key, runs))
            oracle = Oracle().run(value)
            if runs['source']['accepted'] != expected or oracle['accepted'] != expected:
                raise AssertionError(('outcome mismatch', key, runs, oracle, expected))
            if expected:
                if any(runs['source'][field] != oracle[field]
                       for field in ('remaining', 'final_k')):
                    raise AssertionError(('oracle trace mismatch', key))
                rules.update(oracle['rules'])
            certificate.write_bytes(serialized + b'\n')
            wanted = (0, 'ACCEPT', '') if expected else (1, 'REJECT', '')
            for name, checker in KERNELS.items():
                for optimized in (False, True):
                    command = [sys.executable, *(['-O'] if optimized else []),
                               str(checker), str(certificate)]
                    process = subprocess.run(command, capture_output=True, text=True, timeout=15)
                    actual = process.returncode, process.stdout.strip(), process.stderr.strip()
                    if actual != wanted:
                        raise AssertionError(('CLI mismatch', key, name, optimized, actual))
                    cli_counts[name + ('_optimized' if optimized else '_normal')] += 1
            records.append(dict(packet_sha256=key, labels=labels[key], expected=expected,
                                execution=runs['source'], all_three_executions_equal=True,
                                oracle_accepted=oracle['accepted']))

    opening = {'source': audit_opening(modules['source'])}
    for name in ('parity', 'direct'):
        opening[name] = audit_opening(OpeningAdapter(modules[name]))
        if opening[name] != opening['source']:
            raise AssertionError(('opening outcomes differ', name))
    expected_by_hash = {p['packet_sha256']: p['expected'] for p in packets}
    groups = {}
    for group in sorted({c['group'] for c in cases}):
        selected = [c for c in cases if c['group'] == group]
        accepted = sum(expected_by_hash[c['packet_sha256']] for c in selected)
        groups[group] = dict(labelled_cases=len(selected), accepted=accepted,
                             rejected=len(selected) - accepted)
    dependencies = [*KERNELS.values(), ROOT / 'verify.py', ROOT / 'named_oracle.py',
                    ROOT / 'opening_audit.py', ROOT / 'fixtures.json', ROOT / 'provenance.json']
    result = dict(status='PASS', python=platform.python_version(),
                  source_commit=fixtures['source_commit'],
                  file_sha256={str(p.relative_to(ROOT)): sha256(p.read_bytes()).hexdigest()
                               for p in dependencies},
                  labelled_cases=len(cases), groups=groups, unique_packets=len(packets),
                  unique_accepted=sum(p['expected'] for p in packets),
                  unique_rejected=sum(not p['expected'] for p in packets),
                  duplicate_labelled_entries=len(cases) - len(packets),
                  cli_runs=sum(cli_counts.values()), cli_runs_by_program_and_mode=dict(cli_counts),
                  opening_cases_per_implementation=sum(opening['source'].values()),
                  opening_outcomes=opening,
                  accepted_unique_packet_rule_uses=dict(sorted(rules.items())),
                  records=records,
                  limits='Finite replay and independent opening audit, not a formal soundness proof. '
                         'Labelled cohorts overlap; their counts are not counts of distinct theorems.')
    (ROOT / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('file_sha256', 'records')}, indent=2))


if __name__ == '__main__':
    main()
