"""Verify root-kernel identity, then reproduce the comparison and finite checks."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
for public, tested in [('checker.py', 'candidate_parity.py'),
                       ('checker_direct.py', 'candidate_direct.py')]:
    if (ROOT / public).read_bytes() != (ROOT / 'validation/kernels' / tested).read_bytes():
        raise SystemExit('The root checker differs from its validated copy: ' + public)
for script in ('measure.py', 'validation/verify.py'):
    subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)
