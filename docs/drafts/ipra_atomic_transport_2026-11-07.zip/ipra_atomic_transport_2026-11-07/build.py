"""Build the article with pdfLaTeX; stop on compilation errors."""
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
for _ in range(2):
    subprocess.run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error', 'report.tex'],
                   cwd=ROOT, check=True)
