"""Untrusted adapter for the pinned composed-kernel certificate format.

The mathematical rules and asserted sequent are unchanged. Only Boolean or
floating-point aliases in hypothesis lookup keys are replaced by exact integer
leaves. The old and new complete checkers validate the input and output.
This is not a front end for arbitrary iPRA notation or an iPRA proof compiler.
"""

import copy
import importlib.util
import json
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


SOURCE = load("adapter_source_checker", ROOT / "verification/reference/composed_checker.py")
TARGET = load("adapter_target_checker", ROOT / "code/checker.py")


def exact_key(a):
    if type(a) in (bool, float):
        n = int(a)
        if n != a:
            raise ValueError("nonintegral hypothesis alias")
        return n
    if type(a) is list:
        return [exact_key(b) for b in a]
    return a


def adapt_proof(p):
    if type(p) is list:
        if len(p) == 2 and p[0] == "hyp":
            return ["hyp", exact_key(p[1])]
        return [adapt_proof(q) for q in p]
    return p


def adapt(data):
    SOURCE.check(copy.deepcopy(data))
    assumptions, goal, proof = copy.deepcopy(data)
    result = [assumptions, goal, adapt_proof(proof)]
    TARGET.check(result)
    return result


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: adapt_certificate.py SOURCE.json TARGET.json")
    data = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    result = adapt(data)
    Path(sys.argv[2]).write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("Accepted input and output; preserved the asserted sequent.")
