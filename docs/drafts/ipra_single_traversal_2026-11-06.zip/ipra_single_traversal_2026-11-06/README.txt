A SINGLE SYNTAX TRAVERSAL FOR A SMALLER COMPLETE iPRA CHECKER
Prepared for Vladimir Reshetnikov, 6 November 2026
==========================================================

START WITH report.pdf. Its complete rebuildable source is report.tex
and sections/*.tex. The entire trusted acceptance program is code/checker.py.

RESULT

The complete checker has 878 significant source tokens, 922 executable
AST nodes, 2,777 normalized executable bytes and 3,161 raw source bytes.
The coordinatewise minima across 33 current complete comparison sources
are 957 tokens, 1,013 AST nodes, 3,127 normalized bytes and 3,430 raw bytes.
The new checker is below every coordinate. All syntax, binding operations,
arithmetic schema generation, public falsity handling, statement checks,
imports and the JSON command-line boundary are counted.

The new reduction is one typed syntax traversal shared by formation
checking, capture-avoiding substitution, lifting, and falsity conversion.
Validation is a shift by zero. Every elimination annotation is explicitly
validated, so the smaller code also simplifies the old checker invariant.
The mathematical two-binder/finite-recursion basis is inherited and credited.
This is a reproducible implementation improvement, not an absolute global
shortest-program theorem.

THEORY

There is one number sort. Terms have variables, zero, successor and finite
initialized recursion. Public formulas have equality, genuine falsity,
Pi_x(A;B)=forall x(A->B), and Sigma_x(A;B)=exists x(A and B).
The report lists all six logical inference schemas, both recursion
computation schemas, the equation-induction/numerical-cases axiom schema,
and the explicit falsity conversion. Nothing else is primitive.

The report proves recovery of full intuitionistic logic and quantifier-free
induction, exact public sequent adequacy, and ordinary whole-domain
bi-interpretability with full first-order iPRA. It defines the ordinary
first-order realization explicitly. Both composites are internally
isomorphic to the identity; the proof treats arbitrary, not only standard,
recursion counters. Genuine falsity is retained in the public theory.

RUN (Python 3.10+, standard library only)

  python3 reproduce.py
  python3 code/checker.py examples/equation_induction_addition.json
  python3 code/checker.py examples/quantified_explosion.json
  python3 code/checker.py examples/reject_quantified_induction.json

The first two checker examples print ACCEPT and exit 0. The last is a
deliberate negative example; it prints REJECT and exits 1.

A certificate is [assumptions, goal, proof]. Nonempty assumptions certify
a sequent, not an unconditional theorem. See FORMAT.txt for the wire format.

To adapt a certificate from the pinned composed-kernel format:

  python3 code/adapt_certificate.py source.json target.json

The adapter checks both ends and preserves the stated assumptions and goal.
It only repairs historical Boolean/float aliases in hypothesis lookup keys;
the new checker requires these keys to be well-formed formulas. It is not a
front end for arbitrary iPRA notation and is never trusted by the checker.

BUILD

  python3 build.py

Requires pdflatex and the packages listed in report.tex. The builder runs
the verification scripts, compiles three passes, checks layout/reference
diagnostics, updates SHA256SUMS.txt, and creates the ZIP beside this folder.
Use --skip-tests only when the exact code and fixtures were already verified.
Use --package-only to repackage an already compiled and verified report.

COMPARISON AND PROVENANCE

Repository: VladimirReshetnikov/ProveIt
Commit: 36fb791c722edc2549719744c38feef74fa422fb
Directory: docs/drafts

All six ZIP bytes were checked against their Git blob identities.
comparison/ contains 33 exact current complete source files, per-member
provenance and digests, and a static source counter. The mathematical basis
comes from the supplied draft series; the smaller shared traversal is the
new implementation contribution. The source repository was not modified.

VERIFICATION

77 valid source certificates preserve their public sequents under the checked
adapter; 46 invalid sources reject. Of the valid sources, 76 replay directly
and one malformed lookup key is deliberately rejected before repair.
The design suite also covers both matched controls, falsity/clash variants,
18,076 grammar/canonicalization cases, binding and boundary cases, and CLI
execution. An independently written audit passes 103 of 103 checks using
its own named-variable substitution oracle. All results are reproducible.

These are written general proofs plus overlapping finite tests. No Lean/Rocq
formalization of the metatheory or Python semantics is claimed. Host resource
limits can prevent execution on very large finite certificates.

CONTENTS

  report.pdf, report.tex, sections/  Complete report, source, further questions
  code/checker.py                  Entire trusted acceptance program
  code/adapt_certificate.py        Untrusted checked format adapter
  examples/                       Representative positive/negative certificates
  controls/                       Two intermediate complete checkers
  comparison/                     Exact comparator sources, metrics and provenance
  verification/                   Both audits, fixture corpus, results and PDF review
  reproduce.py, build.py           Reproduction and PDF/ZIP creation
  SHA256SUMS.txt                   Digests of all other packaged files
