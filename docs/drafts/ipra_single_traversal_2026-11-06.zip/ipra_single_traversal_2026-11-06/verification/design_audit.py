"""Reproduce finite validation of the single-traversal checker.

Loads the actual packaged checker, frozen ablation controls, and exact pinned
reference. No scratch paths or network access are used. Formation expectations
come from an independently written pattern grammar and separate canonicalizer;
binding expectations are literal hand-written trees. Finite checks complement
the report's proofs; they do not establish universal soundness by themselves.
"""

import copy
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parents[1]
FAILURES = (ValueError, TypeError, IndexError, KeyError, RecursionError, OverflowError)
CLASH = ["=", -1, ["s", -1]]
TRUE = ["=", -1, -1]
REC = ["r", -1, -1, -1]
REFLEXIVITY = ["use", ["rec", REC], ["=", 0, -1], ["rec", REC]]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def accepted(module, data):
    try:
        return module.check(copy.deepcopy(data)) is True
    except FAILURES:
        return False


def demand(condition, detail):
    if not condition:
        raise AssertionError(detail)


def surface_shape(a, formula):
    """Independent grammar: no constructor indices or candidate helpers."""
    match a:
        case int() if type(a) is int:
            return not formula and a >= -1
        case ["s", t]:
            return not formula and surface_shape(t, False)
        case ["r", n, t, h]:
            return (not formula and surface_shape(n, False)
                    and surface_shape(t, False) and surface_shape(h, False))
        case ["=", s, t]:
            return formula and surface_shape(s, False) and surface_shape(t, False)
        case ["false"]:
            return formula
        case ["pi", a, b] | ["sig", a, b]:
            return formula and surface_shape(a, True) and surface_shape(b, True)
        case _:
            return False


def canonical(a):
    """Separate expected public-falsity conversion; it does not validate."""
    if a == ["false"]:
        return copy.deepcopy(CLASH)
    return [canonical(b) for b in a] if type(a) is list else a


def public_false(a):
    if a == CLASH:
        return ["false"]
    return [public_false(b) for b in a] if type(a) is list else a


def main():
    checker_path = ROOT / "code/checker.py"
    target = load("audit_target", checker_path)
    source_path = ROOT / "verification/reference/composed_checker.py"
    source = load("audit_source", source_path)
    controls = [
        (name, load("audit_" + name, ROOT / "controls" / (name + ".py")))
        for name in ("separate_table", "shared_walk")
    ]
    adapter = load("audit_adapter", ROOT / "code/adapt_certificate.py")
    provenance = json.loads((ROOT / "verification/reference/provenance.json").read_text())
    demand(hashlib.sha256(source_path.read_bytes()).hexdigest()
           == provenance["checker_sha256"], "reference source hash")

    corpus_rows = []
    adapted_count = 0
    adaptation_changes = []
    variants = 0
    source_rejections = 0
    alias_file = "direct_lookup_returns_stored_formula.json"
    for row in provenance["fixtures"]:
        path = ROOT / "verification/fixtures/composed" / row["filename"]
        raw = path.read_bytes()
        demand(hashlib.sha256(raw).hexdigest() == row["sha256"], path.name + " hash")
        data = json.loads(raw)
        old = accepted(source, data)
        demand(old == row["expected_source_accept"], path.name + " source outcome")
        for name, control in controls:
            demand(accepted(control, data) == old, (path.name, name))
        new = accepted(target, data)
        expected_direct = old and path.name != alias_file
        demand(new == expected_direct, path.name + " target outcome")
        if old:
            result = adapter.adapt(data)
            demand(json.dumps(result[:2]) == json.dumps(data[:2]), path.name + " sequent changed")
            demand(accepted(target, result), path.name + " adapted output")
            adapted_count += 1
            if json.dumps(result) != json.dumps(data):
                adaptation_changes.append(path.name)
        else:
            source_rejections += 1
            try:
                adapter.adapt(data)
            except FAILURES:
                pass
            else:
                raise AssertionError(path.name + " invalid source adapted")
        for transform in (canonical, public_false):
            transformed = transform(data)
            demand(accepted(source, transformed) == old,
                   (path.name, transform.__name__, "reference conversion"))
            demand(accepted(target, transformed) == expected_direct,
                   (path.name, transform.__name__, "target conversion"))
            variants += 1
        corpus_rows.append({"file": path.name, "source_accept": old,
                            "target_direct_accept": new})
    demand(adaptation_changes == [alias_file], "unexpected adapter change")

    # Every tag, wrong arity, scalar kind and child sort occurs in this corpus.
    small = [None, False, True, -2, -1, 0, 1, ["false"], CLASH]
    shapes = small + ["", "s", "ss", "rrrr", "===", {}, {"0": -1}, [], ["false", 0]]
    for tag in ("s", "r", "=", "pi", "sig", "false", None, False, 0, [], {}):
        for arity in range(4):
            shapes.extend([tag, *args] for args in itertools.product(small, repeat=arity))
    shape_count = 0
    for a in shapes:
        for formula in (False, True):
            expected = surface_shape(a, formula)
            try:
                actual = target.shift(copy.deepcopy(a), 0, formula)
                obtained = True
            except FAILURES:
                actual, obtained = None, False
            demand(obtained == expected, ("formation", a, formula))
            if expected:
                demand(actual == canonical(a), ("canonical form", a, formula))
            shape_count += 1

    binding_cases = [
        ("shift equation", "shift", ["=", 0, 1], 1, ["=", 1, 2]),
        ("zero fixed", "shift", -1, 5, -1),
        ("large free index", "shift", 1000000, 2, 1000002),
        ("Pi bound slot", "shift", ["pi", ["=", 0, 1], ["=", 1, 2]], 1,
         ["pi", ["=", 0, 2], ["=", 2, 3]]),
        ("recursion depths", "shift", ["r", 0, -1, ["r", 1, 2, ["s", 3]]], 1,
         ["r", 1, -1, ["r", 1, 3, ["s", 3]]]),
        ("falsity is closed", "shift", ["false"], 7, CLASH),
        ("substitution below recursion", "inst",
         ["=", ["r", 0, -1, ["s", 2]], 1], ["s", 0],
         ["=", ["r", ["s", 0], -1, ["s", ["s", 2]]], 0]),
        ("substitution below both binders", "inst",
         ["pi", ["=", 0, 1], ["sig", ["=", 0, 2], ["=", 1, 3]]], ["s", 0],
         ["pi", ["=", 0, ["s", 1]], ["sig", ["=", 0, ["s", 2]], ["=", 1, 2]]]),
        ("falsity under binder", "inst", ["pi", ["false"], ["=", 1, 2]], -1,
         ["pi", CLASH, ["=", -1, 1]]),
    ]
    for name, operation, a, argument, expected in binding_cases:
        actual = getattr(target, operation)(copy.deepcopy(a), copy.deepcopy(argument))
        demand(actual == expected, (name, actual, expected))

    f = ["false"]
    atomic = ["=", 0, 0]
    normalized_hyp = [[CLASH], f, ["hyp", f]]
    boundary = [
        ("falsity lookup normalization", normalized_hyp, True),
        ("falsity Pi normalization", [[], ["pi", f, f], ["pi", f, ["hyp", f]]], True),
        ("falsity equality template", [[CLASH, TRUE], f,
         ["use", ["hyp", TRUE], f, ["hyp", f]]], True),
        ("falsity Sigma conclusion", [[["sig", f, f]], f,
         ["use", ["hyp", ["sig", f, f]], f, ["hyp", f]]], True),
        ("falsity numerical matrix", [[], ["pi", ["sig", f, ["pi", f, f]], f],
         ["nat", f]], True),
        ("unproved falsity", [[], f, ["hyp", f]], False),
        ("falsity is not a numerical witness", [[], ["sig", TRUE, TRUE],
         ["pair", f, REFLEXIVITY, REFLEXIVITY]], False),
        ("falsity is not a recursion body", [[], TRUE, ["rec", ["r", -1, -1, f]]], False),
        ("Boolean key alias rejected", [[atomic], atomic, ["hyp", ["=", False, False]]], False),
        ("float key alias rejected", [[atomic], atomic, ["hyp", ["=", 0.0, 0.0]]], False),
        ("Boolean assertion rejected", [[], ["=", False, False], REFLEXIVITY], False),
        ("scalar envelope rejected", False, False),
        ("object envelope rejected", {"assumptions": [], "goal": TRUE, "proof": REFLEXIVITY}, False),
        ("malformed tag rejected", [[], TRUE, ["nat", [["="], -1, -1]]], False),
    ]
    for name, data, expected in boundary:
        demand(accepted(target, data) == expected, name)
    stored = ["=", 0, 1]
    demand(target.infer(["hyp", copy.deepcopy(stored)], [stored]) is stored,
           "canonical hypothesis identity")

    cli_rows = []
    with tempfile.TemporaryDirectory(prefix="ipra_single_traversal_") as directory:
        for optimized in (False, True):
            for name, data, expected in boundary[:2] + boundary[5:6] + boundary[8:10] + boundary[12:13]:
                path = Path(directory) / "certificate.json"
                path.write_text(json.dumps(data), encoding="utf-8")
                command = [sys.executable, *(["-O"] if optimized else []),
                           str(checker_path), str(path)]
                completed = subprocess.run(command, text=True, capture_output=True, timeout=15)
                demand(completed.returncode == (0 if expected else 1)
                       and completed.stdout.strip() == ("ACCEPT" if expected else "REJECT"),
                       ("CLI", name, optimized, completed.stdout, completed.stderr))
                cli_rows.append({"name": name, "optimized": optimized, "accepted": expected})

    results = {
        "all_passed": True,
        "candidate_sha256": hashlib.sha256(checker_path.read_bytes()).hexdigest(),
        "source_commit": provenance["commit"],
        "source_fixture_count": len(corpus_rows),
        "source_acceptances": adapted_count,
        "source_rejections": source_rejections,
        "candidate_direct_acceptances": sum(row["target_direct_accept"] for row in corpus_rows),
        "intentional_strict_key_rejections": adaptation_changes,
        "adapter_accepted_outputs": adapted_count,
        "adapter_rejected_source_inputs": source_rejections,
        "source_statement_preservation_checks": adapted_count,
        "control_replays": len(corpus_rows) * len(controls),
        "falsity_conversion_cases": variants,
        "independent_formation_and_canonicalization_cases": shape_count,
        "literal_binding_cases": len(binding_cases),
        "handwritten_boundary_cases": len(boundary),
        "canonical_hypothesis_identity_checks": 1,
        "cli_cases": len(cli_rows),
        "qualification": "Finite verification; the adapter only converts this named certificate format, not arbitrary iPRA source proofs.",
        "corpus_results": corpus_rows,
        "cli_results": cli_rows,
    }
    path = ROOT / "verification/design_audit_results.json"
    path.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in results.items()
                      if key not in ("corpus_results", "cli_results")}, indent=2))


if __name__ == "__main__":
    main()
