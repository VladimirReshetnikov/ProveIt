"""Independent audit of the unified validation/substitution/falsity checker.

Run from the package root with python3 verification/independent_audit.py.  The named-variable oracle below is written
independently: it represents binding by fresh symbolic names and substitutes
only free names.  No repository proof builder or translator is imported.
"""

from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile


HERE = Path(__file__).resolve().parent
TARGET = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else HERE.parent / "code" / "checker.py"
spec = importlib.util.spec_from_file_location("audited_checker", TARGET)
K = importlib.util.module_from_spec(spec)
spec.loader.exec_module(K)
RESULTS = []


def record(name, condition):
    RESULTS.append({"name": name, "passed": bool(condition)})
    if not condition:
        raise AssertionError(name)


def accepted(certificate):
    try:
        return K.check(copy.deepcopy(certificate)) is True
    except (ValueError, TypeError, IndexError, KeyError, RecursionError):
        return False


def named_term(a, scope=(), space="input", path=()):
    """Decode explicit names; local binders are globally unique tuples."""
    if a == -1:
        return ("zero",)
    if type(a) is int:
        return ("variable", scope[a] if a < len(scope) else ("free", a - len(scope)))
    if a[0] == "s":
        return ("succ", named_term(a[1], scope, space, path + (0,)))
    if a[0] == "r":
        u = ("bound", space, path, "state")
        n = ("bound", space, path, "counter")
        return ("recursion", named_term(a[1], scope, space, path + (0,)),
                named_term(a[2], scope, space, path + (1,)), u, n,
                named_term(a[3], (u, n) + scope, space, path + (2,)))
    raise AssertionError("oracle term input")


def named_formula(a, scope=(), space="input", path=()):
    if a == ["false"]:
        return named_formula(["=", -1, ["s", -1]], scope, space, path)
    if a[0] == "=":
        return ("equality", named_term(a[1], scope, space, path + (0,)),
                named_term(a[2], scope, space, path + (1,)))
    if a[0] in ("pi", "sig"):
        x = ("bound", space, path, "number")
        return (a[0], x, named_formula(a[1], (x,) + scope, space, path + (0,)),
                named_formula(a[2], (x,) + scope, space, path + (1,)))
    raise AssertionError("oracle formula input")


def named_substitute(a, replacement):
    """One simultaneous substitution; inserted terms are not revisited."""
    if a[0] == "variable":
        name = a[1]
        return replacement(name[1]) if name[0] == "free" else a
    if a[0] == "zero":
        return a
    if a[0] == "succ":
        return ("succ", named_substitute(a[1], replacement))
    if a[0] == "recursion":
        return ("recursion", named_substitute(a[1], replacement),
                named_substitute(a[2], replacement), a[3], a[4],
                named_substitute(a[5], replacement))
    if a[0] == "equality":
        return ("equality", named_substitute(a[1], replacement),
                named_substitute(a[2], replacement))
    return (a[0], a[1], named_substitute(a[2], replacement),
            named_substitute(a[3], replacement))


def numbered(a, scope=()):
    if a[0] == "zero":
        return -1
    if a[0] == "variable":
        return len(scope) + a[1][1] if a[1][0] == "free" else scope.index(a[1])
    if a[0] == "succ":
        return ["s", numbered(a[1], scope)]
    if a[0] == "recursion":
        return ["r", numbered(a[1], scope), numbered(a[2], scope),
                numbered(a[5], (a[3], a[4]) + scope)]
    if a[0] == "equality":
        return ["=", numbered(a[1], scope), numbered(a[2], scope)]
    return [a[0], numbered(a[2], (a[1],) + scope), numbered(a[3], (a[1],) + scope)]


def reference(a, env, formula):
    decoded = named_formula(a) if formula else named_term(a)
    return numbered(named_substitute(decoded,
        lambda i: named_term(env(i), space=("substitution", i))))


T = ["=", -1, -1]
E = ["=", -1, ["s", -1]]


def main():
    # A finite constructor matrix exercises all sort gates in the new walker.
    samples = [(-1, False), (5, False), (["s", 2], False),
               (["r", 0, -1, ["s", 0]], False), (T, True),
               (["pi", T, T], True), (["sig", T, T], True), (["false"], True)]
    for a, is_formula in samples:
        record("zero_shift_canonicalization_" + str(a), K.shift(a, 0, is_formula) == (E if a == ["false"] else a))
        try:
            K.shift(a, 0, not is_formula)
            wrong_sort = True
        except (ValueError, TypeError, IndexError, KeyError):
            wrong_sort = False
        record("reject_wrong_sort_" + str(a), not wrong_sort)

    malformed = [False, True, 0.0, -2, None, "s", {}, [], ["s"],
                 ["s", -1, -1], ["r", 0, -1], ["=", T, -1],
                 ["pi", -1, T], ["sig", T, ["s", -1]],
                 ["r", 0, -1, T], ["s", True], ["=", -1, 0.0],
                 ["=", ["false"], -1], ["r", 0, -1, ["false"]],
                 ["false", T], ["s", ["false"]]]
    for a in malformed:
        try:
            K.walk(a, lambda i, d: i + d)
            well_formed = True
        except (ValueError, TypeError, IndexError, KeyError):
            well_formed = False
        record("reject_malformed_walk_" + repr(a), not well_formed)

    # These include open parameters, nested recursion and both logical binders.
    binding_samples = [
        (-1, False),
        (["r", 2, 0, ["r", 1, 3, ["s", 4]]], False),
        (["r", ["s", 0], 1, ["r", 0, 1, ["r", 2, 4, ["s", 6]]]], False),
        (["pi", ["=", 0, 1], ["=", ["r", 0, 1, ["r", 1, 3, 5]], 1]], True),
        (["sig", ["=", 0, 2], ["pi", ["=", 1, 3], ["=", 4, ["r", 0, 3, 5]]]], True),
        (["pi", ["false"], ["sig", ["=", 1, 2], ["false"]]], True),
    ]
    witness = ["r", 1, ["s", 0], ["r", 0, 3, ["s", 4]]]
    environments = [
        ("shift_three", lambda i: i + 3),
        ("instantiate", lambda i: witness if i == 0 else i - 1),
        ("simultaneous_swap", lambda i: ["s", 1] if i == 0 else 0 if i == 1 else i),
    ]
    for j, (a, form) in enumerate(binding_samples):
        for name, env in environments:
            expected = reference(a, env, form)
            actual = K.shift(a, 3) if name == "shift_three" else K.inst(a, witness) if name == "instantiate" else K.subst(a, env)
            record(name + "_named_oracle_" + str(j), actual == expected)

    # Recursion leaf uses the preceding state and counter simultaneously.
    r = ["r", ["s", 0], 1, ["r", 0, 1, ["r", 2, 4, ["s", 6]]]]
    prior = ["r", 0, r[2], r[3]]
    expected_step = reference(r[3], lambda i: prior if i == 0 else 0 if i == 1 else i - 2, False)
    record("nested_recursion_successor_axiom", accepted([[], ["=", r, expected_step], ["rec", r]]))
    wrong_step = reference(r[3], lambda i: 0 if i == 0 else prior if i == 1 else i - 2, False)
    record("reject_swapped_recursion_slots", not accepted([[], ["=", r, wrong_step], ["rec", r]]))
    r0 = ["r", -1, 0, ["r", 1, 3, ["s", 4]]]
    record("recursion_base_with_open_parameters", accepted([[], ["=", r0, 0], ["rec", r0]]))
    bad_counter = ["r", 0, -1, 0]
    record("reject_recursion_axiom_at_variable", not accepted([[], T, ["rec", bad_counter]]))

    # Equality replacement under Pi and two recursion binders.
    template = ["pi", ["=", 0, 1], ["=", ["r", 0, 1, ["r", 1, 3, 5]], 1]]
    equation = ["=", 0, ["s", 0]]
    image = ["pi", ["=", 0, ["s", 1]],
             ["=", ["r", 0, ["s", 1], ["r", 1, ["s", 3], ["s", 5]]], ["s", 1]]]
    transport = [[equation, template], image, ["use", ["hyp", equation], template, ["hyp", template]]]
    record("transport_through_nested_binding", accepted(transport))
    wrong = copy.deepcopy(transport)
    wrong[1][2][1][3][3] = ["s", 4]
    record("reject_capture_in_transport_goal", not accepted(wrong))

    # Witness discharge and eigenvariable protection.
    local_eq = ["=", 0, 1]
    record("witness_equation_intro_open_parameter", accepted([[], ["sig", local_eq, local_eq],
           ["pair", 0, ["hyp", local_eq], ["hyp", local_eq]]]))
    sigma = ["sig", ["=", 0, 0], ["=", 0, 0]]
    parameter_eq = ["=", 0, 0]
    record("sigma_elimination_retains_parameter", accepted([[sigma, parameter_eq], parameter_eq,
           ["use", ["hyp", sigma], parameter_eq, ["hyp", ["=", 1, 1]]]]))
    record("reject_sigma_witness_escape", not accepted([[sigma, parameter_eq], parameter_eq,
           ["use", ["hyp", sigma], parameter_eq, ["hyp", ["=", 0, 0]]]]))
    pi = ["pi", T, T]
    record("pi_elimination_unused_valid_witness", accepted([[pi, T], T,
           ["use", ["hyp", pi], -1, ["hyp", T]]]))
    for bad in (["false"], True, 0.0, ["s", False]):
        record("reject_unused_bad_pi_witness_" + repr(bad), not accepted([[pi, T], T,
               ["use", ["hyp", pi], bad, ["hyp", T]]]))
    for key in (["=", False, 0.0], ["=", 0.0, 0.0], ["=", 0, True],
                None, {}, ["hyp", parameter_eq], ["=", 0], ["s", 0]):
        record("reject_malformed_hypothesis_key_" + repr(key),
               not accepted([[parameter_eq], parameter_eq, ["hyp", key]]))
    record("reject_alias_in_goal", not accepted([[parameter_eq], ["=", False, 0.0],
           ["hyp", parameter_eq]]))
    record("falsity_bridge_forward", accepted([[["false"]], E, ["hyp", E]]))
    record("falsity_bridge_backward", accepted([[E], ["false"], ["hyp", E]]))

    # Every formula-valued proof annotation normalizes surface falsity.
    record("false_in_hypothesis_key", accepted([[E], E, ["hyp", ["false"]]]))
    record("false_in_pi_guard", accepted([[], ["pi", ["false"], ["false"]],
           ["pi", ["false"], ["hyp", ["false"]]]]))
    record("false_in_equality_template", accepted([[equation, E], ["false"],
           ["use", ["hyp", equation], ["false"], ["hyp", ["false"]]]]))
    record("false_in_sigma_elimination_goal", accepted([[sigma, E], ["false"],
           ["use", ["hyp", sigma], ["false"], ["hyp", ["false"]]]]))
    record("false_in_pair_branches", accepted([[["false"]], ["sig", ["false"], ["false"]],
           ["pair", -1, ["hyp", ["false"]], ["hyp", ["false"]]]]))
    record("reject_false_as_witness", not accepted([[E], ["sig", E, E],
           ["pair", ["false"], ["hyp", E], ["hyp", E]]]))
    record("reject_false_in_recursion_body", not accepted([[], T,
           ["rec", ["r", -1, -1, ["false"]]]]))
    # Check actual inferred outputs, not only equality with a normalized goal.
    false_pi = K.infer(["pi", ["false"], ["hyp", ["false"]]], [])
    record("inferred_pi_is_canonical", false_pi == ["pi", E, E])
    record("inferred_sigma_goal_is_canonical", K.infer(
           ["use", ["hyp", sigma], ["false"], ["hyp", ["false"]]], [sigma, E]) == E)
    record("stored_hypothesis_returned", K.infer(["hyp", ["false"]], [E]) is E)

    # Arithmetic schema: equation induction versus non-equational cases.
    matrix = ["=", ["r", 0, 1, 1], 1]
    base2 = ["=", ["r", -1, 2, 1], 2]
    step2 = ["pi", ["=", ["r", 0, 3, 1], 3],
             ["=", ["r", ["s", 0], 3, 1], 3]]
    numerical = ["pi", ["sig", base2, step2], matrix]
    record("parameterized_equation_induction_schema", accepted([[], numerical, ["nat", matrix]]))
    composite = ["pi", T, ["=", 1, 1]]
    composite_base2 = ["pi", T, ["=", -1, -1]]
    composite_successor3 = ["pi", T, ["=", ["s", 1], ["s", 1]]]
    case_step = ["pi", composite_base2, composite_successor3]
    case_schema = ["pi", ["sig", composite_base2, case_step], composite]
    record("composite_matrix_gets_cases", accepted([[], case_schema, ["nat", composite]]))
    unrestricted = copy.deepcopy(case_schema)
    unrestricted[1][2][1] = composite
    record("reject_full_induction_for_composite", not accepted([[], unrestricted, ["nat", composite]]))

    false_schema = ["pi", ["sig", ["false"], ["pi", ["false"], ["false"]]], ["false"]]
    record("false_numerical_matrix", accepted([[], false_schema, ["nat", ["false"]]]))
    record("false_numerical_output_canonical", K.infer(["nat", ["false"]], []) ==
           ["pi", ["sig", E, ["pi", E, E]], E])
    record("reject_malformed_equality_template", not accepted([[equation, T], T,
           ["use", ["hyp", equation], ["=", False, False], ["hyp", T]]]))
    record("reject_malformed_sigma_goal", not accepted([[sigma, T], T,
           ["use", ["hyp", sigma], ["=", -1.0, -1], ["hyp", T]]]))

    # Top-level JSON boundary and optimized Python execution.
    with tempfile.TemporaryDirectory(prefix="ipra-walk-audit-") as tmp:
        cases = [("accept", [[], ["=", r0, 0], ["rec", r0]], True),
                 ("bad_boolean", [[parameter_eq], ["=", False, 0], ["hyp", parameter_eq]], False),
                 ("bad_envelope", {"a": [], "b": T, "c": ["hyp", T]}, False),
                 ("bad_scalar", None, False),
                 ("false", [[E], ["false"], ["hyp", ["false"]]], True),
                 ("bad_key_alias", [[parameter_eq], parameter_eq, ["hyp", ["=", False, 0]]], False)]
        for name, data, valid in cases:
            path = Path(tmp) / (name + ".json")
            path.write_text(json.dumps(data), encoding="utf-8")
            run = subprocess.run([sys.executable, "-O", str(TARGET), str(path)],
                                 text=True, capture_output=True, timeout=10)
            record("cli_optimized_" + name, run.returncode == (0 if valid else 1)
                   and run.stdout.strip() == ("ACCEPT" if valid else "REJECT")
                   and not run.stderr)


if __name__ == "__main__":
    try:
        main()
    finally:
        output = {"target": str(TARGET),
                  "target_sha256": hashlib.sha256(TARGET.read_bytes()).hexdigest(),
                  "passed": sum(r["passed"] for r in RESULTS),
                  "total": len(RESULTS), "results": RESULTS,
                  "limitations": "Finite regression checks plus source audit; no formal proof of Python semantics."}
        (HERE / "independent_results.json").write_text(json.dumps(output, indent=2) + "\n")
        print(json.dumps({"passed": output["passed"], "total": output["total"]}))
