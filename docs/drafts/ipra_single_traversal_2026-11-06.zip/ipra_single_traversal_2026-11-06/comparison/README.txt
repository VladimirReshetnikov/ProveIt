EXACT CURRENT SOURCE COMPARISON
===============================

The 33 files under sources/ are unchanged copies from the six ZIP archives
present in ProveIt/docs/drafts at commit:

  36fb791c722edc2549719744c38feef74fa422fb

Repository: https://github.com/VladimirReshetnikov/ProveIt

All original archive bytes were checked against their Git blob identifiers
and SHA-256 digests when retrieved. Every copied source was compared with
its exact original ZIP member. archive_manifest.json records the archives;
source_manifest.json records each member, current local copy, role and
SHA-256 digest. Attribution and source comments remain in every copied file.

The selection includes all six primary checkers plus the direct/native,
representation, interface and matched-control alternatives supplied by these
current reports. Draft3 controls/combined.py duplicates its primary, so the
33 entries contain 32 distinct byte sequences. The ablation controls in
draft5 are included even when they differ only in documentation: its
03_sentinel.py attains the smallest raw source size, 3,430 bytes. Historical
nested comparison collections have not been copied into this package.

Run from the deliverable root, with Python 3.10 or later:

  python3 comparison/measure.py

The script may also be invoked by absolute path from any directory. It
reads only files inside this deliverable. It parses code using ast and
tokenize; it never imports or executes a comparator or the new checker.
It verifies every supplied comparator hash before measuring it. The current
candidate code/checker.py is measured when present.

Generated files:

  verification/metrics.json   Full per-file metrics, envelope and candidate
  verification/metrics.tex   Checker/envelope macros for the report
  comparison/current_table.tex  Six primary rows, full envelope, candidate

All source modules are counted in full, including syntax validation,
substitution/binding, arithmetic data, rules, root statement validation,
falsity conversion, imports and JSON CLI. Python and its standard library
are a shared runtime excluded on every side. All supplied comparator
modules import only json and sys and have no local code dependencies.

Significant SOURCE tokens exclude comments, layout, and genuine module,
class and function docstrings. NORMALIZED tokens are counted separately
after removing those docstrings and running ast.unparse. These quantities
can differ because unparse changes parentheses and formatting; for example,
the compact checker has 981 source tokens and 989 normalized tokens.
Executable AST nodes omit only genuine docstrings. Normalized bytes are
UTF-8 bytes of ast.unparse plus a single final newline. Raw bytes retain
comments, documentation and formatting. The Python version is recorded.

Coordinate minima across these 33 complete supplied implementations:

  source tokens       957   draft4/checker.py
  normalized tokens   957   draft4/checker.py
  AST nodes          1013   draft4/checker.py
  normalized bytes   3127   draft1/checker.py
  raw bytes          3430   draft5/ablation/03_sentinel.py

supporting_inventory_summary.json separately records a broader static scan
of 233 standalone source occurrences / 76 unique source files across all
six archives, including historical embedded copies. Its envelope was the
same. That scan used a simple check-function/JSON-CLI/import heuristic; it
is supporting inventory evidence only. It is not an independent soundness
proof, an exhaustive multi-file dependency-closure analysis, or an absolute
program-size lower bound. Reproducing that broader scan requires the pinned
original archives; the exact 33-file comparison above is fully offline.
