"""Recount complete, immutable checker sources without executing any checker.

Run from any directory with Python 3.10 or later:
    python3 comparison/measure.py

Only this counter and Python's standard library are executed. The comparator
programs and candidate are read as UTF-8 and processed with ast/tokenize.
"""

import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize


ROOT = Path(__file__).resolve().parents[1]
AXES = (
    "significant_source_tokens",
    "normalized_python_tokens",
    "ast_nodes_without_docstrings",
    "normalized_utf8_bytes",
    "raw_utf8_bytes",
)
IGNORED = {
    tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
    tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
}
OWNERS = (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)


def local_file(relative):
    """All measured inputs must be files inside this deliverable."""
    path = (ROOT / relative).resolve()
    if not path.is_relative_to(ROOT):
        raise ValueError("Path escapes deliverable: " + str(relative))
    return path


def is_docstring_owner(node):
    return (isinstance(node, OWNERS) and node.body
            and isinstance(node.body[0], ast.Expr)
            and isinstance(node.body[0].value, ast.Constant)
            and isinstance(node.body[0].value.value, str))


def measure(path):
    raw = path.read_bytes()
    source = raw.decode("utf-8")
    tree = ast.parse(source)
    spans = []
    for node in list(ast.walk(tree)):
        if is_docstring_owner(node):
            doc = node.body.pop(0)
            spans.append(((doc.lineno, doc.col_offset),
                          (doc.end_lineno, doc.end_col_offset)))
    source_tokens = [
        token for token in tokenize.generate_tokens(io.StringIO(source).readline)
        if token.type not in IGNORED
        and not any(lo <= token.start and token.end <= hi for lo, hi in spans)
    ]
    normalized = ast.unparse(tree) + "\n"
    normalized_tokens = [
        token for token in tokenize.generate_tokens(io.StringIO(normalized).readline)
        if token.type not in IGNORED
    ]
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.append("." * node.level + (node.module or ""))
    return {
        "raw_utf8_bytes": len(raw),
        "normalized_utf8_bytes": len(normalized.encode("utf-8")),
        "significant_source_tokens": len(source_tokens),
        "normalized_python_tokens": len(normalized_tokens),
        "significant_token_characters": sum(len(t.string) for t in source_tokens),
        "ast_nodes_without_docstrings": sum(1 for _ in ast.walk(tree)),
        "physical_lines": len(source.splitlines()),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "imports": imports,
    }


def coordinate_minima(rows):
    return {
        axis: {
            "value": min(row["metrics"][axis] for row in rows),
            "attained_by": [
                row["source_path"] for row in rows
                if row["metrics"][axis]
                == min(item["metrics"][axis] for item in rows)
            ],
        }
        for axis in AXES
    }


def table_row(label, metrics, bold=False):
    cells = [label, *(f"{metrics[axis]:,}" for axis in AXES)]
    if bold:
        cells = [r"\textbf{" + cell + "}" for cell in cells]
    return " & ".join(cells) + r" \\"


def main():
    manifest_path = local_file("comparison/source_manifest.json")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    rows = []
    for entry in manifest["source_entries"]:
        counts = measure(local_file(entry["source_path"]))
        if counts["sha256"] != entry["sha256"]:
            raise ValueError("Comparator source changed: " + entry["source_path"])
        if sorted(counts["imports"]) != ["json", "sys"]:
            raise ValueError("Unexpected comparator dependencies: " + entry["source_path"])
        rows.append({**entry, "metrics": counts})
    if len(rows) != manifest["source_entry_count"]:
        raise ValueError("Source manifest count mismatch")
    principal = sorted((row for row in rows if row["primary"]),
                       key=lambda row: row["draft_index"])
    if len(principal) != 6:
        raise ValueError("Expected the six pinned primary checkers")
    envelope = coordinate_minima(rows)
    minima = {axis: envelope[axis]["value"] for axis in AXES}
    candidate_path = local_file("code/checker.py")
    candidate = measure(candidate_path) if candidate_path.is_file() else None
    savings = None if candidate is None else {
        axis: {
            "absolute": minima[axis] - candidate[axis],
            "percent": round(100 * (minima[axis] - candidate[axis]) / minima[axis], 6),
        }
        for axis in AXES
    }
    method = (
        "Count each entire standalone checker module, including arithmetic data, "
        "syntax/formation checking, binding/substitution, proof inference, surface "
        "conversion, public statement validation, imports and JSON CLI. Python and "
        "its standard library are the common excluded runtime. Source tokens omit "
        "comments, layout and true module/class/function docstrings. Executable AST "
        "nodes omit only those docstrings. Normalized tokens/bytes use ast.unparse "
        "followed by one newline. No checker or comparator is imported or executed."
    )
    result = {
        "python_version": platform.python_version(),
        "repository": manifest["repository"],
        "repository_commit": manifest["commit"],
        "method": method,
        "source_manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
        "source_entries": len(rows),
        "unique_comparator_source_files": len({row["sha256"] for row in rows}),
        "all_comparator_source_hashes_verified": True,
        "all_comparators_import_only_json_and_sys": True,
        "coordinate_minima": envelope,
        "primary_coordinate_minima": coordinate_minima(principal),
        "candidate": candidate,
        "candidate_path": "code/checker.py" if candidate is not None else None,
        "candidate_savings_against_coordinate_minima": savings,
        "candidate_strictly_below_every_coordinate": (
            None if candidate is None else all(candidate[axis] < minima[axis] for axis in AXES)
        ),
        "comparators": rows,
        "limitations": (
            "An observed envelope of complete supplied source implementations, not "
            "an absolute program-size lower bound. Coordinate minima can be attained "
            "by different programs. Raw bytes depend on comments/layout. Static "
            "source measurements neither establish checker soundness nor quantify "
            "proof length, runtime, or the size of Python's common runtime. The "
            "broader 233-occurrence inventory is supporting evidence only and is "
            "not silently substituted for this exact offline corpus."
        ),
    }
    output = local_file("verification")
    output.mkdir(exist_ok=True)
    (output / "metrics.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    macros = {
        "EnvelopeTokens": minima["significant_source_tokens"],
        "EnvelopeAST": minima["ast_nodes_without_docstrings"],
        "EnvelopeNormalizedBytes": minima["normalized_utf8_bytes"],
        "EnvelopeRawBytes": minima["raw_utf8_bytes"],
    }
    if candidate is not None:
        macros.update({
            "CheckerTokens": candidate["significant_source_tokens"],
            "CheckerNormalizedTokens": candidate["normalized_python_tokens"],
            "CheckerAST": candidate["ast_nodes_without_docstrings"],
            "CheckerNormalizedBytes": candidate["normalized_utf8_bytes"],
            "CheckerRawBytes": candidate["raw_utf8_bytes"],
        })
    (output / "metrics.tex").write_text("".join(
        "\\newcommand{\\" + name + "}{" + str(value) + "}\n"
        for name, value in macros.items()), encoding="utf-8")
    lines = [
        r"\begin{tabular}{@{}lrrrrr@{}}",
        r"\toprule",
        r"Complete checker & Tokens & Norm. tokens & AST & Norm. bytes & Raw bytes \\",
        r"\midrule",
        *(table_row(row["label"], row["metrics"]) for row in principal),
        r"\midrule",
        table_row("All 33: coordinate minima", minima),
    ]
    if candidate is not None:
        lines.append(table_row("This checker", candidate, bold=True))
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    local_file("comparison/current_table.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({
        "comparators": len(rows),
        "unique_source_files": result["unique_comparator_source_files"],
        "all_comparator_hashes_verified": True,
        "coordinate_minima": minima,
        "candidate": candidate,
        "strictly_below_every_coordinate": result["candidate_strictly_below_every_coordinate"],
    }, indent=2))


if __name__ == "__main__":
    main()
