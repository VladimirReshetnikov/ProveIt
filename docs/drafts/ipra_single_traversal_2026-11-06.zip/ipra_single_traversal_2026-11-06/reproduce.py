"""Reproduce the complete source comparison and both finite audit suites."""
from pathlib import Path
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    for relative in ("comparison/measure.py", "verification/design_audit.py",
                     "verification/independent_audit.py"):
        subprocess.run([sys.executable, str(ROOT / relative)], cwd=ROOT,
                       check=True)
    design = json.loads((ROOT / "verification/design_audit_results.json").read_text())
    independent = json.loads((ROOT / "verification/independent_results.json").read_text())
    if not design["all_passed"] or independent["passed"] != independent["total"]:
        raise RuntimeError("audit failed")
    summary = {
        "all_passed": True,
        "candidate_sha256": design["candidate_sha256"],
        "accepted_source_certificates": design["adapter_accepted_outputs"],
        "rejected_source_certificates": design["adapter_rejected_source_inputs"],
        "formation_comparisons": design["independent_formation_and_canonicalization_cases"],
        "independent_audit_passed": independent["passed"],
        "independent_audit_total": independent["total"],
        "python_version": sys.version,
        "qualification": "Finite executable evidence plus written general proofs; no formal verification of Python semantics."
    }
    (ROOT / "verification/summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
