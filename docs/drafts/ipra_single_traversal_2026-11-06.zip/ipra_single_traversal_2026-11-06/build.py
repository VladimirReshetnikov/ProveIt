"""Reproduce checks, compile the report, and create the distributable ZIP."""
from pathlib import Path
import argparse
import hashlib
import os
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent


def deliverables():
    return sorted(p for p in ROOT.rglob("*") if p.is_file()
                  and not {"build", "__pycache__"}.intersection(p.relative_to(ROOT).parts)
                  and p.suffix not in {".pyc", ".aux", ".log", ".toc", ".out"}
                  and p.name != "SHA256SUMS.txt")


def package():
    files = deliverables()
    checksum = ROOT / "SHA256SUMS.txt"
    checksum.write_text("".join(hashlib.sha256(p.read_bytes()).hexdigest() + "  "
                               + p.relative_to(ROOT).as_posix() + "\n" for p in files))
    archive = ROOT.with_suffix(".zip")
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in files + [checksum]:
            z.write(path, ROOT.name + "/" + path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(archive) as z:
        bad = z.testzip()
        if bad:
            raise RuntimeError("Corrupt archive member: " + bad)
    print(archive)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-tests", action="store_true")
    parser.add_argument("--package-only", action="store_true")
    args = parser.parse_args()
    if args.package_only:
        package()
        return
    if not args.skip_tests:
        subprocess.run([sys.executable, str(ROOT / "reproduce.py")], cwd=ROOT, check=True)
    build = ROOT / "build"
    build.mkdir(exist_ok=True)
    env = os.environ.copy()
    probe = subprocess.run(["kpsewhich", "pdflatex.fmt"], cwd=build,
                           capture_output=True, text=True)
    if not probe.stdout.strip() and not (build / "pdflatex.fmt").exists():
        with (build / "format_creation.txt").open("w") as log:
            subprocess.run(["pdftex", "-ini", "-etex", "-jobname=pdflatex",
                            "-progname=pdflatex", "pdflatex.ini"], cwd=build,
                           stdout=log, stderr=subprocess.STDOUT, check=True)
    if (build / "pdflatex.fmt").exists():
        env["TEXFORMATS"] = str(build) + os.pathsep + env.get("TEXFORMATS", "")
    for i in range(3):
        result = subprocess.run(["pdflatex", "-no-shell-escape", "-interaction=nonstopmode",
                                 "-halt-on-error", "-output-directory=" + str(build),
                                 "report.tex"], cwd=ROOT, env=env,
                                capture_output=True, text=True)
        (build / ("pass" + str(i + 1) + ".txt")).write_text(result.stdout + result.stderr)
        if result.returncode:
            print(result.stdout[-12000:])
            raise RuntimeError("LaTeX compilation failed")
    log = (build / "report.log").read_text()
    bad = [line for line in log.splitlines() if "Overfull" in line or
           "undefined references" in line or "undefined citations" in line or
           ("LaTeX Warning: Reference" in line and "undefined" in line)]
    if bad:
        print("\n".join(bad))
        raise RuntimeError("Resolve layout/reference issues before packaging")
    shutil.copyfile(build / "report.pdf", ROOT / "report.pdf")
    package()


if __name__ == "__main__":
    main()
