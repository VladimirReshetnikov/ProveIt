"""Compile the editable report using pdfLaTeX, keeping logs in results/."""
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    for number in range(1, 4):
        run = subprocess.run(['pdflatex', '-interaction=nonstopmode',
                              '-halt-on-error', 'report.tex'],
                             cwd=ROOT, capture_output=True, text=True)
        (ROOT / 'results' / f'latex_pass_{number}.log').write_text(run.stdout + run.stderr)
        if run.returncode:
            raise RuntimeError(f'LaTeX pass {number} failed; inspect its results log')
    log = (ROOT / 'report.log').read_text(errors='replace')
    errors = [line for line in log.splitlines()
              if ('Overfull' in line or 'undefined' in line.lower()
                  or 'multiply defined' in line.lower())]
    receipt = {'status': 'PASS' if not errors else 'REVIEW',
               'layout_or_reference_warnings': errors,
               'pdf_bytes': (ROOT / 'report.pdf').stat().st_size}
    (ROOT / 'results/build.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
