"""Reproduce whole-program metrics and generate the report's exact tables."""
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def main():
    spec = importlib.util.spec_from_file_location(
        'frozen_measure', ROOT / 'comparison/source_measure.py')
    measure = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(measure)
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    rows = []
    for entry in manifest['programs']:
        path = ROOT / 'comparison' / entry['local_file']
        result = measure.metrics(path)
        if result['sha256'] != entry['sha256']:
            raise ValueError('Changed comparator: ' + entry['label'])
        rows.append({**entry, **result})
    candidate = measure.metrics(ROOT / 'checker.py')
    minimum = {key: min(row[key] for row in rows) for key in KEYS}
    if not all(candidate[key] < minimum[key] for key in KEYS):
        raise AssertionError('The candidate no longer beats every coordinate minimum')
    result = {'python': platform.python_version(),
              'repository': manifest['repository'], 'commit': manifest['commit'],
              'archive_count': len(manifest['archives']), 'program_count': len(rows),
              'boundary': 'Complete standalone source, including I/O and rejection.',
              'normalizer_sha256': hashlib.sha256(
                  (ROOT / 'comparison/source_measure.py').read_bytes()).hexdigest(),
              'coordinatewise_minima': minimum, 'candidate': candidate, 'programs': rows}
    (ROOT / 'results/measurements.json').write_text(json.dumps(result, indent=2) + '\n')
    names = {'ipra_arithmetic_scopes_2026-11-07': 'Arithmetic scopes',
             'ipra_arity_scopes_2026-11-07': 'Arity scopes',
             'ipra_compact_kernel_2026-11-07': 'Compact kernel',
             'ipra_permanent_zero_2026-11-07': 'Permanent zero',
             'ipra_validated_erasure_2026-11-07': 'Validated erasure'}
    lines = [r'\begin{center}\small', r'\begin{tabular}{@{}llrrr@{}}',
             r'\toprule', r'Active archive & Root program & Tokens & AST & Bytes\\',
             r'\midrule']
    for row in rows:
        parent, file = row['label'].split('/')
        lines.append(names[parent] + ' & \\texttt{' + file.replace('_', r'\_') +
                     '} & ' + ' & '.join(str(row[key]) for key in KEYS) + r'\\')
    lines += [r'\midrule', r'New fixed contexts & \texttt{checker.py} & ' +
              ' & '.join(str(candidate[key]) for key in KEYS) + r'\\',
              r'\bottomrule', r'\end{tabular}\end{center}']
    (ROOT / 'results/comparison_table.tex').write_text('\n'.join(lines) + '\n')
    run = subprocess.run([sys.executable, str(ROOT / 'comparison/controls.py')],
                         capture_output=True, text=True, check=True)
    (ROOT / 'results/controls.log').write_text(run.stdout)
    controls = json.loads((ROOT / 'results/controls.json').read_text())
    labels = {'delivered': 'Delivered', 'common_driver': 'Common driver',
              'common_helper_names': 'Common helper names',
              'common_driver_names_success': 'Driver, names, success literal',
              'common_driver_short_names_success': 'Same, short helper names',
              'common_driver_descriptive_names_success': 'Same, descriptive helper names'}
    lines = [r'\begin{center}\small', r'\begin{tabular}{@{}lrr@{}}',
             r'\toprule', r'Control & Old minima (tokens/AST/bytes) & Candidate\\',
             r'\midrule']
    for name, profile in controls['profiles'].items():
        if not all(profile['strictly_below_each_minimum'].values()):
            raise AssertionError('Failed common control: ' + name)
        old = '/'.join(str(profile['coordinate_minima'][key]) for key in KEYS)
        new = '/'.join(str(profile['candidate'][key]) for key in KEYS)
        lines.append(labels[name] + ' & ' + old + ' & ' + new + r'\\')
    lines += [r'\bottomrule', r'\end{tabular}\end{center}']
    (ROOT / 'results/controls_table.tex').write_text('\n'.join(lines) + '\n')
    print(json.dumps({'candidate': {k: candidate[k] for k in KEYS},
                      'active_minima': minimum, 'all_controls_pass': True}, indent=2))


if __name__ == '__main__':
    main()
