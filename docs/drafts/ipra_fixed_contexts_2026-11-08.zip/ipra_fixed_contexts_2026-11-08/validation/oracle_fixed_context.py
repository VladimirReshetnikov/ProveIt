"""Independent named-rule checker for the fixed-width-context presentation.

This validation interpreter uses distinct numerical and formula traversals,
explicit protected-variable counts, and named logical rules.  It imports
no acceptance kernel and uses neither its packed depth table nor match
dispatch.  Adapted from the independently written oracle_erasure.py in
ipra_compact_kernel_2026-11-07, with two specified changes: formula scalar
labels retain their in-range spelling, and paired introduction always
adds [base, equation-or-truth].  The inherited provenance and MIT license
are preserved by the parent archive.
"""
from copy import deepcopy


class Oracle:
    def __init__(self):
        self.lower = 0
        self.rules = {}

    def record(self, name):
        self.rules[name] = self.rules.get(name, 0) + 1

    def term(self, value, image=None, protected=0):
        if type(value) is not list:
            if self.lower <= value < 2 * protected + 1:
                return value
            return self.term(image)
        if not value:
            return []
        if len(value) == 1:
            return [self.term(value[0], image, protected + 1)]
        if len(value) == 2:
            return [self.formula(child, image, protected + 1)
                    for child in value]
        if len(value) == 3:
            return [self.term(child, image, protected + 2)
                    for child in value]
        raise ValueError('term arity')

    def formula(self, value, image=None, protected=0):
        if type(value) is not list:
            if self.lower <= value < 2 * protected:
                return value
            return 0
        if not value:
            return []
        if len(value) == 1:
            return [self.formula(value[0], image, protected + 1)]
        if len(value) == 2:
            return [self.term(child, image, protected) for child in value]
        if len(value) == 3:
            return [self.formula(child, image, protected + 2)
                    for child in value]
        raise ValueError('formula arity')

    def fresh(self):
        self.lower -= 1
        return self.lower

    def check(self, goal, context):
        checked = self.formula(goal)
        if checked in context:
            self.record('hypothesis')
            if type(checked) is not list:
                self.record('truth_hypothesis')
            return True
        instruction = self.stack.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            if self.check(major, context):
                if type(major) is not list:
                    self.record('rejected_scalar_major')
                    raise ValueError('a scalar truth cannot be eliminated')
                if len(major) == 3:
                    self.record('paired_elimination')
                    eigen = self.fresh()
                    assumption = self.formula([major[2]], eigen)
                    return self.check(self.formula(goal, [eigen]),
                                      context + [assumption])
                if len(major) == 1:
                    self.record('closure_elimination')
                    matrix, left, right = major[0], 0, annotation
                elif len(major) == 2:
                    self.record('equality_transport')
                    matrix = annotation
                    left, right = major
                else:
                    raise ValueError('major arity')
                if self.formula(matrix, right) != goal:
                    return False
                return self.check(self.formula(matrix, left), context)
            self.record('failed_major_fallthrough')
        if type(instruction) is list and not instruction:
            if type(goal) is not list or len(goal) != 2:
                raise ValueError('computation requires equality')
            term, right = goal
            if type(term) is not list or len(term) != 3:
                raise ValueError('computation requires ternary iterator')
            count, initial, update = term
            if not count:
                expected = initial
                self.record('computation_zero')
            elif type(count) is list and len(count) == 1:
                expected = self.term(update, [count[0], initial, update])
                self.record('computation_successor')
            else:
                raise ValueError('counter shape')
            return right == expected
        if type(goal) is not list or len(goal) != 3:
            raise ValueError('paired introduction shape')
        self.record('paired_introduction')
        matrix = self.formula(goal[2], instruction, 1)
        base = self.formula(matrix, 0)
        if type(matrix) is not list:
            raise ValueError('scalar introduction matrix')
        if len(matrix) in (0, 2):
            hypothesis = matrix
            self.record('equation_induction')
        else:
            hypothesis = 1
            self.record('truth_completed_context')
        eigen = self.fresh()
        conclusion = self.formula(matrix, [eigen])
        hypotheses = [self.formula(base, eigen),
                      self.formula(hypothesis, eigen)]
        return self.check(conclusion, context + hypotheses)

    def run(self, packet):
        self.lower = 0
        self.rules = {}
        self.stack = deepcopy(packet)
        try:
            accepted = bool(self.check(self.stack.pop(), []))
            error = None
        except Exception as exc:
            accepted = False
            error = type(exc).__name__
        return {'accepted': accepted, 'final_k': self.lower,
                'remaining': len(self.stack) if type(self.stack) is list else None,
                'rules': dict(self.rules), 'error': error}
