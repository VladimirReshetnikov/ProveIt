"""Finite differential and adversarial evidence for the fixed-context checker.

Usage: python3 validate_fixed_context.py [path/to/checker.py]
The reference interpreter has separate term/formula traversals and named
rules.  Neither it nor this runner is imported by the acceptance program.
This is bounded test evidence, not a formal soundness proof.
"""
import ast
from collections import Counter
from copy import deepcopy
import hashlib
import itertools
import json
from pathlib import Path
import random
import subprocess
import sys

from oracle_fixed_context import Oracle

ROOT = Path(__file__).resolve().parent
CANDIDATE = (Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else
             ROOT.parent / 'checker.py')
SEED = 20261108


def definitions(source, label):
    tree = ast.parse(source)
    tree.body = [node for node in tree.body if isinstance(
        node, (ast.Import, ast.ImportFrom, ast.Assign, ast.FunctionDef))]
    namespace = {}
    exec(compile(tree, label, 'exec'), namespace)
    return namespace


def production(namespace, packet):
    namespace['k'] = 0
    stack = deepcopy(packet)
    try:
        namespace['take'] = stack.pop
        accepted = bool(namespace['check'](stack.pop(), []))
    except Exception:
        accepted = False
    return accepted, namespace['k'], len(stack) if type(stack) is list else None


def denotation(term, environment=(), budget=None):
    """Ground numerical meaning using environments, without substitution."""
    import math
    if budget is None:
        budget = [20000]
    budget[0] -= 1
    if budget[0] < 0:
        raise OverflowError('test evaluator bound')
    if type(term) is not list:
        index = math.floor(term)
        if index == 0:
            return 0
        if index < 0:
            raise ValueError('ground denotation has a free parameter')
        return environment[(index - 1) // 2]
    if len(term) in (0, 2):
        return 0
    if len(term) == 1:
        return 1 + denotation(term[0], (0,) + environment, budget)
    if len(term) != 3:
        raise ValueError('term arity')
    count, initial, update = term
    count = denotation(count, (0, 0) + environment, budget)
    value = denotation(initial, (0, 0) + environment, budget)
    if count > 100:
        raise OverflowError('test counter bound')
    for _ in range(count):
        value = denotation(update, (value, value) + environment, budget)
    return value


def main():
    source = CANDIDATE.read_text()
    namespace = definitions(source, str(CANDIDATE))
    oracle = Oracle()
    randomizer = random.Random(SEED)
    fixture_data = json.loads((ROOT / 'fixtures' / 'positive_certificates.json').read_text())
    fixtures = fixture_data['records']
    focused = json.loads((ROOT / 'fixtures' / 'focused_star_packets.json').read_text())
    non_atomic = json.loads((ROOT / 'fixtures' / 'non_atomic_induction_attempt.json').read_text())
    comparisons = Counter()
    rule_counts = Counter()
    accepted = Counter()
    named_results = []

    def compare(packet, cohort, name=None, expected=None):
        actual = production(namespace, packet)
        reference = oracle.run(packet)
        target = (reference['accepted'], reference['final_k'], reference['remaining'])
        if actual != target:
            raise AssertionError(('oracle disagreement', cohort, name, actual, target, packet))
        if expected is not None and actual[0] != expected:
            raise AssertionError(('unexpected verdict', cohort, name, actual, expected, packet))
        comparisons[cohort] += 1
        accepted[cohort] += actual[0]
        rule_counts.update(reference['rules'])
        if name is not None:
            named_results.append({'cohort': cohort, 'name': name,
                                  'accepted': actual[0], 'final_k': actual[1],
                                  'remaining': actual[2], 'rules': reference['rules']})
        return actual[0]

    for record in fixtures:
        compare(record['packet'], 'inherited_positive', record['name'], True)
    for record in focused:
        compare(record['packet'], 'inherited_boundary', record['name'],
                record['expected']['retained'])
    compare(non_atomic, 'induction_guard', 'non_atomic_induction_attempt', False)

    # This enclosing compound DI puts a scalar truth in its local context.
    # A numeric major can now prove that truth by Hyp; slicing it must fail.
    scalar_majors = [0, 1, 2, False, True, -2, 0.5, 1e100,
                     float('inf'), float('-inf'), float('nan')]
    for major in scalar_majors:
        packet = [[major, 0], 0, [0, 0, [[3, 3]]]]
        compare(packet, 'scalar_major', repr(major), False)
        if oracle.rules.get('rejected_scalar_major') != 1:
            raise AssertionError(('scalar major did not reach its intended boundary', major))
    for major in [None, '', 'x', 'ab', 'abc', {}, {'': 1}, [], [0], [0, 0]]:
        compare([[major, 0], 0, [0, 0, [[3, 3]]]],
                'malformed_major', repr(major), False)

    # Every old proof stack is also tried with an explicitly false goal.
    for index, record in enumerate(fixtures):
        compare(record['packet'][:-1] + [[0, [0]]], 'false_goal', expected=False)

    # Ground computation probes are additionally checked by numerical value,
    # using a direct evaluator without the opener or proof rules.
    counters = [0, [], False, [0], [[0]], [[[0]]], [1], [3], [5], [6], [0, 0]]
    initials = [0, [], [0], [[0]], 0.25, [0, 0]]
    updates = [0, [], 1, 3, [0], [3], [5], [0, 0]]
    right_sides = [0, [], [0], [[0]], [[[0]]], 0.25, [0, 0]]
    true_computations = 0
    for count, initial, update, right in itertools.product(
            counters, initials, updates, right_sides):
        equation = [[count, initial, update], right]
        if compare([[], equation], 'ground_computation'):
            if denotation(equation[0]) != denotation(equation[1]):
                raise AssertionError(('false ground equation accepted', equation))
            true_computations += 1

    leaves = [-4, -2, -1, 0, 1, 2, 3, 4, 7, True, False,
              None, '', 'a', 'abc', {}, {'': 0}, .5, -1.5]

    def tree(depth=3):
        if not depth or randomizer.randrange(3) == 0:
            return deepcopy(randomizer.choice(leaves))
        return [tree(depth - 1) for _ in range(randomizer.randrange(6))]

    for _ in range(12500):
        compare([tree(2) for _ in range(randomizer.randrange(9))], 'random_packet')
    for record in fixtures:
        for _ in range(24):
            packet = deepcopy(record['packet'])
            packet[randomizer.randrange(len(packet))] = tree(3)
            compare(packet, 'mutated_positive')

    # The targeted induction test must fail if the restriction is intact
    # and succeed when it is deliberately removed. This demonstrates that
    # the fixture exercises the relevant logical premise, not only syntax.
    mutant_source = source.replace('len(a) % 2 or a', 'a')
    if mutant_source == source:
        raise AssertionError('induction mutation target missing')
    mutant = definitions(mutant_source, 'deliberately_invalid_full_induction')
    if not production(mutant, non_atomic)[0]:
        raise AssertionError('induction fixture did not kill unrestricted-induction mutant')

    stdin_checks = []
    for name, packet, expected in [
        ('zero_computation', [[], [[0, 0, 0], 0]], True),
        ('false_equation', [[], [0, [0]]], False),
        ('scalar_major', [[0, 0], 0, [0, 0, [[3, 3]]]], False),
    ]:
        run = subprocess.run([sys.executable, str(CANDIDATE)],
                             input=json.dumps(packet), text=True,
                             capture_output=True, timeout=10)
        if (run.returncode == 0) != expected:
            raise AssertionError(('stdin exit', name, run.returncode, run.stdout, run.stderr))
        if run.stdout.strip() != ('ACCEPT' if expected else 'REJECT'):
            raise AssertionError(('stdin output', name, run.stdout))
        stdin_checks.append({'name': name, 'exit_code': run.returncode,
                             'output': run.stdout.strip()})

    receipt = {
        'status': 'PASS', 'candidate_sha256': hashlib.sha256(CANDIDATE.read_bytes()).hexdigest(),
        'oracle_sha256': hashlib.sha256((ROOT / 'oracle_fixed_context.py').read_bytes()).hexdigest(),
        'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'seed': SEED, 'compared': ['acceptance', 'final_parameter_floor', 'remaining_packet_cells'],
        'packet_comparisons': sum(comparisons.values()),
        'cohort_comparisons': dict(comparisons), 'cohort_acceptances': dict(accepted),
        'rule_events': dict(rule_counts), 'accepted_ground_computations_semantically_checked': true_computations,
        'unrestricted_induction_mutant_killed': True, 'stdin_checks': stdin_checks,
        'limits': 'Finite validation only; no claim of exact packet equivalence with earlier checkers.'}
    (ROOT / 'validation_results.json').write_text(json.dumps(receipt, indent=2) + '\n')
    (ROOT / 'named_results.json').write_text(json.dumps(named_results, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
