"""Reproduce comparisons, validation, and generated report data offline."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    results = {}
    for name, command in [
        ('measurements', [sys.executable, str(ROOT / 'measure.py')]),
        ('validation', [sys.executable, str(ROOT / 'validation/validate_fixed_context.py')])
    ]:
        run = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
        (ROOT / 'results' / (name + '.log')).write_text(run.stdout + run.stderr)
        if run.returncode:
            raise RuntimeError(name + ' failed; see results/' + name + '.log')
        results[name] = 'PASS'
    validation = json.loads((ROOT / 'validation/validation_results.json').read_text())
    controls = json.loads((ROOT / 'results/controls.json').read_text())
    result = {'status': 'PASS', 'candidate_sha256': validation['candidate_sha256'],
              'packet_comparisons': validation['packet_comparisons'],
              'control_profiles': len(controls['profiles']), 'stages': results}
    (ROOT / 'results/reproduction.json').write_text(json.dumps(result, indent=2) + '\n')
    summary = (
        'The independent named-rule interpreter and the delivered kernel agree on '
        + f"\\textbf{{{validation['packet_comparisons']:,}}} complete packet comparisons, "
        'checking acceptance, the final fresh-name floor, and the remaining '
        'instruction cells. The suite includes all 147 inherited positive '
        'certificates, 147 replacements by an explicitly false goal, 11 scalar '
        'major attacks against the new truth hypothesis, and 10 malformed '
        'major attacks. It also includes 3,696 ground computation probes, '
        'of which 312 accepted equations are checked by a separate numerical '
        'evaluator, 12,500 randomized packets, and 3,528 mutations of positive '
        'certificates. A targeted compound-induction certificate rejects in '
        'the real checker but accepts in a deliberately weakened checker '
        'that grants induction to all matrices. Three real stdin executions '
        'check acceptance, rejection, and scalar-major rejection. '
        'All checks passed.\\par\n')
    (ROOT / 'results/validation_summary.tex').write_text(summary)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
