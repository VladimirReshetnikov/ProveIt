FIXED-WIDTH LOCAL CONTEXTS FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov, 8 November 2026.

START WITH report.pdf. Its complete editable source is report.tex,
sections/, appendices/, and the generated results/*.tex tables.

RESULT
At ProveIt commit ce3371c9025b5c0ba12543acc2e6475d13ff7a3c, the five
active draft archives contain ten root checker programs. Their normalized
coordinatewise minima are 328 Python tokens / 356 AST nodes / 957 bytes.
This complete checker measures 325 / 355 / 953. With a common driver,
helper names, and success literal, the old byte minimum becomes 954;
the candidate remains strictly smaller in all three coordinates.

This is a modest implementation reduction, not a new arithmetic axiom
basis, a global minimality theorem, or a claimed foundational breakthrough.
The rule change always retains two introduction hypotheses: the base,
and either the literal-equation induction hypothesis or a proved truth.
The language, native formulas, and two interpretation composites are
preserved. The report explicitly gives all logical and nonlogical rules,
the full intuitionistic reconstruction, internal scalar arithmetic, and
whole-domain bi-interpretability and equiconsistency with iPRA.

TRUSTED ACCEPTANCE PROGRAM
  python3 checker.py < examples/zero_computation.json

The checker reads one JSON list. The last entry is the closed goal;
preceding entries are consumed in reverse order as proof instructions.
ACCEPT exits 0; REJECT exits 1. All project-specific trusted code is in
checker.py. Python 3.10+ and its standard library suffice to run it.
Exact reported source metrics were obtained with Python 3.12.14.

REPRODUCE OFFLINE
  python3 reproduce.py
  python3 build.py
  python3 package.py

The first command remeasures all ten frozen comparators, repeats six
fairness controls, and checks 20,052 complete packets against a separate
named-rule oracle. It also verifies ground computations, targeted scalar
major attacks, and an induction-guard mutation. The second command needs
pdfLaTeX and the packages declared in report.tex. The third creates a ZIP
with checksums. No command downloads dependencies or contacts a service.

FILES
  report.tex / report.pdf       Full editable paper and compiled PDF
  checker.py                   Complete, measured acceptance program
  sections/ / appendices/       Full mathematical proofs
  comparison/baselines/         Ten unchanged active root checker programs
  comparison/manifest.json     Pinned archive identities and source hashes
  comparison/source_measure.py Unchanged inherited normalizer
  comparison/controls.py       Independent whole-program fairness controls
  validation/                  Separate named-rule oracle, test runner, fixtures
  examples/                    Public accepted and rejected proof packets
  results/                     Measurements, controls, validation/build receipts
  ATTRIBUTION.txt               Exact new/inherited contribution boundary
  LICENSE-inherited.txt         Permission for the inherited code and proofs
  SHA256SUMS.txt                Archive content checksums

LIMITS
Finite tests are implementation evidence, not proof-assistant verification.
Completeness is understood with sufficient finite execution resources.
No raw-packet acceptance equivalence with all earlier checkers is claimed.
The program-size improvement is strict but small; further research questions
and a failed stronger simplification are included in the report.
