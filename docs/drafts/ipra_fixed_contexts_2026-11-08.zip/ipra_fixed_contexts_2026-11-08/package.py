"""Create a reproducible source/PDF/code archive with content checksums."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED = {'.aux', '.log', '.out', '.toc', '.pyc'}


def main():
    files = [p for p in ROOT.rglob('*') if p.is_file()
             and '__pycache__' not in p.parts and 'controls' not in p.relative_to(ROOT).parts
             and p.suffix not in EXCLUDED and p.name != 'SHA256SUMS.txt']
    files.sort()
    manifest = '\n'.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' +
                         p.relative_to(ROOT).as_posix() for p in files) + '\n'
    checksum = ROOT / 'SHA256SUMS.txt'
    checksum.write_text(manifest)
    files.append(checksum)
    archive = ROOT.with_suffix('.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as z:
        for p in sorted(files):
            info = zipfile.ZipInfo(ROOT.name + '/' + p.relative_to(ROOT).as_posix(),
                                   date_time=(2026, 11, 8, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, p.read_bytes())
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise RuntimeError('Archive integrity failure')
    print(archive)
    print('Files:', len(files), 'Bytes:', archive.stat().st_size)


if __name__ == '__main__':
    main()
