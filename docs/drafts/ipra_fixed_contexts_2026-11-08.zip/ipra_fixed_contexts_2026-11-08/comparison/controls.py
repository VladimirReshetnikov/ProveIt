"""Independent, whole-program controls for the five active iPRA drafts.

Each control is applied identically to all ten primary checker programs
and to the candidate. No helper, driver, or data-table code is excluded.
Run with Python 3.12 or later; paths default to the delivered package.
"""
import argparse
import ast
import hashlib
import importlib.util
import json
from pathlib import Path


class RenameHelpers(ast.NodeTransformer):
    def __init__(self, opening, checking):
        self.names = {"sub": opening, "inst": opening,
                      "test": checking, "check": checking}

    def visit_FunctionDef(self, node):
        node.name = self.names.get(node.name, node.name)
        return self.generic_visit(node)

    def visit_Name(self, node):
        node.id = self.names.get(node.id, node.id)
        return node


class SuccessLiteral(ast.NodeTransformer):
    """Normalize only the successful hypothesis return, not input booleans."""
    def visit_Return(self, node):
        if isinstance(node.value, ast.Constant) and node.value.value is True:
            node.value = ast.Constant(value=1)
        return self.generic_visit(node)


def common_driver(tree):
    defs = [n for n in tree.body if isinstance(n, ast.FunctionDef)]
    if len(defs) != 2:
        raise ValueError("Expected precisely two complete core functions")
    checker = defs[1].name
    prefix = ast.parse("import json, sys\nk = 0\n").body
    driver = ast.parse(f'''try:
    take = json.load(sys.stdin).pop
    1 / {checker}(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
''').body
    tree.body = prefix + defs + driver
    return tree


def controlled(source, spec):
    tree = ast.parse(source)
    if spec.get("driver"):
        tree = common_driver(tree)
    if "helpers" in spec:
        tree = RenameHelpers(*spec["helpers"]).visit(tree)
    if spec.get("success_literal"):
        tree = SuccessLiteral().visit(tree)
    return ast.unparse(ast.fix_missing_locations(tree)) + "\n"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-root', type=Path,
                        default=Path(__file__).resolve().parent / 'baselines')
    parser.add_argument('--candidate', type=Path,
                        default=Path(__file__).resolve().parent.parent / 'checker.py')
    parser.add_argument('--output', type=Path,
                        default=Path(__file__).resolve().parent.parent / 'results/controls.json')
    args = parser.parse_args()
    module_path = Path(__file__).resolve().parent / 'source_measure.py'
    module_spec = importlib.util.spec_from_file_location('measure_frozen', module_path)
    measure = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(measure)
    programs = sorted(args.source_root.glob('*.py'))
    if len(programs) != 10:
        raise ValueError(f'Expected all ten current root programs, found {len(programs)}')
    profiles = {
        'delivered': {},
        'common_driver': {'driver': True},
        'common_helper_names': {'helpers': ['inst', 'check']},
        'common_driver_names_success': {
            'driver': True, 'helpers': ['inst', 'check'], 'success_literal': True},
        'common_driver_short_names_success': {
            'driver': True, 'helpers': ['f', 'p'], 'success_literal': True},
        'common_driver_descriptive_names_success': {
            'driver': True, 'helpers': ['open_expression', 'verify'],
            'success_literal': True},
    }
    keys = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
    output = {'program_count': len(programs), 'candidate': str(args.candidate),
              'candidate_sha256': hashlib.sha256(args.candidate.read_bytes()).hexdigest(),
              'frozen_normalizer_sha256': hashlib.sha256(module_path.read_bytes()).hexdigest(),
              'profile_specs': profiles, 'profiles': {}}
    artifacts = args.output.with_suffix('')
    artifacts.mkdir(parents=True, exist_ok=True)
    for name, spec in profiles.items():
        dest = artifacts / name
        dest.mkdir(exist_ok=True)
        rows = []
        for path in [*programs, args.candidate]:
            label = str(path.relative_to(args.source_root)) if path != args.candidate else 'candidate.py'
            target = dest / label.replace('/', '__')
            target.write_text(path.read_text() if name == 'delivered'
                              else controlled(path.read_text(), spec))
            metric = measure.metrics(target)
            rows.append({'label': label,
                         'original_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                         'metrics': {k: metric[k] for k in keys}})
        minimum = {k: min(r['metrics'][k] for r in rows[:-1]) for k in keys}
        candidate = rows[-1]['metrics']
        output['profiles'][name] = {
            'coordinate_minima': minimum,
            'minimum_attainers': {k: [r['label'] for r in rows[:-1]
                                      if r['metrics'][k] == minimum[k]] for k in keys},
            'candidate': candidate,
            'strictly_below_each_minimum': {k: candidate[k] < minimum[k] for k in keys},
            'all_programs': rows,
        }
    args.output.write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps({name: {k: v for k, v in data.items() if k != 'all_programs'}
                      for name, data in output['profiles'].items()}, indent=2))


if __name__ == '__main__':
    main()
