import json, sys
k = 0


def sub(a, t=None, d=0):
    match a:
        case [*_]:
            return [sub(b, t, d + len(a[:3]) + 1) for b in a]
    return d % 2 and (a if k <= a < d else sub(t, d=3))


def test(a, g):
    global k
    if sub(a) in g:
        return 1
    match take():
        case [m, t] if test(m, g):
            match m:
                case [b]:
                    t, m = b, [0, t]
            if not m[2:]:
                return sub(t, m[1]) == a and test(sub(t, m[0]), g)
            h = [[m[2]]]
        case []:
            (n, t, r), b = a
            if n:
                n, = n
                t = sub(r, [n, t, r], 3)
            return b == t
        case t:
            a = sub(a[2], t, 2)
            h = [a, sub(a, 0)][len(a) != 2:]
    k -= 1
    return test(sub(a, [k]), g + [sub(c, k) for c in h])


try:
    take = json.load(sys.stdin).pop
    1 / test(take(), [])
except:
    print('REJECT')
    sys.exit(1)

print('ACCEPT')
