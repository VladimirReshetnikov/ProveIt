"""Complete scalar iPRA certificate verifier with validated sort erasure.

Read one JSON packet from standard input. Formula erasure occurs only
after the scalar or substitution image has passed coordinate validation.
The pending closure is cached before elimination dispatch.
"""
import json, sys
k = 0


def inst(a, t=None, d=0):
    try:
        return [inst(b, t, d + (4, 1, 2)[-len(a)]) for b in a + []]
    except:
        return (a if k <= a < d else inst(t, d=1)) * (d % 2)


def check(a, g):
    global k
    if inst(a) in g:
        return True
    match take():
        case [m, t] if check(m, g):
            h = [m[2:]]
            if [] in h:
                if not m[1:]:
                    t, m = m[0], [0, t]
                return inst(t, m[1]) == a and check(inst(t, m[0]), g)
        case []:
            (n, t, r), b = a
            if n:
                n, = n
                t = inst(r, [n, t, r], 1)
            return b == t
        case t:
            a = inst(a[2], t, 2)
            h = [a, inst(a, 0)][len(a) % 2:]
    k -= 1
    return check(inst(a, [k]), g + [inst(c, k) for c in h])


try:
    take = json.load(sys.stdin).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
