# Complete uniform layers: exact Frankl-completeness threshold

**Research draft, November 25, 2026.** The manuscript proves a restricted-case theorem of Frankl's union-closed sets conjecture, with a necessary and sufficient criterion for a complete uniform layer to force a half-frequency witness within its own ground set. It also proves a sharp asymptotic boundary and a strictness theorem. It does not claim a resolution of the unrestricted conjecture or certify publication priority.

## Contents

- `uniform_threshold.tex`: self-contained LaTeX manuscript, including proofs and references.
- `uniform_threshold.pdf`: compiled 11-page manuscript.
- `verify.py`: Python standard-library exact arithmetic regression checks; no solver or external packages required.
- `verification.txt`: actual output of the verifier.
- `thresholds.csv`: exact boundary values for 2 through 512 elements. The signed gaps use unbounded integers.
- `witness_m6_r5.json`: an explicit 300-set union-closed family with all five-subsets of a six-element marked set, each marked element occurring only 149 times. Bits 0–5 designate the marked elements; higher bits designate the outside elements. Each integer in `sets_bitmask` specifies one member.
- `MANIFEST.sha256`: checksums of the deliverable files.

## Reproduce

With Python 3.10+ and TeX Live:

```sh
python3 verify.py
pdflatex -interaction=nonstopmode -halt-on-error uniform_threshold.tex
pdflatex -interaction=nonstopmode -halt-on-error uniform_threshold.tex
pdflatex -interaction=nonstopmode -halt-on-error uniform_threshold.tex
```

The mathematical proof does not depend on the finite checks. They independently test the integer identities, shadow inequalities on small sections, and explicit negative witnesses. No Lean or other proof-assistant verification is claimed.

## Prior-work audit

The closest ProveIt source is `docs/drafts/union_closed_abundance_theorems.zip`, specifically `blocks.tex`. Relevant extracted TeX excerpts from that and other archives were inspected using GitHub. Some archive extraction/review was incomplete. The paper also compares its criterion to the FC framework and finite classifications of Pulaj and Wood, arXiv:2301.01331v2. A targeted literature search did not locate the full criterion and asymptotic; exhaustive novelty verification remains outstanding. The archive is supplied for review and integration; no repository changes were made.
