#!/usr/bin/env python3
"""Exact regression checks for the complete-layer FC threshold.

No third-party dependencies. These finite checks supplement, not replace,
the proofs in the manuscript. Run from any working directory.
"""
from collections import Counter
from fractions import Fraction
from itertools import combinations
from math import comb
from pathlib import Path
import csv
import json
import random

ROOT = Path(__file__).resolve().parent


def G(m, r):
    return sum((2*k-m)*comb(m-1,k-1) for k in range(r,m+1))


def G_closed(m,r):
    c = comb(m-2,r-2) if r >= 2 else 0
    return (m-1)*c + sum(comb(m-1,k) for k in range(r-1,m))


def inner_outer(m,r):
    I = sum((2*j-m)**2*comb(m,j) for j in range(m//2+1,r))
    W = sum((2*t-m)*(m-t)*comb(m,t) for t in range(r,m+1))
    return I,W


def threshold(m):
    # G strictly decreases as r advances above m/2.
    total = 0
    for r in range(m,m//2,-1):
        total += (2*r-m)*comb(m-1,r-1)
        if total >= 2**(m-1):
            return r
    raise AssertionError((m,total))


def uc(S):
    return all(a|b in S for a,b in combinations(S,2))


def stable(S,m,r):
    return all(a|b in S for a in S for b in range(1<<m) if b.bit_count()==r)


def weight(S,m):
    return sum(2*a.bit_count()-m for a in S)


def star_section(m,r,x):
    return {a for a in range(1<<m) if not (a>>x)&1 or a.bit_count()>=r}


def check_section(S,m,r):
    assert S and uc(S) and stable(S,m,r)
    D = set(range(1<<m)) - S
    D0 = set()
    for a in D:
        if a.bit_count()<r:
            continue
        b=a
        while True:
            D0.add(b)
            if not b:
                break
            b=(b-1)&a
    assert D0 <= D
    E = D-D0
    # The simply-rooted property, checked independently of the proof.
    for a in D-{0}:
        covered=0
        for b in S:
            if b&a==b:
                covered |= b
        assert covered != a
    d=Counter(a.bit_count() for a in D)
    e=Counter(a.bit_count() for a in E)
    f=[Fraction(d[j],comb(m,j)) for j in range(m+1)]
    eta=[Fraction(e[j],comb(m,j)) for j in range(m+1)]
    delta=G(m,r)-(1<<(m-1))
    if 2*r>m:
        inner=range(m//2+1,r)
        M=max((eta[j]/j for j in inner),default=Fraction(0))
        for j in inner:
            assert f[m-j]-f[j] >= -Fraction(2*j-m,j)*eta[j]
        for t in range(r,m+1):
            assert f[m-t]-f[t] >= (m-t)*M
        assert weight(S,m)>=m*delta*M
    else:
        for j in range(m//2+1,m+1):
            assert f[m-j]>=f[j]
    if delta>=0:
        assert weight(S,m)>=0
    if delta>0 and m>=3 and D:
        assert weight(S,m)>0


def closure(seeds):
    S=set()
    for a in seeds:
        S |= {a} | {a|b for b in S}
    return S


def compatible(seeds,m,r):
    S=closure(seeds)
    assert S
    return S | {a for a in range(1<<m) if a.bit_count()>=r and any(a&b==b for b in S)}


def witness(m,r):
    gap=(1<<(m-1))-G(m,r)
    assert gap>0
    base={0}|{a for a in range(1<<m) if a.bit_count()>=r}
    S=[star_section(m,r,x) for x in range(m)]
    assert all(weight(s,m)==-gap for s in S)
    L=max(1,weight(base,m)//(m*gap)+1)
    q=m*L
    top=((1<<q)-1)<<m
    F=set(base) | {top|a for a in range(1<<m)}
    for i in range(q):
        tag=top^(1<<(m+i))
        F.update(tag|a for a in S[i%m])
    assert len(F)==len(base)+q*len(S[0])+(1<<m)
    degrees=[sum((a>>x)&1 for a in F) for x in range(m+q)]
    assert len(set(degrees[:m]))==1
    assert all(2*d<len(F) for d in degrees[:m])
    assert all(2*d>len(F) for d in degrees[m:])
    assert all(a in F for a in range(1<<m) if a.bit_count()==r)
    assert uc(F)
    return dict(m=m,r=r,L=L,ground_size=m+q,size=len(F),marked_degrees=degrees[:m],
                outside_degrees=degrees[m:],sets_bitmask=sorted(F))


def main():
    nidentity=0
    for m in range(2,129):
        for r in range(1,m+1):
            g=G(m,r)
            assert g==G_closed(m,r)
            if 2*r>m:
                I,W=inner_outer(m,r)
                assert W-I==m*(g-2**(m-1))
            nidentity+=1
    print(f'Exact binomial identities: {nidentity} pairs (m <= 128).')
    rows=[]
    for m in range(2,513):
        r=threshold(m)
        low=G(m,r); high=G(m,r+1) if r<m else None
        assert low>=2**(m-1)
        assert high is None or high<2**(m-1)
        rows.append((m,r,2*r-m,low-2**(m-1),None if high is None else high-2**(m-1)))
    with (ROOT/'thresholds.csv').open('w',newline='') as f:
        w=csv.writer(f); w.writerow(('m','largest_forcing_r','2r_minus_m','G_at_r_minus_half_cube','G_at_next_r_minus_half_cube')); w.writerows(rows)
    print(f'Threshold boundary signs: {len(rows)} dimensions (2 through 512).')
    assert threshold(1000)==536 and G(1000,536)>=2**999>G(1000,537)
    print('Additional boundary: m=1000, r*=536.')
    checked=0; ucs=0
    for m in range(2,5):
        for mask in range(1,1<<(1<<m)):
            S={a for a in range(1<<m) if (mask>>a)&1}
            if not uc(S):
                continue
            ucs+=1
            for r in range(1,m+1):
                if stable(S,m,r):
                    check_section(S,m,r); checked+=1
    print(f'Exhaustive small cases: {ucs} nonempty union-closed families, {checked} compatible (family,r) pairs, m=2..4.')
    rng=random.Random(20261125)
    checked=0
    for m in range(5,9):
        for r in range(1,m+1):
            for x in range(m):
                S=star_section(m,r,x)
                check_section(S,m,r)
                assert weight(S,m)==G(m,r)-2**(m-1)
                checked+=1
            for _ in range(30):
                k=rng.randrange(1, min(12,1<<m)+1)
                seeds=rng.sample(range(1<<m),k)
                S=compatible(seeds,m,r)
                check_section(S,m,r); checked+=1
    print(f'Additional structured and seeded-random compatible sections: {checked} (m=5..8).')
    for m,r in [(3,3),(4,4),(6,5),(7,6),(8,7),(9,7)]:
        a=witness(m,r)
        print(f'Explicit non-FC witness m={m}, r={r}: N={a["size"]}, marked degree={a["marked_degrees"][0]}, outside degree={a["outside_degrees"][0]}, outside={a["ground_size"]-m}.')
        if (m,r)==(6,5):
            (ROOT/'witness_m6_r5.json').write_text(json.dumps(a,indent=2)+'\n')
    print('All exact checks passed.')

if __name__=='__main__':
    main()
