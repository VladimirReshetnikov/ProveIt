iPRA with a smaller complete proof checker
Research package, 6 November 2026

MAIN RESULT

The complete checker has 613 normalized Python tokens, 658 AST nodes,
and 2,001 normalized executable bytes. The componentwise minima of the
six pinned draft checkers, including their supplied complete variants and
historical dependency groups, are 634, 675, and 2,053 respectively.

The theory uses equality, guarded universal quantification, unary existence,
and initialized primitive recursion. report.pdf lists every primitive rule,
derives full intuitionistic logic and quantifier-free induction, and proves
whole-domain bi-interpretability with the explicitly specified iPRA target.

This is a strict finite-corpus implementation improvement. It is not a proof
of absolute optimality. The mathematical basis is inherited from the draft
series; the implementation composes reductions, retaining the smaller choice
of existential discharge in this architecture, and validates computation
equations in the traversal that returns them. The metatheorems are paper
proofs, not a completed Lean or Rocq formalization.

PINNED SOURCE

Repository: VladimirReshetnikov/ProveIt
Commit: 0a86fcbd7c5e0d6a541291b4ac06c7dc77989161
Directory: docs/drafts
source_snapshot.json records all six archive names, sizes, and Git blob IDs.
comparison/manifest.json records 272 frozen Python source identities,
183 standalone checkers, and 74 full dependency groups. Sources are included
for offline remeasurement. The two demand-kernel uploads differ and are both
counted. Historical imported fragments are counted with their dependencies.

FILES

report.tex, report.pdf, sections/   Complete paper and compiled PDF.
checker.py                        The only trusted project acceptance file.
examples/                         Named accepted mathematical certificates.
comparison/                       Frozen baseline sources and measurement.
ablation/                         Regeneration and controlled implementations.
validation/independent/            Independent named-variable oracle,
                                  source and translated proof corpora, tests.
verification_summary.json          Results of the supplied verification run.
build.py                          Remeasure tables and compile the paper.
verify.py                         Reproduce comparisons and verification.
SHA256SUMS                        Snapshot hashes of the delivered files.

USAGE

Use Python 3.12 (measurements were made with 3.12.14). From this directory:

    python3 checker.py examples/reflexivity.json
    python3 -O checker.py examples/reflexivity.json
    python3 verify.py
    python3 build.py

The checker prints ACCEPT with status 0 or REJECT with status 1. For API
calls, normal return of check(data) means acceptance and an exception means
rejection. Resource exhaustion is also rejection; mathematical completeness
is in the usual unbounded-resource interpretation of the algorithm.

Each input is [goal, proof, *hypotheses], using finite JSON. Numerical zero
is -1; nonnegative integers are de Bruijn variable indices. Terms are
integers, ["s", term], or ["r", counter, initial, update]. Formulas are
["=", left, right], ["pi", guard, conclusion], or ["ex", matrix].
The update binds two indices (previous value, previous counter), while each
logical binder binds one. See Section 6 for the full proof-data convention.

Every goal and hypothesis is validated. An unused witness annotation in a
vacuous universal application may be any payload: the proof is reconstructed
with zero as its witness. Live mathematical Boolean or float leaves are
rejected; Boolean proof indices are merely aliases of stored assumptions.

verify.py needs no network or third-party Python modules. build.py needs
pdflatex and ordinary LaTeX packages. report.tex can also be compiled directly
with pdflatex twice; its generated tables are already present.

The independent rule oracle imports no candidate helpers. It uses fresh
named variables for substitution. Validation includes 167 distinct translated
certificates (154 sequents), 6,880 independent inference occurrences,
2,000 substitution comparisons, 152 targeted boundaries, 128 generated
nested derivations, and 16 actual CLI checks including optimized Python.
These categories overlap and are not a combined count of independent proofs.

All quoted complexity measures include the complete CLI and error boundary.
Comments and docstrings are excluded from primary measurements. Python and
its standard JSON library are the shared runtime boundary. No proof generator,
translator, audit oracle, external axiom table, or report file is imported
by checker.py. The source file SHA-256 is:
fb42aabb3bab4416094ed87286195b3a93de91c07d187cc8be4a2d6d5f9dc814
