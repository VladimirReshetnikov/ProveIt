INDEPENDENT VALIDATION OF THE SHARED LOCAL iPRA CHECKER

Audited checker SHA-256:
fb42aabb3bab4416094ed87286195b3a93de91c07d187cc8be4a2d6d5f9dc814
Python 3.12.14. Current draft snapshot:
0a86fcbd7c5e0d6a541291b4ac06c7dc77989161

Run, without network or nonstandard Python dependencies:

  python3 validate.py --checker /absolute/path/to/checker.py

The full results are in validation_results.json; concise counts are in
summary.json. A fresh run updates translated/ and validation_results.json.

OBSERVED RESULTS

* 279 archived certificate/source pairs accepted by seven frozen source
  checkers, then translated while preserving every context and conclusion.
* 167 distinct translated certificates, representing 154 distinct sequents.
* All 167 accepted by the candidate and an independently written rule
  interpreter using globally named binding; 6,880 inference occurrences.
* All 167 reconstructed in the strict complete local-kernel baseline and
  accepted there too.
* 2,000 substitution comparisons across eight operation families, including
  two-variable recursion binders and nested formula binders; no disagreements.
* 152 targeted boundary cases plus 128 generated nested derivations: 161
  accepted, 119 rejected as expected; independent oracle agrees throughout.
* 16 actual JSON CLI executions, including Python -O, all agree with expected
  verdicts. Raw booleans and floats in goals are tested across this boundary.

These categories partly overlap and must not be added into a single count of
independent mathematical proofs. The evidence is finite. It does not replace
soundness, completeness, bi-interpretability, or nonstandard-recursion proofs.

INDEPENDENCE AND TRUST

rule_oracle.py does not import candidate code. Its logical/numerical rules are
written separately, not by sharing the candidate's inference branches.
Its variable operations in named_syntax.py decode binders into globally fresh
Python object identities, replace only free variable names, and encode back.
The named syntax implementation is preserved from the checked local-kernel
archive's validation/oracle.py. It uses neither the candidate's scope table
nor its index-arithmetic substitution function.

The explicit substitution-comparison phase calls candidate.subst as the
implementation under test. No other oracle phase uses it. Translators call
old source checkers for source formulas only, then both the new checker and
the independent rule interpreter validate the output.

Malformed universal witness payloads are accepted only when unused in both
principal matrices. The independent oracle verifies that nonoccurrence by
fresh-name substitution and replaces the payload by numerical zero for strict
baseline replay. It never replaces a used malformed witness. Thirteen targeted
vacuous-payload cases exercise this distinction.

BOUNDARIES COVERED

* Capture avoidance under existential, guarded universal, and two-slot
  recursion binders; outer parameters are raised correctly.
* Existential elimination rejects an escaping eigenvariable and a shifted
  external conclusion.
* Compound numerical cases receive only the zero case; attempting an
  unrestricted compound induction hypothesis is rejected.
* Recursion validates unused update bodies at zero and unused initial values
  at successor counters, even though the result is computed before the final
  whole-equation validation in the candidate.
* Invalid constructors, wrong arities/sorts, negative term indices below -1,
  malformed unused context entries, and incorrect equality templates reject.
* Booleans/floats never become mathematical terms through Python equality
  aliases. Boolean/negative assumption indices select validated assumptions.
* Unused arbitrary universal witness payloads are harmlessly canonicalized.

FILES

source_manifest.json    Original hashes, source formats, and certificate paths.
sources/               Seven exact standalone source checkers.
originals/             Frozen original certificate byte strings.
translated/            Candidate-format accepted certificates by SHA-256.
milestones/            Named arithmetic milestone certificates and provenance.
replay.py              Archived-source revalidation and translation runner.
translate_archived.py  Offline dialect translator; untrusted.
rule_oracle.py         Independent explicit rule interpreter; untrusted test code.
named_syntax.py        Independent fresh-name syntax and substitution.
validate.py            Reproduction entry point and targeted generators.

