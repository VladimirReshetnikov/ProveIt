CURRENT DRAFT COMPARISON CORPUS

Pinned repository: VladimirReshetnikov/ProveIt
Commit: 0a86fcbd7c5e0d6a541291b4ac06c7dc77989161
Directory: docs/drafts

All six archive bytes were matched to their exact Git blob hashes and lengths
returned by the GitHub API. manifest.json records every archive hash, every
Python source file's SHA-256, and every containing archive/member pair.

There are 272 distinct Python source byte strings, including checkers, helper
modules, and non-checker clients. The expanded comparison includes 183 distinct
self-contained checker programs plus 74 full historical dependency groups
already identified by the draft manifests. Duplicate appearances do not lower
an envelope. Historical sources are retained to make the comparison more
conservative than the six primary programs alone. Test generators, translators,
and other non-acceptance helpers are not treated as standalone checkers.

A standalone checker has a public check/verify function, a JSON CLI, and no
imports except json/sys. Programs with local dependencies are counted with
those dependencies. In particular, the superficially smaller 608-token source
993065... imports the shared syntax/logic kernel and is not a complete program.

The componentwise minima, using CPython 3.12.14, are:
  normalized tokens: 634 (local_kernel)
  AST nodes:          675 (demand_kernel without suffix)
  normalized bytes: 2053 (shared_transition)
  source tokens:      636 (local_kernel)
  raw bytes:         2205 (demand_kernel without suffix)
  physical lines:      75 (demand_kernel without suffix)

No single primary program attains all componentwise minima. Therefore a new
candidate below this envelope beats each primary program on every reported
axis. This establishes a finite-corpus implementation comparison, not a lower
bound on all iPRA axiomatizations, proof checkers, or programming languages.

Run:
  python3 measure.py --candidate /absolute/path/to/checker.py

The measurement script parses candidate/source syntax and does not execute any
of the checkers. It removes docstrings and comments, counts significant tokens,
and uses Python's AST unparser for normalized syntax/bytes. Token spelling and
AST nodes are not invariant under arbitrary implementation languages. The
Python version is recorded. Metric implementation is preserved unmodified in
legacy_measure.py from the pinned local_kernel archive.
