CONTROLLED COMPLETE-CHECKER COMPARISONS

Reproduce, from any working directory:

  python3 /path/to/ablation/build_ablation.py

Python 3.11 or later is required. The directory is self-contained: no network,
third-party package, repository checkout, or sibling directory is read. The
script reconstructs all four complete variants, measures their full sources,
and reruns 56 rule and rejection-boundary smoke tests. It rewrites metrics.json
and table.csv and exits nonzero if a source hash or expected outcome changes.

BASELINE AND SCOPE

baseline.py is the exact local-kernel checker in the current ProveIt snapshot
0a86fcbd7c5e0d6a541291b4ac06c7dc77989161. Its archive, Git blob, member path and
source SHA-256 are recorded in metrics.json. The generator verifies the source
hash before transformation. All measured programs include JSON input, syntax
validation, inference, exceptions, and CLI behavior. Only json and sys are
imported. The generator, measurements, transformations and smoke tests are
untrusted support artifacts and are not imported by any kernel.

measure.py preserves the canonical measurement functions used in the frozen
corpus comparison. Normalization removes docstrings and uses ast.unparse;
tokens omit comments, whitespace, indentation and docstrings. AST nodes count
the complete executable tree. Raw byte differences involving the original
baseline's different docstring must not be attributed entirely to structural
savings; normalized measures exclude that difference.

VARIANTS

final.py is byte-for-byte identical to the proposed complete checker. It is
regenerated from the exact baseline by the following explicit transformations:

  * Flatten the public judgment to [goal, proof, *hypotheses].
  * Remove the application marker and move generic application after recursor
    recognition; the application record is [major, annotation, minor].
  * Validate a pi witness when substitution actually uses it. Equality still
    validates its formula template, and existential elimination still checks
    the explicitly annotated external conclusion after raising it.
  * Inline the fixed literal -1; this small naming change is separate from the
    structural proof-representation changes.
  * Validate the returned recursion equation by identity substitution, in place
    of separately validating its left-hand recursor before construction.

pre_fusion.py changes only the last item. It restores validation of the entire
recursor before constructing its equation and returns that equation directly.
This costs two additional AST nodes and 23 normalized bytes; token count is
unchanged. The final variant traverses the computed right-hand side as well.

inferred_ex.py changes only existential discharge representation. It omits the
external conclusion annotation, infers the minor conclusion, then removes the
fresh variable using subst(result, [None, -1]); any escaping occurrence rejects.
The generic application uses variable-length arguments to accommodate that
case. In this architecture the inferred version costs six additional tokens,
six AST nodes, and nine normalized bytes. Shorter certificates do not imply a
smaller checker.

tagged_application.py changes only the application record to
["use", major, annotation, minor]. It costs two additional tokens, two AST
nodes, and seven normalized bytes. Local rules and recursor certificates retain
their own tags in every variant.

All four variants keep exact term-sort checks and validate the separately
supplied goal. In particular, none uses Python value equality as a replacement
for goal syntax validation: Boolean and floating-point leaves can compare equal
to integers while failing the term grammar.

All four variants have the same native derivability relation after the stated
certificate-format translations. The paper supplies the universal arguments;
finite smoke tests only exercise representative constructors and failures.
They do not establish soundness, consistency, completeness or bi-interpretability.

COUNTS ON PYTHON 3.12.14

                             Tokens     AST     Normalized bytes
  Exact local baseline          634     688                 2122
  Final                         613     658                 2001
  Before recursion fusion       613     660                 2024
  Inferred existential          619     664                 2010
  Tagged application            615     660                 2008

The overall comparison against every current draft and its complete embedded
checker variants belongs to the main comparison bundle, not this ablation.
