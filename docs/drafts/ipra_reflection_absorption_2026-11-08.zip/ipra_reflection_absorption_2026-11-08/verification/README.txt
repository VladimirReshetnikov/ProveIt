SYMBOLIC CERTIFICATE: ABSORBING EQUALITY REFLECTION
================================================

Purpose
-------
This package replays finite symbolic derivations of four universally
scoped claims. It does not sample numerical inputs and does not evaluate
the unknown numerical operation e. The certificate producer and checker
are independent files; the producer does not import the checker.

The signature has 0, unary S, ternary C, and an otherwise arbitrary
binary operation e. All theorem parameters range over an arbitrary
nonempty numerical domain. Passive parameters in a fixed term e can be
held fixed throughout; no property of e is assumed unless explicitly
listed below.

Common assumptions
------------------
  C(0,a,b) = a.
  C(S(n),a,b) = b.
  Every e(x,y) is either 0 or S(u) for some u.

The last assumption is used by an explicit two-branch test-range rule.
The verifier requires the split subject to have syntactic head e; it
does not permit case splits on arbitrary numerical terms. The successor
branch receives a fresh u and the equation e(x,y)=S(u); its
conclusion must agree with the zero branch and u may not escape. This
is justified in ordinary intuitionistic logic by disjunction elimination
and existential elimination. Thus FULL NUMERICAL COVERAGE IS NOT ASSUMED.
The weaker e-value range assumption follows, for example, from Boolean
range e(x,y)=0 or e(x,y)=1, with 1=S(0). The proof does not require that
stronger Boolean-range assumption, successor separation, successor
injectivity, induction, or a falsity principle.

Theories used by the checker
---------------------------
In theory 'abs', the additional schema is precisely

  C(C(e(x,x), e(x,y), 0), x, y) = y.                 (Abs)

In theory 'ref', two explicit consequences of equality reflection are
available:

  e(x,x) = 0;                                      (Ref-diagonal)
  from e(x,y) = 0 infer x = y.                     (Ref-soundness)

Ref-diagonal follows from x=x and the right-to-left direction of
e(x,y)=0 iff x=y. Ref-soundness is its left-to-right direction. Conversely,
these two schemas recover the complete reflection biconditional by
equality substitution. The checker does not silently assume the Abs
schema in theory 'ref', or either Ref schema in theory 'abs'.

Verified universal claims
-------------------------
1. In theory Abs: e(x,x)=0, for arbitrary x.
2. In theory Abs, from e(x,y)=0: x=y.
3. In theory Abs, from x=y: e(x,y)=0.
4. In theory Ref: the Abs equation, for arbitrary x,y.

For claim 1, put c=e(x,x) and split on the permitted test range of c. In the successor
branch C(c,e(x,t),0)=0 for every t. Abs therefore gives x=t. Use t=0 and
t=c to obtain x=0 and x=c, hence c=0. No contradiction or collapse
principle is used. This is shorter than introducing 1 and proving a
general numerical-collapse lemma.

The complete certificate contains 80 replayed proof nodes. The checker
validates its declared equations; run_checks.py separately verifies that
the declarations are exactly the four claims above. The conditional
claims use explicit local equation assumptions, which cannot be silently
discarded when a proved lemma is specialized.

Trusted implementation and limits
---------------------------------
Trusted code consists of check_certificate.py, the Python interpreter,
and the standard-library JSON decoder. The verifier implements:

  * finite term and equation syntax with fixed symbol arities;
  * explicit scopes for universal parameters and case eigenvariables;
  * equation hypotheses, reflexivity, symmetry, transitivity, congruence;
  * exactly the two selector computation schemas;
  * the stated Abs or Ref schema interface;
  * test-value range with fresh successor witness and discharged cases;
  * specialization of earlier verified lemmas, checking every hypothesis.

There is no eval, exec, imported theorem prover, assert-dependent logical
check, finite-model oracle, induction rule, or universal evaluator in the
verifier. Proof input is JSON data. Terms involving e remain symbolic.

The checker has not itself been formally verified in Lean or Rocq. The
rule soundness argument is the ordinary equational and intuitionistic
interpretation described above. The scripts do not verify stationarity,
primitive-recursion compilation, the full iPRA bi-interpretation, or any
proof-checker size comparison. They are NOT a complete iPRA checker and
must not be entered against the repository's tiny complete checkers.

Reproduction
------------
Python 3.10+ and its standard library are sufficient. No network access
or nonstandard Python packages are used.

  python3 make_certificate.py
  python3 check_certificate.py certificate.json
  python3 run_checks.py

The last command verifies the four stated universal claims, exercises a
lemma specialized at the compound term e(x,y), and rejects 31 deliberately
damaged certificates. Both valid certificates and all negative controls
are also run through the command-line verifier under ordinary Python
and python -O: 4 accepted positive runs and 62 rejected negative runs.
The result is recorded in verification_results.json.

Files
-----
check_certificate.py       Standalone proof replayer and explicit rule basis.
make_certificate.py        Independent certificate producer.
certificate.json           Fully explicit finite symbolic proof data.
run_checks.py              Exact-claim checks and rejection controls.
verification_results.json  Reproduced results, rule counts, and certificate hash.
README.txt                This scope and trust-boundary explanation.

Separate finite shifted-latch diagnostic
---------------------------------------
check_latch_bits.py and latch_bit_results.json concern a DIFFERENT,
strictly finite calculation supporting the written stationarity argument.
Run:

  python3 check_latch_bits.py

For r(0)=0, r(Sn)=C(sg(r(n)),q(n),1), and c(n)=r(Sn), the script checks
all eight local Boolean assignments to sg(r(n)), q(n), and q(Sn). It checks
Boolean range of c(n), the no-false-success implication c(n)=0 -> q(n)=0,
and c(Sn)=c(n) under the progress premise q(n)=0 -> q(Sn)=0. Six of the
eight assignments satisfy that premise. It also checks the two possible
Boolean base values and detects four deliberately broken variants.

These are exhaustive Boolean transition tables, NOT symbolic arithmetic
proofs. In particular, they do not establish induction for nonstandard
numbers, the stationarity rule, reflection, or bi-interpretability. Those
claims require the report's written arguments. This diagnostic is separate
from the 80-node universal absorption certificate described above.
