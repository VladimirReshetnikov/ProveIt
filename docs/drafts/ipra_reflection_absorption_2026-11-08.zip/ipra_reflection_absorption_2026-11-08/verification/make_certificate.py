"""Produce the selector-absorption certificate; does not import its verifier."""
import json
from pathlib import Path


Z = ["0"]


def V(name):
    return ["v", name]


def S(t):
    return ["S", t]


def C(c, a, b):
    return ["C", c, a, b]


def E(x, y):
    return ["e", x, y]


def D(x, y):
    return C(E(x, x), E(x, y), Z)


def ref(t):
    return {"r": "refl", "t": t}


def sym(p):
    return {"r": "sym", "p": p}


def trans(*ps):
    result = ps[0]
    for p in ps[1:]:
        result = {"r": "trans", "p": result, "q": p}
    return result


def cong(f, *ps):
    return {"r": "cong", "f": f, "ps": list(ps)}


def hyp(i):
    return {"r": "hyp", "index": i}


def c0(a, b):
    return {"r": "c0", "a": a, "b": b}


def cs(n, a, b):
    return {"r": "cs", "n": n, "a": a, "b": b}


def ax_abs(x, y):
    return {"r": "abs", "x": x, "y": y}


def lemma(name, arguments, premises=()):
    return {"r": "lemma", "name": name, "args": arguments,
            "premises": list(premises)}


def cases(t, u, zero, successor):
    return {"r": "cases", "t": t, "u": u,
            "zero": zero, "successor": successor}


def theorem(name, theory, params, assumptions, lhs, rhs, proof):
    return {"name": name, "theory": theory, "parameters": params,
            "assumptions": assumptions, "goal": [lhs, rhs], "proof": proof}


def build():
    x, y, u = V("x"), V("y"), V("u")
    diagonal = E(x, x)

    # In the successor branch c=S(u), d(x,t)=0 for every numerical t.
    def d_zero(t):
        return trans(cong("C", hyp(0), ref(E(x, t)), ref(Z)),
                     cs(u, E(x, t), Z))

    # Abs then gives x=t. Use t=0 and t=c, avoiding separation entirely.
    def x_is(t):
        lhs_to_x = trans(cong("C", d_zero(t), ref(x), ref(t)), c0(x, t))
        return trans(sym(lhs_to_x), ax_abs(x, t))

    diagonal_proof = cases(diagonal, "u", hyp(0),
                           trans(sym(x_is(diagonal)), x_is(Z)))
    first = theorem("abs_implies_diagonal", "abs", ["x"], [],
                    diagonal, Z, diagonal_proof)

    diag = lemma("abs_implies_diagonal", {"x": x})
    d_to_e = trans(cong("C", diag, ref(E(x, y)), ref(Z)), c0(E(x, y), Z))
    d_to_zero = trans(d_to_e, hyp(0))
    lhs_to_x = trans(cong("C", d_to_zero, ref(x), ref(y)), c0(x, y))
    soundness = trans(sym(lhs_to_x), ax_abs(x, y))
    second = theorem("abs_zero_implies_equal", "abs", ["x", "y"],
                     [[E(x, y), Z]], x, y, soundness)

    completeness = trans(cong("e", ref(x), sym(hyp(0))),
                         lemma("abs_implies_diagonal", {"x": x}))
    third = theorem("abs_equal_implies_zero", "abs", ["x", "y"],
                    [[x, y]], E(x, y), Z, completeness)

    ref_diag = {"r": "ref_diag", "x": x}
    d_to_e_ref = trans(cong("C", ref_diag, ref(E(x, y)), ref(Z)), c0(E(x, y), Z))
    outer_rewrite = cong("C", d_to_e_ref, ref(x), ref(y))
    zero_branch = trans(cong("C", hyp(0), ref(x), ref(y)), c0(x, y),
                        {"r": "ref_sound", "x": x, "y": y, "p": hyp(0)})
    successor_branch = trans(cong("C", hyp(0), ref(x), ref(y)), cs(u, x, y))
    case_proof = cases(E(x, y), "u", zero_branch, successor_branch)
    fourth = theorem("reflection_implies_absorption", "ref", ["x", "y"], [],
                     C(D(x, y), x, y), y, trans(outer_rewrite, case_proof))
    return {"format": "selector-absorption-equations-v1",
            "theorems": [first, second, third, fourth]}


if __name__ == "__main__":
    path = Path(__file__).with_name("certificate.json")
    path.write_text(json.dumps(build(), indent=2) + "\n", encoding="utf-8")
    print(path.name)
