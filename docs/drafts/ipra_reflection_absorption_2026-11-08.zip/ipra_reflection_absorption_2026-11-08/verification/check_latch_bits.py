"""Finite Boolean transition diagnostics; not a universal arithmetic proof."""
import itertools
import json
from pathlib import Path


def choose(bit, when_zero, when_one):
    return when_zero if bit == 0 else when_one


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def main():
    rows = []
    for sign_previous, q_current, q_next in itertools.product((0, 1), repeat=3):
        # c(n) = r(Sn), obtained by one actual unfolding of the recurrence.
        current = choose(sign_previous, q_current, 1)
        following = choose(current, q_next, 1)  # sg is identity on Boolean values.
        progress = q_current != 0 or q_next == 0
        boolean = current in (0, 1)
        no_false_success = current != 0 or q_current == 0
        stationary_if_progress = not progress or following == current
        require(boolean and no_false_success and stationary_if_progress,
                "a shifted-latch truth-table identity failed")
        rows.append({
            "sg_r_n": sign_previous, "q_n": q_current, "q_Sn": q_next,
            "c_n": current, "c_Sn": following,
            "q_progress_premise": progress,
            "c_boolean": boolean,
            "c_zero_implies_q_zero": no_false_success,
            "stationary_given_progress": stationary_if_progress,
        })

    base_rows = []
    for q_zero in (0, 1):
        r_zero = 0
        c_zero = choose(r_zero, q_zero, 1)
        require(c_zero == q_zero, "base c(0)=q(0) failed")
        base_rows.append({"r_0": r_zero, "q_0": q_zero, "c_0": c_zero})

    # Each mutation has an explicit small witness to a lost local property.
    controls = [
        {"mutation": "replace_failure_one_by_zero", "inputs": {"sg_r_n": 1, "q_n": 1},
         "c_n": choose(1, 1, 0), "expected_property": "c_n=0 implies q_n=0",
         "caught": choose(1, 1, 0) == 0},
        {"mutation": "use_unshifted_r_n_as_signal", "inputs": {"r_n": 0, "q_n": 1},
         "c_n": 0, "expected_property": "c_n=0 implies q_n=0", "caught": True},
        {"mutation": "initialize_r_0_at_one", "inputs": {"r_0": 1, "q_0": 0},
         "c_0": choose(1, 0, 1), "expected_property": "c_0=q_0",
         "caught": choose(1, 0, 1) != 0},
        {"mutation": "reverse_boolean_sign_at_transition", "inputs": {"c_n": 0, "q_Sn": 0},
         "c_Sn": choose(1, 0, 1), "expected_property": "stationarity under progress",
         "caught": choose(1, 0, 1) != 0},
    ]
    require(all(control["caught"] for control in controls), "a damaged latch was not detected")
    receipt = {
        "status": "passed",
        "scope": "exhaustive local Boolean transition tables only; not induction, stationarity admissibility, or a model of the full arithmetic theory",
        "transition_rows": len(rows),
        "rows_satisfying_progress": sum(row["q_progress_premise"] for row in rows),
        "base_rows": len(base_rows),
        "damaged_variants_detected": len(controls),
        "transitions": rows, "base": base_rows, "controls": controls,
    }
    output = Path(__file__).with_name("latch_bit_results.json")
    output.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({key: receipt[key] for key in
          ("status", "transition_rows", "rows_satisfying_progress", "base_rows",
           "damaged_variants_detected")}, indent=2))


if __name__ == "__main__":
    main()
