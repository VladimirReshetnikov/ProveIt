"""Replay the fixed universal claims and reject deliberately damaged proofs."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

from check_certificate import Replay, Rejection


ROOT = Path(__file__).resolve().parent
Z = ["0"]
X = ["v", "x"]
Y = ["v", "y"]
EXX = ["e", X, X]
EXY = ["e", X, Y]
ABS = ["C", ["C", EXX, EXY, Z], X, Y]
EXPECTED = [
    ("abs_implies_diagonal", "abs", ["x"], [], [EXX, Z]),
    ("abs_zero_implies_equal", "abs", ["x", "y"], [[EXY, Z]], [X, Y]),
    ("abs_equal_implies_zero", "abs", ["x", "y"], [[X, Y]], [EXY, Z]),
    ("reflection_implies_absorption", "ref", ["x", "y"], [], [ABS, Y]),
]


def demand(condition, message):
    if not condition:
        raise RuntimeError(message)


def nodes(value):
    if type(value) is dict:
        if "r" in value:
            yield value
        for child in value.values():
            yield from nodes(child)
    elif type(value) is list:
        for child in value:
            yield from nodes(child)


def first(document, rule, theorem_index=None):
    source = document if theorem_index is None else document["theorems"][theorem_index]["proof"]
    for node in nodes(source):
        if node["r"] == rule:
            return node
    raise RuntimeError("test setup: missing rule " + rule)


def trial(document, name, change):
    result = copy.deepcopy(document)
    change(result)
    return name, result


def append_forged_lemma(document, premises):
    document["theorems"].append({
        "name": "forged_conditional", "theory": "abs", "parameters": ["x", "y"],
        "assumptions": [], "goal": [X, Y],
        "proof": {"r": "lemma", "name": "abs_zero_implies_equal",
                  "args": {"x": X, "y": Y}, "premises": premises},
    })


def damaged(document):
    tests = []
    add = lambda name, change: tests.append(trial(document, name, change))
    add("unknown_format", lambda d: d.update(format="untrusted-format"))
    add("unexpected_top_field", lambda d: d.update(extra_axiom="0=1"))
    add("missing_proof", lambda d: d["theorems"][0].pop("proof"))
    add("false_declared_goal", lambda d: d["theorems"][0]["goal"].__setitem__(1, ["S", Z]))
    add("unscoped_parameter", lambda d: d["theorems"][0].update(parameters=[]))
    add("duplicate_parameter", lambda d: d["theorems"][0].update(parameters=["x", "x"]))
    add("out_of_range_hypothesis", lambda d: first(d, "hyp").update(index=1))
    add("ref_axiom_in_abs_theory", lambda d: d["theorems"][0].update(proof={"r": "ref_diag", "x": X}))
    add("abs_axiom_in_ref_theory", lambda d: d["theorems"][3].update(proof={"r": "abs", "x": X, "y": Y}))
    add("ref_sound_without_zero", lambda d: first(d, "ref_sound").update(p={"r": "refl", "t": EXY}))
    add("wrong_c0_instance", lambda d: first(d, "c0").update(a=["S", Z]))
    add("wrong_cs_instance", lambda d: first(d, "cs").update(n=["S", ["v", "u"]]))
    add("congruence_wrong_arity", lambda d: first(d, "cong")["ps"].pop())
    add("unknown_function_symbol", lambda d: first(d, "refl").update(t=["truth_oracle"]))
    add("unknown_proof_rule", lambda d: first(d, "refl").update(r="trust_me"))
    add("forward_lemma_reference", lambda d: d["theorems"].__setitem__(slice(0, 2), d["theorems"][1::-1]))
    add("lemma_wrong_theory", lambda d: d["theorems"][2].update(theory="ref"))
    add("lemma_wrong_argument_keys", lambda d: first(d, "lemma").update(args={"y": X}))
    add("lemma_missing_hypothesis", lambda d: append_forged_lemma(d, []))
    add("lemma_wrong_hypothesis", lambda d: append_forged_lemma(d, [{"r": "refl", "t": X}]))
    add("nonfresh_case_variable", lambda d: first(d, "cases").update(u="x"))
    add("eigenvariable_in_zero_branch", lambda d: first(d, "cases").update(zero={"r": "refl", "t": ["v", "u"]}))
    add("different_case_conclusions", lambda d: first(d, "cases").update(successor={"r": "refl", "t": X}))
    add("discharged_assumption_leak", lambda d: d["theorems"][0].update(proof={"r": "hyp", "index": 0}))
    add("bad_transitivity", lambda d: first(d, "trans").update(q={"r": "refl", "t": ["S", Z]}))
    add("boolean_hypothesis_index", lambda d: first(d, "hyp").update(index=False))
    add("unbound_term_variable", lambda d: first(d, "ref_diag").update(x=["v", "w"]))
    add("duplicate_theorem_name", lambda d: d["theorems"][1].update(name=d["theorems"][0]["name"]))
    add("unknown_axiom_theory", lambda d: d["theorems"][0].update(theory="arbitrary_true_arithmetic"))
    add("wrong_lemma_substitution", lambda d: first(d, "lemma", 2).update(args={"x": Y}))
    add("case_split_outside_test_range", lambda d: first(d, "cases").update(t=X))
    return tests


def run_cli(path, optimized):
    command = [sys.executable]
    if optimized:
        command.append("-O")
    command += [str(ROOT / "check_certificate.py"), str(path)]
    completed = subprocess.run(command, text=True, capture_output=True, check=False)
    try:
        payload = json.loads(completed.stdout)
    except ValueError as error:
        raise RuntimeError("checker did not return JSON: " + completed.stderr) from error
    return completed.returncode, payload


def main():
    path = ROOT / "certificate.json"
    document = json.loads(path.read_text(encoding="utf-8"))
    demand(len(document["theorems"]) == len(EXPECTED), "required theorem inventory changed")
    for theorem, expected in zip(document["theorems"], EXPECTED):
        actual = tuple(theorem[k] for k in ("name", "theory", "parameters", "assumptions", "goal"))
        demand(actual == expected, "the certificate does not state a required universal claim")
    result = Replay().certificate(document)

    # Exercise uniform specialization at a nonvariable term, beyond the four proofs.
    specialized = copy.deepcopy(document)
    specialized["theorems"].append({
        "name": "compound_specialization", "theory": "abs", "parameters": ["x", "y"],
        "assumptions": [], "goal": [["e", EXY, EXY], Z],
        "proof": {"r": "lemma", "name": "abs_implies_diagonal",
                  "args": {"x": EXY}, "premises": []},
    })
    Replay().certificate(specialized)

    controls = damaged(document)
    rejection_results = []
    for name, changed in controls:
        try:
            Replay().certificate(changed)
        except (Rejection, ValueError, TypeError, KeyError, IndexError, RecursionError) as error:
            rejection_results.append({"name": name, "reason": str(error)})
        else:
            raise RuntimeError("damaged certificate accepted: " + name)

    cli_positive = 0
    cli_negative = 0
    with tempfile.TemporaryDirectory(prefix="absorption-proof-check-") as directory:
        temporary = Path(directory)
        specialized_path = temporary / "specialized.json"
        specialized_path.write_text(json.dumps(specialized), encoding="utf-8")
        for optimized in (False, True):
            for positive in (path, specialized_path):
                status, payload = run_cli(positive, optimized)
                demand(status == 0 and payload.get("accepted") is True,
                       "valid certificate rejected by CLI")
                cli_positive += 1
            for index, (name, changed) in enumerate(controls):
                changed_path = temporary / ("negative_" + str(index) + ".json")
                changed_path.write_text(json.dumps(changed), encoding="utf-8")
                status, payload = run_cli(changed_path, optimized)
                demand(status != 0 and payload.get("accepted") is False,
                       "CLI accepted damaged certificate: " + name)
                cli_negative += 1

    receipt = {
        "status": "passed", "scope": "symbolic equality and zero/successor range for e-values only; not full iPRA",
        "certificate_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "certificate": result, "compound_specialization_accepted": True,
        "negative_controls": len(controls), "negative_control_results": rejection_results,
        "normal_and_optimized_cli_positive_runs": cli_positive,
        "normal_and_optimized_cli_negative_runs": cli_negative,
    }
    (ROOT / "verification_results.json").write_text(
        json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({k: receipt[k] for k in
          ("status", "negative_controls", "normal_and_optimized_cli_positive_runs",
           "normal_and_optimized_cli_negative_runs")}, indent=2))
    print("Verified " + str(result["proof_nodes"]) + " symbolic proof nodes in four universal claims.")


if __name__ == "__main__":
    main()
