"""Replay finite, universally scoped equational proofs of selector absorption.

This is a limited equality/test-range verifier, not an iPRA kernel.
The input is data. No Python code from the input is executed.
"""
import json
import re
import sys


ARITIES = {"0": 0, "S": 1, "C": 3, "e": 2}
NAME = re.compile(r"[A-Za-z][A-Za-z0-9_]*\Z")
ZERO = ("0",)


class Rejection(Exception):
    pass


def require(condition, message):
    if not condition:
        raise Rejection(message)


def fields(value, expected, label):
    require(type(value) is dict, label + " must be an object")
    require(set(value) == set(expected), label + " has unexpected fields")


def term(value, environment):
    require(type(value) is list and len(value) > 0, "malformed term")
    head = value[0]
    require(type(head) is str, "term head must be a string")
    if head == "v":
        require(len(value) == 2, "variable arity")
        require(type(value[1]) is str and NAME.fullmatch(value[1]) is not None,
                "invalid variable name")
        require(value[1] in environment, "unscoped variable: " + value[1])
        return ("v", value[1])
    require(head in ARITIES, "unknown function symbol")
    require(len(value) == ARITIES[head] + 1, "function arity")
    return (head,) + tuple(term(a, environment) for a in value[1:])


def equation(value, environment):
    require(type(value) is list and len(value) == 2, "malformed equation")
    return term(value[0], environment), term(value[1], environment)


def variables(value):
    if value[0] == "v":
        return {value[1]}
    result = set()
    for child in value[1:]:
        result.update(variables(child))
    return result


def replace(value, substitution):
    if value[0] == "v":
        return substitution[value[1]]
    return (value[0],) + tuple(replace(a, substitution) for a in value[1:])


def show(value):
    if value[0] == "v":
        return value[1]
    if value[0] == "0":
        return "0"
    return value[0] + "(" + ",".join(show(a) for a in value[1:]) + ")"


def absorption(x, y):
    diagonal = ("e", x, x)
    detector = ("C", diagonal, ("e", x, y), ZERO)
    return ("C", detector, x, y), y


class Replay:
    def __init__(self):
        self.lemmas = {}
        self.nodes = 0
        self.rules = {}

    def proof(self, node, environment, assumptions, theory):
        require(type(node) is dict and type(node.get("r")) is str,
                "malformed proof node")
        rule = node["r"]
        self.nodes += 1
        require(self.nodes <= 100000, "proof size limit")
        self.rules[rule] = self.rules.get(rule, 0) + 1
        recurse = lambda p: self.proof(p, environment, assumptions, theory)
        parse = lambda t: term(t, environment)

        if rule == "hyp":
            fields(node, ("r", "index"), "hyp")
            i = node["index"]
            require(type(i) is int and 0 <= i < len(assumptions),
                    "hypothesis index out of scope")
            return assumptions[i]

        if rule == "refl":
            fields(node, ("r", "t"), "refl")
            t = parse(node["t"])
            return t, t

        if rule == "sym":
            fields(node, ("r", "p"), "sym")
            a, b = recurse(node["p"])
            return b, a

        if rule == "trans":
            fields(node, ("r", "p", "q"), "trans")
            a, b = recurse(node["p"])
            c, d = recurse(node["q"])
            require(b == c, "transitivity middle terms differ")
            return a, d

        if rule == "cong":
            fields(node, ("r", "f", "ps"), "cong")
            f, ps = node["f"], node["ps"]
            require(type(f) is str and f in ARITIES, "congruence symbol")
            require(type(ps) is list and len(ps) == ARITIES[f],
                    "congruence arity")
            equations = [recurse(p) for p in ps]
            return ((f,) + tuple(p[0] for p in equations),
                    (f,) + tuple(p[1] for p in equations))

        if rule == "c0":
            fields(node, ("r", "a", "b"), "c0")
            a, b = parse(node["a"]), parse(node["b"])
            return ("C", ZERO, a, b), a

        if rule == "cs":
            fields(node, ("r", "n", "a", "b"), "cs")
            n, a, b = parse(node["n"]), parse(node["a"]), parse(node["b"])
            return ("C", ("S", n), a, b), b

        if rule == "abs":
            fields(node, ("r", "x", "y"), "abs")
            require(theory == "abs", "Abs axiom unavailable in this theory")
            return absorption(parse(node["x"]), parse(node["y"]))

        if rule == "ref_diag":
            fields(node, ("r", "x"), "ref_diag")
            require(theory == "ref", "Ref diagonal unavailable in this theory")
            x = parse(node["x"])
            return ("e", x, x), ZERO

        if rule == "ref_sound":
            fields(node, ("r", "x", "y", "p"), "ref_sound")
            require(theory == "ref", "Ref soundness unavailable in this theory")
            x, y = parse(node["x"]), parse(node["y"])
            require(recurse(node["p"]) == (("e", x, y), ZERO),
                    "Ref soundness premise is not its required equation")
            return x, y

        if rule == "cases":
            fields(node, ("r", "t", "u", "zero", "successor"), "cases")
            t, u = parse(node["t"]), node["u"]
            require(t[0] == "e", "case split requires a value of the test e")
            require(type(u) is str and NAME.fullmatch(u) is not None,
                    "invalid eigenvariable")
            require(u not in environment, "test-range eigenvariable is not fresh")
            p = self.proof(node["zero"], environment,
                           assumptions + ((t, ZERO),), theory)
            q = self.proof(node["successor"], environment | {u},
                           assumptions + ((t, ("S", ("v", u))),), theory)
            require(p == q, "test-range branches have different conclusions")
            require(u not in variables(q[0]) | variables(q[1]),
                    "test-range eigenvariable escapes")
            return p

        if rule == "lemma":
            fields(node, ("r", "name", "args", "premises"), "lemma")
            name = node["name"]
            require(type(name) is str and name in self.lemmas,
                    "lemma has not previously been proved")
            lemma = self.lemmas[name]
            require(lemma["theory"] == theory, "lemma theory mismatch")
            args, premises = node["args"], node["premises"]
            require(type(args) is dict and set(args) == set(lemma["parameters"]),
                    "lemma substitution domain mismatch")
            substitution = {v: parse(t) for v, t in args.items()}
            expected = tuple(tuple(replace(t, substitution) for t in e)
                             for e in lemma["assumptions"])
            require(type(premises) is list and len(premises) == len(expected),
                    "lemma premise count mismatch")
            actual = tuple(recurse(p) for p in premises)
            require(actual == expected, "lemma premises do not match")
            return tuple(replace(t, substitution) for t in lemma["goal"])

        raise Rejection("unknown proof rule: " + rule)

    def certificate(self, document):
        fields(document, ("format", "theorems"), "certificate")
        require(document["format"] == "selector-absorption-equations-v1",
                "unknown certificate format")
        require(type(document["theorems"]) is list, "theorems must be a list")
        summaries = []
        for declaration in document["theorems"]:
            fields(declaration,
                   ("name", "theory", "parameters", "assumptions", "goal", "proof"),
                   "theorem")
            name, theory = declaration["name"], declaration["theory"]
            require(type(name) is str and NAME.fullmatch(name) is not None,
                    "invalid theorem name")
            require(name not in self.lemmas, "duplicate theorem name")
            require(theory in ("abs", "ref"), "unknown axiom theory")
            parameters = declaration["parameters"]
            require(type(parameters) is list and all(type(v) is str and
                    NAME.fullmatch(v) is not None for v in parameters),
                    "invalid parameter list")
            require(len(parameters) == len(set(parameters)), "duplicate parameter")
            environment = set(parameters)
            raw_assumptions = declaration["assumptions"]
            require(type(raw_assumptions) is list, "assumptions must be a list")
            assumptions = tuple(equation(a, environment) for a in raw_assumptions)
            goal = equation(declaration["goal"], environment)
            start = self.nodes
            actual = self.proof(declaration["proof"], environment, assumptions, theory)
            require(actual == goal, "proved equation differs from declared goal")
            self.lemmas[name] = {
                "parameters": parameters, "assumptions": assumptions,
                "goal": goal, "theory": theory,
            }
            summaries.append({
                "name": name, "theory": theory, "parameters": parameters,
                "assumptions": [show(a) + " = " + show(b) for a, b in assumptions],
                "conclusion": show(goal[0]) + " = " + show(goal[1]),
                "proof_nodes": self.nodes - start,
            })
        return {"accepted": True, "theorems": summaries,
                "proof_nodes": self.nodes, "rule_counts": self.rules}


def main():
    try:
        if len(sys.argv) != 2:
            raise Rejection("usage: check_certificate.py CERTIFICATE.json")
        with open(sys.argv[1], encoding="utf-8") as stream:
            document = json.load(stream)
        result = Replay().certificate(document)
        print(json.dumps(result, indent=2, sort_keys=True))
    except (Rejection, OSError, ValueError, TypeError, KeyError, IndexError,
            RecursionError) as error:
        print(json.dumps({"accepted": False, "reason": str(error)}))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
