"""Build the primary report offline; no shell escape or external bibliography."""
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
STEM = "ipra_reflection_absorption"

def main():
    engine = shutil.which("pdflatex")
    if engine is None:
        raise SystemExit("pdflatex is required to rebuild the included PDF.")
    with tempfile.TemporaryDirectory(prefix="ipra-tex-") as tmp:
        for _ in range(3):
            result = subprocess.run(
                [engine, "-no-shell-escape", "-interaction=nonstopmode",
                 "-halt-on-error", "-file-line-error", "-output-directory", tmp,
                 str(ROOT / (STEM + ".tex"))],
                cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            if result.returncode:
                print(result.stdout)
                raise SystemExit(result.returncode)
        log = (Path(tmp) / (STEM + ".log")).read_text()
        evidence = ROOT / "evidence"
        evidence.mkdir(exist_ok=True)
        (evidence / "latex_build.log").write_text(log)
        problems = [line for line in log.splitlines()
                    if "Overfull" in line or "undefined" in line
                    or "LaTeX Warning" in line]
        (evidence / "latex_warnings.txt").write_text("\n".join(problems) + ("\n" if problems else ""))
        shutil.copy2(Path(tmp) / (STEM + ".pdf"), ROOT / (STEM + ".pdf"))
        print("PDF built; layout/reference warnings:", len(problems))
        for problem in problems:
            print(problem)

if __name__ == "__main__":
    main()
