"""Regenerate payload hashes and a deterministic ZIP after deliberate edits."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
IGNORED_SUFFIXES = {".aux", ".out", ".toc", ".pyc", ".synctex.gz"}

def members():
    return [p for p in sorted(ROOT.rglob("*"))
            if p.is_file() and "__pycache__" not in p.parts
            and p.suffix not in IGNORED_SUFFIXES
            and p.name != "MANIFEST.json"]

def main():
    files = members()
    manifest = {
        "format": "ipra-research-payload-sha256-v1",
        "files": [{"path": str(p.relative_to(ROOT)), "size": p.stat().st_size,
                   "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
                  for p in files],
    }
    (ROOT/"MANIFEST.json").write_text(json.dumps(manifest, indent=2)+"\n")
    files.append(ROOT/"MANIFEST.json")
    destination = ROOT.parent/(ROOT.name+".zip")
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for p in sorted(files):
            member = zipfile.ZipInfo(ROOT.name+"/"+str(p.relative_to(ROOT)),
                                     date_time=(2026,11,8,0,0,0))
            member.compress_type = zipfile.ZIP_DEFLATED
            member.external_attr = 0o100644 << 16
            archive.writestr(member, p.read_bytes())
    with zipfile.ZipFile(destination) as archive:
        bad = archive.testzip()
        if bad:
            raise SystemExit("Bad archive member: "+bad)
    print(json.dumps({"archive": str(destination),
                      "members": len(files), "bytes": destination.stat().st_size,
                      "sha256": hashlib.sha256(destination.read_bytes()).hexdigest()}))

if __name__ == "__main__":
    main()
