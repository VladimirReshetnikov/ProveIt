"""Reproduce symbolic verification, finite diagnostics, and source measurements."""
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def main():
    commands = [
        ["verification/run_checks.py"],
        ["verification/check_latch_bits.py"],
        ["comparison/measure.py"],
    ]
    receipts = []
    for args in commands:
        run = subprocess.run([sys.executable, *args], cwd=ROOT,
                             text=True, capture_output=True)
        receipts.append({"command": [sys.executable, *args],
                         "returncode": run.returncode,
                         "stdout": run.stdout, "stderr": run.stderr})
        print(args[0], "PASS" if run.returncode == 0 else "FAIL")
        if run.returncode:
            print(run.stdout)
            print(run.stderr)
            raise SystemExit(run.returncode)
    (ROOT/"evidence/reproduction.json").write_text(json.dumps({
        "python": platform.python_version(),
        "all_passed": True, "commands": receipts
    }, indent=2)+"\n")

if __name__ == "__main__":
    main()
