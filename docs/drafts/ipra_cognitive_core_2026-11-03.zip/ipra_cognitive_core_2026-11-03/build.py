#!/usr/bin/env python3
"""Run the included logical checks and compile the self-contained article."""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def main() -> None:
    root = Path(__file__).resolve().parent
    artifacts = root / "artifacts"
    artifacts.mkdir(exist_ok=True)
    checker = artifacts / "check_logic.py"
    if not checker.is_file():
        raise SystemExit("Missing artifacts/check_logic.py")
    check = subprocess.run(
        [sys.executable, str(checker)], cwd=root, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True,
    )
    (artifacts / "logical_check_output.txt").write_text(check.stdout)
    executable = shutil.which("pdflatex")
    if executable is None:
        raise SystemExit("pdflatex is required to compile report.tex")
    environment = os.environ.copy()
    environment.setdefault("SOURCE_DATE_EPOCH", "1793664000")
    passes = []
    with tempfile.TemporaryDirectory(prefix="ipra-core-tex-") as temporary:
        target = Path(temporary)
        for number in range(1, 4):
            result = subprocess.run(
                [executable, "-interaction=nonstopmode", "-halt-on-error",
                 "-file-line-error", f"-output-directory={target}", "report.tex"],
                cwd=root, env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            )
            passes.append({"pass": number, "returncode": result.returncode})
            if result.returncode:
                (artifacts / "latex_error.txt").write_text(result.stdout)
                raise SystemExit(result.stdout[-10000:])
        log = (target / "report.log").read_text(errors="replace")
        warnings = [line for line in log.splitlines()
                    if any(word in line for word in
                           ("Overfull", "Underfull", "Warning", "undefined"))]
        (artifacts / "latex_warnings.txt").write_text(
            "\n".join(warnings) + ("\n" if warnings else "No layout or reference warnings.\n")
        )
        shutil.copy2(target / "report.pdf", root / "report.pdf")
    summary = {
        "checker_exit_code": check.returncode,
        "latex_passes": passes,
        "latex_warnings": warnings,
        "pdf_bytes": (root / "report.pdf").stat().st_size,
        "formalization_scope": "Selected logical derivations only; see report Section 10.",
    }
    (artifacts / "build_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
