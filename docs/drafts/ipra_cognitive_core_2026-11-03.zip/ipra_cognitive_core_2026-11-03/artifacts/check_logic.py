#!/usr/bin/env python3
"""Generate and independently check finite natural-deduction certificates.

The kernel is minimal first-order logic with equality; it has NO falsity-
elimination rule. E(x,c) is a schematic atomic placeholder in the first two
proofs: substitution of an equation gives the intended equation instances.
Only the listed finite assumptions are trusted. This is not a formalization
of all iPRA, primitive-recursive representability, or bi-interpretability.
Run: python3 check_logic.py [--verify-only]
"""
from collections import Counter
from dataclasses import dataclass
import json
from pathlib import Path
import sys


V = lambda x: ("var", x)
F = lambda f, *ts: ("fun", f, tuple(ts))
Eq = lambda s, t: ("eq", s, t)
At = lambda p, *ts: ("atom", p, tuple(ts))
And = lambda a, b: ("and", a, b)
Or = lambda a, b: ("or", a, b)
Imp = lambda a, b: ("imp", a, b)
All = lambda x, a: ("all", x, a)
Some = lambda x, a: ("some", x, a)
Bot = ("bottom",)
ZERO = F("0")
S = lambda t: F("S", t)
Q = lambda n, a: F("Q", n, a)
FUNCTIONS = {"0": 0, "S": 1, "p": 1, "Q": 2, "f": 2, "g": 1}
PREDICATES = {"E": 2}


class InvalidProof(ValueError):
    pass


def need(condition, message):
    if not condition:
        raise InvalidProof(message)


def term_ok(t):
    need(isinstance(t, tuple) and len(t) >= 2, "malformed term")
    if t[0] == "var":
        need(len(t) == 2 and isinstance(t[1], str), "malformed variable")
    else:
        need(t[0] == "fun" and len(t) == 3, "malformed application")
        need(t[1] in FUNCTIONS and len(t[2]) == FUNCTIONS[t[1]], "function arity")
        for a in t[2]:
            term_ok(a)


def formula_ok(a):
    need(isinstance(a, tuple) and a, "malformed formula")
    if a == Bot:
        return
    need(len(a) == 3, "formula arity")
    k = a[0]
    if k == "eq":
        term_ok(a[1]); term_ok(a[2])
    elif k == "atom":
        need(a[1] in PREDICATES and len(a[2]) == PREDICATES[a[1]], "predicate arity")
        for t in a[2]:
            term_ok(t)
    elif k in ("and", "or", "imp"):
        formula_ok(a[1]); formula_ok(a[2])
    elif k in ("all", "some"):
        need(isinstance(a[1], str), "binder is not a variable")
        formula_ok(a[2])
    else:
        raise InvalidProof("unknown formula constructor")


def ft(t):
    return {t[1]} if t[0] == "var" else set().union(*(ft(a) for a in t[2]))


def ff(a):
    k = a[0]
    if k == "bottom": return set()
    if k == "eq": return ft(a[1]) | ft(a[2])
    if k == "atom": return set().union(*(ft(t) for t in a[2]))
    if k in ("all", "some"): return ff(a[2]) - {a[1]}
    return ff(a[1]) | ff(a[2])


def fresh(base, avoid):
    i = 0
    while base + "_" + str(i) in avoid:
        i += 1
    return base + "_" + str(i)


def st(t, x, u):
    if t[0] == "var": return u if t[1] == x else t
    return F(t[1], *(st(a, x, u) for a in t[2]))


def subst(a, x, u):
    """Capture-avoiding substitution of a term for a free variable."""
    k = a[0]
    if k == "bottom": return a
    if k == "eq": return Eq(st(a[1], x, u), st(a[2], x, u))
    if k == "atom": return At(a[1], *(st(t, x, u) for t in a[2]))
    if k in ("all", "some"):
        y, body = a[1:]
        if y == x or x not in ff(body): return a
        if y in ft(u):
            z = fresh(y, ff(body) | ft(u) | {x, y})
            body, y = subst(body, y, V(z)), z
        return (k, y, subst(body, x, u))
    return (k, subst(a[1], x, u), subst(a[2], x, u))


def key(a, bound=()):
    """An alpha-invariant key, using indices for bound occurrences."""
    def tk(t):
        if t[0] == "var":
            for i, x in enumerate(reversed(bound)):
                if t[1] == x: return ("bound", i)
            return ("free", t[1])
        return ("fun", t[1], tuple(tk(s) for s in t[2]))
    k = a[0]
    if k == "bottom": return a
    if k == "eq": return (k, tk(a[1]), tk(a[2]))
    if k == "atom": return (k, a[1], tuple(tk(t) for t in a[2]))
    if k in ("all", "some"): return (k, key(a[2], bound + (a[1],)))
    return (k, key(a[1], bound), key(a[2], bound))


same = lambda a, b: key(a) == key(b)
drop = lambda context, a: frozenset(b for b in context if not same(a, b))
free_context = lambda context: set().union(*(ff(a) for a in context))


@dataclass(frozen=True)
class Proof:
    rule: str
    formula: tuple
    premises: tuple = ()
    data: tuple = ()


def N(rule, formula, *premises, data=()):
    return Proof(rule, formula, premises, data)


def verify(root, allowed):
    """Independent kernel: reconstruct open assumptions, never trust contexts."""
    cache, nodes, active = {}, {}, set()
    arities = {"hyp": (0, 0), "eq_refl": (0, 0), "eq_elim": (2, 2),
               "and_intro": (2, 0), "and_left": (1, 0), "and_right": (1, 0),
               "or_left": (1, 0), "or_right": (1, 0), "or_elim": (3, 0),
               "imp_intro": (1, 0), "imp_elim": (2, 0), "all_intro": (1, 0),
               "all_elim": (1, 1), "some_intro": (1, 1), "some_elim": (2, 1)}
    def walk(n):
        ident = id(n)
        if ident in cache: return cache[ident]
        need(ident not in active, "cyclic proof")
        active.add(ident)
        formula_ok(n.formula)
        r, c, ps, d = n.rule, n.formula, n.premises, n.data
        need(r in arities, "unknown inference rule: " + r)
        need((len(ps), len(d)) == arities[r], "rule arity: " + r)
        cs = [walk(p) for p in ps]
        gamma = frozenset().union(*cs)
        fs = [p.formula for p in ps]
        if r == "hyp": gamma = frozenset({c})
        elif r == "eq_refl": need(c[0] == "eq" and c[1] == c[2], "reflexivity")
        elif r == "eq_elim":
            x, template = d
            need(isinstance(x, str), "equality placeholder")
            formula_ok(template)
            need(fs[0][0] == "eq", "equality premise")
            need(same(fs[1], subst(template, x, fs[0][1])), "equality source")
            need(same(c, subst(template, x, fs[0][2])), "equality target")
        elif r == "and_intro": need(same(c, And(*fs)), "conjunction introduction")
        elif r in ("and_left", "and_right"):
            need(fs[0][0] == "and", "conjunction premise")
            need(same(c, fs[0][1 if r == "and_left" else 2]), "conjunction elimination")
        elif r in ("or_left", "or_right"):
            need(c[0] == "or", "disjunction conclusion")
            need(same(fs[0], c[1 if r == "or_left" else 2]), "disjunction introduction")
        elif r == "or_elim":
            need(fs[0][0] == "or" and same(fs[1], c) and same(fs[2], c), "case split")
            gamma = cs[0] | drop(cs[1], fs[0][1]) | drop(cs[2], fs[0][2])
        elif r == "imp_intro":
            need(c[0] == "imp" and same(fs[0], c[2]), "implication introduction")
            gamma = drop(cs[0], c[1])
        elif r == "imp_elim":
            need(fs[0][0] == "imp", "implication premise")
            need(same(fs[0][1], fs[1]) and same(c, fs[0][2]), "modus ponens")
        elif r == "all_intro":
            need(c[0] == "all" and same(c[2], fs[0]), "universal introduction")
            need(c[1] not in free_context(gamma), "universal eigenvariable")
        elif r == "all_elim":
            term_ok(d[0]); need(fs[0][0] == "all", "universal premise")
            need(same(c, subst(fs[0][2], fs[0][1], d[0])), "universal substitution")
        elif r == "some_intro":
            term_ok(d[0]); need(c[0] == "some", "existential conclusion")
            need(same(fs[0], subst(c[2], c[1], d[0])), "existential witness")
        elif r == "some_elim":
            v = d[0]
            need(isinstance(v, str) and fs[0][0] == "some", "existential premise")
            need(same(fs[1], c), "existential branch conclusion")
            gamma = cs[0] | drop(cs[1], subst(fs[0][2], fs[0][1], V(v)))
            need(v not in ff(c) | ff(fs[0]) | free_context(gamma), "existential eigenvariable")
        active.remove(ident)
        cache[ident], nodes[ident] = gamma, n
        return gamma
    for a in allowed: formula_ok(a)
    context = walk(root)
    need({key(a) for a in context} <= {key(a) for a in allowed}, "unlicensed open assumption")
    return {"node_count": len(nodes), "rules": dict(sorted(Counter(n.rule for n in nodes.values()).items())),
            "open_assumptions": [show(a) for a in sorted(context, key=repr)],
            "conclusion": show(root.formula)}


# The following proof-building conveniences are NOT trusted by the kernel.
H = lambda a: N("hyp", a)
Refl = lambda t: N("eq_refl", Eq(t, t))
AI = lambda p, q: N("and_intro", And(p.formula, q.formula), p, q)
AL = lambda p: N("and_left", p.formula[1], p)
AR = lambda p: N("and_right", p.formula[2], p)
OL = lambda p, b: N("or_left", Or(p.formula, b), p)
OR = lambda a, p: N("or_right", Or(a, p.formula), p)
OE = lambda p, q, r: N("or_elim", q.formula, p, q, r)
II = lambda a, p: N("imp_intro", Imp(a, p.formula), p)
IE = lambda p, q: N("imp_elim", p.formula[2], p, q)
UI = lambda x, p: N("all_intro", All(x, p.formula), p)
UE = lambda p, t: N("all_elim", subst(p.formula[2], p.formula[1], t), p, data=(t,))
EI = lambda a, t, p: N("some_intro", a, p, data=(t,))


def EE(p, q, template, x):
    return N("eq_elim", subst(template, x, p.formula[2]), p, q, data=(x, template))


def symmetric(p):
    s, t = p.formula[1:]
    z = fresh("e", ft(s) | ft(t))
    return EE(p, Refl(s), Eq(V(z), s), z)


def transitive(p, q):
    z = fresh("e", ft(p.formula[1]) | ft(q.formula[1]) | ft(q.formula[2]))
    return EE(q, p, Eq(p.formula[1], V(z)), z)


def congruent(p, name, args, slot):
    z = fresh("e", set().union(*(ft(t) for t in args)) | ft(p.formula[2]))
    target = list(args); target[slot] = V(z)
    source = F(name, *args)
    return EE(p, Refl(source), Eq(source, F(name, *target)), z)


def build_theorems():
    x, c = V("x"), V("c")
    E = lambda t: At("E", t, c)
    P = lambda t: Or(Eq(t, ZERO), E(t))
    closure = All("x", Imp(P(x), P(S(x))))
    z = Imp(closure, All("x", P(x)))
    progress = All("x", Imp(E(x), E(S(x))))
    premise = And(E(ZERO), progress)
    ih = H(premise)
    def base_case(t):
        equality = symmetric(H(Eq(t, ZERO)))
        return EE(equality, AL(ih), E(V("u")), "u")
    ex = OE(H(P(x)), base_case(x), H(E(x)))
    closed = UI("x", II(P(x), OR(Eq(S(x), ZERO), IE(UE(AR(ih), x), ex))))
    all_p = IE(UE(H(All("c", z)), c), closed)
    all_e = UI("x", OE(UE(all_p, x), base_case(x), H(E(x))))
    first = UI("c", II(premise, all_e))
    ind_p = Imp(And(P(ZERO), closure), All("x", P(x)))
    second = UI("c", II(closure, IE(UE(H(All("c", ind_p)), c), AI(OL(Refl(ZERO), E(ZERO)), H(closure)))))
    ec = lambda t: Eq(S(F("p", t)), t)
    pc = lambda t: Or(Eq(t, ZERO), ec(t))
    zc = Imp(All("x", Imp(pc(x), pc(S(x)))), All("x", pc(x)))
    predecessor = All("x", Eq(F("p", S(x)), x))
    es = congruent(UE(H(predecessor), x), "S", (F("p", S(x)),), 0)
    third = IE(H(zc), UI("x", II(pc(x), OR(Eq(S(x), ZERO), es))))
    results = [("Z_implies_contextual_equation_induction", first, [All("c", z)]),
               ("QF_induction_for_zero_or_E_implies_Z", second, [All("c", ind_p)]),
               ("Z_and_predecessor_equation_imply_coverage", third, [zc, predecessor])]
    bridge = Imp(Bot, Eq(ZERO, S(ZERO)))
    q0 = All("a", Eq(Q(ZERO, V("a")), V("a")))
    qs = All("n", All("a", Eq(Q(S(V("n")), V("a")), V("n"))))
    hb, hq0, hqs = H(bridge), H(q0), H(qs)
    delta = IE(hb, H(Bot))
    def collapse(t):
        left = symmetric(UE(hq0, t))
        middle = congruent(delta, "Q", (ZERO, t), 0)
        return transitive(transitive(left, middle), UE(UE(hqs, ZERO), t))
    def explode(a):
        k = a[0]
        if k == "bottom": return H(Bot)
        if k == "eq": return transitive(collapse(a[1]), symmetric(collapse(a[2])))
        if k == "and": return AI(explode(a[1]), explode(a[2]))
        if k == "or": return OL(explode(a[1]), a[2])
        if k == "imp": return II(a[1], explode(a[2]))
        if k == "all": return UI(a[1], explode(a[2]))
        if k == "some": return EI(a, ZERO, explode(subst(a[2], a[1], ZERO)))
        raise ValueError("explosion language has equality atoms only")
    y, u, v, w = map(V, ("y", "u", "v", "w"))
    targets = [("equation", Eq(F("f", x, y), ZERO)), ("bottom", Bot),
               ("connectives", And(Eq(x, ZERO), Or(Eq(Q(S(y), x), F("p", x)), Bot))),
               ("quantified", All("v", Some("w", Imp(Eq(w, S(v)),
                  And(Eq(F("f", v, w), ZERO), Or(Bot, Eq(v, w))))))),
               ("existential_antecedent", Imp(Some("u", Eq(F("f", u, x), ZERO)),
                  All("v", Some("w", Imp(Eq(v, w), Eq(F("g", w), x))))))]
    for label, target in targets:
        proof = II(Bot, explode(target))
        for name in reversed(sorted(ff(target))): proof = UI(name, proof)
        results.append(("arithmetic_explosion_" + label, proof, [bridge, q0, qs]))
    capture = All("x", Some("y", Eq(x, y)))
    results.append(("capture_avoiding_specialization", UE(H(capture), y), [capture]))
    return results


def show(a):
    def ts(t):
        return t[1] if t[0] == "var" or not t[2] else t[1] + "(" + ",".join(map(ts, t[2])) + ")"
    k = a[0]
    if k == "bottom": return "bottom"
    if k == "eq": return "(" + ts(a[1]) + "=" + ts(a[2]) + ")"
    if k == "atom": return a[1] + "(" + ",".join(map(ts, a[2])) + ")"
    if k in ("all", "some"): return k + " " + a[1] + ". " + show(a[2])
    return "(" + show(a[1]) + " " + k + " " + show(a[2]) + ")"


def encode(theorems):
    nodes, seen = [], {}
    def visit(p):
        if id(p) not in seen:
            children = [visit(q) for q in p.premises]
            seen[id(p)] = len(nodes)
            nodes.append({"rule": p.rule, "formula": p.formula, "premises": children, "data": p.data})
        return seen[id(p)]
    roots = [{"name": n, "root": visit(p), "assumptions": a} for n, p, a in theorems]
    return {"format_version": 1, "nodes": nodes, "theorems": roots}


def decode(data):
    freeze = lambda a: tuple(map(freeze, a)) if isinstance(a, list) else a
    need(data["format_version"] == 1, "certificate format")
    nodes = []
    for i, row in enumerate(data["nodes"]):
        need(all(isinstance(j, int) and 0 <= j < i for j in row["premises"]), "non-prior proof reference")
        nodes.append(Proof(row["rule"], freeze(row["formula"]), tuple(nodes[j] for j in row["premises"]), freeze(row["data"])))
    return [(r["name"], nodes[r["root"]], [freeze(a) for a in r["assumptions"]]) for r in data["theorems"]]


def rejection_tests(theorems):
    x, y = V("x"), V("y")
    a = Eq(x, ZERO)
    capture = All("x", Some("y", Eq(x, y)))
    tests = [("bad_universal_eigenvariable", UI("x", H(a)), [a]),
             ("capturing_universal_substitution", N("all_elim", Some("y", Eq(y, y)), H(capture), data=(y,)), [capture]),
             ("forbidden_falsity_elimination", N("bottom_elim", a, H(Bot)), [Bot])]
    ex = Some("x", Eq(x, ZERO))
    tests.append(("bad_existential_eigenvariable", N("some_elim", Eq(y, ZERO), H(ex), H(Eq(y, ZERO)), data=("y",)), [ex]))
    _, explosion, assumptions = next(t for t in theorems if t[0] == "arithmetic_explosion_equation")
    tests.append(("removed_arithmetic_bridge", explosion, assumptions[1:]))
    receipt = []
    for name, proof, allowed in tests:
        try:
            verify(proof, allowed)
        except InvalidProof as error:
            receipt.append({"name": name, "rejected": True, "reason": str(error)})
        else:
            raise AssertionError("invalid certificate accepted: " + name)
    return receipt


def main():
    directory = Path(__file__).resolve().parent
    certificate_path = directory / "logic_certificates.json"
    if "--verify-only" not in sys.argv:
        certificate_path.write_text(json.dumps(encode(build_theorems()), indent=2) + "\n")
    theorems = decode(json.loads(certificate_path.read_text()))
    checks = [{"name": name, **verify(proof, assumptions)} for name, proof, assumptions in theorems]
    receipt = {"status": "PASS", "kernel": "minimal first-order natural deduction with equality",
               "falsity_elimination_rule": False, "certificate_file": certificate_path.name,
               "scope": "Finite logical transformations and explosion examples; NOT a full iPRA formalization or bi-interpretability proof.",
               "trust_boundary": "Only each theorem's listed finite open assumptions; contexts, substitution, and eigenvariables are checked.",
               "checks": checks, "rejection_tests": rejection_tests(theorems)}
    (directory / "logic_checks.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"status": receipt["status"], "theorems": len(checks),
                      "checked_nodes_summed": sum(c["node_count"] for c in checks),
                      "negative_tests": len(receipt["rejection_tests"])}))


if __name__ == "__main__":
    main()
