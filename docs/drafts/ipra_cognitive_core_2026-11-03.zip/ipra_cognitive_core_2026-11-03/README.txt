A READABLE CORE FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
3 November 2026
============================================================

Start with report.pdf. SPECIFICATION.txt gives the complete concise system.

RECOMMENDATION
Use ordinary intuitionistic first-order logic, initialized primitive
recursion equations, 0 != S0, and contextual quantifier-free induction.
The full constructor laws are derived. Keep the current equation-closure
schema as an exact restricted companion, with a proved equivalence.

WHAT THIS PACKAGE CONTRIBUTES
- A cognitive comparison of the four current and four archived proposals
  at a fixed repository commit.
- A complete, familiar presentation with no mandatory program optimizer
  or custom logical binder.
- Explicit whole-carrier bi-interpretations with iPRA and internally
  identity composites, including nonstandard inputs.
- A noncircular proof of equivalence with equation closure and witnessed
  boundaries, and the product counterexample to insufficient atomic
  induction.
- An optional minimal-logic companion deriving falsity elimination from
  the arithmetic bridge FALSE -> 0=S0, while preserving genuine falsity.
- A small inspectable proof checker for selected logical transformations.

CLAIM LIMITS
The equation-closure core and ordinary quantifier-free induction are
existing mathematics, explicitly credited. The recommendation improves
the presentation under the user's revised cognitive objective; it does
not claim a global minimum, a new asymptotic result, or a strict reduction
of every expression in every source grammar. Source-relative optimizer
results remain useful derived arithmetic, not prerequisites to learning
the theory.

The full metatheorem has a written mathematical proof. The Python
artifact checks selected finite first-order proofs; it is not a Lean,
Rocq, or complete independent formalization of the entire metatheorem.

FILES
report.tex, report.pdf                 Complete article
SPECIFICATION.txt                     Standalone exact specification
build.py                              Checks and PDF compilation
artifacts/check_logic.py              Small proof checker and certificates
artifacts/logic_checks.json            Generated logical check results
artifacts/build_summary.json          Compilation/check summary
provenance/source_manifest.json       Pinned archive hashes and URLs
provenance/comparison.csv              Per-draft comparison
provenance/audit_notes.txt             Audit scope and historical filter
SHA256SUMS.txt                        Delivered-file checksums

REBUILD
Requirements: Python 3.10+ and a TeX distribution providing pdflatex and
the standard packages named in report.tex. No third-party Python modules
are required by the included checker.

From this directory run:
  python3 build.py

The script runs the logical checks, compiles the article, and writes
report.pdf and artifacts/build_summary.json. It does not fetch sources
or install dependencies. Render the resulting PDF with a PDF viewer
when making layout changes.

SOURCE SNAPSHOT
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 77e7fdf4a46344cc79cc9c88d78954bab1764ec5
Directory: docs/drafts and its archived subdirectory
All eight original ZIP blob identities were verified.
