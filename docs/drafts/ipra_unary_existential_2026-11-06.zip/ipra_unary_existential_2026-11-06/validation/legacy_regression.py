"""Isolate the binding refactor on the old binary-Sigma calculus."""

import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def accepts(module, data):
    try:
        return module.check(data) is True
    except (ValueError, TypeError, IndexError, KeyError, RecursionError):
        return False


def main():
    old = load("old", ROOT / "comparison/composed.py")
    new = load("binary_control", ROOT / "controls/binary_matched_bundled.py")
    cases = []
    for path in sorted((ROOT / "validation/legacy_certificates").glob("*.json")):
        data = json.loads(path.read_text())
        expected, actual = accepts(old, data), accepts(new, data)
        if expected != actual:
            raise AssertionError(path.name)
        cases.append(dict(file=path.name, accepted=actual))
    result = dict(count=len(cases), accepted=sum(c["accepted"] for c in cases),
                  rejected=sum(not c["accepted"] for c in cases), differences=0,
                  scope=("Old binary-Sigma arithmetic/substitution refactor only; "
                         "these are not claimed as direct unary-E certificates."),
                  cases=cases)
    (ROOT / "validation/legacy_results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "cases"}, indent=2))


if __name__ == "__main__":
    main()
