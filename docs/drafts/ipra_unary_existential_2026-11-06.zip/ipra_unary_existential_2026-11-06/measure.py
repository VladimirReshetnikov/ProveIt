"""Measure complete acceptance programs without importing them."""

import ast
import hashlib
import io
import json
import platform
import tokenize
from pathlib import Path

ROOT = Path(__file__).resolve().parent
AXES = ("raw_bytes", "normalized_bytes", "source_tokens",
        "normalized_tokens", "ast_nodes")


class RemoveDocstrings(ast.NodeTransformer):
    def clean(self, node):
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body.pop(0)
        return self.generic_visit(node)

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(path):
    data = path.read_bytes()
    source = data.decode("utf-8")
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef,
                             ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                doc = node.body[0]
                spans.append(((doc.lineno, doc.col_offset),
                              (doc.end_lineno, doc.end_col_offset)))
    excluded = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
                tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT}
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(source).readline)
              if t.type not in excluded
              and not any(lo <= t.start and t.end <= hi for lo, hi in spans)]
    tree = RemoveDocstrings().visit(tree)
    normalized = ast.unparse(tree) + "\n"
    ntokens = [t for t in tokenize.generate_tokens(io.StringIO(normalized).readline)
               if t.type not in excluded]
    return dict(sha256=hashlib.sha256(data).hexdigest(),
                raw_bytes=len(data), normalized_bytes=len(normalized.encode()),
                source_tokens=len(tokens), normalized_tokens=len(ntokens),
                ast_nodes=sum(1 for _ in ast.walk(tree)),
                lines=len(source.splitlines()))


def main():
    index = json.loads((ROOT / "comparison/index.json").read_text())
    rows = []
    for record in index["checkers"]:
        result = measure(ROOT / record["path"])
        if result["sha256"] != record["sha256"]:
            raise ValueError("Comparator changed: " + record["path"])
        rows.append(dict(record, metrics=result))
    candidate = measure(ROOT / "checker.py")
    controls = {p.stem: measure(p) for p in sorted((ROOT / "controls").glob("*.py"))}
    minima = {k: min(r["metrics"][k] for r in rows) for k in AXES}
    savings = {k: dict(absolute=minima[k] - candidate[k],
                       percent=100 * (minima[k] - candidate[k]) / minima[k])
               for k in AXES}
    result = dict(
        repository=index["repository"], commit=index["commit"],
        python_version=platform.python_version(),
        method=("All source in the complete acceptance programs is counted, "
                "including formation, binding, axioms, falsity conversion, "
                "imports, JSON and command-line handling. Only comments, "
                "docstrings and layout are excluded from significant tokens. "
                "Normalized source is ast.unparse after docstring removal. "
                "Python and the standard library are the common runtime."),
        checkers=rows, coordinate_minima=minima, candidate=candidate,
        savings=savings, controls=controls,
        strictly_below_every_coordinate=all(candidate[k] < minima[k] for k in AXES))
    (ROOT / "validation/metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    labels = {
        "combined": "Combined", "compact": "Compact",
        "compact_kernel": "Compact kernel",
        "compact_kernel_1": "Compact kernel (1)",
        "compact_kernel_1_lists": "Compact (1), list variant",
        "compact_kernel_1_native": "Compact (1), native variant",
        "composed": "Composed", "factored": "Factored",
    }
    table = [r"\begin{tabular}{@{}lrrrr@{}}", r"\toprule",
             r"Complete checker & Bytes & Norm.\ bytes & Norm.\ tokens & AST \\",
             r"\midrule"]
    keys = ("raw_bytes", "normalized_bytes", "normalized_tokens", "ast_nodes")
    for row in rows:
        table.append(labels[row["id"]] + " & "
                     + " & ".join(f'{row["metrics"][k]:,}' for k in keys) + r" \\")
    table += [r"\midrule", "Coordinate minima & "
              + " & ".join(f"{minima[k]:,}" for k in keys) + r" \\",
              r"\textbf{Unary-existential kernel} & "
              + " & ".join(r"\textbf{" + f"{candidate[k]:,}" + "}" for k in keys)
              + r" \\", r"\bottomrule", r"\end{tabular}"]
    (ROOT / "validation/comparison_table.tex").write_text("\n".join(table) + "\n")
    macros = {"CandidateTokens": candidate["normalized_tokens"],
              "CandidateSourceTokens": candidate["source_tokens"],
              "CandidateAST": candidate["ast_nodes"],
              "CandidateBytes": candidate["raw_bytes"],
              "CandidateNormBytes": candidate["normalized_bytes"],
              "MinimumTokens": minima["normalized_tokens"],
              "MinimumAST": minima["ast_nodes"],
              "MinimumBytes": minima["raw_bytes"],
              "MinimumNormBytes": minima["normalized_bytes"]}
    (ROOT / "validation/metrics_macros.tex").write_text("".join(
        "\\newcommand{\\" + name + "}{" + str(value) + "}\n"
        for name, value in macros.items()))
    print(json.dumps(dict(candidate=candidate, minima=minima,
                          strictly_below=result["strictly_below_every_coordinate"]),
                     indent=2))


if __name__ == "__main__":
    main()
