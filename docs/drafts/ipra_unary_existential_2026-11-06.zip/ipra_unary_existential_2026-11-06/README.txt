A SMALLER iPRA KERNEL WITH UNARY EXISTENTIAL QUANTIFICATION
6 November 2026

Start with report.pdf. The complete LaTeX source is report.tex plus sections/.
The complete trusted proof checker is checker.py (standard Python only).

The native logical syntax uses equality, Pi_x(A;B), and unary Ex_x A.
Full intuitionistic conjunction and disjunction are recovered by the
formula-amalgamation construction proved in the report. Public genuine
falsity is explicitly converted to the arithmetic contradiction 0=S0.

Main results:
  - Full first-order iPRA, not merely its quantifier-free fragment.
  - Explicit whole-domain bi-interpretations and syntactic equiconsistency.
  - 865 normalized Python tokens / 926 executable AST nodes for the entire
    checker, below the pinned current coordinate minima 957 / 1013.
  - 116 positive and 60 negative native certificates; all positives also
    checked after expansion by a separate, unchanged existing draft checker.

The repository comparison is pinned to ProveIt commit:
36fb791c722edc2549719744c38feef74fa422fb

The size claim is a reproducible finite comparison, not an absolute
shortest-program theorem. General metatheorems are proved mathematically;
this package does not claim a Lean or Rocq formalization.

REPRODUCTION

Requirements: Python 3.10+; pdfLaTeX with the conventional packages listed
in report.tex. Run from any directory:

  python3 /absolute/path/to/this/package/reproduce.py

Individual checks from the package directory:

  python3 measure.py
  python3 validation/validate.py
  python3 validation/independent_binding.py
  python3 validation/legacy_regression.py
  python3 build.py
  python3 checker.py validation/certificates/induction_zero_plus_n.json

The final command prints ACCEPT. The certificate proves 0+n=n without
assumptions. In any input, a nonempty assumptions list certifies only the
displayed sequent under those assumptions.

FILES

checker.py                  The entire trusted acceptance program.
report.tex, sections/       Complete research article source.
report.pdf                  Compiled article.
comparison/                 Frozen eight current checker variants; exact
                            repository/archive/source provenance and hashes.
controls/                   Matched binary-Sigma ablations.
validation/builder.py       Untrusted general proof construction library.
validation/translate.py     Untrusted expansion to the separate compact kernel.
validation/validate.py      Native certificate, expansion, and CLI tests.
validation/certificates/    All 176 materialized native test fixtures.
validation/legacy_certificates/
                            The composed draft's 123 binary-calculus fixtures.
validation/*.json           Exact finite outcomes and measurement data.
SHA256SUMS.txt              Hashes of packaged files, excluding this manifest.

The proof builder, translator, comparison sources, and tests are not
imported by checker.py. Certificate generators may be wrong without
being able to bypass the kernel. Finite stack and memory limits may reject
large otherwise valid proofs; all delivered examples work at the default
Python recursion limit.

ATTRIBUTION

The initialized-recursion basis, guarded binders, arithmetic falsity,
witness-equation introduction, numerical induction/cases schema, and
arithmetic reflection follow the supplied ProveIt drafts. This iteration
adds the unary-existential formula-amalgamation reduction and a smaller
finite-prefix substitution implementation. See the report and comparison
inventory for precise provenance. The old draft sources are included
unchanged for reproducible comparisons.
