"""Reproduce source measurements, finite verification, and the report PDF."""

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    for script in (
        "measure.py",
        "validation/validate.py",
        "validation/independent_binding.py",
        "validation/legacy_regression.py",
        "build.py",
    ):
        print("\nRunning " + script, flush=True)
        subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
