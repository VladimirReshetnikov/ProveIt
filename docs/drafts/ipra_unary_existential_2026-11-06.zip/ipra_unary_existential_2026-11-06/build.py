"""Compile the report, retaining diagnostics separately from the final PDF."""

import json
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    build = ROOT / "build"
    build.mkdir(exist_ok=True)
    for _ in range(3):
        run = subprocess.run(
            ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
             "-file-line-error", "-output-directory=build", "report.tex"],
            cwd=ROOT, text=True, capture_output=True)
        (build / "stdout.txt").write_text(run.stdout + run.stderr)
        if run.returncode:
            print(run.stdout[-7000:])
            raise SystemExit(run.returncode)
    shutil.copyfile(build / "report.pdf", ROOT / "report.pdf")
    log = (build / "report.log").read_text()
    issues = [line for line in log.splitlines()
              if any(word in line for word in ("Overfull", "undefined", "Warning:"))]
    (ROOT / "validation/latex_results.json").write_text(
        json.dumps(dict(passes=3, success=True, diagnostics=issues), indent=2) + "\n")
    print(json.dumps(dict(pdf=str(ROOT / "report.pdf"), diagnostics=issues), indent=2))


if __name__ == "__main__":
    main()
