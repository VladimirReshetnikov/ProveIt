# Local rewriting and successor-seeded scalar recursion for iPRA

Research prepared for Vladimir Reshetnikov, 10 November 2026.

## Main result

The report gives an explicit presentation of full first-order intuitionistic
primitive recursive arithmetic whose numerical terms use only zero and a
single scalar recursor. Successor is an abbreviation. The recursor begins
with the successor of its initializer; its update receives its previous
state, without a recursion-counter input. A finite transposition first
recovers zero initialization. An internal predecessor construction then
recovers arbitrary initialization and all fixed primitive recursions.

The logical presentation has equations and one paired binder. Its primitive
equality rule rewrites one numerical occurrence in an equation. There is
no general hypothesis-conclusion rule. The report supplies exact finite
expansions for identity and arbitrary formula transport. Both interpretations
keep the whole numerical domain and actual equality, and the two composites
are proved internally.

The complete implementation accepts general transport as a proved derived
rule. It is not a direct occurrence-restricted checker. This distinction is
explained in the report.

## Comparison with the current drafts

The comparison is pinned to ProveIt commit
`7bded17cc0122767f86e494fcf256b47fe85c9b8`. All ten ZIP archives in its
`docs/drafts` directory were inspected: 154 Python source occurrences,
109 distinct raw source hashes. Full modules are normalized with the
inherited `ast.unparse` method under CPython 3.12.14.

| Complete checker | Normalized tokens | AST nodes | Normalized bytes |
| --- | ---: | ---: | ---: |
| Existing token leader | 287 | 328 | 749 |
| Existing AST leader | 293 | 323 | 893 |
| Existing byte leader | 305 | 351 | 738 |
| New scalar byte profile | 290 | 334 | **685** |
| New scalar balanced profile | **286** | **320** | **736** |
| Counter-aware focused control | 295 | 339 | 689 |
| Counter-aware hypothesis control | 294 | 336 | 706 |

The byte profile saves 53 bytes (about 7.18%) against the old byte leader.
The balanced profile beats every old coordinate minimum in one complete
program: by one token, three AST nodes, and two normalized bytes. This
second profile is measured on the fixed CPython runtime. Its permissive
opener rejects nonempty strings through the runtime's recursion limit;
with an ideal unbounded stack those malformed inputs need not terminate.
Canonical array/integer certificates terminate structurally. The byte
profile uses a direct list-type guard and has no such iterable-alias
mechanism. The report explains both profiles and this qualification.

Attained sizes are upper bounds on an unknown minimum, not impossibility
bounds. No absolute minimality, literature-wide novelty, or proof-assistant
certification is claimed.

## Read the report

- `ipra_local_rewriting.pdf`: complete typeset report.
- `ipra_local_rewriting.tex`: standalone LaTeX source, including the checker.
- `report.tex` and `theory/`: modular sources of the same report.

The main dependency order is:

1. Local rewriting gives reflexivity, identity, equation induction,
   numerical cases, and general transport.
2. Boxing derives computation at arbitrary predecessor terms.
3. A finite transposition gives a zero-seeded scalar iterator.
4. Finite-state factor identities give a comparator and predecessor.
5. Predecessor gives initialized iteration and an ordinary selector.
6. The paired binder recovers all ordinary intuitionistic logic.
7. Actual equality reflection gives quantifier-free induction; pairing
   then compiles every fixed primitive recursion.
8. Uniqueness and formula reconstruction establish both interpretation
   composites on the whole numerical domain.

## Reproduce the executable evidence

From this directory, using Python 3.12:

```sh
python3 reproduce.py
```

This regenerates certificates, runs the complete public checkers normally
and with `-O`, and measures the entire source modules. The reference
normalizer is unchanged from the pinned corpus. Exact normalization counts
may differ with another Python version.

The recorded successful runs are:

- 68 scalar-checker runs: 12 positive and 22 negative certificates, each
  in ordinary and optimized Python.
- 104 balanced-profile runs: 12 positive, 22 negative, and 18 additional
  alias/hole cases, each in ordinary and optimized Python.
- 116 runs of the two counter-aware comparison programs.
- 302 finite arithmetic checks evaluated directly from the primitive R.
- 236 independent finite arithmetic diagnostics.

These computations do not prove universal soundness, the universal
arithmetic identities, or facts about nonstandard models. Those claims
are supported by the mathematical proofs and scoped reviews in the report
and evidence directory. The finite tests check examples and important
rejection cases.

To submit a single JSON certificate, use:

```sh
python3 code/kernel_scalar_boxed.py < certificate.json
```

Use `code/kernel_balanced.py` for the second profile. Its producer prunes
goals already in the context, whereas the focused byte profile explicitly
expands identity; corresponding certificate streams are generated by the
included producers and validators.

The final array member is the goal. Earlier members are packets consumed
backwards. Successful finite verification prints `ACCEPT`; failure prints
`REJECT` and exits nonzero. `code/FORMAT.md` documents the syntax, sorted
opening, aliases, fresh parameters, canonical zero, and boxed computation
certificates. The fixture files contain named collections, not a single
certificate each; `reproduce.py` selects and submits their entries.

## Rebuild the PDF

With a standard TeX Live installation including the packages named in
`report.tex`:

```sh
python3 build.py
```

This expands the modular sources into `ipra_local_rewriting.tex`, inlines
the complete checker, and runs `pdflatex` until references stabilize. The
standalone source also compiles directly with `pdflatex`.

## Contents and trust boundary

- `code/kernel_scalar_boxed.py` is the complete 685-byte profile.
- `code/kernel_balanced.py` is the complete 286-token/320-node/736-byte
  profile, with the fixed-runtime qualification stated above.
- `code/kernel_counter.py` and `code/control_counter.py` are explicit
  comparison programs with a different numerical update interface.
- Producers, validators, finite evaluators, build scripts, and measurement
  scripts are supporting artifacts; none is imported by the main checker.
- `reference/` contains the unchanged programs attaining the three old
  coordinate minima, the original normalizer, a source manifest, and the
  repository license.
- `evidence/` contains exact source inventories, metrics, validation
  results, scoped independent reviews, and build/inspection records.
- `MANIFEST.sha256` records every packaged file other than itself.

The checker trusts the fixed Python interpreter and standard JSON library,
as do the compared drafts. It does not evaluate Python supplied by a proof,
call a hidden arithmetic evaluator, or trust the producer's assertions.
The mathematical proof-to-certificate construction concerns finite
derivations under unbounded resources; a particular finite machine can
reject large valid inputs by exhausting its resources.

The new work is explicitly distinguished from inherited Choice-DI,
elimination-only assumptions, endpoint certificates, shared continuations,
and counter-aware successor initialization. See the report's provenance
section and the reference manifest for attribution.
