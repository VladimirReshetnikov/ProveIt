# Final implementation review

This note records the complete-program audit and its limits. The independent
review of the new scalar arithmetic is in `implementation_arithmetic_review.md`.
The full explanation and general invariants appear in the report's implementation
section; `code/FORMAT.md` specifies the public certificate boundary.

## Snapshot

ProveIt commit: `7bded17cc0122767f86e494fcf256b47fe85c9b8`.
The ten current draft archives contain 154 Python-source occurrences and
109 distinct raw hashes. Complete checkers in comparison/reference directories
count toward the benchmark. Build, producer, and test scripts do not.

The current coordinate envelope is 287 normalized tokens, 323 AST nodes, and
738 normalized bytes, with different attainers. These attained descriptions
are upper bounds on the unknown minimum; they are not mathematical lower bounds.

| Complete standalone program | Tokens | AST | Normalized bytes |
|---|---:|---:|---:|
| Endpoint token leader | 287 | 328 | 749 |
| Endpoint matched structural control | 293 | 323 | 893 |
| Successor-recursion byte leader | 305 | 351 | 738 |
| New scalar boxed checker | 290 | 334 | 685 |
| New counter-aware focused control | 295 | 339 | 689 |
| New counter-aware Hyp control | 294 | 336 | 706 |

The scalar program saves 53 bytes (7.18%) against the byte leader, but adds
three tokens and eleven AST nodes compared with the independent coordinate
minima. It does not dominate all three coordinates. The code improvement and
the new scalar arithmetic construction are separate claims.

## Trust and verification boundary

Every measured file contains its entire checker, including JSON import and
parsing, opening and scoping, rule dispatch, arithmetic, and verdicts. No
producer, test, imported prover, or external evaluator is trusted. The shared
Python/JSON runtime is the same background assumption as the baselines. Comments
and genuine docstrings are removed, then the whole module is normalized with
CPython 3.12.14 `ast.unparse`. The unchanged comparator normalizer is retained.

The new checker combines explicit endpoint certificates, elimination-only
assumptions, and common administrative continuations. These implementation
components are inherited and are not presented as new arithmetic theorems.
The scalar numerical language has one bound update state, represented twice
only to match the shared raw binding discipline. It has no counter input.

The `list(*n)` call imposes a real direct-computation restriction: the successor
predecessor must be an array. Removing the old counter-opening call without
any replacement singleton check would be unsound. Every unavailable direct
successor instance is derived using a boxed counter followed by atomic equality
transport. The untrusted scalar producer explicitly emits those proofs.

Ordinary zero is raw scalar 0. Only the auxiliary boxing axiom uses a raw empty
array as its predecessor. A first producer draft used empty arrays universally,
which was identified as incompatible with the kernel's DI base opening. This
was corrected before delivery and two dependent-base regressions were added.
The correction changes certificate generation, not the measured kernel.

The focused checker has no general Hyp leaf. Impure Q goals cannot terminate:
every successful rule with such a goal must continue to another impure minor,
while arithmetic leaves are pure equations. Thus accepted object conclusions
have the advertised Eq/D syntax, and Q appears only as an internal clause.
Failed endpoint matches have their own finite-descent rejection invariant.
All context, scope, eigenvariable, and administration invariants are explained
in the report rather than inferred from testing alone.

## Executable evidence

* Scalar: 12 positive and 22 negative certificates, each run normally and with
  Python `-O`; 68/68 complete public-interface runs passed.
* Counter controls: 10 positive and 19 negative certificates for each of two
  profiles, normally and with `-O`; 116/116 runs passed.
* Displayed scalar arithmetic terms: 236 finite standard-natural-number checks,
  including the factor/comparator chain and predecessor values 0 through 5;
  no discrepancy.

The scalar positives include actual induction-hypothesis use, D-valued identity,
DE, QE, equality transport, and dependent case-base/zero-source formulas. The
negative set includes fake successor shapes, source/target mismatch, false
majors, future eigenparameters, malformed syntax, wrong induction mode, and
unboxed direct arithmetic steps. The checks are finite executable evidence;
they do not establish general mathematical soundness or bi-interpretability.
No Lean/Rocq formal verification is claimed.

## Later balanced profile

The earlier non-dominance statement and 685-byte row above concern the compact
byte profile specifically. A separately reviewed complete program,
`code/kernel_balanced.py`, subsequently attained **286 tokens / 320 AST nodes /
736 normalized bytes**, strictly below all three old coordinate minima at once.
It restores general Hyp and has an explicitly qualified concrete-runtime
handling of noncanonical iterable JSON. Its exact scoped review and 104 public
runs are in `implementation_balanced_review.md` and
`implementation_balanced_validation.json`; the report treats the two profiles
separately. The 685-byte program remains unchanged.
