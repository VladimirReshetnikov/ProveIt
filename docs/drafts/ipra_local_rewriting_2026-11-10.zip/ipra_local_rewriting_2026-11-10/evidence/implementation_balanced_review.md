# Scoped independent review of the balanced profile

Program: `code/kernel_balanced.py`.

SHA-256:
`131271838d7dcc2f317a3815e15d4bf21e66d81d2d8940e0c0bef4ee13a2f06e`.

Whole-program CPython 3.12.14 measurements: **286 normalized tokens,
320 AST nodes, 736 normalized bytes**. Each is strictly below the respective
old coordinate minimum 287/323/738. All three numbers describe this one
standalone program. The separate 685-byte program remains the byte leader.

## Review conclusion

Independent reviews by the primary agent, the theory agent, and the checker
agent found no finite-trace soundness defect in this profile. This is a scoped
mathematical code review, not a proof-assistant certification. Its conclusion
is that a successful finite checking trace extracts a derivation in the full
native Choice-DI calculus with the stated scalar arithmetic and ordinary
conditional-universal reading of Q.

The principal checks were:

* Every successfully appended context entry is a list. DE uses a list slice;
  Eq/Q continuation adds `[]`; DI must pass the matrix-length test, excluding
  scalar matrices before insertion. Restored Hyp therefore cannot close the
  scalar-zero/False state produced by a failed endpoint comparison.
* A failed computation falls through with local `h` unassigned in that fresh
  function frame. Argument evaluation raises before another continuation call.
  A value of `h` in another recursive frame is irrelevant.
* Root opening, image opening, and floor allocation retain the original scope
  and freshness discipline. A successful major must be proved or available
  through Hyp. No ignored Boolean failure can become success.
* `list(*n)` enforces the direct-step restriction. The compiler names any
  unavailable predecessor through the explicit auxiliary box and atomic
  transport. There is no hidden update counter in the scalar body.
* Empty string and empty object are finite aliases for zero/truth. A sole
  empty-string-key object aliases S0/Q-truth, with its value ignored.
  Dictionary predecessors copied by `list(*n)` preserve the same decoded term.
  Successful logical majors still have the structure needed by their slices.
* Retained finite scalars, including Booleans, have the slot meaning of their
  floor. Nonfinite/out-of-range scalars are exposed holes only with a checked
  image; they cannot survive an omitted-image numerical-root validation.
* General Hyp allows Q conclusions, so the focused profile's object-purity
  statement is not reused. Q has its ordinary conditional-universal meaning
  and is equivalent, under arbitrary retained contexts, to D with a fresh
  unused witness. The established focusing/identity translations then connect
  this program to the report's Eq/D object presentation.

## Essential termination qualification

The opener iterates directly in a `try` block. A nonempty string reproduces a
one-character string recursively; an object with a nonempty key has the same
problem. Such input has no successful finite opening. On the concrete CPython
runtime, its recursion limit and the subsequent scalar type failure reject it.
With an ideal unbounded stack, that opening can instead diverge.

Accordingly, this profile is **not** claimed to be a total recognizer for
arbitrary JSON on an ideal unbounded machine. Canonical finite array/integer
syntax retains structural termination and canonical proof completeness.
The all-coordinate result measures the full concrete CPython program under
its disclosed runtime boundary. This qualification is also in the report and
`code/FORMAT.md`; it must accompany the size result. The 685-byte type-guarded
profile does not use this iterable-alias mechanism.

## Targeted executable evidence

All 104 complete public-interface runs passed: twelve positive derivations,
twenty-two negative certificates, and eighteen alias/hole cases, each normally
and under Python `-O`. The unboxed symbolic-step rejection was serialized with
the Hyp-aware producer and included; no earlier expected rejection was changed
to acceptance. Tests include both matching failures, false computation, malformed
successor shapes, scope/freshness failures, dependent base/source formulas,
empty iterable aliases, malformed nonempty strings/keys, null, finite numeric
aliases, nonfinite numerical roots, and checked nonfinite template holes.

The individual verdicts and exact source metrics are retained in
`implementation_balanced_validation.json`. These finite tests supplement the
invariant arguments and do not establish global minimality or a formal
bi-interpretability proof by themselves.
