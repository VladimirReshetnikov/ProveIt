# Independent mathematical review of the scalar bootstrap

The two sections reviewed were `successor_seed_transposition.tex` and
`successor_seed_factor_predecessor.tex`. This was a mathematical review,
not a formal proof-assistant verification.

The transposition construction checks directly. The pulse b starts 1,2,0
and remains zero thereafter by one equation induction. Its exact-one
control K therefore has values 0,1,0 on 0,1,S²n. The update h has equations
h(0)=2, h(1)=0, h(S²n)=S³n, so the R orbit sigma starts 1,0,2 and agrees
with identity thereafter by equation induction. Two successive numerical
case rules prove sigma(sigma(n))=n. Conjugation by this involution yields
zero-seeded J with no predecessor, cancellation, or arbitrary selector.

The continuation was checked equation by equation. In particular:

* N should explicitly be identified with Z(p), not with p: their zero
  values differ. Equation induction proves N(n)=Z(p(n)), making the
  Boolean finite-image lemma available without presupposing parity period.
* The three-state update j has exactly the finite image {0,1,2}; the
  finite-image lemma is derived by cases on an independent control.
  The map pi retracts successor only on these finite controls. Its use
  in the ramp proof never licenses general successor cancellation.
* LiftedControlPush, then pi, proves M(g(u))=Z(M(u)) unconditionally.
  Applying this established equation to G(n) avoids splitting u under a
  retained, correlated induction hypothesis.
* The lifted-triple induction has correct shifts: its two Boolean
  branches give S^5(v) and S^7(v). The induction statement retains the
  leading successor deliberately; no cancellation is used.
* The two expressions in the H∘T calculation have seeds S^4(X) and
  S^5(Y). Applying the same term context to the lifted equality SX=...
  gives the required result. The final Boolean table produces W or
  S^6(Y), as claimed.
* The comparator's induction is on y with x fixed. The saturation
  shift W(St,Sm)=S W(t,m) is proved with m fixed. The later diagonal
  W(n,n)=n uses the already established, universally parameterized shift,
  so it does not change an active passive parameter.
* The final comparison defining P uses induction on t with m fixed,
  and only afterward substitutes t=Sm. This proves P(Sm)=m without
  assuming the predecessor or a hidden counter input.

The dependency order is coherent: equation induction and equation cases;
finite transposition; zero-seeded iteration; finite controls and affine
terms; lifted factor identity; comparator; adjacent selector; predecessor;
full selector and initialized scalar iteration. The last PR/equality and
logical bridges must still be provided in the final report; this review
was specifically of the new arithmetic bootstrap.

The accompanying `code/check_scalar_arithmetic.py` evaluates the displayed
terms directly using successor-seeded scalar R and conjugated J. It found
no discrepancy in 236 finite checks, including predecessor values 0..5.
Those finite checks are supplemental examples, not a proof about arbitrary
or nonstandard numerical domains.
