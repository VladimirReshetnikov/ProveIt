# Native certificate interface

`kernel_scalar_boxed.py` is the complete measured scalar checker. It reads
one JSON array from standard input. The last element is the closed goal;
earlier elements are four-field instructions, consumed from the end.
Unused prefixes are inert. A successful finite trace prints `ACCEPT` and
exits zero. Failure prints `REJECT` and exits nonzero, with a possible
stderr traceback. Standard JSON is the only imported library. The producer
and test modules are outside the trusted checker.

## Sorted expressions

Canonical data are finite arrays and integer coordinates. At formula root,
array lengths 1,2,3 represent the internal Q closure, equality, and D.
The D body is its third field; the first two are checked inert padding.
At numerical root, lengths 0,1,2,3 represent zero, successor, inert zero
annotation, and the recursor R. A numerical triple is `[counter, seed, body]`.
It has two dummy zero slots in the counter and seed, and two aliases of
one state variable in the body. The scalar body has no counter input.
The counter control kernel instead has distinct state and counter slots.

The opener's depth increments for lengths 0,1,2,3 are 0,2,1,4 (the first
is irrelevant because an empty array has no children). At formula depth
2q and numerical depth 2q+1, positive coordinates 2j−1,2j name the jth
protected slot, nearest first. Integer zero denotes numerical zero.
Negative integers name already allocated rigid eigenparameters. The global
floor starts at zero and decreases at each common continuation. The opener
checks retained coordinates against the current floor and depth; exposed
numerical coordinates request a supplied image, checked at numerical root.
All labels in a requested root goal therefore precede any local allocation.

The complete decoder and mathematical meanings are stated in the report.
Raw numerical aliases accepted by Python/JSON do not add axioms; canonical
proof production uses the formats just described. More precisely, for any
retained finite scalar a, including a Boolean, floor(a) identifies the same
protected slot or rigid parameter: the interval boundaries k and d are integers.
Finite scalars outside that interval, and Python JSON's NaN/Infinity extensions,
act as the single exposed template hole only when a supplied image is checked
at numerical root. They cannot survive a numerical-root validation with its
image omitted. At formula positions scalar leaves denote truth, including
scalars in inert numerical annotations. Equal Python numeric aliases therefore
have identical decoded meanings; distinct aliases can make matching stricter,
not justify a false equation. Strings, mappings, and null used as numerical
syntax reject in the 685-byte type-guarded program. Unused packet metadata and
unused certificate prefixes have no mathematical meaning.

## Instructions

An instruction is `[m,s,u,t]`.

* For a proved equality major, `m=[s,u]`, `t` is a formula template.
  The requested goal must be its opening at u; the next minor is its
  opening at s.
* For a Q major, `m=[t]` and s is a zero image. The requested goal must
  be t opened at u; the minor is t opened at zero.
* For D elimination, m is a ternary formula; the remaining fields are
  irrelevant padding. Its major is proved, a fresh witness is allocated,
  and its Q closure is added to the continuation context.
* For introduction, m is false and t is a nonempty witness image. Canonical
  case introduction uses m=[]; atomic progress introduction uses m=0.
  The program permits progress only when the opened matrix is literally
  an equation. The witness is opened before allocating the fresh step
  parameter; the local base or current-equation hypothesis is then added.
* For computation, m and t are false. The goal is an equality whose left
  side is a numerical recursor. It is checked by the two computation clauses.

In the focused program, context formulas can be used as elimination majors.
There is no general Hyp leaf. The identity expansion for Eq/D object formulas
is supplied in the report and producer. Q is an internal reusable closure
clause. General object-language Q is represented by a vacuous D when needed.

Every non-computation instruction shares a continuation. In Eq/Q elimination
this adds a provable truth alias and an unused fresh numerical parameter.
The producer records those allocations even though they have no mathematical
role. No certificates are Python source or executable code.

## The scalar step restriction and its compiler

The scalar arithmetic expression uses `list(*n)` to enforce a singleton
successor counter whose predecessor is itself represented by an array.
This is an explicit, proved certificate restriction. Direct computation
at a scalar numerical predecessor, including canonical scalar 0, rejects.
It does not remove the general successor equation from the theory.

For any required predecessor w, use the auxiliary term

    B_w = R(S[], 0; state.w).

Here `[]` denotes numerical zero. The successor computation for B_w is
legal because its predecessor is literally an array, and proves B_w=w.
Direct successor computation at the array B_w, followed by equality
transport in the atomic equation motive, proves the general equation at w.
The compiler therefore introduces only a constant number of arithmetic
and transport nodes for an unavailable direct step.

Ordinary zeros in the scalar producer remain scalar 0, matching DI's base
opening and QE's zero source. Only the auxiliary box uses the raw empty-array
zero. This distinction matters for strict syntactic matching. Regression
fixtures exercise y-dependent base assumptions and zero specializations.

`produce_scalar.py` creates these proofs without being imported by the kernel.
`validate_scalar.py` checks 12 positive and 22 negative certificates through
the full CLI, both normally and with Python `-O` (68 runs). The two counter
controls have 116 separate public-interface checks. These finite checks do
not replace the metatheoretic proofs.

## Separate balanced profile

`kernel_balanced.py` is a separate complete program, measuring 286 normalized
tokens, 320 AST nodes, and 736 normalized bytes. It restores general Hyp and
uses the same scalar boxed-step theory, endpoints, and common continuation.
Its Hyp-aware certificates are produced by `ScalarEmitter(focused=False)`.
General Q conclusions use the conditional-universal interpretation and are
equivalent to a D with an unused witness; the focused purity invariant is not
claimed for this profile.

Its opener tries to iterate directly, without the `a+[]` type guard. Empty
string and empty object normalize to the empty list (zero/truth), and an object
with a sole empty-string key normalizes to `[[]]` (S0/Q-truth). That object's
value is ignored. All successfully added context entries remain lists, so Hyp
cannot close a failed-match scalar0. A failed computation falls through with
its local h unassigned, which necessarily raises before another call.

Nonempty strings and objects with nonempty keys have no successful finite
opening. On the concrete CPython runtime they reject through recursion-limit
and type failure. With an ideal unbounded stack, the opener can instead loop
on a one-character string. Thus this profile is not claimed to be a total
recognizer for arbitrary JSON on an ideal unbounded machine. Structural
termination and proof completeness concern canonical finite array/integer
syntax. The 736-byte all-coordinate result is explicitly a measurement of
the full concrete CPython program; the 685-byte profile keeps its type guard.

`validate_balanced.py` runs 104 public-interface checks, normal and `-O`:
12 positive proofs, 22 negative certificates, and 18 alias/hole cases.
`fixtures/balanced.json` is standard outer JSON; cases using Python's nonfinite
extensions store their entire input as a `packet_json` string.
