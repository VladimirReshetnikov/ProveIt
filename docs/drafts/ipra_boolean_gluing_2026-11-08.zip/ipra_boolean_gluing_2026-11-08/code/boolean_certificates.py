#!/usr/bin/env python3
"""Symbolic equation certificates for Boolean centrality and gluing.

This is a small checker for a restricted family of equational proofs, NOT a
complete iPRA proof checker and NOT a competitor in the source-size comparison.
It checks first-order rewrite traces and endpoint equation-induction trees.
The induction step is unconditional: no induction hypothesis is assumed.

Trusted arithmetic: I(0,a;u.h)=a and
I(Sn,a;u.h)=h[I(n,a;u.h)/u], instantiated at the three FIXED updates c, S(u),
and Z(u). K, U, and W below are staged first-order symbols for those iterators.
All other symbols with rules are explicit finite definitions. Function symbols
f0,...,f4 stay opaque. No truth tables, numerical sampling, Boolean-range axiom,
numerical coverage, falsity bridge, or predecessor lemma is used.

The producer chooses rewrite paths. The separate replay checker validates each
path against the fixed rule table; it does not trust the normalizer's result.
The only logical proof rule beyond equational rewriting is the restricted
equation-induction rule checked by verify().

For a displayed identity E(b1,...,bk), this artifact proves
E(B(n1),...,B(nk)). The usual substitution of ni:=bi followed by equality
replacement under B(bi)=bi gives the version on Boolean fixed points. That
last general metatheorem, the quotient interpretations, and the gluing theorem
are written proofs in the article; they are not claimed fully formalized here.

Run without arguments to create and replay certificates plus a JSON receipt.
Run --replay FILE to check an existing certificate bundle against the exact
identity list in this script. The script uses only Python's standard library.
"""

import argparse
from collections import Counter
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import platform
import re


class ProofError(ValueError):
    pass


def V(name):
    return ("var", name)


def M(name):
    return ("meta", name)


def A(symbol, *arguments):
    return (symbol, *arguments)


ZERO = A("0")
ONE = A("S", ZERO)
TWO = A("S", ONE)
ARITIES = {
    "0": 0, "S": 1,
    "K": 3, "U": 2, "W": 2,
    "C": 3, "Z": 1, "B": 1,
    "q": 3, "p": 2, "r": 2,
    "Add": 2, "N": 1, "j": 1,
    "Not": 1, "Meet": 2, "Join": 2, "Xor": 2,
    **{"f" + str(k): k for k in range(5)},
}


@dataclass(frozen=True)
class Rewrite:
    name: str
    left: tuple
    right: tuple
    justification: str


n, a, c, b, x, y = (M(s) for s in ("n", "a", "c", "b", "x", "y"))
RULES = (
    Rewrite("K0", A("K", ZERO, a, c), a, "I0 for update h(u,c)=c"),
    Rewrite("KS", A("K", A("S", n), a, c), c,
            "IS for the state-independent update h(u,c)=c"),
    Rewrite("U0", A("U", ZERO, a), a, "I0 for update h(u)=S(u)"),
    Rewrite("US", A("U", A("S", n), a), A("S", A("U", n, a)),
            "IS for update h(u)=S(u)"),
    Rewrite("W0", A("W", ZERO, a), a, "I0 for update h(u)=Z(u)"),
    Rewrite("WS", A("W", A("S", n), a), A("Z", A("W", n, a)),
            "IS for update h(u)=Z(u)"),
    Rewrite("def_C", A("C", n, x, y), A("K", n, x, y),
            "C(n,x,y)=I(n,x;u.y)"),
    Rewrite("def_Z", A("Z", n), A("C", n, ONE, ZERO), "Z(n)=C(n,1,0)"),
    Rewrite("def_B", A("B", n), A("Z", A("Z", n)), "B(n)=Z(Z(n))"),
    Rewrite("def_q", A("q", b, x, y), A("C", b, x, y), "q_b(x,y)=C(b,x,y)"),
    Rewrite("def_p", A("p", b, x), A("q", b, x, ZERO), "p_b(x)=q_b(x,0)"),
    Rewrite("def_r", A("r", b, x), A("q", b, ZERO, x), "r_b(x)=q_b(0,x)"),
    Rewrite("def_Add", A("Add", x, y), A("U", y, x),
            "x+y=I(y,x;u.S(u))"),
    Rewrite("def_N", A("N", n), A("W", n, ZERO), "N(n)=I(n,0;u.Z(u))"),
    Rewrite("def_j", A("j", n),
            A("Add", A("Z", n), A("Add", A("N", n), A("N", n))),
            "j(n)=Z(n)+(N(n)+N(n))"),
    Rewrite("def_Not", A("Not", b), A("Z", b), "not b=Z(b)"),
    Rewrite("def_Meet", A("Meet", b, c), A("q", b, ZERO, c),
            "b meet c=q_b(0,c)"),
    Rewrite("def_Join", A("Join", b, c), A("q", b, c, ONE),
            "b join c=q_b(c,1)"),
    Rewrite("def_Xor", A("Xor", b, c), A("q", b, c, A("Not", c)),
            "b xor c=q_b(c,not c)"),
)
RULE_BY_NAME = {rule.name: rule for rule in RULES}


def validate(term):
    if type(term) is not tuple or not term or type(term[0]) is not str:
        raise ProofError("Malformed term")
    if term[0] == "var":
        if len(term) != 2 or type(term[1]) is not str or not re.fullmatch(
                r"[A-Za-z][A-Za-z0-9_]*", term[1]):
            raise ProofError("Malformed variable")
        return
    if term[0] not in ARITIES or len(term) != ARITIES[term[0]] + 1:
        raise ProofError("Unknown function or wrong arity: " + str(term[0]))
    for child in term[1:]:
        validate(child)


def decode(raw):
    if type(raw) is not list or not raw or type(raw[0]) is not str:
        raise ProofError("Malformed serialized term")
    if raw[0] == "var":
        term = tuple(raw)
    else:
        term = (raw[0], *(decode(child) for child in raw[1:]))
    validate(term)
    return term


def variables(term):
    if term[0] == "var":
        return {term[1]}
    return set().union(*(variables(child) for child in term[1:]))


def substitute(term, mapping):
    if term[0] == "var":
        return mapping.get(term[1], term)
    return (term[0], *(substitute(child, mapping) for child in term[1:]))


def match(pattern, term, environment):
    if pattern[0] == "meta":
        name = pattern[1]
        if name in environment:
            return environment[name] == term
        environment[name] = term
        return True
    if pattern[0] != term[0] or len(pattern) != len(term):
        return False
    return all(match(p, t, environment) for p, t in zip(pattern[1:], term[1:]))


def instantiate(pattern, environment):
    if pattern[0] == "meta":
        return environment[pattern[1]]
    return (pattern[0], *(instantiate(child, environment) for child in pattern[1:]))


def root_rewrite(term, rule):
    environment = {}
    if not match(rule.left, term, environment):
        raise ProofError("Rewrite rule does not match its claimed occurrence")
    result = instantiate(rule.right, environment)
    validate(result)
    return result


def at_path(term, path):
    for index in path:
        if (type(index) is not int or term[0] == "var"
                or index < 0 or index >= len(term) - 1):
            raise ProofError("Invalid rewrite path")
        term = term[index + 1]
    return term


def replace_path(term, path, replacement):
    if not path:
        return replacement
    index, *tail = path
    at_path(term, [index])
    children = list(term[1:])
    children[index] = replace_path(children[index], tail, replacement)
    return (term[0], *children)


def apply_step(term, step):
    if type(step) is not dict or set(step) != {"path", "rule"}:
        raise ProofError("Malformed rewrite step")
    if type(step["path"]) is not list or step["rule"] not in RULE_BY_NAME:
        raise ProofError("Unknown rewrite instruction")
    local = at_path(term, step["path"])
    replacement = root_rewrite(local, RULE_BY_NAME[step["rule"]])
    return replace_path(term, step["path"], replacement)


def replay(term, steps, counts):
    if type(steps) is not list:
        raise ProofError("A rewrite trace must be a finite list")
    for step in steps:
        term = apply_step(term, step)
        counts["rewrites"] += 1
        counts["rewrite_" + step["rule"]] += 1
    return term


def verify(proof, goal, counts=None):
    """Replay one proof of a universal equation with freely fixed parameters.

    No numerical evaluation or producer normalization routine is called here.
    Equational rewriting is justified by congruence, symmetry and transitivity.
    Endpoint induction checks both exact substitutions and eigenvariable scope.
    """
    if counts is None:
        counts = Counter()
    left, right = goal
    validate(left)
    validate(right)
    if type(proof) is not dict:
        raise ProofError("A proof node must be an object")
    if proof.get("rule") == "normalize":
        if set(proof) != {"rule", "left_steps", "right_steps", "normal_form"}:
            raise ProofError("Malformed equational proof leaf")
        normal = decode(proof["normal_form"])
        lresult = replay(left, proof["left_steps"], counts)
        rresult = replay(right, proof["right_steps"], counts)
        if lresult != normal or rresult != normal:
            raise ProofError("The two rewrite traces do not reach one common term")
        counts["equational_leaves"] += 1
        return counts
    if proof.get("rule") == "endpoint_induction":
        if set(proof) != {"rule", "variable", "eigenvariable", "base", "step"}:
            raise ProofError("Malformed induction node")
        variable, eigen = proof["variable"], proof["eigenvariable"]
        validate(V(variable))
        validate(V(eigen))
        if eigen == variable or eigen in variables(left) | variables(right):
            raise ProofError("Induction eigenvariable is not fresh")
        base = tuple(substitute(t, {variable: ZERO}) for t in goal)
        step = tuple(substitute(t, {variable: A("S", V(eigen))}) for t in goal)
        verify(proof["base"], base, counts)
        # No induction-hypothesis context is provided to the step checker.
        verify(proof["step"], step, counts)
        counts["endpoint_inductions"] += 1
        return counts
    raise ProofError("Unknown proof rule")


# Everything below is untrusted production, display, or fixture selection.

def first_redex(term, prefix=()):
    for rule in RULES:
        if match(rule.left, term, {}):
            return {"path": list(prefix), "rule": rule.name}
    if term[0] != "var":
        for index, child in enumerate(term[1:]):
            found = first_redex(child, (*prefix, index))
            if found is not None:
                return found
    return None


def normalize(term):
    steps = []
    for _ in range(100000):
        step = first_redex(term)
        if step is None:
            return term, steps
        term = apply_step(term, step)
        steps.append(step)
    raise ProofError("Producer rewrite budget exhausted")


def serialized(term):
    if term[0] == "var":
        return list(term)
    return [term[0], *(serialized(child) for child in term[1:])]


def pretty(term):
    if term[0] == "var":
        return term[1]
    if term == ZERO:
        return "0"
    if term == ONE:
        return "1"
    if term == TWO:
        return "2"
    return term[0] + ("(" + ", ".join(pretty(t) for t in term[1:]) + ")"
                      if term[1:] else "")


def produce(goal, induction_variables):
    if not induction_variables:
        left, lsteps = normalize(goal[0])
        right, rsteps = normalize(goal[1])
        if left != right:
            raise ProofError("Endpoint equation fails: " + pretty(left)
                             + " != " + pretty(right))
        return {"rule": "normalize", "left_steps": lsteps,
                "right_steps": rsteps, "normal_form": serialized(left)}
    variable, *remaining = induction_variables
    eigen = "fresh_" + variable
    while eigen in variables(goal[0]) | variables(goal[1]):
        eigen += "_fresh"
    base = tuple(substitute(t, {variable: ZERO}) for t in goal)
    step = tuple(substitute(t, {variable: A("S", V(eigen))}) for t in goal)
    return {
        "rule": "endpoint_induction", "variable": variable,
        "eigenvariable": eigen,
        "base": produce(base, remaining), "step": produce(step, remaining),
    }


@dataclass(frozen=True)
class Identity:
    name: str
    category: str
    left: tuple
    right: tuple
    boolean_variables: tuple = ()
    ordinary_induction_variables: tuple = ()

    def instantiated(self):
        mapping = {name: A("B", V("index_" + name))
                   for name in self.boolean_variables}
        goal = (substitute(self.left, mapping), substitute(self.right, mapping))
        return goal, tuple("index_" + name for name in self.boolean_variables) + self.ordinary_induction_variables


def identities():
    b, c, d, x, y, z, w, n, v = (V(s) for s in "b c d x y z w n v".split())
    q = lambda t, u, vv: A("q", t, u, vv)
    p = lambda t: A("p", b, t)
    r = lambda t: A("r", b, t)
    neg = lambda t: A("Not", t)
    meet = lambda t, u: A("Meet", t, u)
    join = lambda t, u: A("Join", t, u)
    rows = []

    def add(name, category, left, right, bools=(), numeric=()):
        rows.append(Identity(name, category, left, right, tuple(bools), tuple(numeric)))

    add("B_idempotent", "Boolean core", A("B", A("B", n)), A("B", n), numeric=("n",))
    add("Z_cubic", "Boolean core", A("Z", A("Z", A("Z", n))), A("Z", n), numeric=("n",))
    add("selector_diagonal", "central selectors", q(b, x, x), x, ("b",))
    add("selector_nest_left", "central selectors", q(b, q(b, x, y), z), q(b, x, z), ("b",))
    add("selector_nest_right", "central selectors", q(b, x, q(b, y, z)), q(b, x, z), ("b",))
    add("selector_nest_both", "central selectors", q(b, q(b, x, y), q(b, z, w)), q(b, x, w), ("b",))
    add("selector_interchange", "central selectors", q(b, q(c, x, y), q(c, z, w)),
        q(c, q(b, x, z), q(b, y, w)), ("b", "c"))
    add("selector_complement", "central selectors", q(neg(b), x, y), q(b, y, x), ("b",))
    add("project_p", "gluing projections", p(q(b, x, y)), p(x), ("b",))
    add("project_r", "gluing projections", r(q(b, x, y)), r(y), ("b",))
    add("recover", "gluing projections", q(b, p(x), r(x)), x, ("b",))
    add("recover_mixed", "gluing projections", q(b, p(x), r(y)), q(b, x, y), ("b",))
    add("p_idempotent", "gluing projections", p(p(x)), p(x), ("b",))
    add("r_idempotent", "gluing projections", r(r(x)), r(x), ("b",))
    add("p_r_zero", "gluing projections", p(r(x)), ZERO, ("b",))
    add("r_p_zero", "gluing projections", r(p(x)), ZERO, ("b",))
    add("p_boolean_collapse", "Boolean endpoint collapse", p(b), p(ZERO), ("b",))
    add("r_boolean_collapse", "Boolean endpoint collapse", r(b), r(ONE), ("b",))
    add("boolean_reconstruction", "Boolean endpoint collapse", q(b, ZERO, ONE), b, ("b",))

    for arity in range(5):
        xs = tuple(V("x" + str(i)) for i in range(arity))
        ys = tuple(V("y" + str(i)) for i in range(arity))
        f = lambda args, k=arity: A("f" + str(k), *args)
        add("homomorphism_arity_" + str(arity), "opaque-function homomorphism",
            f(tuple(q(b, xx, yy) for xx, yy in zip(xs, ys))),
            q(b, f(xs), f(ys)), ("b",))
        add("p_function_arity_" + str(arity), "projected function congruence",
            p(f(tuple(p(xx) for xx in xs))), p(f(xs)), ("b",))
        add("r_function_arity_" + str(arity), "projected function congruence",
            r(f(tuple(r(xx) for xx in xs))), r(f(xs)), ("b",))

    add("not_fixedpoint", "Boolean algebra", A("B", neg(b)), neg(b), ("b",))
    add("meet_fixedpoint", "Boolean algebra", A("B", meet(b, c)), meet(b, c), ("b", "c"))
    add("join_fixedpoint", "Boolean algebra", A("B", join(b, c)), join(b, c), ("b", "c"))
    add("xor_fixedpoint", "Boolean algebra", A("B", A("Xor", b, c)), A("Xor", b, c), ("b", "c"))
    add("double_complement", "Boolean algebra", neg(neg(b)), b, ("b",))
    for name, operation, identity, absorbing in (("meet", meet, ONE, ZERO),
                                               ("join", join, ZERO, ONE)):
        add(name + "_commutative", "Boolean algebra", operation(b, c), operation(c, b), ("b", "c"))
        add(name + "_associative", "Boolean algebra", operation(operation(b, c), d),
            operation(b, operation(c, d)), ("b", "c", "d"))
        add(name + "_idempotent", "Boolean algebra", operation(b, b), b, ("b",))
        add(name + "_identity", "Boolean algebra", operation(b, identity), b, ("b",))
        add(name + "_absorbing", "Boolean algebra", operation(b, absorbing), absorbing, ("b",))
        add(name + "_complement", "Boolean algebra", operation(b, neg(b)), absorbing, ("b",))
    add("meet_distributive", "Boolean algebra", meet(b, join(c, d)),
        join(meet(b, c), meet(b, d)), ("b", "c", "d"))
    add("join_distributive", "Boolean algebra", join(b, meet(c, d)),
        meet(join(b, c), join(b, d)), ("b", "c", "d"))
    add("meet_absorption", "Boolean algebra", meet(b, join(b, c)), b, ("b", "c"))
    add("join_absorption", "Boolean algebra", join(b, meet(b, c)), b, ("b", "c"))
    add("demorgan_meet", "Boolean algebra", neg(meet(b, c)), join(neg(b), neg(c)), ("b", "c"))
    add("demorgan_join", "Boolean algebra", neg(join(b, c)), meet(neg(b), neg(c)), ("b", "c"))

    add("selector_shift_silent_branch", "direct scalar bootstrap",
        A("C", b, A("Add", x, b), y), A("C", b, x, y), ("b",))
    add("successor_selector", "direct scalar bootstrap",
        A("Add", A("Add", v, b), ONE),
        A("C", b, A("Add", v, ONE), A("Add", v, TWO)), ("b",))
    add("j_zero", "direct scalar bootstrap", A("j", ZERO), ONE)
    add("j_one", "direct scalar bootstrap", A("j", ONE), TWO)
    add("j_two", "direct scalar bootstrap", A("j", TWO), ZERO)
    add("j_selector_cycle", "direct scalar bootstrap",
        A("C", b, A("j", b), A("j", A("j", b))), A("Z", b), ("b",))
    add("selector_successor", "direct scalar bootstrap",
        A("C", n, A("S", x), A("S", y)), A("S", A("C", n, x, y)), numeric=("n",))
    add("selector_diagonal_unrestricted", "direct scalar bootstrap",
        A("C", n, x, x), x, numeric=("n",))
    return rows


def negative_checks():
    cases = []
    b, x, y = V("b"), V("x"), V("y")
    false_law = Identity("false_selector_commutativity", "negative",
                         A("q", b, x, y), A("q", b, y, x), ("b",))
    goal, inds = false_law.instantiated()
    try:
        produce(goal, inds)
    except ProofError as error:
        cases.append({"name": false_law.name, "rejected": True, "reason": str(error)})
    else:
        raise ProofError("The false symbolic selector law was not rejected")

    forged = {"rule": "normalize", "left_steps": [], "right_steps": [],
              "normal_form": serialized(x)}
    try:
        verify(forged, (x, y))
    except ProofError as error:
        cases.append({"name": "forged_x_equals_y", "rejected": True, "reason": str(error)})
    else:
        raise ProofError("An invalid equality certificate was accepted")

    valid_goal = (A("C", ZERO, x, y), x)
    changed = produce(valid_goal, ())
    changed["left_steps"][0]["rule"] = "KS"
    try:
        verify(changed, valid_goal)
    except ProofError as error:
        cases.append({"name": "mutated_rewrite_rule", "rejected": True, "reason": str(error)})
    else:
        raise ProofError("A false rewrite instance was accepted")

    valid_goal = (A("B", A("B", V("n"))), A("B", V("n")))
    changed = produce(valid_goal, ("n",))
    changed["eigenvariable"] = "n"
    try:
        verify(changed, valid_goal)
    except ProofError as error:
        cases.append({"name": "nonfresh_induction_eigenvariable", "rejected": True, "reason": str(error)})
    else:
        raise ProofError("An invalid induction scope was accepted")
    return cases


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replay", type=Path, help="Replay a saved certificate bundle")
    parser.add_argument("--certificates", type=Path,
                        default=Path(__file__).resolve().parents[1] / "results" / "boolean_certificates.json")
    parser.add_argument("--results", type=Path,
                        default=Path(__file__).resolve().parents[1] / "results" / "boolean_certificate_results.json")
    args = parser.parse_args()
    selected = identities()
    if args.replay:
        bundle = json.loads(args.replay.read_text())
        if bundle.get("format") != "boolean-endpoint-equations-v1":
            raise ProofError("Unknown certificate format")
        entries = bundle["certificates"]
        if len(entries) != len(selected):
            raise ProofError("Certificate inventory does not match the declared claims")
    else:
        entries = []
        for identity in selected:
            goal, induction_variables = identity.instantiated()
            entries.append({"name": identity.name,
                            "goal": [serialized(t) for t in goal],
                            "proof": produce(goal, induction_variables)})
        bundle = {"format": "boolean-endpoint-equations-v1", "certificates": entries}
        args.certificates.write_text(json.dumps(bundle, indent=2) + "\n")
        # Replay serialized bytes, rather than reusing the producer's objects.
        bundle = json.loads(args.certificates.read_text())
        entries = bundle["certificates"]

    total = Counter()
    receipts = []
    for identity, entry in zip(selected, entries):
        goal, induction_variables = identity.instantiated()
        if entry["name"] != identity.name or tuple(decode(t) for t in entry["goal"]) != goal:
            raise ProofError("Changed statement or wrong certificate order")
        counts = verify(entry["proof"], goal)
        total.update(counts)
        receipts.append({
            "name": identity.name, "category": identity.category, "verified": True,
            "display_identity": pretty(identity.left) + " = " + pretty(identity.right),
            "boolean_fixedpoint_parameters": list(identity.boolean_variables),
            "checked_universal_equation": pretty(goal[0]) + " = " + pretty(goal[1]),
            "induction_variables": list(induction_variables),
            "counts": dict(sorted(counts.items())),
        })
    negative = negative_checks()
    source = args.replay or args.certificates
    result = {
        "status": "PASS", "python": platform.python_version(),
        "certificate_format": "boolean-endpoint-equations-v1",
        "certificate_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "identity_count": len(receipts), "counts": dict(sorted(total.items())),
        "categories": dict(Counter(row["category"] for row in receipts)),
        "trusted_principles": [
            "First-order equality congruence, symmetry, and transitivity",
            "I0 and IS at the fixed updates c, S(u), and Z(u)",
            "The explicitly listed finite defining abbreviations",
            "Equation induction, with a fresh eigenvariable and unused induction hypothesis",
        ],
        "rewrite_rules": [{"name": rule.name, "justification": rule.justification}
                          for rule in RULES],
        "not_assumed": ["Boolean range", "numerical coverage", "falsity bridge",
                        "predecessor equations", "semiring axioms", "numeric sampling"],
        "scope": (
            "Restricted symbolic equational proof certificates. The arbitrary-symbol "
            "homomorphism scheme is instantiated at arities 0 through 4; those symbols "
            "remain opaque. E(B(n1),...,B(nk)) is checked by nested equation induction. "
            "Passage to Boolean fixed-point assumptions, projection interpretations, "
            "the general gluing theorem, the complete scalar predecessor proof, "
            "and iPRA bi-interpretability remain mathematical arguments in the report. "
            "This is neither a full iPRA checker nor a candidate for the size frontier."
        ),
        "identities": receipts, "negative_tests": negative,
    }
    args.results.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in (
        "status", "identity_count", "categories", "counts", "negative_tests")}, indent=2))


if __name__ == "__main__":
    main()
