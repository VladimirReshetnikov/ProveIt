SYMBOLIC BOOLEAN EQUATION CERTIFICATES
====================================

Files
-----
boolean_certificates.py             Producer and separate replay checker
boolean_certificates.json           Explicit rewrite/induction proof trees
boolean_certificate_results.json    Machine-readable verification receipt

Reproduce
---------
From the archive root:
  python3 code/boolean_certificates.py

Replay the supplied proof trees, without regenerating them:
  python3 code/boolean_certificates.py --replay results/boolean_certificates.json

The saved bundle was also reopened and replayed under Python -O; the receipt
was identical. No assertions carry proof-checking obligations.

Exactly what is checked
-----------------------
65 symbolic universal equations are checked, using 106 endpoint equation-
induction nodes, 171 equational leaves, and 5,255 individual rewrite steps.
Free variables remain symbolic throughout. The function symbols f0 through
f4 remain opaque. This is not finite numerical sampling.

For an equation E(b1,...,bk) asserted on Boolean fixed points, the actual
certificate proves E(B(n1),...,B(nk)) by nested equation induction. The base
substitutes ni:=0. The successor step substitutes ni:=S(ai), checks that ai
is fresh, and does not receive an induction hypothesis. It is therefore a
special case of literal-equation induction in the bridge-free theory.

The checker also proves B(B(n))=B(n) and Z(Z(Z(n)))=Z(n), as unrestricted
universal equations. Passing from E(B(ni)) to E(bi) under B(bi)=bi is the
ordinary equality/substitution argument in the article; this general
metatheorem is not a hidden checker axiom.

Included identities
-------------------
- Central-selector diagonal, nesting, interchange, and complement equations.
- The p/r projection equations, idempotence, mixed zeros, and recovery.
- The endpoint collapses p_b(b)=p_b(0) and r_b(b)=r_b(1).
- The homomorphism identity for an arbitrary opaque symbol at arities 0..4.
- Corresponding p/r function identities used for quotient congruence.
- Boolean closure, complement, meet/join laws, distributivity, absorption,
  and De Morgan laws.
- C(b,x+b,y)=C(b,x,y).
- (v+b)+1=C(b,v+1,v+2).
- j(0)=1, j(1)=2, j(2)=0, and
  C(b,j(b),j(j(b)))=Z(b).
- C(n,Sx,Sy)=S(C(n,x,y)) and C(n,x,x)=x for arbitrary n.

Trusted definitions and proof rules
----------------------------------
K(n,a,c) abbreviates I(n,a;u.c).
U(n,a)   abbreviates I(n,a;u.S(u)).
W(n,a)   abbreviates I(n,a;u.Z(u)).

Their six rewrite equations are exactly I0/IS instances. The remaining rules
expand explicit definitions:
  C(n,x,y)=K(n,x,y)
  Z(n)=C(n,1,0)
  B(n)=Z(Z(n))
  q_b(x,y)=C(b,x,y)
  p_b(x)=q_b(x,0), r_b(x)=q_b(0,x)
  x+y=U(y,x)
  N(n)=W(n,0)
  j(n)=Z(n)+(N(n)+N(n))
  not b=Z(b)
  b meet c=q_b(0,c), b join c=q_b(c,1)
  b xor c=q_b(c,not c)

The replay checker accepts only these rule names at matching term occurrences.
Each equational leaf gives one rewrite trace from each side to the same term;
equality congruence, symmetry and transitivity justify that leaf. The sole
remaining proof constructor is the explicitly checked endpoint induction.

No Boolean-range axiom, numerical coverage, falsity bridge, predecessor lemma,
or semiring axiom is imported. In particular, the two addition identities
above need only iterator computations at zero, one, and two; they do not
silently use a commutative-semiring normalizer.

Four negative diagnostics reject an incorrect selector law, a forged x=y
certificate, a mutated rewrite rule, and a nonfresh induction eigenvariable.

Limits
------
This artifact is not a complete iPRA checker and is not compared with the
tiny complete checkers in the source-size frontier. It does not mechanize
the relative-interpretation theorem, the Boolean gluing theorem, the entire
scalar predecessor construction, or iPRA bi-interpretability. It certifies
the stated supporting equations. The all-arities homomorphism result has
the uniform written endpoint-induction proof in the article; this bundle
contains its five arity-0-through-4 instances.
