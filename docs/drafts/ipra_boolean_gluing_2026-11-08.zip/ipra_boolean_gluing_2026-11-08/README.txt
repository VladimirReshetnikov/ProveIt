BOOLEAN GLUING AND THE ALGEBRAIC CORE OF iPRA
==========================================
Prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific date).

STATUS
------
This investigation does NOT provide a complete axiomatization or verifier
strictly smaller than the current drafts. It does not establish an absolute
minimum. The principal contribution is a weaker arithmetic theorem and an
explicit constructive proof transformation, with carefully stated limits.

The 35-page report gives a complete ordinary iPRA presentation, its full
logical and nonlogical basis, both interpretation composites, the new
mathematics, countermodels, comparison data, and inherited supporting
arithmetic. The complete presentation is credited to the existing drafts.
No inherited basis, comparator term, predecessor term, reflection theorem,
pairing compiler, or original central-selector idea is claimed as new.

MAIN RESULTS RELATIVE TO THE INSPECTED CORPUS
--------------------------------------------
1. The existing scalar comparator and predecessor have proofs in the theory
   T^- consisting of ordinary intuitionistic first-order logic with equality,
   the two initialized-iteration computation equations, and induction for
   literal equations. These proofs do not use Boolean range, numerical
   coverage, the falsity bridge, or assumed successor injectivity.

2. Boolean gluing is an admissible finite proof transformation in T^-.
   Equational conclusions proved under complementary Boolean assumptions
   can be recovered without those assumptions. The construction interprets
   the two proofs through complementary quotient equalities and recombines
   their conclusions.

3. The gluing result extends to positive retained assumptions (equations,
   falsity, conjunction, disjunction, and quantifiers, without implication)
   and conclusions generated from equations by conjunction and quantifiers.
   Existential witnesses are recombined using the numerical selector.
   Product counterexamples exclude arbitrary negative assumptions and
   disjunctive conclusions.

4. The initializer obstruction extends to arbitrary unary seeds sigma(n),
   including unbounded ones, and updates h(r,u,p) that can read the local
   iteration counter. The resulting term functions remain almost unary.
   The obstruction also excludes any one-dimensional recoding of addition.
   It does NOT exclude arbitrary relational interpretations, which the
   user's problem permits.

The central direct proof step is Boolean interpolation:
  v+b+1 = C(b,v+1,v+2), when B(b)=b.
It replaces the old case split inside the ramp induction. See Sections 5
and 6 for the complete comparator and predecessor construction.

THE COMPLETE THEORY
-------------------
Terms are x, 0, S(t), and I(n,a;u.h), with fixed passive parameters.
The binder is elaborated into a staged first-order signature; there is no
universal evaluator or quantification over program codes.

Define:
  1 = S(0)
  C(n,a,b) = I(n,a;u.b)
  Z(n) = C(n,1,0)
  B(n) = Z(Z(n))

The completed theory T_B has ordinary intuitionistic first-order logic with
equality and genuine falsity, and exactly:
  I(0,a;u.h) = a
  I(S(n),a;u.h) = h[I(n,a;u.h)/u]
  Z(n)=0 or Z(n)=1
  0=1 implies falsity
  contextual induction for literal equations, with a fresh step variable.

T^- omits the last two displayed axioms. T_B is deductively equivalent to
the coverage presentation in the current drafts, and is whole-domain
bi-interpretable and equiconsistent with full iPRA. The identity relation
implements both round trips. These claims are supported by written proofs,
including the reproduced reflection and scalar recursion compiler.

COMPARISON
----------
Pinned repository:
  https://github.com/VladimirReshetnikov/ProveIt
Commit:
  06e097f723c659030816e0194e5eb7e8c607ba9b

All twelve active draft archives were inspected. Twelve complete root
checker variants occur in eight of those archives. The remaining four
archives contain mathematical audits or proposals without a root checker.

                              Tokens    AST nodes    Bytes
  As delivered                   317          348      885
  Common helper names            317          348      869
  Common names and public driver 318          350      861

These are coordinatewise minima. Different programs attain different
coordinates. They are an observed envelope, not a mathematical lower bound.

The counts include each entire acceptance program: parsing, scope checking,
logical validation, rejection handling, and public output. Only standard
json/sys imports occur. Genuine docstrings are stripped and ast.unparse
normalization is applied. Source-size reductions caused solely by names
or by sys.exit versus raise SystemExit are reported separately.

CONTENTS
--------
report.pdf
  The complete mathematical report.
report.tex, sections/*.tex, appendices/*.tex
  Complete editable LaTeX source, including the inherited supporting proofs.
Makefile
  Build, verification, regeneration, and cleanup targets.
code/boolean_certificates.py
  Symbolic certificate producer and separate trace replay checker.
code/boolean_certificates_README.txt
  Detailed statement of the certificate format and trust boundary.
code/measure_current.py
  Standalone offline source measurement and source-integrity audit.
results/boolean_certificates.json
  Explicit symbolic proof trees.
results/boolean_certificate_results.json
  Replay receipt, per-identity counts, and negative diagnostics.
results/current_benchmark.json, results/checker_table.tex
  Comparison receipt and report table.
results/bootstrap_dependency_audit.json
  Dependency inventory of the inspected earlier scalar bootstrap.
results/validation.json
  Summary of executed checks and their limits.
comparison/checkers/
  The twelve exact root checker sources, with a manifest. Full source ZIPs
  and historical nested checker copies are not bundled or counted again.
provenance/
  Pinned archive identities, attribution, and inherited MIT No Attribution
  license. The historical clausal attribution is explicitly named as such.
SHA256SUMS
  Integrity manifest for all other deliverable files.

REPRODUCE
---------
Work from the directory containing this README. Python 3.10 or newer is
required; the supplied receipts were generated with CPython 3.12.14.
The Python scripts use only the standard library and need no network.

Replay the supplied symbolic certificates and recompute source metrics:
  make verify

Equivalently:
  python3 code/boolean_certificates.py --replay results/boolean_certificates.json
  python3 code/measure_current.py

Regenerate symbolic proof trees, then replay their serialized contents:
  make regenerate-certificates

Compile the report (two passes, with pdflatex and common TeX Live packages):
  make pdf

The PDF was built with pdfTeX 1.40.25 / TeX Live 2023. The source needs
amsmath, amssymb, amsthm, mathtools, geometry, lmodern, microtype, booktabs,
longtable, array, xcolor, listings, fancyhdr, needspace, and hyperref.

Validate the delivered files before rerunning scripts:
  sha256sum -c SHA256SUMS

Some regenerated JSON fields contain the Python version or local source
paths. These can change across machines without changing the mathematics
or normalized size metrics. Recompilation also changes PDF metadata.

EXACT VERIFICATION SCOPE
------------------------
The symbolic replay checks 65 identities using 106 endpoint equation-
induction nodes, 171 equational leaves, and 5,255 explicit rewrite steps.
Four corrupted certificates are rejected. All variables remain symbolic;
the opaque function symbols of arities zero through four remain opaque.
This is not finite numerical sampling.

The replay does not formalize the general quotient translation, positive
Horn gluing theorem, full predecessor construction, or bi-interpretability.
Those are mathematical proofs in the report, independently reviewed during
this investigation, but not certified in Lean or Rocq. The certificate
checker is not a complete iPRA verifier or a competitor in the size table.

The report's layout was visually inspected after compilation. The complete
source measurement and the symbolic replay passed. No new competitive
verifier was constructed, so no nonexistent smaller verifier is benchmarked.

The requested strict simplification remains unresolved.
