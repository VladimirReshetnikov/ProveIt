A SMALLER COMPLETE iPRA AXIOMATIZATION
=====================================
Prepared for Vladimir Reshetnikov -- 6 November 2026

MAIN RESULT

The complete checker.py is strictly below the componentwise minima of the six
current ProveIt/docs/drafts proposals at repository commit
edf7ea445673b29301012177998b0cc66bfabbf0.

                             Previous minimum     This checker
  Normalized Python tokens                603              585
  Executable AST nodes                    639              608
  Normalized source bytes               1,928            1,906
  Raw source bytes                      2,007            2,000

The main size measures strip actual docstrings and include the entire
acceptance program: grammar/binding data, substitution, formation checks,
logical rules, arithmetic schemas, input/output, and error handling. Its only
imports are json and sys. CPython 3.12.14 was used for exact reproduction.
Raw bytes are supplementary and depend on comments and formatting.

This is a strict finite-benchmark reduction, not a theorem of absolute
shortest possible axiomatization. The mathematical basis is inherited from
the draft program; the gain combines previously separate reductions, shared
elimination checking, and a finite binding-signature representation. The
report identifies the source of each inherited ingredient explicitly.

MATHEMATICS

report.tex and the compiled report.pdf provide a self-contained specification
of all logical and nonlogical rules. Terms have zero, successor, and initialized
primitive recursion. Formulas have equality, guarded universal quantification,
and existence. Arithmetic consists of the two recursion equations and one
parameterized numerical schema. Its equation branch gives induction; its
compound branch gives only numerical cases.

The report derives full intuitionistic first-order logic, equality reflexivity
and congruence, successor axioms, all primitive-recursive functions, and
quantifier-free induction (including implication and negation). It gives an
ordinary first-order realization with a precise falsity bridge, proves the two
whole-domain interpretations and their internal inverse isomorphisms, and
proves equiconsistency. The native and ordinary presentations are faithful
for full sequents, not merely for closed numerical equations.

Here iPRA means intuitionistic first-order arithmetic with symbols for each
fixed primitive-recursive description and induction for quantifier-free
formulas with parameters. No induction for arbitrary quantified formulas,
classical logic, or universal program evaluator is assumed.

The soundness proof handles all finite public JSON certificates, including
unused malformed proof data admitted by the small implementation. Public
goals and hypotheses always remain canonical and fully validated. An external
repair reconstructs exact-sequent proofs for a strict reference calculus.
No repair program participates in the small checker's acceptance path.

QUICK START

Python 3.10 or later supports the checker syntax. Use Python 3.12 for the exact
frozen measurements and reproduction script. All Python support uses the
standard library; no third-party Python package is needed.

From this directory:

    python3 checker.py examples/compact/reflexivity.json
    python3 checker.py examples/compact/residual.json
    python3 checker.py examples/compact/forall_exists_successor.json
    python3 checker.py examples/factored/nested_equality_transport.json

The CLI prints ACCEPT and returns status 0 for acceptance; it prints REJECT
and returns status 1 on an invalid certificate or exhausted resources.

The public input layout is

    [goal, proof, *hypotheses]

Zero is encoded by -1. Nonnegative integers are de Bruijn variable indices.
The proof and expression formats are completely described in report.pdf.
An open public sequent may retain assumptions; acceptance then certifies that
sequent, not an unconditional theorem. An empty public context certifies a
theorem uniformly in its free numerical parameters.

REPRODUCE EVERYTHING

    python3 reproduce.py

This reruns the full source comparison, all six proof-format translations,
and the adversarial/reconstruction audit, then writes verification_summary.json.

    python3 reproduce.py --pdf

The second command also compiles report.tex in three passes. It needs a LaTeX
distribution with pdflatex, Latin Modern, AMS packages, mathtools, booktabs,
microtype, enumitem, xcolor, listings, hyperref, and fancyhdr. If the distribution
has its source packages but lacks pdflatex.fmt, the script builds a private
format under .build/. It does not install packages or access the network.

The individual commands are:

    python3 comparison/measure.py
    python3 validation/translation/run.py
    python3 validation/audit/audit.py

The comparison can additionally check the original downloaded ZIP files:

    python3 comparison/measure.py --archives-dir /path/to/original/zips

Original archive URLs and exact hashes are recorded in comparison/manifest.json.
All source bytes needed for the ordinary offline comparison are already here.

VALIDATION RESULTS

  * 103/103 translated source records pass; 99 are inherited examples and
    four are new parameter/scope probes. They comprise 46 distinct target
    certificates and 42 distinct public sequents; 29 retain hypotheses.
  * All 11 compact arithmetic milestones pass, including the residual
    identity and both directions of the equality detector.
  * 177 targeted adversarial cases have their expected outcomes: 64 accept
    and 113 reject. All 177 run both normally and with Python -O, with the
    same public CLI verdicts.
  * Every accepted targeted case reconstructs to the frozen strict checker
    and also passes an independent interpreter using fresh named variables.
  * 1,400 deterministic mutations produce 125 acceptances and 1,275
    rejections; every acceptance also reconstructs and passes the oracle.
  * 1,800 canonical substitution comparisons, 900 malformed-environment
    probes, and 3,969 payload-pair equality probes show no failure.

These are finite implementation checks. The general soundness and
bi-interpretation arguments are mathematical proofs in the report, not
machine-verified Lean or Rocq metatheorems.

FILE GUIDE

  report.tex, report.pdf      Full specification, proofs, evidence, and questions.
  validation_summary.tex     Evidence paragraph included by report.tex.
  checker.py                 Entire measured acceptance boundary.
  reproduce.py               Untrusted aggregate reproduction driver.
  verification_summary.json  Recorded aggregate outcome.
  examples/                 All migrated and focused example certificates.
  comparison/               Frozen sources, provenance, measurements, census.
  validation/translation/   All-six format translators and exact-sequent audit.
  validation/audit/         Independent oracle, strict repair, adversarial data.
  validation/pdf_review.json Final rendering and geometry review record.
  MANIFEST.sha256           SHA-256 hashes of the final packaged files.

The expanded comparison retains 338 distinct Python sources with provenance
for 1,482 occurrences in the six drafts. There are 213 individual source
boundaries and 74 declared groups. Forty-eight groups duplicate singleton
boundaries; the result is 239 distinct source-member sets, including 26 truly
multifile groups. The corpus census is explicitly not a proof that all
historical programs are correct or complete. Its coordinatewise minima equal
the minima of the six primary checkers.

Exact preserved source annotations and hashes are included. Every new
comparison, translation, test, and presentation artifact is outside the
acceptance path. The report finishes with further research questions,
including formalizing repair, substitution coherence, and the inverse
interpretations in Lean or Rocq.
