"""Reproduce the complete-source comparison, certificate audits, and optional PDF."""

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(relative):
    subprocess.run([sys.executable, str(ROOT / relative)], cwd=ROOT, check=True)


def build_pdf():
    engine = shutil.which("pdflatex")
    if engine is None:
        raise RuntimeError("Install a LaTeX distribution with pdflatex to rebuild the PDF.")
    build = ROOT / ".build"
    build.mkdir(exist_ok=True)
    env = os.environ.copy()
    epoch = datetime.datetime(2026, 11, 6, 12, tzinfo=datetime.timezone.utc)
    env["SOURCE_DATE_EPOCH"] = str(int(epoch.timestamp()))
    env["FORCE_SOURCE_DATE"] = "1"
    extra = []
    kpsewhich = shutil.which("kpsewhich")
    if kpsewhich:
        probe = subprocess.run([kpsewhich, "pdflatex.fmt"], capture_output=True, text=True)
        if not probe.stdout.strip():
            pdftex = shutil.which("pdftex")
            if pdftex is None:
                raise RuntimeError("No pdflatex format or pdftex format-building engine found.")
            formats = build / "formats"
            formats.mkdir(exist_ok=True)
            command = [pdftex, "-ini", "-etex", "-interaction=nonstopmode",
                       "-halt-on-error", "-jobname=pdflatex", "-progname=pdflatex",
                       "-output-directory=" + str(formats), "pdflatex.ini"]
            result = subprocess.run(command, cwd=build, env=env, capture_output=True, text=True)
            (build / "format-build.log").write_text(result.stdout + result.stderr)
            if result.returncode:
                raise RuntimeError("Cannot build pdflatex format; see .build/format-build.log.")
            extra = ["-fmt=" + str(formats / "pdflatex.fmt")]
    for number in range(1, 4):
        command = [engine, *extra, "-interaction=nonstopmode", "-halt-on-error", "report.tex"]
        result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True)
        (build / f"latex-pass-{number}.log").write_text(result.stdout + result.stderr)
        if result.returncode:
            raise RuntimeError(f"LaTeX failed; see .build/latex-pass-{number}.log.")
    log = (ROOT / "report.log").read_text()
    if "Overfull \\hbox" in log or "There were undefined references" in log:
        raise RuntimeError("PDF needs layout/reference review; inspect report.log.")
    print("PDF compiled in three passes with no overfull boxes or unresolved references.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf", action="store_true", help="Also compile report.tex three times.")
    args = parser.parse_args()
    if sys.version_info[:2] != (3, 12):
        raise RuntimeError("Use Python 3.12 for the frozen AST/token measurements.")
    run("comparison/measure.py")
    run("validation/translation/run.py")
    run("validation/audit/audit.py")
    if args.pdf:
        build_pdf()
    result = {
        "status": "PASS",
        "source_commit": "edf7ea445673b29301012177998b0cc66bfabbf0",
        "checker_sha256": hashlib.sha256((ROOT / "checker.py").read_bytes()).hexdigest(),
        "python": sys.version,
        "comparison": json.loads((ROOT / "comparison/metrics.json").read_text()),
        "translation": json.loads((ROOT / "validation/translation/results.json").read_text()),
        "audit": json.loads((ROOT / "validation/audit/summary.json").read_text()),
        "pdf_rebuilt": args.pdf,
    }
    (ROOT / "verification_summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print("PASS: complete-source comparison, exact-sequent translations, and independent audit.")


if __name__ == "__main__":
    main()
