#!/usr/bin/env python3
"""Reproduce the complete-source comparison without executing any checker.

Run from any directory. Python 3.12 reproduces the recorded normalization.
Optional --archives-dir verifies the six original ZIP archives as well.
"""

import argparse
import ast
import collections
import csv
import hashlib
import io
import json
from pathlib import Path
import platform
import sys
import tokenize
import zipfile


HERE = Path(__file__).resolve().parent
FIELDS = ("ast_nodes", "normalized_tokens", "normalized_bytes", "raw_bytes")
AUDIT_FIELDS = dict(zip(FIELDS, ("ast", "tokens", "bytes", "raw")))
LAYOUT_TOKENS = {
    tokenize.ENCODING, tokenize.ENDMARKER, tokenize.INDENT, tokenize.DEDENT,
    tokenize.NEWLINE, tokenize.NL, tokenize.COMMENT,
}


def demand(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(name):
    return json.loads((HERE / name).read_text(encoding="utf-8"))


def write_json(name, value):
    (HERE / name).write_text(
        json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )


def strip_docstrings(tree):
    """Remove only actual leading module, class, or function docstrings."""
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef,
                             ast.FunctionDef, ast.AsyncFunctionDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                del node.body[0]
    return tree


def source_facts(data):
    text = data.decode("utf-8")
    tree = ast.parse(text)
    imports = set()
    functions = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.add(node.module or "")
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            functions.add(node.name)
    stripped = strip_docstrings(tree)
    normalized = (ast.unparse(stripped) + "\n").encode("utf-8")
    significant = [token for token in tokenize.tokenize(io.BytesIO(normalized).readline)
                   if token.type not in LAYOUT_TOKENS]
    return {
        "sha256": digest(data),
        "normalized_sha256": digest(normalized),
        "ast_nodes": sum(1 for _ in ast.walk(stripped)),
        "normalized_tokens": len(significant),
        "normalized_bytes": len(normalized),
        "raw_bytes": len(data),
        "imports": sorted(imports),
        "functions": sorted(functions),
        "has_cli_markers": "__main__" in text and "json.load" in text,
    }


def sum_members(members, source_metrics):
    return {field: sum(source_metrics[h][field] for h in members)
            for field in FIELDS}


def envelope(rows):
    return {field: min(row[field] for row in rows) for field in FIELDS}


def collect_declarations(manifest):
    known = set()
    groups = set()
    for declaration in manifest["boundary_declarations"]:
        data = (HERE / declaration["file"]).read_bytes()
        demand(digest(data) == declaration["sha256"],
               "Boundary-declaration hash mismatch: " + declaration["file"])
        parsed = json.loads(data)
        known.update(parsed.get("standalone", []))
        for key in ("historical_groups", "dependency_groups"):
            for group in parsed.get(key, []):
                entries = group.get("members") or group.get("files")
                if entries:
                    members = tuple(sorted({
                        entry if isinstance(entry, str) else entry["sha256"]
                        for entry in entries
                    }))
                    groups.add(members)
    return known, groups


def verify_profiles(candidate_data, primary):
    """Inspect finite literals; do not import or execute either program."""
    def literal_profiles(data):
        tree = ast.parse(data)
        matches = [node.value for node in tree.body
                   if isinstance(node, ast.Assign)
                   and any(isinstance(target, ast.Name) and target.id == "SCOPES"
                           for target in node.targets)]
        demand(len(matches) == 1, "Expected one literal SCOPES assignment")
        return ast.literal_eval(matches[0])

    expected = ({"s": (0,), "r": (0, 0, 2)},
                {"=": (0, 0), "pi": (1, 1), "ex": (1,)})
    factored = next(row for row in primary if row["label"] == "Factored kernel")
    original = literal_profiles((HERE / factored["file"]).read_bytes())
    actual = literal_profiles(candidate_data)
    demand(original == expected, "Frozen tuple profiles differ from the stated profiles")
    demand(len(actual) == len(expected), "Profile-sort count differs")
    rows = []
    for sort, old, new in zip(("term", "formula"), expected, actual, strict=True):
        demand(set(old) == set(new), "Profile constructor set differs")
        for tag in old:
            demand(type(new[tag]) is bytes, "Expected a literal byte profile")
            demand(tuple(new[tag]) == old[tag], "Profile differs for " + tag)
            rows.append({"sort": sort, "constructor": tag,
                         "tuple_widths": list(old[tag]),
                         "byte_iteration": list(new[tag]),
                         "arity": len(old[tag]), "equal": True})
    return {"status": "PASS", "candidate_sha256": digest(candidate_data),
            "profile_count": len(rows), "profiles": rows,
            "method": "AST literal evaluation and exact finite sequence comparison; no checker execution."}


def verify_archives(directory, manifest, sources):
    expected = {(occ["archive"], occ["member"]): h
                for h, record in sources.items() for occ in record["occurrences"]}
    observed = {}
    checked = []
    for record in manifest["archives"]:
        path = directory / record["name"]
        data = path.read_bytes()
        demand(len(data) == record["bytes"], "Archive byte count differs: " + str(path))
        demand(digest(data) == record["sha256"], "Archive SHA-256 differs: " + str(path))
        git_blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        demand(git_blob == record["git_blob_sha1"], "Git blob identity differs: " + str(path))
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            for name in archive.namelist():
                if name.endswith(".py"):
                    observed[(record["name"], name)] = digest(archive.read(name))
            for row in manifest["primary"] + manifest["boundary_declarations"]:
                if row["archive"] == record["name"]:
                    demand(archive.read(row["member"]) == (HERE / row["file"]).read_bytes(),
                           "Frozen member differs from archive: " + row["member"])
        checked.append({"archive": record["name"], "sha256": record["sha256"], "verified": True})
    demand(observed == expected, "Full Python-member inventory differs from the original archives")
    return {"status": "PASS", "commit": manifest["commit"], "archives": checked,
            "python_occurrences": len(observed), "distinct_sources": len(set(observed.values()))}


def write_csv(name, fields, rows):
    with (HERE / name).open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archives-dir", type=Path,
                        help="Optional directory containing the six original ZIP archives")
    args = parser.parse_args()
    manifest = read_json("manifest.json")
    sources = read_json("source_manifest.json")
    inventory_data = (HERE / "inventory.json").read_bytes()
    boundaries_data = (HERE / "boundaries.json").read_bytes()
    demand(digest(inventory_data) == manifest["audit_inventory_sha256"], "Audit inventory changed")
    demand(digest(boundaries_data) == manifest["audit_boundaries_sha256"], "Audit boundaries changed")
    inventory = json.loads(inventory_data)
    frozen_boundaries = json.loads(boundaries_data)

    source_metrics = {}
    for h, record in sorted(sources.items()):
        data = (HERE / record["file"]).read_bytes()
        demand(digest(data) == h == record["sha256"], "Source hash differs: " + h)
        facts = source_facts(data)
        demand(facts["raw_bytes"] == record["bytes"], "Source byte count differs: " + h)
        prior = inventory["sources"][h]
        demand(all(facts[field] == prior[old] for field, old in AUDIT_FIELDS.items()),
               "Recorded normalization differs for " + h + "; reproduce with Python 3.12")
        demand(set(facts["functions"]) == set(prior["functions"]), "Function inventory differs")
        demand(set(facts["imports"]) == set(prior["imports"]), "Import inventory differs")
        demand(facts["has_cli_markers"] == prior["has_cli"], "CLI marker inventory differs")
        source_metrics[h] = facts
    demand(set(source_metrics) == set(inventory["sources"]), "Distinct source inventory differs")
    occurrences = sum(len(row["occurrences"]) for row in sources.values())
    demand(occurrences == inventory["occurrences"] == manifest["occurrence_count"],
           "Occurrence count differs")

    known, groups = collect_declarations(manifest)
    heuristic = {h for h, facts in source_metrics.items()
                 if "check" in facts["functions"] and facts["has_cli_markers"]
                 and set(facts["imports"]) <= {"json", "sys"}}
    standalone = known | heuristic
    rows = []
    for kind, sets in (("standalone", ((h,) for h in sorted(standalone))),
                       ("dependency_group", sorted(groups))):
        for members in sets:
            demand(set(members) <= set(source_metrics), "Missing acceptance-boundary member")
            rows.append({"kind": kind, "members": list(members),
                         **sum_members(members, source_metrics)})
    frozen_sets = {(row["kind"], tuple(sorted(row["members"]))) for row in frozen_boundaries["rows"]}
    demand({(row["kind"], tuple(row["members"])) for row in rows} == frozen_sets,
           "Reconstructed boundary selection differs")
    by_boundary = {(row["kind"], tuple(row["members"])): row for row in rows}
    for old in frozen_boundaries["rows"]:
        new = by_boundary[(old["kind"], tuple(sorted(old["members"])))]
        demand(all(new[field] == old[key] for field, key in AUDIT_FIELDS.items()),
               "Boundary metric differs")

    primary = []
    for row in manifest["primary"]:
        data = (HERE / row["file"]).read_bytes()
        demand(digest(data) == row["sha256"], "Primary source hash differs")
        primary.append({**row, **source_facts(data)})
    candidate_data = (HERE / manifest["candidate"]).read_bytes()
    candidate = source_facts(candidate_data)
    demand(candidate["imports"] == ["json", "sys"],
           "Candidate acceptance dependencies are not exactly json and sys")
    profile_check = verify_profiles(candidate_data, primary)
    complete_min = envelope(rows)
    current_min = envelope(primary)
    strict = {field: candidate[field] < complete_min[field] for field in FIELDS}
    demand(all(strict.values()), "Candidate is not strictly below the complete envelope")
    member_sets = {tuple(row["members"]) for row in rows}
    group_sizes = collections.Counter(map(len, groups))
    counts = {
        "archives": len(manifest["archives"]), "python_occurrences": occurrences,
        "distinct_sources": len(source_metrics), "known_standalone": len(known),
        "heuristic_json_sys_only": len(heuristic), "standalone_union": len(standalone),
        "declared_groups": len(groups), "multifile_groups": sum(n for k, n in group_sizes.items() if k > 1),
        "singleton_group_overlap": len({(h,) for h in standalone} & groups),
        "boundary_records": len(rows), "distinct_member_sets": len(member_sets),
        "selected_source_files": len({h for row in rows for h in row["members"]}),
    }
    result = {
        "status": "PASS", "commit": manifest["commit"],
        "python_version": platform.python_version(), "python_implementation": platform.python_implementation(),
        "counts": counts, "primary": primary, "primary_envelope": current_min,
        "complete_envelope": complete_min, "candidate": candidate, "strictly_below": strict,
        "savings": {field: complete_min[field] - candidate[field] for field in FIELDS},
        "savings_percent": {field: 100 * (complete_min[field] - candidate[field]) / complete_min[field]
                            for field in FIELDS},
        "attaining_sources": {field: sorted(h for h in standalone if source_metrics[h][field] == complete_min[field])
                              for field in FIELDS},
        "profile_equivalence": "profile_equivalence.json",
        "heuristic_filter": "A function named check at any AST depth; literal __main__ and json.load markers;"
                            " the exact set of static import module names is a subset of {json, sys}.",
        "measurement_boundary": "Complete acceptance source, including syntax, rules, validation, JSON input and CLI."
                                " Standard Python runtime and json/sys implementations are excluded equally."
                                " Every declared multifile group is measured as the sum of all its supplied members.",
        "selection_qualification": "A mechanical candidate inventory and inherited declarations, not a certification"
                                   " that every historical program is sound or complete, and not an absolute lower-bound theorem.",
    }
    write_json("metrics.json", result)
    write_json("source_metrics.json", source_metrics)
    write_json("remeasured_boundaries.json", rows)
    write_json("profile_equivalence.json", profile_check)
    if args.archives_dir:
        write_json("archive_verification.json", verify_archives(args.archives_dir, manifest, sources))

    csv_rows = [{"kind": "primary", **row} for row in primary]
    csv_rows += [{"kind": "primary_envelope", "label": "Current six minimum", **current_min},
                 {"kind": "complete_envelope", "label": "Complete selected-boundary minimum", **complete_min},
                 {"kind": "candidate", "label": "Small kernel", **candidate}]
    write_csv("metrics.csv", ("kind", "label", *FIELDS, "sha256", "file", "archive", "member"), csv_rows)
    write_csv("boundaries.csv", ("kind", "members", *FIELDS),
              [{**row, "members": ";".join(row["members"])} for row in rows])
    write_csv("sources.csv", ("sha256", *FIELDS, "imports", "occurrences", "standalone", "group_member"),
              [{**facts, "imports": ";".join(facts["imports"]), "occurrences": len(sources[h]["occurrences"]),
                "standalone": h in standalone, "group_member": any(h in group for group in groups)}
               for h, facts in sorted(source_metrics.items())])

    lines = ["REPRODUCIBLE COMPLETE-SOURCE COMPARISON", "", "Status: PASS",
             "Pinned ProveIt commit: " + manifest["commit"],
             "Runtime: " + platform.python_implementation() + " " + platform.python_version(), "",
             "All six original primary checkers:"]
    for row in primary:
        lines.append("  {label}: AST {ast_nodes}, tokens {normalized_tokens}, normalized bytes {normalized_bytes}, raw bytes {raw_bytes}".format(**row))
    lines += ["", "Coordinatewise complete-boundary minimum: " + str(complete_min),
              "Candidate: " + str({field: candidate[field] for field in FIELDS}),
              "Candidate SHA-256: " + candidate["sha256"],
              "Strict improvement in all four recorded measures: " + str(all(strict.values())), "",
              "Inventory: " + str(counts), "Standalone heuristic: " + result["heuristic_filter"],
              "There are 287 labeled boundary records, but 48 singleton groups duplicate standalone sets;",
              "the inventory contains 239 different member sets, including 26 multifile groups.", "",
              result["measurement_boundary"], result["selection_qualification"], "",
              "Actual docstrings are removed from structural/normalized measurements. Comments and layout",
              "are excluded from significant-token counts. Raw bytes include documentation and whitespace.",
              "Normalization does not rename identifiers. Candidate acceptance imports only json/sys.",
              "Comparators are retained byte-for-byte. No comparator is executed by this measurement script.",
              "Proof builders, translations, validation tools, examples, reports and comparison utilities are",
              "outside the candidate's acceptance path and excluded from its measured source boundary.", "",
              "Five finite binding signatures have been checked by AST literal evaluation:",
              "iterating the candidate's byte literals yields exactly the original tuple widths and arities.", "",
              "Run: python3 comparison/measure.py",
              "Optional full archive verification: python3 comparison/measure.py --archives-dir /path/to/zips", ""]
    (HERE / "summary.txt").write_text("\n".join(lines), encoding="utf-8")
    macros = {"BaselineAST": complete_min["ast_nodes"], "CandidateAST": candidate["ast_nodes"],
              "BaselineTokens": complete_min["normalized_tokens"], "CandidateTokens": candidate["normalized_tokens"],
              "BaselineBytes": complete_min["normalized_bytes"], "CandidateBytes": candidate["normalized_bytes"],
              "BaselineRawBytes": complete_min["raw_bytes"], "CandidateRawBytes": candidate["raw_bytes"],
              "ArchiveCount": counts["archives"], "SourceOccurrences": occurrences,
              "DistinctSources": len(sources), "StandaloneCount": len(standalone),
              "DeclaredGroupCount": len(groups), "DistinctBoundaryCount": len(member_sets),
              "MultifileGroupCount": counts["multifile_groups"]}
    (HERE / "numbers.tex").write_text(
        "% Generated by comparison/measure.py.\n" +
        "".join("\\newcommand{\\" + name + "}{" + str(value) + "}\n" for name, value in macros.items()),
        encoding="utf-8")
    table = ["% Generated by comparison/measure.py.", "\\begin{tabular}{lrrrr}",
             "\\toprule", "Program & AST & Tokens & Norm. bytes & Raw bytes\\\\", "\\midrule"]
    for row in primary:
        table.append("{label} & {ast_nodes} & {normalized_tokens} & {normalized_bytes} & {raw_bytes}\\\\".format(**row))
    table += ["\\midrule", "Complete envelope & {ast_nodes} & {normalized_tokens} & {normalized_bytes} & {raw_bytes}\\\\".format(**complete_min),
              "Small kernel & {ast_nodes} & {normalized_tokens} & {normalized_bytes} & {raw_bytes}\\\\".format(**candidate),
              "\\bottomrule", "\\end{tabular}", ""]
    (HERE / "comparison_table.tex").write_text("\n".join(table), encoding="utf-8")
    print("PASS: six primary sources, 338 distinct sources, 213 standalone records, 74 declared groups.")
    print("Candidate:", {field: candidate[field] for field in FIELDS})
    print("Complete envelope:", complete_min)
    print("All four strict comparisons and five binding-profile identities verified.")


if __name__ == "__main__":
    main()
