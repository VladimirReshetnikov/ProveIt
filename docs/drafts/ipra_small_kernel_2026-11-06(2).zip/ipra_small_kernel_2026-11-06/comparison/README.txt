COMPLETE-SOURCE COMPARISON

This directory freezes the comparison against ProveIt/docs/drafts at commit
edf7ea445673b29301012177998b0cc66bfabbf0. It contains the exact six current
primary checkers, every distinct Python source embedded in those six archives,
the boundary declarations supplied by the drafts, and a reproducible census.

REPRODUCTION

Use Python 3.12. The recorded run used CPython 3.12.14. From the archive root:

    python3 comparison/measure.py

This verifies every frozen source hash, recomputes every source metric,
reconstructs the selected boundaries, checks the candidate's import boundary,
checks its five finite binding profiles, and regenerates the result files.
No checker or other frozen source is imported or executed by measure.py.
The script uses only Python's standard library.

For an additional comparison against the original six downloaded ZIP files:

    python3 comparison/measure.py --archives-dir /path/to/original/zips

The ZIP files need not be extracted. Their lengths, SHA-256 digests, and Git
blob identities are checked. All 1,482 Python members, the six primary members,
and the four preserved boundary-declaration documents must match. The pinned
source URLs and archive hashes are in manifest.json. The completed archive
verification for the supplied snapshot is recorded in archive_verification.json.

MEASUREMENT BOUNDARY

The candidate boundary is the entire checker.py file: its syntax/binding table,
substitution and validation traversal, all inference branches, public sequent
validation, error handling, JSON input, and command-line result handling.
Its only imports are json and sys. The standard Python runtime and standard
library implementations are outside this boundary for every comparator too.

Each historical multifile boundary includes all its declared acceptance files.
Metrics are summed across the members without deleting adapters, validators,
or logical tables that participate in acceptance. Repeated copies of the same
source are identified by SHA-256; a member is counted once within its group.

The new proof builders, certificate translators, regression suites, independent
validators, examples, comparison utilities, and mathematical report do not
participate in checker acceptance and are excluded from its measured source.
They are not imported by checker.py. This exclusion does not remove any part
of the acceptance logic.

For AST nodes, the Python tree is counted after removing actual leading
module, class, and function docstrings. Other string expressions remain.
Normalized source is ast.unparse of that tree plus one final newline. Tokens
are those of this normalized source after removing comments, layout tokens,
and stream markers. Normalized bytes count the UTF-8 bytes of that source.
Normalization does not shorten names or perform code optimization. Raw bytes
include all documentation and whitespace and are supplementary: their small
gain should not be mistaken for an invariant mathematical complexity measure.

INVENTORY AND SELECTION

The six ZIPs contain 1,482 Python-file occurrences and 338 distinct sources.
Every one of the 338 byte sequences is supplied under sources/<sha256>.py.
The complete archive/member provenance is in source_manifest.json. The original
working census and boundary records are retained as inventory.json and
boundaries.json; measure.py reproduces their measurements from actual bytes.

The standalone selection is the union of:

  * 195 SHA-256 identities declared standalone by the preserved draft manifests;
  * 204 sources with a function named check, both literal CLI markers
    '__main__' and 'json.load', and static import module names drawn only
    from the exact set {'json', 'sys'}.

Function discovery uses Python's AST at every nesting depth. CLI-marker
matching is deliberately described as a heuristic, not a semantic guarantee.
The predicate uses this exact two-module set, not the broader standard library.
Generated results call its count heuristic_json_sys_only; the unchanged original
audit used the less specific field name heuristic_standard_only for this count.
The union contains 213 source identities. A declaration or heuristic match
does not prove that a historical checker is correct or complete.

The manifests also declare 74 distinct dependency groups. Their member lists
are normalized by sorting and deduplicating identities. Forty-eight are
singleton groups already represented by standalone sources. Thus there are
287 labeled comparison records but 239 distinct member sets, including 26
genuinely multifile groups. Those boundaries use 240 distinct source files.
All 338 sources are retained, so the support/selection decisions are inspectable.

The exact coordinatewise minima are the same for the six primary programs and
for the complete selected-boundary census:

    AST nodes               639
    Normalized tokens       603
    Normalized source bytes 1928
    Raw source bytes        2007

The candidate is measured again on every run. The supplied final version has
608 AST nodes, 585 normalized tokens, 1906 normalized bytes, and 2000 raw bytes.
measure.py requires strict improvement in all four recorded measures. The
claim is a finite comparison with these supplied programs, not an absolute
lower bound on all iPRA axiomatizations or all implementation languages.

BINDING PROFILES

profile_equivalence.json records a static check of every constructor profile.
AST literal evaluation extracts SCOPES from the factored comparator and from
the new checker. The latter's byte literals must iterate to exactly the former
tuples:

    term s:      (0)
    term r:      (0, 0, 2)
    formula =:   (0, 0)
    formula pi:  (1, 1)
    formula ex:  (1)

This verifies all five finite sequences, their arities, and their sort/tag
keys. It does not replace the mathematical proof of checker soundness.

FILE GUIDE

  current/                    Exact six original primary acceptance programs.
  sources/                    All 338 distinct original Python byte sequences.
  declarations/               Four exact source documents declaring boundaries.
  manifest.json               Pinned archive and primary/declaration provenance.
  repository_manifest.json    Original GitHub directory metadata.
  source_manifest.json        Exact current archive/member provenance per source.
  inventory.json              Original full source census, including measurements.
  boundaries.json             Original selected-boundary audit records.
  measure.py                  Standalone reproduction and verification script.
  metrics.json, metrics.csv   Candidate, primary, and envelope measurements.
  source_metrics.json         Remeasured facts for all 338 source identities.
  sources.csv                 Compact source inventory and selection roles.
  remeasured_boundaries.json  Every reproduced boundary and its aggregate cost.
  boundaries.csv              The same labeled boundary measurements as a table.
  profile_equivalence.json   Exhaustive finite binding-profile comparison.
  archive_verification.json  Original-ZIP provenance verification results.
  summary.txt                Human-readable outcome and measurement policy.
  numbers.tex                 Result macros for the mathematical report.
  comparison_table.tex       Ready-to-include LaTeX comparison table.

The archived draft sources and metadata are reproduced unchanged from the
user-specified ProveIt snapshot. Their original annotations and attributions
remain in the source files. The new measurement utility is an ancillary
artifact of this report and is not an acceptance dependency.
