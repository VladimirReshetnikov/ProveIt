"""Generate the paper's numbers and table from the measured source files."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
FIELDS = ('ast_nodes', 'normalized_tokens', 'normalized_bytes', 'source_tokens', 'raw_bytes')
LABELS = {
    'ipra_demand_kernel_2026-11-06 (1).zip': 'Demand (second upload)',
    'ipra_demand_kernel_2026-11-06.zip': 'Demand',
    'ipra_local_kernel_2026-11-06.zip': 'Local',
    'ipra_scoped_rules_2026-11-06.zip': 'Scoped rules',
    'ipra_shared_transition_2026-11-06.zip': 'Shared transition',
    'ipra_uniform_kernel_2026-11-06.zip': 'Uniform',
}


def main():
    metrics = json.loads((ROOT / 'results/metrics.json').read_text())
    primary, strict, baseline = (metrics[k] for k in ('candidate', 'strict_candidate', 'envelope'))
    for filename, measured in [('checker.py', primary), ('strict_checker.py', strict)]:
        if hashlib.sha256((ROOT / filename).read_bytes()).hexdigest() != measured['sha256']:
            raise ValueError('The checker changed after measurement: ' + filename)
    values = {'PrimaryAST': primary['ast_nodes'], 'PrimaryTokens': primary['normalized_tokens'],
              'PrimaryBytes': f"{primary['normalized_bytes']:,}",
              'StrictAST': strict['ast_nodes'], 'StrictTokens': strict['normalized_tokens'],
              'StrictBytes': f"{strict['normalized_bytes']:,}", 'PythonVersion': sys.version.split()[0]}
    for name, field in [('ASTSaving', 'ast_nodes'), ('TokenSaving', 'normalized_tokens'),
                        ('ByteSaving', 'normalized_bytes')]:
        values[name] = f"{100 * (baseline[field] - primary[field]) / baseline[field]:.2f}"
    (ROOT / 'results/numbers.tex').write_text(''.join(
        '\\newcommand{\\' + key + '}{' + str(value) + '}\n' for key, value in values.items()))
    lines = [r'\begin{tabular}{@{}lrrrrr@{}}', r'\toprule',
             r'Checker & AST & Norm.\ tok. & Norm.\ bytes & Source tok. & Raw bytes\\',
             r'\midrule']
    for row in metrics['primary']:
        lines.append(LABELS[row['archive']] + ' & ' +
                     ' & '.join(f'{row[k]:,}' for k in FIELDS) + r'\\')
    lines.extend([r'\midrule', 'Current lower envelope & ' +
                  ' & '.join(f'{baseline[k]:,}' for k in FIELDS) + r'\\'])
    for name, row in [('Goal-directed primary', primary), ('Strict witnesses', strict)]:
        lines.append(r'\textbf{' + name + '} & ' +
                     ' & '.join(r'\textbf{' + f'{row[k]:,}' + '}' for k in FIELDS) + r'\\')
    lines.extend([r'\bottomrule', r'\end{tabular}', ''])
    (ROOT / 'results/comparison_table.tex').write_text('\n'.join(lines))
    print('Paper measurements agree with both final checker hashes.')


if __name__ == '__main__':
    main()
