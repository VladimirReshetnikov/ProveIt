"""Rebuild the PDF and optionally an integrity-checked ZIP archive."""

import argparse
import hashlib
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
IGNORED_SUFFIXES = {".aux", ".log", ".out", ".toc", ".fdb_latexmk", ".fls", ".pyc"}


def files():
    return sorted(p for p in ROOT.rglob("*") if p.is_file()
                  and "__pycache__" not in p.parts and p.name != "MANIFEST.sha256"
                  and p.suffix not in IGNORED_SUFFIXES)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--zip", action="store_true")
    parser.add_argument("--no-pdf", action="store_true", help="Use the already verified PDF")
    args = parser.parse_args()
    if not args.no_pdf:
        subprocess.run([sys.executable, str(ROOT / "reproduce.py"), "--metrics-only", "--pdf"],
                       cwd=ROOT, check=True)
    if not (ROOT / "report.pdf").is_file():
        raise RuntimeError("Missing compiled report.pdf")
    entries = files()
    manifest = "".join(hashlib.sha256(p.read_bytes()).hexdigest() + "  " +
                       p.relative_to(ROOT).as_posix() + "\n" for p in entries)
    (ROOT / "MANIFEST.sha256").write_text(manifest)
    if args.zip:
        target = ROOT.parent / (ROOT.name + ".zip")
        with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for path in [*entries, ROOT / "MANIFEST.sha256"]:
                archive.write(path, ROOT.name + "/" + path.relative_to(ROOT).as_posix())
        with zipfile.ZipFile(target) as archive:
            if archive.testzip() is not None:
                raise RuntimeError("Archive CRC verification failed")
        print(target)


if __name__ == "__main__":
    main()
