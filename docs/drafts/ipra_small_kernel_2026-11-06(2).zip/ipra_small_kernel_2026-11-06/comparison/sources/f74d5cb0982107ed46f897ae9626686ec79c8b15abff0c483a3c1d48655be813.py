"""Untrusted translation from the published checker dialects.

The source checker supplies inferred formulas only during this offline
translation. The destination checker independently checks every result. All
renaming and substitution here uses independent globally named syntax.
"""
from named_syntax import rename, subst, under_binder, well_formed
from rule_oracle import occurs_slot


def translate(p, old_g, new_g, source, local_nat=False,
              uniform=False, mapping=lambda i: i):
    def rec(q, g=old_g, h=new_g, f=mapping):
        return translate(q, g, h, source, local_nat, uniform, f)

    def raised(g):
        return [subst(a) for a in g]

    bound = under_binder(mapping)
    if type(p) is list and p:
        tag = p[0]
        if tag == ('pi' if uniform else 'lam'):
            _, a, q = p
            a_new = rename(a, bound)
            return ['lam', a_new, rec(q, [*raised(old_g), a],
                                     [*raised(new_g), a_new], bound)]
        if tag == ('ex' if uniform else 'pack'):
            _, t, q = p
            t_new = rename(t, mapping, False)
            a = ['=', 0, subst(t, formula=False)]
            a_new = ['=', 0, subst(t_new, formula=False)]
            return ['pack', t_new, rec(q, [*raised(old_g), a],
                                      [*raised(new_g), a_new], bound)]
        if tag == 'nat':
            _, a, q = p
            a_new = rename(a, bound)
            h = a if a[0] == '=' else subst(a, [-1, 0])
            h_new = a_new if a_new[0] == '=' else subst(a_new, [-1, 0])
            new_local = [*raised(new_g), h_new]
            intro = 'pi' if uniform else 'lam'
            if local_nat:
                body = rec(q, [*raised(old_g), h], new_local, bound)
            elif type(q) is list and q[0] == intro and q[1] == h:
                body = rec(q[2], [*raised(old_g), h], new_local, bound)
            else:
                step = rec(q, old_g, new_local, lambda i: 1 + mapping(i))
                body = [step, 0, len(new_g)]
            return ['nat', a_new, body]
        if tag == 'r':
            return rename(p, mapping, False)
        if uniform or tag == 'use':
            major_proof, *args = p if uniform else p[1:]
            major = source.infer(major_proof, old_g)
            major_new = rec(major_proof)
            if major[0] == 'ex':
                conclusion = rename(source.infer(p, old_g), mapping)
                return [major_new, conclusion,
                        rec(args[-1], [*raised(old_g), major[1]],
                            [*raised(new_g), rename(major[1], bound)], bound)]
            annotation, q = args
            if major[0] == '=':
                annotation = rename(annotation, bound)
            else:
                if not well_formed(annotation, False):
                    if any(occurs_slot(a) for a in major[1:]):
                        raise ValueError('source used a malformed witness')
                    annotation = -1
                annotation = rename(annotation, mapping, False)
            return [major_new, annotation, rec(q)]
    formula = source.infer(p, old_g)
    return new_g.index(rename(formula, mapping))


def document(data, source, local_nat=False, uniform=False, flat=False):
    if flat:
        a, p, *g = data
    else:
        g, a, p = data
    return [a, translate(p, g, g, source, local_nat, uniform), *g]
