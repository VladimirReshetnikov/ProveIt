"""Recount the complete candidate and frozen comparison boundaries, offline.

The measurement convention is retained from the supplied ProveIt drafts.
Sources are parsed, never imported or executed. Python and json/sys are the
common platform. Docstrings and comments are excluded from primary metrics.
"""
import ast
import hashlib
import io
import json
from pathlib import Path
import sys
import tokenize

ROOT = Path(__file__).resolve().parent
FIELDS = ('source_tokens', 'normalized_tokens', 'ast_nodes',
          'normalized_bytes', 'raw_bytes')
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}


def measure(path):
    raw = path.read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                doc = node.body.pop(0)
                spans.append(((doc.lineno, doc.col_offset), (doc.end_lineno, doc.end_col_offset)))
    normalized = ast.unparse(tree) + '\n'
    def count_tokens(text, omitted=()):
        return sum(token.type not in IGNORED and not any(
            start <= token.start and token.end <= end for start, end in omitted
        ) for token in tokenize.generate_tokens(io.StringIO(text).readline))
    return {'sha256': hashlib.sha256(raw).hexdigest(),
            'source_tokens': count_tokens(source, spans),
            'normalized_tokens': count_tokens(normalized),
            'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'normalized_bytes': len(normalized.encode()), 'raw_bytes': len(raw)}


def main():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    sources = {}
    for entry in manifest['sources']:
        row = measure(ROOT / entry['file'])
        if row['sha256'] != entry['sha256']:
            raise ValueError('Modified comparison source: ' + entry['file'])
        sources[entry['sha256']] = row
    groups = []
    for group in manifest['historical_groups']:
        hashes = list(dict.fromkeys(f['sha256'] for f in group['files']))
        groups.append({'id': group['id'], 'label': group['label'],
                       **{key: sum(sources[h][key] for h in hashes) for key in FIELDS}})
    competitors = [sources[h] for h in manifest['standalone']] + groups
    envelope = {key: min(row[key] for row in competitors) for key in FIELDS}
    primary = [{**entry, **sources[entry['sha256']]} for entry in manifest['primary']]
    candidate_path = ROOT.parent / 'checker.py'
    candidate = measure(candidate_path) if candidate_path.exists() else None
    strict_path = ROOT.parent / 'strict_checker.py'
    strict = measure(strict_path) if strict_path.exists() else None
    result = {'python': sys.version, 'commit': manifest['commit'], 'scan': manifest['scan'],
              'definitions': {'source_tokens': 'Significant source tokens excluding docstrings, comments, and structural whitespace.',
                              'normalized_tokens': 'Significant tokens after ast.unparse of the stripped AST.',
                              'ast_nodes': 'Every ast.walk node after removing module/function/class docstrings.',
                              'normalized_bytes': 'UTF-8 bytes after ast.unparse plus one newline.',
                              'raw_bytes': 'All original source bytes, including documentation.'},
              'primary': primary, 'envelope': envelope, 'candidate': candidate,
              'strictly_below': {key: candidate[key] < envelope[key] for key in FIELDS} if candidate else None,
              'strict_candidate': strict,
              'strict_variant_below': {key: strict[key] < envelope[key] for key in FIELDS} if strict else None,
              'sources': sources, 'historical_groups': groups}
    (ROOT.parent / 'results' / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ('scan', 'envelope', 'candidate', 'strictly_below')}, indent=2))
    if candidate and not all(result['strictly_below'].values()):
        raise SystemExit('The candidate does not strictly beat every comparison coordinate.')
    if strict and not all(result['strict_variant_below'].values()):
        raise SystemExit('The strict variant does not beat every comparison coordinate.')


if __name__ == '__main__':
    main()
