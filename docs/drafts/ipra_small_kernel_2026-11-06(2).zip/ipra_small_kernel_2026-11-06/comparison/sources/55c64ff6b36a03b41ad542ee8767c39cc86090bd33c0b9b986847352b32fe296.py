"""Translate certificates in either direction, checking both endpoints.

forward: exact frozen strict_shared.py syntax -> checker.py syntax.
backward: checker.py syntax -> repaired strict_shared.py syntax.
The public context and claimed conclusion are preserved literally.
"""
import argparse
import json
from pathlib import Path
import repair


def proof_forward(p):
    """Erase only the redundant use tags; all term/formula fields stay put."""
    match p:
        case [('lam' | 'pack' | 'nat') as tag, a, q]:
            return [tag, a, proof_forward(q)]
        case ['use', major, a, minor]:
            return [proof_forward(major), a, proof_forward(minor)]
        case ['use', major, minor]:
            return [proof_forward(major), proof_forward(minor)]
        case _:
            return p


def forward(data):
    repair.reference.check(data)
    g, a, p = data
    target = [g, a, proof_forward(p)]
    repair.raw.check(*target)
    if target[:2] != data[:2]:
        raise ValueError('public sequent changed')
    return target


def backward(data):
    target = repair.normalize(data)
    if target[:2] != data[:2]:
        raise ValueError('public sequent changed')
    return target


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('direction', choices=('forward', 'backward'))
    parser.add_argument('source', type=Path)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    data = json.loads(args.source.read_text(encoding='utf-8'))
    result = (forward if args.direction == 'forward' else backward)(data)
    args.destination.write_text(json.dumps(result, separators=(',', ':')) + '\n', encoding='utf-8')
    print('BOTH ENDPOINTS ACCEPTED; PUBLIC CONTEXT AND CONCLUSION UNCHANGED')


if __name__ == '__main__':
    main()
