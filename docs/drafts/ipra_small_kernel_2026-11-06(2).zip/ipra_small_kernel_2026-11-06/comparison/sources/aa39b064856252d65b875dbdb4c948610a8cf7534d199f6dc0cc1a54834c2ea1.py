"""Reproduce checker metrics, fixed proof translations, and independent audits.

Only the standard library is needed. This file is untrusted validation support;
checker.py does not import it. PDF rebuilding is a separate build.py command.
"""

import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(*arguments):
    subprocess.run([sys.executable, *arguments], cwd=ROOT, check=True)


def report_tables():
    data = json.loads((ROOT / "results/comparison.json").read_text())
    spec = importlib.util.spec_from_file_location("size_measure", ROOT / "comparison/measure.py")
    measure = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(measure)
    strict = measure.measure_bytes((ROOT / "comparison/strict_checker.py").read_bytes())
    candidate = data["candidate"]
    envelope = data["coordinatewise_envelope"]
    for key in envelope:
        if candidate[key] >= envelope[key] or strict[key] >= envelope[key]:
            raise ValueError("A claimed strict size improvement no longer holds: " + key)
    (ROOT / "results/strict_metrics.json").write_text(json.dumps(strict, indent=2) + "\n")
    values = {
        "CandidateAST": candidate["ast_nodes"],
        "CandidateTokens": candidate["source_tokens"],
        "CandidateNormalizedTokens": candidate["normalized_tokens"],
        "CandidateBytes": candidate["normalized_bytes"],
        "StrictNormalizedTokens": strict["normalized_tokens"],
        "ASTReduction": f'{data["reduction_percent"]["ast_nodes"]:.2f}',
        "TokenReduction": f'{data["reduction_percent"]["source_tokens"]:.2f}',
        "ByteReduction": f'{data["reduction_percent"]["normalized_bytes"]:.2f}',
    }
    macros = "".join("\\newcommand{\\" + key + "}{" + str(value) + "}\n"
                     for key, value in values.items())
    (ROOT / "results/metrics_macros.tex").write_text(macros)
    columns = ("ast_nodes", "source_tokens", "normalized_bytes", "raw_bytes")
    lines = [r"\begin{tabular}{lrrrr}", r"\toprule",
             r"Complete program & AST & Tokens & Norm. bytes & Raw bytes\\", r"\midrule"]
    for row in sorted(data["baselines"], key=lambda r: r["label"]):
        lines.append(row["label"] + " & " + " & ".join(str(row[k]) for k in columns) + r"\\")
    lines += [r"\midrule",
              "Current frontier & " + " & ".join(str(envelope[k]) for k in columns) + r"\\",
              "New strict control & " + " & ".join(str(strict[k]) for k in columns) + r"\\",
              r"\textbf{New primary} & " + " & ".join(r"\textbf{" + str(candidate[k]) + "}"
                                                       for k in columns) + r"\\",
              r"\bottomrule", r"\end{tabular}"]
    (ROOT / "results/comparison_table.tex").write_text("\n".join(lines) + "\n")
    audits = [json.loads((ROOT / "results" / name).read_text())
              for name in ("independent_audit.json", "strict_audit.json")]
    if any(a["failures"] for a in audits):
        raise ValueError("Independent audit has failures.")
    if [a["checker_sha256"] for a in audits] != [candidate["sha256"], strict["sha256"]]:
        raise ValueError("Audit hash does not match the measured checker.")
    summary = [r"\begin{center}", r"\begin{tabular}{lrrr}", r"\toprule",
               r"Independent audit & Checks & Certificate cases & Failures\\", r"\midrule"]
    for name, a in zip(("Primary", "Strict control"), audits):
        summary.append(f'{name} & {a["total_checks"]} & {a["certificate_cases"]} & 0' + r"\\")
    summary += [r"\bottomrule", r"\end{tabular}", r"\end{center}"]
    (ROOT / "results/validation_summary.tex").write_text("\n".join(summary) + "\n")


def main():
    (ROOT / "results").mkdir(exist_ok=True)
    run("comparison/measure.py", "--candidate", "checker.py", "--out", "results/comparison.json")
    run("validation/run_fixtures.py", "--output", "results/fixtures.json")
    run("validation/independent_audit.py", "--checker", "checker.py",
        "--output", "results/independent_audit.json", "--corpus", "examples")
    run("validation/independent_audit.py", "--checker", "comparison/strict_checker.py",
        "--strict-witness", "--output", "results/strict_audit.json", "--corpus", "examples")
    report_tables()
    print("All recorded comparisons and validation suites reproduced successfully.")


if __name__ == "__main__":
    main()
