"""Recheck both directions of translation from the frozen predecessor.

All paths are relative to this package. Translations are untrusted and both
checkers recheck them. Contexts and goals agree; proof trees may eta-expand.
"""

import hashlib
import importlib.util
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    source_path = HERE / "reference/checker.py"
    source_hash = hashlib.sha256(source_path.read_bytes()).hexdigest()
    if source_hash != "c8ccc683ddd50d18ab5316257cdeaacf2b0a788112c36a844c60d6acc3e80a55":
        raise ValueError("Frozen predecessor changed")
    source = load(source_path, "curried_predecessor")
    target = load(ROOT / "checker.py", "candidate")
    translator = load(HERE / "translate_curried.py", "translator")
    manifest = json.loads((HERE / "reference/corpus_provenance.json").read_text())
    report = {"source_sha256": source_hash,
              "candidate_sha256": hashlib.sha256((ROOT / "checker.py").read_bytes()).hexdigest(),
              "count": len(manifest["records"]), "passed": 0, "failed": [], "files": []}
    for record in manifest["records"]:
        try:
            path = HERE / "reference/corpus" / record["file"]
            contents = path.read_bytes()
            if hashlib.sha256(contents).hexdigest() != record["translated_sha256"]:
                raise ValueError("Frozen predecessor certificate changed")
            old = json.loads(contents)
            new = translator.to_fused(old, source, target)
            reverse = translator.to_curried(new, source, target)
            if not old[:2] == new[:2] == reverse[:2]:
                raise ValueError("Translation changed the sequent")
            frozen = HERE / "corpus" / record["file"]
            if new != json.loads(frozen.read_text()):
                raise ValueError("Translation differs from the frozen target certificate")
            report["passed"] += 1
            report["files"].append({"file": record["file"],
                                    "target_sha256": hashlib.sha256(frozen.read_bytes()).hexdigest()})
        except Exception as error:
            report["failed"].append({"file": record["file"], "error": repr(error)})

    matrices = [["=", 0, 1], ["=", ["s", 0], ["s", 1]],
                ["pi", ["=", 0, 2], ["=", 0, 2]], ["ex", ["=", 0, 1]]]
    report["non_lambda_numerical_steps"] = []
    for matrix in matrices:
        guard = translator.numerical_guard(matrix, source)
        premise = ["pi", guard, source.subst(matrix, [["s", 0], 0])]
        proof = ["nat", matrix, premise]
        data = [[premise], source.infer(proof, [premise]), proof]
        new = translator.to_fused(data, source, target)
        reverse = translator.to_curried(new, source, target)
        if reverse[:2] != data[:2]:
            raise ValueError("Non-lambda numerical premise changed its sequent")
        report["non_lambda_numerical_steps"].append({"matrix": matrix, "passed": True})

    output = ROOT / "results/replay.json"
    output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "files"}, indent=2))
    if report["failed"] or report["passed"] != report["count"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
