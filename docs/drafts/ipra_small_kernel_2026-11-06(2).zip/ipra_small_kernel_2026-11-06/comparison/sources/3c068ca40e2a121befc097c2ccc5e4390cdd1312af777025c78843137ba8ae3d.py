"""Measure the complete candidate and six unchanged archived baselines.

No measured program is executed. Python's AST parser and tokenizer are the
only readers of candidate source. Optional --archives repeats the wider scan
from the six original ZIPs; those ZIPs are not needed for the main comparison.
"""

import argparse
import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize
import zipfile


ROOT = Path(__file__).resolve().parent
FIELDS = ("ast_nodes", "source_tokens", "normalized_tokens",
          "normalized_bytes", "raw_bytes")
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}


def count_tokens(source, omitted=()):
    return sum(token.type not in IGNORED and not any(
        start <= token.start and token.end <= end for start, end in omitted
    ) for token in tokenize.generate_tokens(io.StringIO(source).readline))


def measure_bytes(data):
    source = data.decode("utf-8")
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef,
                             ast.ClassDef)) and node.body:
            first = node.body[0]
            if (isinstance(first, ast.Expr)
                    and isinstance(first.value, ast.Constant)
                    and isinstance(first.value.value, str)):
                spans.append(((first.lineno, first.col_offset),
                              (first.end_lineno, first.end_col_offset)))
                node.body = node.body[1:]
    normalized = ast.unparse(tree) + "\n"
    return {
        "sha256": hashlib.sha256(data).hexdigest(),
        "normalized_sha256": hashlib.sha256(normalized.encode()).hexdigest(),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "source_tokens": count_tokens(source, spans),
        "normalized_tokens": count_tokens(normalized),
        "normalized_bytes": len(normalized.encode("utf-8")),
        "raw_bytes": len(data),
        "top_level_functions": [node.name for node in tree.body
                                if isinstance(node, ast.FunctionDef)],
        "top_level_imports": [ast.unparse(node) for node in tree.body
                              if isinstance(node, (ast.Import, ast.ImportFrom))],
    }


def scan_archives(manifest, directory):
    """Reproduce the frozen scan; source copies remain inside the input ZIPs."""
    all_sources = set()
    selected = {}
    python_occurrences = 0
    small_sources = {}
    for item in manifest["baselines"]:
        archive_path = directory / item["archive"]
        data = archive_path.read_bytes()
        if hashlib.sha256(data).hexdigest() != item["archive_sha256"]:
            raise ValueError("Archive SHA-256 mismatch: " + str(archive_path))
        git_blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        if git_blob != item["archive_git_blob_sha1"]:
            raise ValueError("Archive Git blob mismatch: " + str(archive_path))
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            for member in archive.namelist():
                if not member.endswith(".py"):
                    continue
                source = archive.read(member)
                result = measure_bytes(source)
                python_occurrences += 1
                digest = result["sha256"]
                all_sources.add(digest)
                occurrence = {"archive": item["archive"], "member": member}
                if result["ast_nodes"] < 712:
                    small_sources.setdefault(digest, {**result, "representative": occurrence})
                if {"infer", "check"} <= set(result["top_level_functions"]):
                    selected.setdefault(digest, {**result, "occurrences": []})
                    selected[digest]["occurrences"].append(occurrence)
    return {
        "snapshot_commit": manifest["snapshot_commit"],
        "all_python_occurrences": python_occurrences,
        "all_unique_python_hashes": len(all_sources),
        "infer_check_occurrences": sum(len(row["occurrences"]) for row in selected.values()),
        "infer_check_unique_hashes": len(selected),
        "selection": "Top-level FunctionDef names include both infer and check; deduplication by exact source SHA-256. This filter is an inventory, not a soundness or completeness test.",
        "sources": sorted(selected.values(), key=lambda row: (row["ast_nodes"], row["sha256"])),
        "sources_below_712_ast_nodes": sorted(small_sources.values(), key=lambda row: row["ast_nodes"]),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path,
                        help="Whole standalone candidate checker, including its JSON/CLI wrapper")
    parser.add_argument("--out", type=Path, default=ROOT / "measured.json")
    parser.add_argument("--archives", type=Path,
                        help="Optional directory containing the six original ZIP files")
    parser.add_argument("--scan-out", type=Path, default=ROOT / "rescanned_inventory.json")
    args = parser.parse_args()
    manifest = json.loads((ROOT / "manifest.json").read_text())
    rows = []
    for item in manifest["baselines"]:
        metrics = measure_bytes((ROOT / item["source_file"]).read_bytes())
        if (metrics["sha256"] != item["source_sha256"]
                or metrics["raw_bytes"] != item["source_bytes"]):
            raise ValueError("Frozen baseline mismatch: " + item["source_file"])
        rows.append({"label": item["label"], "source_file": item["source_file"],
                     "archive": item["archive"], **metrics})
    envelope = {field: min(row[field] for row in rows) for field in FIELDS}
    report = {
        "snapshot_commit": manifest["snapshot_commit"],
        "python_version": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "definitions": {
            "ast_nodes": "All nodes in ast.walk after removing actual module/function/class docstrings.",
            "source_tokens": "Original significant Python tokens, excluding docstrings, comments, and whitespace/control-layout tokens.",
            "normalized_tokens": "Significant tokens of ast.unparse(stripped_ast) plus one newline.",
            "normalized_bytes": "UTF-8 bytes of ast.unparse(stripped_ast) plus one newline.",
            "raw_bytes": "Exact original source bytes, including comments and documentation.",
        },
        "baselines": rows,
        "coordinatewise_envelope": envelope,
        "qualification": "A finite source-size comparison, with all application-specific acceptance code counted. It does not prove absolute minimality or certify historical mathematical claims.",
    }
    if args.candidate:
        candidate = measure_bytes(args.candidate.read_bytes())
        report["candidate"] = {"path": str(args.candidate), **candidate}
        report["at_or_below_envelope"] = {field: candidate[field] <= envelope[field]
                                           for field in FIELDS}
        report["strictly_below_envelope"] = {field: candidate[field] < envelope[field]
                                             for field in FIELDS}
        report["reduction_percent"] = {field: 100 * (1 - candidate[field] / envelope[field])
                                        for field in FIELDS}
    if args.archives:
        scan = scan_archives(manifest, args.archives)
        args.scan_out.parent.mkdir(parents=True, exist_ok=True)
        args.scan_out.write_text(json.dumps(scan, indent=2) + "\n")
        report["rescan_summary"] = {key: scan[key] for key in (
            "all_python_occurrences", "all_unique_python_hashes",
            "infer_check_occurrences", "infer_check_unique_hashes")}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2) + "\n")
    print("Complete archived baselines:")
    for row in rows:
        print(row["label"] + ": " + ", ".join(f"{field}={row[field]}" for field in FIELDS))
    print("Envelope: " + json.dumps(envelope, sort_keys=True))
    if args.candidate:
        print("Candidate: " + json.dumps({field: candidate[field] for field in FIELDS}, sort_keys=True))
        print("At or below: " + json.dumps(report["at_or_below_envelope"], sort_keys=True))
    if args.archives:
        print("Wider inventory: " + json.dumps(report["rescan_summary"], sort_keys=True))
    print("Wrote " + str(args.out))


if __name__ == "__main__":
    main()
