"""Independent rule replay and exact source-proof translation audit."""
from collections import Counter
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path

from rule_oracle import check as oracle_check, as_local
from translate_archived import document

ROOT = Path(__file__).resolve().parent


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def canonical(data):
    return (json.dumps(data, separators=(',', ':'), sort_keys=True) + '\n').encode()


def source_accept(module, data):
    arity = len(inspect.signature(module.check).parameters)
    return module.check(*data) if arity == 3 else module.check(data)


def run(candidate, destination):
    manifest = json.loads((ROOT / 'source_manifest.json').read_text())
    sources = {}
    for sha, entry in manifest['sources'].items():
        path = ROOT / entry['file']
        if hashlib.sha256(path.read_bytes()).hexdigest() != sha:
            raise ValueError('Source hash mismatch: ' + sha)
        sources[sha] = load(path, 'frozen_' + sha)
    strict = sources[manifest['baseline_local_sha256']]
    verdicts, outputs, sequents = {}, {}, set()
    records, failures = [], []
    counts = Counter()
    destination.mkdir(parents=True, exist_ok=True)
    for record in manifest['records']:
        try:
            raw = (ROOT / record['file']).read_bytes()
            if hashlib.sha256(raw).hexdigest() != record['sha256']:
                raise ValueError('Original certificate hash mismatch')
            data = json.loads(raw)
            sha = record['source_checker_sha256']
            config = manifest['sources'][sha]
            source = sources[sha]
            key = (sha, record['sha256'])
            if key not in verdicts:
                source_accept(source, data)
                verdicts[key] = True
            translated = document(data, source, config['local_nat'], config['uniform'], config['flat'])
            goal, proof, *g = translated
            old_goal, old_proof, *old_g = data if config['flat'] else [data[1], data[2], *data[0]]
            if g != old_g or goal != old_goal:
                raise ValueError('Translation changed the sequent')
            digest = hashlib.sha256(canonical(translated)).hexdigest()
            sequent = hashlib.sha256(canonical([g, goal])).hexdigest()
            if digest not in outputs:
                candidate.check(translated)
                rules, normalized = oracle_check(translated)
                counts.update(rules)
                strict.check([g, goal, as_local(normalized[1])])
                target = destination / (digest + '.json')
                target.write_bytes(canonical(translated))
                outputs[digest] = {'file': target.name, 'sha256': digest,
                                   'sequent_sha256': sequent, 'rules': dict(rules)}
            sequents.add(sequent)
            records.append({**record, 'translated_sha256': digest, 'sequent_sha256': sequent})
        except Exception as e:
            failures.append({'record': record, 'error': repr(e)})
    return {
        'source_checker_count': len(sources),
        'original_certificate_occurrences': len(manifest['records']),
        'source_acceptance_checks': len(verdicts),
        'distinct_translated_certificates': len(outputs),
        'distinct_sequents': len(sequents),
        'independent_inference_occurrences': sum(counts.values()),
        'independent_rule_counts': dict(counts),
        'strict_local_replays': len(outputs),
        'failures': failures,
        'outputs': list(outputs.values()),
        'records': records,
    }


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=ROOT / 'replay_results.json')
    args = parser.parse_args()
    result = run(load(args.checker, 'candidate'), ROOT / 'translated')
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('records', 'outputs')}, indent=2))
    if result['failures']:
        raise SystemExit(1)
