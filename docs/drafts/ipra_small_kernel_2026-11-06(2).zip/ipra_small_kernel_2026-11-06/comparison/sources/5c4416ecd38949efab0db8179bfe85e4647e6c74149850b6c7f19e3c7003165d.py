"""Finite independent validation; this is not a formal soundness proof.

Checks frozen-source replay, an independent named-variable rule interpreter,
targeted type/scope/admissibility boundaries, nested generated derivations,
2,000 independent substitution comparisons, and the actual JSON CLI under
ordinary and optimized Python. No candidate helper is used by the oracle.
"""
from collections import Counter
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile

from named_syntax import subst as named_subst, well_formed
from replay import load, run as replay_run, canonical
from rule_oracle import check as oracle_check, infer as oracle_infer, as_local

ROOT = Path(__file__).resolve().parent


def accepts(function, data):
    try:
        function(data)
        return True
    except Exception:
        return False


def term(rng, depth):
    if depth == 0 or rng.randrange(5) < 2:
        return rng.choice([-1, 0, 1, 2, 3, 5])
    if rng.randrange(2):
        return ['s', term(rng, depth - 1)]
    return ['r', term(rng, depth - 1), term(rng, depth - 1), term(rng, depth - 1)]


def formula(rng, depth):
    if depth == 0 or rng.randrange(3) == 0:
        return ['=', term(rng, 3), term(rng, 3)]
    if rng.randrange(2):
        return ['ex', formula(rng, depth - 1)]
    return ['pi', formula(rng, depth - 1), formula(rng, depth - 1)]


def substitution_checks(candidate, count=2000):
    rng = random.Random(11062026)
    records, failures, families = [], [], Counter()
    for index in range(count):
        is_formula = bool(rng.randrange(2))
        expression = formula(rng, 3) if is_formula else term(rng, 4)
        family = index % 8
        if family == 0:
            env, depth = (1,), 0
        elif family == 1:
            env, depth = (0,), 0
        elif family == 2:
            env, depth = [-1, -1], 0
        elif family == 3:
            env, depth = [term(rng, 3), -1], 0
        elif family == 4:
            env, depth = [-1, 0], 0
        elif family == 5:
            env, depth = [['s', 0], 0], 0
        elif family == 6:
            env, depth = [term(rng, 3), term(rng, 3), -2], 0
        else:
            env, depth = [term(rng, 3), -1], rng.randrange(1, 5)
        expected = named_subst(expression, env, depth, is_formula)
        actual = candidate.subst(expression, env, depth, is_formula)
        families[str(family)] += 1
        if expected != actual:
            failures.append({'index': index, 'expression': expression, 'env': env,
                             'depth': depth, 'formula': is_formula,
                             'expected': expected, 'actual': actual})
    return {'comparisons': count, 'families': dict(families), 'failures': failures,
            'method': 'Fresh-name substitution versus the candidate implementation; each operation family includes both formula and term syntax with nested recursion and quantifier binders.'}


def targeted_cases():
    cases = []
    def add(name, data, expected):
        cases.append((name, data, expected))
    def theorem(name, p, g=()):
        a, _ = oracle_infer(p, list(g))
        data = [a, p, *g]
        add(name, data, True)
        return data

    T = ['=', -1, -1]
    V = ['=', 0, 0]
    r = ['r', -1, -1, -1]
    refl = [r, ['=', 0, -1], r]
    theorem('derived_reflexivity', refl)
    theorem('recursion_zero', r)
    theorem('recursion_successor_state', ['r', ['s', 0], 1, ['s', 0]])
    theorem('recursion_successor_counter', ['r', ['s', 0], 1, ['s', 1]])
    theorem('recursion_successor_nested_binder', ['r', ['s', 0], 1, ['r', 1, 0, ['s', 3]]])
    theorem('universal_identity', ['lam', V, 0])
    theorem('existential_witness', ['pack', 0, 0])
    theorem('nested_introductions', ['lam', ['ex', V], ['pack', 0, ['lam', ['pi', V, T], -1]]])
    theorem('outer_parameter_raised', ['lam', V, 0], [['=', 0, -1]])
    add('outer_parameter_captured', [['pi', V, ['=', 0, -1]], ['lam', V, 0], ['=', 0, -1]], False)
    add('pack_witness_not_raised', [['ex', ['=', 0, 0]], ['pack', 0, 0]], False)
    theorem('existential_external_parameter', [0, V, 1], [['ex', ['=', 0, 1]], V])
    add('existential_eigenvariable_escape', [['=', 0, -1], [0, ['=', 0, -1], 1], ['ex', ['=', 0, -1]]], False)
    add('existential_wrong_external_parameter', [['=', 1, 1], [0, ['=', 1, 1], 1], ['ex', ['=', 0, 1]], V], False)
    template = ['ex', ['=', 0, 1]]
    equality = ['=', 0, 1]
    theorem('equality_transport_under_exists', [0, template, 1], [equality, named_subst(template, [0, -1])])
    add('equality_transport_captures_binder', [['ex', ['=', 1, 0]], [0, template, 1], equality, template], False)
    theorem('negative_assumption_selector', -1, [T])
    theorem('boolean_assumption_selector_false', False, [T])
    theorem('boolean_assumption_selector_true', True, [V, T])
    add('selector_out_of_range', [T, 1, T], False)
    add('selector_negative_out_of_range', [T, -2, T], False)
    add('selector_float_not_index', [T, 0.0, T], False)
    add('selector_string_not_index', [T, '0', T], False)
    for label, P in [('equation', ['=', 0, 1]), ('compound', ['ex', ['=', 0, 1]])]:
        base = named_subst(P, [-1, 0])
        successor = named_subst(P, [['s', 0], 0])
        h = P if P[0] == '=' else base
        theorem(label + '_numerical_rule', ['nat', P, [0, 0, 1]], [['pi', h, successor]])
        theorem(label + '_numerical_rule_nested', ['lam', ['pi', h, successor], ['nat', P, [0, 0, 1]]])
        add(label + '_numerical_wrong_successor', [['pi', base, P], ['nat', P, 0], ['pi', h, successor]], False)
        if P[0] != '=':
            add('compound_induction_hypothesis_forbidden', [['pi', base, P], ['nat', P, [0, 0, 1]], ['pi', P, successor]], False)
    bad = [None, True, False, 0.0, -1.0, -2, [], {}, ['s'], ['s', -1, -1], ['=', -1, -1], ['r', -1, -1], ['bad', -1]]
    for i, value in enumerate(bad):
        theorem('vacuous_witness_payload_' + str(i), [0, value, 1], [['pi', T, T], T])
        add('used_witness_antecedent_' + str(i), [T, [0, value, 1], ['pi', V, T], T], False)
        add('used_witness_consequent_' + str(i), [V, [0, value, 1], ['pi', T, V], T], False)
        add('recursion_unused_body_' + str(i), [T, ['r', -1, -1, value]], False)
        add('recursion_unused_initial_' + str(i), [T, ['r', ['s', -1], value, 1]], False)
        add('recursion_counter_' + str(i), [T, ['r', value, -1, -1]], False)
        if well_formed(value):
            theorem('valid_extra_context_' + str(i), 0, [T, value])
            theorem('valid_constant_template_' + str(i), [0, value, 1], [T, T])
        else:
            add('malformed_unused_context_' + str(i), [T, 0, T, value], False)
            add('malformed_equality_template_' + str(i), [T, [0, value, 1], T, T], False)
    for value in [True, False, 0.0, -1.0]:
        # Python structural equality aliases booleans/floats with integers;
        # mathematical formation must reject them before final comparison.
        good = ['=', int(value), int(value)]
        add('numeric_alias_goal_' + repr(value), [['=', value, value], 0, good], False)
        add('numeric_alias_hypothesis_' + repr(value), [good, 0, ['=', value, value]], False)
        add('numeric_alias_lam_guard_' + repr(value), [['pi', good, good], ['lam', ['=', value, value], 0]], False)
    for name, p in [('extra_argument', ['r', -1, -1, -1, -1]),
                    ('missing_argument', ['r', -1, -1]),
                    ('counter_non_successor_rec', ['r', ['r', -1, -1, -1], -1, -1]),
                    ('unknown_application_tag', ['use', 0, T, 0]),
                    ('missing_application_argument', [0, T]),
                    ('extra_application_argument', [0, T, 0, 0])]:
        add(name, [T, p, T], False)
    return cases


def generated_cases(count=128):
    rng = random.Random(20261106)
    result = []
    for i in range(count):
        a, b, t = formula(rng, 2), formula(rng, 2), term(rng, 3)
        kind = i % 8
        if kind == 0:
            p, g = ['lam', a, ['lam', b, -1]], []
        elif kind == 1:
            p, g = ['pack', t, ['lam', a, 0]], []
        elif kind == 2:
            r = ['r', -1, t, term(rng, 3)]
            p, g = r, []
        elif kind == 3:
            p, g = ['r', ['s', t], term(rng, 3), term(rng, 3)], []
        elif kind == 4:
            principal = ['pi', a, b]
            p, g = [0, t, 1], [principal, named_subst(a, [t, -1])]
        elif kind == 5:
            s = term(rng, 3)
            p, g = [0, a, 1], [['=', s, t], named_subst(a, [s, -1])]
        elif kind == 6:
            p, g = [0, b, 1], [['ex', a], b]
        else:
            P = a
            base = named_subst(P, [-1, 0])
            h = P if P[0] == '=' else base
            p, g = ['nat', P, [0, 0, 1]], [['pi', h, named_subst(P, [['s', 0], 0])]]
        goal, _ = oracle_infer(p, g)
        result.append(('generated_' + str(i), [goal, p, *g], True))
    return result


def boundary_checks(candidate, strict):
    cases = targeted_cases() + generated_cases()
    records, failures = [], []
    counts = Counter()
    for name, data, expected in cases:
        actual = accepts(candidate.check, data)
        independent = accepts(oracle_check, data)
        baseline = None
        if independent:
            rules, normalized = oracle_check(data)
            goal, p, *g = normalized
            baseline = accepts(strict.check, [g, goal, as_local(p)])
            counts.update(rules)
        passed = actual == independent == expected and (baseline is not False)
        records.append({'name': name, 'expected': expected, 'candidate': actual,
                        'independent': independent, 'strict_baseline': baseline,
                        'passed': passed, 'document': data})
        if not passed:
            failures.append(records[-1])
    return {'targeted_cases': len(targeted_cases()), 'generated_nested_cases': 128,
            'accepted': sum(x[2] for x in cases),
            'rejected': sum(not x[2] for x in cases),
            'independent_rule_counts': dict(counts), 'failures': failures,
            'records': records}


def cli_checks(checker_path, boundaries):
    names = ['derived_reflexivity', 'existential_eigenvariable_escape',
             'compound_induction_hypothesis_forbidden', 'vacuous_witness_payload_3',
             'numeric_alias_goal_False', 'numeric_alias_goal_0.0',
             'recursion_unused_body_1', 'recursion_unused_initial_1']
    selected = [r for r in boundaries['records'] if r['name'] in names]
    results = []
    with tempfile.TemporaryDirectory() as directory:
        for r in selected:
            p = Path(directory) / (r['name'] + '.json')
            p.write_bytes(canonical(r['document']))
            for optimized in (False, True):
                command = [sys.executable] + (['-O'] if optimized else []) + [str(checker_path), str(p)]
                process = subprocess.run(command, capture_output=True, text=True, timeout=15)
                passed = ((process.returncode == 0) == r['expected'] and
                          process.stdout.strip() == ('ACCEPT' if r['expected'] else 'REJECT'))
                results.append({'name': r['name'], 'optimized': optimized,
                                'expected': r['expected'], 'exit_code': process.returncode,
                                'stdout': process.stdout.strip(), 'passed': passed})
    return {'checks': len(results), 'failures': [r for r in results if not r['passed']], 'records': results}


def main():
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=ROOT / 'validation_results.json')
    args = parser.parse_args()
    checker = args.checker.resolve()
    candidate = load(checker, 'audited_candidate')
    manifest = json.loads((ROOT / 'source_manifest.json').read_text())
    sha = manifest['baseline_local_sha256']
    strict = load(ROOT / manifest['sources'][sha]['file'], 'strict_local')
    replay = replay_run(candidate, ROOT / 'translated')
    substitution = substitution_checks(candidate)
    boundaries = boundary_checks(candidate, strict)
    cli = cli_checks(checker, boundaries)
    result = {'checker_sha256': hashlib.sha256(checker.read_bytes()).hexdigest(),
              'python_version': sys.version.split()[0],
              'snapshot_commit': manifest['snapshot_commit'],
              'status': 'passed' if not any(x['failures'] for x in [replay, substitution, boundaries, cli]) else 'failed',
              'replay': replay, 'substitution': substitution, 'boundaries': boundaries, 'cli': cli,
              'qualification': 'Finite independently implemented evidence. The named oracle imports no candidate code; only the explicit substitution comparison calls candidate.subst. Counts cover different, partly overlapping validation categories and are not summed as independent theorem proofs.'}
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    compact = {k: v for k, v in result.items() if k not in ('replay', 'boundaries', 'cli')}
    compact.update({name: {k: v for k, v in block.items() if k not in ('outputs', 'records')}
                    for name, block in [('replay', replay), ('boundaries', boundaries), ('cli', cli)]})
    print(json.dumps(compact, indent=2))
    if result['status'] != 'passed':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
