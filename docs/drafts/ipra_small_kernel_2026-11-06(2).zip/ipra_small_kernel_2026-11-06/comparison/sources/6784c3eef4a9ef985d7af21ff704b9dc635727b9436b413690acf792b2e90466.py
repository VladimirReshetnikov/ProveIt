"""Portable certificate translations and finite validation for the iPRA bundle.

This is untrusted reproduction support. Neither checker imports this file.
Defaults assume this script is installed as validation/roundtrip.py.
Every input and output path can also be specified on the command line.
"""

import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROVENANCE = {
    'repository': 'VladimirReshetnikov/ProveIt',
    'snapshot_commit': '0a86fcbd7c5e0d6a541291b4ac06c7dc77989161',
    'archive': 'docs/drafts/ipra_shared_transition_2026-11-06.zip',
    'archive_url': 'https://github.com/VladimirReshetnikov/ProveIt/blob/0a86fcbd7c5e0d6a541291b4ac06c7dc77989161/docs/drafts/ipra_shared_transition_2026-11-06.zip',
    'archive_sha256': 'dff281c2701ec77501078978f9f80ed704e67d6562df27f435f9334f9501f89c',
    'archive_git_blob_sha1': '557603a4a3398a67a737f052bc419d39952cf0f0',
    'reference_member': 'ipra_shared_transition_2026-11-06/checker.py',
    'reference_sha256': '85fdff0eade03c0c74e864a083f4ee2ecea79b78a8a64656c16cfc0d958f40f2',
    'fixture_manifest_member': 'ipra_shared_transition_2026-11-06/validation/manifest.json',
    'fixture_records_sha256': 'e4db816f538a6bf4e84a7f54957073374a8b61fd3971e3d81f32e3303218dcc7',
    'attribution': 'The reference checker and 256 frozen fixtures are unchanged files from the supplied shared-transition draft. The goal-directed translators and probes in this script are new untrusted validation support.',
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def encode(value):
    return (json.dumps(value, ensure_ascii=True, separators=(',', ':')) + '\n').encode('utf-8')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def reference_accepts(reference, data):
    try:
        return reference.check(data) is True
    except Exception:
        return False


def goal_accepts(checker, data):
    """Mirror the complete CLI boundary, not merely the internal check call."""
    try:
        a, p, *g = data
        for b in g:
            checker.subst(b)
        checker.check(a, p, g)
        return True
    except Exception:
        return False


def uses_slot(a, scopes, depth=0, formula=True):
    """Occurrence test for the first free numerical slot, through all binders."""
    if type(a) is int:
        return a == depth
    tag, *parts = a
    return any(uses_slot(t, scopes, depth + width, width == 1)
               for t, width in zip(parts, scopes[formula][tag], strict=True))


def to_goal(reference, p, g, strict=False, repairs=None):
    """Translate an accepted shared-transition proof, retaining its sequent.

    Demand translation retains all witness payloads. Strict translation changes
    a malformed Pi witness to zero only after verifying that its slot is absent
    from both components of the proved major formula.
    """
    match p:
        case [('lam' | 'nat' | 'pack') as tag, a, q]:
            h = ['=', 0, reference.subst(a, formula=False)] if tag == 'pack' else a
            base = reference.subst(h, [-1, 0] if tag == 'nat' else (0,))
            h = h if h[0] == '=' else base
            local = [*map(reference.subst, g), h]
            q = to_goal(reference, q, local, strict, repairs)
            return ['pack', a, q] if tag == 'pack' else [tag, q]
        case ['use', p, *args]:
            major = reference.infer(p, g)
            tag, *parts = major
            r = to_goal(reference, p, g, strict, repairs)
            if tag == 'ex':
                (q,) = args
                local = [*map(reference.subst, g), *parts]
                return ['use', major, r, to_goal(reference, q, local, strict, repairs)]
            t, q = args
            if strict and tag == 'pi':
                try:
                    reference.subst(t, formula=False)
                except Exception:
                    require(not any(uses_slot(a, reference.SCOPES) for a in parts),
                            'Malformed witness occurs in a purportedly valid source proof')
                    t = -1
                    if repairs is not None:
                        repairs.append('vacuous_pi_witness')
            return ['use', major, r, t, to_goal(reference, q, g, strict, repairs)]
        case ['r', _, _, _]:
            return 'r'
        case _:
            return p


def to_reference(reference, a, p, g):
    """Reconstruct a shared-transition proof from an accepted goal certificate."""
    match a, p:
        case ['pi', h, b], [('lam' | 'nat') as rule, q]:
            if rule == 'nat':
                local = [*map(reference.subst, g), b if b[0] == '=' else h]
                step = reference.subst(b, [['s', 0], 0])
                return ['nat', b, to_reference(reference, step, q, local)]
            local = [*map(reference.subst, g), h]
            return ['lam', h, to_reference(reference, b, q, local)]
        case ['ex', b], ['pack', t, q]:
            local = [*map(reference.subst, g), ['=', 0, reference.subst(t, formula=False)]]
            return ['pack', t, to_reference(reference, b, q, local)]
        case _, ['use', major, r, *args]:
            restored = to_reference(reference, major, r, g)
            tag, *parts = major
            if tag == 'ex':
                (q,) = args
                local = [*map(reference.subst, g), *parts]
                return ['use', restored, to_reference(reference, reference.subst(a), q, local)]
            t, q = args
            b, _ = (reference.subst(t, [v, -1]) if tag == '='
                    else reference.subst(v, [t, -1]) for v in parts)
            return ['use', restored, t, to_reference(reference, b, q, g)]
        case ['=', r, _], 'r':
            return r
        case _:
            return p


def same_statement(source, goal_certificate):
    g, a, _ = source
    b, _, *h = goal_certificate
    return encode([g, a]) == encode([h, b])


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(encode(data))


def probes():
    """Direct source-independent checks of the goal certificate boundary."""
    truth = ['=', -1, -1]
    falsehood = ['=', -1, ['s', -1]]
    constant_major = ['pi', truth, truth]
    dependent_major = ['pi', ['=', 0, 0], ['=', 0, 0]]
    existential = ['ex', ['=', 0, -1]]
    return [
        {'name': 'vacuous_malformed_witness',
         'data': [truth, ['use', constant_major, 0, {'unused': 'invalid'}, 1], constant_major, truth],
         'demand': True, 'strict': False},
        {'name': 'false_computation', 'data': [falsehood, 'r'], 'demand': False, 'strict': False},
        {'name': 'absent_hypothesis', 'data': [falsehood, 0], 'demand': False, 'strict': False},
        {'name': 'wrong_introduction_goal', 'data': [truth, ['lam', 0]], 'demand': False, 'strict': False},
        {'name': 'malformed_existential_witness',
         'data': [['ex', ['=', 0, 0]], ['pack', {'bad': 1}, 0]], 'demand': False, 'strict': False},
        {'name': 'false_induction_step',
         'data': [['pi', truth, ['=', 0, 0]], ['nat', 0]], 'demand': False, 'strict': False},
        {'name': 'boolean_term', 'data': [truth, 0, ['=', False, -1]], 'demand': False, 'strict': False},
        {'name': 'float_term', 'data': [truth, 0, ['=', 0.0, -1]], 'demand': False, 'strict': False},
        {'name': 'invalid_existential_branch',
         'data': [truth, ['use', existential, 0, 0], existential], 'demand': False, 'strict': False},
        {'name': 'eigenvariable_escape',
         'data': [['=', 0, -1], ['use', existential, 0, 0], existential], 'demand': False, 'strict': False},
        {'name': 'malformed_used_witness',
         'data': [truth, ['use', dependent_major, 0, {'bad': 1}, 0], dependent_major],
         'demand': False, 'strict': False},
    ]


def cli_result(checker, certificate, optimize=False):
    command = [sys.executable, *(['-O'] if optimize else []), str(checker), str(certificate)]
    result = subprocess.run(command, capture_output=True, text=True)
    if result.returncode == 0 and result.stdout == 'ACCEPT\n' and result.stderr == '':
        return True
    require(result.returncode != 0 and result.stdout == 'REJECT\n' and result.stderr == '',
            'Unexpected CLI behavior: ' + repr((command, result.returncode, result.stdout, result.stderr)))
    return False


def run(args):
    require(digest(args.reference.read_bytes()) == PROVENANCE['reference_sha256'],
            'Reference checker differs from the frozen shared-transition source')
    manifest = json.loads(args.manifest.read_text(encoding='utf-8'))
    entries = manifest['fixtures']
    require(digest(encode(entries)) == PROVENANCE['fixture_records_sha256'],
            'Frozen fixture records differ from their source provenance')
    require(len(entries) == 256, 'Expected exactly 256 frozen fixtures')
    require({Path(e['file']).name for e in entries} == {p.name for p in args.fixtures.glob('*.json')},
            'Fixture directory and frozen manifest disagree')
    reference = load('roundtrip_reference', args.reference)
    demand = load('roundtrip_demand', args.checker)
    strict = load('roundtrip_strict', args.strict_checker)
    rows = []
    example_paths = []
    accepted = 0
    repaired_certificates = 0
    repairs_total = 0
    strict_unnormalized_accepts = 0
    for entry in entries:
        filename = Path(entry['file']).name
        path = args.fixtures / filename
        raw = path.read_bytes()
        require(digest(raw) == entry['sha256'], 'Changed source fixture: ' + filename)
        source = json.loads(raw)
        source_ok = reference_accepts(reference, source)
        require(source_ok == entry['expected']['primary'], 'Reference result changed: ' + filename)
        row = {'name': entry['name'], 'source_sha256': entry['sha256'], 'source_accepted': source_ok}
        if source_ok:
            accepted += 1
            g, a, p = source
            demand_data = [a, to_goal(reference, p, g), *g]
            require(same_statement(source, demand_data), 'Demand translation changed statement: ' + filename)
            require(goal_accepts(demand, demand_data), 'Demand translation rejected: ' + filename)
            demand_back = [g, a, to_reference(reference, a, demand_data[1], g)]
            require(encode(demand_back[:2]) == encode(source[:2]), 'Demand return changed statement: ' + filename)
            require(reference_accepts(reference, demand_back), 'Demand return rejected: ' + filename)
            strict_unnormalized = goal_accepts(strict, demand_data)
            require(strict_unnormalized == entry['expected']['strict'],
                    'Strict handling of original witness payloads changed: ' + filename)
            strict_unnormalized_accepts += strict_unnormalized
            repairs = []
            strict_data = [a, to_goal(reference, p, g, strict=True, repairs=repairs), *g]
            require(same_statement(source, strict_data), 'Strict translation changed statement: ' + filename)
            require(goal_accepts(strict, strict_data), 'Strict translation rejected: ' + filename)
            strict_back = [g, a, to_reference(reference, a, strict_data[1], g)]
            require(encode(strict_back[:2]) == encode(source[:2]), 'Strict return changed statement: ' + filename)
            require(reference_accepts(reference, strict_back), 'Strict return rejected: ' + filename)
            require(goal_accepts(demand, strict_data), 'Demand rejected canonical strict proof: ' + filename)
            repaired_certificates += bool(repairs)
            repairs_total += len(repairs)
            write_json(args.corpus / filename, demand_data)
            write_json(args.strict_corpus / filename, strict_data)
            if filename.startswith('example_'):
                example_path = args.examples / filename[len('example_'):]
                write_json(example_path, strict_data)
                example_paths.append(example_path)
            row.update({
                'demand_sha256': digest(encode(demand_data)),
                'demand_return_sha256': digest(encode(demand_back)),
                'strict_accepted_before_normalization': strict_unnormalized,
                'strict_sha256': digest(encode(strict_data)),
                'strict_return_sha256': digest(encode(strict_back)),
                'repaired_vacuous_witnesses': len(repairs),
                'exact_statement_preserved': True,
            })
        rows.append(row)
    require(accepted == 194, 'Expected 194 accepted source fixtures')
    require(len(example_paths) == 18, 'Expected 18 inherited examples')
    probe_rows = []
    cli_examples = 0
    cli_probes = 0
    with tempfile.TemporaryDirectory(prefix='ipra-roundtrip-') as temporary:
        for probe in probes():
            data = probe['data']
            require(goal_accepts(demand, data) == probe['demand'], 'Demand probe failed: ' + probe['name'])
            require(goal_accepts(strict, data) == probe['strict'], 'Strict probe failed: ' + probe['name'])
            path = Path(temporary) / (probe['name'] + '.json')
            write_json(path, data)
            for program, expected in [(args.checker, probe['demand']), (args.strict_checker, probe['strict'])]:
                for optimize in (False, True):
                    require(cli_result(program, path, optimize) == expected, 'CLI probe failed: ' + probe['name'])
                    cli_probes += 1
            probe_rows.append({k: v for k, v in probe.items() if k != 'data'})
    for path in example_paths:
        for program in (args.checker, args.strict_checker):
            for optimize in (False, True):
                require(cli_result(program, path, optimize), 'CLI example rejected: ' + path.name)
                cli_examples += 1
    summary = {
        'source_fixtures': len(rows),
        'source_accepts': accepted,
        'source_rejects': len(rows) - accepted,
        'demand_forward_accepts': accepted,
        'demand_reverse_accepts': accepted,
        'strict_forward_accepts': accepted,
        'strict_reverse_accepts': accepted,
        'strict_accepts_before_normalization': strict_unnormalized_accepts,
        'certificates_with_repaired_vacuous_witnesses': repaired_certificates,
        'vacuous_witnesses_repaired': repairs_total,
        'direct_probes_per_checker': len(probe_rows),
        'direct_common_rejections': sum(not p['demand'] and not p['strict'] for p in probe_rows),
        'inherited_examples': len(example_paths),
        'CLI_example_runs': cli_examples,
        'CLI_probe_runs': cli_probes,
    }
    result = {
        'status': 'passed',
        'summary': summary,
        'source_provenance': PROVENANCE,
        'python_version': sys.version,
        'program_sha256': {name: digest(path.read_bytes()) for name, path in
                           [('reference', args.reference), ('demand', args.checker), ('strict', args.strict_checker)]},
        'fixture_manifest_sha256': digest(args.manifest.read_bytes()),
        'encoding': 'UTF-8 JSON; ensure_ascii=True; separators=(comma,colon); one trailing newline; dictionary order retained.',
        'qualification': 'Finite implementation validation and explicit certificate translations; not a Lean/Rocq verification or a proof of consistency. The source reference, translator, probes and runner are not imported by either acceptance checker.',
        'rows': rows,
        'probes': probe_rows,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': 'passed', **summary}, indent=2))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reference', type=Path, default=HERE / 'reference.py')
    parser.add_argument('--checker', type=Path, default=HERE.parent / 'checker.py')
    parser.add_argument('--strict-checker', type=Path, default=HERE.parent / 'strict_checker.py')
    parser.add_argument('--fixtures', type=Path, default=HERE / 'fixtures')
    parser.add_argument('--manifest', type=Path, default=HERE / 'fixture_manifest.json')
    parser.add_argument('--output', type=Path, default=HERE / 'roundtrip_results.json')
    parser.add_argument('--examples', type=Path, default=HERE.parent / 'examples')
    parser.add_argument('--corpus', type=Path, default=HERE / 'goal_corpus')
    parser.add_argument('--strict-corpus', type=Path, default=HERE / 'strict_corpus')
    run(parser.parse_args())


if __name__ == '__main__':
    main()
