"""Compile the LaTeX report; optionally create a complete ZIP with hashes."""

import argparse
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile


ROOT = Path(__file__).resolve().parent
OMIT = {".aux", ".log", ".out", ".toc", ".pyc", ".synctex.gz"}


def files():
    return sorted(p for p in ROOT.rglob("*") if p.is_file()
                  and "__pycache__" not in p.parts and p.suffix not in OMIT
                  and p.name != "MANIFEST.sha256")


def build_pdf():
    executable = shutil.which("pdflatex")
    if executable is None:
        raise SystemExit("pdfLaTeX is required to build report.pdf")
    with tempfile.TemporaryDirectory(prefix="ipra-tex-format-") as temporary:
        environment = os.environ.copy()
        finder = shutil.which("kpsewhich")
        found = subprocess.run([finder, "pdflatex.fmt"], capture_output=True, text=True) if finder else None
        if found is not None and not found.stdout.strip():
            # Some minimal TeX installations contain the source packages but
            # no prebuilt format. Build a private one without changing TeX's
            # system configuration or the user's home directory.
            engine = shutil.which("pdftex")
            if engine is None:
                raise SystemExit("pdftex is required to generate the missing LaTeX format")
            result = subprocess.run([engine, "-ini", "-interaction=nonstopmode", "-halt-on-error",
                                     "-etex", "-jobname=pdflatex", "-progname=pdflatex", "pdflatex.ini"],
                                    cwd=temporary, capture_output=True, text=True)
            if result.returncode:
                print(result.stdout)
                print(result.stderr)
                raise SystemExit(result.returncode)
            environment["TEXFORMATS"] = temporary + os.pathsep + environment.get("TEXFORMATS", "")
        for _ in range(2):
            result = subprocess.run([executable, "-interaction=nonstopmode", "-halt-on-error",
                                     "-file-line-error", "report.tex"],
                                    cwd=ROOT, env=environment, capture_output=True, text=True)
            if result.returncode:
                print(result.stdout)
                print(result.stderr)
                raise SystemExit(result.returncode)
    print("Built report.pdf")


def package():
    entries = files()
    manifest = ROOT / "MANIFEST.sha256"
    manifest.write_text("".join(hashlib.sha256(p.read_bytes()).hexdigest() + "  "
                                + p.relative_to(ROOT).as_posix() + "\n" for p in entries))
    archive = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for path in [*entries, manifest]:
            output.write(path, arcname=ROOT.name + "/" + path.relative_to(ROOT).as_posix())
    print("Built " + archive.name)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--zip", action="store_true", help="Create the ZIP after building the PDF")
    arguments = parser.parse_args()
    build_pdf()
    if arguments.zip:
        package()
