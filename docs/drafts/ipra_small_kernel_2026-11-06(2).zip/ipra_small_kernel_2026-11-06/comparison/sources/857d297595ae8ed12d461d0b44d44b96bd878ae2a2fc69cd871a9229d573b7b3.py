"""Remeasure the frozen current-corpus sources without executing checker code."""
import argparse
import json
from pathlib import Path
import platform
from legacy_measure import measure, AXES

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate', type=Path)
    parser.add_argument('--output', type=Path, default=ROOT / 'measured.json')
    args = parser.parse_args()
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    metrics = {}
    for sha, record in manifest['sources'].items():
        m = measure(ROOT / record['file'])
        if m['sha256'] != sha:
            raise ValueError('Frozen source changed: ' + sha)
        metrics[sha] = m
    groups = [
        {'files': group['files'], 'metrics': {
            axis: sum(metrics[sha][axis] for sha in group['files'])
            for axis in AXES}}
        for group in manifest['dependency_groups']]
    rows = [metrics[sha] for sha in manifest['standalone']]
    rows += [group['metrics'] for group in groups]
    envelope = {axis: min(row[axis] for row in rows) for axis in AXES}
    result = {
        'snapshot_commit': manifest['snapshot_commit'],
        'python_version': platform.python_version(),
        'verified_source_count': len(metrics),
        'standalone_count': len(manifest['standalone']),
        'dependency_group_count': len(groups),
        'primary': [{'archive': r['archive'], 'metrics': metrics[r['sha256']]}
                    for r in manifest['primary']],
        'complete_envelope': envelope,
        'dependency_groups': groups,
    }
    if args.candidate:
        candidate = measure(args.candidate)
        result['candidate'] = candidate
        result['candidate_strictly_below'] = {
            axis: candidate[axis] < envelope[axis] for axis in AXES}
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items()
                      if k != 'dependency_groups'}, indent=2))


if __name__ == '__main__':
    main()
