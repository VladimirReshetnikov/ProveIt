"""Offline remeasurement of every frozen Python source and acceptance group.

Examples:
  python3 comparison/measure.py --candidate checker.py --out results/comparison.json

Compared programs are parsed, never imported or executed. Both acceptance
and excluded support sources are frozen, so the classification is inspectable.
"""

import argparse
import ast
import copy
import hashlib
import io
import json
from pathlib import Path
import platform
import sys
import tokenize

ROOT = Path(__file__).resolve().parent
FIELDS = ("source_tokens", "normalized_tokens", "ast_nodes", "normalized_bytes", "raw_bytes")
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}


def docstrings(tree):
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if node.body and isinstance(node.body[0], ast.Expr):
                value = node.body[0].value
                if isinstance(value, ast.Constant) and isinstance(value.value, str):
                    yield node.body[0]


def tokens(source, omitted=()):
    return sum(item.type not in IGNORED and not any(
        start <= item.start and item.end <= end for start, end in omitted)
        for item in tokenize.generate_tokens(io.StringIO(source).readline))


def measure(path):
    data = path.read_bytes()
    source = data.decode("utf-8")
    tree = ast.parse(source)
    spans = [((n.lineno, n.col_offset), (n.end_lineno, n.end_col_offset))
             for n in docstrings(tree)]
    stripped = copy.deepcopy(tree)
    omitted = {id(n) for n in docstrings(stripped)}
    for node in ast.walk(stripped):
        if hasattr(node, "body") and isinstance(node.body, list):
            node.body = [child for child in node.body if id(child) not in omitted]
    normalized = ast.unparse(stripped) + "\n"
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(a.name for a in node.names)
        if isinstance(node, ast.ImportFrom):
            imports.append(node.module)
    return {
        "sha256": hashlib.sha256(data).hexdigest(),
        "normalized_sha256": hashlib.sha256(normalized.encode()).hexdigest(),
        "source_tokens": tokens(source, spans),
        "normalized_tokens": tokens(normalized),
        "ast_nodes": sum(1 for _ in ast.walk(stripped)),
        "normalized_bytes": len(normalized.encode()),
        "raw_bytes": len(data),
        "raw_lines": len(source.splitlines()),
        "functions": sorted(n.name for n in tree.body if isinstance(n, ast.FunctionDef)),
        "classes": sorted(n.name for n in tree.body if isinstance(n, ast.ClassDef)),
        "imports": sorted(set(imports)),
        "has_main_branch": any(isinstance(n, ast.If)
                               and isinstance(n.test, ast.Compare)
                               and isinstance(n.test.left, ast.Name)
                               and n.test.left.id == "__name__"
                               and any(isinstance(c, ast.Constant) and c.value == "__main__"
                                       for c in n.test.comparators)
                               for n in tree.body),
    }


def envelope(rows):
    return {f: min(r[f] for r in rows) for f in FIELDS}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    metadata = json.loads((ROOT / "metadata.json").read_text())
    inventory = json.loads((ROOT / "full_inventory.json").read_text())
    measured = {}
    locations = {}
    for folder in ("sources", "excluded_support"):
        for path in sorted((ROOT / folder).glob("*.py")):
            row = measure(path)
            if row["sha256"] != path.stem or path.stem in measured:
                raise ValueError("Hash mismatch or duplicate frozen source: " + str(path))
            measured[path.stem] = row
            locations[path.stem] = folder
    if set(measured) != set(inventory):
        raise ValueError("Frozen inventory differs from complete recorded Python inventory")

    standalone = set()
    for digest, row in measured.items():
        ordinary = {"infer", "check"} <= set(row["functions"])
        class_based = "Checker" in row["classes"]
        if (ordinary or class_based) and row["has_main_branch"] and set(row["imports"]) <= {"json", "sys"}:
            standalone.add(digest)
    if standalone != set(metadata["standalone"]):
        raise ValueError("Standalone classification does not reproduce")

    groups = []
    dependency_audit = []
    grouped = set()
    for declaration in metadata["historical_groups"]:
        members = declaration["members"]
        if len(members) != len(set(members)) or not set(members) <= set(measured):
            raise ValueError("Missing or repeated dependency-group member")
        grouped.update(members)
        totals = {f: sum(measured[h][f] for h in members) for f in FIELDS}
        groups.append({"id": declaration["id"], "members": members, **totals})
        recorded_names = set()
        for origin in declaration["declarations"]:
            for member in origin["group"].get("files", []):
                recorded_names.add(Path(member.get("recorded_path", "")).stem)
        project_imports = {name.split(".")[0] for h in members for name in measured[h]["imports"]
                           if name.split(".")[0] not in sys.stdlib_module_names}
        missing_names = sorted(project_imports - recorded_names)
        dependency_audit.append({
            "id": declaration["id"],
            "member_count": len(members),
            "recorded_module_names": sorted(recorded_names),
            "project_import_names": sorted(project_imports),
            "variant_installation_aliases_required": missing_names,
            "note": ("Original adapter imports kernel; group declares a differently named variant as that kernel. This is a favorable recorded source boundary, not an independently runnable assembled directory."
                     if missing_names else "All explicit project import names occur among recorded member module names, or the group contains no project imports.")
        })
    selected = standalone | grouped
    if {h for h, folder in locations.items() if folder == "sources"} != selected:
        raise ValueError("Frozen acceptance-source selection does not reproduce")
    if sum(len(row["origins"]) for row in inventory.values()) != metadata["python_occurrences"]:
        raise ValueError("Source occurrence count mismatch")
    standalone_rows = [measured[h] for h in sorted(standalone)]
    lower = envelope(standalone_rows + groups)
    result = {
        "status": "passed", "repository": metadata["repository"], "commit": metadata["commit"],
        "python": platform.python_version(),
        "source_occurrences": metadata["python_occurrences"],
        "unique_sources": len(measured), "standalone_count": len(standalone),
        "historical_group_count": len(groups), "frozen_acceptance_source_count": len(selected),
        "excluded_support_source_count": len(measured) - len(selected),
        "primary": [{**row, **{f: measured[row["sha256"]][f] for f in FIELDS}}
                    for row in metadata["primary"]],
        "lower_envelope": lower,
        "historical_group_envelope": envelope(groups),
        "multifile_group_envelope": envelope([g for g in groups if len(g["members"]) > 1]),
        "standalone": standalone_rows, "historical_groups": groups,
        "dependency_audit": dependency_audit,
        "qualification": metadata["qualification"],
    }
    if args.candidate:
        candidate = measure(args.candidate)
        result.update({
            "candidate": candidate,
            "strictly_below": {f: candidate[f] < lower[f] for f in FIELDS},
            "savings": {f: lower[f] - candidate[f] for f in FIELDS},
            "savings_percent": {f: 100 * (1 - candidate[f] / lower[f]) for f in FIELDS},
        })
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(result, indent=2) + "\n")
    keys = ["status", "commit", "python", "source_occurrences", "unique_sources", "standalone_count",
            "historical_group_count", "frozen_acceptance_source_count", "excluded_support_source_count", "lower_envelope"]
    if args.candidate:
        keys += ["candidate", "strictly_below", "savings_percent"]
    print(json.dumps({k: result[k] for k in keys}, indent=2))


if __name__ == "__main__":
    main()
