"""Build report.pdf from the supplied TeX and measured source; no network needed."""

import os
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def main():
    if not shutil.which("pdflatex"):
        raise SystemExit("pdfLaTeX is required to rebuild the PDF.")
    with tempfile.TemporaryDirectory(prefix="ipra-report-") as temporary:
        target = Path(temporary)
        environment = os.environ.copy()
        if shutil.which("kpsewhich"):
            lookup = subprocess.run(["kpsewhich", "pdflatex.fmt"], capture_output=True)
            if lookup.returncode:
                initialize = subprocess.run(
                    ["pdftex", "-ini", "-etex", "-interaction=nonstopmode",
                     "-jobname=pdflatex", "-progname=pdflatex",
                     "-output-directory=" + temporary, "pdflatex.ini"],
                    cwd=temporary, capture_output=True, text=True)
                if initialize.returncode:
                    print(initialize.stdout)
                    print(initialize.stderr)
                    raise SystemExit(initialize.returncode)
                environment["TEXFORMATS"] = temporary + os.pathsep + environment.get("TEXFORMATS", "")
        command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                   "-file-line-error", "-output-directory=" + temporary, "report.tex"]
        for _ in range(3):
            result = subprocess.run(command, cwd=ROOT, env=environment,
                                    text=True, capture_output=True)
            if result.returncode:
                print(result.stdout)
                print(result.stderr)
                raise SystemExit(result.returncode)
        log = (target / "report.log").read_text(errors="replace")
        (ROOT / "results").mkdir(exist_ok=True)
        (ROOT / "results/build.log").write_text(log)
        bad = [line for line in log.splitlines()
               if "Overfull" in line or "undefined" in line.lower()]
        if bad:
            raise SystemExit("Review TeX layout/references before delivery:\n" + "\n".join(bad))
        shutil.copyfile(target / "report.pdf", ROOT / "report.pdf")
    print("Built report.pdf with resolved references and no overfull boxes.")


if __name__ == "__main__":
    main()
