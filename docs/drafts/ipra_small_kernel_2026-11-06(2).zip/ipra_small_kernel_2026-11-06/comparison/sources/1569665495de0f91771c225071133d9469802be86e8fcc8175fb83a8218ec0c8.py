"""Independent rule interpreter for the new finite-JSON proof format.

No code from the candidate is imported. Variable operations decode into globally
fresh names, replace free names, and encode back to de Bruijn indices. Rules
are written separately, without the candidate's shared transition machinery.
"""
from collections import Counter
from named_syntax import decode, subst, well_formed, DeletedParameter


def need(condition):
    if not condition:
        raise ValueError('independent rule check failed')


def valid(a, formula=True):
    decode(a, formula)
    return a


def lift_context(g):
    return [subst(a) for a in g]


def occurs_slot(matrix):
    try:
        subst(matrix, [None, -1])
        return False
    except DeletedParameter:
        return True


def infer(p, g, counts=None):
    """Return (formula, canonical proof), normalizing only harmless payloads."""
    if counts is None:
        counts = Counter()
    if type(p) is list and len(p) == 3 and p[0] == 'lam':
        _, a, q = p
        valid(a)
        b, q = infer(q, lift_context(g) + [a], counts)
        counts['universal_introduction'] += 1
        return ['pi', a, b], ['lam', a, q]
    if type(p) is list and len(p) == 3 and p[0] == 'pack':
        _, t, q = p
        valid(t, False)
        guard = ['=', 0, subst(t, formula=False)]
        b, q = infer(q, lift_context(g) + [guard], counts)
        counts['existential_introduction'] += 1
        return ['ex', b], ['pack', t, q]
    if type(p) is list and len(p) == 3 and p[0] == 'nat':
        _, matrix, q = p
        valid(matrix)
        base = subst(matrix, [-1, 0])
        guard = matrix if matrix[0] == '=' else base
        b, q = infer(q, lift_context(g) + [guard], counts)
        need(b == subst(matrix, [['s', 0], 0]))
        counts['equation_induction' if matrix[0] == '=' else 'numerical_cases'] += 1
        return ['pi', base, matrix], ['nat', matrix, q]
    if type(p) is list and len(p) == 4 and p[0] == 'r':
        valid(p, False)
        _, counter, initial, update = p
        if counter == -1:
            result = initial
            counts['recursion_zero'] += 1
        else:
            need(type(counter) is list and len(counter) == 2 and counter[0] == 's')
            n = counter[1]
            result = subst(update, [['r', n, initial, update], n, -2], formula=False)
            counts['recursion_successor'] += 1
        return ['=', p, result], p
    if type(p) is list and len(p) == 3:
        major, annotation, minor = p
        principal, canonical_major = infer(major, g, counts)
        if principal[0] == 'ex':
            valid(annotation)
            b, canonical_minor = infer(minor, lift_context(g) + [principal[1]], counts)
            need(b == subst(annotation))
            counts['existential_elimination'] += 1
            return annotation, [canonical_major, annotation, canonical_minor]
        if principal[0] == 'pi':
            witness = annotation
            if not well_formed(witness, False):
                need(not any(occurs_slot(a) for a in principal[1:]))
                witness = -1
                counts['vacuous_payload_normalized'] += 1
            guard = subst(principal[1], [witness, -1])
            result = subst(principal[2], [witness, -1])
            counts['universal_elimination'] += 1
            annotation = witness
        else:
            need(principal[0] == '=')
            valid(annotation)
            guard = subst(annotation, [principal[1], -1])
            result = subst(annotation, [principal[2], -1])
            counts['equality_transport'] += 1
        b, canonical_minor = infer(minor, g, counts)
        need(b == guard)
        return result, [canonical_major, annotation, canonical_minor]
    need(type(p) in (int, bool))
    index = int(p)
    if index < 0:
        index += len(g)
    need(0 <= index < len(g))
    counts['assumption'] += 1
    return g[index], index


def check(data):
    need(type(data) is list and len(data) >= 2)
    goal, proof, *context = data
    for a in context + [goal]:
        valid(a)
    counts = Counter()
    result, canonical = infer(proof, context, counts)
    need(result == goal)
    return counts, [goal, canonical, *context]


def as_local(proof):
    """Canonical new proof to the complete strict local baseline format."""
    if type(proof) is list:
        if len(proof) == 3 and proof[0] in ('lam', 'pack', 'nat'):
            return [proof[0], proof[1], as_local(proof[2])]
        if len(proof) == 4 and proof[0] == 'r':
            return proof
        if len(proof) == 3:
            return ['use', as_local(proof[0]), proof[1], as_local(proof[2])]
    return proof
