"""Remeasure the frozen corpus, write paper tables, and compile the PDF."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def tables():
    result = subprocess.run(
        [sys.executable, str(ROOT / 'comparison/measure.py'),
         '--candidate', str(ROOT / 'checker.py')],
        check=True, text=True, capture_output=True)
    data = json.loads(result.stdout)
    (ROOT / 'comparison/candidate_metrics.json').write_text(
        json.dumps(data, indent=2) + '\n')
    candidate, lower = data['candidate'], data['complete_envelope']
    if not all(data['candidate_strictly_below'][k] for k in
               ('normalized_tokens', 'ast_nodes', 'normalized_bytes')):
        raise ValueError('The checker is not strictly below the frozen envelope.')
    macros = []
    for prefix, row in [('Candidate', candidate), ('Baseline', lower)]:
        for name, key in [('Tokens', 'normalized_tokens'), ('AST', 'ast_nodes'),
                          ('Bytes', 'normalized_bytes')]:
            macros.append('\\newcommand{\\' + prefix + name + '}{'
                          + format(row[key], ',') + '}')
    (ROOT / 'sections/metrics_macros.tex').write_text('\n'.join(macros) + '\n')
    labels = ['Demand, (1) archive', 'Demand, unsuffixed archive', 'Local',
              'Scoped rules', 'Shared transition', 'Uniform']
    lines = [r'\begin{tabular}{@{}lrrr@{}}', r'\toprule',
             r'Complete checker & Norm. tokens & AST nodes & Norm. bytes \\',
             r'\midrule']

    def line(label, row, bold=False):
        cells = [label] + [format(row[k], ',') for k in
                          ('normalized_tokens', 'ast_nodes', 'normalized_bytes')]
        if bold:
            cells = [r'\textbf{' + s + '}' for s in cells]
        return ' & '.join(cells) + r' \\'

    lines.extend(line(label, row['metrics']) for label, row in
                 zip(labels, data['primary'], strict=True))
    lines += [r'\midrule', line('Expanded lower envelope', lower),
              line('This construction', candidate, True),
              r'\bottomrule', r'\end{tabular}']
    (ROOT / 'sections/metrics_table.tex').write_text('\n'.join(lines) + '\n')
    return data


def main():
    data = tables()
    for run in range(3):
        with (ROOT / 'latex_build.txt').open('w') as log:
            result = subprocess.run(
                ['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
                 'report.tex'], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        if result.returncode:
            raise SystemExit('LaTeX failed; inspect latex_build.txt.')
    print(json.dumps({'pdf': str(ROOT / 'report.pdf'),
                      'candidate': data['candidate'],
                      'strictly_below': data['candidate_strictly_below']}, indent=2))


if __name__ == '__main__':
    main()
