"""Meaningful hostile-annotation and scope checks for the raw-equation change."""
import json
import random
from pathlib import Path
import repair

ROOT = Path(__file__).resolve().parent
K = repair.raw
F = ['=', -1, -1]
# Reflexivity from one actual computation equation and equality transport.
r0 = ['r', -1, -1, -1]
truth = [r0, ['=', 0, -1], r0]


def accepted(data):
    try:
        K.check(*data)
        return True
    except Exception:
        return False


def discard(major):
    # The raw equation is an equality major; the valid motive ignores both ends.
    return [major, F, truth]


def verify(name, proof, expected=True, g=None, goal=None):
    data = [[] if g is None else g, F if goal is None else goal, proof]
    actual = accepted(data)
    assert actual == expected, (name, actual, expected)
    if actual:
        target = repair.normalize(data)
        assert target[:2] == data[:2]
    return {'name': name, 'accepted': actual, 'repaired': actual}


def run(output):
    bad = [None, True, False, -2, -1.0, 0.0, 1.0, 2.5, 'unused', [], {},
           ['s'], ['s', -1, -1], ['r', -1], ['r', -1, -1, None],
           ['pi', F, F], {'s': None}, float('inf'), float('-inf'), float('nan')]
    rows = []
    for i, payload in enumerate(bad):
        rows.append(verify(f'base_unused_body_{i}', discard(['r', -1, -1, payload])))
        rows.append(verify(f'base_raw_seed_{i}', discard(['r', -1, payload, -1])))
        rows.append(verify(f'step_unused_seed_{i}', discard(['r', ['s', -1], payload, 1])))
        rows.append(verify(f'step_unused_counter_{i}', discard(['r', ['s', payload], -1, -1])))
        # An existential with raw matrix may be opened and its invalid hypothesis ignored.
        rows.append(verify(f'raw_existential_matrix_{i}',
                           [['pack', -1, ['r', -1, -1, payload]], truth]))
        # If the step uses the malformed seed through the previous value, it is demanded.
        try:
            K.subst(payload, formula=False)
            canonical = True
        except Exception:
            canonical = False
        rows.append(verify(f'step_demanded_seed_{i}',
                           discard(['r', ['s', -1], payload, 0]), canonical))

    # Numeric aliases are accepted in raw R0 data, but only as encodings of the same
    # normalized arithmetic term. Public syntax remains exact and rejects aliases.
    for i, alias in enumerate([-1.0, True, False, 0.0, 1.0, 2.0]):
        canonical = repair.term(alias)
        proof = ['r', -1.0, alias, -1]
        goal = ['=', ['r', -1, canonical, -1], canonical]
        rows.append(verify(f'raw_numeric_alias_{i}', proof, goal=goal))
        malformed_goal = ['=', ['r', -1.0, alias, -1], alias]
        rows.append(verify(f'public_numeric_alias_rejected_{i}', proof,
                           expected=False, goal=malformed_goal))

    # The removed check must not mask an invalid counter constructor or malformed
    # step body. These cases never reach a sound structural recursion pattern.
    for i, counter in enumerate([0, -2, None, ['s'], ['s', -1, -1], ['r', -1, -1, -1]]):
        rows.append(verify(f'bad_counter_{i}', discard(['r', counter, -1, -1]), False))
    for i, h in enumerate([None, True, -2, -1.0, ['s'], ['=', -1, -1]]):
        rows.append(verify(f'bad_step_body_{i}', discard(['r', ['s', -1], -1, h]), False))

    # Generalized repair invariant in weak contexts, as needed when an existential
    # elimination opens a raw matrix. This is stronger than top-level tests alone.
    for i, payload in enumerate(bad):
        g = [['=', ['r', -1, -1, payload], -1]]
        for j, p in enumerate([0, [0, F, truth], ['r', -1, payload, -1]]):
            a = K.infer(p, g)
            q = repair.repair(p, g)
            assert repair.reference.infer(q, list(map(repair.formula, g))) == repair.formula(a)
            assert repair.eager.infer(q, list(map(repair.formula, g))) == repair.formula(a)
            rows.append({'name':f'weak_context_invariant_{i}_{j}', 'accepted':True, 'repaired':True})

    # Substitution commutation with normalization, including nested recursor binders.
    random.seed(20261106)
    def canonical_term(depth):
        if depth == 0:
            return random.choice([-1, 0, 1, 2, 3, 4, 9])
        tag = random.randrange(3)
        if tag == 0:
            return canonical_term(0)
        if tag == 1:
            return ['s', canonical_term(depth - 1)]
        return ['r', *(canonical_term(depth - 1) for _ in range(3))]

    trials = success = 0
    for _ in range(800):
        a = canonical_term(3)
        env = [random.choice(bad + [-1, 0, 2, ['s', -1]]) for _ in range(random.randrange(3))]
        env.append(random.choice([-2, -1, 0, 1, 2]))
        d = random.randrange(3)
        trials += 1
        try:
            value = K.subst(a, env, d, formula=False)
        except Exception:
            continue
        normalized_env = [*map(repair.term, env[:-1]), env[-1]]
        expected = K.subst(a, normalized_env, d, formula=False)
        assert expected == value, (a, env, d, value, expected)
        success += 1

    result = {'status':'passed', 'focused_tests':len(rows),
              'accepted_and_repaired':sum(row['accepted'] for row in rows),
              'rejected':sum(not row['accepted'] for row in rows),
              'substitution_trials':trials, 'successful_substitution_cases':success,
              'rows':rows}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result,indent=2)+'\n')
    return result


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT/'results/raw_checks.json')
    args = parser.parse_args()
    result = run(args.output)
    print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
