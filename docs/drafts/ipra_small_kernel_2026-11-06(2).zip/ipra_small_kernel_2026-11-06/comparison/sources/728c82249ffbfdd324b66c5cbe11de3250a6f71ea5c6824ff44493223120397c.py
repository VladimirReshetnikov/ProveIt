"""Create the delivery ZIP and its file-hash manifest from this package."""
import hashlib
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent
IGNORED = {'.aux', '.log', '.toc', '.out', '.pyc'}


def delivered(path):
    return (path.is_file() and path.suffix not in IGNORED
            and '__pycache__' not in path.parts
            and path.name not in {'SHA256SUMS', 'latex_build.txt'})


def main():
    files = sorted(p for p in ROOT.rglob('*') if delivered(p))
    if not (ROOT / 'report.pdf').is_file():
        raise SystemExit('Compile report.pdf first.')
    hashes = [hashlib.sha256(p.read_bytes()).hexdigest() + '  '
              + p.relative_to(ROOT).as_posix() for p in files]
    (ROOT / 'SHA256SUMS').write_text('\n'.join(hashes) + '\n')
    files.append(ROOT / 'SHA256SUMS')
    destination = ROOT.parent / 'output'
    destination.mkdir(exist_ok=True)
    archive = destination / (ROOT.name + '.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as target:
        for path in sorted(files):
            name = ROOT.name + '/' + path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 6, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            target.writestr(info, path.read_bytes(), compresslevel=9)
    pdf = destination / (ROOT.name + '.pdf')
    shutil.copyfile(ROOT / 'report.pdf', pdf)
    with zipfile.ZipFile(archive) as check:
        if check.testzip() is not None or len(check.infolist()) != len(files):
            raise SystemExit('ZIP integrity check failed.')
    print(f'{archive.name}: {len(files)} files; {archive.stat().st_size} bytes')
    print(f'{pdf.name}: {pdf.stat().st_size} bytes')


if __name__ == '__main__':
    main()
