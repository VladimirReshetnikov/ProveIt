"""Recheck the frozen finite fixture corpus and normalize accepted proofs.

This is untrusted validation support. Acceptance checkers import none of it.
Only the packaged fixtures and the three named frozen checkers are required.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(data):
    return (json.dumps(data, ensure_ascii=True, separators=(',', ':')) + '\n').encode('utf-8')


def load(name, path, expected):
    require(digest(path.read_bytes()) == expected, 'Changed checker: ' + name)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def accepts(kernel, data):
    try:
        return kernel.check(data) is True
    except Exception:
        return False


def uses_slot(a, scopes, d=0, formula=True):
    """Find the distinguished free slot, accounting for all internal binders."""
    if type(a) is int:
        return a == d
    tag, *parts = a
    return any(uses_slot(t, scopes, d + width, width == 1)
               for t, width in zip(parts, scopes[formula][tag], strict=True))


def restore(p, g, primary, explicit_ex=False):
    """Translate a successful primary proof without changing its claimed sequent.

    Vacuous pi witness fields become numerical zero. When explicit_ex=True,
    inferred existential conclusions are restored for the frozen source checker.
    """
    match p:
        case [('lam' | 'pack' | 'nat') as tag, a, q]:
            guard = ['=', 0, primary.subst(a, formula=False)] if tag == 'pack' else a
            base = primary.subst(guard, [-1, 0] if tag == 'nat' else (0,))
            h = guard if guard[0] == '=' else base
            local = [*map(primary.subst, g), h]
            return [tag, a, restore(q, local, primary, explicit_ex)]
        case ['use', major, *args]:
            tag, *parts = primary.infer(major, g)
            converted_major = restore(major, g, primary, explicit_ex)
            if tag == 'ex':
                (minor,) = args
                converted_minor = restore(minor, [*map(primary.subst, g), *parts], primary, explicit_ex)
                if explicit_ex:
                    return ['use', converted_major, primary.infer(p, g), converted_minor]
                return ['use', converted_major, converted_minor]
            a, minor = args
            if tag == 'pi' and not any(uses_slot(t, primary.SCOPES) for t in parts):
                a = -1
            return ['use', converted_major, a, restore(minor, g, primary, explicit_ex)]
        case _:
            return p


def run(primary_path, strict_path, source_path, output):
    manifest = json.loads((ROOT / 'manifest.json').read_text(encoding='utf-8'))
    kernels = manifest['kernels']
    primary = load('fixture_primary', primary_path, kernels['primary']['sha256'])
    strict = load('fixture_strict', strict_path, kernels['strict']['sha256'])
    source = load('fixture_source', source_path, kernels['source']['sha256'])
    rows = []
    groups = {}
    for entry in manifest['fixtures']:
        name = entry['name']
        raw = (ROOT / entry['file']).read_bytes()
        require(digest(raw) == entry['sha256'], 'Changed fixture: ' + name)
        data = json.loads(raw)
        primary_ok = accepts(primary, data)
        strict_ok = accepts(strict, data)
        require(primary_ok == entry['expected']['primary'], 'Primary result changed: ' + name)
        require(strict_ok == entry['expected']['strict'], 'Strict result changed: ' + name)
        normalized = None
        if primary_ok:
            g, a, p = data
            controlled = [g, a, restore(p, g, primary)]
            restored = [g, a, restore(p, g, primary, explicit_ex=True)]
            require(controlled[:2] == data[:2] and restored[:2] == data[:2],
                    'Claimed sequent changed: ' + name)
            normalized = {'strict_sha256': digest(encode(controlled)),
                          'source_sha256': digest(encode(restored))}
            require(normalized == entry['normalization'], 'Normalized proof changed: ' + name)
            require(accepts(strict, controlled), 'Strict normalized proof rejected: ' + name)
            require(accepts(source, restored), 'Source normalized proof rejected: ' + name)
        else:
            require(entry['normalization'] is None, 'Unexpected negative normalization: ' + name)
        summary = groups.setdefault(entry['group'], {'count': 0, 'primary_accept': 0, 'strict_accept': 0})
        summary['count'] += 1
        summary['primary_accept'] += primary_ok
        summary['strict_accept'] += strict_ok
        rows.append({'name': name, 'primary_accepted': primary_ok, 'strict_accepted': strict_ok,
                     'normalization': normalized})
    require(len(rows) == manifest['total'], 'Fixture count changed')
    require(groups == manifest['groups'], 'Fixture group totals changed')
    result = {'status': 'passed', 'total': len(rows), 'groups': groups,
              'kernel_sha256': {name: item['sha256'] for name, item in kernels.items()},
              'manifest_sha256': digest((ROOT / 'manifest.json').read_bytes()),
              'normalized_to_both_targets': sum(row['normalization'] is not None for row in rows),
              'rows': rows, 'qualification': manifest['qualification']}
    output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: value for key, value in result.items() if key != 'rows'}, indent=2))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--primary', type=Path, default=ROOT.parent / 'checker.py')
    parser.add_argument('--strict', type=Path, default=ROOT.parent / 'comparison/strict_checker.py')
    parser.add_argument('--source', type=Path, default=ROOT.parent / 'comparison/baselines/smaller.py')
    parser.add_argument('--output', type=Path, default=ROOT / 'results.json')
    args = parser.parse_args()
    run(args.primary, args.strict, args.source, args.output)


if __name__ == '__main__':
    main()
