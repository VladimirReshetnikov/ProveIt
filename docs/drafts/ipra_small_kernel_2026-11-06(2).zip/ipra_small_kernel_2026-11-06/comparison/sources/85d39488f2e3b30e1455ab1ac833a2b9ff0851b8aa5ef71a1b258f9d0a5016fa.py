"""Finite independent audit of a complete direct-step iPRA checker.

Run: python3 validation/run.py --candidate checker.py --output audit.json
     [--corpus translated_directory] [--legacy-negative-directory directory]

The independent syntax and rule oracles never import the candidate. This
driver imports it only to compare outcomes. Expected results for focused
certificates are fixed below, not obtained from candidate inference.
"""

import argparse
from collections import Counter
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile

from named_syntax import oracle, valid, term, formula
import rule_oracle


ZERO = -1
ONE = ["s", ZERO]
TRUE = ["=", ZERO, ZERO]
FALSE = ["=", ZERO, ONE]


def load(path):
    spec = importlib.util.spec_from_file_location("audited_candidate", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def outcome(function, *args, **kwargs):
    try:
        return True, function(*args, **kwargs)
    except Exception:
        return False, None


def run(candidate_path, output, corpus=(), legacy_negative_directory=None):
    candidate_path = Path(candidate_path).resolve()
    candidate = load(candidate_path)
    counts, rule_counts = Counter(), Counter()
    failures, certificate_records, corpus_records = [], [], []

    def test(category, name, condition):
        counts[category] += 1
        if not condition:
            failures.append({"category": category, "name": name})

    def certificate(name, data, expected):
        accepted, value = outcome(candidate.check, data)
        independently_accepted, trace = outcome(rule_oracle.check, data)
        test("focused_certificate", name,
             accepted == expected and independently_accepted == expected
             and (not accepted or value is True))
        certificate_records.append({"name": name, "expected": expected,
                                    "accepted": accepted, "oracle": independently_accepted})
        if independently_accepted:
            rule_counts.update(trace)

    rng = random.Random(762941)
    expressions = []
    for _ in range(240):
        expressions += [(term(rng), False), (formula(rng), True)]
    for i, (a, sort) in enumerate(expressions):
        for depth in range(4):
            k = rng.randrange(4)
            environment = [*(term(rng, 2) for _ in range(k)), rng.randrange(-k, 4)]
            expected = oracle(a, environment, depth, sort)
            ok, actual = outcome(candidate.subst, a, environment, depth, formula=sort)
            test("named_substitution", f"{i}:{depth}", ok and actual == expected)
            expected_ok, expected = outcome(oracle, a, [None, -1], depth, sort)
            ok, actual = outcome(candidate.subst, a, [None, -1], depth, formula=sort)
            test("partial_scope_deletion", f"{i}:{depth}",
                 ok == expected_ok and (not ok or actual == expected))
        lifted = oracle(a, (1,), formula=sort)
        ok, lowered = outcome(candidate.subst, lifted, [None, -1], formula=sort)
        test("lift_delete_roundtrip", str(i), ok and lowered == a)

    bad_scalars = [None, True, False, -2, -100, 0.0, -1.0, 1.0,
                   0.5, "", "s", "r", "=", "pi", "ex", {}, {"=": 0}]
    grammar_values = list(bad_scalars) + [-1, 0, 1, [], TRUE, ["s", -1]]
    tags = ["s", "r", "=", "pi", "ex", "unknown"]
    seeds = [-1, 0, True, None, "s", [], TRUE, ["s", -1]]
    for tag in tags:
        grammar_values.append([tag])
        for a in seeds:
            grammar_values.append([tag, a])
            for b in seeds:
                grammar_values.append([tag, a, b])
                for c in seeds:
                    grammar_values.append([tag, a, b, c])
    for width in range(1, 5):
        grammar_values.extend("".join(s) for s in itertools.product("sr=pex", repeat=width))
    grammar_values.extend(a for a, _ in expressions)
    for i, a in enumerate(grammar_values):
        for sort in (False, True):
            ok, _ = outcome(candidate.subst, a, formula=sort)
            test("grammar", f"{i}:{sort}", ok == valid(a, sort))
        if not valid(a, True):
            ok, _ = outcome(candidate.check, [[a], TRUE, 0])
            test("malformed_sequent", f"context:{i}", not ok)
            ok, _ = outcome(candidate.check, [[TRUE], a, 0])
            test("malformed_sequent", f"goal:{i}", not ok)

    certificate("indexed hypothesis", [[TRUE], TRUE, 0], True)
    certificate("negative hypothesis index", [[FALSE, TRUE], TRUE, -1], True)
    certificate("boolean hypothesis alias false", [[TRUE], TRUE, False], True)
    certificate("boolean hypothesis alias true", [[FALSE, TRUE], TRUE, True], True)
    certificate("float hypothesis rejected", [[TRUE], TRUE, 0.0], False)
    certificate("out of range hypothesis", [[TRUE], TRUE, 1], False)
    certificate("too negative hypothesis", [[TRUE], TRUE, -2], False)
    certificate("boolean arithmetic goal rejected", [[["=", 0, 1]], ["=", False, True], 0], False)
    certificate("false has no empty-context hypothesis", [[], FALSE, 0], False)
    certificate("universal identity", [[], ["pi", ["=", 0, ZERO], ["=", 0, ZERO]],
                                       ["lam", ["=", 0, ZERO], -1]], True)
    certificate("universal context captured", [[["=", 0, ZERO]], ["pi", TRUE, ["=", 0, ZERO]],
                                               ["lam", TRUE, 0]], False)
    certificate("universal context lifted", [[["=", 0, ZERO]], ["pi", TRUE, ["=", 1, ZERO]],
                                             ["lam", TRUE, 0]], True)
    certificate("witness equation packing", [[], ["ex", ["=", 0, ONE]], ["pack", ONE, -1]], True)
    certificate("parameter witness lifted", [[], ["ex", ["=", 0, 1]], ["pack", 0, -1]], True)
    certificate("parameter witness capture rejected", [[], ["ex", ["=", 0, 0]], ["pack", 0, -1]], False)
    ex = ["ex", ["=", 0, ZERO]]
    certificate("existential witness escape", [[ex], ["=", 0, ZERO], ["use", 0, -1]], False)
    certificate("existential retained parameter", [[ex, ["=", 0, ZERO]], ["=", 0, ZERO],
                                                   ["use", 0, 1]], True)
    certificate("existential vacuous witness", [[["ex", TRUE]], TRUE, ["use", 0, -1]], True)
    certificate("existential extra conclusion field", [[["ex", TRUE]], TRUE, ["use", 0, TRUE, -1]], False)
    certificate("existential missing branch", [[["ex", TRUE]], TRUE, ["use", 0]], False)
    rec0 = ["r", ZERO, 0, ["r", 1, 0, ["s", 2]]]
    certificate("recursor zero nested body", [[], ["=", rec0, 0], rec0], True)
    old = ["r", 2, 1, ["r", 1, 0, ["s", 2]]]
    rec1 = ["r", ["s", 2], 1, ["r", 1, 0, ["s", 2]]]
    lifted_old = ["r", 4, 3, ["r", 1, 0, ["s", 2]]]
    expected_update = ["r", 2, old, ["s", lifted_old]]
    certificate("recursor successor simultaneous substitution", [[], ["=", rec1, expected_update], rec1], True)
    for n in (0, 1, ["r", ZERO, ZERO, ZERO]):
        r = ["r", n, ZERO, ZERO]
        certificate("nonconstructor recursion " + repr(n), [[], ["=", r, ZERO], r], False)
    for bad in bad_scalars + [TRUE, ["s"], ["r", ZERO, ZERO]]:
        certificate("unused malformed update " + repr(bad), [[], TRUE, ["r", ZERO, ZERO, bad]], False)
        certificate("unused malformed witness " + repr(bad), [[TRUE], ["ex", TRUE], ["pack", bad, 0]], False)
        certificate("unused universal witness " + repr(bad),
                    [[["pi", TRUE, TRUE], TRUE], TRUE, ["use", 0, bad, 1]], False)

    nested_bodies = [["pi", TRUE, ["=", 1, ZERO]], ["ex", ["=", 1, ZERO]],
                     ["=", ["r", ZERO, ZERO, 2], ZERO],
                     ["ex", ["=", ["r", ZERO, ZERO, 3], ZERO]],
                     ["pi", ["=", 1, ZERO], TRUE]]
    for i, body in enumerate(nested_bodies):
        certificate(f"nested witness escape {i}", [[["ex", body]], TRUE, ["use", 0, -1]], False)
        shifted = oracle(body)
        certificate(f"nested old variable survives {i}", [[["ex", shifted]], body, ["use", 0, -1]], True)

    for i in range(80):
        matrix = formula(rng, 2)
        base = oracle(matrix, [ZERO, 0])
        step_conclusion = oracle(matrix, [["s", 0], 0])
        guard = matrix if matrix[0] == "=" else base
        step = ["pi", guard, step_conclusion]
        proof = ["nat", matrix, ["use", 0, 0, -1]]
        certificate(f"direct numerical rule {i}", [[step], ["pi", base, matrix], proof], True)
        certificate(f"missing numerical premise {i}", [[], ["pi", base, matrix], ["nat", matrix]], False)
        certificate(f"extra numerical field {i}", [[step], ["pi", base, matrix], proof + [0]], False)
        if matrix[0] != "=" and matrix != base:
            forbidden = ["pi", matrix, step_conclusion]
            certificate(f"quantified induction rejected {i}", [[forbidden], ["pi", base, matrix], proof], False)

    # The following structural input families exercise hypothesis-index and
    # rule arity validation in context; no expected result is inferred by the
    # candidate. The explicit interpreter supplies an independent verdict.
    proof_values = [None, False, True, -4, -1, 0, 1, 3, 0.0, "", [], {}, TRUE]
    proof_tags = ["lam", "pack", "nat", "use", "r", "unknown"]
    for tag in proof_tags:
        for values in itertools.product([None, -1, 0, TRUE], repeat=3):
            for width in range(4):
                proof_values.append([tag, *values[:width]])
    probe_contexts = [[], [TRUE], [FALSE, TRUE], [["ex", TRUE]], [["pi", TRUE, TRUE], TRUE]]
    for i, proof in enumerate(proof_values):
        for j, context in enumerate(probe_contexts):
            expected_ok, expected = outcome(rule_oracle.infer, proof, context)
            actual_ok, actual = outcome(candidate.infer, proof, context)
            test("raw_proof_differential", f"{i}:{j}",
                 actual_ok == expected_ok and (not actual_ok or actual == expected))

    for directory in corpus:
        root = Path(directory)
        for path in sorted(root.rglob("*.json")):
            data = json.loads(path.read_text())
            accepted, value = outcome(candidate.check, data)
            independently_accepted, trace = outcome(rule_oracle.check, data)
            test("translated_corpus", f"{root.name}/{path.relative_to(root)}",
                 accepted and value is True and independently_accepted)
            if independently_accepted:
                rule_counts.update(trace)
            corpus_records.append({"directory": root.name, "file": str(path.relative_to(root)),
                                   "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                                   "accepted": accepted, "oracle": independently_accepted,
                                   "proof_nodes": sum(trace.values()) if independently_accepted else 0})

    if legacy_negative_directory is not None:
        root = Path(legacy_negative_directory)
        manifest = json.loads((root / "manifest.json").read_text())
        for record in manifest["records"]:
            if record["expected"]:
                continue
            path = root / record["file"]
            require_hash = hashlib.sha256(path.read_bytes()).hexdigest() == record["sha256"]
            accepted, _ = outcome(candidate.check, json.loads(path.read_text()))
            test("unchanged_legacy_negative", record["name"], require_hash and not accepted)

    cli_cases = [
        ("valid", json.dumps([[TRUE], TRUE, 0]), True),
        ("falsity", json.dumps([[], FALSE, 0]), False),
        ("null", "null", False),
        ("truncated", "[", False),
        ("nan_goal", '[[["=",0,0]],["=",NaN,0],0]', False),
        ("infinite_context", '[[["=",Infinity,0]],["=",0,0],0]', False),
        ("float_index", '[[["=",0,0]],["=",0,0],0.0]', False),
        ("boolean_index", '[[["=",0,0]],["=",0,0],false]', True),
        ("string_context", '["x",["=",0,0],0]', False),
        ("dictionary_context", '[{},["=",0,0],0]', False),
    ]
    with tempfile.TemporaryDirectory(prefix="ipra-audit-") as temp:
        for name, contents, expected in cli_cases:
            path = Path(temp) / (name + ".json")
            path.write_text(contents)
            for options, category in (([], "json_cli"), (["-O"], "optimized_json_cli")):
                result = subprocess.run([sys.executable, *options, str(candidate_path), str(path)],
                                        capture_output=True, text=True, timeout=20)
                test(category, name, result.returncode == (0 if expected else 1)
                     and result.stdout.strip() == ("ACCEPT" if expected else "REJECT"))
        for options, category in (([], "json_cli"), (["-O"], "optimized_json_cli")):
            for arguments, name in (([], "missing filename"), ([str(path), str(path)], "extra filename"),
                                    ([str(Path(temp)/"missing.json")], "nonexistent filename")):
                result = subprocess.run([sys.executable, *options, str(candidate_path), *arguments],
                                        capture_output=True, text=True, timeout=20)
                test(category, name, result.returncode == 1 and result.stdout.strip() == "REJECT")

    report = {"candidate_filename": candidate_path.name,
              "candidate_sha256": hashlib.sha256(candidate_path.read_bytes()).hexdigest(),
              "audit_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "seed": 762941, "counts": dict(counts), "total": sum(counts.values()),
              "failures": failures, "rules_exercised": dict(rule_counts),
              "focused_certificates": certificate_records, "corpus": corpus_records,
              "limitations": "Finite implementation checks, not a formal proof of checker soundness. Raw old-format negatives supplement, rather than replace, format-specific scope and induction tests."}
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    Path(output).write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: report[k] for k in ("candidate_filename", "candidate_sha256", "counts", "total", "failures", "rules_exercised")}, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--corpus", action="append", default=[])
    parser.add_argument("--legacy-negative-directory")
    args = parser.parse_args()
    run(args.candidate, args.output, args.corpus, args.legacy_negative_directory)
