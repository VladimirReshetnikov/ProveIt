"""Untrusted equivalence translation for the frozen curried predecessor.

The source kernel has formula hypothesis leaves and a curried numerical
premise. The target has integer leaves and a local numerical premise.
Both kernels infer existential-elimination conclusions. All inputs and
outputs are rechecked; no acceptance kernel imports this module.
"""


def numerical_guard(matrix, kernel):
    return matrix if matrix[0] == "=" else kernel.subst(matrix, [-1, 0])


def lift(proof, context, kernel, amount=1, depth=0):
    """Raise outer numeric parameters while preserving proof-local binders.

    `context` is the original, unshifted context at this recursion node.
    Formula hypotheses permit weakening by an arbitrary added assumption.
    Expression-internal binders are handled by the source substitution.
    """
    def expression(value, formula=True, extra=0):
        return kernel.subst(value, (amount,), d=depth + extra, formula=formula)

    match proof:
        case ["lam", a, q]:
            local = [*map(kernel.subst, context), a]
            return ["lam", expression(a, extra=1),
                    lift(q, local, kernel, amount, depth + 1)]
        case ["pack", a, q]:
            local = [*map(kernel.subst, context),
                     ["=", 0, kernel.subst(a, formula=False)]]
            return ["pack", expression(a, formula=False),
                    lift(q, local, kernel, amount, depth + 1)]
        case ["use", p, *args]:
            major = kernel.infer(p, context)
            lifted_major = lift(p, context, kernel, amount, depth)
            if major[0] == "ex":
                q, = args
                local = [*map(kernel.subst, context), major[1]]
                return ["use", lifted_major,
                        lift(q, local, kernel, amount, depth + 1)]
            a, q = args
            return ["use", lifted_major,
                    expression(a, formula=major[0] != "pi",
                               extra=int(major[0] == "=")),
                    lift(q, context, kernel, amount, depth)]
        case ["r", _, _, _]:
            return expression(proof, formula=False)
        case ["nat", a, q]:
            return ["nat", expression(a, extra=1),
                    lift(q, context, kernel, amount, depth)]
        case _:
            return expression(context[context.index(proof)])


def to_fused(data, source, target):
    """Translate every accepted source certificate, including non-lambda steps."""
    source.check(data)

    def convert(proof, context):
        match proof:
            case [("lam" | "pack") as tag, a, q]:
                h = a if tag == "lam" else ["=", 0, source.subst(a, formula=False)]
                return [tag, a, convert(q, [*map(source.subst, context), h])]
            case ["use", p, *args]:
                major = source.infer(p, context)
                converted_major = convert(p, context)
                if major[0] == "ex":
                    q, = args
                    return ["use", converted_major,
                            convert(q, [*map(source.subst, context), major[1]])]
                a, q = args
                return ["use", converted_major, a, convert(q, context)]
            case ["r", _, _, _]:
                return proof
            case ["nat", a, q]:
                h = numerical_guard(a, source)
                local = [*map(source.subst, context), h]
                body = ["use", lift(q, context, source), 0, h]
                return ["nat", a, convert(body, local)]
            case _:
                return context.index(proof)

    g, a, p = data
    translated = [g, a, convert(p, g)]
    target.check(translated)
    return translated


def to_curried(data, source, target):
    """Translate every accepted target certificate back to source syntax."""
    target.check(data)

    def convert(proof, context):
        match proof:
            case [("lam" | "pack" | "nat") as tag, a, q]:
                h = ["=", 0, target.subst(a, formula=False)] if tag == "pack" else a
                if tag == "nat":
                    h = numerical_guard(a, target)
                local = [*map(target.subst, context), h]
                body = convert(q, local)
                return [tag, a, ["lam", h, body] if tag == "nat" else body]
            case ["use", p, *args]:
                major = target.infer(p, context)
                converted_major = convert(p, context)
                if major[0] == "ex":
                    q, = args
                    return ["use", converted_major,
                            convert(q, [*map(target.subst, context), major[1]])]
                a, q = args
                return ["use", converted_major, a, convert(q, context)]
            case ["r", _, _, _]:
                return proof
            case _:
                return context[proof]

    g, a, p = data
    translated = [g, a, convert(p, g)]
    source.check(translated)
    return translated
