"""Offline, reproducible verification of the delivered comparison and tests."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(script, *args):
    result = subprocess.run([sys.executable, str(ROOT / script), *map(str, args)],
                            cwd=ROOT, text=True, capture_output=True)
    if result.returncode:
        print(result.stdout)
        print(result.stderr, file=sys.stderr)
        raise SystemExit(result.returncode)
    return result.stdout


def main():
    metrics = json.loads(run('comparison/measure.py', '--candidate', ROOT / 'checker.py'))
    if not all(metrics['candidate_strictly_below'].values()):
        raise SystemExit('Strict improvement failed on at least one recorded measure.')
    run('ablation/build_ablation.py')
    run('validation/independent/validate.py', '--checker', ROOT / 'checker.py')
    summary = json.loads((ROOT / 'validation/independent/summary.json').read_text())
    if summary['status'] != 'passed':
        raise SystemExit('Independent validation failed.')
    result = {'status': 'passed', 'snapshot_commit': metrics['snapshot_commit'],
              'candidate': metrics['candidate'],
              'complete_envelope': metrics['complete_envelope'],
              'comparison_sources': metrics['verified_source_count'],
              'independent_validation': summary,
              'ablation_smoke_checks': 56}
    (ROOT / 'verification_summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
