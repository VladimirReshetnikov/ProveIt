"""Measure the entire candidate and frozen current-draft comparison corpus.

No compared program is imported or executed. Run with CPython 3.12.14 for
the recorded normalization; each run measures all sources on the same runtime.

    python3 comparison/measure.py --candidate checker.py --output metrics.json
"""

import argparse
import ast
import copy
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize


ROOT = Path(__file__).resolve().parent
FIELDS = ("source_tokens", "normalized_tokens", "ast_nodes", "normalized_bytes", "raw_bytes")
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}


def docstrings(tree):
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if node.body and isinstance(node.body[0], ast.Expr):
                value = node.body[0].value
                if isinstance(value, ast.Constant) and isinstance(value.value, str):
                    yield node.body[0]


def tokens(source, omitted=()):
    return sum(item.type not in IGNORED and not any(
        start <= item.start and item.end <= end for start, end in omitted)
        for item in tokenize.generate_tokens(io.StringIO(source).readline))


def measure(path):
    data = path.read_bytes()
    source = data.decode("utf-8")
    original = ast.parse(source, filename=str(path))
    spans = [((node.lineno, node.col_offset), (node.end_lineno, node.end_col_offset))
             for node in docstrings(original)]
    stripped = copy.deepcopy(original)
    omitted = {id(node) for node in docstrings(stripped)}
    for node in ast.walk(stripped):
        if hasattr(node, "body") and isinstance(node.body, list):
            node.body = [child for child in node.body if id(child) not in omitted]
    normalized = ast.unparse(stripped) + "\n"
    return {"sha256": hashlib.sha256(data).hexdigest(),
            "source_tokens": tokens(source, spans),
            "normalized_tokens": tokens(normalized),
            "ast_nodes": sum(1 for _ in ast.walk(stripped)),
            "normalized_bytes": len(normalized.encode("utf-8")),
            "raw_bytes": len(data)}


def envelope(rows):
    return {field: min(row[field] for row in rows) for field in FIELDS}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--require-strict-improvement", action="store_true")
    args = parser.parse_args()
    manifest_path = ROOT / "manifest.json"
    manifest = json.loads(manifest_path.read_text())
    measured = {}
    for path in sorted((ROOT / "sources").glob("*.py")):
        row = measure(path)
        if path.stem != row["sha256"]:
            raise ValueError("Frozen source hash mismatch: " + path.name)
        measured[path.stem] = row
    census = [{**measured[row["sha256"]], "occurrences": len(row["origins"])}
              for row in manifest["census"]["sources"]]
    if len(census) != manifest["census"]["unique_sources"]:
        raise ValueError("Census length mismatch")
    if sum(row["occurrences"] for row in census) != manifest["census"]["source_occurrences"]:
        raise ValueError("Census occurrence mismatch")
    primary = [{"archive": row["archive"], **measured[row["sha256"]]}
               for row in manifest["primary"]]
    additional = [measured[row["sha256"]] for row in manifest["additional_standalone"]]
    groups = []
    for group in manifest["historical_groups"]:
        sources = [measured[row["sha256"]] for row in group["files"]]
        groups.append({"id": group["id"], "label": group["label"],
                       **{field: sum(row[field] for row in sources) for field in FIELDS}})
    lower = envelope(census + additional + groups)
    candidate = measure(args.candidate)
    result = {"snapshot": manifest["snapshot"], "python_version": platform.python_version(),
              "metric_definitions": manifest["metric_definitions"],
              "manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
              "frozen_source_count": len(measured), "census_source_count": len(census),
              "census_occurrences": sum(row["occurrences"] for row in census),
              "additional_standalone_count": len(additional), "historical_group_count": len(groups),
              "primary": primary, "census": census, "historical_groups": groups,
              "additional_standalone": additional, "lower_envelope": lower,
              "candidate": {"filename": args.candidate.name, **candidate},
              "candidate_at_or_below": {field: candidate[field] <= lower[field] for field in FIELDS},
              "candidate_strictly_below": {field: candidate[field] < lower[field] for field in FIELDS},
              "savings": {field: lower[field] - candidate[field] for field in FIELDS},
              "savings_percent": {field: 100 * (1 - candidate[field] / lower[field]) for field in FIELDS},
              "qualification": manifest["qualification"]}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in ("python_version", "frozen_source_count", "lower_envelope",
                                                  "candidate", "candidate_strictly_below", "savings_percent")}, indent=2))
    if args.require_strict_improvement and not all(result["candidate_strictly_below"].values()):
        raise SystemExit("Candidate is not strictly below every coordinate of the finite envelope")


if __name__ == "__main__":
    main()
