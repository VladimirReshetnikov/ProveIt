"""Untrusted certificate repair for the raw kernel's raw recursor equations.

Normalize numerical syntax and restore the shared-transition proof syntax.
The target is the exact frozen shared-transition checker, which still
validates every recursor axiom in full. No checker imports this module.
"""
import importlib.util
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


raw = load('raw_kernel', ROOT / 'checker.py')
reference = load('frozen_shared', ROOT / 'strict_shared.py')
eager = load('frozen_eager', ROOT / 'strict_eager.py')


def term(a):
    """Total retraction on finite JSON terms, compatible with Python ==."""
    if isinstance(a, int):
        return int(a) if a >= -1 else -1
    if isinstance(a, float) and math.isfinite(a) and a.is_integer():
        return int(a) if a >= -1 else -1
    if isinstance(a, list):
        if len(a) == 2 and a[0] == 's':
            return ['s', term(a[1])]
        if len(a) == 4 and a[0] == 'r':
            return ['r', *(term(t) for t in a[1:])]
    return -1


def formula(a):
    """Retract a formula whose logical tree is sound but terms may be raw."""
    match a:
        case ['=', s, t]:
            return ['=', term(s), term(t)]
        case ['pi', a, b]:
            return ['pi', formula(a), formula(b)]
        case ['ex', a]:
            return ['ex', formula(a)]
    raise ValueError('not even a weak formula')


def repair(p, g):
    """Return a strict shared-transition proof of formula(raw.infer(p,g))."""
    match p:
        case [('lam' | 'pack' | 'nat') as tag, a, q]:
            guard = ['=', 0, raw.subst(a, formula=False)] if tag == 'pack' else a
            base = raw.subst(guard, [-1, 0] if tag == 'nat' else (0,))
            h = guard if guard[0] == '=' else base
            local = [*map(raw.subst, g), h]
            return [tag, a, repair(q, local)]
        case ['r', -1, a, h]:
            return ['r', -1, term(a), term(h)]
        case ['r', ['s', n], a, h]:
            return ['r', ['s', term(n)], term(a), term(h)]
        case [major, *args]:
            tag, *parts = raw.infer(major, g)
            major = repair(major, g)
            if tag == 'ex':
                (minor,) = args
                local = [*map(raw.subst, g), *parts]
                return ['use', major, repair(minor, local)]
            a, minor = args
            if tag == 'pi':
                a = term(a)
            return ['use', major, a, repair(minor, g)]
        case _:
            return int(p)


def normalize(data):
    """Validate source and target; preserve exact context and conclusion."""
    g, a, p = data
    raw.check(g, a, p)
    target = [g, a, repair(p, g)]
    reference.check(target)
    eager.check(target)
    return target


if __name__ == '__main__':
    import sys
    source, destination = map(Path, sys.argv[1:])
    target = normalize(json.loads(source.read_text()))
    destination.write_text(json.dumps(target, separators=(',', ':')) + '\n')
    print('SOURCE AND REPAIRED TARGET ACCEPTED')
