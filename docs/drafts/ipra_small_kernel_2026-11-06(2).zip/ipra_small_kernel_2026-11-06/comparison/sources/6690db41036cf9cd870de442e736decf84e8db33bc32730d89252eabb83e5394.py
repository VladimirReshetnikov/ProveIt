"""Reproduce inherited regressions, proof repair, and normal/-O CLI checks.

Run from any working directory. No network, repository checkout, third-party
package, or external proof generator is needed. All support is untrusted;
checker.py imports only json and sys.
"""
import hashlib
import json
import platform
import subprocess
import sys
import tempfile
from pathlib import Path

import raw_checks
import repair
import translate

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'results'


def expect(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encode(data):
    return (json.dumps(data, separators=(',', ':')) + '\n').encode()


def accepts(checker, data, unpack=False):
    try:
        checker.check(*data) if unpack else checker.check(data)
        return True
    except Exception:
        return False


def inherited():
    provenance = json.loads((ROOT / 'provenance.json').read_text())
    for filename, key in [('checker.py', 'candidate_checker_sha256'),
                          ('strict_shared.py', 'strict_checker_sha256'),
                          ('strict_eager.py', 'eager_checker_sha256')]:
        expect(digest((ROOT / filename).read_bytes()) == provenance[key],
               'Frozen checker hash changed: ' + filename)
    rows = []
    for item in provenance['fixtures']:
        data_bytes = (ROOT / item['file']).read_bytes()
        expect(digest(data_bytes) == item['sha256'], 'Changed fixture: ' + item['name'])
        source = json.loads(data_bytes)
        strict_ok = accepts(repair.reference, source)
        expect(strict_ok == item['strict_expected'], 'Strict regression: ' + item['name'])
        eager_ok = accepts(repair.eager, source)
        expect(eager_ok == item['eager_expected'], 'Eager regression: ' + item['name'])
        g, a, p = source
        target = [g, a, translate.proof_forward(p)]
        raw_ok = accepts(repair.raw, target, unpack=True)
        expect(raw_ok == item['raw_expected'], 'Raw regression: ' + item['name'])
        repaired_hash = None
        if raw_ok:
            repaired = translate.backward(target)
            expect(repaired[:2] == source[:2], 'Backward public sequent changed')
            repaired_hash = digest(encode(repaired))
            roundtrip = translate.forward(repaired)
            expect(roundtrip[:2] == source[:2], 'Forward public sequent changed')
        if strict_ok:
            forward = translate.forward(source)
            expect(forward[:2] == source[:2], 'Strict forward public sequent changed')
        rows.append({'name': item['name'], 'group': item['group'],
                     'strict_source_accepted': strict_ok,
                     'eager_source_accepted': eager_ok,
                     'raw_accepted': raw_ok,
                     'repaired_to_both_oracles': raw_ok,
                     'repaired_sha256': repaired_hash})
    extension = [r['name'] for r in rows if r['raw_accepted'] != r['strict_source_accepted']]
    expect(extension == ['unused_bad_recursor_body'], 'Unexpected acceptance extension')
    result = {'status': 'passed', 'fixtures': len(rows),
              'strict_source_accepted': sum(r['strict_source_accepted'] for r in rows),
              'eager_source_accepted': sum(r['eager_source_accepted'] for r in rows),
              'raw_accepted_and_repaired': sum(r['raw_accepted'] for r in rows),
              'raw_rejected': sum(not r['raw_accepted'] for r in rows),
              'intentional_acceptance_extension': extension, 'rows': rows}
    (RESULTS / 'inherited.json').write_text(json.dumps(result, indent=2) + '\n')
    return {k: v for k, v in result.items() if k != 'rows'}


def command_line():
    manifest = json.loads((ROOT / 'examples/manifest.json').read_text())
    rows = []
    with tempfile.TemporaryDirectory(prefix='ipra-raw-kernel-') as temp:
        temporary = Path(temp)
        for optimized in (False, True):
            flags = ['-O'] if optimized else []
            for example in manifest:
                path = ROOT / example['file']
                expect(digest(path.read_bytes()) == example['sha256'], 'Example hash changed')
                checkers = ['checker.py'] if example['checker'] == 'raw' else ['strict_shared.py', 'strict_eager.py']
                for filename in checkers:
                    result = subprocess.run([sys.executable, *flags, str(ROOT / filename), str(path)],
                                            cwd=temporary, text=True, capture_output=True, timeout=15)
                    want = 'ACCEPT\n' if example['expected'] else 'REJECT\n'
                    expect(result.stdout == want and result.returncode == (0 if example['expected'] else 1),
                           'CLI mismatch: ' + example['name'] + ', ' + filename)
                    expect(not result.stderr, 'Unexpected CLI error text')
                    rows.append({'name': example['name'], 'checker': filename,
                                 'optimized': optimized, 'accepted': example['expected']})
            for name, text in [('malformed_json', '[[], '),
                               ('invalid_context_envelope', '[{}, ["=",-1,-1], 0]')]:
                path = temporary / (name + '.json')
                path.write_text(text)
                result = subprocess.run([sys.executable, *flags, str(ROOT / 'checker.py'), str(path)],
                                        cwd=temporary, text=True, capture_output=True, timeout=15)
                expect(result.returncode == 1 and result.stdout == 'REJECT\n' and not result.stderr,
                       'Parser/envelope rejection changed')
                rows.append({'name': name, 'checker': 'checker.py', 'optimized': optimized, 'accepted': False})
            for direction, name in [('forward', 'repaired_unused_body'), ('backward', 'raw_unused_body')]:
                source = ROOT / 'examples' / (name + '.json')
                destination = temporary / (direction + '.json')
                result = subprocess.run([sys.executable, *flags, str(ROOT / 'translate.py'),
                                         direction, str(source), str(destination)],
                                        cwd=temporary, text=True, capture_output=True, timeout=15)
                expect(result.returncode == 0 and not result.stderr, 'Translation CLI failed')
                before = json.loads(source.read_text())
                after = json.loads(destination.read_text())
                expect(after[:2] == before[:2], 'CLI translation changed public statement')
                repair.raw.check(*after) if direction == 'forward' else repair.eager.check(after)
                rows.append({'name': direction, 'checker': 'translate.py',
                             'optimized': optimized, 'accepted': True})
    result = {'status': 'passed', 'process_checks': len(rows),
              'normal_checks': sum(not r['optimized'] for r in rows),
              'optimized_checks': sum(r['optimized'] for r in rows), 'rows': rows}
    (RESULTS / 'cli.json').write_text(json.dumps(result, indent=2) + '\n')
    return {k: v for k, v in result.items() if k != 'rows'}


def main():
    RESULTS.mkdir(exist_ok=True)
    first = inherited()
    focused = raw_checks.run(RESULTS / 'raw_checks.json')
    focused = {k: v for k, v in focused.items() if k != 'rows'}
    cli = command_line()
    result = {'status': 'passed', 'python_version': platform.python_version(),
              'python_implementation': platform.python_implementation(),
              'candidate_sha256': digest((ROOT / 'checker.py').read_bytes()),
              'strict_shared_sha256': digest((ROOT / 'strict_shared.py').read_bytes()),
              'strict_eager_sha256': digest((ROOT / 'strict_eager.py').read_bytes()),
              'inherited': first, 'focused_raw_checks': focused, 'command_line': cli,
              'qualification': 'Finite regression and reconstruction evidence; no proof-assistant certification of the general metatheorem.'}
    (RESULTS / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
