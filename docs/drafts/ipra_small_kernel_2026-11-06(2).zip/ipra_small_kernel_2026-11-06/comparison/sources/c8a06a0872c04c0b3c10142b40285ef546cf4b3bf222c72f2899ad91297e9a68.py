"""Independent hostile-JSON audit of the proposed raw-recursor checker.

This audit tests accepted statements against the supplied repair and frozen
strict-recursor control. It is not a formal soundness proof.
"""

import copy
import importlib.util
import itertools
import json
from pathlib import Path
import random

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


repair = load("raw_repair_audit", ROOT / "repair.py")
raw = repair.raw
strict = repair.reference
T = ["=", -1, -1]
F = ["=", -1, ["s", -1]]
values = [None, False, True, -3, -2, -1, 0, 1, 2, -1.0, 0.0, 1.0,
          2.0, 0.5, -2.5, "", "s", "r", "pi", [], {}, {"s": 0},
          ["s"], ["s", -1], ["s", False], ["s", 0, 1],
          ["r", -1, -1, -1], ["r", -1, 0, None],
          ["ex", T], ["pi", T, T], ["=", -1, -1]]
updates = [-1, 0, 1, 2, ["s", 0], ["s", 1],
           ["r", -1, 2, 1], ["r", 1, -1, 0],
           ["r", 0, 1, 2], None, False, 0.0]
counts = {}
failures = []
accepted_samples = []


def accepted(data):
    try:
        raw.check(*data)
        return True
    except Exception:
        return False


def inspect(label, data, expected=None):
    counts[label] = counts.get(label, {"cases": 0, "acceptances": 0})
    counts[label]["cases"] += 1
    yes = accepted(data)
    counts[label]["acceptances"] += yes
    if expected is not None and yes != expected:
        failures.append({"label": label, "reason": "wrong acceptance", "data": data,
                         "expected": expected, "accepted": yes})
    if yes:
        try:
            target = repair.normalize(data)
            if target[:2] != data[:2]:
                raise ValueError("changed sequent")
        except Exception as error:
            failures.append({"label": label, "reason": repr(error), "data": data})
        if len(accepted_samples) < 20:
            accepted_samples.append({"label": label, "data": data})


def raw_eq_proofs():
    for z, a, h in itertools.product((-1, -1.0), values, values):
        yield ["r", z, a, h]
    for n, a, h in itertools.product(values, values, updates):
        yield ["r", ["s", n], a, h]


def path_nodes(value, path=()):
    yield path, value
    if type(value) is list:
        for i, child in enumerate(value):
            yield from path_nodes(child, path + (i,))


def replaced(value, path, replacement):
    if not path:
        return copy.deepcopy(replacement)
    result = copy.deepcopy(value)
    current = result
    for index in path[:-1]:
        current = current[index]
    current[path[-1]] = copy.deepcopy(replacement)
    return result


def convert(proof):
    match proof:
        case [("lam" | "pack" | "nat") as tag, a, q]:
            return [tag, a, convert(q)]
        case ["use", p, *args]:
            if len(args) == 1:
                return [convert(p), convert(args[0])]
            a, q = args
            return [convert(p), a, convert(q)]
        case _:
            return proof


def main():
    # No semantic effect may arise when the equality motive ignores its input.
    for p in raw_eq_proofs():
        inspect("vacuous_equality_transport", [[T], T, [p, T, 0]])
        # The theorem request sees a canonicalized statement, so any numeric
        # equality aliases surviving the final comparison are exercised.
        try:
            goal = repair.formula(raw.infer(p, []))
        except Exception:
            continue
        inspect("canonical_statement_of_raw_equation", [[], goal, p])
        # Existential elimination may discard a raw local equation but must
        # still satisfy deletion of the eigenvariable from the conclusion.
        packed = ["pack", -1, p]
        inspect("discard_raw_existential_assumption", [[T], T, [packed, 0]])
        inspect("transport_from_raw_existential_assumption", [[T], T, [packed, [-1, T, 0]]])

    # Scope deletion must not treat numeric aliases as absent eigenvariables.
    for alias in (0, False, 0.0):
        p = ["pack", -1, ["r", -1, alias, -1]]
        inspect("eigenvariable_escape", [[], ["=", -1, -1], [p, 0]], False)
    # Strict formation remains obligatory at the public sequent boundary.
    for bad in (False, True, -1.0, 0.0, 1.0, None, [], {}, ["pi", T]):
        goal = ["=", bad, bad]
        p = ["r", -1, bad, -1]
        inspect("malformed_goal", [[], goal, p], False)
        inspect("malformed_context", [[goal], goal, 0], False)

    # Random mutations of real quantified/inductive certificates probe mixed
    # scopes and the raw-equation path. Every accepted mutation is replayed.
    manifest = json.loads((ROOT / "provenance.json").read_text())
    fixtures = []
    for item in manifest["fixtures"]:
        if item["strict_expected"]:
            g, a, p = json.loads((ROOT / item["file"]).read_text())
            fixtures.append([g, a, convert(p)])
    rng = random.Random(20261106)
    for _ in range(30000):
        g, a, p = copy.deepcopy(rng.choice(fixtures))
        nodes = list(path_nodes(p))
        path, current = rng.choice(nodes)
        replacement = rng.choice(values + [p, ["r", -1, current, None]])
        p = replaced(p, path, replacement)
        inspect("real_certificate_mutation", [g, a, p])

    report = {"status": "passed" if not failures else "failed", "counts": counts,
              "total_cases": sum(r["cases"] for r in counts.values()),
              "total_acceptances_repaired": sum(r["acceptances"] for r in counts.values()),
              "failures": failures, "accepted_samples": accepted_samples,
              "limitation": "Finite hostile-input audit of statement-preserving replay, not a formal soundness proof."}
    OUT.mkdir(exist_ok=True)
    (OUT / "adversarial.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: report[k] for k in ("status", "total_cases", "total_acceptances_repaired", "counts")}, indent=2))
    if failures:
        print(json.dumps(failures[:5], indent=2))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
