"""Reproduce the complete finite source comparison and certificate audits."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pdf', action='store_true')
    args = parser.parse_args()
    commands = [
        ['comparison/measure.py'],
        ['validation/roundtrip.py'],
        ['validation/goal_audit.py', '--checker', 'checker.py',
         '--output', 'results/goal_audit_demand.json', '--corpus', 'validation/goal_corpus'],
        ['validation/goal_audit.py', '--checker', 'strict_checker.py', '--strict-witness',
         '--output', 'results/goal_audit_strict.json', '--corpus', 'validation/strict_corpus'],
        ['report_numbers.py'],
    ]
    if args.pdf:
        commands.append(['build.py'])
    for command in commands:
        subprocess.run([sys.executable, *command], cwd=ROOT, check=True)
    metrics = json.loads((ROOT / 'results/metrics.json').read_text())
    primary_audit = json.loads((ROOT / 'results/goal_audit_demand.json').read_text())
    strict_audit = json.loads((ROOT / 'results/goal_audit_strict.json').read_text())
    roundtrip = json.loads((ROOT / 'validation/roundtrip_results.json').read_text())
    for filename, audit, key in [
        ('checker.py', primary_audit, 'candidate'),
        ('strict_checker.py', strict_audit, 'strict_candidate')
    ]:
        actual = hashlib.sha256((ROOT / filename).read_bytes()).hexdigest()
        if actual != audit['checker_sha256'] or actual != metrics[key]['sha256'] or audit['failures']:
            raise ValueError('Evidence does not agree with final checker: ' + filename)
    summary = {
        'status': 'passed', 'python': sys.version.split()[0],
        'primary_sha256': metrics['candidate']['sha256'],
        'strict_sha256': metrics['strict_candidate']['sha256'],
        'primary_strictly_below': metrics['strictly_below'],
        'strict_variant_below': metrics['strict_variant_below'],
        'roundtrip': roundtrip['summary'],
        'primary_independent_checks': primary_audit['total_checks'],
        'strict_independent_checks': strict_audit['total_checks'],
        'qualification': 'Finite executable evidence; mathematical proofs are in report.pdf.'
    }
    (ROOT / 'results/reproduction.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
