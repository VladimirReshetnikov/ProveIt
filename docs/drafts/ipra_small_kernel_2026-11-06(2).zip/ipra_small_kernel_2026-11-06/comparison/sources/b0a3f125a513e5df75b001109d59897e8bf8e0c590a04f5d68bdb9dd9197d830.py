"""Build a deterministic ZIP and checksum manifest of the deliverable."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
OMIT_ROOT = {'report.aux', 'report.log', 'report.out', 'report.toc', 'report.fls',
             'report.fdb_latexmk', 'report.synctex.gz'}


def files():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and '__pycache__' not in p.relative_to(ROOT).parts
                  and p.suffix != '.pyc'
                  and not (p.parent == ROOT and p.name in OMIT_ROOT))


def main():
    manifest = ROOT / 'MANIFEST.sha256'
    included = [p for p in files() if p != manifest]
    manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' +
                                p.relative_to(ROOT).as_posix() + '\n' for p in included))
    archive = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for path in files():
            name = ROOT.name + '/' + path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 6, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            output.writestr(info, path.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(archive) as result:
        if result.testzip() is not None:
            raise ValueError('Archive CRC validation failed.')
        for line in manifest.read_text().splitlines():
            expected, name = line.split('  ', 1)
            actual = hashlib.sha256(result.read(ROOT.name + '/' + name)).hexdigest()
            if actual != expected:
                raise ValueError('Archive content hash mismatch: ' + name)
    print('Archive:', archive)
    print('Files:', len(files()))
    print('Bytes:', archive.stat().st_size)
    print('SHA-256:', hashlib.sha256(archive.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
