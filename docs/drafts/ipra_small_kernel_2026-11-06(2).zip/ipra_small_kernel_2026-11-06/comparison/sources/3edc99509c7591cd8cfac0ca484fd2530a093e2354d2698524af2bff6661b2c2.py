"""Recompute the measurements and independent audits without network access."""

import argparse
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent


def run(*arguments):
    subprocess.run([sys.executable, *arguments], cwd=ROOT, check=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf", action="store_true", help="Also build report.pdf using pdfLaTeX")
    args = parser.parse_args()
    run("comparison/measure.py", "--candidate", "checker.py", "--output", "results/metrics.json",
        "--require-strict-improvement")
    run("validation/run.py", "--candidate", "checker.py", "--output", "results/validation.json",
        "--corpus", "validation/corpus", "--legacy-negative-directory", "validation/legacy_negative")
    run("validation/replay.py")
    metrics = json.loads((ROOT / "results/metrics.json").read_text())
    validation = json.loads((ROOT / "results/validation.json").read_text())
    replay = json.loads((ROOT / "results/replay.json").read_text())
    if validation["failures"] or replay["failed"]:
        raise SystemExit("A verification step failed")
    report = {"status": "passed", "candidate": metrics["candidate"],
              "strict_improvement": metrics["candidate_strictly_below"],
              "independent_checks": validation["total"],
              "positive_corpus": validation["counts"]["translated_corpus"],
              "bidirectional_replay": replay["passed"],
              "non_lambda_numerical_steps": len(replay["non_lambda_numerical_steps"])}
    (ROOT / "results/reproduction.json").write_text(json.dumps(report, indent=2) + "\n")
    if args.pdf:
        run("build.py")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
