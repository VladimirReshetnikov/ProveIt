"""Read every Python source from the six pinned ZIP archives without execution.

The included logical acceptance corpus is the union of self-contained
standalone checkers and the historical dependency groups explicitly declared
in the input manifests. Support programs remain in the complete inventory.
"""

import argparse
import ast
import copy
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize
import zipfile

ROOT = Path(__file__).resolve().parent
FIELDS = ("source_tokens", "normalized_tokens", "ast_nodes", "normalized_bytes", "raw_bytes")
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}


def docstrings(tree):
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if node.body and isinstance(node.body[0], ast.Expr):
                value = node.body[0].value
                if isinstance(value, ast.Constant) and isinstance(value.value, str):
                    yield node.body[0]


def tokens(source, omitted=()):
    return sum(item.type not in IGNORED and not any(
        start <= item.start and item.end <= end for start, end in omitted)
        for item in tokenize.generate_tokens(io.StringIO(source).readline))


def measure(data):
    source = data.decode("utf-8")
    tree = ast.parse(source)
    spans = [((n.lineno, n.col_offset), (n.end_lineno, n.end_col_offset))
             for n in docstrings(tree)]
    stripped = copy.deepcopy(tree)
    omitted = {id(n) for n in docstrings(stripped)}
    for node in ast.walk(stripped):
        if hasattr(node, "body") and isinstance(node.body, list):
            node.body = [child for child in node.body if id(child) not in omitted]
    normalized = ast.unparse(stripped) + "\n"
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(a.name for a in node.names)
        if isinstance(node, ast.ImportFrom):
            imports.append(node.module)
    return {
        "sha256": hashlib.sha256(data).hexdigest(),
        "normalized_sha256": hashlib.sha256(normalized.encode()).hexdigest(),
        "source_tokens": tokens(source, spans),
        "normalized_tokens": tokens(normalized),
        "ast_nodes": sum(1 for _ in ast.walk(stripped)),
        "normalized_bytes": len(normalized.encode()),
        "raw_bytes": len(data),
        "raw_lines": len(source.splitlines()),
        "functions": sorted(n.name for n in tree.body if isinstance(n, ast.FunctionDef)),
        "classes": sorted(n.name for n in tree.body if isinstance(n, ast.ClassDef)),
        "imports": sorted(set(imports)),
        "has_main_branch": any(isinstance(n, ast.If)
                               and isinstance(n.test, ast.Compare)
                               and isinstance(n.test.left, ast.Name)
                               and n.test.left.id == "__name__"
                               and any(isinstance(c, ast.Constant) and c.value == "__main__"
                                       for c in n.test.comparators)
                               for n in tree.body),
    }


def envelope(rows):
    return {f: min(r[f] for r in rows) for f in FIELDS}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archives", type=Path, help="Directory containing the six pinned ZIP archives")
    parser.add_argument("--out", type=Path, default=ROOT / "rebuilt")
    args = parser.parse_args()
    OUT = args.out
    snapshot = json.loads((ROOT / "snapshot.json").read_text())
    source_data = {}
    inventory = {}
    archives = []
    manifests = []
    primary = []
    occurrences = 0
    for item in snapshot["entries"]:
        archive_path = args.archives / item["name"]
        data = archive_path.read_bytes()
        blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        if blob != item["sha"]:
            raise ValueError("Archive Git blob mismatch: " + item["name"])
        archives.append({"name": item["name"], "repository_path": item["path"],
                         "git_blob_sha1": blob, "bytes": len(data),
                         "sha256": hashlib.sha256(data).hexdigest()})
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            for member in archive.namelist():
                if member.endswith("/comparison/manifest.json"):
                    manifests.append((item["name"], member, json.loads(archive.read(member))))
                if not member.endswith(".py"):
                    continue
                source = archive.read(member)
                digest = hashlib.sha256(source).hexdigest()
                source_data[digest] = source
                if digest not in inventory:
                    inventory[digest] = {**measure(source), "origins": []}
                inventory[digest]["origins"].append({"archive": item["name"], "member": member})
                occurrences += 1
                if len(Path(member).parts) == 2 and Path(member).name == "checker.py":
                    primary.append({"archive": item["name"], "member": member, "sha256": digest})

    groups = {}
    declared_standalone = set()
    for archive_name, member, manifest in manifests:
        for entry in manifest.get("standalone", []):
            if isinstance(entry, str):
                declared_standalone.add(entry)
            elif isinstance(entry, dict):
                digest = entry.get("sha256", entry.get("metrics", {}).get("sha256"))
                if digest:
                    declared_standalone.add(digest)
        for group in manifest.get("historical_groups", []):
            if "members" in group:
                members = tuple(sorted(set(group["members"])))
            else:
                members = tuple(sorted({x["sha256"] for x in group["files"]}))
            for digest in members:
                if digest not in inventory:
                    raise ValueError("Missing dependency source: " + digest)
            row = groups.setdefault(members, {"members": list(members), "declarations": []})
            row["declarations"].append({"archive": archive_name, "member": member,
                                        "group": group})

    standalone = set()
    for digest, row in inventory.items():
        ordinary = {"infer", "check"} <= set(row["functions"])
        class_based = "Checker" in row["classes"]
        if (ordinary or class_based) and row["has_main_branch"] and set(row["imports"]) <= {"json", "sys"}:
            standalone.add(digest)

    grouped = {h for g in groups for h in g}
    selected = standalone | grouped
    for digest, row in inventory.items():
        roles = []
        if digest in standalone:
            roles.append("self_contained_standalone_checker")
        if digest in grouped:
            roles.append("declared_dependency_group_member")
        if not roles:
            roles.append("excluded_support_or_validation")
        row["roles"] = roles

    group_rows = []
    for i, (members, group) in enumerate(sorted(groups.items())):
        metrics = {f: sum(inventory[h][f] for h in members) for f in FIELDS}
        group_rows.append({"id": "historical_%03d" % i, **group, **metrics})
    standalone_rows = [inventory[h] for h in sorted(standalone)]
    primary_rows = [{**row, **{f: inventory[row["sha256"]][f] for f in FIELDS}} for row in primary]
    envelope_rows = standalone_rows + group_rows
    lower = envelope(envelope_rows)
    attaining = {f: [{"sha256": row["sha256"], "origins": row["origins"]}
                     for row in standalone_rows if row[f] == lower[f]] for f in FIELDS}
    result = {
        "repository": "VladimirReshetnikov/ProveIt",
        "commit": snapshot["head"],
        "directory": "docs/drafts",
        "python": platform.python_version(),
        "archives": archives,
        "python_occurrences": occurrences,
        "unique_python_sources": len(inventory),
        "standalone_count": len(standalone),
        "historical_group_count": len(groups),
        "multifile_historical_group_count": sum(len(g) > 1 for g in groups),
        "frozen_acceptance_source_count": len(selected),
        "excluded_support_source_count": len(inventory) - len(selected),
        "primary": primary_rows,
        "standalone": sorted(standalone),
        "historical_groups": group_rows,
        "lower_envelope": lower,
        "attaining_standalone_sources": attaining,
        "selection": "Every self-contained infer/check or declared class-based Checker module with a __main__ branch and only json/sys imports, plus all files in every declared historical acceptance dependency group.",
        "measurement_boundary": "Entire source including imports, JSON input, validation, inference and CLI rejection. For inherited groups use the sum of distinct original files exactly as declared; some explicitly favor old proposals by measuring a mathematical core without a CLI.",
        "qualification": "Finite implementation corpus, not an absolute minimum or a certification of historical mathematical correctness. Standalone and historical groups overlap. Auxiliary test interpreters, proof generators, build tools and measurement scripts are excluded from the envelope and retained in full_inventory.json.",
    }
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "sources").mkdir(exist_ok=True)
    (OUT / "excluded_support").mkdir(exist_ok=True)
    for digest in sorted(selected):
        (OUT / "sources" / (digest + ".py")).write_bytes(source_data[digest])
    for digest in sorted(inventory.keys() - selected):
        (OUT / "excluded_support" / (digest + ".py")).write_bytes(source_data[digest])
    (OUT / "metadata.json").write_text(json.dumps(result, indent=2) + "\n")
    (OUT / "full_inventory.json").write_text(json.dumps(inventory, indent=2) + "\n")
    print(json.dumps({k: result[k] for k in (
        "commit", "python_occurrences", "unique_python_sources", "standalone_count",
        "historical_group_count", "multifile_historical_group_count", "frozen_acceptance_source_count",
        "excluded_support_source_count", "lower_envelope")}, indent=2))


if __name__ == "__main__":
    main()
