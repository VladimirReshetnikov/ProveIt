"""Reconstruct four complete kernels from one exact current draft checker.

Untrusted reproduction code. Run from any directory with Python 3.11+.
No network, repository checkout, or third-party package is needed.
"""
import ast
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import sys

from measure import measure

ROOT = Path(__file__).resolve().parent
BASELINE_SHA = '672afaab345fa563807621166cf9f3b7604a8cf288fca145b8d8aed5b666648b'
FINAL_SHA = 'fb42aabb3bab4416094ed87286195b3a93de91c07d187cc8be4a2d6d5f9dc814'
HEADER = '''"""Complete iPRA checker. Finite JSON input: [goal, proof, *hypotheses].

Normal check() return means acceptance; an exception means rejection.
"""'''


def replace_once(source, old, new):
    if source.count(old) != 1:
        raise ValueError('Transformation does not have one source occurrence: ' + old)
    return source.replace(old, new)


def construct_final(baseline):
    source = replace_once(baseline,
        '    g, a, p = data\n    require(type(g) is list)',
        '    a, p, *g = data')
    source = replace_once(source,
        'case ["use", p, a, q]:', 'case [p, a, q]:')
    # A generic application must follow the specific recursor pattern.
    start = source.index('        case [p, a, q]:')
    end = source.index('        case ["r",', start)
    application = source[start:end]
    source = source[:start] + source[end:]
    end = source.index('        case _:')
    source = source[:end] + application + source[end:]
    source = replace_once(source,
        '''            lifted = subst(a, formula=tag != "pi")
            if tag == "ex":
                require(infer(q, [*map(subst, g), *parts]) == lifted)''',
        '''            if tag == "ex":
                require(infer(q, [*map(subst, g), *parts]) == subst(a))''')
    # Naming a fixed literal is accounted separately in the report.
    source = replace_once(source, 'ZERO = -1\n\n\n', '')
    source = source.replace('ZERO', '-1')
    source = replace_once(source, '            subst(r, formula=False)\n', '')
    source = replace_once(source, '            return ["=", r, b]',
                          '            return subst(["=", r, b], (0,))')
    end = source.index('"""', 3) + 3
    return HEADER + source[end:]


def variants(final):
    pre_fusion = replace_once(final,
        '        case ["r", n, a, h] as r:\n',
        '        case ["r", n, a, h] as r:\n            subst(r, formula=False)\n')
    pre_fusion = replace_once(pre_fusion,
        '            return subst(["=", r, b], (0,))',
        '            return ["=", r, b]')
    inferred = replace_once(final, 'case [p, a, q]:', 'case [p, *args]:')
    inferred = replace_once(inferred,
        '''            if tag == "ex":
                require(infer(q, [*map(subst, g), *parts]) == subst(a))
                return a''',
        '''            if tag == "ex":
                return subst(infer(*args, [*map(subst, g), *parts]), [None, -1])
            a, q = args''')
    tagged = replace_once(final, 'case [p, a, q]:', 'case ["use", p, a, q]:')
    return {'final.py': final, 'pre_fusion.py': pre_fusion,
            'inferred_ex.py': inferred, 'tagged_application.py': tagged}


def load(path):
    spec = importlib.util.spec_from_file_location('ablation_checker', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def smoke_cases(name):
    zero = -1
    truth = ['=', zero, zero]
    falsehood = ['=', zero, ['s', zero]]
    def apply(major, annotation, minor, existential=False):
        if name == 'tagged_application.py':
            return ['use', major, annotation, minor]
        if name == 'inferred_ex.py' and existential:
            return [major, minor]
        return [major, annotation, minor]
    rec = ['r', zero, zero, ['s', 0]]
    step = ['r', ['s', zero], zero, ['s', 0]]
    opened = ['ex', truth]
    escape = ['=', 0, zero]
    return [
        ('hypothesis', [truth, 0, truth], True),
        ('guarded_identity', [['pi', truth, truth], ['lam', truth, 0]], True),
        ('witness_pack', [['ex', ['=', 0, 1]], ['pack', 0, 0]], True),
        ('recursor_zero', [['=', rec, zero], rec], True),
        ('recursor_step', [['=', step, ['s', rec]], step], True),
        ('equation_transport', [['=', ['s', zero], ['s', zero]],
             apply(0, ['=', 0, 0], 1), falsehood, truth], True),
        ('unused_pi_witness', [truth, apply(0, None, 1),
             ['pi', truth, truth], truth], True),
        ('existential_discharge', [truth, apply(0, truth, 1, True), opened], True),
        ('equation_induction', [['pi', truth, truth], ['nat', truth, 0]], True),
        ('quantified_cases', [['pi', opened, opened], ['nat', opened, 0]], True),
        ('empty_context_falsehood', [falsehood, 0], False),
        ('escaped_eigenvariable', [escape, apply(0, escape, 1, True),
             ['ex', escape]], False),
        ('malformed_zero_update', [['=', ['r', zero, zero, None], zero],
             ['r', zero, zero, None]], False),
        ('boolean_goal_alias', [['ex', ['=', 0, True]], ['pack', 0, 0]], False),
    ]


def main():
    baseline_path = ROOT/'baseline.py'
    baseline = baseline_path.read_bytes()
    if hashlib.sha256(baseline).hexdigest() != BASELINE_SHA:
        raise ValueError('Frozen verified baseline changed.')
    final = construct_final(baseline.decode())
    if hashlib.sha256(final.encode()).hexdigest() != FINAL_SHA:
        raise ValueError('Regenerated final source differs from the delivered checker.')
    rows = [{'file': 'baseline.py', 'description': 'Exact local-kernel draft',
             'metrics': measure(baseline_path)}]
    tests = []
    for name, source in variants(final).items():
        path = ROOT/name
        ast.parse(source)
        path.write_text(source)
        metrics = measure(path)
        if metrics['imports'] != ['json', 'sys'] or not metrics['has_cli']:
            raise ValueError('Incomplete or externally dependent checker boundary.')
        rows.append({'file': name, 'metrics': metrics})
        kernel = load(path)
        for label, data, expected in smoke_cases(name):
            try:
                kernel.check(data)
                accepted = True
            except Exception:
                accepted = False
            tests.append({'variant': name, 'case': label, 'expected': expected,
                          'accepted': accepted, 'passed': accepted == expected})
    result = {'python_version': platform.python_version(),
              'snapshot_commit': '0a86fcbd7c5e0d6a541291b4ac06c7dc77989161',
              'baseline_archive': 'ipra_local_kernel_2026-11-06.zip',
              'baseline_archive_git_blob': 'd02b3faf69319dce2320cff6de59195e5dfe31dc',
              'baseline_member': 'ipra_local_kernel_2026-11-06/checker.py',
              'baseline_sha256': BASELINE_SHA, 'final_sha256': FINAL_SHA,
              'variants': rows, 'smoke_tests': tests,
              'qualification': 'Full sources are measured. Smoke tests distinguish key rule representations and rejection boundaries; they are not metatheoretic proofs.'}
    (ROOT/'metrics.json').write_text(json.dumps(result, indent=2)+'\n')
    fields = ['file', 'ast_nodes', 'source_tokens', 'normalized_tokens',
              'normalized_bytes', 'raw_bytes', 'source_lines']
    with (ROOT/'table.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({'file': row['file'], **{k: row['metrics'][k] for k in fields[1:]}})
    failed = [t for t in tests if not t['passed']]
    print((ROOT/'table.csv').read_text(), end='')
    print(json.dumps({'smoke_tests': len(tests), 'failures': failed}, indent=2))
    if failed:
        sys.exit(1)


if __name__ == '__main__':
    main()
