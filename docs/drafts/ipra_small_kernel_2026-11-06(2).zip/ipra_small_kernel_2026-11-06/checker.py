"""Complete iPRA checker."""

import json
import sys


SCOPES = ({"s": b"\x00", "r": b"\x00\x00\x02"},
          {"=": b"\x00\x00", "pi": b"\x01\x01", "ex": b"\x01"})


def subst(a, env=(1,), d=0, formula=True):
    if type(a) is int:
        if formula or a < -1:
            raise ValueError
        i = a - d
        return a if i < 0 else subst(env[i], (d,), formula=False) if i < len(env) - 1 else a + env[-1]
    tag, *args = a
    return [tag, *(subst(b, env, d + width, width == 1)
                   for b, width in zip(args, SCOPES[formula][tag], strict=True))]


def infer(p, g):
    match p:
        case [("lam" | "pack") as tag, a, q]:
            h = a if tag == "lam" else ["=", 0, subst(a, formula=False)]
            subst(h)
            b = infer(q, [*map(subst, g), h])
            return ["pi", a, b] if tag == "lam" else ["ex", b]
        case ["nat", a]:
            base = subst(a, [-1, 0])
            return ["pi", ["pi", a if a[0] == "=" else base,
                            subst(a, [["s", 0], 0])], ["pi", base, a]]
        case ["r", -1, a, h] as r:
            return ["=", r, a]
        case ["r", ["s", n], a, h] as r:
            return ["=", r, subst(h, [["r", n, a, h], n, -2], formula=False)]
        case [p, a, q]:
            tag, *parts = infer(p, g)
            if tag == "ex":
                b, c = subst(a), a
                g = [*map(subst, g), *parts]
            else:
                b, c = (subst(a, [t, -1]) if tag == "=" else subst(t, [a, -1]) for t in parts)
            if infer(q, g) != b:
                raise ValueError
            return c
        case _:
            return g[p]


def check(a, p, *g):
    for b in [*g, a]:
        subst(b)
    if infer(p, g) != a:
        raise ValueError


if __name__ == "__main__":
    try:
        _, path = sys.argv
        with open(path, encoding="utf-8") as stream:
            check(*json.load(stream))
        print("ACCEPT")
    except Exception:
        print("REJECT")
        sys.exit(1)
