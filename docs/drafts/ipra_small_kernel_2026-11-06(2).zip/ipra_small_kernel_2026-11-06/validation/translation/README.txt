POSITIVE CERTIFICATE TRANSLATIONS
================================

Run from any working directory:

    python3 validation/translation/run.py

The runner checks the original inputs with six frozen primary draft checkers,
translates their certificates, verifies that every public context and goal is
literally preserved, and checks both the translated object and the JSON file
shipped under examples/. Manifest hashes cover each original checker and input.
All sources were read from ProveIt commit
edf7ea445673b29301012177998b0cc66bfabbf0, docs/drafts.

The --write option regenerates the shipped target JSON files. Without it, the
runner requires byte-for-byte agreement with the stored examples. Results are
written to results.json. No source checker or translator participates in the
new checker's acceptance boundary.

Translate another accepted certificate with both endpoints rechecked:

    python3 validation/translation/translate.py SOURCE old.json new.json

SOURCE is one of the six identifiers in the format list below. The command
checks the frozen source hash, checks the source proof, translates it, checks
the target proof, and only then writes the target JSON file.

FORMATS

compact:   [goal, proof, *hypotheses], fixed-three-item applications,
           local numerical rule, and explicit existential conclusion.
factored:  [hypotheses, goal, proof], local numerical rule, and
           existential result computed by checked variable deletion.
integrated:[goal, proof, *hypotheses], local numerical rule, and
           existential result computed by checked variable deletion.
parameter: [hypotheses, goal, proof], parameterized numerical axiom, and
           existential result computed by checked variable deletion.
repaired:  [hypotheses, goal, proof], local numerical rule, retractable
           raw computations, and checked existential variable deletion.
reduction: [goal, proof, *hypotheses], goal-directed introductions and
           explicit principal formulas in elimination certificates.

LOCAL NUMERICAL RULE -> PARAMETERIZED AXIOM

Let P be the old matrix with number slot 0, and let q be its local step.
Put A = subst(P,(1,),d=1), reserving a fresh parameter slot 1 while protecting
slot 0 and every internal binder. Put H=P for literal equations, otherwise
H=subst(P,[-1,0]). The translated proof is

    [["nat", A], -1, ["lam", H, translated(q)]]

The inserted lambda has exactly the old numerical rule's local context, so
no hypothesis-index remapping or weakening of q is needed. Instantiating the
fresh, unused outer parameter at zero removes exactly the reserved slot.
Existing parameter-axiom nodes remain unchanged, including matrices that
really depend on the bound parameter and on retained external parameters.

EXISTENTIAL ELIMINATION

Old two-item applications [p,q] compute the result C by checked deletion.
They translate to [translated(p),C,translated(q)]. The target verifies the
local result against the lift of the exact external C. The compact format
already carries C. Goal-directed source proofs supply C from their checked
goal. Both methods enforce the same freshness condition.

OTHER NODES

Lambda and existential introduction preserve their annotations and local
contexts. Computation certificates preserve their literal trees, including
unused raw data accepted by the repaired source. Equality and guarded-universal
elimination preserve their annotations; their proof children translate in the
same retained context. Hypothesis selectors retain their source meanings.
Goal-directed computation labels acquire the redex from the checked goal;
other goal-directed introduction annotations acquire their source goal parts.

EVIDENCE AND LIMITS

The corpus includes all eleven compact-draft arithmetic milestones, the
factored draft's quantifier and equality regressions, all eight parameterized
axiom examples, and accepted public examples from each other primary checker.
Additional generated positive scope probes use retained assumptions and actual
parameter instantiation. Their origin is explicitly marked in the manifest.

Source fixtures labelled negative are not translated; a repaired example
intended for a different frozen historical checker is also excluded. These
exclusions and their reasons are recorded in manifest.json. The separate
adversarial suite is responsible for malformed-input rejection evidence.

Finite successful replay is implementation evidence, not a machine proof of
the all-input translation theorem or of bi-interpretability.
