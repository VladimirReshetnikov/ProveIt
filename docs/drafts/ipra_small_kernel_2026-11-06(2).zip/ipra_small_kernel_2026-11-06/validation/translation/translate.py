"""Translate one certificate from a frozen draft format and recheck both ends."""
import argparse
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from translators import translate

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    manifest = json.loads((HERE / "manifest.json").read_text())
    sources = {row["id"]: row for row in manifest["sources"]}
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source_format", choices=sorted(sources))
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    source = sources[args.source_format]
    source_path = HERE / source["checker"]
    if hashlib.sha256(source_path.read_bytes()).hexdigest() != source["sha256"]:
        raise ValueError("source checker hash mismatch")
    old = load(source_path, "frozen_source_checker")
    new = load(ROOT / "checker.py", "new_target_checker")
    result = translate(args.source_format, old, json.loads(args.input.read_text()))
    new.check(*result)
    args.output.write_text(json.dumps(result, separators=(",", ":")) + "\n")
    print("SOURCE AND TARGET ACCEPTED; EXACT PUBLIC SEQUENT PRESERVED")


if __name__ == "__main__":
    main()
