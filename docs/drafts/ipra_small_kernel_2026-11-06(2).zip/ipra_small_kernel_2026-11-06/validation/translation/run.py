"""Recheck frozen source examples, translate them, and check exact target sequents."""
import argparse
import hashlib
import importlib.util
import json
import sys
from collections import Counter
from pathlib import Path

sys.dont_write_bytecode = True
from translators import translate, unpack

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def encoded(value):
    return (json.dumps(value, separators=(",", ":"), ensure_ascii=True) + "\n").encode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write", action="store_true",
                        help="write regenerated target examples before verifying them")
    args = parser.parse_args()
    manifest = json.loads((HERE / "manifest.json").read_text())
    modules = {}
    source_hashes = {}
    for source in manifest["sources"]:
        path = HERE / source["checker"]
        actual = digest(path)
        if actual != source["sha256"]:
            raise ValueError("source checker hash mismatch: " + source["id"])
        source_hashes[source["id"]] = actual
        modules[source["id"]] = load(path, "frozen_" + source["id"])
    target = load(ROOT / "checker.py", "new_target_checker")

    results = []
    failures = []
    sources = Counter()
    target_hashes = set()
    sequent_hashes = set()
    retained_contexts = 0
    for case in manifest["cases"]:
        record = {"id": case["id"], "source": case["source"],
                  "input_sha256": case["sha256"], "target": case["target"]}
        try:
            source_path = HERE / case["input"]
            if digest(source_path) != case["sha256"]:
                raise ValueError("input fixture hash mismatch")
            data = json.loads(source_path.read_text())
            translated = translate(case["source"], modules[case["source"]], data)
            context, goal, _ = unpack(case["source"], data)
            if translated[0] != goal or translated[2:] != context:
                raise ValueError("public sequent changed")
            # These are separate executions of the frozen source and new target.
            target.check(*translated)
            output = ROOT / case["target"]
            payload = encoded(translated)
            if args.write:
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_bytes(payload)
            if output.read_bytes() != payload:
                raise ValueError("stored target certificate differs from regeneration")
            # Also parse and replay the exact JSON file shipped in the archive.
            target.check(*json.loads(output.read_text()))
            target_hash = hashlib.sha256(payload).hexdigest()
            sequent_hash = hashlib.sha256(encoded([context, goal])).hexdigest()
            target_hashes.add(target_hash)
            sequent_hashes.add(sequent_hash)
            retained_contexts += bool(context)
            sources[case["source"]] += 1
            record.update(passed=True, target_sha256=target_hash,
                          sequent_sha256=sequent_hash,
                          hypotheses=len(context), target_bytes=len(payload))
        except Exception as error:
            record.update(passed=False,
                          error=type(error).__name__ + ": " + str(error))
            failures.append(record)
        results.append(record)

    report = {
        "description": "Frozen source acceptance, exact-sequent translation, and target replay",
        "source_commit": manifest["source_commit"],
        "target_checker_sha256": digest(ROOT / "checker.py"),
        "source_checker_sha256": source_hashes,
        "cases": len(results),
        "passed": len(results) - len(failures),
        "failed": len(failures),
        "per_source": dict(sorted(sources.items())),
        "cases_with_retained_hypotheses": retained_contexts,
        "distinct_target_certificates": len(target_hashes),
        "distinct_public_sequents": len(sequent_hashes),
        "compact_arithmetic_milestones": sum(
            r["passed"] and r["source"] == "compact" for r in results),
        "source_check_calls": len(results),
        "target_check_calls": 2 * (len(results) - len(failures)),
        "limitations": [
            "These are finite positive regression checks, not a formal metatheory proof.",
            "Inherited examples overlap; record counts are not independent theorem counts.",
            "The translator is untrusted and not imported by the target checker.",
            "Negative and malformed-data tests are maintained in the separate audit suite."
        ],
        "failures": failures,
        "results": results
    }
    (HERE / "results.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items()
                      if k not in ("results", "limitations", "source_checker_sha256")}, indent=2))
    return bool(failures)


if __name__ == "__main__":
    raise SystemExit(main())
