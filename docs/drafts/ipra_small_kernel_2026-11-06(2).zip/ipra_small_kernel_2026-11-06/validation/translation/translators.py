"""Untrusted translations from the six inspected draft certificate formats.

The target checker does not import this module. Every source certificate is
checked by its frozen source checker before translation, and every resulting
certificate must independently pass the target checker.
"""


def unpack(source_id, data):
    """Return the common mathematical sequent and proof: (context, goal, proof)."""
    if source_id in ("compact", "integrated", "reduction"):
        goal, proof, *context = data
    else:
        context, goal, proof = data
    return context, goal, proof


def source_check(source_id, module, data):
    context, goal, proof = unpack(source_id, data)
    if source_id == "compact":
        module.check(data)
    elif source_id == "reduction":
        # This is the original program's complete public validation boundary.
        for hypothesis in context:
            module.subst(hypothesis)
        module.check(goal, proof, context)
    else:
        module.check(*data)


def local_numerical_axiom(module, matrix, translated_step):
    """Internalize a local numerical rule using the parameterized axiom.

    The source matrix has one distinguished slot n. Raising above cutoff 1
    reserves a fresh, unused parameter z without moving n or bound variables
    inside logical binders and two-slot recursor bodies. The local source step
    and inserted lambda therefore have exactly the same numerical/hypothesis
    scope. No proof weakening or hypothesis-index remapping is needed.
    """
    axiom_matrix = module.subst(matrix, (1,), d=1)
    guard = matrix if matrix[0] == "=" else module.subst(matrix, [-1, 0])
    return [["nat", axiom_matrix], -1, ["lam", guard, translated_step]]


def translate_inference(source_id, module, proof, context):
    """Translate any accepted inference-format source proof recursively."""
    sub = module.subst

    if isinstance(proof, list):
        if len(proof) == 2 and proof[0] == "nat":
            # The parameter-axiom draft already has the target axiom format.
            return proof

        if len(proof) == 3 and proof[0] in ("lam", "pack", "nat"):
            rule, annotation, child = proof
            if rule == "pack":
                guard = ["=", 0, sub(annotation, formula=False)]
            elif rule == "nat" and annotation[0] != "=":
                guard = sub(annotation, [-1, 0])
            else:
                guard = annotation
            local_context = [*map(sub, context), guard]
            translated = translate_inference(source_id, module, child, local_context)
            if rule == "nat":
                return local_numerical_axiom(module, annotation, translated)
            return [rule, annotation, translated]

        if len(proof) == 4 and proof[0] == "r":
            # This includes the raw computation draft's unused payloads.
            return proof

        principal, *arguments = proof
        principal_formula = module.infer(principal, context)
        tag, *parts = principal_formula
        translated_principal = translate_inference(source_id, module, principal, context)
        if tag == "ex":
            child = arguments[1] if source_id == "compact" else arguments[0]
            local_context = [*map(sub, context), *parts]
            translated_child = translate_inference(source_id, module, child, local_context)
            # The source either asserts this result already or computes it by
            # checked scope deletion. The target checks its lift in the branch.
            conclusion = module.infer(proof, context)
            return [translated_principal, conclusion, translated_child]
        annotation, child = arguments
        return [translated_principal, annotation,
                translate_inference(source_id, module, child, context)]

    # Negative and Boolean hypothesis indices retain their actual source meaning.
    return proof


def translate_goal_directed(module, goal, proof, context):
    """Translate the reduction draft, whose introduction labels omit goals."""
    sub = module.subst
    if isinstance(proof, list):
        if len(proof) == 2 and proof[0] in ("lam", "nat"):
            rule, child = proof
            _, guard, consequent = goal
            if rule == "nat":
                matrix = consequent
                guard = matrix if matrix[0] == "=" else guard
                consequent = sub(matrix, [["s", 0], 0])
            local_context = [*map(sub, context), guard]
            translated = translate_goal_directed(module, consequent, child, local_context)
            if rule == "nat":
                return local_numerical_axiom(module, matrix, translated)
            return ["lam", guard, translated]

        if len(proof) == 3 and proof[0] == "pack":
            _, witness, child = proof
            guard = ["=", 0, sub(witness, formula=False)]
            local_context = [*map(sub, context), guard]
            return ["pack", witness,
                    translate_goal_directed(module, goal[1], child, local_context)]

        if proof[0] == "use":
            _, principal_formula, principal, *arguments = proof
            translated_principal = translate_goal_directed(
                module, principal_formula, principal, context)
            tag, *parts = principal_formula
            if tag == "ex":
                child, = arguments
                local_context = [*map(sub, context), *parts]
                return [translated_principal, goal,
                        translate_goal_directed(module, sub(goal), child, local_context)]
            annotation, child = arguments
            antecedent, _ = (
                sub(annotation, [term, -1]) if tag == "="
                else sub(term, [annotation, -1])
                for term in parts)
            return [translated_principal, annotation,
                    translate_goal_directed(module, antecedent, child, context)]

    if proof == "r":
        # The checked equation itself supplies the recursor certificate.
        return goal[1]
    return proof


def translate(source_id, module, data):
    """Check the source and return [same goal, new proof, *same hypotheses]."""
    source_check(source_id, module, data)
    context, goal, proof = unpack(source_id, data)
    if source_id == "reduction":
        translated = translate_goal_directed(module, goal, proof, context)
    else:
        translated = translate_inference(source_id, module, proof, context)
    return [goal, translated, *context]
