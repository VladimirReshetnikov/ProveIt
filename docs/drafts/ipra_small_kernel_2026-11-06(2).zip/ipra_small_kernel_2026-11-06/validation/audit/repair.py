"""Untrusted proof reconstruction to the frozen, fully checked local calculus.

This module does not import the candidate, its substitution routine, or its scope
table. All canonical substitutions use the independent named-variable model.
"""

import math

from named_syntax import decode, subst
from rule_oracle import infer as strict_infer


def term(payload):
    """A total repair compatible with equality of finite JSON payloads."""
    if type(payload) in (int, bool):
        return int(payload) if payload >= -1 else -1
    if type(payload) is float:
        if math.isfinite(payload) and payload.is_integer() and payload >= -1:
            return int(payload)
        return -1
    if type(payload) is list:
        if len(payload) == 2 and payload[0] == 's':
            return ['s', term(payload[1])]
        if len(payload) == 4 and payload[0] == 'r':
            return ['r', *(term(x) for x in payload[1:])]
    return -1


def formula(preformula):
    """Homomorphic repair of the three well-shaped formula constructors."""
    if type(preformula) is not list:
        raise ValueError('not a preformula')
    match preformula:
        case ['=', s, t]:
            return ['=', term(s), term(t)]
        case ['pi', a, b]:
            return ['pi', formula(a), formula(b)]
        case ['ex', a]:
            return ['ex', formula(a)]
    raise ValueError('not a preformula')


def proof(p, context):
    """Repair an accepted candidate proof to the strict local-N format.

    context is canonical. The returned syntax is checked by the separately
    written rule oracle; each PAx is expanded to Pi introduction and local N.
    """
    if type(p) is list:
        if len(p) == 3 and p[0] in ('lam', 'pack'):
            tag, annotation, q = p
            if tag == 'lam':
                decode(annotation)
                guard = annotation
            else:
                decode(annotation, False)
                guard = ['=', 0, subst(annotation, formula=False)]
            local = [subst(a) for a in context] + [guard]
            return [tag, annotation, proof(q, local)]
        if len(p) == 2 and p[0] == 'nat':
            matrix = p[1]
            decode(matrix)
            base = subst(matrix, [-1, 0])
            step = ['pi', matrix if matrix[0] == '=' else base,
                    subst(matrix, [['s', 0], 0])]
            # The outer Pi binds a real parameter, not an unused dummy.
            # In the local N premise, -2 selects step and -1 its permitted
            # induction/base hypothesis. The current fresh number is 0.
            return ['lam', step, ['nat', matrix, [-2, 0, -1]]]
        if len(p) == 4 and p[0] == 'r':
            return term(p)
        if len(p) == 3:
            major, annotation, minor = p
            translated_major = proof(major, context)
            principal, _ = strict_infer(translated_major, context)
            if principal[0] == 'ex':
                decode(annotation)
                local = [subst(a) for a in context] + [principal[1]]
                translated_minor = proof(minor, local)
            else:
                if principal[0] == 'pi':
                    annotation = term(annotation)
                else:
                    decode(annotation)
                translated_minor = proof(minor, context)
            return [translated_major, annotation, translated_minor]
    if type(p) not in (int, bool):
        raise ValueError('not a hypothesis index')
    i = int(p)
    if i < 0:
        i += len(context)
    if not 0 <= i < len(context):
        raise ValueError('hypothesis index out of range')
    return i


def document(data):
    goal, p, *context = data
    for a in [goal, *context]:
        decode(a)
    return [goal, proof(p, context), *context]
