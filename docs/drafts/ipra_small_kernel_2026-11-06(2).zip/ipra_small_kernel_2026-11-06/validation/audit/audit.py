"""Reproduce the independent adversarial audit of the complete iPRA checker.

No expected positive is accepted solely on the candidate's own authority:
its certificate is repaired, PAx is expanded to local N, and the exact sequent
is replayed by both a frozen strict checker and a named-variable rule oracle.
"""

from collections import Counter
import copy
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import random
import subprocess
import sys

import named_syntax as names
import repair
import rule_oracle

ROOT = Path(__file__).resolve().parent
BUNDLE = ROOT.parent.parent
ZERO = -1
TRUE = ['=', -1, -1]
FALSE = ['=', -1, ['s', -1]]


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def encode(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()


def eq(a, b):
    return ['=', a, b]


def successor(a):
    return ['s', a]


def refl(t=-1):
    r = ['r', -1, t, -1]
    return [r, ['=', 0, names.subst(t, formula=False)], r]


def pax(matrix):
    base = names.subst(matrix, [-1, 0])
    step = names.subst(matrix, [['s', 0], 0])
    local = matrix if matrix[0] == '=' else base
    return ['pi', ['pi', local, step], ['pi', base, matrix]]


def discard_equation(r):
    return [r, TRUE, refl()]


def targeted_cases():
    out = []

    def add(name, data, accepted, purpose):
        out.append({'name': name, 'data': data, 'expected': accepted,
                    'purpose': purpose})

    add('closed_reflexivity', [TRUE, refl()], True, 'Canonical closed derivation.')
    add('closed_falsity_rejected', [FALSE, refl()], False, 'Wrong asserted conclusion.')
    for label, index, okay in [('zero', 0, True), ('negative', -1, True),
                               ('false_alias', False, True), ('true_alias', True, True),
                               ('float', 0.0, False), ('too_large', 2, False),
                               ('too_negative', -3, False), ('object', {}, False)]:
        add('hypothesis_' + label, [TRUE, index, TRUE, TRUE], okay,
            'Only indices selecting existing assumptions can act as hypotheses.')
    for i, data in enumerate([[], [TRUE], 17, None, True, '[]', {}, {'goal': TRUE}]):
        add('invalid_outer_' + str(i), data, False, 'Malformed external record.')

    matrix = eq(0, 1)
    add('pax_real_bound_parameter', [pax(matrix), ['nat', matrix]], True,
        'The outer binder captures a real numerical parameter in both matrices.')
    different_matrix = eq(0, 2)
    add('pax_parameter_not_silently_free', [pax(different_matrix), ['nat', matrix]], False,
        'Parameter and free-variable scopes must not be confused.')
    witness = successor(0)
    schema = pax(matrix)
    guard = names.subst(schema[1], [witness, -1])
    result = names.subst(schema[2], [witness, -1])
    add('pax_parameter_instantiated', [result, [['nat', matrix], witness, 0], guard], True,
        'A nontrivial term can instantiate the genuinely bound parameter.')
    for i, matrix in enumerate([eq(['r', 0, 1, successor(0)], 2),
                               ['ex', eq(successor(0), 1)],
                               ['pi', TRUE, eq(1, -1)]]):
        add('pax_matrix_' + str(i), [pax(matrix), ['nat', matrix]], True,
            'Equation and both compound root constructors are covered.')
        if matrix[0] != '=':
            base = names.subst(matrix, [-1, 0])
            step = names.subst(matrix, [successor(0), 0])
            wrong = ['pi', ['pi', matrix, step], ['pi', base, matrix]]
            add('compound_induction_forbidden_' + str(i), [wrong, ['nat', matrix]], False,
                'A compound predicate receives its fixed base, not P(y).')
    add('old_local_nat_not_an_axiom', [pax(eq(0, 1)), ['nat', eq(0, 1), 0]], False,
        'The axiom certificate is exactly two elements.')

    bad = [None, False, True, 0.0, -1.0, 0.5, -2, 's', [], {},
           ['s'], ['s', -1, -1], ['bad', -1], ['=', -1, -1],
           ['r', -1, -1], {'r': -1}]
    for i, payload in enumerate(bad):
        add('public_goal_payload_' + str(i), [eq(-1, payload), refl()], False,
            'Every asserted numerical subtree is strictly formed.')
        add('unused_public_hypothesis_' + str(i), [TRUE, refl(), eq(-1, payload)], False,
            'Unused hypotheses are validated too.')
        add('raw_zero_dead_' + str(i), [TRUE, discard_equation(['r', -1, payload, payload])], True,
            'Unused raw computation payloads admit a strict repaired derivation.')
    for i, payload in enumerate([None, [], {}, 0.5, False, ['bad', -1]]):
        add('raw_successor_dead_counter_seed_' + str(i),
            [TRUE, discard_equation(['r', ['s', payload], payload, -1])], True,
            'A constant successor update does not demand the counter or seed.')
        add('raw_successor_demands_counter_' + str(i),
            [TRUE, discard_equation(['r', ['s', payload], -1, 1])], False,
            'The counter slot traverses and validates its demanded payload.')
        add('raw_successor_demands_recursive_value_' + str(i),
            [TRUE, discard_equation(['r', ['s', -1], payload, 0])], False,
            'The previous-value slot demands the entire recursive term.')
        add('raw_successor_malformed_update_' + str(i),
            [TRUE, discard_equation(['r', ['s', -1], -1, payload])], False,
            'The source update is always traversed, even if intended as dead data.')
    add('raw_successor_counter_only',
        [TRUE, discard_equation(['r', ['s', 0], {'seed': 'unused'}, 1])], True,
        'A counter-only update permits a malformed unused initializer.')
    for i, counter in enumerate([0, False, [], ['x', -1], ['s'], ['s', -1, -1],
                                 ['r', -1, -1, -1]]):
        add('invalid_counter_constructor_' + str(i),
            [TRUE, discard_equation(['r', counter, -1, -1])], False,
            'Only the exact zero or successor computation patterns are admitted.')
    add('zero_counter_float_alias',
        [TRUE, discard_equation(['r', -1.0, None, None])], True,
        'The pattern alias -1.0 repairs to the canonical zero atom.')
    for i, raw in enumerate([['r', -1.0, -1, -1],
                              ['r', -1, False, -1],
                              ['r', -1, 0.0, True],
                              ['r', -1, -1, -1.0]]):
        canonical = repair.term(raw)
        expected_minor = eq(canonical, canonical[2])
        major = ['lam', names.subst(expected_minor), refl()]
        add('raw_minor_numeric_equality_alias_' + str(i),
            [TRUE, [major, -1, raw]], True,
            'Host equality aliases transfer only to the same repaired strict formula.')

    closed_major = ['lam', TRUE, refl()]
    for i, payload in enumerate(bad):
        add('dead_universal_witness_' + str(i), [TRUE, [closed_major, payload, refl()]], True,
            'An absent bound slot permits replacement of the witness by zero.')
    for i, payload in enumerate([None, False, 0.0, {}, ['bad', -1]]):
        identity = ['lam', eq(0, 0), -1]
        add('live_universal_witness_' + str(i), [TRUE, [identity, payload, refl()]], False,
            'A demanded witness is strictly validated.')
        nested = eq(['r', -1, -1, 2], ['r', -1, -1, 2])
        identity = ['lam', nested, -1]
        add('live_slot_in_zero_recursor_body_' + str(i),
            [TRUE, [identity, payload, refl()]], False,
            'Syntactic occurrence in a recursor body demands the witness.')
    for i, payload in enumerate([None, 0.0, ['bad'], ['=', False, -1]]):
        add('malformed_lambda_guard_' + str(i), [TRUE, ['lam', payload, refl()]], False,
            'A newly introduced guard must be canonical.')
        add('malformed_existential_witness_' + str(i),
            [['ex', TRUE], ['pack', payload, refl()]], False,
            'Existential witnesses are always validated.')
        add('malformed_pax_matrix_' + str(i), [TRUE, ['nat', payload]], False,
            'PAx validates every part of its predicate before emitting an axiom.')
        add('malformed_equality_motive_' + str(i),
            [TRUE, [refl(), payload, refl()]], False,
            'Equality motives are fully traversed.')

    w = successor(0)
    add('pack_retains_outer_parameter',
        [['ex', eq(0, successor(1))], ['pack', w, -1]], True,
        'The chosen witness is raised past the fresh existential number.')
    add('pack_parameter_capture_rejected',
        [['ex', eq(0, successor(0))], ['pack', w, -1]], False,
        'The outer witness parameter must not be captured.')
    external = eq(0, -1)
    add('lambda_parameter_lift',
        [['pi', TRUE, eq(1, -1)], ['lam', TRUE, 0], external], True,
        'Ambient assumptions are raised under fresh universal binders.')
    add('lambda_parameter_capture_rejected',
        [['pi', TRUE, eq(0, -1)], ['lam', TRUE, 0], external], False,
        'An ambient numerical parameter cannot become the introduced number.')
    for i, body in enumerate([eq(0, -1),
                              ['pi', TRUE, eq(1, -1)],
                              eq(['r', -1, -1, 2], -1)]):
        add('existential_eigenvariable_leak_' + str(i),
            [body, [0, body, 1], ['ex', body]], False,
            'The local witness cannot escape, including beneath nested binders.')
        add('existential_elimination_constant_' + str(i),
            [TRUE, [0, TRUE, refl()], ['ex', body]], True,
            'Independent conclusions can be eliminated from the same major.')
    for i, payload in enumerate([None, eq(False, -1), ['pi', TRUE, eq(0.0, -1)]]):
        add('malformed_existential_conclusion_' + str(i),
            [TRUE, [0, payload, refl()], ['ex', TRUE]], False,
            'The asserted external existential-elimination conclusion is validated.')
    for i, p in enumerate([[closed_major, -1], [closed_major, -1, refl(), refl()],
                            ['r', -1, -1, -1, -1]]):
        add('fixed_application_arity_' + str(i), [TRUE, p], False,
            'Malformed certificate lengths cannot select a different inference.')
    raw_equation = ['r', -1, {'unused_seed': True}, None]
    raw_existential = ['pack', -1, raw_equation]
    add('opened_raw_existential_body_unused',
        [TRUE, [raw_existential, TRUE, refl()]], True,
        'An opened preformula can be ignored without shifting or inspecting it.')
    add('opened_raw_existential_body_as_major',
        [TRUE, [raw_existential, TRUE, [0, TRUE, refl()]]], True,
        'A raw opened equation supports transport through a constant motive.')
    closed_schema = pax(eq(0, -1))
    add('pax_under_opened_raw_existential',
        [closed_schema, [raw_existential, closed_schema, ['nat', eq(0, -1)]]], True,
        'PAx is valid under repaired contexts even when no raw-context traversal occurs.')
    add('opened_raw_body_lift_is_demanded',
        [['pi', TRUE, TRUE],
         [raw_existential, ['pi', TRUE, TRUE], ['lam', TRUE, refl()]]], False,
        'Entering a further scope demands every retained raw assumption.')
    raw_alias = ['r', -1.0, 0.0, True]
    canonical_equation = eq(repair.term(raw_alias), 0)
    add('lambda_returns_aliased_preformula',
        [['pi', TRUE, canonical_equation], ['lam', TRUE, raw_alias]], True,
        'An inferred compound preformula can match a canonical public conclusion only after harmless aliases.')
    raw_existential_alias = ['pack', -1, raw_alias]
    add('existential_returns_aliased_preformula',
        [['ex', canonical_equation], raw_existential_alias], True,
        'Compound homomorphic repair handles existential matrices as well.')
    add('raw_free_index_cannot_leak_through_alias',
        [eq(['r', -1, -1, 2], -1),
         [['pack', -1, ['r', -1, -1, 2.0]], eq(['r', -1, -1, 2], -1), 0]], False,
        'A float alias of a local free index cannot equal the raised external index.')
    return out


def accepts(candidate, data):
    try:
        candidate.check(*data)
        return True, None
    except Exception as e:
        return False, type(e).__name__


def reconstruct(data, strict):
    fixed = repair.document(data)
    if fixed[0] != data[0] or fixed[2:] != data[2:]:
        raise ValueError('repair changed the external sequent')
    counts, canonical = rule_oracle.check(fixed)
    strict.check(canonical)
    return canonical, counts


def random_syntax(rng, depth, formula):
    if not formula:
        if depth <= 0 or rng.randrange(3) == 0:
            return rng.choice([-1, 0, 1, 2, 4, 7])
        if rng.randrange(2):
            return ['s', random_syntax(rng, depth - 1, False)]
        return ['r', *(random_syntax(rng, depth - 1, False) for _ in range(3))]
    kind = rng.randrange(3) if depth > 0 else 0
    if kind == 0:
        return eq(random_syntax(rng, depth, False), random_syntax(rng, depth, False))
    if kind == 1:
        return ['ex', random_syntax(rng, depth - 1, True)]
    return ['pi', random_syntax(rng, depth - 1, True), random_syntax(rng, depth - 1, True)]


def substitution_audit(candidate):
    rng = random.Random(20261106)
    canonical_count = 0
    for i in range(1800):
        formula = bool(rng.randrange(2))
        source = random_syntax(rng, 3, formula)
        t = random_syntax(rng, 2, False)
        u = random_syntax(rng, 2, False)
        env = rng.choice([(0,), (1,), (3,), [t, -1], [t, u, -2],
                          [-1, 0], [['s', 0], 0]])
        result = candidate.subst(source, env, formula=formula)
        expected = names.subst(source, env, formula=formula)
        if result != expected:
            raise ValueError('canonical substitution mismatch')
        names.decode(result, formula)
        canonical_count += 1
    junk = [None, False, 0.0, 0.5, -2, [], {}, ['bad'], ['r', -1, None, -1]]
    demand_success, demand_reject = 0, 0
    for i in range(900):
        formula = bool(rng.randrange(2))
        source = random_syntax(rng, 3, formula)
        env = [rng.choice(junk), -1]
        try:
            result = candidate.subst(source, env, formula=formula)
        except Exception:
            demand_reject += 1
            continue
        expected = names.subst(source, [repair.term(env[0]), -1], formula=formula)
        if result != expected:
            raise ValueError('successful demand substitution changed after repair')
        demand_success += 1
    return {'canonical_named_comparisons': canonical_count,
            'malformed_environment_trials': demand_success + demand_reject,
            'successful_repaired_environment_comparisons': demand_success,
            'demanded_invalid_environment_rejections': demand_reject}


def payload_paths(data):
    yield ()
    if type(data) is list:
        for i, child in enumerate(data):
            for rest in payload_paths(child):
                yield (i, *rest)


def replace(data, path, value):
    if not path:
        return copy.deepcopy(value)
    data = copy.deepcopy(data)
    cursor = data
    for i in path[:-1]:
        cursor = cursor[i]
    cursor[path[-1]] = copy.deepcopy(value)
    return data


def mutation_audit(candidate, strict, cases):
    rng = random.Random(7106112026)
    base = [r['data'] for r in cases if r['expected']]
    replacements = [None, False, True, -2, -1, 0, 1, 2, -1.0, 0.0, 1.0,
                    0.5, '', 's', 'nat', [], {}, ['s', -1],
                    ['r', -1, None, None], TRUE, FALSE]
    counts, rules = Counter(), Counter()
    failures = []
    for i in range(1400):
        source = rng.choice(base)
        mutated = replace(source, rng.choice(list(payload_paths(source))), rng.choice(replacements))
        ok, _ = accepts(candidate, mutated)
        counts['accepted' if ok else 'rejected'] += 1
        if ok:
            try:
                _, c = reconstruct(mutated, strict)
                rules.update(c)
            except Exception as error:
                failures.append({'trial': i, 'input': mutated, 'error': repr(error)})
    if failures:
        (ROOT / 'mutation_failures.json').write_bytes(encode(failures))
        raise ValueError('mutation acceptance failed strict reconstruction')
    return {**dict(counts), 'total': sum(counts.values()),
            'independent_rule_occurrences': sum(rules.values())}


def repair_equality_audit():
    atoms = [None, False, True, -3, -2, -1, 0, 1, 2, -1.0, 0.0, 1.0,
             2.0, 0.5, 's', 'r', '', [], {}, {'x': 0}, {'x': False}]
    payloads = atoms + [['s', x] for x in atoms] + [['r', -1, x, 0] for x in atoms]
    compared = equal = 0
    for a, b in itertools.product(payloads, repeat=2):
        compared += 1
        if a == b:
            equal += 1
            if repair.term(a) != repair.term(b):
                raise ValueError('repair violates host equality')
    return {'payload_pair_comparisons': compared, 'equal_pairs_checked': equal}


def main():
    candidate = load(BUNDLE / 'checker.py', 'candidate_under_audit')
    strict = load(ROOT / 'strict_reference.py', 'strict_frozen_reference')
    cases = targeted_cases()
    case_dir = ROOT / 'cases'
    repair_dir = ROOT / 'repaired'
    case_dir.mkdir(exist_ok=True)
    repair_dir.mkdir(exist_ok=True)
    rows, failures, totals, rules = [], [], Counter(), Counter()
    for entry in cases:
        name, data = entry['name'], entry['data']
        path = case_dir / (name + '.json')
        path.write_bytes(encode(data))
        okay, error = accepts(candidate, data)
        verdicts = {}
        for flag in [None, '-O']:
            args = [sys.executable, *([] if flag is None else [flag]),
                    str(BUNDLE / 'checker.py'), str(path)]
            run = subprocess.run(args, capture_output=True, text=True, timeout=10)
            observed = run.returncode == 0 and run.stdout.strip() == 'ACCEPT'
            verdicts['normal' if flag is None else 'optimized'] = observed
            if observed != okay:
                failures.append({'name': name, 'kind': 'CLI/API or optimization disagreement',
                                 'stdout': run.stdout, 'stderr': run.stderr})
        row = {'name': name, 'expected': entry['expected'], 'observed': okay,
               'error': error, 'cli': verdicts, 'purpose': entry['purpose'],
               'file': 'cases/' + path.name,
               'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
        if okay != entry['expected']:
            failures.append({'name': name, 'kind': 'unexpected verdict', 'observed': okay})
        if okay:
            try:
                fixed, counts = reconstruct(data, strict)
                rules.update(counts)
                fixed_path = repair_dir / path.name
                fixed_path.write_bytes(encode(fixed))
                row['strict_repaired_file'] = 'repaired/' + path.name
                row['strict_repaired_sha256'] = hashlib.sha256(fixed_path.read_bytes()).hexdigest()
            except Exception as e:
                failures.append({'name': name, 'kind': 'strict reconstruction failed', 'error': repr(e)})
        totals['accepted' if okay else 'rejected'] += 1
        rows.append(row)
    results = {'candidate_sha256': hashlib.sha256((BUNDLE / 'checker.py').read_bytes()).hexdigest(),
               'strict_reference_sha256': hashlib.sha256((ROOT / 'strict_reference.py').read_bytes()).hexdigest(),
               'python': sys.version,
               'targeted_cases': len(cases), 'targeted_counts': dict(totals),
               'normal_cli_runs': len(cases), 'optimized_cli_runs': len(cases),
               'independent_rule_counts': dict(rules),
               'substitution_audit': substitution_audit(candidate),
               'repair_equality_audit': repair_equality_audit(),
               'mutation_audit': mutation_audit(candidate, strict, cases),
               'failures': failures, 'cases': rows}
    (ROOT / 'results.json').write_bytes(encode(results))
    summary = {k: v for k, v in results.items() if k != 'cases'}
    (ROOT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
