Independent adversarial audit
============================

From the bundle root run:

    python3 validation/audit/audit.py

The script uses only the Python standard library. It creates targeted input
files in cases/, strict repaired certificates in repaired/, and results.json
plus summary.json. Every targeted test is run via the public CLI normally and
with Python -O. Every accepted targeted or deterministic mutation test must
reconstruct to the same goal and hypotheses under two strict checks.

soundness_audit.txt records the all-input repaired-consequence argument,
including the real bound parameter of PAx and the explicit-conclusion
existential freshness check. repair.py is the untrusted constructive proof
transformation. Neither it nor any audit file is imported by checker.py.

strict_reference.py is frozen from the compact-calculus draft in the supplied
repository snapshot. named_syntax.py and rule_oracle.py are frozen independent
validation modules from that same draft. Their substitution algorithm uses
globally fresh names and does not call the candidate. See provenance.json for
source identities. The local numerical rule in these references is used only
after the candidate's PAx axiom is expanded into an ordinary local derivation.

The finite tests are implementation evidence, not a machine-checked proof of
the universal soundness theorem or the theory's iPRA bi-interpretability.
