CHECKED EXAMPLES
===============

Every certificate uses the new public layout:

    [goal, proof, *hypotheses]

Run, for example:

    python3 checker.py examples/compact/reflexivity.json
    python3 checker.py examples/compact/zero_plus_n.json
    python3 checker.py examples/compact/residual.json
    python3 checker.py examples/factored/nested_equality_transport.json
    python3 checker.py examples/scope/parameter_retained_instantiation_01.json

The compact/ directory contains all eleven arithmetic and logical milestones
from the compact draft, translated without changing their public statements:

  reflexivity.json                 Equality reflexivity.
  successor_injective.json         Successor injectivity.
  zero_plus_n.json                 The identity 0+n=n.
  successor_plus.json              Successor/addition compatibility.
  diff_cancel.json                 Simultaneous-successor subtraction identity.
  diff_diagonal.json               The diagonal subtraction identity.
  residual.json                    The selector/subtraction residual identity.
  equal_implies_epsilon_zero.json   Equality implies a zero equality detector.
  epsilon_zero_implies_equal.json   A zero equality detector implies equality.
  coverage.json                    Numerical zero/successor coverage.
  forall_exists_successor.json      A quantified existence example.

factored/ additionally exercises conjunction/disjunction expansions, retained
contexts, dependent existential elimination, nested equality transport through
both logical binders and recursor bodies, parameter induction, and explosion.

parameter/ includes eight actual parameterized-axiom matrices. scope/ adds
four focused probes: actual instantiation of the axiom's bound parameter by
a recursor term under retained hypotheses, and an axiom below another lambda.
These are generated positive probes, separately identified in the provenance.

integrated/, reduction/, and repaired/ contain the accepted primary-checker
examples from those drafts in the new format. repaired/ includes valid public
sequents whose computations have unused raw data; these exercise the paper's
external canonical-repair argument.

The regression inventory contains 103 source records: 99 inherited positive
examples and 4 generated scope probes. Because source examples overlap, these
produce 46 distinct target certificates and 42 distinct public sequents.
All 103 pass their source checker and the target checker; 29 retain hypotheses.

See validation/translation/manifest.json for original paths and input hashes,
and validation/translation/results.json for per-case checked output hashes.
To rerun the entire exact-sequent translation audit:

    python3 validation/translation/run.py

To translate another accepted source certificate:

    python3 validation/translation/translate.py SOURCE old.json new.json

SOURCE is compact, factored, integrated, parameter, reduction, or repaired.
The translator is untrusted and rechecks both the original and its output.
