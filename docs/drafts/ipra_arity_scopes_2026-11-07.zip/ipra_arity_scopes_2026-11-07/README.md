# Arity-completed scopes for iPRA

This package supplies a complete scalar-iteration presentation of intuitionistic primitive recursive arithmetic, its full LaTeX report and compiled PDF, two standalone certificate checkers, and reproducible comparison/validation artifacts.

The repository snapshot is `VladimirReshetnikov/ProveIt` commit `fa69b78013baadf9a4e9d63ef1a57f56ca1eb017` (six draft ZIPs, eleven root checkers).

## Result

| Complete program or envelope | Normalized tokens | AST nodes | Normalized bytes |
|---|---:|---:|---:|
| Current delivered minimum | 342 | 364 | 978 |
| Current common-stdin minimum | 341 | 362 | 970 |
| `checker.py` | 333 | 362 | 965 |
| `checker_compact.py` | 332 | 361 | 962 |

The new structural idea adds an inert slot at equality, admits checked padding after the third child, and keeps formula leaves independent of numerical substitution. The child scope increment becomes `1 + min(3, arity)`. The induction test is exactly `arity == 2`. The compact program changes only the integer expression `d + len(a[:3]) + 1` to the equivalent `d - ~len(a[:3])`; this last saving is a notation optimization, not the substantive result.

The native basis remains the inherited two scalar-iteration computation schemas and five inference patterns. The report includes the complete logical reconstruction, internal scalar arithmetic, an ordinary first-order realization with its falsity bridge, and both identity composite interpretations. Its new representation proof explains why scalar iteration supports this completion and why a naive direct-recursion adaptation fails.

## Run

Python 3.10 or later is required for pattern matching. No third-party Python package is required for acceptance, measurement, or finite validation.

```bash
python3 checker.py < examples/iteration_zero.json
python3 checker_compact.py < examples/iteration_step.json
python3 reproduce.py
python3 build.py
python3 package.py
```

`build.py` requires a TeX distribution with `pdflatex` and the packages listed in `report.tex`. `reproduce.py`, the certificate producers, semantic oracles, and measurement tools are untrusted ancillary artifacts. Only a chosen checker and the standard Python platform participate in accepting a certificate.

## Files

- `report.tex`, `sections/`, `appendices/`, `report.pdf`: complete paper, including all mathematical dependencies.
- `checker.py`, `checker_compact.py`: complete trusted programs with the same public stdin interface.
- `comparison/`: unchanged current root checker sources, original measurement utility, and provenance.
- `validation/`, `examples/`, `results/`: finite evidence, seeds, executable certificates, and recorded results.
- `SHA256SUMS.txt`: hashes of the delivered files, excluding the manifest itself.

## Scope of the claim

The source comparison is strict against the stated corpus and metric. It is not an absolute lower-bound or global-minimality theorem. The underlying axiom basis and scalar bootstrap are inherited and attributed in the paper and `ATTRIBUTION.txt`. No proof-assistant formalization is claimed. Finite tests supplement the written proofs; they do not prove arithmetic soundness, consistency, or the interpretation theorem. A fixed Python process may reject large valid certificates because of resource limits; completeness refers to the idealized algorithm with sufficient finite resources.
