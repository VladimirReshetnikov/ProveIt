"""Repeat measurements and finite verification; all dependencies are bundled."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    commands = ("measure.py", "validation/validate.py", "validation/scalar_semantics.py")
    for command in commands:
        print("Running " + command, flush=True)
        subprocess.run([sys.executable, str(ROOT / command)], cwd=ROOT, check=True)
    records = {name: json.loads((ROOT / "results" / name).read_text())
               for name in ("measurements.json", "validation.json", "scalar_semantics.json")}
    if not all(record.get("status") == "PASS" for record in records.values()):
        raise SystemExit("A verification result did not report PASS")
    print("All reproducible checks passed.")


if __name__ == "__main__":
    main()
