"""Create the requested ZIP with source, PDF, evidence, and hashes."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDE = {"build_temp", "__pycache__"}


def files():
    return sorted(path for path in ROOT.rglob("*")
                  if path.is_file() and not (set(path.relative_to(ROOT).parts) & EXCLUDE)
                  and path.name != "SHA256SUMS.txt")


def main():
    for required in ("report.pdf", "report.tex", "results/measurements.json",
                     "results/validation.json", "results/scalar_semantics.json"):
        if not (ROOT / required).is_file():
            raise SystemExit("Missing required deliverable: " + required)
    entries = files()
    (ROOT / "SHA256SUMS.txt").write_text("".join(
        hashlib.sha256(path.read_bytes()).hexdigest() + "  " +
        path.relative_to(ROOT).as_posix() + "\n" for path in entries))
    archive = ROOT.with_suffix(".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as output:
        for path in entries + [ROOT / "SHA256SUMS.txt"]:
            output.write(path, ROOT.name + "/" + path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(archive) as check:
        if check.testzip() is not None:
            raise SystemExit("ZIP integrity check failed")
    print(archive)
    print("SHA256 " + hashlib.sha256(archive.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
