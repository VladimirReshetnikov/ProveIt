"""Compile the complete LaTeX report; not part of certificate acceptance."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    compiler = shutil.which("pdflatex")
    if compiler is None:
        raise SystemExit("Install a TeX distribution providing pdflatex, then rerun.")
    work = ROOT / "build_temp"
    work.mkdir(exist_ok=True)
    logs = []
    for index in range(3):
        result = subprocess.run(
            [compiler, "-interaction=nonstopmode", "-halt-on-error",
             "-file-line-error", f"-output-directory={work}", "report.tex"],
            cwd=ROOT, capture_output=True, text=True)
        logs.append(result.stdout + result.stderr)
        if result.returncode:
            (ROOT / "results/latex_failure.log").write_text(logs[-1])
            raise SystemExit(logs[-1][-10000:])
    shutil.copyfile(work / "report.pdf", ROOT / "report.pdf")
    final = logs[-1]
    warnings = [line for line in final.splitlines()
                if any(key in line for key in ("Warning:", "Overfull", "Underfull"))]
    result = {"status": "PASS", "passes": len(logs),
              "compiler": "pdflatex", "warnings": warnings,
              "pdf_bytes": (ROOT / "report.pdf").stat().st_size,
              "pdf_sha256": hashlib.sha256((ROOT / "report.pdf").read_bytes()).hexdigest()}
    (ROOT / "results/build.json").write_text(json.dumps(result, indent=2) + "\n")
    (ROOT / "results/latex_final.log").write_text(final)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
