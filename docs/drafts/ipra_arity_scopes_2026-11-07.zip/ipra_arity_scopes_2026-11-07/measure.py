"""Reproduce whole-program measurements against the frozen current corpus."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import tempfile

ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location(
    "inherited_source_measure", ROOT / "comparison/source_measure.py")
MEASURE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MEASURE)
FIELDS = ("normalized_tokens", "ast_nodes", "normalized_bytes")


def driver(source, mode):
    if mode == "delivered":
        return source
    stream = "sys.stdin" if mode == "common_stdin" else "open(sys.argv[1])"
    replacement = ast.parse(
        "try:\n"
        f"    take = json.load({stream}).pop\n"
        "    1 / check(take(), [])\n"
        "    print('ACCEPT')\n"
        "except:\n"
        "    print('REJECT')\n"
        "    sys.exit(1)\n").body[0]
    tree = ast.parse(source)
    indices = [i for i, node in enumerate(tree.body) if isinstance(node, ast.Try)]
    if len(indices) != 1:
        raise ValueError("Comparator does not have one identifiable public driver")
    tree.body[indices[0]] = replacement
    return ast.unparse(ast.fix_missing_locations(tree)) + "\n"


def source_metrics(source):
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "program.py"
        path.write_text(source)
        return MEASURE.metrics(path)


def main():
    manifest_path = ROOT / "comparison/manifest.json"
    manifest = json.loads(manifest_path.read_text())
    modes = ("delivered", "common_stdin", "common_filename")
    programs = []
    for entry in manifest["programs"]:
        path = ROOT / "comparison" / entry["local_file"]
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != entry["sha256"]:
            raise ValueError("Frozen baseline changed: " + entry["label"])
        programs.append({**entry, "measurements": {
            mode: source_metrics(driver(raw.decode(), mode)) for mode in modes}})
    minima = {mode: {field: min(row["measurements"][mode][field]
                                for row in programs)
                     for field in FIELDS} for mode in modes}
    candidates = []
    for name in ("checker.py", "checker_compact.py"):
        source = (ROOT / name).read_text()
        measurements = {mode: source_metrics(driver(source, mode)) for mode in modes}
        candidates.append({"file": name, "measurements": measurements,
            "strict_improvement": {mode: {
                field: measurements[mode][field] < minima[mode][field]
                for field in FIELDS} for mode in modes}})
    expected = {"normalized_tokens": 342, "ast_nodes": 364, "normalized_bytes": 978}
    if minima["delivered"] != expected:
        raise AssertionError((minima["delivered"], expected))
    if not all(candidates[0]["strict_improvement"]["delivered"].values()):
        raise AssertionError("Transparent program no longer improves delivered envelope")
    if not all(candidates[1]["strict_improvement"]["common_stdin"].values()):
        raise AssertionError("Compact program no longer improves the common interface")
    result = {"status": "PASS", "python": platform.python_version(),
              "implementation": platform.python_implementation(),
              "commit": manifest["commit"], "archive_count": len(manifest["archives"]),
              "root_programs": len(programs), "normalizer_sha256": hashlib.sha256(
                  (ROOT / "comparison/source_measure.py").read_bytes()).hexdigest(),
              "minima": minima, "programs": programs, "candidates": candidates}
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results/measurements.json").write_text(json.dumps(result, indent=2) + "\n")
    rows = []
    for row in programs:
        label = row["label"].replace("ipra_", "").replace("_2026-11-07/", " / ")
        label = label.replace("_", r"\_")
        metric = row["measurements"]["delivered"]
        rows.append(label + " & " + " & ".join(str(metric[x]) for x in FIELDS) + r"\\")
    table = [r"\begin{tabular}{@{}lrrr@{}}", r"\toprule",
             r"Delivered root program & Tokens & AST nodes & Bytes\\",
             r"\midrule", *rows, r"\midrule",
             r"Coordinatewise minimum & 342 & 364 & 978\\",
             r"\bottomrule", r"\end{tabular}"]
    (ROOT / "results/baseline_table.tex").write_text("\n".join(table) + "\n")
    print(json.dumps({"status": result["status"], "minima": minima,
                      "candidates": [{"file": x["file"],
                          **{f: x["measurements"]["delivered"][f] for f in FIELDS}}
                          for x in candidates]}, indent=2))


if __name__ == "__main__":
    main()
