"""Standalone iPRA certificate checker with sort-directed scalar erasure.

Direct recursion: update slots bind prior value and prior counter.
Numerical unary nodes bind zero; ternary nodes bind two slots. Numerical
binary nodes mean zero and their children are logical annotations. At a
formula position, every scalar leaf erases to truth. A whole node arity
determines its uniform child scope increment. No imported project module.
"""
import json, sys
k = 0


def inst(a, t=None, d=0):
    if isinstance(a, list):
        return [inst(b, t, d + (0, 2, 1, 4)[len(a)]) for b in a]
    return d % 2 and (a if k <= a < d else inst(t, d=1))


def check(a, g):
    global k
    if inst(a) in g:
        return True
    match take():
        case [m, t] if check(m, g):
            if m[2:]:
                h = [m[2:]]
            else:
                if not m[1:]:
                    t, m = m[0], [0, t]
                return inst(t, m[1]) == a and check(inst(t, m[0]), g)
        case []:
            (n, t, r), b = a
            if n:
                n, = n
                t = inst(inst(r, n, 3), [n, t, r], 1)
            return b == t
        case t:
            a = inst(a[2], t, 2)
            h = [a, inst(a, 0)][len(a) % 2:]
    k -= 1
    return check(inst(a, [k]), g + [inst(c, k) for c in h])


try:
    take = json.load(open(sys.argv[1])).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
