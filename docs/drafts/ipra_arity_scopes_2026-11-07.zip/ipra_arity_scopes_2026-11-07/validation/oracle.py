"""Named-rule validation interpreter for arity scopes, scalar iteration only.

Adapted from the sort_erasure draft at ProveIt commit
fa69b78013baadf9a4e9d63ef1a57f56ca1eb017, validation/oracle_erasure.py.
The inherited fixtures and their prior provenance are in fixtures/.

This interpreter imports no production kernel.  It uses distinct term and
formula traversals, explicit protected-variable counts, ordinary conditionals,
and named inference rules.  It deliberately does not use the kernel's clipped
arity expression or Python structural pattern matcher.  Agreement is claimed
only for public closed packets with empty initial context.

The tests that use this interpreter are finite implementation evidence, not
a proof-assistant formalization of soundness or completeness.
"""
from copy import deepcopy


class Oracle:
    def __init__(self):
        self.lower = 0
        self.rules = {}

    def rule(self, name):
        self.rules[name] = self.rules.get(name, 0) + 1

    def term(self, value, image=None, protected=0):
        if type(value) is not list:
            if self.lower <= value < 2 * protected + 1:
                return value
            return self.term(image)
        if len(value) == 0:
            return []
        if len(value) == 1:
            return [self.term(value[0], image, protected + 1)]
        if len(value) == 2:
            return [self.formula(child, image, protected + 2) for child in value]
        return [self.term(child, image, protected + 2) for child in value]

    def formula(self, value, image=None, protected=0):
        if type(value) is not list:
            if self.lower <= value < 2 * protected:
                return value
            return 0
        if len(value) == 0:
            return []
        if len(value) == 1:
            return [self.formula(value[0], image, protected + 1)]
        if len(value) == 2:
            return [self.term(child, image, protected + 1) for child in value]
        return [self.formula(child, image, protected + 2) for child in value]

    def fresh(self):
        self.lower -= 1
        return self.lower

    def check(self, goal, context):
        checked = self.formula(goal)
        if checked in context:
            self.rule('hypothesis')
            return True
        instruction = self.stack.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            if self.check(major, context):
                if type(major) is not list:
                    raise ValueError('scalar major')
                if len(major) >= 3:
                    self.rule('paired_elimination')
                    eigen = self.fresh()
                    assumption = self.formula([major[2]], eigen)
                    return self.check(self.formula(goal, [eigen]), context + [assumption])
                if len(major) == 1:
                    self.rule('closure_elimination')
                    matrix, left, right = major[0], 0, annotation
                elif len(major) == 2:
                    self.rule('equality_transport')
                    matrix = annotation
                    left, right = major
                else:
                    raise ValueError('major arity')
                if self.formula(matrix, right) != goal:
                    return False
                return self.check(self.formula(matrix, left), context)
            self.rule('failed_major_fallthrough')
        if type(instruction) is list and not instruction:
            if type(goal) is not list or len(goal) != 2:
                raise ValueError('computation requires equality')
            term, right = goal
            if type(term) is not list or len(term) != 3:
                raise ValueError('computation requires exact recursor arity')
            count, initial, update = term
            if not count:
                expected = initial
                self.rule('computation_zero')
            elif type(count) is list and len(count) == 1:
                smaller = [count[0], initial, update]
                expected = self.term(update, smaller)
                self.rule('computation_successor')
            else:
                raise ValueError('counter shape')
            return right == expected
        if type(goal) is not list or len(goal) < 3:
            raise ValueError('primitive introduction requires paired goal')
        self.rule('paired_introduction')
        matrix = self.formula(goal[2], instruction, 1)
        base = self.formula(matrix, 0)
        if type(matrix) is not list:
            raise ValueError('scalar introduction matrix')
        assumptions = [matrix, base] if len(matrix) == 2 else [base]
        eigen = self.fresh()
        conclusion = self.formula(matrix, [eigen])
        opened = [self.formula(a, eigen) for a in assumptions]
        return self.check(conclusion, context + opened)

    def run(self, packet):
        self.lower = 0
        self.rules = {}
        self.stack = deepcopy(packet)
        try:
            accepted = bool(self.check(self.stack.pop(), []))
            error = None
        except Exception as exc:
            accepted = False
            error = type(exc).__name__
        return {'accepted': accepted, 'final_k': self.lower,
                'remaining': len(self.stack) if type(self.stack) is list else None,
                'rules': dict(self.rules), 'error': error}
