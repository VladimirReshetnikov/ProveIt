"""Translate canonical old certificates by inserting equality's dummy slot.

This is an untrusted fixture producer.  It never participates in acceptance.
The source fixtures carry their existing attribution and provenance.
"""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = HERE / 'fixtures/positive_certificates.json'


def extend(mapping, new_count, old_add, new_add):
    # Canonical constructors retain all original nearest slots in order.
    return list(range(1, old_add + 1)) + [n + new_add for n in mapping], new_count + new_add


def leaf(value, mapping, new_count):
    if type(value) not in (int, float) or value <= 0:
        return value
    if value != int(value):
        raise ValueError('This canonical translator requires integer coordinates')
    slot = (value + 1) // 2
    if slot <= len(mapping):
        return 2 * mapping[slot - 1] - 1 + (value % 2 == 0)
    return value + 2 * (new_count - len(mapping))


def term(value, mapping=(), new_count=0):
    if type(value) is not list:
        return leaf(value, mapping, new_count)
    n = len(value)
    if n == 0:
        return []
    if n == 1:
        m, q = extend(mapping, new_count, 1, 1)
        return [term(value[0], m, q)]
    if n == 2:
        m, q = extend(mapping, new_count, 1, 2)
        return [formula(child, m, q) for child in value]
    if n == 3:
        m, q = extend(mapping, new_count, 2, 2)
        return [term(child, m, q) for child in value]
    raise ValueError('Old canonical term arity')


def formula(value, mapping=(), new_count=0):
    if type(value) is not list:
        return 0
    n = len(value)
    if n == 0:
        return []
    if n == 1:
        m, q = extend(mapping, new_count, 1, 1)
        return [formula(value[0], m, q)]
    if n == 2:
        m, q = extend(mapping, new_count, 0, 1)
        return [term(child, m, q) for child in value]
    if n == 3:
        m, q = extend(mapping, new_count, 2, 2)
        return [formula(child, m, q) for child in value]
    raise ValueError('Old canonical formula arity')


def packet(old):
    out = []
    for instruction in old[:-1]:
        if instruction == []:
            out.append([])
        elif type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            if type(major) is not list:
                raise ValueError('Noncanonical major')
            if len(major) == 1:
                annotation = term(annotation)
            elif len(major) == 2:
                annotation = formula(annotation)
            out.append([formula(major), annotation])
        else:
            out.append(term(instruction))
    out.append(formula(old[-1]))
    return out


def main():
    source = json.loads(SOURCE.read_text())
    records = [{'source_id': r['id'], 'source_name': r['name'], 'packet': packet(r['packet'])}
               for r in source['records']]
    output = {'source_file': 'fixtures/positive_certificates.json',
              'source_archive': 'ipra_sort_erasure_2026-11-07.zip',
              'source_commit': 'fa69b78013baadf9a4e9d63ef1a57f56ca1eb017',
              'source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
              'transformation': 'Insert one nearest dummy slot at formula equality; shift outer coordinates, including exposed template holes. Proof instruction roles determine their syntax sort.',
              'records': records}
    (HERE / 'positive_certificates.json').write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps({'translated': len(records), 'source_sha256': output['source_sha256']}, indent=2))


if __name__ == '__main__':
    main()
