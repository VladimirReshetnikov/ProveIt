"""Bounded experimental search; not a metatheory formalization."""
from pathlib import Path
import random, json, hashlib, argparse
ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--samples', type=int, default=60000)
parser.add_argument('--seed', type=int, default=18112)
args = parser.parse_args()
checker_path = ROOT / 'checker.py'
src = checker_path.read_text().split('\ntry:\n    take =')[0]
ns={};exec(src,ns)
rng=random.Random(args.seed)
class Large(Exception):pass

def term(a, env=(), gas=None):
    if gas is None: gas=[20000]
    gas[0]-=1
    if gas[0]<0:raise Large
    if not isinstance(a,list):
        n=int(a//1)
        if n==0:return 0
        if n<0:raise Large
        return env[(n-1)//2]
    if not a or len(a)==2:return 0
    if len(a)==1:return 1+term(a[0],(0,)+env,gas)
    n=term(a[0],(0,0)+env,gas)
    if n>40:raise Large
    u=term(a[1],(0,0)+env,gas)
    for _ in range(n):
        u=term(a[2],(u,u)+env,gas)
        if u>1000:raise Large
    return u

def raw(depth,d):
    if depth==0 or rng.random()<.45:
        if d%2:return rng.randrange(d)
        return rng.choice([0,1,2,5,9,False,True,100.5])
    n=rng.choice([0,1,1,2,3,3,4,5,6])
    return [raw(depth-1,d+min(n,3)+1) for _ in range(n)]

stats={'seed':args.seed,'sample_count':args.samples,'checker_sha256':hashlib.sha256(checker_path.read_bytes()).hexdigest(),'scope':'Atomic scalar computation checks under an independent bounded natural-number decoder; not a proof of general soundness.','attempts':0,'computed_rhs':0,'accepted':0,'evaluated':0,'large':0,'counterexamples':[]}
for _ in range(args.samples):
    stats['attempts']+=1
    n=0 if rng.random()<.2 else [raw(rng.randrange(4),9)]
    a=raw(rng.randrange(4),7)
    r=raw(rng.randrange(4),7)
    ns['k']=0
    try:
        b=a if not n else ns['inst'](r,[n[0],a,r],1)
        stats['computed_rhs']+=1
        goal=[[n,a,r],b]
        packet=[[],goal]
        ns['take']=packet.pop
        ok=ns['check'](ns['take'](),[])
        if not ok:continue
    except (Exception,RecursionError):continue
    stats['accepted']+=1
    try:
        left=term(goal[0],(0,))
        right=term(goal[1],(0,))
    except Large:
        stats['large']+=1;continue
    except Exception as e:
        stats['counterexamples'].append({'goal':goal,'decoder_error':repr(e)})
        break
    stats['evaluated']+=1
    if left!=right:
        stats['counterexamples'].append({'goal':goal,'left':left,'right':right})
        break
stats['status'] = 'FAIL' if stats['counterexamples'] else 'PASS'
print(json.dumps(stats,indent=2))
(ROOT / 'results' / 'scalar_semantics.json').write_text(json.dumps(stats,indent=2)+'\n')
raise SystemExit(bool(stats['counterexamples']))
