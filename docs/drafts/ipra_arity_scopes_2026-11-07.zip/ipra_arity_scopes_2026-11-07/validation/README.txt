FINITE VALIDATION OF ARITY SCOPES

Run from any directory:

    python3 validation/validate.py

Python 3.10 or later and only its standard library are required. The script
locates both delivered checker programs and its data relative to its own
path, and writes results/validation.json. It does not modify the checkers.
The checkers import none of these validation files.

OBSERVED RESULTS

Both the straightforward and compact checker passed the same checks:

- 147 inherited positive scalar certificates, re-encoded to insert the new
  equality dummy slot. The translation source and old fixtures are included.
- 735 further positive representations per checker: the 147 certificates
  with every paired formula padded to each arity from 4 through 8.
  These are representation variants, not 735 additional mathematical theorems.
- 18 named positive and 21 named negative public cases.
- 4,000 deterministic mutations per checker, of which 538 were accepted.
- 6,000 deterministic mixed-shape packets per checker, of which 35 were
  accepted. Mutated and generated packets are not presumed to be invalid.
- 1,729 one-step arithmetic packets per checker. All 475 accepted equations
  were independently evaluated in the natural numbers and found true.
- 118 actual subprocess invocations per checker: 59 ordinarily and 59 with
  Python's -O option. Exact stdout, stderr, and exit status were checked.
  Across the two delivered checkers this is 236 public entry-point checks.

The seed is 19481108. All checked public traces agree with the named-rule
oracle on verdict, final eigenparameter allocation floor, and remaining
proof-stack length. The deterministic positive and named cases exercise
the two computation schemas, all five logical inference patterns, and
false-major fallthrough, including fallthrough after a discarded major
subtrace has allocated a fresh name.

INDEPENDENT ORGANIZATION

oracle.py is adapted from the preceding sort_erasure oracle, with explicit
numerical and formula traversals and protected-slot counts. It does not
import the production checker, use the clipped-arity expression, or use
the production structural matcher. Its rule names make exercised cases
visible in the result receipt. Its agreement claim is for the public
empty-context boundary, not arbitrary calls with fabricated contexts.

The arithmetic evaluator uses a nearest-slot environment and ordinary
iteration, not the checker's opening routine. Equality operands receive
one zero dummy; scalar updates receive two copies of the previous state.
Only accepted generated arithmetic equations are claimed to be numerically
true. A rejected packet may encode a true equation with an invalid one-step
certificate. Evaluation bounds protect the test runner, not the checker;
no generated case was skipped because of an evaluation bound.

REGRESSION CONTROLS

The tests deliberately construct wrong checker variants in memory:

1. Replacing the literal-equation test with an even-arity test wrongly
   grants induction hypotheses to padded paired formulas. The diagnostic
   packets are rejected by the correct checker at every arity from 3 to 8.
   The mutant accepts exactly arities 4, 6, and 8. These packets violate a
   rule side condition; their conclusions are not claimed underivable.

2. Restoring the previous direct-recursion two-stage opening without fixing
   the new equality dummy accepts a packet that decodes to the false
   equation 0=1. The delivered scalar checker rejects it. The exact packet
   is included in examples/defective_direct_ghost_regression.json.

Other named cases include used versus unused previous-state images,
independent rejection of an actually used image containing a nonroot
ghost coordinate, an accepted unused image, Boolean/fractional coordinate
aliases, empty numerical zero, binary numerical zero annotations, invalid
padding, unallocated rigid parameters, malformed JSON, and inert unread
prefix cells. Every padding field is still validated.

FIXTURE REPRODUCTION AND PROVENANCE

    python3 validation/translate_fixtures.py

rebuilds positive_certificates.json from the included unmodified source
fixtures. It inserts one new nearest dummy slot at equality boundaries,
shifts outer coordinates, and preserves the roles of proof instructions,
numerical witnesses, and formula motives. It is an untrusted producer and
is not part of acceptance.

The immediate source is ProveIt commit
fa69b78013baadf9a4e9d63ef1a57f56ca1eb017,
docs/drafts/ipra_sort_erasure_2026-11-07.zip.
provenance.json records exact source identities and hashes. The original
fixture metadata preserves earlier source paths and transformation history.
The inherited MIT No Attribution license is included in fixtures/.

LIMITS

This is finite implementation evidence. Random testing is not exhaustive
proof search. The named-rule interpreter is not an independently verified
proof assistant, and matching it does not prove soundness, completeness,
equiconsistency, bi-interpretability, or global minimality. Those mathematical
claims must be assessed from the report's arguments. Actual Python runs
also have finite memory and recursion limits; mathematical completeness
refers to the idealized checker with sufficient finite resources.
