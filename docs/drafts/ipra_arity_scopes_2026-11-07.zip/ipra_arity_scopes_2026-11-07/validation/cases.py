"""Explicit positive, negative, and induction-restriction test packets."""
from copy import deepcopy


def numeral(number):
    result = 0
    for _ in range(number):
        result = [result]
    return result


def pair(matrix, arity=3):
    return [0, 0, deepcopy(matrix)] + [0 for _ in range(arity - 3)]


def compound_induction_attempt(arity):
    """A proof that requires the forbidden IH for a paired (compound) matrix.

    It is rejected by the correct checker.  Replacing the literal-equation
    test by an even-arity test accepts it when arity is even.  The goal itself
    need not be underivable: this tests one prohibited certificate step.
    """
    hole = 100000
    previous = [-1, 0, 1]
    following = [[-1], 0, 1]
    zero_recursion = [0, following, 0]
    computation = [following, previous]
    reflexive_zero = [zero_recursion, following]
    symmetric = [previous, following]
    motive = [hole, following]
    logical_motive = pair([hole, 0], arity)
    # Reading order: outer introduction, transport, symmetry of a
    # computation equation, and a reflexivity proof using two R0 steps.
    instructions = [
        0,
        [symmetric, logical_motive],
        [computation, motive],
        [],
        [reflexive_zero, motive],
        [],
        [],
    ]
    # The outer induction variable is the sixth protected slot in this
    # counter: two inner paired binders, one equality dummy, and two
    # iterator dummies precede it. Coordinates 11 and 12 name that slot.
    matrix = pair([[11, 0, 1], 0], arity)
    goal = pair(matrix)
    return list(reversed(instructions)) + [goal]


def named_cases():
    cases = []
    def add(name, packet, accept, note):
        cases.append({'name': name, 'packet': packet, 'expected': accept, 'note': note})

    add('computation_zero', [[], [[0, 0, 0], 0]], True, 'I(0,0;u.0)=0')
    add('computation_successor_image_used', [[], [[[0], 0, 1], [0, 0, 1]]], True,
        'The successor equation validates and inserts its previous-state image.')
    add('computation_successor_image_unused', [[], [[[0], [0], 0], 0]], True,
        'A constant update ignores the previous-state image.')
    add('unused_image_may_have_nonroot_ghost', [[], [[[7], 0, 0], 0]], True,
        'Count uses equality dummy zero; update is constant; no image is used.')
    add('used_image_rejects_nonroot_ghost', [[], [[[7], 0, 1], 0]], False,
        'The previous-state image fails independent numerical-root validation.')
    add('defective_direct_ghost_regression', [[], [[[[0]], 0, 5], [0]]], False,
        'Naive direct two-stage opening accepts this false equation; scalar rejects it.')
    add('zero_boolean_alias', [[], [[False, True, 0], True]], True,
        'False is a zero counter; True in both term positions is a zero-slot alias.')
    add('fractional_zero_alias', [[], [[0, 0.25, 0], 0.25]], True,
        'The fractional label [0,1) denotes zero.')
    add('equality_dummy_alias', [[], [[0, 1.5, 0], 1.5]], True,
        'Equality adds a dummy zero; a coordinate in its first slot denotes zero.')
    add('empty_seed', [[], [[0, [], 0], []]], True, 'Empty numerical syntax denotes zero.')
    add('binary_numerical_zero', [[], [[0, [[0, 0], [0, 0]], 0], [[0, 0], [0, 0]]]], True,
        'The two numerical-binary children are checked formula annotations.')
    add('false_computation', [[], [[0, 0, 0], [0]]], False, 'False arithmetic equation 0=1.')
    add('falsity', [[], [0, [0]]], False, 'The designated falsity formula has no computation proof.')
    add('invalid_update_string', [[], [[[0], 0, 'x'], 0]], False, 'A numerical string fails validation.')
    add('invalid_formula_padding', [0, [0, 0, [0, 0], 'x']], False,
        'Every padded field is checked; formula strings are not accepted by this profile.')
    add('unallocated_negative_parameter', [[], [[0, -1, 0], -1]], False,
        'Public validation starts at floor zero.')
    add('unused_prefix', ['unused', {'unused': True}, [], [[0, 0, 0], 0]], True,
        'Unread prefix cells are inert and contribute no hypotheses.')
    failed_major = [[0, 0, 0], [0]]
    add('failed_major_fallthrough', [[], [failed_major, None], pair([0, 0])], True,
        'A Boolean false major result falls through to a valid independent introduction.')
    allocating_major = pair([[0, 7, 0], [5]])
    add('failed_major_fallthrough_after_allocation',
        [[], 0, [allocating_major, None], pair([0, 0])], True,
        'Discarded major subtrace may allocate a name; its local assumptions do not escape.')
    for arity in range(3, 9):
        add(f'paired_introduction_arity_{arity}', [0, pair([0, 0], arity)], True,
            'Constant equation matrix closes from its retained base.')
        add(f'compound_induction_forbidden_arity_{arity}', compound_induction_attempt(arity), False,
            'Only a literal two-child equality receives an induction hypothesis.')
    for invalid in [None, 0, 'x', {}, [0], [[], None], [[], 'xx'], [[], {'abc': 'x'}]]:
        add('malformed_' + str(len(cases)), invalid, False, 'Malformed public input or goal.')
    return cases
