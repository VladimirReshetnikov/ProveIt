"""Portable finite validation of both delivered arity-scope checkers.

Run from any directory using Python 3.10 or later.  This script exercises
the actual checker definitions, an independently organized named-rule
interpreter, explicit wrong-kernel controls, and real JSON subprocess entry
points.  It is implementation evidence, not a formal correctness proof.
"""
import ast
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import json
import math
from pathlib import Path
import platform
import random
import subprocess
import sys

from cases import compound_induction_attempt, named_cases, numeral
from oracle import Oracle

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
RESULTS = ROOT / 'results'
SEED = 19481108


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def definitions(source, label):
    tree = ast.parse(source)
    require(isinstance(tree.body[-1], ast.Try), 'Expected final public acceptance driver')
    tree.body.pop()
    namespace = {}
    exec(compile(tree, str(label), 'exec'), namespace)
    return namespace


def kernel_run(namespace, packet):
    stack = deepcopy(packet)
    namespace['k'] = 0
    try:
        namespace['take'] = stack.pop
        accepted = bool(namespace['check'](stack.pop(), []))
        error = None
    except Exception as exc:
        accepted = False
        error = type(exc).__name__
    return {'accepted': accepted, 'final_k': namespace['k'],
            'remaining': len(stack) if type(stack) is list else None, 'error': error}


def compare(namespace, packet, expected=None):
    actual = kernel_run(namespace, packet)
    oracle = Oracle().run(packet)
    fields = ('accepted', 'final_k', 'remaining')
    if any(actual[key] != oracle[key] for key in fields):
        RESULTS.mkdir(exist_ok=True)
        (RESULTS / 'validation_disagreement.json').write_text(json.dumps(
            {'packet': packet, 'kernel': actual, 'oracle': oracle}, indent=2) + '\n')
        raise AssertionError('Named-rule oracle disagrees with actual checker trace')
    if expected is not None:
        require(actual['accepted'] is expected, ('Unexpected verdict', expected, actual, packet))
    return actual, oracle


def pad_term(value, arity):
    if type(value) is not list:
        return value
    if len(value) == 2:
        return [pad_formula(child, arity) for child in value]
    return [pad_term(child, arity) for child in value]


def pad_formula(value, arity):
    if type(value) is not list:
        return value
    if len(value) == 2:
        return [pad_term(child, arity) for child in value]
    converted = [pad_formula(child, arity) for child in value]
    if len(value) >= 3:
        converted += [0] * (arity - len(value))
    return converted


def pad_packet(packet, arity):
    converted = []
    for instruction in packet[:-1]:
        if instruction == []:
            converted.append([])
        elif type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            if len(major) == 1:
                annotation = pad_term(annotation, arity)
            elif len(major) == 2:
                annotation = pad_formula(annotation, arity)
            converted.append([pad_formula(major, arity), annotation])
        else:
            converted.append(pad_term(instruction, arity))
    return converted + [pad_formula(packet[-1], arity)]


def paths(value, prefix=()):
    found = [prefix]
    if type(value) is list:
        for index, child in enumerate(value):
            found.extend(paths(child, prefix + (index,)))
    return found


def replace_at(value, path, replacement):
    if not path:
        return replacement
    target = value
    for index in path[:-1]:
        target = target[index]
    target[path[-1]] = replacement
    return value


def random_tree(rng, depth):
    atoms = [None, False, True, -9, -1, 0, 1, 2, 3, 5, 7, 12,
             0.25, 1.5, -0.25, 'x', {}, [], float('inf'), float('nan')]
    if depth == 0 or rng.random() < 0.66:
        return deepcopy(rng.choice(atoms))
    return [random_tree(rng, depth - 1) for _ in range(rng.randrange(9))]


def numerical_value(value, environment=()):
    """Evaluate a closed numerical expression independently of substitution.

    The environment is nearest-slot first.  Scalar iteration duplicates its
    previous state in both update slots.  Padding is semantically ignored.
    Limits protect this finite test runner and are not part of the checker.
    """
    if type(value) is not list:
        if not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ValueError('Nonnumerical leaf in semantic evaluator')
        coordinate = math.floor(value)
        if coordinate == 0:
            return 0
        if coordinate < 0:
            raise ValueError('Evaluator accepts only closed arithmetic examples')
        return environment[(coordinate - 1) // 2]
    if len(value) in (0, 2):
        return 0
    if len(value) == 1:
        return 1 + numerical_value(value[0], (0,) + environment)
    count = numerical_value(value[0], (0, 0) + environment)
    state = numerical_value(value[1], (0, 0) + environment)
    if count > 32:
        raise OverflowError('Finite-test evaluator count bound')
    for _ in range(count):
        state = numerical_value(value[2], (state, state) + environment)
        if state > 100000:
            raise OverflowError('Finite-test evaluator value bound')
    return state


def arithmetic_cases(namespace):
    seeds = [0, [0], [[0]], [], 1, 2, [[0, 0], [0, 0]]]
    updates = [0, 1, 2, 3, 4, 5, 6, [0], [1], [3], [5], [7],
               [], [[0, 0], [0, 0]], [0, 0, 0, 0], [[[0]], 5, 1]]
    counts = Counter()
    for count in range(4):
        for seed in seeds:
            for update in updates:
                left = [numeral(count), deepcopy(seed), deepcopy(update)]
                candidates = [0, [0], [[0]]]
                if count == 0:
                    candidates.append(deepcopy(seed))
                else:
                    try:
                        candidates.append(Oracle().term(update, [numeral(count - 1), seed, update]))
                    except Exception:
                        pass
                for right in candidates:
                    packet = [[], [left, right]]
                    actual, _ = compare(namespace, packet)
                    counts['checked'] += 1
                    if actual['accepted']:
                        # Both equality operands receive one zero dummy.
                        lhs = numerical_value(left, (0,))
                        rhs = numerical_value(right, (0,))
                        require(lhs == rhs, ('Accepted a numerically false equation', packet, lhs, rhs))
                        counts['accepted_and_semantically_true'] += 1
    return dict(counts)


def mutation_controls(source):
    wrong_induction = definitions(source.replace('[len(a) != 2:]', '[len(a) % 2:]'), '<wrong-induction-control>')
    control = []
    for arity in range(3, 9):
        result = kernel_run(wrong_induction, compound_induction_attempt(arity))
        require(result['accepted'] == (arity % 2 == 0), ('Induction mutation control', arity, result))
        control.append({'matrix_arity': arity, 'wrong_checker_accepts': result['accepted']})

    old = 't = inst(r, [n, t, r], 1)'
    require(old in source, 'Scalar computation code changed unexpectedly')
    defective_direct = definitions(source.replace(old, 't = inst(inst(r, n, 3), [n, t, r], 1)'), '<defective-direct-control>')
    packet = [[], [[[[0]], 0, 5], [0]]]
    direct_result = kernel_run(defective_direct, packet)
    require(direct_result['accepted'], 'Defective direct control did not expose ghost-slot bug')
    left, right = packet[-1]
    require(numerical_value(left, (0,)) == 0 and numerical_value(right, (0,)) == 1,
            'Regression should decode to a false 0=1 equation')
    return {'forbidden_compound_induction': control,
            'defective_direct_accepts_false_equation': direct_result['accepted'],
            'regression_packet': packet}


def subprocess_checks(path, named, records):
    examples = [(c['name'], c['packet'], c['expected']) for c in named]
    # Representative inherited certificates exercise more than local steps;
    # the complete fixture corpus is checked in-process above.
    examples += [('inherited_' + r['source_id'], r['packet'], True) for r in records[::13]]
    counts = Counter()
    for flag in ([], ['-O']):
        for name, packet, expected in examples:
            process = subprocess.run([sys.executable, *flag, str(path)],
                                     input=json.dumps(packet), text=True, capture_output=True, timeout=10)
            verdict = 'ACCEPT\n' if expected else 'REJECT\n'
            require(process.stdout == verdict, ('Public stdout', path.name, name, flag, process.stdout))
            require(process.returncode == (0 if expected else 1), ('Public exit status', name, process.returncode))
            require(process.stderr == '', ('Unexpected stderr', name, process.stderr))
            counts['optimized' if flag else 'normal'] += 1
        for raw in ('', '{', '[', 'null', '{}', 'true', '"x"', '[[],]'):
            process = subprocess.run([sys.executable, *flag, str(path)], input=raw,
                                     text=True, capture_output=True, timeout=10)
            require(process.stdout == 'REJECT\n' and process.returncode == 1 and process.stderr == '',
                    ('Malformed JSON boundary', path.name, raw, flag))
            counts['malformed_optimized' if flag else 'malformed_normal'] += 1
    return dict(counts)


def main():
    RESULTS.mkdir(exist_ok=True)
    records = json.loads((HERE / 'positive_certificates.json').read_text())['records']
    named = named_cases()
    (HERE / 'named_cases.json').write_text(json.dumps(named, indent=2) + '\n')
    rows = []
    for filename in ('checker.py', 'checker_compact.py'):
        path = ROOT / filename
        source = path.read_text()
        namespace = definitions(source, path)
        rules = Counter()
        counts = Counter()
        positives = []
        for arity in range(3, 9):
            for record in records:
                packet = pad_packet(record['packet'], arity)
                actual, oracle = compare(namespace, packet, True)
                rules.update(oracle['rules'])
                counts['translated_positive_packets' if arity == 3 else 'padded_positive_variants'] += 1
                positives.append(packet)
        for case in named:
            actual, oracle = compare(namespace, case['packet'], case['expected'])
            rules.update(oracle['rules'])
            counts['named_positive' if case['expected'] else 'named_negative'] += 1

        rng = random.Random(SEED)
        for _ in range(4000):
            packet = deepcopy(rng.choice(positives))
            packet = replace_at(packet, rng.choice(paths(packet)), random_tree(rng, 2))
            actual, _ = compare(namespace, packet)
            counts['mutations'] += 1
            counts['accepted_mutations'] += actual['accepted']
        for _ in range(6000):
            packet = [random_tree(rng, 3) for _ in range(rng.randrange(1, 11))]
            actual, _ = compare(namespace, packet)
            counts['random_packets'] += 1
            counts['accepted_random_packets'] += actual['accepted']

        needed = {'hypothesis', 'paired_introduction', 'paired_elimination',
                  'closure_elimination', 'equality_transport', 'computation_zero',
                  'computation_successor', 'failed_major_fallthrough'}
        require(needed <= rules.keys(), ('Missing exercised rules', needed - rules.keys()))
        row = {'checker': filename, 'sha256': sha256(path.read_bytes()).hexdigest(),
               'packet_counts': dict(counts), 'named_rule_counts': dict(rules),
               'arithmetic': arithmetic_cases(namespace),
               'public_subprocess_checks': subprocess_checks(path, named, records),
               'mutation_controls': mutation_controls(source)}
        rows.append(row)
        print(json.dumps({k: v for k, v in row.items() if k != 'mutation_controls'}, indent=2))

    example_dir = ROOT / 'examples'
    example_dir.mkdir(exist_ok=True)
    for name in ('defective_direct_ghost_regression', 'compound_induction_forbidden_arity_4',
                 'paired_introduction_arity_8', 'failed_major_fallthrough_after_allocation'):
        case = next(c for c in named if c['name'] == name)
        (example_dir / (name + '.json')).write_text(json.dumps(case['packet'], indent=2) + '\n')
    result = {'status': 'PASS', 'python': platform.python_version(), 'implementation': platform.python_implementation(),
              'seed': SEED,
              'scope': 'Finite validation evidence: deterministic fixture translation, arity padding, named boundary/regression cases, seeded mutations/random packets, named-rule differential checks, and real public subprocess checks. This is not exhaustive proof search or a proof-assistant correctness proof.',
              'rows': rows,
              'support_sha256': {str(p.relative_to(ROOT)): sha256(p.read_bytes()).hexdigest()
                                 for p in (HERE / 'oracle.py', HERE / 'cases.py', HERE / 'validate.py',
                                           HERE / 'translate_fixtures.py', HERE / 'positive_certificates.json',
                                           HERE / 'fixtures/positive_certificates.json')}}
    (RESULTS / 'validation.json').write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()
