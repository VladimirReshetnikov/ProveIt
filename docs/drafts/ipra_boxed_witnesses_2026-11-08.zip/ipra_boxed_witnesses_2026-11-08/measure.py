"""Reproduce whole-program counts and the identical-driver control."""
import ast
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import tempfile

ROOT = Path(__file__).resolve().parent
METRICS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
spec = importlib.util.spec_from_file_location(
    'inherited_measure', ROOT / 'comparison/source_measure.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def whole_program_metrics(path):
    result = module.metrics(path)
    # Preserve the inherited measurements, but omit its unused import-stripped
    # "core" summary: all comparisons in this report concern complete programs.
    return {key: value for key, value in result.items() if key != 'core'}


def common_driver(path):
    tree = ast.parse(path.read_text())
    core = [node for node in tree.body
            if isinstance(node, (ast.Import, ast.ImportFrom, ast.FunctionDef))
            or (isinstance(node, ast.Assign) and any(
                isinstance(t, ast.Name) and t.id == 'k'
                for t in node.targets))]
    checker = [node.name for node in core
               if isinstance(node, ast.FunctionDef)][-1]
    driver = ast.parse(
        'try:\n'
        ' take = json.load(sys.stdin).pop\n'
        f' 1 / {checker}(take(), [])\n'
        ' print("ACCEPT")\n'
        'except:\n'
        ' print("REJECT")\n'
        ' raise SystemExit(1)\n')
    tree.body = core + driver.body
    with tempfile.TemporaryDirectory() as directory:
        normalized = Path(directory) / 'controlled.py'
        normalized.write_text(ast.unparse(tree) + '\n')
        result = module.metrics(normalized)
    return {key: result[key] for key in METRICS}


def minimum(rows, key):
    return {metric: min(row[key][metric] for row in rows)
            for metric in METRICS}


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    rows = []
    for entry in manifest['programs']:
        source = ROOT / 'comparison' / entry['local_file']
        actual = whole_program_metrics(source)
        if actual['sha256'] != entry['sha256']:
            raise ValueError('Changed frozen baseline: ' + entry['label'])
        rows.append({**entry, 'actual': actual,
                     'common_driver': common_driver(source)})
    candidates = []
    for name in ('checker.py', 'checker_compatible.py'):
        source = ROOT / name
        candidates.append({'file': name, 'actual': whole_program_metrics(source),
                           'common_driver': common_driver(source)})
    actual_minimum = minimum(rows, 'actual')
    controlled_minimum = minimum(rows, 'common_driver')
    for row in candidates:
        row['strict_delivered_improvement'] = {
            key: row['actual'][key] < actual_minimum[key] for key in METRICS}
        row['strict_controlled_improvement'] = {
            key: row['common_driver'][key] < controlled_minimum[key]
            for key in METRICS}
    frontier = [row['label'] for row in rows if not any(
        all(other['actual'][key] <= row['actual'][key] for key in METRICS)
        and any(other['actual'][key] < row['actual'][key] for key in METRICS)
        for other in rows)]
    result = {
        'python': platform.python_version(),
        'implementation': platform.python_implementation(),
        'commit': manifest['commit'],
        'archive_count': len(manifest['archives']),
        'program_count': len(rows),
        'metric_module_sha256': hashlib.sha256(
            (ROOT / 'comparison/source_measure.py').read_bytes()).hexdigest(),
        'delivered_minima': actual_minimum,
        'common_driver_minima': controlled_minimum,
        'pareto_frontier': frontier,
        'programs': rows,
        'candidates': candidates,
        'scope': 'Complete acceptance programs, including imports and driver; '
                 'unchanged inherited docstring removal and ast.unparse metric.',
        'control': 'Identical stdin/ACCEPT/REJECT/raise-SystemExit driver; '
                   'kernel names and all kernel code left as delivered.'}
    destination = ROOT / 'results'
    destination.mkdir(exist_ok=True)
    (destination / 'measurements.json').write_text(
        json.dumps(result, indent=2) + '\n')
    with (destination / 'measurements.csv').open('w', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(['program', 'profile', *METRICS])
        for row in rows + candidates:
            for profile in ('actual', 'common_driver'):
                writer.writerow([row.get('label', row.get('file')), profile,
                                 *(row[profile][key] for key in METRICS)])
    lines = ['\\begin{longtable}{@{}p{0.56\\textwidth}rrr@{}}',
             '\\toprule Program & Tokens & AST & Bytes\\\\', '\\midrule']
    for row in rows:
        label = row['label'].replace('ipra_', '').replace('_2026-11-07', '')
        label = label.replace('_', '\\_')
        values = ' & '.join(str(row['actual'][key]) for key in METRICS)
        lines.append(label + ' & ' + values + '\\\\')
    lines.extend(['\\bottomrule', '\\end{longtable}'])
    (destination / 'all_programs.tex').write_text('\n'.join(lines) + '\n')
    print(json.dumps({key: value for key, value in result.items()
                      if key != 'programs'}, indent=2))


if __name__ == '__main__':
    main()
