"""False-equation attacks and public normal/optimized CLI checks."""
import ast,copy,hashlib,json,random,subprocess,sys
from pathlib import Path
from boxed_oracle import Oracle
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'checker.py'
tree=ast.parse(SOURCE.read_text());tree.body=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.Assign))]
ns={};exec(compile(tree,str(SOURCE),'exec'),ns)

def actual(packet):
    ns['k']=0;stack=copy.deepcopy(packet)
    try:
        ns['take']=stack.pop
        return bool(ns['check'](ns['take'](),[]))
    except BaseException:return False

loaded=json.loads((ROOT/'validation/boxed_positive_certificates.json').read_text())
records=loaded['records'] if isinstance(loaded,dict) else loaded
false_goals=[[0,[0]],[{},[0]],[0,[{}]],[0.5,[0.5]],[False,[False]],[[],[[]]],[[0],0]]
attacks=0
for record in records:
    for goal in false_goals:
        packet=copy.deepcopy(record['packet'][:-1])+[copy.deepcopy(goal)]
        a=actual(packet);b=Oracle().run(packet)['accepted'];attacks+=1
        if a or b:raise AssertionError(('false theorem accepted',record.get('name'),goal,packet))

rng=random.Random(739343)
leaves=[0,1,-1,-2,-999,None,False,True,'','bad',{}, {'':0}, [],[0],[0,0],[0,0,0],[0,0,[],0]]
for _ in range(15000):
    if rng.random()<.7:
        source=copy.deepcopy(rng.choice(records)['packet'][:-1])
        for _ in range(rng.randrange(1,5)):
            if not source:break
            at=rng.randrange(len(source))
            if rng.randrange(2):source[at]=[copy.deepcopy(rng.choice(leaves)),copy.deepcopy(rng.choice(leaves))]
            else:del source[at]
    else:
        source=[[copy.deepcopy(rng.choice(leaves)),copy.deepcopy(rng.choice(leaves))] for _ in range(rng.randrange(8))]
    packet=source+[copy.deepcopy(rng.choice(false_goals))]
    a=actual(packet);b=Oracle().run(packet)['accepted'];attacks+=1
    if a or b:raise AssertionError(('false theorem accepted',packet))

named={
'zero_computation':([[0,0],[[0,0,0],0]],True),
'false_computation':([[0,0],[[0,0,0],[0]]],False),
'boxed_zero_witness':([[0,[0,0,0]],[0,0,[3,3]]],True),
'reserved_bare_zero':([[0,0],[0,0,[3,3]]],False),
'empty_object_counter':([[0,0],[[{},0,0],0]],True),
'nonempty_object_counter':([[0,0],[[{'':0},0,0],0]],False),
'used_invalid_string':([[0,'bad'],[0,0,[3,3]]],False),
'unused_invalid_string':([[0,'bad'],[0,0,[]]],True),
'future_name':([[0,[0,-1,0]],[0,0,[3,3]]],False),
'padded_induction_matrix':([[0,[0,0,0]],[0,0,[0,0,[],0]]],False),
'string_does_not_recurse':([[0,0],[[0,'x'*20000,0],'x'*20000]],False),
'failed_major_fallthrough':([[0,0],[[[0,0,0],[0]],[0,0,0]],[0,0,[]]],True),
'first_boxed_fixture':(records[0]['packet'],True),
'large_boxed_fixture':(max(records,key=lambda r:len(r['packet']))['packet'],True),
}
cli=[]
for name,(packet,expected) in named.items():
    if actual(packet)!=expected or Oracle().run(packet)['accepted']!=expected:
        raise AssertionError(('bad named expectation',name,expected))
    source=json.dumps(packet)
    for flags in ([],['-O']):
        run=subprocess.run([sys.executable,*flags,str(SOURCE)],input=source,text=True,capture_output=True,timeout=10)
        verdict=run.returncode==0 and run.stdout.strip()=='ACCEPT'
        if verdict!=expected or run.returncode!=(0 if expected else 1) or run.stdout.strip()!=('ACCEPT' if expected else 'REJECT'):
            raise AssertionError((name,flags,run.returncode,run.stdout,run.stderr))
        cli.append({'name':name,'optimized':bool(flags),'accepted':verdict,'exit':run.returncode})
for name,source in [('malformed_json','['),('dictionary_top','{}'),('empty_input',''),('too_deep_json','['*2000+'0'+']'*2000)]:
    for flags in ([],['-O']):
        run=subprocess.run([sys.executable,*flags,str(SOURCE)],input=source,text=True,capture_output=True,timeout=10)
        if run.returncode!=1 or run.stdout.strip()!='REJECT':raise AssertionError((name,flags,run.returncode,run.stdout,run.stderr))
        cli.append({'name':name,'optimized':bool(flags),'accepted':False,'exit':run.returncode})
receipt={'status':'PASS','candidate_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'seed':739343,'false_equation_attacks':attacks,'false_theorems_accepted':0,'false_goal_aliases':false_goals,'public_cli_runs':len(cli),'cli':cli,'assert_statements':sum(isinstance(n,ast.Assert) for n in ast.walk(ast.parse(SOURCE.read_text()))),'limitations':'Finite attack population and CLI checks; universal soundness is established by the mathematical extraction argument, not by these tests.'}
(ROOT/'results').mkdir(exist_ok=True)
(ROOT/'results/adversarial.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k not in ('cli','false_goal_aliases')},indent=2))
