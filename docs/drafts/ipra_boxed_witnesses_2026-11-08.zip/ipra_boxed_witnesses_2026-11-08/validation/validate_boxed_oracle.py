"""Bounded differential checks of independently organized boxed-witness oracle."""
import ast, copy, hashlib, importlib.util, itertools, json, random
from pathlib import Path
from boxed_oracle import Oracle
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'checker.py'
tree=ast.parse(SOURCE.read_text());tree.body=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.Assign))]
ns={};exec(compile(tree,str(SOURCE),'exec'),ns)

def actual(packet):
    stack=copy.deepcopy(packet);ns['k']=0
    try:
        ns['take']=stack.pop
        accepted=bool(ns['check'](ns['take'](),[]))
    except BaseException:
        accepted=False
    return {'accepted':accepted,'final_k':ns['k'],'remaining':len(stack) if type(stack) is list else None}

def compare(packet):
    a=actual(packet);b=Oracle().run(packet)
    for key in ('accepted','final_k','remaining'):
        if a[key]!=b[key]:
            raise AssertionError((packet,a,b))
    return a['accepted']

leaves=[None,False,True,-3,-2,-1,-.5,0,.5,1,1.5,2,3,8,10**30,'','x',{}, {'':0}, {'a':0},float('inf'),float('-inf'),float('nan')]
values=leaves+[[],[0],[1],[None],[4],[0,0],[0,1],[0,0,0],[0,0,1],[0,0,0,0],[None,0,0,0],[[None]],[[0,0,0,0]],[[0],[1]],[{}],[[{}],{}],[0,{},0]]
rng=random.Random(739342)
def raw(depth):
    if depth==0 or rng.randrange(3)==0:return copy.deepcopy(rng.choice(leaves))
    return [raw(depth-1) for _ in range(rng.randrange(6))]
values += [raw(3) for _ in range(350)]
images=[None,0,-1,-2,.5,[],{},[0],[4],[0,0],[0,0,0],{'bad':0}]
openings=0
for k,d,t,a in itertools.product((0,-1,-3),range(7),images,values):
    ns['k']=k; oracle=Oracle();oracle.lower=k
    outcomes=[]
    for f in (lambda:ns['inst'](a,t,d),lambda:(oracle.term(a,t,d//2) if d%2 else oracle.formula(a,t,d//2))):
        try:outcomes.append((True,f()))
        except BaseException:outcomes.append((False,None))
    openings+=1
    if outcomes[0]!=outcomes[1]:raise AssertionError(('opening',k,d,t,a,outcomes))

named={
'zero_computation':([[0,0],[[0,0,0],0]],True),
'successor_computation':([[0,0],[[[0],0,0],0]],True),
'false_computation':([[0,0],[[0,0,0],[0]]],False),
'empty_object_counter':([[0,0],[[{},0,0],0]],True),
'empty_object_initializer':([[0,0],[[0,{},0],{}]],True),
'nonempty_object_counter':([[0,0],[[{'':0},0,0],0]],False),
'empty_string_initializer':([[0,0],[[0,'',0],'']],False),
'boxed_zero_witness':([[0,[0,0,0]],[0,0,[3,3]]],True),
'bare_zero_witness_is_reserved':([[0,0],[0,0,[3,3]]],False),
'empty_truth_matrix':([[0,[0,0,0]],[0,0,[]]],True),
'unused_bad_witness':([[0,'x'],[0,0,[]]],True),
'used_bad_witness':([[0,'x'],[0,0,[3,3]]],False),
'future_witness':([[0,-1],[0,0,[3,3]]],False),
'boxed_future_witness':([[0,[0,-1,0]],[0,0,[3,3]]],False),
'dictionary_instruction':([{'':'ignored','w':'ignored'},[0,0,[]]],True),
'oversized_formula':([[0,[0,0,0]],[0,0,[],0]],False),
'oversized_atomic_matrix':([[0,[0,0,0]],[0,0,[0,0,[],0]]],False),
}
for name,(packet,expected) in named.items():
    found=compare(packet)
    if found!=expected:raise AssertionError((name,found,expected))

random_cases=0;random_accept=0
for _ in range(15000):
    if rng.random()<.65:
        goal=rng.choice([[[0,0,0],0],[[[0],0,0],0],[0,0,[]],[0,0,[3,3]],raw(3)])
        packet=[[raw(1),raw(2)] for _ in range(rng.randrange(4))]+[copy.deepcopy(goal)]
    else:
        packet=raw(4)
    random_accept+=compare(packet);random_cases+=1

positive_path=ROOT/'validation/boxed_positive_certificates.json'
loaded=json.loads(positive_path.read_text())
records=loaded.get('records',loaded) if isinstance(loaded,dict) else loaded
fixtures=0;accepted_fixtures=0;mutations=0;mutation_accept=0
for record in records:
    packet=record['packet']
    accepted_fixtures+=compare(packet);fixtures+=1
    for _ in range(16):
        q=copy.deepcopy(packet)
        if q:
            op=rng.randrange(4)
            at=rng.randrange(len(q))
            if op==0:q[at]=raw(2)
            elif op==1:del q[at]
            elif op==2:q.insert(at,raw(2))
            else:q[-1]=raw(3)
        mutation_accept+=compare(q);mutations+=1

receipt={'status':'PASS','candidate_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'oracle_sha256':hashlib.sha256((Path(__file__).parent/'boxed_oracle.py').read_bytes()).hexdigest(),'seed':739342,'opener_comparisons':openings,'named_cases':len(named),'named_expected_verdicts':{n:e for n,(_,e) in named.items()},'random_packets':random_cases,'random_acceptances':random_accept,'fixture_file':positive_path.name,'fixtures':fixtures,'fixture_acceptances':accepted_fixtures,'mutation_packets':mutations,'mutation_acceptances':mutation_accept,'comparison_fields':['accepted','final_k','remaining'],'limitations':'Finite deterministic tests; not an exhaustive search or a formal proof of the universal metatheorems.'}
out=ROOT/'results/oracle.json';out.parent.mkdir(exist_ok=True);out.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
