"""Reproduce exact-refinement checks for the compatible companion.

The program boundary, source files and comparison script are all in this
archive. Python standard library only; no repository checkout is required.
"""
import ast,copy,hashlib,itertools,json,random,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT/'comparison/baselines/ipra_compact_kernel_2026-11-07__checker_retained.py'
NEW=ROOT/'checker_compatible.py'

def load(path):
    tree=ast.parse(path.read_text())
    tree.body=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.Assign))]
    ns={};exec(compile(tree,str(path),'exec'),ns);return ns
old,new=load(OLD),load(NEW)

def run(ns,packet):
    stack=copy.deepcopy(packet);ns['k']=0
    try:
        ns['take']=stack.pop
        accepted=bool(ns['check'](ns['take'](),[]))
    except BaseException:accepted=False
    return (accepted,ns['k'],len(stack) if type(stack) is list else None)

def compare(packet):
    a,b=run(old,packet),run(new,packet)
    if a!=b:raise AssertionError(('proof disagreement',packet,a,b))
    return a[0]

leaves=[None,False,True,-3,-2,-1,-.5,0,.5,1,1.5,2,3,8,10**30,'','x',{}, {'a':0},float('inf'),float('-inf'),float('nan')]
values=leaves+[[],[0],[1],[None],[4],[0,0],[0,1],[0,0,0],[0,0,1],[0,0,0,0],[None,0,0,0],[[None]],[[0,0,0,0]],[[0],[1]]]
rng=random.Random(739341)
def raw(depth):
    if depth==0 or rng.randrange(3)==0:return copy.deepcopy(rng.choice(leaves))
    return [raw(depth-1) for _ in range(rng.randrange(6))]
values += [raw(3) for _ in range(450)]
images=[None,0,-1,-2,.5,[],[0],[4],[0,0],[0,0,0],{'bad':0}]
openings=0
for k,d,t,a in itertools.product((0,-1,-2),(0,1,2,3,4,5,8),images,values):
    decisions=[]
    for ns in (old,new):
        ns['k']=k
        try:decisions.append((True,ns['inst'](a,t,d)))
        except BaseException:decisions.append((False,None))
    openings+=1
    if decisions[0]!=decisions[1]:raise AssertionError(('opening disagreement',k,d,t,a,decisions))

fixture_path=ROOT/'validation/source_positive_certificates.json'
records=json.loads(fixture_path.read_text())['records']
positives=0;mutations=0
for record in records:
    if not compare(record['packet']):raise AssertionError(('positive fixture rejected',record['name']))
    positives+=1
    for _ in range(8):
        q=copy.deepcopy(record['packet'])
        if q:
            at=rng.randrange(len(q));op=rng.randrange(3)
            if op==0:q[at]=raw(2)
            elif op==1:del q[at]
            else:q[-1]=raw(3)
        compare(q);mutations+=1
random_packets=5000
for _ in range(random_packets):
    packet=raw(4) if rng.randrange(3) else [raw(2) for _ in range(rng.randrange(7))]
    compare(packet)

named={
'zero_computation':([[],[[0,0,0],0]],True),
'successor_computation':([[],[[[0],0,0],0]],True),
'false_computation':([[],[[0,0,0],[0]]],False),
'empty_object_rejects':([[],[[{},0,0],0]],False),
'string_rejects':([[],[[0,'x'*20000,0],'x'*20000]],False),
'oversized_matrix_rejects':([0,[0,0,[0,0,[],0]]],False),
'positive_transport_fixture':(records[0]['packet'],True),
}
cli=[]
for name,(packet,expected) in named.items():
    if compare(packet)!=expected:raise AssertionError(('named verdict',name,expected))
    for flags in ([],['-O']):
        p=subprocess.run([sys.executable,*flags,str(NEW)],input=json.dumps(packet),text=True,capture_output=True,timeout=10)
        if p.returncode!=(0 if expected else 1) or p.stdout.strip()!=('ACCEPT' if expected else 'REJECT'):
            raise AssertionError((name,flags,p.returncode,p.stdout,p.stderr))
        cli.append({'name':name,'optimized':bool(flags),'accepted':expected,'exit':p.returncode})
receipt={'status':'PASS','candidate_sha256':hashlib.sha256(NEW.read_bytes()).hexdigest(),'baseline_sha256':hashlib.sha256(OLD.read_bytes()).hexdigest(),'seed':739341,'opener_comparisons':openings,'positive_fixtures':positives,'mutations':mutations,'random_packets':random_packets,'named_packets':len(named),'public_cli_runs':len(cli),'cli':cli,'comparison_fields':['accepted','final_k','remaining'],'limitations':'Finite executable evidence. Exact idealized refinement is justified by the report proof, not inferred from these samples.'}
(ROOT/'results').mkdir(exist_ok=True);(ROOT/'results/compatible_validation.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='cli'},indent=2))
