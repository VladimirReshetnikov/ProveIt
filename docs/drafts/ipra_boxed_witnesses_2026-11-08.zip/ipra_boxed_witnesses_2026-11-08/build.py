"""Build the complete paper offline using a local pdfLaTeX installation."""
from pathlib import Path
import os
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def main():
    if not shutil.which('pdflatex'):
        raise SystemExit('Install pdfLaTeX and the packages declared in report.tex.')
    with tempfile.TemporaryDirectory(prefix='ipra-boxed-latex-') as directory:
        work = Path(directory)
        environment = os.environ.copy()

        def locate(name):
            return subprocess.run(['kpsewhich', name], env=environment,
                                  capture_output=True).returncode == 0

        # Local-format/font-map setup adapted from the supplied arithmetic-
        # scopes report. It uses installed TeX sources and downloads nothing.
        distribution = Path('/usr/share/texlive/texmf-dist')
        if not locate('article.cls') and (distribution / 'tex/latex/base/article.cls').exists():
            environment['TEXMF'] = '{/usr/share/texlive/texmf-dist,/usr/share/texmf,/etc/texmf}'
        if not locate('pdflatex.fmt'):
            setup = subprocess.run(
                ['pdftex', '-ini', '-etex', '-interaction=nonstopmode',
                 '-jobname=pdflatex', '-progname=pdflatex', 'pdflatex.ini'],
                cwd=directory, env=environment, capture_output=True, text=True)
            if setup.returncode:
                raise SystemExit(setup.stdout[-5000:] + setup.stderr)
            environment['TEXFORMATS'] = directory + os.pathsep + environment.get('TEXFORMATS', '')
        if not locate('pdftex.map') and distribution.exists():
            maps = sorted((distribution / 'fonts/map/dvips/amsfonts').glob('*.map'))
            latin_modern = Path('/usr/share/texmf/fonts/map/dvips/lm/lm.map')
            if latin_modern.exists():
                maps.append(latin_modern)
            if maps:
                (work / 'pdftex.map').write_bytes(b'\n'.join(p.read_bytes() for p in maps))
                environment['TEXFONTMAPS'] = directory + os.pathsep + environment.get('TEXFONTMAPS', '')
        for _ in range(3):
            result = subprocess.run(
                ['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
                 '-no-shell-escape', '-output-directory=' + directory,
                 'report.tex'], cwd=ROOT, env=environment, capture_output=True, text=True)
            if result.returncode:
                print(result.stdout[-14000:])
                print(result.stderr)
                raise SystemExit(result.returncode)
        log = (work / 'report.log').read_text(errors='replace')
        if ('undefined references' in log or 'Citation `' in log
                or 'Reference `' in log):
            raise SystemExit('Unresolved reference: ' + log[-6000:])
        shutil.copy2(work / 'report.pdf', ROOT / 'report.pdf')
        warnings = [line for line in log.splitlines()
                    if 'Overfull' in line or 'Warning' in line]
        (ROOT / 'results/build_warnings.txt').write_text(
            '\n'.join(warnings) + ('\n' if warnings else 'No LaTeX warnings.\n'))
    print('Built report.pdf')


if __name__ == '__main__':
    main()
