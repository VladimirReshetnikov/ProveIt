"""Create the distributable archive and SHA-256 manifest, using only stdlib."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / 'MANIFEST.sha256'


def payload_files():
    return sorted(path for path in ROOT.rglob('*')
                  if path.is_file() and path != MANIFEST
                  and '__pycache__' not in path.parts
                  and path.suffix not in {'.pyc', '.pyo'}
                  and not any(part.startswith('.')
                              for part in path.relative_to(ROOT).parts))


def main():
    files = payload_files()
    lines = [hashlib.sha256(path.read_bytes()).hexdigest() + '  '
             + path.relative_to(ROOT).as_posix() for path in files]
    MANIFEST.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    destination = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(destination, 'w') as archive:
        for path in sorted(files + [MANIFEST]):
            info = zipfile.ZipInfo(
                ROOT.name + '/' + path.relative_to(ROOT).as_posix(),
                date_time=(2026, 11, 8, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compresslevel=9)
    print(destination)
    print('Files:', len(files) + 1)
    print('Bytes:', destination.stat().st_size)
    print('SHA-256:', hashlib.sha256(destination.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
