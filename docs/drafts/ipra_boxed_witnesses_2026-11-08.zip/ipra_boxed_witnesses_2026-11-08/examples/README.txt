Run all examples with checker.py except compatible_zero.json, which uses checker_compatible.py.
false_computation.json and bare_zero_witness_rejects.json intentionally REJECT. All others ACCEPT.
The longer examples are translated inherited fixtures; their exact provenance is preserved under validation/.
