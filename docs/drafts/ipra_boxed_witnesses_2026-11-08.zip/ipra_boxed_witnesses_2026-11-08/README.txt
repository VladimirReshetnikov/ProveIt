BOXED WITNESSES FOR iPRA
=======================
Prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific date).

Start with report.pdf. report.tex, sections/, appendices/ and the generated
results/all_programs.tex are its complete editable LaTeX source.

RESULT
------
At ProveIt commit ce3371c9025b5c0ba12543acc2e6475d13ff7a3c, the five current
draft archives contain ten complete root programs. Remeasuring them gives:

                                           Tokens   AST nodes   Bytes
Current delivered coordinate minima           328         356     957
checker.py: uniform two-field instructions     322         355     903
checker_compatible.py: exact old protocol      327         354     955

These are complete docstring-stripped, ast.unparse-normalized programs,
including imports, stdin parsing, ACCEPT/REJECT output and rejection exit.
CPython 3.12.14 was used. Raw source sizes and hashes are separate.

FAIRNESS CONTROL
With an identical input/output driver, current minima are 327/354/965.
The uniform checker is 322/355/903: fewer tokens and bytes, but one more AST
node than the controlled minimum. The compatible checker is 326/352/963,
strictly below all three controlled coordinates. Both are standalone
alternatives; neither imports the other. No global-minimality claim is made.

NEW IDEA
--------
The primitive computation equation proves

    box(t) = Iter(0,t;u.0) = t.

The box has a nonempty raw encoding even for t=0. Equality transport converts
any introduction proof to one using a boxed witness. Therefore a falsey
payload can select computation and a truthy payload can select introduction
in a uniform [major,payload] instruction. The extra equality reasoning is
in the certificate and is checked normally. No theorem prover is trusted.

The arithmetic basis is inherited: zero, successor, initialized scalar
iteration, two computation schemas and five native inference patterns.
The report gives the boxed normal form, all rules and side conditions,
full intuitionistic logic reconstruction, internal scalar arithmetic,
whole-domain interpretations and both internal identity composites.
This is a new certificate normal form and a measured implementation advance,
not a new arithmetic foundation or an absolute simplestness theorem.

RUN
---
  python3 checker.py < examples/zero_computation.json
  python3 checker.py < examples/boxed_zero_witness.json
  python3 checker_compatible.py < examples/compatible_zero.json

The last packet cell is the closed goal; preceding cells are instructions
consumed from the end. ACCEPT exits 0 and REJECT exits 1. FORMAT.txt specifies
both formats and the exact decoding. Python 3.10+ and the standard library
suffice. Finite memory/recursion limits may reject large valid certificates;
the mathematical completeness statement uses sufficient finite resources.

REPRODUCE
---------
  python3 reproduce.py
  python3 build.py
  python3 reproduce.py --pdf
  python3 package.py

Reproduction recomputes measurements, translates and rechecks all 147 source
positive fixtures, and runs independent opening/protocol/adversarial/CLI
checks. PDF rebuilding requires pdfLaTeX and the packages in report.tex.
No network downloads are performed. Python version changes may alter exact
normalization counts; mathematical claims do not depend on those spellings.

EVIDENCE
--------
147/147 translated positive certificates accept; 92 zero-witness uses are
boxed, including 28 transported hypotheses and 16 transported conclusions.
2,250 source cells become 2,334 delivered cells. Both interpreters preserve
the final eigenparameter floor on that corpus.

The independent main oracle agrees on 98,280 opening cases, 17 targeted
packets, 15,000 random packets and 2,352 mutations. All 16,029 generated
false-equation attacks reject. There are 36 actual main CLI checks under
normal and optimized Python. The companion has an additional 112,266
opening comparisons, 147 positive fixtures, 1,176 mutations, 5,000 random
packets, seven named cases and 14 public CLI checks.

These are finite checks. The report contains written proofs, not a Lean or
Rocq formalization. The experimental translator is partial and untrusted;
its general completeness claim is the separately proved native boxing
normal form, not an inference from 147 test runs.

CONTENTS
--------
report.tex / report.pdf       Complete research paper and compiled PDF
sections/, appendices/        Complete mathematical source
checker.py                   Main uniform-instruction standalone verifier
checker_compatible.py        Exact old-protocol standalone companion
examples/                    Small positive and negative public packets
comparison/                  Ten frozen current checkers, hashes and licenses
validation/                  Independent oracle, translator and fixtures
results/                     Measurements and validation receipts
measure.py                   Whole-program metric and identical-driver control
build.py / reproduce.py       Offline reproduction entry points
package.py                    Rebuild the ZIP and integrity manifest
ATTRIBUTION.txt / LICENSE     New/inherited contribution boundaries
MANIFEST.sha256               Package-integrity hashes

No changes have been pushed to the GitHub repository.
