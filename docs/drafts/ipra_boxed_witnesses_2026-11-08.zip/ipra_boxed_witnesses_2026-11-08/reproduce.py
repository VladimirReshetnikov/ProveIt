"""Reproduce measurements, translation, and finite validation offline."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pdf', action='store_true', help='Also rebuild the PDF')
    args = parser.parse_args()
    scripts = ['measure.py', 'validation/compile_boxed.py',
               'validation/validate_boxed_oracle.py',
               'validation/validate_adversarial.py',
               'validation/validate_compatible.py']
    if args.pdf:
        scripts.append('build.py')
    for script in scripts:
        result = subprocess.run([sys.executable, str(ROOT / script)],
                                cwd=ROOT, capture_output=True, text=True)
        if result.returncode:
            print(result.stdout)
            print(result.stderr)
            raise SystemExit(f'Failed: {script}')
        print('PASS ' + script, flush=True)
    receipts = {}
    for relative in ['results/measurements.json',
                     'validation/boxed_translation_results.json',
                     'results/oracle.json', 'results/adversarial.json',
                     'results/compatible_validation.json']:
        data = json.loads((ROOT / relative).read_text())
        receipts[relative] = data.get('status', 'MEASURED')
    (ROOT / 'results/reproduction.json').write_text(json.dumps(
        {'status': 'PASS', 'scripts': scripts, 'receipts': receipts,
         'scope': 'Offline finite checks; not a proof-assistant formalization.'},
        indent=2) + '\n')
    print('All requested reproduction steps passed.')


if __name__ == '__main__':
    main()
