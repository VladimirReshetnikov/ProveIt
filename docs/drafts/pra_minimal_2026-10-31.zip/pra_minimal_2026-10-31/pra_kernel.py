#!/usr/bin/env python3
"""Executable syntax and finite semantic checks for the accompanying PRA paper.

This is NOT a formal proof checker or a proof of the equivalence theorem.
The only initial term constructors are variables, 0, and successor.  A fresh
function is introduced by primitive recursion; its base and step terms may
call only earlier functions.  Ordinary term nesting supplies composition.

The Python evaluator is a metalevel universal evaluator.  Mathematically it
is total recursive on well-formed programs and natural-number inputs; it is
NOT primitive recursive uniformly in program syntax.  Individual programs
in this language denote primitive recursive functions.  Python resource
limits still apply to actual execution.

Run with Python 3.10 or later, using only the standard library:
    python3 pra_kernel.py
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from itertools import product
import json


@dataclass(frozen=True)
class Var:
    index: int


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Suc:
    argument: Term


@dataclass(frozen=True)
class Call:
    name: str
    arguments: tuple[Term, ...]


Term = Var | Zero | Suc | Call
ZERO = Zero()
ONE = Suc(ZERO)


def call(name: str, *arguments: Term) -> Call:
    return Call(name, tuple(arguments))


@dataclass(frozen=True)
class Definition:
    name: str
    parameters: int
    base: Term
    step: Term


class Program:
    """An ordered list of primitive recursion declarations.

    For k parameters, base variables are (a_0, ..., a_{k-1}); step variables
    are (n, previous, a_0, ..., a_{k-1}).  The declared function takes the
    recursion argument first, followed by its k parameters.
    """

    def __init__(self) -> None:
        self.definitions: dict[str, Definition] = {}

    def validate(self, term: Term, variables: int) -> None:
        if isinstance(term, Var):
            if type(term.index) is not int or not 0 <= term.index < variables:
                raise ValueError("Variable index is outside the current scope")
        elif isinstance(term, Zero):
            return
        elif isinstance(term, Suc):
            self.validate(term.argument, variables)
        elif isinstance(term, Call):
            if term.name not in self.definitions:
                raise ValueError("Calls must reference an earlier declaration")
            arity = self.definitions[term.name].parameters + 1
            if len(term.arguments) != arity:
                raise ValueError(f"{term.name} requires {arity} arguments")
            for argument in term.arguments:
                self.validate(argument, variables)
        else:
            raise TypeError("Unknown term constructor")

    def declare(self, name: str, parameters: int, base: Term, step: Term) -> None:
        if not name.isidentifier() or name == "S" or name in self.definitions:
            raise ValueError("A declaration requires a fresh function name")
        if type(parameters) is not int or parameters < 0:
            raise ValueError("The parameter count must be a natural number")
        # Check before insertion: neither forward references nor self-calls
        # are allowed.  The recursive value is supplied by Var(1) in step.
        self.validate(base, parameters)
        self.validate(step, parameters + 2)
        self.definitions[name] = Definition(name, parameters, base, step)

    def evaluate(self, term: Term, *environment: int) -> int:
        if any(type(value) is not int or value < 0 for value in environment):
            raise ValueError("Inputs must be natural numbers")
        self.validate(term, len(environment))
        return self._evaluate(term, tuple(environment))

    def _evaluate(self, term: Term, environment: tuple[int, ...]) -> int:
        if isinstance(term, Var):
            return environment[term.index]
        if isinstance(term, Zero):
            return 0
        if isinstance(term, Suc):
            return self._evaluate(term.argument, environment) + 1
        if isinstance(term, Call):
            values = tuple(self._evaluate(t, environment) for t in term.arguments)
            return self._apply(term.name, values)
        raise TypeError("Unknown term constructor")

    @lru_cache(maxsize=None)
    def _apply(self, name: str, arguments: tuple[int, ...]) -> int:
        definition = self.definitions[name]
        recursion_argument, *parameters = arguments
        value = self._evaluate(definition.base, tuple(parameters))
        for n in range(recursion_argument):
            value = self._evaluate(definition.step, (n, value, *parameters))
        return value


def arithmetic_program() -> Program:
    program = Program()
    program.declare("p", 0, ZERO, Var(0))
    program.declare("z", 0, ONE, ZERO)
    program.declare("C", 2, Var(0), Var(3))
    program.declare("add", 1, Var(0), Suc(Var(1)))
    program.declare("A", 1, Var(0), call("p", Var(1)))
    program.declare(
        "B", 1, ZERO,
        call("C", call("A", Var(0), Var(2)), Suc(Var(1)), Var(1)),
    )
    return program


def distance(left: Term, right: Term) -> Term:
    """A term abbreviation, not a new primitive symbol or declaration."""
    return call("add", call("A", left, right), call("B", left, right))


@dataclass(frozen=True)
class Eq:
    left: Term
    right: Term


@dataclass(frozen=True)
class Not:
    argument: Formula


@dataclass(frozen=True)
class And:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Or:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Implies:
    left: Formula
    right: Formula


Formula = Eq | Not | And | Or | Implies


def compile_error(formula: Formula) -> Term:
    """Compile a quantifier-free formula to a term: zero means true.

    Outputs need not be Boolean.  Disjunction and implication use C directly
    and require no multiplication program.  This is a syntactic construction.
    Its general correctness is proved in the paper, not by the finite tests.
    """
    if isinstance(formula, Eq):
        return distance(formula.left, formula.right)
    if isinstance(formula, Not):
        return call("z", compile_error(formula.argument))
    left = compile_error(formula.left)
    right = compile_error(formula.right)
    if isinstance(formula, And):
        return call("add", left, right)
    if isinstance(formula, Or):
        return call("C", left, ZERO, right)
    if isinstance(formula, Implies):
        return call("C", left, right, ZERO)
    raise TypeError("Unknown formula constructor")


def truth(program: Program, formula: Formula, environment: tuple[int, ...]) -> bool:
    if isinstance(formula, Eq):
        return program.evaluate(formula.left, *environment) == program.evaluate(
            formula.right, *environment
        )
    if isinstance(formula, Not):
        return not truth(program, formula.argument, environment)
    left = truth(program, formula.left, environment)
    right = truth(program, formula.right, environment)
    if isinstance(formula, And):
        return left and right
    if isinstance(formula, Or):
        return left or right
    if isinstance(formula, Implies):
        return not left or right
    raise TypeError("Unknown formula constructor")


def display(term: Term, variables: tuple[str, ...] = ()) -> str:
    if isinstance(term, Var):
        return variables[term.index] if term.index < len(variables) else f"x{term.index}"
    if isinstance(term, Zero):
        return "0"
    if isinstance(term, Suc):
        return f"S({display(term.argument, variables)})"
    return f"{term.name}({', '.join(display(t, variables) for t in term.arguments)})"


def finite_checks() -> dict:
    program = arithmetic_program()
    x, y = Var(0), Var(1)
    values = range(9)
    counts = {"arithmetic_assertions": 0, "selector_assertions": 0,
              "formula_environments": 0, "rejected_invalid_declarations": 0}

    def check(condition: bool, category: str) -> None:
        if not condition:
            raise AssertionError(f"Finite check failed: {category}")
        counts[category] += 1

    for n in values:
        check(program.evaluate(call("p", x), n) == max(n - 1, 0), "arithmetic_assertions")
        check(program.evaluate(call("z", x), n) == int(n == 0), "arithmetic_assertions")
    for n, m in product(values, repeat=2):
        a = program.evaluate(call("A", x, y), n, m)
        b = program.evaluate(call("B", x, y), n, m)
        d = program.evaluate(distance(x, y), n, m)
        for condition in (a == max(m - n, 0), b == max(n - m, 0),
                          d == abs(n - m), (d == 0) == (n == m),
                          n + a == m + b,
                          program.evaluate(call("add", x, y), n, m) == n + m):
            check(condition, "arithmetic_assertions")
    for n, u, v in product(range(5), repeat=3):
        result = program.evaluate(call("C", Var(0), Var(1), Var(2)), n, u, v)
        check(result == (u if n == 0 else v), "selector_assertions")

    samples: list[tuple[str, Formula]] = [
        ("x = y", Eq(x, y)),
        ("not (x = y)", Not(Eq(x, y))),
        ("x + y = y + x", Eq(call("add", x, y), call("add", y, x))),
        ("x = y and not (x = 0)", And(Eq(x, y), Not(Eq(x, ZERO)))),
        ("x = 0 or y = 1", Or(Eq(x, ZERO), Eq(y, ONE))),
        ("x = 0 implies y = 0", Implies(Eq(x, ZERO), Eq(y, ZERO))),
        ("not ((x = y or x = 0) implies y = 1)",
         Not(Implies(Or(Eq(x, y), Eq(x, ZERO)), Eq(y, ONE)))),
        ("(x = 1 implies y = 0) and (y = 0 or x = y)",
         And(Implies(Eq(x, ONE), Eq(y, ZERO)), Or(Eq(y, ZERO), Eq(x, y)))),
    ]
    for _, formula in samples:
        compiled = compile_error(formula)
        for environment in product(values, repeat=2):
            check((program.evaluate(compiled, *environment) == 0)
                  == truth(program, formula, environment), "formula_environments")

    invalid = [
        ("bad_scope", 0, Var(0), ZERO),
        ("bad_forward", 0, call("not_declared", ZERO), ZERO),
        ("bad_arity", 0, call("p", ZERO, ZERO), ZERO),
        ("bad_self", 0, ZERO, call("bad_self", Var(0))),
    ]
    for declaration in invalid:
        try:
            program.declare(*declaration)
        except ValueError:
            counts["rejected_invalid_declarations"] += 1
        else:
            raise AssertionError("An invalid declaration was accepted")

    witness = (0, 1)
    product_zero, product_one = (0, 0), (1, 1)
    z_witness = tuple(int(coordinate == 0) for coordinate in witness)
    return {
        "status": "All finite sanity checks passed; no formal proof was checked.",
        "natural_number_sample": {"minimum": 0, "maximum": 8},
        "declaration_count": len(program.definitions),
        "counts": counts,
        "compiled_examples": [
            {"formula": label, "error_term": display(compile_error(formula), ("x", "y"))}
            for label, formula in (samples[0], samples[4], samples[5])
        ],
        "product_counterexample": {
            "parameter": witness,
            "predicate": "x != parameter",
            "base_case": product_zero != witness,
            "conclusion_at_parameter": witness != witness,
            "successor_observation": "Any successor has positive first coordinate, so cannot equal (0, 1).",
            "coordinatewise_zero_test_at_parameter": z_witness,
            "zero_test_is_either_global_zero_or_global_one": z_witness in (product_zero, product_one),
            "scope": "An explicit witness; the script does not verify all atomic induction instances.",
        },
    }


if __name__ == "__main__":
    print(json.dumps(finite_checks(), indent=2, sort_keys=True))
