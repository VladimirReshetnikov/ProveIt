A Small Kernel for Primitive Recursive Arithmetic
Prepared for Vladimir Reshetnikov -- 31 October 2026

RESULT

An exact first-order presentation of PRA consists of:
  * the two equations for each primitive-recursion declaration;
  * the single ground separation axiom 0 != S(0);
  * induction only for equalities and disequalities, with parameters.

Projection and composition are represented by variables and ordinary term
formation. No additional successor axioms are needed. The paper supplies
a complete internal proof of equivalence with full quantifier-free
induction, including an explicit equality comparator and formula compiler.

It also describes a fixed implication-of-equations induction pattern,
an equivalent equation-induction-plus-exhaustion presentation, and the
classical Goodstein equational calculus. The latter has theorem
correspondence under translation and must not be confused with literal
equivalence of first-order model classes.

No absolute optimality, new historical priority, minimal machine-state
count, or machine-checked proof is claimed.

FILES

pra_minimal.pdf   Complete research note, with proofs and further questions.
pra_minimal.tex   Self-contained LaTeX source; bibliography is embedded.
axioms.txt        Standalone specification of the first-order kernel.
pra_kernel.py     Executable recursion-only syntax and formula compiler.
verification.txt  Actual output of the script's finite sanity checks.
Makefile          Commands to build the PDF and rerun the code.
SHA256SUMS        Digests of the files in this directory, excluding itself.

BUILD THE PDF

From this directory, use:
    make pdf

Or run twice:
    pdflatex -interaction=nonstopmode -halt-on-error pra_minimal.tex

Dependencies: a standard LaTeX installation with Latin Modern, microtype,
amsmath/amssymb/amsthm, mathtools, geometry, booktabs, enumitem, tcolorbox,
xcolor, titlesec, fancyhdr, and hyperref. No BibTeX run is required.

RUN THE EXECUTABLE ARTIFACT

Use Python 3.10 or later, with no external packages:
    python3 pra_kernel.py

The interpreter checks declaration scope, arities, and dependency order.
Its six helper functions are predecessor, zero test, case selector,
addition, countdown, and overflow. The compiler translates a quantifier-free
formula to a term that is zero exactly when the formula holds.

The recorded run checked 504 arithmetic assertions, 125 selector assertions,
648 sample formula/environment cases, and rejection of four invalid
declarations. These are finite semantic sanity checks. They do not prove
the theorem and are not a formal proof assistant verification. The general
proof is the mathematical argument in the PDF and LaTeX source.

The metalevel Python evaluator is not asserted to be primitive recursive
uniformly in program syntax; every fixed declared program is primitive
recursive. Actual execution is subject to ordinary resource limits.

SCOPE AND NEXT STEPS

The paper distinguishes finitely many schemes from finitely many axioms,
retains all number parameters, gives the product countermodel to an
incorrect equation-only simplification, and lists further research
questions, including a verified Lean or Rocq proof translation.

References are linked in the paper. No reference papers are redistributed.
