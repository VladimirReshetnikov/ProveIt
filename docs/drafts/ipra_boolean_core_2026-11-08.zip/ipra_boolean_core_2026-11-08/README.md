# The Boolean gap in equation induction

Prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific time).

## Read first

The complete mathematical report is **report.pdf**, compiled from **report.tex**
and the included section and appendix sources.

This package establishes an explicit equivalence between full quantifier-free
iPRA and an equational-induction presentation supplemented by one fixed
Boolean-range axiom. It also proves an automorphism obstruction to
bi-interpretability of theories admitting direct-product models, with an
arbitrary-power version allowing finite parameters.

The acceptance program combines existing boxed-witness and context-block
methods. Against all nine current root checkers in the six supplied archives,
it improves normalized tokens and source bytes, but **does not improve the AST
minimum**:

| Measure | Current minimum | This checker |
| --- | ---: | ---: |
| Normalized tokens | 322 | 319 |
| AST nodes | 350 | 352 |
| Normalized bytes | 903 | 898 |

This is not a claim of an absolutely simplest axiomatization, of strict
improvement in every measure, or of the requested major new arithmetic
foundation. Mathematical novelty is claimed only relative to the inspected
draft corpus, with the underlying standard model-theoretic facts attributed.

## Exact source boundary

Repository: VladimirReshetnikov/ProveIt  
Commit: 6fac3001a902d6666186fc4692a96de0ef296cf7

**comparison/manifest.json** identifies all six source archives by Git blob and
SHA-256 and all nine frozen root checkers by SHA-256. The inherited measurement
normalizer is included unchanged. Common-name and common-driver controls are
recorded in **results/measurements.json**.

## Run the checker

The checker reads one JSON packet from standard input:

    python3 checker.py < examples/zero_computation.json

A valid packet prints ACCEPT and exits zero. A rejected packet prints
REJECT and exits one. The supplied false example is expected to reject:

    python3 checker.py < examples/false_computation.json

The format and its scope convention are defined in the report. The program
checks native certificates; it is not an interactive prover or a parser for
ordinary first-order proof text. It imports only json and sys.

## Reproduce

Python 3.12 was used for the recorded source measurements and tests.
A standard LaTeX installation including pdflatex is required for the PDF.

    python3 reproduce.py

Or run the steps separately:

    python3 comparison/measure.py
    python3 validation/run.py
    python3 build.py

To recreate the ZIP and its SHA-256 manifest after a build:

    python3 package.py

The validation result records 147 certificate translations checked against a
separately sorted oracle, 16,029 rejected false-equation attacks, and 36 public
CLI cases under normal and optimized Python. These are finite implementation
checks, not proof-assistant formalizations of the mathematical metatheorems.

## Contents

- report.tex, sections/, appendices/: complete LaTeX sources.
- report.pdf: compiled report.
- checker.py: entire project-specific accepting program.
- comparison/: frozen source programs, provenance, measurement code.
- validation/: fixture translator, separate oracle, source and translated
  certificates, and reproduction driver.
- examples/: small accepted and rejected public packets.
- results/: measurement tables, validation results, build and PDF QA records.
- attribution/: preserved inherited notices.
- SHA256SUMS.txt: checksums for the final package contents.

The scalar arithmetic and gate/selector reconstruction are inherited from the
supplied drafts and credited in the report. The new report is self-contained:
no network request or undistributed proof-checking module is required.

