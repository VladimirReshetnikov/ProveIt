"""Reproduce measurements, finite validation, and the compiled report."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

for script in ("comparison/measure.py", "validation/run.py", "build.py"):
    subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)
print("Reproduction completed. See results/measurements.json and results/validation.json.")

