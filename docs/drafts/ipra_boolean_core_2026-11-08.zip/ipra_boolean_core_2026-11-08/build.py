"""Compile the complete report with a standard LaTeX installation."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    executable = shutil.which("pdflatex")
    if executable is None:
        raise SystemExit("pdflatex is required to build report.pdf")
    for run in range(3):
        result = subprocess.run(
            [executable, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
            cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT
        )
        (ROOT / "results" / "latex-build.txt").write_text(result.stdout)
        if result.returncode:
            print(result.stdout[-10000:])
            raise SystemExit(result.returncode)
    log = (ROOT / "report.log").read_text(errors="replace")
    failures = ("There were undefined references", "There were undefined citations",
                "multiply defined", "Overfull ")
    found = [phrase for phrase in failures if phrase in log]
    if found:
        raise SystemExit("LaTeX review required: " + ", ".join(found))
    print("Built report.pdf; no undefined references, citations, or overfull boxes.")


if __name__ == "__main__":
    main()

