CANONICAL AND RAW-BOUNDARY EXAMPLES

From the package directory:
  python3 checker.py < examples/zero_computation.json       ACCEPT
  python3 checker.py < examples/false_computation.json      REJECT (exit 1)
  python3 checker.py < examples/boxed_zero_witness.json     ACCEPT
  python3 checker.py < examples/equation_induction.json     ACCEPT

failed_major_fallthrough.json is an accepted raw-boundary regression case,
not a recommended proof-production format. It verifies that a failed major
can be discarded without leaking its local assumptions, after which the
actual introduction succeeds. Canonical producers do not need fallthrough.

Run python3 validation/run.py to reconstruct all translated positive
certificates, the examples, and results/validation.json. The single main
checker does not import the compiler, oracle, fixtures, or measurement code.
