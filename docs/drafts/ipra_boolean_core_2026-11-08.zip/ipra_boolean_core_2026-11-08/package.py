#!/usr/bin/env python3
"""Package the complete deliverable and verify every archived checksum."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile


ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {".aux", ".log", ".out", ".toc", ".pyc"}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def package():
    members = sorted(
        p for p in ROOT.rglob("*")
        if p.is_file()
        and not p.is_symlink()
        and "__pycache__" not in p.parts
        and p.suffix not in EXCLUDED_SUFFIXES
        and p.name != "SHA256SUMS.txt"
    )
    sums = ROOT / "SHA256SUMS.txt"
    sums.write_text("".join(
        f"{digest(p)}  {p.relative_to(ROOT).as_posix()}\n" for p in members
    ))
    members.append(sums)
    archive = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as output:
        for path in sorted(members):
            name = f"{ROOT.name}/{path.relative_to(ROOT).as_posix()}"
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 9, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            output.writestr(info, path.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(archive) as check:
        assert check.testzip() is None, "Archive CRC verification failed"
        for line in sums.read_text().splitlines():
            expected, name = line.split("  ", 1)
            content = check.read(f"{ROOT.name}/{name}")
            assert hashlib.sha256(content).hexdigest() == expected, name
        assert any(p.suffix == ".tex" for p in members)
        assert "report.pdf" in {p.name for p in members}
    pdf = ROOT.parent / (ROOT.name + ".pdf")
    shutil.copyfile(ROOT / "report.pdf", pdf)
    result = {
        "status": "PASS",
        "archive": str(archive),
        "archived_files": len(members),
        "archive_bytes": archive.stat().st_size,
        "archive_sha256": digest(archive),
        "pdf": str(pdf),
        "pdf_sha256": digest(pdf),
        "verified_file_checksums": len(members) - 1,
        "archive_crc": "PASS",
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    package()
