"""Reproduce the complete current-corpus comparison and uniform controls.

Only two global function names and the already equivalent rejection driver
are normalized by the controls. Source programs and their checking logic are
not edited. The inherited whole-program normalizer is used unchanged.
"""
import ast
import csv
import hashlib
import json
from pathlib import Path
import platform
import tempfile

from source_measure import metrics

ROOT = Path(__file__).resolve().parent.parent
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
PROFILES = ('delivered', 'common_driver', 'common_names',
            'common_names_and_driver')
DRIVER = '''try:
    take = json.load(sys.stdin).pop
    1 / test(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    raise SystemExit(1)
'''


class CommonNames(ast.NodeTransformer):
    """Rename the two inspected global definitions and all their name uses."""
    names = {'inst': 'sub', 'check': 'test'}

    def visit_Name(self, node):
        node.id = self.names.get(node.id, node.id)
        return node

    def visit_FunctionDef(self, node):
        node.name = self.names.get(node.name, node.name)
        return self.generic_visit(node)


def dump(tree):
    return ast.dump(tree, include_attributes=False)


def inspect_boundary(source):
    """Reject an unrecognized source boundary rather than omit any code."""
    tree = ast.parse(source)
    if (tree.body and isinstance(tree.body[0], ast.Expr)
            and isinstance(tree.body[0].value, ast.Constant)
            and isinstance(tree.body[0].value.value, str)):
        tree.body.pop(0)
    if sum(isinstance(n, ast.Try) for n in tree.body) != 1:
        raise ValueError('Expected exactly one top-level driver')
    if not isinstance(tree.body[-1], ast.Try):
        raise ValueError('Driver is not the final top-level statement')
    prefix = tree.body[:-1]
    if not all(isinstance(n, (ast.Import, ast.FunctionDef, ast.Assign))
               for n in prefix):
        raise ValueError('Unrecognized top-level statement')
    definitions = [n.name for n in prefix if isinstance(n, ast.FunctionDef)]
    if definitions not in (['inst', 'check'], ['sub', 'test']):
        raise ValueError('Unrecognized checking entry points')
    assignments = [n for n in prefix if isinstance(n, ast.Assign)]
    if len(assignments) != 1 or dump(assignments[0]) != dump(ast.parse('k=0').body[0]):
        raise ValueError('Unexpected top-level data')
    common = CommonNames().visit(ast.parse(source))
    common_driver = common.body[-1]
    expected = ast.parse(DRIVER).body[-1]
    alternate = ast.parse(DRIVER.replace('raise SystemExit(1)', 'sys.exit(1)')).body[-1]
    if dump(common_driver) not in (dump(expected), dump(alternate)):
        raise ValueError('Driver is not one of the two inspected equivalents')
    return definitions[-1]


def controlled(source, names=False, driver=False):
    checker = inspect_boundary(source)
    tree = ast.parse(source)
    original_prefix = dump(ast.Module(body=tree.body[:-1], type_ignores=[]))
    if names:
        tree = CommonNames().visit(tree)
        checker = 'test'
    if driver:
        replacement = DRIVER.replace('test(take()', checker + '(take()')
        tree.body[-1] = ast.parse(replacement).body[-1]
    if not names:
        actual_prefix = dump(ast.Module(body=tree.body[:-1], type_ignores=[]))
        if actual_prefix != original_prefix:
            raise ValueError('Driver control altered a checking operation')
    else:
        reference = CommonNames().visit(ast.parse(source))
        if dump(ast.Module(body=tree.body[:-1], type_ignores=[])) != dump(
                ast.Module(body=reference.body[:-1], type_ignores=[])):
            raise ValueError('Name control altered more than the two names')
    result = ast.unparse(ast.fix_missing_locations(tree)) + '\n'
    compile(result, '<controlled>', 'exec')
    return result


def whole_metrics(path):
    # The inherited import-stripped "core" view is not used or advertised.
    return {key: value for key, value in metrics(path).items() if key != 'core'}


def profiles(path, temporary):
    source = path.read_text()
    inspect_boundary(source)
    answer = {'delivered': whole_metrics(path)}
    for profile, names, driver in (
            ('common_driver', False, True),
            ('common_names', True, False),
            ('common_names_and_driver', True, True)):
        temporary.write_text(controlled(source, names, driver))
        answer[profile] = whole_metrics(temporary)
    return answer


def tex_row(label, values):
    return label + ' & ' + ' & '.join(str(values[k]) for k in FIELDS) + r' \\'


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    normalizer_hash = hashlib.sha256(
        (ROOT / 'comparison/source_measure.py').read_bytes()).hexdigest()
    if normalizer_hash != manifest['measurement_normalizer']['sha256']:
        raise ValueError('Changed inherited measurement normalizer')
    with tempfile.TemporaryDirectory() as scratch:
        temporary = Path(scratch) / 'controlled.py'
        baselines = []
        for entry in manifest['programs']:
            path = ROOT / 'comparison' / entry['local_file']
            if hashlib.sha256(path.read_bytes()).hexdigest() != entry['sha256']:
                raise ValueError('Changed frozen baseline: ' + entry['label'])
            baselines.append({**entry, 'profiles': profiles(path, temporary)})
        candidate = {'file': 'checker.py',
                     'profiles': profiles(ROOT / 'checker.py', temporary)}
    minima = {profile: {field: min(row['profiles'][profile][field]
                                  for row in baselines)
                        for field in FIELDS}
              for profile in PROFILES}
    comparisons = {profile: {
        field: candidate['profiles'][profile][field] < minima[profile][field]
        for field in FIELDS} for profile in PROFILES}
    result = {
        'status': ('STRICT_COORDINATE_DOMINANCE' if all(
            all(values.values()) for values in comparisons.values())
            else 'PARTIAL_IMPROVEMENT_NO_COORDINATE_DOMINANCE'),
        'repository': manifest['repository'], 'commit': manifest['commit'],
        'python': platform.python_version(),
        'implementation': platform.python_implementation(),
        'archive_count': len(manifest['archives']),
        'program_count': len(baselines), 'coordinates': list(FIELDS),
        'metric_source_sha256': normalizer_hash,
        'control_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'minima': minima,
        'attainers': {profile: {field: [row['label'] for row in baselines
            if row['profiles'][profile][field] == minima[profile][field]]
            for field in FIELDS} for profile in PROFILES},
        'candidate': candidate, 'strict_improvement': comparisons,
        'baseline_programs': baselines,
        'scope': 'All imports, data, checking operations, input parsing, output '
                 'and rejection are counted. No project-specific interpreter '
                 'or helper module is omitted.',
        'controls': 'Common names replace only inst/check by sub/test. '
                    'The common driver has identical JSON input, ACCEPT/REJECT '
                    'output and raise-SystemExit(1) rejection. Every original '
                    'driver is structurally checked against the two equivalent '
                    'raise-SystemExit/sys.exit drivers before transformation.',
        'limitation': 'Tokens and bytes are not a language-independent measure. '
                      'The candidate does not beat every coordinate minimum; '
                      'in particular its delivered AST count exceeds the '
                      'current context-block minimum.'}
    destination = ROOT / 'results'
    destination.mkdir(exist_ok=True)
    (destination / 'measurements.json').write_text(json.dumps(result, indent=2) + '\n')
    with (destination / 'measurements.csv').open('w', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(['program', 'profile', *FIELDS])
        for row in baselines + [candidate]:
            for profile in PROFILES:
                writer.writerow([row.get('label', row.get('file')), profile,
                                 *(row['profiles'][profile][field] for field in FIELDS)])
    table = [r'\begin{tabular}{@{}lrrr@{}}', r'\toprule',
             r'Complete program / profile & Tokens & AST nodes & Bytes \\', r'\midrule']
    for profile, label in [('delivered', 'Delivered'),
                           ('common_driver', 'Common driver'),
                           ('common_names', 'Common names'),
                           ('common_names_and_driver', 'Common names and driver')]:
        table.append(tex_row(label + ': current minima', minima[profile]))
        table.append(tex_row(label + ': candidate', candidate['profiles'][profile]))
        if profile != PROFILES[-1]:
            table.append(r'\addlinespace')
    table.extend([r'\bottomrule', r'\end{tabular}'])
    (destination / 'comparison_table.tex').write_text('\n'.join(table) + '\n')
    complete = [r'\begin{tabular}{@{}lrrr@{}}', r'\toprule',
                r'Current complete checker & Tokens & AST nodes & Bytes \\', r'\midrule']
    for row in baselines:
        label = row['label'].replace('ipra_', '').replace('_2026-11-08', '')
        complete.append(tex_row(label.replace('_', r'\_'), row['profiles']['delivered']))
    complete.extend([r'\midrule', tex_row('Candidate synthesis', candidate['profiles']['delivered']),
                     r'\bottomrule', r'\end{tabular}'])
    (destination / 'all_programs.tex').write_text('\n'.join(complete) + '\n')
    print(json.dumps({'status': result['status'], 'minima': minima,
                      'candidate': {profile: {field: candidate['profiles'][profile][field]
                                             for field in FIELDS} for profile in PROFILES},
                      'strict_improvement': comparisons}, indent=2))


if __name__ == '__main__':
    main()
