"""Named-rule oracle for the boxed-witness checker.

Adapted from the independently sorted oracle in the supplied compact draft,
validation/validation_sources/oracle_erasure.py. That source credits ProveIt
commit df8beb801d9f3e3eb3a8141722953fb58e63009e (uniform-scopes oracle).
Preserve its inherited license when redistributing this file.

Changes inherited: retained truth labels, the empty-object alias, uniform two-cell
instructions, and truthy-payload introduction. Additional synthesis change:
paired elimination pads with truth, and non-atomic introduction pads with truth,
so every extended context has two added entries. No production kernel is imported
and no packed scope table is used. The oracle is validation evidence, not a
proof-assistant formalization of the metatheorems.
"""
from copy import deepcopy

class Oracle:
    def __init__(self):
        self.lower = 0
        self.rules = {}

    def rule(self, name):
        self.rules[name] = self.rules.get(name, 0) + 1

    def leaf(self, value, image, protected, formula):
        if not isinstance(value, (int, float)):
            raise ValueError('non-numerical coordinate')
        ceiling = 2 * protected + (0 if formula else 1)
        if self.lower <= value < ceiling:
            return value
        if formula:
            return 0
        return self.term(image)

    def term(self, value, image=None, protected=0):
        if type(value) is dict and not value:
            return []
        if type(value) is not list:
            return self.leaf(value, image, protected, False)
        if len(value) == 0:
            return []
        if len(value) == 1:
            return [self.term(value[0], image, protected + 1)]
        if len(value) == 2:
            return [self.formula(child, image, protected + 1) for child in value]
        if len(value) == 3:
            count, initial, update = value
            return [self.term(count, image, protected + 2),
                    self.term(initial, image, protected + 2),
                    self.term(update, image, protected + 2)]
        raise ValueError('term arity')

    def formula(self, value, image=None, protected=0):
        if type(value) is dict and not value:
            return []
        if type(value) is not list:
            return self.leaf(value, image, protected, True)
        if len(value) == 0:
            return []
        if len(value) == 1:
            return [self.formula(value[0], image, protected + 1)]
        if len(value) == 2:
            return [self.term(value[0], image, protected),
                    self.term(value[1], image, protected)]
        if len(value) == 3:
            return [self.formula(child, image, protected + 2) for child in value]
        raise ValueError('formula arity')

    def fresh(self):
        self.lower -= 1
        return self.lower

    def check(self, goal, context):
        checked = self.formula(goal)
        if checked in context:
            self.rule('hypothesis')
            return True
        instruction = self.stack.pop()
        major, payload = instruction
        if major:
            if self.check(major, context):
                if type(major) is not list:
                    raise ValueError('usable major must be an array')
                if len(major) == 3:
                    self.rule('paired_elimination')
                    eigen = self.fresh()
                    assumption = self.formula([major[2]], eigen)
                    return self.check(self.formula(goal, [eigen]), context + [0, assumption])
                if len(major) == 1:
                    self.rule('closure_elimination')
                    matrix, left, right = major[0], 0, payload
                elif len(major) == 2:
                    self.rule('equality_transport')
                    matrix = payload
                    left, right = major
                else:
                    raise ValueError('major arity')
                if self.formula(matrix, right) != goal:
                    return False
                return self.check(self.formula(matrix, left), context)
            self.rule('failed_major_fallthrough')
        if payload:
            if type(goal) is not list or len(goal) != 3:
                raise ValueError('paired goal required')
            self.rule('paired_introduction')
            matrix = self.formula(goal[2], payload, 1)
            base = self.formula(matrix, 0)
            if type(matrix) is not list:
                raise ValueError('array matrix required')
            if len(matrix) in (0, 2):
                self.rule('equation_induction' if len(matrix) == 2 else 'empty_truth_intro')
                assumptions = [matrix, base]
            else:
                assumptions = [0, base]
            eigen = self.fresh()
            return self.check(self.formula(matrix, [eigen]),
                              context + [self.formula(a, eigen) for a in assumptions])
        self.rule('computation')
        if type(goal) is not list or len(goal) != 2:
            raise ValueError('equation required')
        left, right = goal
        if type(left) is not list or len(left) != 3:
            raise ValueError('iterator required')
        count, initial, update = left
        if not count:
            self.rule('computation_zero')
            expected = initial
        elif type(count) is list and len(count) == 1:
            self.rule('computation_successor')
            expected = self.term(update, [count[0], initial, update])
        else:
            raise ValueError('zero or successor counter required')
        return right == expected

    def run(self, packet):
        self.lower = 0
        self.rules = {}
        self.stack = deepcopy(packet)
        try:
            accepted = bool(self.check(self.stack.pop(), []))
            error = None
        except Exception as exc:
            accepted = False
            error = type(exc).__name__
        return {'accepted': accepted, 'final_k': self.lower,
                'remaining': len(self.stack) if type(self.stack) is list else None,
                'rules': dict(self.rules), 'error': error}
