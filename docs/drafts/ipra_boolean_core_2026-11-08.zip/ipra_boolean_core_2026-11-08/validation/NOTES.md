# Experimental synthesis: mathematical scope and exact result

## Status

`checker.py` is a synthesis of three already supplied techniques,
not a new arithmetic basis. Under the inherited whole-program normalizer it
has **319 normalized tokens, 352 AST nodes, and 898 normalized bytes**. The
current six-archive envelope is 322 tokens / 350 AST nodes / 903 bytes.
Consequently this prototype improves tokens and bytes but **does not improve
every coordinate**. Its AST count is two above the current minimum. It is
strictly smaller in all three coordinates than the supplied boxed-witness
primary checker (322 / 355 / 903).

No claim of an absolute minimum, a new foundation, or a new soundness theorem
proved in a proof assistant is made. The trusted kernel is the complete file,
including its input/output and rejection driver. Its mathematical foundation
is the five-pattern auxiliary native calculus in the supplied drafts.

## Provenance

Repository snapshot: `6fac3001a902d6666186fc4692a96de0ef296cf7`.

- `boxed_witnesses/checker.py` supplies the uniform `[major,payload]`
  instruction convention, `.copy()` opener, four-entry scope table, and
  raising driver.
- `context_blocks/checker.py` supplies the two-entry assumption blocks and
  `inst(h,k,-1)` opening identity.
- The empty-tail membership classification is already used by the boxed
  checker. Here its context list has the additional harmless entry zero.

The original three-entry scope-table variant was retained as an ablation.
For nonempty arrays of length 1, 2, 3, `b'\4\1\2'[-len(a)]` and
`b'\0\2\1\4'[len(a)]` return the same offsets 2, 1, 4. The offset at an
empty array is not used. The negative index saves normalized bytes but adds
two AST nodes. The primary chooses the existing four-entry table to reduce
AST cost. The `.copy()` and `a + []` traversals differ on empty objects: the
former normalizes `{}` to `[]`; the latter rejects it. The primary retains
the original boxed checker's already documented `.copy()` semantics.

## Mathematical transformations

### Witness boxing

For every numerical term `t`, let `box(t)=I(0,t;u.0)`. The zero-iteration
computation schema proves `box(t)=t`. The term is always syntactically
nonempty and has exactly the free parameters of `t`.

To replace an introduction witness `t` by `box(t)`, transport each local
assumption along this equality to the old assumption, reuse the old proof,
and transport its conclusion back along the symmetric equality. The optional
induction hypothesis is transported only for a literal equation. It is not
granted to compound formulas. This preserves the final paired formula and
the eigenparameter side condition. `validation/compile_boxed.py` performs this
transformation for every introduction witness, including already nonempty
ones. Computation cells become `[0,0]`; introductions become `[0,box(t)]`
with the necessary transports; existing elimination cells remain unchanged.

A literal replacement of just the witness field is not sufficient in
general. The additional transports are essential and checked by the kernel.

### Fixed context blocks

An atomic introduction retains both its equation induction hypothesis and
its base. A compound introduction retains its base and a harmless truth.
Paired elimination retains its opened closure and a harmless truth.

Let `O(a;t,d)` be the raw opening traversal. Binary nodes increase its
depth by one. Therefore

`O([A,B];t,-1)=[O(A;t,0),O(B;t,0)]`.

This identity justifies replacing a separate traversal over a local context
list by one traversal over its binary frame. The offset -1 is an internal
scope offset, not a negative natural number in the interpreted domain.

For a compound introduction `len(a)%2 or a` is the scalar 1, which opens
at formula depth zero to scalar 0. Scalar formula zero denotes truth. For
literal equations it retains `a`; for the empty truth array it retains
that empty array. Thus the equation-only restriction is preserved.

### Tail classification

After a successful elimination major, set the local block to
`[0,m[2:]]`. Its second entry is empty exactly when a usable major is an
equation or unary closure. Because Python `0 != []`,

`[] in [0,m[2:]]`

is equivalent to the prior `not [0,m[2:]][1]` test for these majors.
This is an implementation reuse, not an additional mathematical reduction.

## Raw-input and rejection details

1. The new padded contexts contain scalar zero, so it is false that every
   retained raw context entry is an array. The corrected invariant is that
   every entry denotes a valid formula; the new scalar entries denote truth.
2. A truthy scalar major may now prove itself by hypothesis membership. It
   still cannot serve as an elimination major: the subsequent slice/index
   operations raise and the public driver rejects. A successful major used
   by an elimination is therefore still an array of the appropriate arity.
3. The `.copy()` opener permits the existing empty-object-to-empty-array
   alias. Traversed strings and nonempty objects reject. Unused instruction
   payloads can be inert; no claim is made that every ignored raw value is
   validated. Canonical instructions are two-field arrays, but Python
   unpacking can accept some other two-element iterables at the raw public
   boundary. Any successfully used data still follow the native extraction
   argument.
4. If a truthy major check returns false normally, the outer checker can
   fall through to introduction or computation using the payload. The failed
   attempt may consume cells and decrease the freshness floor. It does not
   alter the retained context. Extraction discards that failed proof attempt
   and uses the actual later rule. The monotone freshness floor still keeps
   subsequently allocated parameters fresh. A raised exception instead
   rejects; it does not trigger this fallthrough.
5. Hypothesis pruning can leave unread prefix cells. They are inert and are
   not part of the extracted proof. The validation compiler trims such
   prefixes from its resulting canonical certificates.
6. Completeness has the same unbounded-resource convention as the source
   drafts. A finite process can reject valid enormous certificates because
   of resource limits. This does not make a false certificate valid.

## Validation and reproducibility

Run `python3 validation/run.py` from the package directory.
The script reads the pinned boxed archive's positive source fixtures,
replays them with its unmodified retained source checker, compiles every
witness through boxing, and checks the outputs with both the prototype and
a separately sorted named-rule oracle. The oracle has separate term and
formula walkers and does not import the production kernel or its scope
table. The only synthesis-specific oracle changes are the explicit truth
entries in the two relevant context extensions.

The script also performs false-equation mutation attacks and named checks
covering future parameters, invalid used witnesses, padding arities,
reserved instruction payloads, empty-object aliases, and failed-major
fallthrough. Public acceptance/rejection is exercised both normally and
with Python `-O`; the kernel has no assertion-dependent correctness branch.

The machine-readable result is `results/validation.json`, and complete
translated certificates are `validation/positive_certificates.json`.
These finite checks are implementation evidence, not a replacement for
the universal derivation-extraction proof.

## Measured alternatives

The initial three-slot/strict-list combination measures 320 / 356 / 894.
Using the inherited membership test gives these alternatives:

| Scope table | Traversal | Tokens | AST | Bytes |
|---|---|---:|---:|---:|
| Three entries | `a + []` | 319 | 355 | 893 |
| Four entries | `a + []` | 318 | 353 | 896 |
| Three entries | `.copy()` | 320 | 354 | 895 |
| Four entries | `.copy()` | 319 | 352 | 898 |

Delaying creation of the padded context until after equality/closure
elimination looks simpler but does not improve the measured program:
the best AST variant of that refactor is 319 / 357 / 917. The exploratory files were not included as trusted dependencies; the primary
source and the current frozen comparator files suffice for the claimed
comparison.

All these variants combine existing techniques. None establishes a
mathematical breakthrough or an improvement below every coordinate of
the current six-archive envelope.
