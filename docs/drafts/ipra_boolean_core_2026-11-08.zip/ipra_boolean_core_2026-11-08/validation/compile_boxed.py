"""Compile canonical old certificates to uniform packets with boxed witnesses.

Adapted from the pinned boxed-witness compiler: every introduction witness is
boxed, including witnesses whose raw encoding was already nonempty. Preserve
the inherited attribution and license when redistributing this adaptation.

This is an untrusted proof translator. Both source and result are rechecked.
Added proof steps use only computation and equality transport.
"""
import argparse
import ast
import hashlib
import json
from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OFFSETS = (0, 2, 1, 4)


def definitions(path):
    tree = ast.parse(path.read_text())
    if not isinstance(tree.body[-1], ast.Try):
        raise ValueError('Expected explicit final driver')
    tree.body.pop()
    ns = {}
    exec(compile(tree, str(path), 'exec'), ns)
    return ns


def run(ns, packet):
    ns['k'] = 0
    stack = deepcopy(packet)
    try:
        ns['take'] = stack.pop
        result = bool(ns['check'](stack.pop(), []))
    except Exception:
        result = False
    return result, ns['k'], len(stack)


@dataclass
class Node:
    rule: str
    goal: object
    instruction: object = None
    children: list = field(default_factory=list)
    eigen: int = 0
    hypotheses: list = field(default_factory=list)


class Trace:
    """A readable replay of canonical successful source derivations."""
    def __init__(self, source, packet):
        self.ns = source
        self.ns['k'] = 0
        self.stack = deepcopy(packet)
        self.initial_goal = self.stack.pop()
        self.counts = {}

    def inst(self, a, t=None, d=0):
        return self.ns['inst'](a, t, d)

    def proof(self, a, g):
        validated = self.inst(a)
        if validated in g:
            if validated != a:
                raise ValueError('Translator requires canonical hypothesis goals')
            return Node('hyp', a)
        instruction = self.stack.pop()
        if type(instruction) is list and len(instruction) == 2:
            m, payload = instruction
            major = self.proof(m, g)
            if len(m) == 2:
                if self.inst(payload, m[1]) != a:
                    raise ValueError('Source transport target mismatch')
                minor = self.proof(self.inst(payload, m[0]), g)
                return Node('transport', a, instruction, [major, minor])
            if len(m) == 1:
                if self.inst(m[0], payload) != a:
                    raise ValueError('Source closure target mismatch')
                minor = self.proof(self.inst(m[0], 0), g)
                return Node('closure', a, instruction, [major, minor])
            if len(m) != 3:
                raise ValueError('Noncanonical major')
            self.ns['k'] -= 1
            eigen = self.ns['k']
            assumptions = [self.inst(m[2:], eigen)]
            minor = self.proof(self.inst(a, [eigen]), g + assumptions)
            return Node('eliminate', a, instruction, [major, minor], eigen, assumptions)
        if instruction == []:
            (n, seed, update), rhs = a
            if n:
                n, = n
                seed = self.inst(update, [n, seed, update], 1)
            if seed != rhs:
                raise ValueError('False source computation')
            return Node('compute', a, instruction)
        matrix = self.inst(a[2], instruction, 2)
        hypotheses = [matrix, self.inst(matrix, 0)][len(matrix) % 2:]
        self.ns['k'] -= 1
        eigen = self.ns['k']
        hypotheses = [self.inst(h, eigen) for h in hypotheses]
        minor = self.proof(self.inst(matrix, [eigen]), g + hypotheses)
        return Node('introduce', a, instruction, [minor], eigen, hypotheses)


def key(a):
    return json.dumps(a, separators=(',', ':'), sort_keys=True)


def nodes(a):
    return 1 + sum(nodes(b) for b in a) if type(a) is list else 1


def open_two(a, x, y, d=0):
    """Expose the two outer slots; images may contain a chosen template hole.

    Local positive coordinates remain protected. The first two exposed
    coordinates denote y, and the next two denote x.
    """
    if type(a) is list:
        return [open_two(b, x, y, d + OFFSETS[len(a)]) for b in a]
    if a < d:
        return a
    if not d % 2:
        return 0
    if a < d + 2:
        return deepcopy(y)
    if a < d + 4:
        return deepcopy(x)
    raise ValueError('Noncanonical outer numerical coordinate')


def computation():
    return [[0, 0]]


def reflexivity(t):
    equation = [[0, t, 0], t]
    return [[equation, [1, t]]] + computation() + computation()


def symmetric_box_equality(box, term):
    equation = [box, term]
    return [[equation, [1, box]]] + computation() + reflexivity(box)


class Compiler:
    def __init__(self):
        self.boxed_introductions = 0
        self.transported_hypotheses = 0
        self.transported_conclusions = 0

    def proof(self, node, environment=None):
        environment = environment or {}
        if node.rule == 'hyp':
            return deepcopy(environment.get(key(node.goal), []))
        if node.rule == 'compute':
            return computation()
        if node.rule in ('transport', 'closure'):
            return [deepcopy(node.instruction)] + self.proof(node.children[0], environment) + self.proof(node.children[1], environment)
        if node.rule == 'eliminate':
            local = dict(environment)
            for h in node.hypotheses:
                local[key(h)] = []
            return [deepcopy(node.instruction)] + self.proof(node.children[0], environment) + self.proof(node.children[1], local)
        if node.rule != 'introduce':
            raise ValueError(node.rule)
        witness = node.instruction
        self.boxed_introductions += 1
        box = [0, deepcopy(witness), 0]
        equation = [box, witness]
        matrix = node.goal[2]
        hole = 8 * (nodes(matrix) + 1)
        y_values = [node.eigen, 0] if len(node.hypotheses) == 2 else [0]
        local = dict(environment)
        for old_hypothesis, y in zip(node.hypotheses, y_values):
            old_expected = open_two(matrix, witness, y)
            new_hypothesis = open_two(matrix, box, y)
            if old_expected != old_hypothesis:
                raise ValueError(('Hypothesis reconstruction failed', old_expected, old_hypothesis))
            if new_hypothesis == old_hypothesis:
                local[key(old_hypothesis)] = []
            else:
                motive = open_two(matrix, hole, y)
                local[key(old_hypothesis)] = [[equation, motive]] + computation()
                self.transported_hypotheses += 1
        minor = self.proof(node.children[0], local)
        old_goal = open_two(matrix, witness, [node.eigen])
        new_goal = open_two(matrix, box, [node.eigen])
        if old_goal != node.children[0].goal:
            raise ValueError(('Conclusion reconstruction failed', old_goal, node.children[0].goal))
        if new_goal != old_goal:
            motive = open_two(matrix, hole, [node.eigen])
            minor = [[[witness, box], motive]] + symmetric_box_equality(box, witness) + minor
            self.transported_conclusions += 1
        return [[0, box]] + minor


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, default=HERE/'source_retained_checker.py')
    parser.add_argument('--checker', type=Path, default=ROOT/'checker.py')
    parser.add_argument('--fixtures', type=Path, default=HERE/'source_positive_certificates.json')
    parser.add_argument('--output-dir', type=Path, default=HERE)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    source = definitions(args.baseline)
    target = definitions(args.checker)
    fixtures = json.loads(args.fixtures.read_text())['records']
    records = []
    totals = {'boxed_introductions':0,'transported_hypotheses':0,'transported_conclusions':0}
    for fixture in fixtures:
        packet = fixture['packet']
        before = run(source, packet)
        if not before[0]:
            raise ValueError('Input fixture did not verify')
        replay = Trace(source, packet)
        tree = replay.proof(replay.initial_goal, [])
        compiler = Compiler()
        forward = compiler.proof(tree)
        result = list(reversed(forward)) + [deepcopy(replay.initial_goal)]
        after = run(target, result)
        if not after[0] or before[1] != after[1]:
            (args.output_dir/'failed_boxed_packet.json').write_text(json.dumps(result,indent=2))
            raise ValueError((fixture['name'],before,after))
        ignored = after[2]
        if ignored:
            result = result[ignored:]
            checked_again = run(target, result)
            if checked_again != (True, after[1], 0):
                raise ValueError('Prefix removal changed the verified derivation')
        for k in totals: totals[k] += getattr(compiler,k)
        records.append({'id':fixture['id'],'name':fixture['name'],'packet':result,'source_cells':len(packet),'target_cells':len(result),'discarded_prefix_cells':ignored,**{k:getattr(compiler,k) for k in totals}})
    (args.output_dir/'boxed_positive_certificates.json').write_text(json.dumps({'records':records},indent=2)+'\n')
    receipt={'status':'PASS','fixture_count':len(fixtures),'accepted_count':len(records),'same_eigenparameter_floor':len(records),'baseline_file':str(args.baseline.resolve()),'checker_file':str(args.checker.resolve()),'fixtures_file':str(args.fixtures.resolve()),'source_sha256':hashlib.sha256(args.baseline.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(args.checker.read_bytes()).hexdigest(),'compiler_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_fixture_sha256':hashlib.sha256(args.fixtures.read_bytes()).hexdigest(),**totals,'source_cells':sum(r['source_cells'] for r in records),'target_cells':sum(r['target_cells'] for r in records),'discarded_prefix_cells':sum(r['discarded_prefix_cells'] for r in records),'claim':'Finite translation checks, not a mechanized soundness proof.'}
    (args.output_dir/'boxed_translation_results.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))

if __name__ == '__main__':
    main()
