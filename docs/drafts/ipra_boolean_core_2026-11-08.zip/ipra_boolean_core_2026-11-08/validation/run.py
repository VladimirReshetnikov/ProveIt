"""Finite validation of the experimental synthesis; not a soundness proof.

The fixtures and the unmodified compiler/oracle ancestors are from the pinned
boxed-witness archive. The adapted compiler boxes every introduction witness.
"""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CHECKER = ROOT / 'checker.py'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


compiler = load('combined_compiler', HERE / 'compile_boxed.py')
oracle = load('combined_reference', HERE / 'oracle.py')
measure = load('combined_measure', ROOT / 'comparison/source_measure.py')
source = compiler.definitions(HERE / 'source_retained_checker.py')
target = compiler.definitions(CHECKER)
fixtures = json.loads((HERE / 'source_positive_certificates.json').read_text())['records']
records = []
rule_totals = {}


def actual(packet):
    return compiler.run(target, packet)


for fixture in fixtures:
    before = compiler.run(source, fixture['packet'])
    if not before[0]:
        raise ValueError('Source certificate rejected: ' + fixture['name'])
    replay = compiler.Trace(source, fixture['packet'])
    tree = replay.proof(replay.initial_goal, [])
    translation = compiler.Compiler()
    forward = translation.proof(tree)
    packet = list(reversed(forward)) + [copy.deepcopy(replay.initial_goal)]
    checked = actual(packet)
    if not checked[0] or checked[1] != before[1]:
        raise ValueError(('Translated certificate failed', fixture['name'], before, checked))
    ignored = checked[2]
    if ignored:
        packet = packet[ignored:]
    reference = oracle.Oracle().run(packet)
    checked = actual(packet)
    if checked != (True, before[1], 0) or not reference['accepted'] or reference['final_k'] != before[1] or reference['remaining'] != 0:
        raise ValueError(('Reference mismatch', fixture['name'], checked, reference))
    for key, value in reference['rules'].items():
        rule_totals[key] = rule_totals.get(key, 0) + value
    records.append({'id': fixture['id'], 'name': fixture['name'], 'packet': packet,
                    'source_cells': len(fixture['packet']), 'target_cells': len(packet),
                    'boxed_introductions': translation.boxed_introductions,
                    'transported_hypotheses': translation.transported_hypotheses,
                    'transported_conclusions': translation.transported_conclusions,
                    'discarded_prefix_cells': ignored})


false_goals = [[0, [0]], [{}, [0]], [0, [{}]], [0.5, [0.5]],
               [False, [False]], [[], [[]]], [[0], 0]]
attacks = 0
for record in records:
    for goal in false_goals:
        packet = copy.deepcopy(record['packet'][:-1]) + [copy.deepcopy(goal)]
        if actual(packet)[0] or oracle.Oracle().run(packet)['accepted']:
            raise ValueError(('False theorem accepted', record['name'], goal))
        attacks += 1

rng = random.Random(739343)
leaves = [0, 1, -1, -2, -999, None, False, True, '', 'bad', {}, {'': 0},
          [], [0], [0, 0], [0, 0, 0], [0, 0, [], 0]]
for _ in range(15000):
    if rng.random() < .7:
        prefix = copy.deepcopy(rng.choice(records)['packet'][:-1])
        for _ in range(rng.randrange(1, 5)):
            if not prefix:
                break
            at = rng.randrange(len(prefix))
            if rng.randrange(2):
                prefix[at] = [copy.deepcopy(rng.choice(leaves)), copy.deepcopy(rng.choice(leaves))]
            else:
                del prefix[at]
    else:
        prefix = [[copy.deepcopy(rng.choice(leaves)), copy.deepcopy(rng.choice(leaves))]
                  for _ in range(rng.randrange(8))]
    packet = prefix + [copy.deepcopy(rng.choice(false_goals))]
    if actual(packet)[0] or oracle.Oracle().run(packet)['accepted']:
        raise ValueError(('Mutated false theorem accepted', packet))
    attacks += 1

named = {
    'zero_computation': ([[0, 0], [[0, 0, 0], 0]], True),
    'false_computation': ([[0, 0], [[0, 0, 0], [0]]], False),
    'boxed_zero_witness': ([[0, [0, 0, 0]], [0, 0, [3, 3]]], True),
    'reserved_bare_zero': ([[0, 0], [0, 0, [3, 3]]], False),
    'empty_object_counter': ([[0, 0], [[{}, 0, 0], 0]], True),
    'nonempty_object_counter': ([[0, 0], [[{'': 0}, 0, 0], 0]], False),
    'used_invalid_string': ([[0, 'bad'], [0, 0, [3, 3]]], False),
    'unused_invalid_string': ([[0, 'bad'], [0, 0, []]], True),
    'future_name': ([[0, [0, -1, 0]], [0, 0, [3, 3]]], False),
    'padded_induction_matrix': ([[0, [0, 0, 0]], [0, 0, [0, 0, [], 0]]], False),
    'string_does_not_recurse': ([[0, 0], [[0, 'x' * 20000, 0], 'x' * 20000]], False),
    'failed_major_fallthrough': ([[0, 0], [[[0, 0, 0], [0]], [0, 0, 0]], [0, 0, []]], True),
    'first_translated_fixture': (records[0]['packet'], True),
    'large_translated_fixture': (max(records, key=lambda r: len(r['packet']))['packet'], True),
}
cli = []
for name, (packet, expected) in named.items():
    observed = actual(packet)
    reference = oracle.Oracle().run(packet)
    if observed[0] != expected or reference['accepted'] != expected:
        raise ValueError(('Named expectation failed', name, observed, reference))
    for flags in ([], ['-O']):
        process = subprocess.run([sys.executable, *flags, str(CHECKER)],
                                 input=json.dumps(packet), text=True, capture_output=True, timeout=10)
        if process.returncode != (0 if expected else 1) or process.stdout.strip() != ('ACCEPT' if expected else 'REJECT'):
            raise ValueError(('CLI mismatch', name, flags, process.returncode, process.stdout, process.stderr))
        cli.append({'name': name, 'optimized': bool(flags), 'accepted': expected})
for name, text in [('malformed_json', '['), ('dictionary_top', '{}'),
                   ('empty_input', ''), ('too_deep_json', '[' * 2000 + '0' + ']' * 2000)]:
    for flags in ([], ['-O']):
        process = subprocess.run([sys.executable, *flags, str(CHECKER)], input=text,
                                 text=True, capture_output=True, timeout=10)
        if process.returncode != 1 or process.stdout.strip() != 'REJECT':
            raise ValueError(('Malformed CLI mismatch', name, flags, process.stdout, process.stderr))
        cli.append({'name': name, 'optimized': bool(flags), 'accepted': False})

measurements = {}
measurements[CHECKER.name] = {k: v for k, v in measure.metrics(CHECKER).items() if k != 'core'}
result = {
    'status': 'PASS', 'python': sys.version.split()[0],
    'checker_sha256': hashlib.sha256(CHECKER.read_bytes()).hexdigest(),
    'source_archive_git_blob': '73b06b0453b7529a91f2e2be5f48d61ca54caed4',
    'source_fixture_sha256': hashlib.sha256((HERE / 'source_positive_certificates.json').read_bytes()).hexdigest(),
    'source_certificates': len(fixtures), 'translated_certificates': len(records),
    'same_eigenparameter_floor': len(records), 'sorted_oracle_agreements': len(records),
    'boxed_introductions': sum(r['boxed_introductions'] for r in records),
    'transported_hypotheses': sum(r['transported_hypotheses'] for r in records),
    'transported_conclusions': sum(r['transported_conclusions'] for r in records),
    'rule_coverage': rule_totals, 'false_equation_attacks': attacks,
    'false_equations_accepted': 0, 'public_cli_runs': len(cli), 'cli': cli,
    'measurements': measurements,
    'scope': 'Finite translation, sorted-oracle, malformed-input, and false-goal checks. '
             'These are implementation evidence, not a proof-assistant soundness theorem.',
    'comparison_warning': 'The primary synthesis does not beat the current AST-node minimum of 350.'}
(ROOT / 'results').mkdir(exist_ok=True)
(ROOT / 'examples').mkdir(exist_ok=True)
for name in ('zero_computation', 'false_computation', 'boxed_zero_witness', 'failed_major_fallthrough'):
    (ROOT / 'examples' / (name + '.json')).write_text(json.dumps(named[name][0], indent=2) + '\n')
for record in records:
    if 'induction' in record['name'].lower():
        (ROOT / 'examples/equation_induction.json').write_text(json.dumps(record['packet'], indent=2) + '\n')
        break
(HERE / 'positive_certificates.json').write_text(json.dumps({'records': records}, indent=2) + '\n')
(ROOT / 'results/validation.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k not in ('cli', 'measurements')}, indent=2))
