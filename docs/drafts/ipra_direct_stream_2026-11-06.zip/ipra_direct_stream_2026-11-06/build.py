"""Compile the self-contained paper; run reproduce.py separately for validation."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    required = ["results/numbers.tex", "results/validation_table.tex"]
    if any(not (ROOT / path).exists() for path in required):
        subprocess.run([sys.executable, "reproduce.py"], cwd=ROOT, check=True)
    for _ in range(3):
        result = subprocess.run(
            ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
            cwd=ROOT, capture_output=True, text=True
        )
        if result.returncode:
            print(result.stdout)
            print(result.stderr, file=sys.stderr)
            raise SystemExit(result.returncode)
    print("Built:", ROOT / "report.pdf")


if __name__ == "__main__":
    main()
