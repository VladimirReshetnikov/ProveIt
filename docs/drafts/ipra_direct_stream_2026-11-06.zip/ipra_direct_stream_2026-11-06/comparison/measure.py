"""Recompute the complete-program comparison against all pinned root checkers.

This program measures source; it never imports or executes a checker. The
primary boundary is the entire acceptance program, including syntax checking,
substitution, inference, JSON/file input, reader binding, verdicts and errors.
Actual docstrings and comments are excluded uniformly; executable syntax is
normalized with ast.unparse. Identifier spelling is NOT normalized.

The auxiliary core numbers remove imports and __name__-guarded CLI blocks.
They are only a diagnostic: removing the new CLI also removes the definition
of the global input reader take, while old checkers receive their proof stream
as an explicit argument. These fragments are not standalone acceptance programs.
"""
import ast
import copy
import csv
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

ROOT = Path(__file__).resolve().parent.parent
MEASURES = ("normalized_tokens", "ast_nodes", "normalized_bytes")
IGNORED_TOKENS = {
    tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
    tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER,
}


def count_tokens(source, omitted_spans=()):
    """Count significant tokens, optionally excluding actual docstring spans."""
    return sum(
        token.type not in IGNORED_TOKENS
        and not any(start <= token.start and token.end <= end
                    for start, end in omitted_spans)
        for token in tokenize.generate_tokens(io.StringIO(source).readline)
    )


def normalized_metrics(tree):
    source = ast.unparse(tree) + "\n"
    return {
        "normalized_tokens": count_tokens(source),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "normalized_bytes": len(source.encode("utf-8")),
    }


def is_cli_guard(node):
    if not isinstance(node, ast.If):
        return False
    return any(isinstance(part, ast.Name) and part.id == "__name__"
               for part in ast.walk(node.test))


def metrics(path):
    """Return whole-program metrics and explicitly non-standalone core metrics."""
    raw = path.read_bytes()
    source = raw.decode("utf-8")
    tree = ast.parse(source, filename=str(path))
    omitted = []
    for node in list(ast.walk(tree)):
        if not isinstance(node, (ast.Module, ast.FunctionDef,
                                 ast.AsyncFunctionDef, ast.ClassDef)):
            continue
        if not node.body:
            continue
        first = node.body[0]
        if (isinstance(first, ast.Expr)
                and isinstance(first.value, ast.Constant)
                and isinstance(first.value.value, str)):
            omitted.append(((first.lineno, first.col_offset),
                            (first.end_lineno, first.end_col_offset)))
            node.body.pop(0)
    core = copy.deepcopy(tree)
    core.body = [node for node in core.body
                 if not isinstance(node, (ast.Import, ast.ImportFrom))
                 and not is_cli_guard(node)]
    return {
        "sha256": hashlib.sha256(raw).hexdigest(),
        "raw_bytes": len(raw),
        "source_tokens": count_tokens(source, omitted),
        **normalized_metrics(tree),
        "core": normalized_metrics(core),
    }


def policies(filename):
    return {
        "witness_policy": "demand" if "demand" in filename else "strict",
        "input_policy": "open sequent" if "open" in filename else "theorem",
        "stack_policy": "exact exhaustion" if "exact" in filename
                        else "unread prefix allowed",
    }


def envelope(rows, core=False):
    return {key: min((row["core"] if core else row)[key] for row in rows)
            for key in MEASURES}


def comparison(candidate, reference):
    return {
        "strictly_below": {key: candidate[key] < reference[key]
                           for key in MEASURES},
        "absolute_reduction": {key: reference[key] - candidate[key]
                               for key in MEASURES},
        "percentage_reduction": {
            key: 100.0 * (reference[key] - candidate[key]) / reference[key]
            for key in MEASURES
        },
    }


def table_values(row):
    return " & ".join(str(row[key]) for key in MEASURES)


def write_tex(result, directory):
    macros = {
        "ArchiveCount": result["archive_count"],
        "BaselineCount": result["baseline_count"],
    }
    groups = {
        "Old": result["whole_envelope"],
        "OldStrict": result["strict_whole_envelope"],
        "OldCore": result["core_diagnostic"]["envelope"],
        "OldStrictCore": result["core_diagnostic"]["strict_envelope"],
        "New": result["candidates"]["checker.py"],
        "Demand": result["candidates"]["checker_demand.py"],
        "NewCore": result["candidates"]["checker.py"]["core"],
        "DemandCore": result["candidates"]["checker_demand.py"]["core"],
    }
    suffixes = dict(zip(MEASURES, ("Tokens", "AST", "Bytes")))
    for prefix, values in groups.items():
        for key in MEASURES:
            macros[prefix + suffixes[key]] = values[key]
    for prefix, label in (("New", "strict_vs_all"),
                          ("Demand", "demand_vs_all"),
                          ("NewStrict", "strict_vs_strict")):
        data = result["comparisons"][label]
        for key in MEASURES:
            macros[prefix + suffixes[key] + "Drop"] = data["absolute_reduction"][key]
            macros[prefix + suffixes[key] + "Percent"] = (
                f"{data['percentage_reduction'][key]:.2f}"
            )
    (directory / "numbers.tex").write_text(
        "% Generated by comparison/measure.py; do not edit.\n"
        + "".join("\\newcommand{\\" + key + "}{" + str(value) + "}\n"
                  for key, value in macros.items()), encoding="utf-8")

    lines = ["\\begin{center}\\small", "\\begin{tabular}{@{}lllrrr@{}}",
             "\\toprule", "Archive & Variant & Witnesses & Tokens & AST & Bytes\\\\",
             "\\midrule"]
    for row in result["baselines"]:
        variant = Path(row["local_path"]).stem.removeprefix("checker").strip("_")
        variant = variant.replace("_", " ") or "primary"
        lines.append(f"{row['archive_label']} & {variant} & {row['witness_policy']} & "
                     + table_values(row) + "\\\\")
    lines += ["\\midrule",
              "All-baseline envelope & & & " + table_values(result["whole_envelope"]) + "\\\\",
              "Strict-baseline envelope & & & " + table_values(result["strict_whole_envelope"]) + "\\\\",
              "New & primary & strict & " + table_values(result["candidates"]["checker.py"]) + "\\\\",
              "New & companion & demand & " + table_values(result["candidates"]["checker_demand.py"]) + "\\\\",
              "\\bottomrule", "\\end{tabular}", "\\end{center}"]
    (directory / "comparison_table.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")

    lines = ["\\begin{center}", "\\begin{tabular}{@{}lrrr@{}}", "\\toprule",
             "Complete acceptance program & Tokens & AST & Bytes\\\\", "\\midrule"]
    for label, row in (
        ("Current corpus envelope", result["whole_envelope"]),
        ("Current strict envelope", result["strict_whole_envelope"]),
        ("New strict checker", result["candidates"]["checker.py"]),
        ("New demand checker", result["candidates"]["checker_demand.py"]),
    ):
        lines.append(label + " & " + table_values(row) + "\\\\")
    lines += ["\\bottomrule", "\\end{tabular}", "\\end{center}"]
    (directory / "summary_table.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")

    lines = ["\\begin{center}\\small", "\\begin{tabular}{@{}lrrr@{}}", "\\toprule",
             "Non-standalone core diagnostic & Tokens & AST & Bytes\\\\", "\\midrule"]
    for label, row in (
        ("Current corpus envelope", result["core_diagnostic"]["envelope"]),
        ("Current strict envelope", result["core_diagnostic"]["strict_envelope"]),
        ("New strict fragment", result["candidates"]["checker.py"]["core"]),
        ("New demand fragment", result["candidates"]["checker_demand.py"]["core"]),
    ):
        lines.append(label + " & " + table_values(row) + "\\\\")
    lines += ["\\bottomrule", "\\end{tabular}", "\\end{center}"]
    (directory / "core_table.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")

    lines = ["\\begin{center}\\small", "\\begin{tabular}{@{}ll@{}}", "\\toprule",
             "Label & Archive filename\\\\", "\\midrule"]
    for index, archive in enumerate(result["archives"]):
        lines.append(chr(65 + index) + " & \\texttt{\\detokenize{" + archive["name"] + "}}\\\\")
    lines += ["\\bottomrule", "\\end{tabular}", "\\end{center}"]
    (directory / "archive_table.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    manifest = json.loads((ROOT / "comparison/manifest.json").read_text(encoding="utf-8"))
    rows = []
    for entry in manifest["sources"]:
        path = ROOT / entry["local_path"]
        row = metrics(path)
        if row["sha256"] != entry["sha256"]:
            raise ValueError("Pinned source hash mismatch: " + entry["local_path"])
        archive = manifest["archives"][entry["archive_index"]]
        if entry["archive"] != archive["name"] or entry["archive_git_blob"] != archive["sha"]:
            raise ValueError("Inconsistent archive provenance: " + entry["local_path"])
        rows.append({**entry, "archive_label": chr(65 + entry["archive_index"]),
                     **policies(path.name), **row})
    expected = {entry["local_path"] for entry in manifest["sources"]}
    observed = {str(path.relative_to(ROOT))
                for path in (ROOT / "comparison/sources").rglob("checker*.py")}
    if len(expected) != len(rows) or expected != observed:
        raise ValueError("Pinned checker inventory has duplicates, omissions, or extras")
    strict_rows = [row for row in rows if row["witness_policy"] == "strict"]
    whole = envelope(rows)
    strict_whole = envelope(strict_rows)
    candidates = {name: {"local_path": name, **policies(name), **metrics(ROOT / name)}
                  for name in ("checker.py", "checker_demand.py")}
    comparisons = {
        "strict_vs_all": comparison(candidates["checker.py"], whole),
        "strict_vs_strict": comparison(candidates["checker.py"], strict_whole),
        "demand_vs_all": comparison(candidates["checker_demand.py"], whole),
    }
    result = {
        "python_version": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "reference_python_version": "3.12.14",
        "repository": manifest["repository"],
        "commit": manifest["commit"],
        "archive_count": len(manifest["archives"]),
        "baseline_count": len(rows),
        "archives": manifest["archives"],
        "boundary": __doc__.strip(),
        "normalization": {
            "remove": "comments and actual module/function/class docstrings",
            "source": "ast.unparse of the remaining AST, followed by one newline",
            "tokens": "all tokenize tokens except formatting, comments, and end marker",
            "ast": "all nodes returned by ast.walk, including context nodes",
            "bytes": "UTF-8 length of the normalized source",
            "identifier_spelling": "preserved; byte counts are sensitive to names",
            "external_runtime": "shared CPython and ordinary standard-library json/sys",
        },
        "whole_envelope": whole,
        "strict_whole_envelope": strict_whole,
        "core_diagnostic": {
            "standalone": False,
            "envelope": envelope(rows, core=True),
            "strict_envelope": envelope(strict_rows, core=True),
            "warning": (
                "Imports and __name__-guarded CLI blocks are removed uniformly, but "
                "the resulting fragments have different external dependencies: the "
                "new fragment needs take bound by its omitted CLI, whereas old "
                "checkers receive the proof stream as an explicit parameter. "
                "These numbers are descriptive only, not an independent fair-boundary "
                "or standalone-kernel domination claim."
            ),
        },
        "comparisons": comparisons,
        "candidates": candidates,
        "baselines": rows,
        "scope": (
            "Strict domination of the measured complete programs at this repository "
            "snapshot; no claim of absolute minimality, an invariant complexity "
            "ordering, or a lower bound on all equivalent axiomatizations."
        ),
    }
    directory = ROOT / "results"
    directory.mkdir(exist_ok=True)
    (directory / "measurements.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    fields = ("archive_label", "local_path", "witness_policy", "input_policy", "stack_policy",
              "normalized_tokens", "ast_nodes", "normalized_bytes", "source_tokens", "raw_bytes",
              "core_normalized_tokens", "core_ast_nodes", "core_normalized_bytes", "sha256")
    with (directory / "measurements.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows + [{"archive_label": "New", **row} for row in candidates.values()]:
            writer.writerow({**row, **{"core_" + key: value for key, value in row["core"].items()}})
    write_tex(result, directory)
    print(json.dumps({key: result[key] for key in (
        "python_version", "commit", "archive_count", "baseline_count",
        "whole_envelope", "strict_whole_envelope", "candidates", "comparisons")}, indent=2))
    if not all(all(data["strictly_below"].values()) for data in comparisons.values()):
        raise AssertionError("The declared complete-program strict improvement did not reproduce")
    return result


if __name__ == "__main__":
    main()
