REPRODUCIBLE COMPLETE-PROGRAM SIZE COMPARISON

Run from any directory:

  python3 /path/to/ipra_direct_stream_2026-11-06/comparison/measure.py

The reference environment is CPython 3.12.14. Other Python releases may
normalize the same source differently. The script records the actual runtime.
It reads and parses the checkers as data; it never executes or imports them.

SCOPE

manifest.json pins all sixteen complete checker variants at the roots of the
six draft archives present at the recorded ProveIt commit. The snapshot's
embedded comparison directories are not additional current draft checkers.
Every frozen source is byte-identical to its archive member and identified by
SHA-256. The measurement script verifies these hashes and the source inventory
before claiming an improvement. Source archive blob IDs and exact member paths
are retained for independent retrieval.

The primary measured boundary is the entire acceptance program. It includes
grammar validation, substitution, inference, computation, imports, JSON/file
input, input-reader binding, success/rejection output, and exception handling.
The common external runtime is CPython and its ordinary json and sys modules.
No proof generator, theorem database, or testing program participates in
acceptance or is imported by either new checker.

COUNTING

Actual module, function, and class docstrings are removed from a parsed AST.
Comments are naturally absent from the AST. All remaining executable syntax
is normalized with ast.unparse, followed by one newline. The main counts are:

  normalized_tokens  significant tokenize tokens after normalization;
  ast_nodes          every node from ast.walk, including context nodes;
  normalized_bytes   UTF-8 byte length of the normalized executable source.

Formatting tokens, comments, and the end marker are omitted from token counts.
Original-source significant tokens (excluding actual docstring spans) and raw
file bytes are also recorded; those are descriptive supplementary columns.
Identifier names and literal tag spellings are NOT normalized. Consequently
byte counts are sensitive to those choices. Token and AST counts do not reward
merely shortening identifiers. No metric is claimed to be implementation- or
language-invariant, and no absolute shortest-program theorem is asserted.

POLICIES AND ENVELOPES

The full-corpus envelope takes each coordinate's minimum over all sixteen
programs, including demand witnesses and open/exact interfaces. The strict
envelope takes minima only over programs that validate every selected numerical
witness, even a vacuous one. All boundary and policy labels are retained in the
JSON and CSV. A coordinatewise envelope need not be attained by one program.
Both new complete programs are compared with the full-corpus envelope; the new
strict checker is also compared with the matching strict envelope. The script
checks strict inequalities and records absolute and percentage reductions.

CORE DIAGNOSTIC: NOT ANOTHER FAIR-BOUNDARY CLAIM

For transparency, the script also strips imports and each __name__-guarded CLI
block uniformly. These fragments are not standalone programs. In particular,
the new check function refers to the global reader take, whose binding was in
the removed CLI; old checkers receive their proof stream as an explicit
parameter. Thus the core figures are descriptive diagnostics only. They must
not be advertised as a separate fair-boundary or standalone-kernel comparison.
The complete-program figures include the actual reader binding and dispatch.

OUTPUTS

  results/measurements.json      Provenance, policies, all counts, comparisons.
  results/measurements.csv       One row per old/new complete source.
  results/numbers.tex            Numeric macros consumed by the report.
  results/comparison_table.tex   All sixteen old variants and both new programs.
  results/summary_table.tex      Complete-program envelopes and new programs.
  results/core_table.tex         Explicitly non-standalone core diagnostic.
  results/archive_table.tex      Archive-label-to-filename mapping.
