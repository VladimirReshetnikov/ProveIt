A SMALLER COMPLETE PRESENTATION OF iPRA
One certificate stream and direct substitution indices
Prepared for Vladimir Reshetnikov, 6 November 2026

RESULT

The complete strict checker has 492 normalized significant Python tokens,
498 executable AST nodes, and 1,527 normalized UTF-8 bytes.
These are all strictly below the corresponding current corpus minima:
505 tokens, 510 AST nodes, and 1,554 bytes.

The optional demand-validation companion is smaller: 483 / 491 / 1,508.
It accepts the same theorems, permitting an unused malformed Q-instance
annotation that can always be replaced by zero.

The comparison includes all sixteen root checker variants in the six
active draft ZIPs at ProveIt commit:
  9e8e3161b0dffb54fceb0b75ee818cc9e4ed2b10

The reduction is in the complete proof presentation and checking program.
The retained-base unary mathematical basis is inherited, with attribution,
from those drafts. The paper supplies its complete explicit calculus,
full intuitionistic logical reconstruction, arithmetic reflection,
faithful ordinary realization, and bi-interpretability proof.

This is a measured finite-corpus improvement, not a global minimality theorem.
The mathematical metatheorems have not been formalized in Lean or Rocq.

CONTENTS

report.tex, sections/*.tex       Complete LaTeX paper sources
report.pdf                      Compiled self-contained paper
checker.py                      Recommended strict standalone acceptance program
checker_demand.py               Smaller theorem-equivalent companion
FORMAT.txt                      Syntax, input, rules, and acceptance conventions
examples/*.json                 89 canonical public theorem certificates
validation/independent.py       Named-binder oracle and readable rule interpreter
validation/regression.py        Baseline differential and real CLI audit
validation/example_provenance.json
                                Example source members and hashes
comparison/sources/             Sixteen unchanged current comparison checkers
comparison/manifest.json        Repository pin, archives, sources, and hashes
comparison/measure.py           Complete-program size comparison
results/                        Reproducible measurement and validation records
reproduce.py                    Replay all packaged finite evidence
build.py                        Compile the paper with pdfLaTeX
package.py                      Rebuild the clean ZIP and delivered-file manifest
ATTRIBUTION.txt                  Inherited and new contributions
LICENSE_SOURCE.txt              Preserved MIT No Attribution source license
MANIFEST.sha256                 Delivered file hashes

QUICK START

  python3 checker.py examples/02_successor_plus_theorem.json
  python3 reproduce.py
  python3 build.py

The first command prints ACCEPT. Reproduction needs only Python's standard
library and no network. Use CPython 3.12.14 for identical ast.unparse counts.
The kernels require Python 3.10 or newer. Rebuilding report.pdf requires
pdfLaTeX and the ordinary packages declared in report.tex.

INPUT

A certificate is one JSON list:

  [instruction_m, ..., instruction_1, goal]

The rightmost cell is the requested theorem. Instructions are read from the
right, beginning with instruction_1. A bound list.pop reader is created by
the standalone program itself. No external proof generator or checker is
imported by the kernel.

Positive integers in term positions are ordinary de Bruijn coordinates.
Zero is number zero. Negative integers are rigid numerical parameter NAMES,
not negative numbers. The theory's numerical domain remains the ordinary
one-sorted domain, and both bi-interpretations use that whole domain.

All 89 packaged examples exhaust their proof lists. The public kernel permits
inert earlier entries, as do the current minimal comparison programs.
It prints ACCEPT/REJECT and exits with zero/one, respectively.
Additional command-line arguments are ignored; the first argument names
the JSON input. See FORMAT.txt for all canonical instruction forms.

WHAT CHANGED

1. The theorem and its proof use one input stream; recursive calls no longer
   repeatedly pass the same mutable certificate list.
2. A substitution environment is [offset, image1, ...], so positive variable
   slot i addresses its image directly as env[i].
3. A fresh local assumption list is extended by the shifted retained context.
   Context exchange already belongs to the admissible structural operations.
4. Strict witness validation is its identity substitution, directly yielding
   the checked Q-elimination instance.

VALIDATION

Both kernels passed independent named-binder substitution checks and a
readable independent interpreter for every primitive rule; comparison with
the frozen smallest draft also checks exact unread prefixes. The CLI was
tested under ordinary and optimized Python. The JSON result records include
the exact kernel hashes. The paper and results/validation_summary.json give
the counts and limitations without conflating finite tests with metatheory.

Only the complete-program comparison is the headline size result. Core-only
figures are diagnostic because removing the new CLI also removes the binding
of its shared input reader, whereas older cores take a stream parameter.
