"""Create a clean research ZIP and a complete delivered-file hash manifest."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
OMIT_SUFFIXES = {".aux", ".log", ".out", ".toc", ".pyc", ".synctex", ".fls", ".fdb_latexmk"}
STAMP = (2026, 11, 6, 12, 0, 0)


def deliverable(path):
    relative = path.relative_to(ROOT)
    return (
        path.is_file()
        and "__pycache__" not in relative.parts
        and path.suffix not in OMIT_SUFFIXES
        and not path.name.endswith(".synctex.gz")
        and path.name != "MANIFEST.sha256"
    )


def main():
    files = sorted(path for path in ROOT.rglob("*") if deliverable(path))
    manifest = ROOT / "MANIFEST.sha256"
    manifest.write_text("".join(
        hashlib.sha256(path.read_bytes()).hexdigest()
        + "  " + path.relative_to(ROOT).as_posix() + "\n"
        for path in files
    ))
    archive = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for path in sorted([*files, manifest]):
            name = ROOT.name + "/" + path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(name, STAMP)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            output.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(archive) as check:
        bad = check.testzip()
        if bad is not None:
            raise ValueError("Corrupt ZIP member: " + bad)
        if len(check.namelist()) != len(files) + 1:
            raise ValueError("ZIP inventory mismatch.")
    print("Packaged", len(files) + 1, "files:", archive)
    print("SHA256", hashlib.sha256(archive.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
