"""Independent implementation review of the finalized direct-stream kernels.

This is a finite regression and adversarial audit, not a formal soundness proof.
It preserves the delivered kernel files and writes only a JSON review result.
"""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import random
import subprocess
import sys
import tempfile

PACKAGE = Path(__file__).resolve().parents[1]
OLD = PACKAGE / 'comparison/sources/archive2'
RNG = random.Random(20261106)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


strict = load('review_current_strict', PACKAGE / 'checker.py')
demand = load('review_current_demand', PACKAGE / 'checker_demand.py')
old_strict = load('review_old_strict', OLD / 'checker.py')
old_demand = load('review_old_demand', OLD / 'checker_demand.py')


def tags(value, old=False):
    """Translate the old u label and the new q label, leaving all other data."""
    if isinstance(value, list):
        return [tags(x, old) for x in value]
    if isinstance(value, dict):
        return {k: tags(v, old) for k, v in value.items()}
    if value == ('q' if old else 'u'):
        return 'u' if old else 'q'
    return value


def run(module, goal, proof, context=(), old=False):
    stack = copy.deepcopy(proof)
    a = copy.deepcopy(goal)
    g = copy.deepcopy(list(context))
    if old:
        stack, a, g = tags(stack, True), tags(a, True), tags(g, True)
    accepted = False
    exception = None
    try:
        if old:
            accepted = bool(module.check(a, stack, g))
        else:
            module.take = stack.pop
            accepted = bool(module.check(a, g))
    except Exception as error:
        exception = type(error).__name__
    return {
        'accepted': accepted,
        'remaining': tags(stack) if old else stack,
        'exception': exception,
    }


def equivalent(old_module, new_module, goal, proof, context=()):
    left = run(old_module, goal, proof, context, old=True)
    right = run(new_module, goal, proof, context)
    return left['accepted'] == right['accepted'] and left['remaining'] == right['remaining'], left, right


def lift(term):
    return strict.subst(term, [1], False)


def refl(term):
    equation = ['=', ['r', 0, term, 0], term]
    motive = ['=', 1, lift(term)]
    return [[], [], [equation, motive]]


T = ['=', 0, 0]
FALSE = ['=', 0, ['s', 0]]
QT = ['q', T]
QB = ['q', ['=', 1, 1]]
refl_zero = refl(0)
q_constant = ['hyp', []]
q_reflexive = refl(['s', 1]) + [[]]


def q_elimination(body_q, major_proof, witness, base_proof, goal):
    return goal, copy.deepcopy(base_proof) + copy.deepcopy(major_proof) + [[body_q, witness]]


def random_term(depth=3):
    if depth <= 0 or RNG.random() < 0.45:
        return RNG.randrange(-3, 9)
    if RNG.random() < 0.4:
        return ['s', random_term(depth - 1)]
    return ['r', random_term(depth - 1), random_term(depth - 1), random_term(depth - 1)]


def random_formula(depth=3):
    if depth <= 0 or RNG.random() < 0.55:
        return ['=', random_term(3), random_term(3)]
    return [RNG.choice(['q', 'ex']), random_formula(depth - 1)]


failures = []
checks = []


def record(name, passed, detail=None):
    entry = {'name': name, 'passed': bool(passed)}
    if detail is not None:
        entry['detail'] = detail
    checks.append(entry)
    if not passed:
        failures.append(entry)


hashes_before = {name: hashlib.sha256((PACKAGE / name).read_bytes()).hexdigest()
                 for name in ['checker.py', 'checker_demand.py']}

# The default environment and caller-owned substitution environments must not mutate.
default_before = copy.deepcopy(strict.subst.__defaults__)
env_unchanged = True
substitution_mismatch = []
for number in range(3000):
    formula = bool(number % 2)
    value = random_formula(3) if formula else random_term(4)
    replacement_count = RNG.randrange(3)
    offset = RNG.randrange(-2, 3)
    images = [random_term(2) for _ in range(replacement_count)]
    environment = [offset, *images]
    before = copy.deepcopy(environment)
    depth = RNG.randrange(5)
    new_value = strict.subst(copy.deepcopy(value), environment, formula, depth)
    old_value = old_strict.subst(tags(copy.deepcopy(value), True),
                               tags([*images, offset], True), depth, formula)
    if new_value != tags(old_value):
        substitution_mismatch.append(number)
    if environment != before:
        env_unchanged = False
record('offset_first_substitution_matches_old_layout_3000_cases', not substitution_mismatch,
       {'cases': 3000, 'mismatching_case_indices': substitution_mismatch[:10]})
record('substitution_does_not_mutate_environments', env_unchanged and strict.subst.__defaults__ == default_before,
       {'caller_environments': 3000, 'default_environment': strict.subst.__defaults__[0]})

# Independent randomized proof comparison, including exact unread prefixes.
public = []
seen = set()
for file in sorted((PACKAGE / 'examples').glob('*.json')):
    value = json.loads(file.read_text())
    if not isinstance(value, list) or not value:
        raise ValueError('Malformed distributed example: ' + str(file))
    public.append((value[-1], value[:-1]))
public += [(T, refl_zero), (QT, q_constant), (QB, q_reflexive)]
corpus = list(public)
mutation_values = [None, True, False, 3, -1, 0.0, 'hyp', {}, {'unused': [None]}, [],
                   [0], ['bad'], ['=', 0, 0], ['q', ['=', 0, 0]],
                   [['=', 0, ['s', 0]], ['=', 1, 0]]]
for goal, proof in public:
    for _ in range(16):
        changed = copy.deepcopy(proof)
        action = RNG.randrange(4)
        if action == 0 and changed:
            changed[RNG.randrange(len(changed))] = copy.deepcopy(RNG.choice(mutation_values))
        elif action == 1 and changed:
            del changed[RNG.randrange(len(changed))]
        elif action == 2:
            changed.insert(RNG.randrange(len(changed) + 1), copy.deepcopy(RNG.choice(mutation_values)))
        else:
            changed = changed[:RNG.randrange(len(changed) + 1)]
        corpus.append((goal, changed))
for _ in range(1000):
    corpus.append((random_formula(2), [copy.deepcopy(RNG.choice(mutation_values))
                                      for _ in range(RNG.randrange(7))]))

strict_diffs = []
demand_diffs = []
accepted_public = 0
for index, (goal, proof) in enumerate(corpus):
    good, left, right = equivalent(old_strict, strict, goal, proof)
    if index < len(public) and right['accepted']:
        accepted_public += 1
    if not good:
        strict_diffs.append({'index': index, 'old': left, 'new': right})
    good, left, right = equivalent(old_demand, demand, goal, proof)
    if not good:
        demand_diffs.append({'index': index, 'old': left, 'new': right})
record('strict_acceptance_and_consumed_prefix_match_baseline', not strict_diffs,
       {'cases': len(corpus), 'public_cases': len(public), 'accepted_public_cases': accepted_public,
        'mismatches': strict_diffs[:5]})
record('demand_acceptance_and_consumed_prefix_match_baseline', not demand_diffs,
       {'cases': len(corpus), 'mismatches': demand_diffs[:5]})

# Exact prefix behavior: one suffix supplies the proof; earlier data stay unread.
marker = [{'unread': [None, 'not a proof', {'q': 0}]}, False, 'INERT PREFIX']
prefix_outcome = run(strict, T, marker + refl_zero)
record('inert_input_prefix_remains_exactly_unchanged',
       prefix_outcome['accepted'] and prefix_outcome['remaining'] == marker,
       {'prefix_items': len(marker), 'proof_items_consumed': len(refl_zero)})
record('canonical_reflexivity_certificate_exhausts_stream',
       run(strict, T, refl_zero)['accepted'] and run(strict, T, refl_zero)['remaining'] == [])

# A failed major can consume input and fall through only to a hypothesis.
# This is inherited behavior; test exact stream prefix with a retained valid assumption.
context_cases = [
    (T, [[], [['=', 0, ['s', 0]], ['=', 1, 0]]], [T]),
    (T, ['hyp'], [T, QT]),
    (T, ['hyp'], [QT, T]),
    (['ex', T], ['hyp', [0]], [QT]),
]
context_match = True
for goal, proof, context in context_cases:
    good, _, _ = equivalent(old_strict, strict, goal, proof, context)
    context_match &= good
record('context_order_and_guard_fallback_match_baseline', context_match,
       {'cases': len(context_cases), 'context_boundary': 'internal API, supplied well-formed assumptions'})

# Witness strictness is explicit, not inferred from only successful examples.
unused_bad = q_elimination(QT, q_constant, {'bad': 'not a term'}, refl_zero, T)
used_bad = q_elimination(QB, q_reflexive, {'bad': 'not a term'}, refl_zero, T)
valid_zero = q_elimination(QB, q_reflexive, 0, refl_zero, T)
record('strict_rejects_malformed_unused_Q_witness', not run(strict, *unused_bad)['accepted'])
record('demand_accepts_only_dead_malformed_Q_annotation_in_this_case',
       run(demand, *unused_bad)['accepted'])
record('both_reject_malformed_used_Q_witness',
       not run(strict, *used_bad)['accepted'] and not run(demand, *used_bad)['accepted'])
record('both_accept_valid_Q_witness_zero',
       run(strict, *valid_zero)['accepted'] and run(demand, *valid_zero)['accepted'])

# Test the standalone boundary under normal Python and Python -O.
cli_cases = [
    ('reflexivity_zero', refl_zero + [T], True, True),
    ('inert_prefix', marker + refl_zero + [T], True, True),
    ('constant_closure', q_constant + [QT], True, True),
    ('equation_closure', q_reflexive + [QB], True, True),
    ('strict_unused_witness', unused_bad[1] + [unused_bad[0]], False, True),
    ('used_witness', used_bad[1] + [used_bad[0]], False, False),
    ('valid_zero_witness', valid_zero[1] + [valid_zero[0]], True, True),
    ('empty_document_list', [], False, False),
    ('object_document', {'goal': T}, False, False),
    ('null_document', None, False, False),
    ('integer_document', 0, False, False),
    ('string_document', 'bad', False, False),
    ('false_document', False, False, False),
    ('missing_instruction', [T], False, False),
    ('false_equation', [[], FALSE], False, False),
    ('boolean_as_zero', [[], ['=', False, False]], False, False),
    ('float_as_zero', [[], ['=', 0.0, 0.0]], False, False),
    ('formula_as_term', [[], ['=', QT, 0]], False, False),
    ('term_as_formula', [[], ['s', 0]], False, False),
    ('extra_formula_field', [[], ['=', 0, 0, 0]], False, False),
    ('missing_formula_field', [[], ['=', 0]], False, False),
    ('extra_successor_field', [[], ['=', ['s', 0, 0], 0]], False, False),
    ('extra_recursor_field', [[], ['=', ['r', 0, 0, 0, 0], 0]], False, False),
    ('unknown_formula_tag', [[], ['bad', 0, 0]], False, False),
    ('unknown_term_tag', [[], ['=', ['bad', 0], 0]], False, False),
    ('Q_with_numeric_matrix', [[], ['q', 0]], False, False),
    ('existential_with_numeric_matrix', [[0], ['ex', 0]], False, False),
    ('recursor_zero', [[], ['=', ['r', 0, 3, ['s', 1]], 3]], True, True),
    ('recursor_zero_wrong_rhs', [[], ['=', ['r', 0, 3, ['s', 1]], 4]], False, False),
    ('recursor_successor', [[], ['=', ['r', ['s', 0], 3, 2], 0]], True, True),
    ('recursor_positive_parameter', [[], ['=', ['r', 1, 0, 0], 0]], False, False),
    ('recursor_rigid_parameter', [[], ['=', ['r', -1, 0, 0], 0]], False, False),
    ('recursor_uncanonical_counter', [[], ['=', ['r', ['r', 0, 0, 0], 0, 0], 0]], False, False),
]
cli_failures = []
cli_runs = 0
with tempfile.TemporaryDirectory(prefix='ipra_checker_review_') as td:
    td = Path(td)
    for name, value, strict_expected, demand_expected in cli_cases:
        file = td / (name + '.json')
        file.write_text(json.dumps(value))
        for variant, expected in [('checker.py', strict_expected), ('checker_demand.py', demand_expected)]:
            for optimize in [False, True]:
                command = [sys.executable] + (['-O'] if optimize else []) + [str(PACKAGE / variant), str(file)]
                result = subprocess.run(command, capture_output=True, text=True, timeout=5)
                cli_runs += 1
                actual = result.returncode == 0 and result.stdout.strip() == 'ACCEPT'
                rejected_cleanly = result.returncode == 1 and result.stdout.strip() == 'REJECT' and not result.stderr
                if actual != expected or (not expected and not rejected_cleanly):
                    cli_failures.append({'case': name, 'variant': variant, 'optimized': optimize,
                                         'expected_accept': expected, 'returncode': result.returncode,
                                         'stdout': result.stdout, 'stderr': result.stderr})
    malformed = td / 'malformed.json'
    malformed.write_text('{ this is not JSON')
    for variant in ['checker.py', 'checker_demand.py']:
        for optimize in [False, True]:
            for argument in [str(malformed), str(td / 'missing.json'), None]:
                command = [sys.executable] + (['-O'] if optimize else []) + [str(PACKAGE / variant)]
                if argument is not None:
                    command.append(argument)
                result = subprocess.run(command, capture_output=True, text=True, timeout=5)
                cli_runs += 1
                if result.returncode != 1 or result.stdout.strip() != 'REJECT' or result.stderr:
                    cli_failures.append({'case': 'CLI_or_JSON_error', 'variant': variant, 'optimized': optimize,
                                         'argument': argument, 'returncode': result.returncode,
                                         'stdout': result.stdout, 'stderr': result.stderr})
record('standalone_negative_cases_and_python_optimized_mode', not cli_failures,
       {'semantic_cases': len(cli_cases), 'subprocess_runs': cli_runs,
        'variants': ['strict', 'demand'], 'python_modes': ['normal', '-O'],
        'failures': cli_failures[:10]})

hashes_after = {name: hashlib.sha256((PACKAGE / name).read_bytes()).hexdigest()
                for name in ['checker.py', 'checker_demand.py']}
record('kernel_files_unchanged_during_audit', hashes_before == hashes_after)

result = {
    'audit': 'Final direct-stream checker implementation review',
    'status': 'PASS' if not failures else 'FAIL',
    'python': sys.version.split()[0],
    'kernel_sha256': hashes_after,
    'scope': 'Finite tests and source review; no machine-checked metatheorem is claimed.',
    'checks': checks,
    'source_review': {
        'input_reader': 'The standalone program constructs a bound list.pop method from its sole JSON certificate. No external reader or state is trusted. Non-list JSON roots either lack pop or require a pop argument and are rejected.',
        'wildcard_computation': 'Sorted subst validation precedes matching. Formula arity three forces equality, and a four-field term forces r. The zero counter is exactly integer zero. A reducible nonzero counter must unpack as the validated two-field successor constructor.',
        'context_order': 'Each h is a fresh list (including star-captured parts). h += map(subst,g) changes assumption order but not membership. No parent context or input formula list is mutated by this extension.',
        'strict_witness': 'subst(t,[0],False) validates the full numerical witness and reconstructs it with identity offset. The right hand side of tuple assignment is evaluated before the old t is rebound.',
        'environment_aliasing': 'The default list [1] and all caller-owned environments are read only. Constructor rebuilding returns fresh lists. Offset-first layout is the permutation [old_offset,*old_images].',
        'instruction_prefix': 'Only the suffix read by take participates in acceptance. Earlier items may remain unread. Failed major proof attempts may consume items before a hypothesis fallback; this behavior is inherited and was compared with exact residual stacks.',
        'optimized_execution': 'Kernel validity does not rely on assert statements. Both normal and Python -O modes produced the expected outcomes in subprocess tests.',
        'unused_annotations': 'An existential-elimination second annotation and a hypothesis marker may be arbitrary inert JSON. The strictness claim concerns every used numerical witness, not every unread or semantically inert byte.',
    },
    'material_limits': [
        'Finite tests do not prove the general metatheorems or absence of all implementation defects.',
        'The input reader is global per standalone invocation; imported check is not a reentrant concurrent API.',
        'Host recursion and memory limits can reject very large valid certificates; no unbounded resource-completeness claim is made.',
        'The kernel intentionally permits an inert unread initial certificate segment and ignores additional command-line arguments.',
    ],
    'failures': failures,
}
(PACKAGE / 'results').mkdir(exist_ok=True)
(PACKAGE / 'results/checker_review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'checks': len(checks), 'failures': failures,
                  'substitution_cases': 3000, 'differential_cases_per_variant': len(corpus),
                  'subprocess_runs': cli_runs, 'kernel_sha256': hashes_after}, indent=2))
raise SystemExit(bool(failures))
