"""Replay the complete finite evidence without network access."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(*arguments):
    result = subprocess.run(
        [sys.executable, *arguments], cwd=ROOT, capture_output=True, text=True
    )
    if result.returncode:
        print(result.stdout)
        print(result.stderr, file=sys.stderr)
        raise SystemExit(result.returncode)
    print("Passed:", arguments[0])


def check_examples():
    provenance = json.loads((ROOT / "validation/example_provenance.json").read_text())
    actual = {str(p.relative_to(ROOT)) for p in (ROOT / "examples").glob("*.json")}
    if actual != {row["file"] for row in provenance}:
        raise ValueError("Example inventory does not match its provenance record.")
    for row in provenance:
        path = ROOT / row["file"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != row["sha256"]:
            raise ValueError("Changed example: " + row["file"])
    for filename in ("checker.py", "checker_demand.py"):
        spec = importlib.util.spec_from_file_location("replay_" + filename, ROOT / filename)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        for row in provenance:
            stream = json.loads((ROOT / row["file"]).read_text())
            module.take = stream.pop
            if not module.check(module.take(), []) or stream:
                raise ValueError("Example did not accept and exhaust: " + row["file"])
    return len(provenance)


def summarize(example_count):
    independent = json.loads((ROOT / "validation/independent.json").read_text())
    regression = json.loads((ROOT / "results/checker_review.json").read_text())
    measurements = json.loads((ROOT / "results/measurements.json").read_text())
    if independent["status"] != "PASS" or regression["status"] != "PASS":
        raise ValueError("A validation result does not pass.")
    hashes = {
        name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
        for name in ("checker.py", "checker_demand.py")
    }
    if regression["kernel_sha256"] != hashes:
        raise ValueError("Regression evidence is stale.")
    if independent["kernel_sha256"] != {
        "strict": hashes["checker.py"], "demand": hashes["checker_demand.py"]
    }:
        raise ValueError("Independent evidence is stale.")
    details = {row["name"]: row.get("detail", {}) for row in regression["checks"]}
    if not all(row["passed"] for row in regression["checks"]):
        raise ValueError("Regression check failed.")
    rows = [
        ("Random inputs checked with named-binder substitution", independent["substitution"]["random_named_oracle_inputs"]),
        ("Explicit capture and simultaneous-substitution fixtures", independent["substitution"]["explicit_capture_and_simultaneous_cases"]),
        ("Kernel comparisons and substitution algebra checks", independent["substitution"]["kernel_comparisons_and_algebra_checks"]),
        ("Targeted independent certificate cases", len(independent["certificates"]["cases"])),
        ("Certificates mutated and independently compared", independent["mutations"]["mutated_documents"]),
        ("Offset-layout comparisons with the frozen checker", details["offset_first_substitution_matches_old_layout_3000_cases"]["cases"]),
        ("Verdict and unread-prefix comparisons, per variant", details["strict_acceptance_and_consumed_prefix_match_baseline"]["cases"]),
        ("Standalone subprocess checks, including optimized Python", details["standalone_negative_cases_and_python_optimized_mode"]["subprocess_runs"]),
        ("Distributed theorem files, accepted and exhausted", example_count),
    ]
    lines = [
        r"\begin{center}\small",
        r"\begin{tabularx}{\linewidth}{@{}Xr@{}}",
        r"\toprule",
        r"Finite validation category & Count\\",
        r"\midrule",
    ]
    lines.extend(label + " & " + str(value) + r"\\" for label, value in rows)
    lines.extend([r"\bottomrule", r"\end{tabularx}", r"\end{center}"])
    (ROOT / "results/validation_table.tex").write_text("\n".join(lines) + "\n")
    summary = {
        "status": "PASS",
        "kernel_sha256": hashes,
        "example_files": example_count,
        "validation_rows": [{"category": label, "count": value} for label, value in rows],
        "independent_result": "validation/independent.json",
        "regression_result": "results/checker_review.json",
        "comparison_result": "results/measurements.json",
        "limitation": "Finite implementation evidence, not a formalized general metatheory.",
    }
    (ROOT / "results/validation_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print("All evidence passed; tested", example_count, "distributed theorem files.")


def main():
    run("comparison/measure.py")
    examples = check_examples()
    run("validation/independent.py", "--samples", "8000", "--output", "validation/independent.json")
    run("validation/regression.py")
    summarize(examples)


if __name__ == "__main__":
    main()
