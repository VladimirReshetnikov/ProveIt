"""Rerun the frozen source measurements and both validation suites offline."""
import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pdf', action='store_true', help='also compile the LaTeX paper')
    args = parser.parse_args()
    for relative in ('measure.py', 'validation/run.py', 'validation/independent/audit.py'):
        subprocess.run([sys.executable, str(ROOT / relative)], cwd=ROOT, check=True)
    if args.pdf:
        subprocess.run([sys.executable, str(ROOT / 'build.py')], cwd=ROOT, check=True)
    print('All requested reproduction steps passed.')


if __name__ == '__main__':
    main()
