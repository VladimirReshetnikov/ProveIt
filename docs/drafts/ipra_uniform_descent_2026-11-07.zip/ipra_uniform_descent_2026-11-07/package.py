"""Create a complete deterministic ZIP and a release SHA-256 manifest."""
import hashlib
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {'.aux', '.log', '.out', '.toc', '.pyc'}


def release_files():
    return sorted(p for p in ROOT.rglob('*')
                  if p.is_file() and p.name != 'SHA256SUMS.txt'
                  and '__pycache__' not in p.parts and p.suffix not in EXCLUDED_SUFFIXES)


def main():
    files = release_files()
    manifest = ROOT / 'SHA256SUMS.txt'
    manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  '
                                + p.relative_to(ROOT).as_posix() + '\n' for p in files))
    target = ROOT.with_suffix('.zip')
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(files + [manifest]):
            info = zipfile.ZipInfo((ROOT.name + '/' + path.relative_to(ROOT).as_posix()),
                                   date_time=(2026, 11, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())
    with zipfile.ZipFile(target) as archive:
        if archive.testzip() is not None:
            raise SystemExit('ZIP integrity failure')
    print(target)
    print('SHA256', hashlib.sha256(target.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
