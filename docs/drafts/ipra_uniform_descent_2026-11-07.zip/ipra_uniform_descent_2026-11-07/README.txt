UNIFORM DESCENT: A SMALLER COMPLETE PRESENTATION OF iPRA
Prepared for Vladimir Reshetnikov, 7 November 2026 (Pacific time)
================================================================

Read report.pdf. The complete editable source is report.tex with the
sections/ and foundation/ directories. This archive is self-contained
for offline reproduction and PDF rebuilding.

RESULT

Complete acceptance programs, measured with the unchanged supplied metric:

                                           Tokens   AST nodes   Norm. bytes
Current six-archive delivered envelope        356         378         1038
Current envelope with one common stdin driver 350         372         1030
This checker                                 342         364          990

All eleven root-level checker*.py programs in the six current archives were
included. The snapshot is ProveIt commit:
df8beb801d9f3e3eb3a8141722953fb58e63009e

The improvement survives the common-driver control: 8 normalized tokens,
8 AST nodes, and 40 bytes. A vector traversal with exactly the same completed
syntax measures 349/373/1028; replacing its vectors by one increment per
constructor therefore saves 7 tokens, 9 nodes, and 38 bytes.

THE IDEA

The existing uniform-scopes representation assigns the same scope increment
to every child of a constructor, but its implementation stores repeated
child-width vectors and traverses them with zip. The new helper selects
one increment per constructor and traverses the children directly. Its
empty traversal admits [] as numerical zero or formula truth. The report
proves that this completion is conservative, including computation,
empty-matrix induction, persistent truth under numerical insertion,
freshness, and the complete public acceptance boundary.

MATHEMATICAL STRENGTH

The native calculus has a scalar iterator, two computation schemas, and
five inference patterns. Its full logical reconstruction and arithmetic
bootstrap are inherited and reproduced with attribution. The ordinary
first-order realization is bi-interpretable with full first-order iPRA on
the whole numerical domain, with identity graph x=y for both composite
isomorphisms. Equiconsistency follows. The raw JSON trees are proof notation,
not a new object domain.

This is a strict measured implementation reduction of the inherited
axiomatization. It does not establish an absolute simplest axiomatization,
a new logical/arithmetic foundation, or a foundational breakthrough.
The larger conceptual target in the research request remains unresolved.
The metatheorems have written proofs, not a Lean or Rocq formalization.

RUN

  python3 checker.py < examples/zero.json
  python3 checker.py < examples/atomic_induction.json
  python3 reproduce.py
  python3 build.py

checker.py prints ACCEPT and exits 0 for an accepted packet, or prints
REJECT and exits 1 otherwise. Rejection is about that certificate, not
about unprovability of its intended formula. It reads JSON from stdin;
no filename argument is needed. FORMAT.txt specifies the entire syntax.

Python 3.10 or later is required. Reported measurements use CPython 3.12.14.
The verifier and audit tools use only Python's standard library.
PDF rebuilding additionally uses pdfLaTeX and the packages listed in the
report preamble. The supplied PDF is already compiled and visually checked.

EVIDENCE

The main validation suite passed 29,444 packet comparisons against a
separately structured sorted oracle, 1,500 opening comparisons, 400
opening-denotation checks, and 370 real normal/optimized CLI executions.
It includes all 147 supplied canonical uniform-scope proofs.

The independently adapted audit passed 15,000 opening comparisons,
the same 147 positive proofs, 75 closed-equation evaluations, 30,000
computation attempts (20,586 accepted and independently evaluated true),
10 focused scope/sort/nonfinite cases, and 29 additional empty-completion
packets. There were no mismatches or false evaluated equations.

These categories overlap. The oracles share inherited ancestry; they are
not independent proofs of the metatheory. Detailed receipts, exact source
hashes, and the distinction between old and new raw grammar meanings are
included. Finite testing does not establish consistency or bi-interpretability.

CONTENTS

  report.tex / report.pdf     Complete source and compiled mathematical paper
  sections/                  New traversal, correctness, comparison, evidence
  foundation/                Complete attributed logical and arithmetic proofs
  checker.py                 Entire trusted project-specific acceptance program
  FORMAT.txt                 Raw syntax, meanings, scope, instruction contract
  examples/                  28 named accepted/rejected packets with an index
  comparison/                Eleven frozen current programs, provenance, metric
  validation/                Main sorted oracle and executable validation
  validation/independent/    Separately adapted oracle and semantic audit
  results/                   Measurements, validation, build, and visual receipts
  measure.py                 Complete and common-driver comparisons
  reproduce.py               Offline verification entry point
  build.py                   Three-pass PDF build, shell escape disabled
  package.py                 ZIP and SHA-256 manifest creation
  ATTRIBUTION.txt / LICENSE.txt
                             Exact inherited/new contribution boundary

Only checker.py and the ordinary Python runtime/standard library determine
acceptance. None of the other project files is a trusted dependency.
Completeness idealizes sufficient finite resources; actual parser, stack,
time, and memory limits can reject large valid proofs.

After intentional edits run python3 package.py to regenerate SHA256SUMS.txt
and the ZIP. Rebuilding the PDF can change its metadata and therefore its
hash. The release manifest records the exact files delivered in this archive.
