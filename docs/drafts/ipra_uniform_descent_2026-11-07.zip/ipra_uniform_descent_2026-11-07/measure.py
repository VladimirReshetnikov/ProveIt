"""Reproduce the whole-program comparison with the supplied unmodified metric."""
import ast
import hashlib
import importlib.util
import json
import platform
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('source_measure', ROOT / 'comparison/source_measure.py')
METRIC = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(METRIC)
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
DRIVER = '''try:
    take = json.load(sys.stdin).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
'''


def measure_text(source, directory, label):
    path = directory / (label + '.py')
    path.write_text(source)
    return {key: METRIC.metrics(path)[key] for key in KEYS}


def common_driver(source):
    tree = ast.parse(source)
    if not isinstance(tree.body[-1], ast.Try):
        raise ValueError('Expected an explicit final public acceptance boundary')
    tree.body[-1:] = ast.parse(DRIVER).body
    return ast.unparse(tree) + '\n'


def main():
    entries = json.loads((ROOT / 'comparison/current_sources.json').read_text())
    rows = []
    with tempfile.TemporaryDirectory() as temporary:
        tmp = Path(temporary)
        for number, entry in enumerate(entries):
            path = ROOT / entry['local_file']
            result = METRIC.metrics(path)
            if entry.get('sha256') and result['sha256'] != entry['sha256']:
                raise ValueError('A frozen comparator changed: ' + str(path))
            rows.append({**entry, 'sha256': result['sha256'],
                         'delivered': {key: result[key] for key in KEYS},
                         'common_stdin': measure_text(common_driver(path.read_text()), tmp, str(number))})
        candidate = METRIC.metrics(ROOT / 'checker.py')
        candidate = {key: candidate[key] for key in KEYS}
        baseline = {mode: {key: min(row[mode][key] for row in rows) for key in KEYS}
                    for mode in ('delivered', 'common_stdin')}
        # A vector-based checker with exactly the same completed syntax as ours.
        vector = (ROOT / 'comparison/current/ipra_uniform_scopes_2026-11-07__checker.py').read_text()
        old = "(0, b'\\2', (b'\\1\\1', 0)[d % 2], b'\\4\\4\\4')[len(a)]"
        new = "(b'\\4\\4\\4', (b'\\1\\1', 0)[d % 2], b'\\2')[-len(a)]"
        if old not in vector:
            raise ValueError('Frozen vector traversal did not match the controlled change')
        vector = common_driver(vector.replace(old, new))
        control = measure_text(vector, tmp, 'vector_empty_control')
        (ROOT / 'comparison/vector_empty_control.py').write_text(vector)
    result = {'python': platform.python_version(), 'implementation': platform.python_implementation(),
              'commit': 'df8beb801d9f3e3eb3a8141722953fb58e63009e', 'archives': 6,
              'root_programs': len(rows), 'metric': 'Unmodified supplied source_measure.metrics',
              'coordinatewise_minima': baseline, 'candidate': candidate,
              'same_syntax_vector_control': control,
              'core_improvement_over_common_driver': {key: baseline['common_stdin'][key] - candidate[key] for key in KEYS},
              'structural_improvement_over_same_syntax': {key: control[key] - candidate[key] for key in KEYS},
              'programs': rows}
    for mode in baseline:
        if not all(candidate[key] < baseline[mode][key] for key in KEYS):
            raise ValueError('Candidate does not strictly improve every coordinate: ' + mode)
    (ROOT / 'results/measurements.json').write_text(json.dumps(result, indent=2) + '\n')
    lines = [r'\begin{tabular}{@{}lrrr@{}}', r'\toprule',
             r'Complete program or envelope & Tokens & AST nodes & Bytes\\', r'\midrule']
    for label, values in [('Current, delivered drivers', baseline['delivered']),
                          ('Current, one common stdin driver', baseline['common_stdin']),
                          ('Vector traversal, same completed syntax', control),
                          ('Uniform descent (this work)', candidate)]:
        lines.append(label + ' & ' + ' & '.join(str(values[key]) for key in KEYS) + r'\\')
    lines.extend([r'\bottomrule', r'\end{tabular}'])
    (ROOT / 'results/summary_table.tex').write_text('\n'.join(lines) + '\n')
    detail = [r'\begin{longtable}{@{}p{0.53\textwidth}rrr@{}}', r'\toprule',
              r'Archive / root program & Tokens & Nodes & Bytes\\', r'\midrule', r'\endhead']
    for row in rows:
        label = row['archive'].replace('ipra_', '').replace('_2026-11-07.zip', '')
        filename = Path(row['path_in_archive']).name
        escaped = (label + ' / ' + filename).replace('_', r'\_')
        detail.append(escaped + ' & ' + ' & '.join(str(row['delivered'][key]) for key in KEYS) + r'\\')
    detail.extend([r'\bottomrule', r'\end{longtable}'])
    (ROOT / 'results/current_table.tex').write_text('\n'.join(detail) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'programs'}, indent=2))


if __name__ == '__main__':
    main()
