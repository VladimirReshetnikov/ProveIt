"""Compile the complete report without shell escape and check the final log."""
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    subprocess.run([sys.executable, str(ROOT / 'measure.py')], cwd=ROOT, check=True)
    if not shutil.which('pdflatex'):
        raise SystemExit('pdfLaTeX is required to rebuild the PDF; the release includes a compiled PDF.')
    for number in range(1, 4):
        result = subprocess.run(['pdflatex', '-no-shell-escape', '-interaction=nonstopmode',
                                 '-halt-on-error', 'report.tex'], cwd=ROOT,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        (ROOT / 'results' / ('latex_pass_' + str(number) + '.txt')).write_text(result.stdout)
        if result.returncode:
            print(result.stdout[-9000:])
            raise SystemExit(result.returncode)
    log = (ROOT / 'report.log').read_text(errors='replace')
    bad = re.findall(r'Overfull \\[hv]box[^\n]*|LaTeX Warning: (?:Reference|Citation)[^\n]*|There were undefined references[^\n]*', log)
    receipt = {'pdf': 'report.pdf', 'passes': 3, 'shell_escape': False, 'layout_or_reference_errors': bad}
    (ROOT / 'results/build.json').write_text(json.dumps(receipt, indent=2) + '\n')
    if bad:
        print('\n'.join(bad))
        raise SystemExit('Fix the reported layout/reference defects before publication.')
    print('Compiled report.pdf; no overfull boxes or unresolved references.')


if __name__ == '__main__':
    main()
