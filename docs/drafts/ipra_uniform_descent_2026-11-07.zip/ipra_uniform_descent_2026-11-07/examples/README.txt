EXPLICIT CERTIFICATES AND REJECTION CONTROLS
===========================================

Run an example through the complete stdin checker:

    python3 checker.py < examples/zero.json
    python3 -O checker.py < examples/reject_numeric_binary.json

The first command prints ACCEPT and exits 0; the second prints REJECT and
exits 1. index.json gives every expected result, description, source
identity, and exact file hash. validation/run.py checks each example
through the actual public CLI in both modes.

The positive cases include both computation schemas, atomic induction,
paired introduction/elimination, closure elimination, equality transport,
small arithmetic proofs, empty numerical zero, and an empty formula matrix.
The controls cover false equations, freshness, scope escape, numerical
binary nodes, the older first-child-introduction attack, excessive arity,
strings, objects, missing instructions, and active nonfinite labels.

An empty matrix means truth. Its extra local assumption in the tiny
program is harmless because that assumption itself denotes truth; it does
not make arbitrary-formula induction available. A numerical binary node
remains invalid, preserving the interpretation of inserted numerical
images as truth-only formula trees.

reject_nonfinite.json deliberately contains Python JSON's optional NaN
extension; strict RFC JSON parsers will reject that spelling before proof
checking. The production Python decoder accepts the spelling and the
checker then rejects its active occurrence in the asserted formula.
