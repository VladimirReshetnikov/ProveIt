FINITE VALIDATION
=================

Run from the package root:

    python3 validation/run.py

The command needs Python 3.10 or later and only its standard library. It
reads the actual checker.py, this directory, and examples/. It writes
results/validation.json. No repository checkout, network access, installed
research package, or file outside this archive is required.

TRUST BOUNDARY

Only checker.py decides acceptance. The oracle, generators, numerical
evaluator, and fixtures are test support and are not imported by it.
The harness extracts the actual definitions for trace comparisons, and
separately invokes the complete public stdin program in new Python
processes both normally and with -O. It verifies exit status, the exact
verdict, and empty stderr.

EVIDENCE

The named-rule oracle implements numerical and formula syntax separately,
counts protected variables rather than encoded coordinates, and dispatches
inferences by explicit named cases. It includes the newly allowed empty
zero, empty truth, empty-counter computation, and empty-matrix introduction
cases. It is independently structured software adapted from the supplied
uniform-scopes oracle, not an independent formal metatheory.

The suite includes 147 inherited positive certificates (with original
provenance), explicitly named examples, deterministic subtree mutations,
random malformed packets, false-equation substitutions at the root,
opening comparisons across scopes, numerical denotation checks, and
base/successor computations containing empty arrays. Every population is
reported separately; overlapping populations are not independent results.

The numerical evaluator uses finite budgets, reported in the receipt.
These bound test generation only and never affect the production checker
or add axioms to the theory. The written proofs supply the universal
soundness, completeness, and bi-interpretation arguments; finite tests do
not establish those theorems.

REPRODUCIBILITY

The receipt records the checker, harness, oracle, fixture, provenance, and
example-index hashes, the Python version, deterministic seed, population
counts, and failures. The provenance file retains the inspected source
commit and exact inherited member hashes. Original fixture paths inside
its metadata describe historical provenance, not runtime dependencies.

The public program follows Python JSON decoding. A named rejection example
therefore deliberately exercises the decoder's nonstandard NaN spelling;
additional CLI checks cover Infinity and -Infinity. Their occurrence in an
active asserted goal is rejected. This does not claim that every unused
prefix or never-inserted annotation must be rejected.
