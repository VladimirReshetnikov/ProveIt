#!/usr/bin/env python3
"""Reproduce finite validation using only this package and the standard library.

The public checker imports none of this file, the oracle, or the fixtures.
Run from any directory: python3 validation/run.py
"""

import ast
from collections import Counter
from copy import deepcopy
import hashlib
import itertools
import json
import math
from pathlib import Path
import platform
import random
import subprocess
import sys
import types

from oracle import Oracle


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CHECKER = ROOT / 'checker.py'
SEED = 104881


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_definitions(path):
    """Load the actual checker definitions; CLI tests run its actual driver."""
    tree = ast.parse(Path(path).read_text())
    body = []
    for node in tree.body:
        if isinstance(node, ast.Try):
            break
        body.append(node)
    module = types.ModuleType('checker_under_test')
    exec(compile(ast.Module(body=body, type_ignores=[]), str(path), 'exec'),
         module.__dict__)
    return module


def trace(module, packet):
    module.k = 0
    stack = deepcopy(packet)
    try:
        module.take = stack.pop
        accepted = bool(module.check(stack.pop(), []))
    except Exception:
        accepted = False
    return accepted, module.k, len(stack) if type(stack) is list else None


def paths(value, prefix=()):
    result = [prefix]
    if type(value) is list:
        for index, child in enumerate(value):
            result.extend(paths(child, prefix + (index,)))
    return result


def replace(value, path, replacement):
    if not path:
        return replacement
    parent = value
    for index in path[:-1]:
        parent = parent[index]
    parent[path[-1]] = replacement
    return value


ATOMS = [None, False, True, -4, -1, 0, 1, 2, 3, 4, 0.25, 0.75,
         1.5, 2.75, -0.25, -1.5, 10**100, float('inf'),
         float('-inf'), float('nan'), 'x', {}, []]


def random_tree(rng, depth=3):
    if depth <= 0 or rng.random() < 0.65:
        return deepcopy(rng.choice(ATOMS))
    return [random_tree(rng, depth - 1) for _ in range(rng.randrange(5))]


def numeric_value(term, scope=(), rigid=None, exposed=None, budget=None):
    """Finite standard-model denotation, independent of opening or proof rules.

    Execution bounds are for testing only and never affect proof acceptance.
    Successor binds one zero dummy; an iterator's count and seed bind two
    zero dummies; its update binds two aliases of the previous state.
    """
    rigid = {} if rigid is None else rigid
    budget = [10000] if budget is None else budget
    budget[0] -= 1
    if budget[0] < 0:
        raise OverflowError('finite evaluation work budget')
    if isinstance(term, (int, float)):
        if isinstance(term, float) and not math.isfinite(term):
            raise ValueError('a surviving numerical label must be finite')
        label = math.floor(term)
        if label < 0:
            if label in rigid:
                return rigid[label]
        elif label == 0:
            return 0
        elif (label - 1) // 2 < len(scope):
            return scope[(label - 1) // 2]
        if exposed is None:
            raise ValueError('unbound coordinate')
        return exposed
    if type(term) is not list:
        raise ValueError('non-numerical syntax')
    if len(term) == 0:
        return 0
    if len(term) == 1:
        result = numeric_value(term[0], (0,) + scope, rigid,
                               exposed, budget) + 1
    elif len(term) == 3:
        count = numeric_value(term[0], (0, 0) + scope, rigid,
                              exposed, budget)
        if count > 16:
            raise OverflowError('finite evaluation iteration budget')
        result = numeric_value(term[1], (0, 0) + scope, rigid,
                               exposed, budget)
        for _ in range(count):
            result = numeric_value(term[2], (result, result) + scope,
                                   rigid, exposed, budget)
    else:
        raise ValueError('invalid numerical constructor')
    if result > 10000:
        raise OverflowError('finite evaluation value budget')
    return result


def term_tree(rng, depth, protected=0, holes=False, lower=-2):
    if depth <= 0 or rng.random() < 0.55:
        labels = [0, False, 0.25] + list(range(1, 2 * protected + 1))
        labels += list(range(lower, 0))
        if holes:
            labels += [2 * protected + 1, 2 * protected + 3, lower - 1]
        label = rng.choice(labels)
        if isinstance(label, int) and label != 0 and rng.random() < 0.25:
            label += 0.5
        return label
    arity = rng.choice((0, 1, 3))
    if arity == 0:
        return []
    added = 1 if arity == 1 else 2
    return [term_tree(rng, depth - 1, protected + added, holes, lower)
            for _ in range(arity)]


def numeral(value):
    result = 0
    for _ in range(value):
        result = [result]
    return result


def json_safe(value):
    if isinstance(value, float) and not math.isfinite(value):
        return repr(value)
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    return value


class Audit:
    def __init__(self):
        self.module = load_definitions(CHECKER)
        self.rng = random.Random(SEED)
        self.counts = Counter()
        self.accepted = 0
        self.rules = Counter()
        self.failures = []
        self.failure_count = 0

    def failure(self, label, detail):
        self.failure_count += 1
        if len(self.failures) < 20:
            self.failures.append({'label': label, 'detail': json_safe(detail)})

    def packet(self, packet, cohort, expected=None, required_rules=()):
        self.counts[cohort] += 1
        actual = trace(self.module, packet)
        reference = Oracle().run(packet)
        wanted = (reference['accepted'], reference['final_k'],
                  reference['remaining'])
        if actual != wanted:
            self.failure('named-rule agreement', {
                'cohort': cohort, 'actual': actual,
                'oracle': reference, 'packet': packet})
        if expected is not None and actual[0] != expected:
            self.failure('expected verdict', {
                'cohort': cohort, 'actual': actual,
                'expected': expected, 'packet': packet})
        if actual[0]:
            self.accepted += 1
            self.rules.update(reference['rules'])
        for rule in required_rules:
            if not reference['rules'].get(rule):
                self.failure('missing example rule', {
                    'cohort': cohort, 'rule': rule, 'oracle': reference})
        return actual[0]

    def packet_populations(self, records, examples):
        for record in records:
            self.packet(record['packet'], 'inherited_positive', True)
        for example in examples:
            path = ROOT / 'examples' / example['file']
            if digest(path) != example['sha256']:
                self.failure('example hash', example['file'])
            self.packet(json.loads(path.read_text()), 'named_example',
                        example['expected'],
                        example.get('required_oracle_rules', ()))

        replacements = [None, [], 0, 1, -1, 0.5, 1.5, -0.5, {}, '',
                        'x', False, True, [0], [0, 0], [0, 0, 0],
                        [0, 0, 0, 0]]
        for record in records:
            available = paths(record['packet'])
            for _ in range(125):
                path = self.rng.choice(available)
                value = deepcopy(self.rng.choice(replacements))
                packet = replace(deepcopy(record['packet']), path, value)
                self.packet(packet, 'single_subtree_mutation')
        for _ in range(10000):
            packet = [random_tree(self.rng, 3)
                      for _ in range(self.rng.randrange(1, 9))]
            self.packet(packet, 'random_packet')

        for false_goal in ([[0], 0], [0, [0]]):
            for record in records:
                packet = deepcopy(record['packet'][:-1]) + [false_goal]
                self.packet(packet, 'false_root_equation', False)

    def opening_agreement(self):
        counts = Counter()
        for index in range(1500):
            lower = self.rng.choice((0, -1, -3))
            formula = bool(index % 2)
            protected = self.rng.randrange(4)
            tree = random_tree(self.rng, 4)
            image = self.rng.choice((None, 0, [], [0], [0, 0], -1, 'x'))
            self.module.k = lower
            depth = 2 * protected + (0 if formula else 1)
            try:
                actual = True, self.module.inst(deepcopy(tree),
                                                deepcopy(image), depth)
            except Exception:
                actual = False, None
            oracle = Oracle()
            oracle.lower = lower
            method = oracle.formula if formula else oracle.term
            try:
                expected = True, method(deepcopy(tree), deepcopy(image),
                                        protected)
            except Exception:
                expected = False, None
            counts['successful' if actual[0] else 'rejected'] += 1
            if actual != expected:
                self.failure('opening agreement', {
                    'tree': tree, 'image': image, 'lower': lower,
                    'formula': formula, 'protected': protected,
                    'actual': actual, 'expected': expected})
        return {'cases': sum(counts.values()), 'counts': dict(counts),
                'sorts': ['formula', 'numerical'],
                'protected_variable_counts': [0, 1, 2, 3],
                'allocation_floors': [0, -1, -3]}

    def opening_denotation(self):
        checked = skipped = 0
        for _ in range(800):
            rigid = {-2: self.rng.randrange(4), -1: self.rng.randrange(4)}
            template = term_tree(self.rng, 3, holes=True)
            image = term_tree(self.rng, 2)
            self.module.k = -2
            try:
                opened = self.module.inst(template, image, 1)
                image_value = numeric_value(image, rigid=rigid)
                before = numeric_value(template, rigid=rigid,
                                       exposed=image_value)
                after = numeric_value(opened, rigid=rigid)
            except OverflowError:
                skipped += 1
                continue
            except Exception as exc:
                self.failure('valid numerical opening', {
                    'template': template, 'image': image,
                    'error': type(exc).__name__})
                continue
            checked += 1
            if before != after:
                self.failure('opening denotation', {
                    'template': template, 'image': image, 'opened': opened,
                    'rigid': rigid, 'before': before, 'after': after})
            if checked == 400:
                break
        if checked < 200:
            self.failure('insufficient denotation sample', checked)
        return {'checked': checked, 'budget_skips': skipped,
                'meaning': 'Opening agrees with replacing every exposed '
                           'coordinate by the numerical image value.',
                'test_limits_only': {'maximum_iterator_count': 16,
                                     'maximum_numerical_value': 10000,
                                     'maximum_evaluator_calls': 10000}}

    def computation_denotation(self):
        counts = Counter()
        counters = [0, [], [0], [[]], [1], [[0]]]
        seeds = [0, [], [0], [1], [0, 0, 0]]
        updates = [0, [], 1, 2, 3, 4, [1], [3], [4], [0, 3, [3]]]
        for count, seed, update in itertools.product(counters, seeds, updates):
            if count in (0, []):
                right = deepcopy(seed)
            else:
                right = Oracle().term(update, [count[0], seed, update])
            left = [count, seed, update]
            packet = [[], [left, right]]
            self.packet(packet, 'targeted_computation', True)
            try:
                left_value, right_value = numeric_value(left), numeric_value(right)
                if left_value != right_value:
                    self.failure('computation denotation', {
                        'packet': packet, 'left': left_value,
                        'right': right_value})
                bad_packet = [[], [deepcopy(left), numeral(left_value + 1)]]
                self.packet(bad_packet, 'incorrect_computation_result', False)
            except Exception as exc:
                self.failure('computation evaluation', {
                    'packet': packet, 'error': type(exc).__name__})
            counts['base' if count in (0, []) else 'successor'] += 1
            if count == []:
                counts['empty_counter'] += 1
            if seed == []:
                counts['empty_seed'] += 1
            if update == []:
                counts['empty_update'] += 1
        return {'positive_cases': 300, 'wrong_result_cases': 300,
                'counts': dict(counts),
                'independent_denotation': True}

    def public_cli(self, records, examples):
        counts = Counter()
        expected_acceptances = 0
        expected_rejections = 0

        def execute(text, expected, cohort, label):
            nonlocal expected_acceptances, expected_rejections
            for optimized in (False, True):
                command = [sys.executable]
                if optimized:
                    command.append('-O')
                command.append(str(CHECKER))
                counts[cohort] += 1
                expected_acceptances += expected
                expected_rejections += not expected
                try:
                    process = subprocess.run(command, input=text, text=True,
                                             capture_output=True, timeout=10)
                    actual = (process.returncode, process.stdout.strip(),
                              process.stderr)
                    wanted = (0, 'ACCEPT', '') if expected else (1, 'REJECT', '')
                    if actual != wanted:
                        self.failure('public stdin CLI', {
                            'label': label, 'optimized': optimized,
                            'actual': actual, 'expected': wanted})
                except Exception as exc:
                    self.failure('public stdin execution', {
                        'label': label, 'optimized': optimized,
                        'error': type(exc).__name__})

        for record in records:
            execute(json.dumps(record['packet'], allow_nan=False), True,
                    'inherited_positive', record['id'])
        for example in examples:
            execute((ROOT / 'examples' / example['file']).read_text(),
                    example['expected'], 'named_example', example['file'])
        malformed = {
            'empty_input': '', 'truncated_json': '[',
            'trailing_garbage': '[0] trailing', 'null_packet': 'null',
            'numeric_packet': '7', 'string_packet': '"x"',
            'object_packet': '{}', 'empty_packet': '[]',
            'active_positive_infinity': '[[], [[0, Infinity, 0], 0]]',
            'active_negative_infinity': '[[], [[0, -Infinity, 0], 0]]',
        }
        for label, contents in malformed.items():
            execute(contents, False, 'malformed_stdin', label)
        return {'runs': sum(counts.values()), 'counts': dict(counts),
                'expected_acceptances': expected_acceptances,
                'expected_rejections': expected_rejections,
                'normal_and_optimized': True,
                'contract_checked': ['exit status', 'verdict on stdout',
                                     'empty stderr', 'stdin decoding'],
                'per_process_timeout_seconds': 10}


def main():
    provenance = json.loads((HERE / 'provenance.json').read_text())
    records = json.loads((HERE / 'positive_certificates.json').read_text())['records']
    examples = json.loads((ROOT / 'examples/index.json').read_text())
    audit = Audit()
    for source in provenance['inherited_files']:
        if 'local_file' in source and digest(HERE / source['local_file']) != source['sha256']:
            audit.failure('inherited source hash', source['local_file'])
    audit.packet_populations(records, examples)
    opening = audit.opening_agreement()
    denotation = audit.opening_denotation()
    computation = audit.computation_denotation()
    cli = audit.public_cli(records, examples)
    receipt = {
        'status': 'PASS' if audit.failure_count == 0 else 'FAIL',
        'python_version': platform.python_version(),
        'python_implementation': platform.python_implementation(),
        'deterministic_random_seed': SEED,
        'checker': {'path': 'checker.py', 'sha256': digest(CHECKER)},
        'validation_files': {str(p.relative_to(ROOT)): digest(p)
                             for p in (HERE / 'run.py', HERE / 'oracle.py',
                                       HERE / 'positive_certificates.json',
                                       HERE / 'provenance.json',
                                       ROOT / 'examples/index.json')},
        'packet_populations': dict(audit.counts),
        'packet_comparisons': sum(audit.counts.values()),
        'accepted_packets': audit.accepted,
        'accepted_rule_counts': dict(audit.rules),
        'opening_agreement': opening,
        'opening_denotation': denotation,
        'computation_denotation': computation,
        'public_cli': cli,
        'failure_count': audit.failure_count,
        'failures': audit.failures,
        'scope': 'Finite reproducible implementation evidence; overlapping '
                 'samples are not independent mathematical theorems. '
                 'No proof-assistant formalization of soundness, completeness, '
                 'consistency, or bi-interpretability is claimed.',
    }
    destination = ROOT / 'results/validation.json'
    destination.parent.mkdir(exist_ok=True)
    destination.write_text(json.dumps(receipt, indent=2, allow_nan=False) + '\n')
    print(json.dumps({key: receipt[key] for key in (
        'status', 'checker', 'packet_populations', 'packet_comparisons',
        'accepted_packets', 'opening_agreement', 'opening_denotation',
        'computation_denotation', 'public_cli', 'failure_count')}, indent=2))
    if audit.failure_count:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
