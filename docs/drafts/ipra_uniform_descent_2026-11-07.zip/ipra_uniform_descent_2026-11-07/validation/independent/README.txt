Independent validation
======================

From the package root run:
  python validation/independent/audit.py

No network or third-party Python packages are required. The script resolves
all inputs relative to itself, so it also runs from another working directory.
It reads ../../checker.py and writes ../../results/independent_audit.json.
Optional positional arguments override the checker, positive fixture file,
and result path, in that order.

The audit compares opening and full proof acceptance with an explicit sorted,
named-rule oracle. A separate numerical evaluator checks closed equations
without invoking the production opener or production proof checker. Samples
include empty zero aliases, floating interval aliases, zero dummy scopes,
duplicated state slots, scope-loss attacks, NaN/infinities, and sort attacks.
All counts are finite regression evidence; no exhaustive soundness claim is made.

The public JSON driver is not exercised here: the checker functions are loaded
by omitting its top-level driver AST node. Driver validation belongs to the
package's other validation script. The entire production checker source hash
is recorded in the audit output to identify the tested version.

Files and provenance are documented in ATTRIBUTION.txt and provenance.json.
The old pairing example labels are not expectations for the new grammar.
