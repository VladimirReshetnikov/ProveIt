"""Independent finite audit for the complete uniform-descent checker.

Run from the package root:
    python validation/independent/audit.py
Optional positional arguments: CHECKER.py POSITIVE_CERTIFICATES.json OUT.json.
Defaults are relative to this script; output is results/independent_audit.json.

The named-rule oracle uses explicitly sorted syntax and separate rule branches.
The numerical evaluator independently interprets the intended zero-dummy scopes,
including empty zero aliases. Tests are finite evidence, not a proof of soundness.
See ATTRIBUTION.txt and provenance.json for the inherited source and modifications.
"""
from pathlib import Path
import ast, copy, hashlib, importlib.util, json, math, random, sys

HERE=Path(__file__).resolve().parent
PACKAGE=HERE.parent.parent
checker=Path(sys.argv[1]) if len(sys.argv)>1 else PACKAGE/'checker.py'
fixtures=Path(sys.argv[2]) if len(sys.argv)>2 else HERE/'positive_certificates.json'
output=Path(sys.argv[3]) if len(sys.argv)>3 else PACKAGE/'results/independent_audit.json'
spec=importlib.util.spec_from_file_location('independent_oracle',HERE/'oracle.py')
om=importlib.util.module_from_spec(spec);spec.loader.exec_module(om)
raw_checker=checker.read_bytes();tree=ast.parse(raw_checker)
ns={};tree.body=[n for n in tree.body if not isinstance(n,ast.Try)]
exec(compile(tree,str(checker),'exec'),ns)


def actual(packet):
    ns['k']=0
    try:
        cells=copy.deepcopy(packet);ns['take']=cells.pop
        return bool(ns['check'](cells.pop(),[]))
    except BaseException:
        return False


class Limit(Exception):pass


def numerical(t,env=(),budget=None):
    """Evaluate the mathematical reading, independent of production opening.

    env contains values of positive coordinates, nearest first. Every two
    coordinates refer to one slot. Global negative parameters are forbidden
    because this evaluator is used only for closed equations at root.
    """
    if budget is None:budget=[20000]
    budget[0]-=1
    if budget[0]<0:raise Limit('evaluation budget')
    if isinstance(t,(int,float)):
        if not math.isfinite(t) or t<0:raise ValueError('non-closed numerical leaf')
        if t<1:return 0
        return env[math.floor((t-1)/2)]
    if type(t) is not list:raise ValueError('numerical type')
    if not t:return 0
    if len(t)==1:
        ans=1+numerical(t[0],(0,)+env,budget)
    elif len(t)==3:
        count=numerical(t[0],(0,0)+env,budget)
        ans=numerical(t[1],(0,0)+env,budget)
        if count>2000:raise Limit('counter too large')
        for _ in range(count):
            ans=numerical(t[2],(ans,ans)+env,budget)
    else:raise ValueError('numerical arity')
    if ans>100000:raise Limit('value too large')
    return ans

rng=random.Random(20261107042)
pool=[-1e100,-5.5,-3.,-2.999,-2.5,-2.,-1.999,-1.5,-1.,-.999,-.5,-.001,-0.0,0,0.001,.5,.999,1.,1.001,1.5,1.999,2.,2.001,2.5,2.999,3.,3.5,4.,4.999,5.,5.5,7.,100.5,1e100,float('nan'),float('inf'),-float('inf'),True,False,None,'',{},[]]


def raw(depth):
    if depth==0 or rng.random()<.57:return copy.deepcopy(rng.choice(pool))
    return [raw(depth-1) for _ in range(rng.randrange(5))]


def call(f,*args):
    try:return True,f(*args)
    except BaseException:return False,None


opening_bad=[];opening_total=15000
for i in range(opening_total):
    k=-rng.randrange(5);d=rng.randrange(11)
    a=raw(4);t=raw(3)
    ns['k']=k;o=om.Oracle();o.lower=k
    x=call(ns['inst'],a,t,d)
    y=call(o.term if d%2 else o.formula,a,t,d//2)
    if x!=y:
        opening_bad.append({'i':i,'k':k,'d':d,'a':a,'t':t,'actual':x,'oracle':y})
        if len(opening_bad)>9:break

sources=json.loads(fixtures.read_text())
if isinstance(sources,dict):sources=[record['packet'] for record in sources['records']]
source_bad=[];source_accepts=0;closed_roots=0;root_limits=0;root_false=[]
for i,p in enumerate(sources):
    x=actual(p);y=om.Oracle().run(p)['accepted'];source_accepts+=x
    if x!=y:source_bad.append({'i':i,'actual':x,'oracle':y})
    goal=p[-1]
    if x and type(goal) is list and len(goal)==2:
        try:
            l=numerical(goal[0]);r=numerical(goal[1]);closed_roots+=1
            if l!=r:root_false.append({'i':i,'goal':goal,'values':[l,r]})
        except Limit:root_limits+=1


def term(q,depth):
    if rng.random()<.12:return []
    if depth==0 or rng.random()<.65:
        a=rng.randrange(2*q+1)
        return a+(rng.choice([0.,.125,.5,.875]) if rng.random()<.4 else 0)
    if rng.random()<.55:return [term(q+1,depth-1)]
    return [term(q+2,depth-1) for _ in range(3)]

# Directly stress both computation equations, especially scope removal:
# n=[p] reads p under three zero slots; the recursive image reads p under two.
schema_total=30000;schema_accepted=0;schema_rejected=0;schema_evaluated=0;schema_limits=0;schema_false=[]
for i in range(schema_total):
    count=rng.choice([0,[]]) if rng.random()<.3 else [term(3,3)]
    seed=term(2,3);update=term(2,3)
    whole=[count,seed,update]
    ns['k']=0
    try:
        rhs=seed if not count else ns['inst'](update,[count[0],seed,update],1)
        packet=[[],[whole,rhs]]
    except BaseException:
        schema_rejected+=1;continue
    if not actual(packet):schema_rejected+=1;continue
    schema_accepted+=1
    if not om.Oracle().run(packet)['accepted']:
        schema_false.append({'i':i,'kind':'oracle disagreement','packet':packet});continue
    try:
        l=numerical(whole);r=numerical(rhs);schema_evaluated+=1
        if l!=r:schema_false.append({'i':i,'packet':packet,'values':[l,r]})
    except Limit:schema_limits+=1
    except Exception as exc:schema_false.append({'i':i,'kind':'semantic parse failure','error':type(exc).__name__,'packet':packet})

# Concrete boundary cases isolate scope loss instead of random source noise.
# First: zero seed mentions a ghost slot, and cannot escape at root.
# Second: successor p uses the third slot and must be rejected when inserted.
# Third: the same p is harmless when the update ignores the state.
focused=[
    ('zero_seed_escape',[[],[[0,1,0],1]],False),
    ('successor_used_third_slot',[[],[[[5],0,1],[5,0,1]]],False),
    ('successor_unused_third_slot',[[],[[[5],0,0],0]],True),
    ('successor_used_second_slot',[[],[[[3],0,1],[3,0,1]]],True),
    ('fractional_unused_third_slot',[[],[[[5.5],0,0],0]],True),
    ('fractional_used_third_slot',[[],[[[5.5],0,1],[5.5,0,1]]],False),
    ('unguarded_equation_attack',[0,[[0],0]],False),
    ('active_NaN_rejected',[[],[[0,float('nan'),0],0]],False),
    ('active_positive_infinity_rejected',[[],[[0,float('inf'),0],0]],False),
    ('active_negative_infinity_rejected',[[],[[0,-float('inf'),0],0]],False),
]
focused_results=[]
for name,p,expected in focused:
    x=actual(p);y=om.Oracle().run(p)['accepted']
    focused_results.append({'name':name,'expected':expected,'actual':x,'oracle':y,'passed':x==y==expected,'packet':p})

# These packets use the older pairing grammar. Only agreement with the
# independently specified NEW grammar is asserted, not preservation of their
# former expected verdicts. Uniform dummy slots can change their interpretation.
empty_examples=[]
for record in json.loads((HERE/'empty_examples.json').read_text())['records']:
    p=record['packet'];x=actual(p);y=om.Oracle().run(p)['accepted']
    empty_examples.append({'name':record['name'],'actual':x,'oracle':y,
                           'previous_grammar_expected':record['previous_grammar_expected'],
                           'passed':x==y})

res={'checker_sha256':hashlib.sha256(raw_checker).hexdigest(),
     'opening_comparisons':opening_total,'opening_mismatches':opening_bad,
     'source_packets':len(sources),'source_accepts':source_accepts,'source_oracle_mismatches':source_bad,
     'source_closed_equations_evaluated':closed_roots,'source_evaluation_limits':root_limits,'source_false_equations':root_false,
     'schema_attempts':schema_total,'schema_accepted':schema_accepted,'schema_rejected':schema_rejected,
     'schema_evaluated':schema_evaluated,'schema_evaluation_limits':schema_limits,'schema_failures':schema_false,
     'focused_cases':focused_results,'empty_examples':empty_examples}
res['status']='FAIL' if (opening_bad or source_bad or root_false or schema_false or
    not all(x['passed'] for x in focused_results+empty_examples)) else 'PASS'
output.parent.mkdir(parents=True,exist_ok=True)
output.write_text(json.dumps(res,indent=2,allow_nan=True)+'\n')
print(json.dumps({k:(len(v) if isinstance(v,list) else v) for k,v in res.items()},indent=2))
if res['status']!='PASS':
    raise SystemExit('AUDIT FAILURE')
