"""Readable, separately structured acceptance oracle for the scalar calculus.

This validation program is adapted from the current uniform-scopes draft's
``validation/oracle_uniform.py``.  See ATTRIBUTION.txt for pinned provenance
and LICENSE-inherited.txt for its license.  The changes are conservative
empty-array completion and explicit counters for its inference cases.

The production checker is not imported.  Numerical and formula traversals
are separate, and binding depth counts variables rather than packed labels.
This is an independently structured implementation, not an independent
formal proof of the mathematical soundness theorem.
"""

from copy import deepcopy


class Oracle:
    """Name each inference and distinguish numerical from formula syntax."""

    def __init__(self):
        self.lower = 0
        self.rules = {}
        self.stack = []

    def rule(self, name):
        self.rules[name] = self.rules.get(name, 0) + 1

    def leaf(self, value, image, protected, formula):
        ceiling = 2 * protected + (0 if formula else 1)
        if self.lower <= value < ceiling:
            return value
        return self.term(image)

    def term(self, value, image=None, protected=0):
        if isinstance(value, (int, float)):
            return self.leaf(value, image, protected, False)
        if type(value) is not list:
            raise ValueError('numerical syntax must be a number or array')
        if len(value) == 0:
            return []
        if len(value) == 1:
            return [self.term(value[0], image, protected + 1)]
        if len(value) == 3:
            count, seed, update = value
            return [self.term(count, image, protected + 2),
                    self.term(seed, image, protected + 2),
                    self.term(update, image, protected + 2)]
        raise ValueError('invalid numerical constructor arity')

    def formula(self, value, image=None, protected=0):
        if isinstance(value, (int, float)):
            return self.leaf(value, image, protected, True)
        if type(value) is not list:
            raise ValueError('formula syntax must be a number or array')
        if len(value) == 0:
            return []
        if len(value) == 1:
            return [self.formula(value[0], image, protected + 1)]
        if len(value) == 2:
            return [self.term(value[0], image, protected),
                    self.term(value[1], image, protected)]
        if len(value) == 3:
            return [self.formula(child, image, protected + 2)
                    for child in value]
        raise ValueError('invalid formula constructor arity')

    def fresh(self):
        self.lower -= 1
        return self.lower

    def check(self, goal, context):
        checked = self.formula(goal)
        if checked in context:
            self.rule('hypothesis')
            return True

        instruction = self.stack.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            # An ordinary False result triggers the witness fallback.
            # Exceptions reject the packet, as in the public checker.
            if self.check(major, context):
                if type(major) is not list:
                    raise ValueError('an elimination major must be an array')
                if len(major) == 3:
                    self.rule('paired_elimination')
                    eigen = self.fresh()
                    assumption = self.formula([major[2]], eigen)
                    return self.check(self.formula(goal, [eigen]),
                                      context + [assumption])
                if len(major) == 1:
                    self.rule('closure_elimination')
                    matrix, left, right = major[0], 0, annotation
                elif len(major) == 2:
                    self.rule('equality_transport')
                    matrix, left, right = annotation, major[0], major[1]
                else:
                    raise ValueError('empty major has no elimination rule')
                if self.formula(matrix, right) != goal:
                    return False
                return self.check(self.formula(matrix, left), context)
            self.rule('failed_major_fallthrough')

        if type(instruction) is list and not instruction:
            if type(goal) is not list or len(goal) != 2:
                raise ValueError('computation requires an equation')
            term, right = goal
            if type(term) is not list or len(term) != 3:
                raise ValueError('computation requires an iterator')
            count, seed, update = term
            if ((isinstance(count, (int, float)) and count == 0)
                    or (type(count) is list and not count)):
                expected = seed
                self.rule('computation_zero')
                if type(count) is list:
                    self.rule('empty_zero_counter')
            elif type(count) is list and len(count) == 1:
                smaller = [count[0], seed, update]
                expected = self.term(update, smaller)
                self.rule('computation_successor')
            else:
                raise ValueError('invalid computation counter shape')
            return right == expected

        if type(goal) is not list or len(goal) != 3:
            raise ValueError('primitive introduction requires a paired goal')
        self.rule('paired_introduction')
        matrix = self.formula(goal[2], instruction, 1)
        base = self.formula(matrix, 0)
        if type(matrix) is not list:
            raise ValueError('scalar matrix has no introduction instruction')
        if len(matrix) == 2:
            assumptions = [matrix, base]
            self.rule('equation_induction')
        elif len(matrix) == 0:
            # Both additional assumptions are truth, not a stronger induction
            # principle.  The written proof treats this completion case.
            assumptions = [matrix, base]
            self.rule('empty_truth_introduction')
        else:
            assumptions = [base]
        eigen = self.fresh()
        conclusion = self.formula(matrix, [eigen])
        opened = [self.formula(a, eigen) for a in assumptions]
        return self.check(conclusion, context + opened)

    def run(self, packet):
        self.lower = 0
        self.rules = {}
        self.stack = deepcopy(packet)
        try:
            accepted = bool(self.check(self.stack.pop(), []))
            error = None
        except Exception as exc:
            accepted = False
            error = type(exc).__name__
        return {
            'accepted': accepted,
            'final_k': self.lower,
            'remaining': len(self.stack) if type(self.stack) is list else None,
            'rules': dict(self.rules),
            'error': error,
        }
