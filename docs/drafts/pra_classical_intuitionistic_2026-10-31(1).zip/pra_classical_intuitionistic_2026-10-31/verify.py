#!/usr/bin/env python3
"""Reproduce the supplementary checks in the PRA axiomatization note.

This program is not a proof checker.  It evaluates the displayed primitive
recursive definitions on bounded natural-number inputs, checks complete finite
Boolean tables, and checks ground formulas in the three-world Kripke example.
It does not verify an unbounded induction/constancy schema, a first-order
derivation, or the mathematical equivalence theorem.  Those proofs are in the
accompanying paper.

Only the Python standard library is required.  Run:

    python3 verify.py --output verification.json
"""

from __future__ import annotations

import argparse
import itertools
import json
import platform
from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any, Callable


def primitive_recursion(
    n: int, initial: int, step: Callable[[int, int], int]
) -> int:
    """Evaluate one ordinary primitive recursion with its parameters fixed."""
    if not isinstance(n, int) or n < 0:
        raise ValueError("The recursion argument must be a natural number.")
    value = initial
    for index in range(n):
        value = step(index, value)
    return value


@lru_cache(maxsize=None)
def pred(n: int) -> int:
    """p(0)=0; p(Sn)=n."""
    return primitive_recursion(n, 0, lambda index, value: index)


@lru_cache(maxsize=None)
def zero(n: int) -> int:
    """z(0)=1; z(Sn)=0.  Thus zero is a zero indicator, not constant zero."""
    return primitive_recursion(n, 1, lambda index, value: 0)


@lru_cache(maxsize=None)
def select(n: int, u: int, v: int) -> int:
    """c(0,u,v)=u; c(Sn,u,v)=v."""
    return primitive_recursion(n, u, lambda index, value: v)


@lru_cache(maxsize=None)
def add(x: int, y: int) -> int:
    """0+y=y; Sx+y=S(x+y).  Recursion is in the first argument."""
    return primitive_recursion(x, y, lambda index, value: value + 1)


@lru_cache(maxsize=None)
def alpha(x: int, y: int) -> int:
    """alpha(0,y)=y; alpha(Sx,y)=p(alpha(x,y))."""
    return primitive_recursion(x, y, lambda index, value: pred(value))


@lru_cache(maxsize=None)
def beta(x: int, y: int) -> int:
    """beta(0,y)=0; beta(Sx,y)=c(alpha(x,y),S(beta(x,y)),beta(x,y))."""
    return primitive_recursion(
        x, 0, lambda index, value: select(alpha(index, y), value + 1, value)
    )


def distance(x: int, y: int) -> int:
    return add(alpha(x, y), beta(x, y))


def epsilon(x: int, y: int) -> int:
    """The chosen equality indicator: 1 on equal inputs, 0 otherwise."""
    return zero(distance(x, y))


def normalized_zero(t: int) -> int:
    """Z(t)=c(epsilon(t,0),0,1), the normalized zero test used by the latch."""
    return select(epsilon(t, 0), 0, 1)


@dataclass(frozen=True)
class Term:
    tag: str
    args: tuple[Any, ...] = ()


def variable(name: str) -> Term:
    return Term("variable", (name,))


def constant(value: int) -> Term:
    return Term("constant", (value,))


def term_value(term: Term, values: dict[str, int]) -> int:
    if term.tag == "variable":
        return values[term.args[0]]
    if term.tag == "constant":
        return term.args[0]
    arguments = [term_value(argument, values) for argument in term.args]
    operations = {
        "successor": lambda x: x + 1,
        "pred": pred,
        "add": add,
        "alpha": alpha,
        "beta": beta,
    }
    return operations[term.tag](*arguments)


@dataclass(frozen=True)
class Formula:
    tag: str
    args: tuple[Any, ...] = ()


def equation(left: Term, right: Term) -> Formula:
    return Formula("eq", (left, right))


def logical_value(formula: Formula, values: dict[str, int]) -> bool:
    """Independent ordinary truth evaluation on the standard natural numbers."""
    if formula.tag == "eq":
        left, right = formula.args
        return term_value(left, values) == term_value(right, values)
    if formula.tag == "top":
        return True
    if formula.tag == "bottom":
        return False
    arguments = [logical_value(argument, values) for argument in formula.args]
    if formula.tag == "not":
        return not arguments[0]
    if formula.tag == "and":
        return arguments[0] and arguments[1]
    if formula.tag == "or":
        return arguments[0] or arguments[1]
    if formula.tag == "imp":
        return (not arguments[0]) or arguments[1]
    raise ValueError(f"Unknown formula constructor: {formula.tag}")


def error_code(formula: Formula, values: dict[str, int]) -> int:
    """Evaluate the paper's error compiler; zero means true, any nonzero false.

    The recursion here is on a finite formula syntax tree.  It is not an
    object-language number-induction rule or a universal PR evaluator.
    """
    if formula.tag == "eq":
        left, right = formula.args
        return distance(term_value(left, values), term_value(right, values))
    if formula.tag == "top":
        return 0
    if formula.tag == "bottom":
        return 1
    arguments = [error_code(argument, values) for argument in formula.args]
    if formula.tag == "not":
        return zero(arguments[0])
    if formula.tag == "and":
        return add(arguments[0], arguments[1])
    if formula.tag == "or":
        return select(arguments[0], 0, arguments[1])
    if formula.tag == "imp":
        return select(arguments[0], arguments[1], 0)
    raise ValueError(f"Unknown formula constructor: {formula.tag}")


def boolean_code(formula: Formula, values: dict[str, int]) -> int:
    """Evaluate normalized formula codes; 0 means true and 1 means false."""
    if formula.tag == "eq":
        left, right = formula.args
        return normalized_zero(epsilon(term_value(left, values), term_value(right, values)))
    if formula.tag == "top":
        return 0
    if formula.tag == "bottom":
        return 1
    arguments = [boolean_code(argument, values) for argument in formula.args]
    if formula.tag == "not":
        return normalized_zero(arguments[0])
    if formula.tag == "and":
        return select(arguments[0], arguments[1], 1)
    if formula.tag == "or":
        return select(arguments[0], 0, arguments[1])
    if formula.tag == "imp":
        return select(arguments[0], arguments[1], 0)
    raise ValueError(f"Unknown formula constructor: {formula.tag}")


Pair = tuple[int, int]
WORLD_EXTENSIONS = {
    "root": ("root", "left", "right"),
    "left": ("left",),
    "right": ("right",),
}
PAIR_ZERO: Pair = (0, 0)


def pair_lift(function: Callable[..., int], *arguments: Pair) -> Pair:
    return tuple(function(*(value[index] for value in arguments)) for index in (0, 1))


def pair_successor(value: Pair) -> Pair:
    return value[0] + 1, value[1] + 1


def pair_predecessor(value: Pair) -> Pair:
    return pair_lift(pred, value)


def atom(left: Pair, right: Pair) -> tuple[Any, ...]:
    return "eq", left, right


def neg(formula: tuple[Any, ...]) -> tuple[Any, ...]:
    return "imp", formula, ("bottom",)


def iff(left: tuple[Any, ...], right: tuple[Any, ...]) -> tuple[Any, ...]:
    return "and", ("imp", left, right), ("imp", right, left)


def exclusive_or(left: tuple[Any, ...], right: tuple[Any, ...]) -> tuple[Any, ...]:
    return "and", ("or", left, right), neg(("and", left, right))


def force(world: str, formula: tuple[Any, ...]) -> bool:
    """Force a ground formula in the finite frame with growing congruences.

    Equality compares both coordinates at the root, just the first coordinate
    at the left leaf, and just the second at the right leaf.  This implements
    the equality part of the paper's interpretation; it does not enumerate the
    infinite natural-number domain or verify a universal schema.
    """
    tag = formula[0]
    if tag == "eq":
        left, right = formula[1:]
        if world == "root":
            return left == right
        coordinate = 0 if world == "left" else 1
        return left[coordinate] == right[coordinate]
    if tag == "bottom":
        return False
    if tag == "and":
        return force(world, formula[1]) and force(world, formula[2])
    if tag == "or":
        return force(world, formula[1]) or force(world, formula[2])
    if tag == "imp":
        return all(
            (not force(extension, formula[1])) or force(extension, formula[2])
            for extension in WORLD_EXTENSIONS[world]
        )
    raise ValueError(f"Unknown Kripke formula constructor: {tag}")


def predecessor_classical(value: Pair) -> tuple[Any, ...]:
    return iff(atom(pair_successor(pair_predecessor(value)), value), neg(atom(value, PAIR_ZERO)))


def predecessor_intuitionistic(value: Pair) -> tuple[Any, ...]:
    return exclusive_or(atom(value, PAIR_ZERO), atom(value, pair_successor(pair_predecessor(value))))


def equality_classical(left: Pair, right: Pair) -> tuple[Any, ...]:
    return iff(atom(pair_lift(epsilon, left, right), PAIR_ZERO), neg(atom(left, right)))


def equality_intuitionistic(left: Pair, right: Pair) -> tuple[Any, ...]:
    return exclusive_or(atom(left, right), atom(pair_lift(epsilon, left, right), PAIR_ZERO))


def coverage(value: Pair) -> tuple[Any, ...]:
    return "or", atom(value, PAIR_ZERO), atom(value, pair_successor(pair_predecessor(value)))


class Checks:
    def __init__(self) -> None:
        self.counts: Counter[str] = Counter()

    def check(self, category: str, condition: bool, description: str) -> None:
        if not condition:
            raise AssertionError(f"{category}: {description}")
        self.counts[category] += 1


def check_helpers(checks: Checks, bound: int) -> dict[str, Any]:
    category = "bounded_arithmetic_checks"
    values = range(bound + 1)
    checks.check(category, pred(0) == 0, "p(0)=0")
    checks.check(category, zero(0) == 1, "z(0)=1")
    for x in values:
        checks.check(category, pred(x + 1) == x, "p(Sx)=x")
        checks.check(category, zero(x + 1) == 0, "z(Sx)=0")
        checks.check(category, normalized_zero(x) == zero(x), "normalized zero test")
        checks.check(category, add(x, 0) == x, "right additive identity")
        checks.check(category, alpha(x, x) == 0, "countdown diagonal")
        checks.check(category, beta(x, x) == 0, "overflow diagonal")
        for y in values:
            checks.check(category, select(0, x, y) == x, "conditional base")
            checks.check(category, add(0, y) == y, "addition base")
            checks.check(category, add(x + 1, y) == add(x, y) + 1, "addition recursion")
            checks.check(category, add(x, y + 1) == add(x, y) + 1, "right successor law")
            checks.check(category, (add(x, y) == 0) == (x == 0 and y == 0), "zero-sum law")
            checks.check(category, alpha(0, y) == y, "countdown base")
            checks.check(category, alpha(x + 1, y) == pred(alpha(x, y)), "countdown recursion")
            checks.check(category, beta(0, y) == 0, "overflow base")
            checks.check(
                category,
                beta(x + 1, y) == select(alpha(x, y), beta(x, y) + 1, beta(x, y)),
                "overflow recursion",
            )
            checks.check(category, alpha(x, y) == max(y - x, 0), "independent countdown value")
            checks.check(category, beta(x, y) == max(x - y, 0), "independent overflow value")
            checks.check(category, alpha(x + 1, y + 1) == alpha(x, y), "countdown shift")
            checks.check(category, beta(x + 1, y + 1) == beta(x, y), "overflow shift")
            checks.check(
                category,
                add(x, alpha(x, y)) == add(y, beta(x, y)),
                "countdown invariant",
            )
            checks.check(category, distance(x, y) == abs(x - y), "independent distance value")
            checks.check(category, (distance(x, y) == 0) == (x == y), "zero-distance reflection")
            checks.check(category, epsilon(x, y) == int(x == y), "equality indicator")
            for n in values:
                checks.check(category, select(n + 1, x, y) == y, "conditional successor")
    return {
        "input_range": [0, bound],
        "scope": "Bounded numerical checks; these do not prove the identities for all inputs.",
        "helpers": ["p", "z", "c", "+", "alpha", "beta"],
        "comparator": "d(x,y)=alpha(x,y)+beta(x,y); epsilon(x,y)=z(d(x,y))",
    }


def check_compilers(checks: Checks) -> dict[str, Any]:
    category = "bounded_formula_checks"
    x, y, w = variable("x"), variable("y"), variable("w")
    nil, one = constant(0), constant(1)
    a = equation(x, y)
    b = equation(Term("alpha", (x, y)), nil)
    c = equation(Term("beta", (x, y)), nil)
    formulas = [
        Formula("top"),
        Formula("bottom"),
        a,
        b,
        c,
        Formula("not", (a,)),
        Formula("and", (a, b)),
        Formula("or", (a, b)),
        Formula("imp", (a, b)),
        Formula("imp", (b, a)),
        Formula("or", (equation(x, nil), equation(x, Term("successor", (Term("pred", (x,)),))))),
        Formula("and", (Formula("or", (a, b)), Formula("imp", (b, c)))),
        Formula("not", (Formula("and", (a, Formula("not", (a,)))),)),
        Formula("imp", (equation(Term("add", (x, w)), y), equation(w, one))),
        Formula("or", (Formula("not", (a,)), Formula("and", (b, c)))),
    ]
    for inputs in itertools.product(range(4), repeat=3):
        values = dict(zip(("x", "y", "w"), inputs))
        for formula in formulas:
            truth = logical_value(formula, values)
            error = error_code(formula, values)
            boolean = boolean_code(formula, values)
            checks.check(category, (error == 0) == truth, "error-code reflection")
            checks.check(category, boolean in (0, 1), "normalized code range")
            checks.check(category, (boolean == 0) == truth, "normalized-code reflection")
    return {
        "formulas": len(formulas),
        "variables": ["x", "y", "w"],
        "input_range": [0, 3],
        "assignments_per_formula": 4**3,
        "scope": "Bounded examples of both compilers; structural correctness is proved in the paper.",
    }


def check_boolean_tables(checks: Checks) -> dict[str, Any]:
    category = "complete_boolean_table_checks"
    rows = []
    for u, v in itertools.product((0, 1), repeat=2):
        results = {
            "not_u": normalized_zero(u),
            "and": select(u, v, 1),
            "or": select(u, 0, v),
            "imp": select(u, v, 0),
        }
        expectations = {
            "not_u": int(u == 0),
            "and": int(not (u == 0 and v == 0)),
            "or": int(not (u == 0 or v == 0)),
            "imp": int(not (u != 0 or v == 0)),
        }
        for operation in results:
            checks.check(category, results[operation] == expectations[operation], operation)
        rows.append({"u": u, "v": v, **results})

    # 'r' is an unevaluated formal value, not one bounded numerical sample.
    symbolic_rows = []
    for current, following in ((0, 0), (1, 0), (1, 1)):
        latch = "r" if current == 0 else 0
        next_latch = latch if following == 0 else 0
        checks.check(
            "symbolic_latch_case_checks",
            next_latch == latch,
            "stationarity for an arbitrary accumulator symbol r",
        )
        symbolic_rows.append({
            "b_n": current,
            "b_Sn": following,
            "L_n": latch,
            "L_Sn": next_latch,
        })
    return {
        "orientation": "0 means true; 1 means false",
        "complete_gate_table": rows,
        "stationary_latch": {
            "cases": symbolic_rows,
            "excluded_case": [0, 1],
            "reason_excluded": "The assumed induction step forbids this Boolean transition.",
            "scope": "All three local Boolean cases, keeping the accumulator r arbitrary.",
        },
    }


def check_kripke_example(checks: Checks) -> dict[str, Any]:
    category = "bounded_kripke_ground_checks"
    inputs = list(itertools.product(range(4), repeat=2))
    for world in WORLD_EXTENSIONS:
        for value in inputs:
            checks.check(category, force(world, predecessor_classical(value)), "K_C ground instance")
            expected_k_i = world != "root" or ((value[0] == 0) == (value[1] == 0))
            checks.check(
                category,
                force(world, predecessor_intuitionistic(value)) == expected_k_i,
                "K_I ground instance agrees with coordinate zero-status agreement",
            )
            checks.check(category, force(world, coverage(pair_successor(value))), "successor coverage")
            for other in inputs:
                checks.check(category, force(world, equality_classical(value, other)), "E_C ground instance")
                expected_e_i = world != "root" or ((value[0] == other[0]) == (value[1] == other[1]))
                checks.check(
                    category,
                    force(world, equality_intuitionistic(value, other)) == expected_e_i,
                    "E_I ground instance agrees with coordinate equality-status agreement",
                )

    witness = (0, 1)
    facts = {
        "x_eq_zero": atom(witness, PAIR_ZERO),
        "x_neq_zero": neg(atom(witness, PAIR_ZERO)),
        "coverage": coverage(witness),
        "zero_decidability": ("or", atom(witness, PAIR_ZERO), neg(atom(witness, PAIR_ZERO))),
        "K_C": predecessor_classical(witness),
        "K_I": predecessor_intuitionistic(witness),
        "E_C_x_zero": equality_classical(witness, PAIR_ZERO),
        "E_I_x_zero": equality_intuitionistic(witness, PAIR_ZERO),
    }
    evaluations = {
        world: {name: force(world, formula) for name, formula in facts.items()}
        for world in WORLD_EXTENSIONS
    }
    checks.check("exact_kripke_witness_checks", not evaluations["root"]["coverage"], "coverage fails at root")
    checks.check("exact_kripke_witness_checks", not evaluations["root"]["zero_decidability"], "decidability fails at root")
    checks.check("exact_kripke_witness_checks", force("root", coverage(PAIR_ZERO)), "coverage base")
    checks.check("exact_kripke_witness_checks", force("root", coverage(pair_successor(witness))), "witness successor coverage")
    return {
        "frame": {key: list(value) for key, value in WORLD_EXTENSIONS.items()},
        "equality": {
            "root": "both coordinates agree",
            "left": "first coordinates agree",
            "right": "second coordinates agree",
        },
        "sample_coordinate_range": [0, 3],
        "witness": list(witness),
        "witness_forcing": evaluations,
        "scope": (
            "Exact forcing calculations for the displayed ground witness and bounded ground "
            "instances. The carrier N x N is infinite. This code does not check its universal "
            "constancy or induction schemas; the paper proves the required schema facts analytically."
        ),
    }


def run_checks() -> dict[str, Any]:
    checks = Checks()
    arithmetic = check_helpers(checks, 8)
    formulas = check_compilers(checks)
    tables = check_boolean_tables(checks)
    kripke = check_kripke_example(checks)
    return {
        "artifact": "Supplementary checks for compact classical and intuitionistic PRA",
        "status": "passed",
        "python_version": platform.python_version(),
        "required_dependencies": "Python standard library only",
        "total_assertions": sum(checks.counts.values()),
        "assertion_counts": dict(checks.counts),
        "limitations": [
            "This is not a formal proof or a first-order proof checker.",
            "Bounded arithmetic and formula evaluations are smoke checks only.",
            "Finite Boolean tables and the symbolic latch cases are exhaustive for their stated finite cases.",
            "Ground forcing checks do not verify any infinite-domain axiom schema.",
            "All general equivalence and countermodel claims rely on the accompanying mathematical proofs.",
        ],
        "arithmetic": arithmetic,
        "formula_compilers": formulas,
        "boolean_tables_and_latch": tables,
        "kripke_example": kripke,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path,
        default=Path(__file__).resolve().with_name("verification.json"),
        help="Destination for the reproducible JSON verification report.",
    )
    arguments = parser.parse_args()
    report = run_checks()
    arguments.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": report["status"],
        "total_assertions": report["total_assertions"],
        "assertion_counts": report["assertion_counts"],
        "report": str(arguments.output),
    }, indent=2))


if __name__ == "__main__":
    main()
