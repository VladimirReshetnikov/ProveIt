SMALL AXIOMATIZATIONS OF PRIMITIVE RECURSIVE ARITHMETIC
Classical and intuitionistic logic -- 31 October 2026
Prepared for Vladimir Reshetnikov

MAIN RESULT

In an effective language of primitive-recursive construction descriptions,
take the two defining equations for each primitive recursion, ordinary
first-order equality, and induction only on equations s(n,a)=t(n,a).

The sole additional fixed axiom is:

  Classical:      for all x, S(p(x))=x iff x != 0.

  Intuitionistic: for all x, exactly one of x=0 and x=S(p(x)) holds,
                  where 'exactly one' is the positive formula
                  (A or B) and not (A and B).

Here p is the explicitly defined predecessor, p(0)=0 and p(S(x))=x.
No separate nontriviality or successor axioms are needed. Each kernel is
proved deductively equivalent to first-order PRA in the corresponding logic.

A shared alternative uses only 0 != S(0) beyond the computation equations
and induction with the fixed two-term matrix t(n,a)=0 or t(n,a)=u(n,a).
It works in either logic. The paper proves a precise obstruction to removing
positive disjunction from the intuitionistic induction matrices over this base.

The paper also supplies classical and intuitionistic constancy presentations,
an explicit constructive equality comparator, formula compilers, and two
countermodels. It compares all six provided ProveIt draft archives.

CONTENTS

  pra_classical_intuitionistic.tex   Complete self-contained LaTeX source
  pra_classical_intuitionistic.pdf   Compiled research note
  axioms.txt                        Standalone formal specification
  verify.py                         Supplementary reproducible checks
  verification.json                Recorded check results and their scope
  sources.json                      Source provenance and archive hashes
  validation.txt                    Build, verification, and layout record
  Makefile                          Build and checking commands
  SHA256SUMS                        SHA-256 hashes of the other deliverables

BUILD

Requires Python 3.10+ (standard library only for the supplement), and a
LaTeX installation with amsmath, amssymb, amsthm, mathtools, lmodern,
microtype, geometry, booktabs, array, tabularx, enumitem, tcolorbox,
xcolor, titlesec, fancyhdr, needspace, and hyperref.

  make

Or separately:

  latexmk -pdf -interaction=nonstopmode -halt-on-error pra_classical_intuitionistic.tex
  python3 verify.py --output verification.json

Without latexmk, run pdflatex on the .tex file at least twice until references
settle. No external bibliography tool, network access, or proprietary dependency
is required to build the note.

  sha256sum -c SHA256SUMS

checks the delivered files before rebuilding. A rebuilt PDF can have different
metadata and therefore a different hash without a mathematical content change.

VERIFICATION STATUS

The initial delivered check report contains 6,745 successful assertions:
bounded arithmetic checks, bounded formula examples, complete finite Boolean
tables, three symbolic accumulator cases, bounded Kripke ground-formula checks,
and exact evaluations of the counterexample witness. The report labels these
categories separately. They supplement the paper's mathematical proofs.

The complete equivalence and non-derivability theorems are not formalized in
Lean, Rocq, or another proof assistant. Finite computations do not prove the
infinite induction or constancy schemas. No absolute syntactic minimality or
historical-priority claim is made.

PROVENANCE

The six source archives were obtained from VladimirReshetnikov/ProveIt,
docs/drafts, pinned at commit:

  ffbbfd31452e7188a9e3ba62c81a3bdb64072b82

Exact paths, source URLs, Git blob IDs, and SHA-256 hashes are in sources.json.
Original source archives and third-party publications are not redistributed
inside this package; the complete new deliverable is included.
