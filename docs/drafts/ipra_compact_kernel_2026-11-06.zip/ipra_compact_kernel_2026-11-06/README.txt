A COMPACT COMPLETE AXIOMATIZATION OF iPRA
Prepared for Vladimir Reshetnikov, 6 November 2026
================================================

START HERE
  report.pdf                  Complete self-contained mathematical paper
  report.tex + sections/      Rebuildable LaTeX sources
  checker.py                 Entire trusted proof checker

RESULT
  1,004 significant original-source Python tokens
  1,061 executable AST nodes
  3,335 normalized executable bytes
  3,806 raw UTF-8 source bytes

The current supplied coordinate minima are 1,089 tokens, 1,154 AST nodes,
3,486 normalized bytes, and 3,817 raw bytes. They come from different
programs. This candidate is below every coordinate, including reductions of
85 tokens (7.81%) and 93 AST nodes (8.06%). The entire acceptance program,
all fixed data, syntax checks, substitution, arithmetic schema construction,
error handling, and JSON CLI are counted. Canonical-source token counts are
reported separately and are not mixed with original-source counts.

THEORY
The proposed calculus S has native finite initialized-recursion terms;
equations, genuine falsity, and the binders Pi=forall(implication) and
Sigma=exists(conjunction); six logical inference patterns; two recursion
computation schemas; two fixed falsity conversions; and one numerical axiom
schema. The latter supplies equation induction and number cases for other
formulas. It does not supply unrestricted induction.

The paper includes every logical and nonlogical axiom/rule, full recovery of
intuitionistic logic, an explicit equality test and quantifier-free induction
reconstruction, and both interpretations with internal round trips. Both
interpretation domains are the whole number carrier; genuine falsity is
preserved. The reference iPRA is explicitly full first-order intuitionistic
arithmetic with all fixed finite primitive-recursive descriptions and
quantifier-free induction.

WHAT IS NEW
This is a synthesis of compatible reductions in the six current repository
drafts. It combines shared elimination, fresh-witness-equation existential
introduction, a curried numerical axiom, a zero sentinel, direct JSON lists,
and stored-formula hypothesis lookup. The common arithmetic theory and
interpretation strategy are inherited and credited. Genuine falsity and all
explicit validators are retained. No positive-reduct semantic qualification
is needed for the main result, and no proof generator is trusted.

CURRENT COMPARISON
  Repository: VladimirReshetnikov/ProveIt
  Commit: 39c2b3c738e4cacbc0b2cb31f093c1eb4f976e75
  Directory: docs/drafts
  Six current ZIP archives; original bytes verified against Git blob hashes
  216 source-group records, 74 distinct content groups, 81 exact source files

The six draft headlines themselves compare to the older eleven-draft snapshot
b079e5787b1d708049ff0643ce1b534c1a225198. This deliverable instead compares
them to one another and to their supplied alternatives. It does not reuse
the obsolete 1,167-token threshold. Comparison scripts execute no comparator
code. Exact sources and provenance are in comparison/.

RUN (Python 3.10+, standard library only)
  python3 checker.py certificates/legacy_reflexivity_derived.json
  python3 verify.py
  python3 independent_audit.py
  python3 measure.py

BUILD (also requires pdflatex and packages listed in report.tex)
  python3 build.py

The build regenerates tests, measurements, PDF, and an integrity manifest.
build/ contains intermediate TeX output and is omitted from the ZIP.
An unchanged validated build can use --skip-tests; --package-only updates the
ZIP and SHA256SUMS without compiling. PDF metadata can vary between builds.

PROOF TRANSLATION
  python3 translate.py forward source_certificates/legacy_reflexivity_derived.json out.json
  python3 translate.py backward out.json restored.json

All compiler inputs and outputs are checked by the appropriate complete
checkers. Translation proceeds through the unchanged universal-kernel
reference format. Neither compiler is an acceptance dependency.

VALIDATION
The primary suite checks 53 original proofs forward/backward, 106 additional
Sigma-wrapped proofs, 9 direct native examples, 37 invalid certificates,
6 independently specified substitution cases, and 4 CLI cases including -O.
The independent suite passes 53 handwritten certificate checks (21 accepted,
32 rejected), 11 binding/type/stored-object checks, and 8 CLI checks. It uses
no proof builders or translators to generate expected formulas.
The universal mathematical proofs are written proofs, not a Lean or Rocq
formalization. Finite tests do not prove the metatheorems by themselves.

LIMITS
No absolute shortest-program theorem is claimed. The request's unspecified
language/encoding metric is made concrete by a consistent Python source
comparison. The result improves the observed envelope of supplied complete
implementations. Resource limits can reject exceptionally large valid proof
trees; the formal completeness proof concerns the unbounded algorithm.

CONTENTS
  checker.py                  Sole trusted acceptance program
  translate.py, to_universal.py  Untrusted general bidirectional proof compilers
  baseline.py, universal.py    Unchanged reference checkers
  source_certificates/        Exact inherited proof fixtures
  certificate_provenance.json  Original archive members and fixture hashes
  certificates/              Translated and new accepted proofs
  controls/                  Matched one-change source variants
  comparison/                Exact source census and offline remeasurement
  verify.py, independent_audit.py  Finite validation suites
  metrics.json, test_results.json, independent_results.json
  kernel_provenance.json      Detailed source attribution and hashes
  SHA256SUMS.txt              Integrity hashes of deliverable files

See README_KERNEL.txt for the exact certificate format and boundary details.
