"""Untrusted proof compiler; checker.py imports none of this module.

First use the credited universal-schema compiler, then translate its proof
to shared elimination and witness-equation introduction. Every source and
destination certificate is checked. This is not part of source-size counts.
"""

import json
import sys
from pathlib import Path

import checker as k
import universal as u
import to_universal as first


def syntax(a):
    return [syntax(b) for b in a] if type(a) in (list, tuple) else a


def insert(a, protected=0):
    return k.walk(a, lambda i, d: i + d + 1, protected)


def refl(t):
    p = ["rec", ["r", k.ZERO, t, k.ZERO]]
    return ["use", p, ["=", 0, k.shift(t)], p]


def symmetry(p, left):
    return ["use", p, ["=", 0, k.shift(left)], refl(left)]


def lift(p, g, protected=0):
    """Insert one fresh ambient number; formula hypotheses need no indices."""
    def syn(a, extra=0):
        return insert(a, protected + extra)

    def sub(q):
        return lift(q, g, protected)

    match p:
        case ["hyp", a]:
            return ["hyp", syn(a)]
        case ["rec", a]:
            return ["rec", syn(a)]
        case ["nat", a]:
            return ["nat", syn(a, 1)]
        case ["bridge", q]:
            return ["bridge", sub(q)]
        case ["pi", a, q]:
            h = [*map(k.shift, g), a]
            return ["pi", syn(a, 1), lift(q, h, protected + 1)]
        case ["pair", t, p, q]:
            h = [*map(k.shift, g), ["=", 0, k.shift(t)]]
            return ["pair", syn(t), lift(p, h, protected + 1),
                    lift(q, h, protected + 1)]
        case ["use", p, a, q]:
            e = k.infer(p, g)
            if e[0] == "sig":
                h = [*map(k.shift, g), *e[1:]]
                return ["use", sub(p), syn(a), lift(q, h, protected + 1)]
            return ["use", sub(p), syn(a, e[0] == "="), sub(q)]
        case _:
            raise ValueError("unknown candidate proof")


def ordinary_pair(a, t, p, q, g):
    """Expand ordinary Sigma introduction using y=t and equality transport."""
    witness_equation = ["=", 0, k.shift(t)]
    backward = symmetry(["hyp", witness_equation], 0)

    def branch(matrix, premise):
        return ["use", backward, insert(matrix, 1), lift(premise, g)]

    return ["pair", t, branch(a[1], p), branch(a[2], q)]


def compile_proof(p, g):
    def sub(q):
        return compile_proof(q, g)

    match p:
        case ("hyp", i):
            return ["hyp", syntax(g[i])]
        case ("rec", a):
            return ["rec", syntax(a)]
        case ("nat", a):
            return ["nat", syntax(a)]
        case ("bridge", q):
            return ["bridge", sub(q)]
        case ("pi", a, q):
            return ["pi", syntax(a), compile_proof(q, (*map(u.shift, g), a))]
        case (("app" | "eq"), p, a, q):
            return ["use", sub(p), syntax(a), sub(q)]
        case ("let", p, a, q):
            e = u.infer(p, g)
            return ["use", sub(p), syntax(a),
                    compile_proof(q, (*map(u.shift, g), *e[1:]))]
        case ("pair", a, t, p, q):
            return ordinary_pair(syntax(a), syntax(t), sub(p), sub(q), syntax(g))
        case _:
            raise ValueError("unknown universal proof")


def universal_forward(document):
    u.check(document)
    g = tuple(map(u.freeze, document["assumptions"]))
    result = {"assumptions": syntax(g), "goal": syntax(document["goal"]),
              "proof": compile_proof(u.freeze(document["proof"]), g)}
    k.check(result)
    return result


def forward(document):
    return universal_forward(first.forward(document))



def u_refl(t):
    p = ("rec", ("r", u.ZERO, t, u.ZERO))
    return ("eq", p, ("=", 0, u.shift(t)), p)


def substitute_universal(p, sg, tg, env, indices):
    """Substitution plus a proved discharge of the selected reflexive hypothesis.

    A None index represents an equality hypothesis whose substituted sides
    coincide. Its use is replaced by a derived reflexivity proof, never an
    unchecked axiom. Local number and assumption binders are both respected.
    """
    lifted = lambda i: 0 if i == 0 else u.shift(env(i - 1))
    syn = lambda a: u.subst(a, env)
    matrix = lambda a: u.subst(a, lifted)
    sub = lambda q: substitute_universal(q, sg, tg, env, indices)
    match p:
        case ("hyp", i):
            if indices[i] is None:
                equation = syn(sg[i])
                if equation[0] != "=" or equation[1] != equation[2]:
                    raise ValueError("discharged assumption is not reflexive")
                return u_refl(equation[1])
            return ("hyp", indices[i])
        case ("rec", r):
            return ("rec", syn(r))
        case ("nat", a):
            return ("nat", matrix(a))
        case ("bridge", q):
            return ("bridge", sub(q))
        case ("pi", a, q):
            b = matrix(a)
            return ("pi", b, substitute_universal(q, (*map(u.shift, sg), a),
                    (*map(u.shift, tg), b), lifted, (*indices, len(tg))))
        case ("app", p, t, q):
            return ("app", sub(p), syn(t), sub(q))
        case ("eq", p, a, q):
            return ("eq", sub(p), matrix(a), sub(q))
        case ("pair", a, t, p, q):
            return ("pair", syn(a), syn(t), sub(p), sub(q))
        case ("let", p, c, q):
            e = u.infer(p, sg)
            return ("let", sub(p), syn(c), substitute_universal(q,
                (*map(u.shift, sg), *e[1:]),
                (*map(u.shift, tg), *(matrix(b) for b in e[1:])),
                lifted, (*indices, len(tg), len(tg) + 1)))
        case _:
            raise ValueError("unknown universal proof for substitution")


def decompile_proof(p, g):
    sub = lambda q: decompile_proof(q, g)
    syn = u.freeze
    match p:
        case ["hyp", a]:
            return ("hyp", g.index(a))
        case ["rec", a]:
            return ("rec", syn(a))
        case ["nat", a]:
            return ("nat", syn(a))
        case ["bridge", q]:
            return ("bridge", sub(q))
        case ["pi", a, q]:
            h = [*map(k.shift, g), a]
            return ("pi", syn(a), decompile_proof(q, h))
        case ["use", p, a, q]:
            e = k.infer(p, g)
            if e[0] == "sig":
                h = [*map(k.shift, g), *e[1:]]
                return ("let", sub(p), syn(a), decompile_proof(q, h))
            return ("eq" if e[0] == "=" else "app", sub(p), syn(a), sub(q))
        case ["pair", t, p, q]:
            h = [*map(k.shift, g), ["=", 0, k.shift(t)]]
            a = ["sig", k.infer(p, h), k.infer(q, h)]
            sg, tg, witness = syn(h), syn(g), syn(t)
            env = lambda i: witness if i == 0 else i - 1
            indices = (*range(len(g)), None)
            lp = substitute_universal(decompile_proof(p, h), sg, tg, env, indices)
            rq = substitute_universal(decompile_proof(q, h), sg, tg, env, indices)
            return ("pair", syn(a), witness, lp, rq)
        case _:
            raise ValueError("unknown candidate proof")


def universal_backward(document):
    k.check(document)
    g = document["assumptions"]
    result = {"assumptions": g, "goal": document["goal"],
              "proof": decompile_proof(document["proof"], g)}
    u.check(result)
    return result


def backward(document):
    return first.backward(universal_backward(document))


if __name__ == "__main__":
    if len(sys.argv) != 4 or sys.argv[1] not in ("forward", "backward"):
        raise SystemExit("usage: translate.py forward|backward INPUT.json OUTPUT.json")
    operation = forward if sys.argv[1] == "forward" else backward
    result = operation(json.loads(Path(sys.argv[2]).read_text()))
    Path(sys.argv[3]).write_text(json.dumps(result, separators=(",", ":")) + "\n")
