"""Independent boundary audit for the inferred-existential iPRA checker.

The oracle uses fresh named variables, explicit syntax cases, and simultaneous
replacement of free names.  It does not import the candidate's scope table or
use candidate substitution to compute any expected result.  This is a finite
test suite and an audit aid, not a formal proof of kernel soundness.

Usage: python3 audit.py path/to/checker.py [path/to/results.json]
"""

import copy
import hashlib
import importlib.util
import inspect
import json
import random
import sys
import types
from pathlib import Path


ZERO = -1
TT = ["=", ZERO, ZERO]
XX = ["=", 0, 0]
EX = ["ex", XX]
REJECTIONS = (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError)


class BadSyntax(Exception):
    pass


class ForbiddenName(Exception):
    pass


class Names:
    def __init__(self):
        self.next = 0

    def fresh(self):
        self.next += 1
        return ("bound", self.next)


def decode(a, formula, names, stack=()):
    """Read indices into globally fresh binder names and free-name identifiers."""
    if not formula and type(a) is int and a >= ZERO:
        if a == ZERO:
            return ("zero",)
        return ("var", stack[a] if a < len(stack) else ("free", a - len(stack)))
    if type(a) is not list:
        raise BadSyntax
    if not formula:
        if len(a) == 2 and a[0] == "s":
            return ("succ", decode(a[1], False, names, stack))
        if len(a) == 4 and a[0] == "r":
            previous, counter = names.fresh(), names.fresh()
            return ("rec", decode(a[1], False, names, stack),
                    decode(a[2], False, names, stack), previous, counter,
                    decode(a[3], False, names, (previous, counter, *stack)))
    elif len(a) == 3 and a[0] == "=":
        return ("equal", decode(a[1], False, names, stack),
                decode(a[2], False, names, stack))
    elif len(a) == 3 and a[0] == "pi":
        variable = names.fresh()
        return ("guarded", variable,
                decode(a[1], True, names, (variable, *stack)),
                decode(a[2], True, names, (variable, *stack)))
    elif len(a) == 2 and a[0] == "ex":
        variable = names.fresh()
        return ("exists", variable, decode(a[1], True, names, (variable, *stack)))
    raise BadSyntax


def rename_free(a, replacements, delta):
    head = a[0]
    if head == "zero":
        return a
    if head == "var":
        name = a[1]
        if name[0] != "free":
            return a
        index = name[1]
        if index >= len(replacements):
            return ("var", ("free", index + delta))
        answer = replacements[index]
        if answer is None:
            raise ForbiddenName
        return answer
    if head == "succ":
        return (head, rename_free(a[1], replacements, delta))
    if head == "rec":
        return (head, rename_free(a[1], replacements, delta),
                rename_free(a[2], replacements, delta), a[3], a[4],
                rename_free(a[5], replacements, delta))
    if head == "equal":
        return (head, rename_free(a[1], replacements, delta),
                rename_free(a[2], replacements, delta))
    if head == "guarded":
        return (head, a[1], rename_free(a[2], replacements, delta),
                rename_free(a[3], replacements, delta))
    if head == "exists":
        return (head, a[1], rename_free(a[2], replacements, delta))
    raise AssertionError(head)


def encode(a, stack=()):
    head = a[0]
    if head == "zero":
        return ZERO
    if head == "var":
        if a[1][0] == "free":
            return a[1][1] + len(stack)
        return stack.index(a[1])
    if head == "succ":
        return ["s", encode(a[1], stack)]
    if head == "rec":
        return ["r", encode(a[1], stack), encode(a[2], stack),
                encode(a[5], (a[3], a[4], *stack))]
    if head == "equal":
        return ["=", encode(a[1], stack), encode(a[2], stack)]
    if head == "guarded":
        return ["pi", encode(a[2], (a[1], *stack)), encode(a[3], (a[1], *stack))]
    if head == "exists":
        return ["ex", encode(a[2], (a[1], *stack))]
    raise AssertionError(head)


def oracle(a, env=(1,), depth=0, formula=True):
    names = Names()
    surrounding = tuple(names.fresh() for _ in range(depth))
    named = decode(a, formula, names, surrounding)
    values = [None if t is None else decode(t, False, names) for t in env[:-1]]
    return encode(rename_free(named, values, env[-1]), surrounding)


def outcome(function):
    try:
        return True, function()
    except (*REJECTIONS, BadSyntax, ForbiddenName):
        return False, None


def generate_term(rng, depth, bound):
    choice = rng.randrange(4) if depth else rng.randrange(2)
    if choice == 0:
        return ZERO
    if choice == 1:
        return rng.randrange(bound + 4)
    if choice == 2:
        return ["s", generate_term(rng, depth - 1, bound)]
    return ["r", generate_term(rng, depth - 1, bound),
            generate_term(rng, depth - 1, bound),
            generate_term(rng, depth - 1, bound + 2)]


def generate_formula(rng, depth, bound):
    choice = rng.randrange(3) if depth else 0
    if choice == 0:
        return ["=", generate_term(rng, min(depth, 3), bound),
                generate_term(rng, min(depth, 3), bound)]
    if choice == 1:
        return ["pi", generate_formula(rng, depth - 1, bound + 1),
                generate_formula(rng, depth - 1, bound + 1)]
    return ["ex", generate_formula(rng, depth - 1, bound + 1)]


def substitution_corpus():
    rng = random.Random(20261106)
    trees = []
    for depth in range(4):
        for _ in range(12):
            trees.append((generate_formula(rng, 4, depth), depth, True))
            trees.append((generate_term(rng, 4, depth), depth, False))
    # Explicitly distinguish the removed slot from both recursor-local slots,
    # including below two ordinary binders and in an unused update body.
    for slot in range(8):
        trees.append((["pi", TT, ["ex", ["=", ["r", ZERO, ZERO, slot], ZERO]]], 0, True))
    environments = [(1,), (3,), [ZERO, 0], [["s", 0], 0],
                    [["r", 0, 1, ["s", 0]], 0, -2], [None, -1]]
    return [(tree, env, depth, formula)
            for tree, depth, formula in trees for env in environments]


def check_call(kernel, data):
    if len(inspect.signature(kernel.check).parameters) == 1:
        return kernel.check(data)
    return kernel.check(*data)


def direct_cases(shared=False):
    rows = []

    def add(name, data, expected):
        rows.append((name, data, expected))

    # A valid TT assumption makes each vacuous-witness control sensitive to
    # removing the validation being tested.
    invalid_terms = [True, 0.0, None, -2, "s", "s0", {}, {"s": 0},
                     ["s", TT], ["r", ZERO, ZERO, TT], ["s", ZERO, ZERO]]
    forall_tt = ["pi", TT, TT]
    add("vacuous_pack_control", [[TT], ["ex", TT], ["pack", ZERO, TT]], True)
    add("vacuous_universal_control", [[TT, forall_tt], TT, ["use", forall_tt, ZERO, TT]], True)
    for index, bad in enumerate(invalid_terms):
        add(f"ignored_pack_witness_{index}", [[TT], ["ex", TT], ["pack", bad, TT]], False)
        add(f"ignored_universal_witness_{index}",
            [[TT, forall_tt], TT, ["use", forall_tt, bad, TT]], False)
        rec = ["r", ZERO, ZERO, bad]
        add(f"unused_update_vacuous_transport_{index}",
            [[TT], TT, ["use", rec, TT, TT]], False)
    valid_rec = ["r", ZERO, ZERO, 0]
    add("unused_update_control", [[TT], TT, ["use", valid_rec, TT, TT]], True)
    for index, counter in enumerate([0, 2, ["r", ZERO, ZERO, 0]]):
        rec = ["r", counter, ZERO, 0]
        add(f"nonliteral_counter_vacuous_transport_{index}",
            [[TT], TT, ["use", rec, TT, TT]], False)

    # Every generated elimination uses its actual opened existential body as
    # minor proof. Thus rejection isolates forbidden-name deletion.
    rng = random.Random(60112026)
    matrices = [XX, TT]
    matrices += [["pi", TT, ["ex", ["=", ["r", ZERO, ZERO, n], ZERO]]]
                 for n in range(8)]
    matrices += [generate_formula(rng, 3, 0) for _ in range(24)]
    for index, matrix in enumerate(matrices):
        valid, projection = outcome(lambda: oracle(matrix, [None, -1]))
        # A substituted-zero target makes the simplest escape mutation accept.
        if not valid:
            projection = oracle(matrix, [ZERO, -1])
        exists = ["ex", matrix]
        add(f"existential_projection_{index}", [[exists], projection, ["use", exists, matrix]], valid)

    # A retained context depends on an outer free parameter. It must lift on
    # entry and return to exactly the original parameter on exit.
    for index, retained in enumerate([
        ["=", 0, ["s", ZERO]],
        ["pi", ["=", 0, 1], ["ex", ["=", 2, ["r", ZERO, ZERO, 4]]]],
        ["=", ["r", 0, 1, ["r", 2, 3, 5]], 0],
    ]):
        lifted = oracle(retained)
        add(f"retained_parameter_{index}",
            [[retained, EX, retained], retained, ["use", EX, lifted]], True)
        add(f"unlifted_retained_parameter_{index}",
            [[retained, EX], retained, ["use", EX, retained]], False)

    # The numerical rule may receive an equation induction step, but a Pi- or
    # E-headed invariant must receive a step guarded by the BASE formula.
    templates = [["=", 0, 1], ["ex", ["=", 1, 2]],
                 ["pi", TT, ["=", 1, 2]],
                 ["ex", ["pi", ["=", 0, 1], ["=", 2, 3]]]]
    retained = ["=", 0, ["s", ZERO]]
    for index, a in enumerate(templates):
        base = oracle(a, [ZERO, 0])
        successor = oracle(a, [["s", 0], 0])
        guard = a if a[0] == "=" else base
        step = ["pi", guard, successor]
        p = ["use", oracle(step), 0, guard] if shared else step
        add(f"numerical_guard_control_{index}",
            [[retained, step], ["pi", base, a], ["nat", a, p]], True)
        if a[0] != "=":
            strong_step = ["pi", a, successor]
            bad_p = ["use", oracle(strong_step), 0, a] if shared else strong_step
            add(f"quantified_induction_rejected_{index}",
                [[retained, strong_step], ["pi", base, a], ["nat", a, bad_p]], False)

    # Formula positions must stay canonical. Only lookup proof leaves permit
    # Python equality aliases, and lookup returns a validated stored formula.
    one = ["=", 1, 1]
    for kind, alias in [("bool", ["=", True, True]), ("float", ["=", 1.0, 1.0])]:
        add(f"canonical_lookup_{kind}", [[one], one, alias], True)
        add(f"noncanonical_goal_{kind}", [[one], alias, one], False)
        add(f"noncanonical_context_{kind}", [[alias], one, one], False)
    for index, malformed in enumerate([
        ["use", EX], ["use", EX, TT, TT], ["use", EX, TT, TT, TT],
        ["lam", TT], ["pack", ZERO], ["nat", XX], ["r", ZERO, ZERO],
        ["use", forall_tt, ZERO], ["use", forall_tt, ZERO, TT, TT],
    ]):
        add(f"proof_arity_{index}", [[EX, forall_tt, TT], TT, malformed], False)
    return rows


def audit_substitution(kernel, corpus):
    rows = []
    for i, (a, env, depth, formula) in enumerate(corpus):
        wanted = outcome(lambda: oracle(a, env, depth, formula))
        got = outcome(lambda: kernel.subst(copy.deepcopy(a), copy.deepcopy(env), depth, formula))
        rows.append({"case": i, "operation": "erase" if env[0] is None else "substitute",
                     "formula": formula, "ambient_depth": depth,
                     "oracle_accepts": wanted[0], "passed": got == wanted})
        if got != wanted:
            rows[-1].update(input=a, environment=env, expected=wanted, actual=got)
    return rows


def audit_certificates(kernel, cases):
    rows = []
    for name, data, expected in cases:
        got = outcome(lambda: check_call(kernel, copy.deepcopy(data)))[0]
        rows.append({"name": name, "expected_accepts": expected,
                     "actual_accepts": got, "passed": got == expected,
                     "certificate": data})
    return rows


def mutation_sensitivity(source, cases, corpus):
    controls = [
        ("erase_replaces_witness_by_zero", "[None, -1]", "[-1, -1]"),
        ("skip_unused_recursor_validation", "            subst(r, formula=False)\n", ""),
        ("skip_unused_universal_witness_validation", "            subst(a, formula=tag != \"pi\")\n", "            if tag != \"pi\": subst(a)\n"),
        ("quantified_induction_hypothesis", "h = a if a[0] == \"=\" else base", "h = a"),
        ("fail_to_lift_retained_context", "[*map(subst, g), *parts]", "[*g, *parts]"),
        ("recursor_binds_one_slot", '"r": (0, 0, 2)', '"r": (0, 0, 0)'),
    ]
    rows = []
    for name, before, after in controls:
        if before not in source:
            rows.append({"name": name, "applicable": False})
            continue
        mutant = types.ModuleType(name)
        exec(compile(source.replace(before, after), "<audit mutation>", "exec"), mutant.__dict__)
        direct = [r["name"] for r in audit_certificates(mutant, cases) if not r["passed"]]
        substitutions = sum(not r["passed"] for r in audit_substitution(mutant, corpus))
        rows.append({"name": name, "applicable": True, "detected": bool(direct or substitutions),
                     "certificate_failures": direct, "oracle_disagreements": substitutions})
    return rows


def main():
    path = Path(sys.argv[1]).resolve()
    destination = Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else Path(__file__).with_name("results.json")
    source = path.read_text()
    spec = importlib.util.spec_from_file_location("audited_checker", path)
    kernel = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(kernel)
    shared = '("lam" | "pack" | "nat")' in source
    corpus = substitution_corpus()
    cases = direct_cases(shared)
    subrows = audit_substitution(kernel, corpus)
    certrows = audit_certificates(kernel, cases)
    mutation_rows = mutation_sensitivity(source, cases, corpus)
    one = ["=", 1, 1]
    canonical_object = kernel.infer(["=", True, True], [one]) is one
    summary = {
        "checker_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "oracle": "Fresh named variables; explicit independent constructors; free-name simultaneous replacement.",
        "substitution_cases": len(subrows),
        "substitution_passed": sum(r["passed"] for r in subrows),
        "erasure_cases": sum(r["operation"] == "erase" for r in subrows),
        "erasure_rejections_expected": sum(r["operation"] == "erase" and not r["oracle_accepts"] for r in subrows),
        "certificate_cases": len(certrows),
        "certificate_passed": sum(r["passed"] for r in certrows),
        "positive_certificates": sum(r["expected_accepts"] for r in certrows),
        "negative_certificates": sum(not r["expected_accepts"] for r in certrows),
        "lookup_returns_stored_object": canonical_object,
        "applicable_mutations": sum(r["applicable"] for r in mutation_rows),
        "detected_mutations": sum(r.get("detected", False) for r in mutation_rows),
        "shared_numerical_introduction": shared,
        "qualification": "Finite targeted tests plus independent oracle, not formal verification or a proof of global minimality.",
    }
    result = {"summary": summary, "substitution_cases": subrows,
              "certificates": certrows, "mutation_controls": mutation_rows}
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
    if any(not r["passed"] for r in [*subrows, *certrows]) or not canonical_object:
        raise AssertionError("Independent audit failed; inspect results JSON")
    if any(r["applicable"] and not r["detected"] for r in mutation_rows):
        raise AssertionError("Mutation control escaped detection")


if __name__ == "__main__":
    main()
