"""Verify all frozen positive translations and their sequent-preserving reverses."""
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('proof_translation', ROOT / 'proof_tools/translate.py')
translation = importlib.util.module_from_spec(spec)
spec.loader.exec_module(translation)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def run():
    manifest = json.loads((ROOT / 'validation/translation_manifest.json').read_text())
    records = []
    for row in manifest['records']:
        old_bytes = (ROOT / row['original']).read_bytes()
        new_bytes = (ROOT / row['translated']).read_bytes()
        if digest(old_bytes) != row['original_sha256'] or digest(new_bytes) != row['translated_sha256']:
            raise ValueError('Frozen fixture changed: ' + row['name'])
        old = json.loads(old_bytes)
        supplied = json.loads(new_bytes)
        new = translation.translate(old)
        if new != supplied:
            raise ValueError('Forward translation changed: ' + row['name'])
        returned = translation.translate(new, reverse=True)
        if returned[:2] != old[:2] or new[:2] != old[:2]:
            raise ValueError('Translation changed sequent: ' + row['name'])
        sequent_hash = digest(json.dumps(old[:2], separators=(',', ':')).encode())
        if sequent_hash != row['sequent_sha256']:
            raise ValueError('Sequent hash changed: ' + row['name'])
        records.append({'name': row['name'], 'forward_checked': True,
                        'reverse_checked': True, 'sequent_preserved': True})
    result = {'status': 'passed', 'positive_certificates': len(records),
              'forward_checks': len(records), 'reverse_checks': len(records),
              'records': records,
              'qualification': 'Finite implementation evidence, not a formal proof of the metatheorems. This corpus contains accepted inputs only; direct/adversarial audits cover rejections.'}
    destination = ROOT / 'results/translation_replay.json'
    destination.parent.mkdir(exist_ok=True)
    destination.write_text(json.dumps(result, indent=2) + '\n')
    return result


if __name__ == '__main__':
    result = run()
    print(json.dumps({key: value for key, value in result.items() if key != 'records'}, indent=2))
