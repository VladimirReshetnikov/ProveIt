"""Independent fixed cases for numerical-scope deletion and total input validation."""
import argparse
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('checker', type=Path, nargs='?', default=ROOT / 'checker.py')
args = parser.parse_args()
spec = importlib.util.spec_from_file_location('candidate', args.checker)
kernel = importlib.util.module_from_spec(spec)
spec.loader.exec_module(kernel)

ZERO = -1
TT = ['=', ZERO, ZERO]
XX = ['=', 0, 0]
EX = ['ex', XX]
rows = []


def case(name, data, wanted):
    try:
        result = bool(kernel.check(*data))
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        result = False
    if result != wanted:
        raise AssertionError((name, wanted, result, data))
    rows.append({'name': name, 'expected': wanted, 'passed': True, 'certificate': data})


case('ex_elimination_closed_result', [[EX, TT], TT, ['use', EX, TT]], True)
case('ex_elimination_direct_witness_escape', [[EX], TT, ['use', EX, XX]], False)
case('ex_elimination_too_many_fields', [[EX, TT], TT, ['use', EX, TT, TT]], False)
case('ex_elimination_missing_minor', [[EX, TT], TT, ['use', EX]], False)

# A local number under Pi is independent of the eliminated witness.
local_pi = ['pi', XX, XX]
local_ex = ['ex', local_pi]
case('ex_keeps_nested_local_binder', [[local_ex], local_pi, ['use', local_ex, local_pi]], True)
escaping_pi = ['pi', TT, ['=', 1, 1]]
escaping_ex = ['ex', escaping_pi]
case('ex_rejects_witness_under_pi', [[escaping_ex], local_pi, ['use', escaping_ex, escaping_pi]], False)

# Recursor update has two local binders. Neither may be mistaken for witness.
local_r = ['r', ZERO, ZERO, ['s', 0]]
local_eq = ['=', local_r, local_r]
local_rex = ['ex', local_eq]
case('ex_keeps_recursion_local_slots', [[local_rex], local_eq, ['use', local_rex, local_eq]], True)
escape_r = ['r', ZERO, ZERO, 2]
escape_req = ['=', escape_r, escape_r]
escape_rex = ['ex', escape_req]
case('ex_rejects_witness_under_recursor', [[escape_rex], local_eq, ['use', escape_rex, escape_req]], False)

# Free parameter one becomes free parameter zero when the scope is removed.
parameter_eq = ['=', 1, 1]
parameter_ex = ['ex', parameter_eq]
case('ex_decrements_free_parameter', [[parameter_ex], XX, ['use', parameter_ex, parameter_eq]], True)

r0 = ['r', ZERO, ZERO, 0]
rs = ['r', ['s', ZERO], ZERO, 0]
case('rec_zero', [[], ['=', r0, ZERO], r0], True)
case('rec_successor', [[], ['=', rs, r0], rs], True)
for counter in [0, 1, ['r', ZERO, ZERO, 0]]:
    r = ['r', counter, ZERO, 0]
    case('rec_rejects_nonconstructor_' + str(len(rows)), [[], ['=', r, ZERO], r], False)

# Unused arguments and matrices still have their intended sorts checked.
for bad in [True, 0.0, None, -2, ['=', ZERO, ZERO], ['s'], ['s', ZERO, ZERO], {'s': ZERO}]:
    r = ['r', ZERO, ZERO, bad]
    case('rec_validates_unused_update_' + str(len(rows)), [[TT], TT, ['use', r, TT, TT]], False)
    case('pack_validates_witness_' + str(len(rows)), [[TT], ['ex', TT], ['pack', bad, TT]], False)

case('formula_goal_bool_rejected', [[['=', 1, 1]], ['=', True, True], ['=', 1, 1]], False)
case('formula_context_bool_rejected', [[['=', True, True]], ['=', 1, 1], ['=', 1, 1]], False)
case('lookup_bool_alias_returns_stored_formula', [[['=', 1, 1]], ['=', 1, 1], ['=', True, True]], True)
case('lookup_float_alias_returns_stored_formula', [[XX], XX, ['=', 0.0, 0.0]], True)

result = {'cases': len(rows), 'positive': sum(row['expected'] for row in rows), 'negative': sum(not row['expected'] for row in rows), 'rows': rows}
(ROOT / 'results').mkdir(exist_ok=True)
(ROOT / 'results/direct_audit.json').write_text(json.dumps(result, indent=2) + '\n')
print({key: value for key, value in result.items() if key != 'rows'})
