"""Reproduce complete-program ablation metrics without executing measured sources."""
import ast
import copy
import hashlib
import io
import json
import platform
from pathlib import Path
import tokenize

ROOT = Path(__file__).resolve().parents[1]
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}


def docstrings(tree):
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and node.body:
            first = node.body[0]
            if isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant) and isinstance(first.value.value, str):
                yield first


def measure(path):
    data = path.read_bytes()
    source = data.decode('utf-8')
    parsed = ast.parse(source, filename=str(path))
    stripped = copy.deepcopy(parsed)
    identities = {id(node) for node in docstrings(stripped)}
    for node in ast.walk(stripped):
        if hasattr(node, 'body') and isinstance(node.body, list):
            node.body = [child for child in node.body if id(child) not in identities]
    ranges = [((node.lineno, node.col_offset), (node.end_lineno, node.end_col_offset))
              for node in docstrings(parsed)]
    source_tokens = sum(token.type not in IGNORED and not any(start <= token.start and token.end <= end for start, end in ranges)
                        for token in tokenize.generate_tokens(io.StringIO(source).readline))
    normalized = ast.unparse(stripped) + '\n'
    normalized_tokens = sum(token.type not in IGNORED for token in tokenize.generate_tokens(io.StringIO(normalized).readline))
    return {'path': str(path.relative_to(ROOT)),
            'sha256': hashlib.sha256(data).hexdigest(),
            'source_bytes': len(data),
            'ast_nodes': sum(1 for _ in ast.walk(stripped)),
            'tokens': source_tokens,
            'normalized_tokens': normalized_tokens,
            'normalized_bytes': len(normalized.encode('utf-8')),
            'normalized_sha256': hashlib.sha256(normalized.encode('utf-8')).hexdigest()}


def run():
    manifest = json.loads((ROOT / 'comparison/ablation_manifest.json').read_text())
    rows = []
    for entry in manifest['records']:
        row = measure(ROOT / entry['path'])
        if row['sha256'] != entry['sha256']:
            raise ValueError('Measured source changed: ' + entry['path'])
        rows.append({'change': entry['change'], **row})
    result = {'python_version': platform.python_version(), 'scope': manifest['scope'], 'records': rows}
    destination = ROOT / 'results/ablation.json'
    destination.parent.mkdir(exist_ok=True)
    destination.write_text(json.dumps(result, indent=2) + '\n')
    return result


if __name__ == '__main__':
    result = run()
    for row in result['records']:
        print(row['change'], *(str(row[key]) for key in ('source_bytes', 'ast_nodes', 'tokens', 'normalized_tokens', 'normalized_bytes')))
