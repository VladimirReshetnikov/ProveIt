"""Recount delivered source groups; no comparator code is executed."""
from pathlib import Path
import ast
import csv
import hashlib
import io
import json
import sys
import tokenize

HERE = Path(__file__).resolve().parent
SKIP = {tokenize.COMMENT, tokenize.ENCODING, tokenize.ENDMARKER,
        tokenize.INDENT, tokenize.DEDENT, tokenize.NEWLINE, tokenize.NL}

class NoDocs(ast.NodeTransformer):
    def clear(self, node):
        self.generic_visit(node)
        if node.body and is_doc(node.body[0]):
            node.body.pop(0)
        if not node.body:
            node.body.append(ast.Pass())
        return node
    visit_Module = clear
    visit_ClassDef = clear
    visit_FunctionDef = clear
    visit_AsyncFunctionDef = clear

def is_doc(n):
    return (isinstance(n, ast.Expr) and isinstance(n.value, ast.Constant)
            and isinstance(n.value.value, str))

def count(path):
    raw = path.read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    spans = []
    for n in ast.walk(tree):
        if isinstance(n, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            if n.body and is_doc(n.body[0]):
                d = n.body[0]
                spans.append(((d.lineno, d.col_offset), (d.end_lineno, d.end_col_offset)))
    def sig(txt, omit=()):
        return [t for t in tokenize.generate_tokens(io.StringIO(txt).readline)
                if t.type not in SKIP and not any(a <= t.start and t.end <= b for a,b in omit)]
    original = sig(source, spans)
    clean = NoDocs().visit(tree)
    normalized = ast.unparse(clean) + '\n'
    imports = sorted({n.name.split('.')[0] for a in ast.walk(clean)
                      if isinstance(a, ast.Import) for n in a.names}
                     | {a.module.split('.')[0] for a in ast.walk(clean)
                        if isinstance(a, ast.ImportFrom) and a.module})
    return dict(raw_bytes=len(raw), normalized_bytes=len(normalized.encode()),
                significant_tokens=len(original), canonical_tokens=len(sig(normalized)),
                ast_nodes=sum(1 for _ in ast.walk(clean)),
                sha256=hashlib.sha256(raw).hexdigest(), imports=imports)

def main():
    spec = json.loads((HERE/'groups.json').read_text())
    rows = []
    fields = ['raw_bytes','normalized_bytes','significant_tokens','canonical_tokens','ast_nodes']
    for group in spec:
        files = []
        for name in group['files']:
            files.append(dict(path=name, **count(HERE/name)))
        totals = {k:sum(f[k] for f in files) for k in fields}
        digest = hashlib.sha256()
        for sha in sorted(f['sha256'] for f in files):
            digest.update(sha.encode()+b'\0')
        rows.append(dict(**group, file_counts=files, totals=totals,
                         content_group_sha256=digest.hexdigest()))
    envelope = {k:dict(value=min(r['totals'][k] for r in rows),
                      groups=[r['id'] for r in rows if r['totals'][k]==min(x['totals'][k] for x in rows)])
                for k in fields}
    unique = len({r['content_group_sha256'] for r in rows})
    result = dict(python_version=sys.version.split()[0],
        scope='Six current headline implementations, all discoverable controls, plus inherited source-accounted groups from current archives. Inherited incomplete boundaries are retained conservatively; none sets the current envelope.',
        method='No comparator code executed. Original significant token stream excludes only comments, layout, and actual docstrings. Canonical token count and normalized bytes use ast.unparse after removal of actual module/class/function docstrings. Every selected source in the supplied group is counted once. Standard Python runtime and standard library are excluded. All fixed data, validators, encoding, and CLI code remain charged.',
        current_commit='39c2b3c738e4cacbc0b2cb31f093c1eb4f976e75',
        group_count=len(rows), unique_content_groups=unique,
        coordinate_envelope=envelope, groups=rows)
    (HERE/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
    with (HERE/'comparison.csv').open('w',newline='') as f:
        w=csv.writer(f); w.writerow(['id','class','boundary',*fields,'content_group_sha256'])
        for r in rows:
            w.writerow([r['id'],r['class'],r['boundary'],*[r['totals'][k] for k in fields],r['content_group_sha256']])
    print(json.dumps(dict(group_count=len(rows),unique_content_groups=unique,envelope=envelope),indent=2))

if __name__ == '__main__':
    main()
