"""Remeasure frozen complete iPRA comparators and a proposed checker offline.

No comparator or candidate is imported or executed. A SHA-256 mismatch fails
before comparison. Run from any working directory, using Python 3.10 or later:

    python3 comparison/measure.py
    python3 comparison/measure.py --candidate /absolute/path/checker.py

Defaults: candidate ../checker.py; outputs metrics.json, table.tex, macros.tex
beside this script. Python 3.12.14 is the pinned measurement runtime. Other
Python versions can change ast.unparse output or AST details; the same version
always measures every candidate and comparator in a run.
"""

import argparse
import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

ROOT = Path(__file__).resolve().parent
AXES = ('raw_bytes', 'normalized_bytes', 'source_tokens',
        'normalized_tokens', 'ast_nodes')
IGNORED = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
           tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT}


class RemoveDocstrings(ast.NodeTransformer):
    def clean(self, node):
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body.pop(0)
        return self.generic_visit(node)

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(path):
    """Count the entire file; omit only genuine docstrings/comments/layout."""
    raw = path.read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source, filename=str(path))
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef,
                             ast.AsyncFunctionDef, ast.ClassDef)) and node.body:
            doc = node.body[0]
            if (isinstance(doc, ast.Expr) and isinstance(doc.value, ast.Constant)
                    and isinstance(doc.value.value, str)):
                spans.append(((doc.lineno, doc.col_offset),
                              (doc.end_lineno, doc.end_col_offset)))
    source_tokens = [
        token for token in tokenize.generate_tokens(io.StringIO(source).readline)
        if token.type not in IGNORED
        and not any(lo <= token.start and token.end <= hi for lo, hi in spans)
    ]
    tree = RemoveDocstrings().visit(tree)
    normalized = ast.unparse(tree) + '\n'
    normalized_tokens = [
        token for token in tokenize.generate_tokens(io.StringIO(normalized).readline)
        if token.type not in IGNORED
    ]
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(alias.name for alias in node.names)
        if isinstance(node, ast.ImportFrom):
            imports.append(node.module)
    return {
        'sha256': hashlib.sha256(raw).hexdigest(),
        'raw_bytes': len(raw),
        'normalized_bytes': len(normalized.encode('utf-8')),
        'source_tokens': len(source_tokens),
        'normalized_tokens': len(normalized_tokens),
        'ast_nodes': sum(1 for _ in ast.walk(tree)),
        'imports': sorted(set(imports)),
    }


def envelope(rows):
    return {axis: min(row['metrics'][axis] for row in rows) for axis in AXES}


def tex_number(number):
    return f'{number:,}'


def write_tex(result, table_path, macros_path):
    table = [r'\begin{tabular}{@{}lrrrr@{}}', r'\toprule',
             r'Complete program & Tokens & AST & Norm. bytes & Raw bytes \\',
             r'\midrule']

    def add_row(label, metrics):
        values = (metrics[key] for key in
                  ('normalized_tokens', 'ast_nodes', 'normalized_bytes', 'raw_bytes'))
        table.append(label + ' & ' + ' & '.join(map(tex_number, values)) + r' \\')

    for row in result['primary']:
        add_row(row['label'], row['metrics'])
    table.append(r'\midrule')
    for row in result['highlighted']:
        add_row(row['label'], row['metrics'])
    table.append(r'\midrule')
    add_row('Observed coordinate minima', result['comparison_envelope'])
    add_row(r'\textbf{New checker}', result['candidate'])
    table.extend([r'\bottomrule', r'\end{tabular}'])
    table_path.write_text('\n'.join(table) + '\n')
    macros = []
    for prefix, metrics in [('Candidate', result['candidate']),
                            ('Baseline', result['comparison_envelope'])]:
        for key, suffix in [('normalized_tokens', 'Tokens'),
                            ('source_tokens', 'SourceTokens'),
                            ('ast_nodes', 'AST'),
                            ('normalized_bytes', 'Bytes'),
                            ('raw_bytes', 'RawBytes')]:
            macros.append('\\newcommand{\\' + prefix + suffix + '}{'
                          + tex_number(metrics[key]) + '}')
    for suffix, value in [('StandaloneCount', len(result['standalone'])),
                          ('GroupCount', len(result['historical_groups'])),
                          ('FrozenSourceCount', len(result['source_metrics']))]:
        macros.append('\\newcommand{\\' + suffix + '}{' + str(value) + '}')
    macros_path.write_text('\n'.join(macros) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate', type=Path, default=ROOT.parent / 'checker.py')
    parser.add_argument('--output', type=Path, default=ROOT / 'metrics.json')
    parser.add_argument('--table', type=Path, default=ROOT / 'table.tex')
    parser.add_argument('--macros', type=Path, default=ROOT / 'macros.tex')
    args = parser.parse_args()
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    metrics = {}
    for source in manifest['sources']:
        path = ROOT / source['path']
        measured = measure(path)
        if measured['sha256'] != source['sha256']:
            raise ValueError('Frozen source SHA-256 mismatch: ' + source['path'])
        if measured['raw_bytes'] != source['raw_bytes']:
            raise ValueError('Frozen source length mismatch: ' + source['path'])
        metrics[source['sha256']] = measured
    if len(metrics) != len(manifest['sources']):
        raise ValueError('Duplicate frozen source identity')

    def rows(records):
        return [{**record, 'metrics': metrics[record['sha256']]} for record in records]

    standalone = rows(manifest['standalone'])
    groups = []
    for group in manifest['historical_groups']:
        members = [metrics[member['sha256']] for member in group['files']]
        total = {axis: sum(member[axis] for member in members) for axis in AXES}
        groups.append({**group, 'metrics': total})
    base = envelope(standalone + groups)
    candidate = measure(args.candidate)
    if candidate['imports'] != ['json', 'sys']:
        raise ValueError('Candidate requires dependencies outside the counted common runtime')
    result = {
        'format_version': 1,
        'snapshot_commit': manifest['snapshot_commit'],
        'python_version': platform.python_version(),
        'pinned_python_version': '3.12.14',
        'definitions': {
            'raw_bytes': 'Complete UTF-8 file including comments and documentation.',
            'normalized_bytes': 'Genuine docstrings removed; UTF-8 ast.unparse plus one newline.',
            'source_tokens': 'Original source tokens excluding comments, genuine docstrings and layout.',
            'normalized_tokens': 'Significant tokens in the normalized source.',
            'ast_nodes': 'All ast.walk nodes, including contexts, after removing genuine docstrings.',
            'scope': manifest['measurement_boundary'],
        },
        'qualification': manifest['qualification'],
        'source_metrics': metrics,
        'standalone': standalone,
        'historical_groups': groups,
        'primary': rows(manifest['primary']),
        'highlighted': rows(manifest['highlighted']),
        'primary_envelope': envelope(rows(manifest['primary'])),
        'standalone_envelope': envelope(standalone),
        'historical_group_envelope': envelope(groups),
        'comparison_envelope': base,
        'envelope_holders': {
            axis: [row['sha256'] for row in standalone if row['metrics'][axis] == base[axis]]
            + [row['id'] for row in groups if row['metrics'][axis] == base[axis]]
            for axis in AXES
        },
        'candidate': candidate,
        'candidate_at_or_below': {axis: candidate[axis] <= base[axis] for axis in AXES},
        'candidate_strictly_below': {axis: candidate[axis] < base[axis] for axis in AXES},
        'candidate_savings': {axis: base[axis] - candidate[axis] for axis in AXES},
        'candidate_savings_percent': {
            axis: 100 * (base[axis] - candidate[axis]) / base[axis] for axis in AXES
        },
    }
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    write_tex(result, args.table, args.macros)
    print(json.dumps({
        'python_version': result['python_version'],
        'verified_source_files': len(metrics),
        'standalone_count': len(standalone),
        'historical_group_count': len(groups),
        'comparison_envelope': base,
        'candidate': candidate,
        'candidate_strictly_below': result['candidate_strictly_below'],
    }, indent=2))


if __name__ == '__main__':
    main()
