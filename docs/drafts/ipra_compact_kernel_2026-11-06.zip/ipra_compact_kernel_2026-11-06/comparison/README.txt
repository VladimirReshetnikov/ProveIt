CURRENT DRAFT COMPARISON (READ-ONLY SOURCE CENSUS)
================================================
Snapshot: VladimirReshetnikov/ProveIt
Commit: 39c2b3c738e4cacbc0b2cb31f093c1eb4f976e75
Directory: docs/drafts
All six current ZIPs were obtained through the GitHub connector. Their bytes
match their returned Git blob SHA-1 identifiers. archive_manifest.json gives
byte counts, SHA-256 values, Git blob hashes, and stable source URLs.

The comparison includes six current headline programs, their supplied controls
and alternatives, and inherited source-accounted comparison groups copied into
those six archives. There are 216 group records, 74 distinct multisets of exact
source-file contents, and 81 distinct exact Python source files. Duplicates are
retained with their provenance. All groups are recounted from actual source;
old reported size figures are not treated as measurements of current programs.

Original significant tokens omit only comments, layout, and actual docstring
spans. Canonical tokens and normalized bytes use ast.unparse after removing
actual docstrings. AST counts retain operator/context nodes. Each group's
selected local dependency and JSON/CLI adapter is charged. Common Python and
its standard library are outside every count. Tests and builders are untrusted.
Some supplied inherited groups explicitly omit adapters or have other boundary
qualifications. They are retained in the conservative envelope; none attains
any of the current minima. No comparator program is executed by this census.

Current headline programs:
                            raw    normalized  original tokens  AST
 arithmetic_falsity         4093      3648          1129         1215
 checked_presentation       3821      3522          1089         1154
 premise_kernel             4204      3772          1149         1230
 shared_eliminator          4026      3642          1098         1183
 universal_kernel           4522      3734          1139         1220
 witness_kernel             3817      3486          1125         1203

The coordinate minima over ALL groups are:
  raw bytes:        3817 (witness headline)
  normalized bytes:3486 (witness headline)
  original tokens:1089 (checked_presentation headline)
  canonical tokens:1089 (checked_presentation headline)
  AST nodes:        1154 (checked_presentation headline)
These coordinates belong to different implementations, not one fictional
best checker. All old controls and all inspected current optional controls
are above or equal to these respective figures.

Beware of small counting differences: universal headline has 1139 original
significant tokens but 1140 canonical tokens; the optional premise encoded
checker has 1110 original tokens but 1111 canonical tokens. The report should
state one convention and consistently apply it. JSON outputs include both.

NOVELTY AUDIT
--------------
The six archives all compare themselves to an EARLIER common snapshot,
b079e5787b1d708049ff0643ce1b534c1a225198, containing eleven ZIPs. They do not
compare to one another. Thus their headline claim 'below every draft' is no
longer sufficient for a new iteration. Today's target is the envelope above.

The inherited mathematical base is common: native initialized primitive
recursion, equality, Pi=forall(implication), Sigma=exists(conjunction), an
explicit falsity bridge in genuine formulations, arithmetic equality-based
induction plus number cases, derived reflexivity/explosion, arithmetic
encoding of disjunction, and reflection of quantifier-free formulas as zero
equations. Whole-carrier bi-interpretability is proved by fixed-recursion
uniqueness and substitution coherence, not universal PR evaluation.

Complementary innovations:
  arithmetic_falsity: erase primitive falsity and bridge in encoded native core.
  premise_kernel: certify several well-formed annotations through premises,
    with a necessary guard against malformed syntax repaired by substitution.
  shared_eliminator: one principal-directed 'use' certificate for Eq/Pi/Sigma.
  universal_kernel: numerical induction/cases as a zero-premise axiom, plus
    -1 zero encoding separate from nonnegative variable indices.
  witness_kernel: Sigma introduction under fresh equality y=t, inferring both
    component formulas from checked branch derivations.
  checked_presentation: lists, stored-formula hypothesis lookup, falsity
    encoding, and a bundled numerical axiom constructed with Pi/Sigma.

A next checker retaining genuine falsity can combine the shared eliminator,
fresh-witness Sigma introduction, -1 zero encoding, and numerical axiom. It
must still beat 1089 tokens and 1154 AST, not the obsolete 1167/1248 frontier.

MATHEMATICAL AUDIT SCOPE
-----------------------
All six README files and selected full checker sources were inspected. The
checked_presentation report's full-logic recovery, arithmetic reflection,
interpretations, and encoded-certificate argument were reviewed. No fatal
soundness defect was identified in that inspected material. This is not a
formal verification of every inherited comparator or every paper.

The singleton issue is real and explicitly acknowledged by the drafts. A raw
positive first-order theory with ordinary equality can have a singleton model.
Encoded falsity acceptance is justified through a separate genuine-falsity
ordinary presentation and full-sequent adequacy. A new genuine-falsity checker
avoids relying on that distinction. Merely calling 0=S0 'bottom' is not enough
for an ordinary full-logic interpretation unless its relation to genuine
falsity is supplied and justified.

FILES AND REPRODUCTION
----------------------
  remeasure.py             Offline measurement, executes no comparator source
  groups.json              Source groups and exact source-reference provenance
  sources/*.py             Exact content-addressed source bytes
  comparison.json/.csv     Recomputed metrics and group classifications
  archive_manifest.json    Verified current six ZIP identities
  missing_groups.json      Empty; no referenced measurement group unresolved

Run 'python3 remeasure.py' from any directory. It uses only files alongside it.
Exact normalized bytes may change with a different Python ast.unparse version.
The delivered run used the Python version recorded in comparison.json.
