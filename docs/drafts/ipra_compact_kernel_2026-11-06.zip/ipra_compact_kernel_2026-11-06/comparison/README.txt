OFFLINE SIZE COMPARISON

This directory is intended to be placed at comparison/ next to checker.py.
Run from any working directory:

    python3 comparison/measure.py

For a different candidate:

    python3 comparison/measure.py --candidate /absolute/path/to/checker.py

The script writes metrics.json, table.tex and macros.tex beside itself.
Optional --output, --table and --macros arguments change those destinations.
Python 3.12.14 is the pinned measurement runtime; other Python versions may
change ast.unparse output or AST details. The same runtime measures all sources
and the candidate in every run.

Frozen input
------------

manifest.json identifies the current six ProveIt draft archives at commit
473749742630b5a7779e7c3a36cd23ebd9cb53b5 and records every frozen source's
SHA-256, byte length and exact member path in each current archive containing
it. The original archive SHA-256 and Git blob identities are also recorded in
archive_provenance.json. All six archive identities were checked during
assembly. Those archives and any network access are unnecessary for rerunning
the comparison.

sources/ contains 181 unmodified source files named by SHA-256. Original
comments, docstrings, formatting and line endings are retained. This set covers
145 unique complete standalone programs and every member of 74 recorded
historical dependency groups. The groups overlap standalone programs, so
145 + 74 is not a count of distinct checkers. Some historical groups explicitly
compare a mathematical core alone; they are counted favorably and remain
larger than the observed minimum.

The original six archives contain 750 Python members with 238 distinct source
hashes. An initial scan found 632 occurrences (151 distinct hashes) with
infer/check entry points. Of those, 142 were complete standalone CLI programs;
three additional historical standalone programs with different entry-point
arrangements were included. Dependencies are never measured as an isolated
small adapter: each historical group is measured as the sum of its recorded
member files.

Measurement
-----------

The entire standalone file is counted, including input parsing, syntax/sort
validation, substitution, every axiom and rule, imports, and rejection/CLI
handling. Python and its standard JSON library form the common runtime.

- Raw bytes count every byte, including documentation and formatting.
- Source tokens exclude comments, genuine Python docstrings, whitespace and
  layout tokens.
- AST nodes count all ast.walk nodes, including context nodes, after deleting
  genuine docstrings.
- Normalized bytes use ast.unparse on that docstring-stripped tree, with a
  single final newline.
- Normalized tokens count the significant tokens of that normalized source.

Only actual module/function/class docstrings are excluded. A significant
string constant inside executable code remains counted. No comparator or
candidate is imported or executed. Every frozen SHA-256 and length is checked
before measurement. The proposed standalone candidate is rejected from the
comparison if its imports exceed the common json/sys runtime boundary.

Observed frontier
-----------------

The sorted-certificates native core minimizes token counts (703 source and
701 normalized). Its split-introduction control minimizes byte counts (2574
raw and 2265 normalized). Both have 750 AST nodes. The coordinate envelope
combines those minima; it is intentionally a stronger comparison target than
either file separately.

For the frozen candidate c450c71b809ecfa25990ae43f97394b839fab78e0686488319e5b56543407b06,
remeasurement gives 2441 raw bytes, 2175 normalized bytes, 674 source tokens,
672 normalized tokens, and 717 AST nodes. It is strictly below every frontier
coordinate. The script derives these values from actual files rather than
trusting the numbers printed here.

Scope of the claim
------------------

The inventory establishes finite implementation-size comparisons. It is not
a correctness certification of every historical source, an absolute minimum
for iPRA, or a claim that the informal notion of simplicity has a unique
numerical measure. Public-falsity aliases and canonical arithmetic falsity
interfaces are both included; the smaller canonical competitors are counted
favorably. Proof translations and test generators are outside the trusted
acceptance boundary, and none is required to perform this measurement.
