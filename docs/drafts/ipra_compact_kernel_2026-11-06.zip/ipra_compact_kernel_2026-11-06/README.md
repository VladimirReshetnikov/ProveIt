# A smaller complete presentation of iPRA

The paper is `report.pdf`; its complete LaTeX source is `report.tex` and
`sections/`. The only trusted acceptance file is `checker.py`.

The target is full intuitionistic first-order primitive recursive arithmetic
with quantifier-free induction. Arbitrary quantified formulas remain available.
The native calculus has equality, a guarded universal, unary existence,
initialized recursion, equation induction, and numerical cases. The paper
specifies every primitive rule, derives ordinary intuitionistic logic and
quantifier-free induction, and proves a faithful ordinary realization that is
bi-interpretable with iPRA. Both interpretation domains are the whole number
sort; the two internal round-trip isomorphisms are equality. The ordinary
realization explicitly contains coverage and the genuine-falsity bridge.

## Concrete improvement

The comparison is pinned to ProveIt commit
`473749742630b5a7779e7c3a36cd23ebd9cb53b5`, the current six archives inspected
on 6 November 2026 (America/Los_Angeles). Their bundled complete implementations
and dependency groups were included, rather than only the six primary files.

| Whole-program measure | Observed draft envelope | This checker |
|---|---:|---:|
| Significant source tokens | 703 | **674** |
| Significant normalized tokens | 701 | **672** |
| AST nodes | 750 | **717** |
| Normalized bytes | 2,265 | **2,175** |
| Raw source bytes | 2,574 | **2,441** |

These are measured finite-corpus improvements, not a global minimality theorem.
The reduction combines the strongest sorted core with checked existential
scope deletion and the shared introduction-result construction. The main
mathematical foundation is inherited and credited. The ablation separates
representation improvements from ordinary API and command-line simplification.

## Reproduce offline

Use Python 3.12 for the recorded normalization measurements. The checker itself
uses Python 3.10+ features. No third-party Python packages or network calls are
required for checking or reproduction.

```bash
python3 reproduce.py
python3 checker.py examples/reflexivity.json
python3 checker.py examples/coverage.json
python3 reproduce.py --pdf
```

The PDF command additionally requires pdfLaTeX and the standard packages listed
at the top of `report.tex`. `build.py` initializes a temporary local format if
the TeX installation has not generated one. It does not download dependencies.

The API is `check(context, goal, proof)`. Input files contain the JSON triple
`[context, goal, proof]`. Falsity has canonical representation
`["=", -1, ["s", -1]]`; a separate `["false"]` alias is not accepted.
The report describes the complete grammar and the checked eigenvariable rule.

## Evidence included

- 149 preserved source certificates and their forward/reverse translations,
  checked with unchanged contexts and conclusions.
- An independent named-variable substitution oracle: 624 comparisons,
  including 104 scope-deletion cases and 30 required escape rejections.
- An independent 101-case certificate audit (38 positive, 63 negative),
  with all six deliberate fault injections detected.
- A separate 34-case direct regression and nine actual JSON/CLI checks.
- 181 verbatim comparison sources covering 145 standalone competitors and
  all dependencies of 74 historical groups; their counts overlap.
- Source hashes, provenance, metrics, ablation, and reproducible results.

Tests provide finite implementation evidence. The general equivalence and
soundness arguments are mathematical proofs in the article; no Lean or Rocq
formalization is claimed. The report explicitly documents harmless lookup-key
aliases that Python can equate with a validated stored assumption.

## Directory guide

| Path | Contents |
|---|---|
| `checker.py` | Complete acceptance implementation |
| `report.tex`, `sections/`, `report.pdf` | Full mathematical report |
| `examples/` | Named arithmetic and logical certificates |
| `proof_tools/` | Untrusted forward/reverse certificate translator |
| `validation/` | Frozen fixtures and targeted audits |
| `comparison/` | Verbatim competitors, provenance, metrics, ablations |
| `results/` | Reproduced evidence and PDF checks |
| `reproduce.py`, `build.py` | Offline checking and compilation commands |
| `MANIFEST.sha256` | Hashes of delivered files other than itself |

No script is imported by the checker except Python's standard `json` and `sys`.
Auxiliary scripts never extend the accepted mathematical theory.
