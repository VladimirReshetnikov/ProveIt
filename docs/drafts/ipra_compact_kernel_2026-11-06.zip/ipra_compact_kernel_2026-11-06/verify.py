"""Finite differential and adversarial checks; not part of the trusted kernel."""

import ast
import copy
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tokenize

import checker as k
import translate as tr

ROOT = Path(__file__).resolve().parent
Z, F = k.ZERO, k.FALSE
T = ["=", Z, Z]

def doc(goal, proof, assumptions=None):
    return {"assumptions": [] if assumptions is None else assumptions,
            "goal": goal, "proof": proof}

def accept(d):
    try:
        return k.check(d) is True
    except (ValueError, TypeError, IndexError, KeyError, RecursionError):
        return False

checks = []
def test(name, d, expected):
    actual = accept(d)
    if actual != expected:
        raise AssertionError((name, actual, expected, d))
    checks.append({"name": name, "accepted": actual, "expected": expected})

# Every compiled archived source certificate is cross-checked back in the
# independent complete predecessor calculus, with exactly the original goal.
source = ROOT / "source_certificates"
compiled = ROOT / "certificates"
compiled.mkdir(exist_ok=True)
for f in sorted(source.glob('*.json')):
    original = json.loads(f.read_text())
    result = tr.forward(original)
    restored = tr.backward(result)
    if tr.first.old.freeze(restored['goal']) != tr.first.old.freeze(original['goal']):
        raise AssertionError('goal changed: ' + f.name)
    if tr.first.old.freeze(restored['assumptions']) != tr.first.old.freeze(original['assumptions']):
        raise AssertionError('assumptions changed: ' + f.name)
    (compiled/f.name).write_text(json.dumps(result, separators=(',', ':'))+'\n')
    test('archived:' + f.stem, result, True)

# Additional source-level Sigma wrappers force the compiler's new witness
# branches to lift complete proofs, including their nested numerical schemas.
wrapped = 0
for f in sorted(source.glob('*.json')):
    original = json.loads(f.read_text())
    old = tr.first.old
    for depth in (1, 2):
        current = original
        for _ in range(depth):
            formula = old.freeze(current['goal'])
            conjunction = ('sig', old.shift(formula), old.shift(formula))
            current = {'assumptions': current['assumptions'], 'goal': conjunction,
                       'proof': ('pair', conjunction, old.ZERO,
                                 old.freeze(current['proof']), old.freeze(current['proof']))}
        result = tr.forward(current)
        restored = tr.backward(result)
        if old.freeze(restored['goal']) != old.freeze(current['goal']):
            raise AssertionError('wrapped goal changed')
        test('wrapped:'+str(depth)+':'+f.stem, result, True)
        wrapped += 1

native = {}
for name, witness in [
    ('zero_witness', Z), ('parameter_witness', 17),
    ('recursion_witness', ['r', 2, 0, ['r', 1, 2, ['s', 3]]])]:
    equation = ['=', 0, k.shift(witness)]
    native[name] = doc(['sig', equation, equation],
                       ['pair', witness, ['hyp', equation], ['hyp', equation]])
    guard = ['=', 1, 1]
    # Pair binds a witness; Pi then binds an independent number. Its guard
    # and its body deliberately refer to different surrounding scopes.
    body = ['pi', guard, k.shift(equation)]
    native[name+'_nested_pi'] = doc(['sig', body, equation],
        ['pair', witness, ['pi', guard, ['hyp', k.shift(equation)]], ['hyp', equation]])

native['genuine_false_bridge'] = doc(F, ['bridge', ['hyp', k.CLASH]], [k.CLASH])
native['false_is_not_equation'] = doc(k.CLASH, ['bridge', ['hyp', F]], [F])
native['stored_hypothesis'] = doc(['=', 0, 0], ['hyp', ['=', 0.0, False]], [['=', 0, 0]])
for name, d in native.items():
    test('native:'+name, d, True)
    tr.backward(d)
    (compiled/(name+'.json')).write_text(json.dumps(d,separators=(',',':'))+'\n')

# Inference returns the validated context object, not the possibly aliased
# claim supplied inside the hypothesis proof record.
g = [['=', 0, 0]]
if k.infer(['hyp', ['=', False, 0.0]], g) is not g[0]:
    raise AssertionError('hypothesis lookup leaked unvalidated metadata')

negative = {}
for name, bad in [('boolean', False), ('float', 0.0), ('negative', -2),
                  ('string', '0'), ('empty', []), ('object', {}),
                  ('unknown', ['q']), ('wrong_arity', ['s', Z, Z])]:
    negative['bad_term_'+name] = doc(['=', bad, bad], tr.refl(Z))
    negative['bad_witness_'+name] = doc(['sig', T, T], ['pair', bad, tr.refl(Z), tr.refl(Z)])
negative['unbound_hypothesis'] = doc(F, ['hyp', F])
negative['falsity_without_bridge'] = doc(F, ['hyp', k.CLASH], [k.CLASH])
negative['equation_without_bridge'] = doc(k.CLASH, ['hyp', F], [F])
negative['use_falsity_principal'] = doc(T, ['use', ['hyp', F], T, ['hyp', F]], [F])
negative['use_nonformula_template'] = doc(T, ['use', tr.refl(Z), Z, tr.refl(Z)])
negative['wrong_equation_premise'] = doc(T, ['use', tr.refl(Z), ['=', 0, ['s', Z]], tr.refl(Z)])
negative['malformed_pi_guard'] = doc(['pi', T, T], ['pi', Z, tr.refl(Z)])
negative['pi_eigenvariable_escape'] = doc(['pi', T, ['=', 0, Z]],
    ['pi', T, ['hyp', ['=', 0, Z]]], [['=', 0, Z]])
sigma = ['sig', ['=', 0, 0], ['=', 0, 0]]
negative['sigma_witness_escape'] = doc(['=', 0, 0],
    ['use', ['hyp', sigma], ['=', 0, 0], ['hyp', ['=', 0, 0]]], [sigma])
negative['sigma_bad_result'] = doc(T, ['use', ['hyp', sigma], ['=', False, False], tr.refl(Z)], [sigma])
negative['pair_self_referential_witness'] = doc(['sig', ['=', 0, 0], ['=', 0, 0]],
    ['pair', 0, ['hyp', ['=', 0, 0]], ['hyp', ['=', 0, 0]]])
negative['rec_unknown_counter'] = doc(T, ['rec', ['r', 0, Z, Z]])
negative['rec_formula_body'] = doc(T, ['rec', ['r', Z, Z, T]])
negative['rec_bad_successor_arity'] = doc(T, ['rec', ['r', ['s', Z, Z], Z, Z]])
negative['nat_formula_sort'] = doc(T, ['nat', Z])
negative['nat_forged_equation_IH'] = doc(T, ['nat', ['=', 0, 0], Z, tr.refl(Z), tr.refl(0)])
for name, a in [('falsity', F), ('pi', ['pi', ['=', 1, Z], ['=', 1, Z]]),
                 ('sigma', ['sig', ['=', 1, Z], ['=', 1, Z]])]:
    successor = k.subst(a, lambda i: ['s', 0] if i == 0 else i)
    forged_step = ['pi', a, successor]
    forged_schema = ['pi', k.shift(k.inst(a, Z)), ['pi', k.shift(forged_step, 2), k.shift(a)]]
    # For constant falsity the two guards coincide; use a malformed tag test
    # instead. Genuine falsity is still never classified as an equation.
    if name != 'falsity':
        negative['unrestricted_induction_'+name] = doc(forged_schema, ['nat', a])
negative['missing_field'] = {'goal': T, 'proof': tr.refl(Z)}
negative['extra_field'] = {**doc(T, tr.refl(Z)), 'trusted': True}
negative['assumption_wrong_container'] = doc(T, tr.refl(Z), {})
for name, d in negative.items():
    test('negative:'+name, d, False)

# Independent expected substitutions at distinct binding depths.
substitutions = [
    ('zero_fixed', k.shift(Z, 8), Z),
    ('free_variable', k.shift(3, 2), 5),
    ('pi_two_children_bound', k.shift(['pi', ['=',0,1], ['=',2,0]], 3),
          ['pi', ['=',0,4], ['=',5,0]]),
    ('rec_two_local_slots', k.shift(['r', 0, 1, ['r',1,2,['s',4]]], 3),
          ['r', 3, 4, ['r',1,5,['s',7]]]),
    ('instantiate_nested_pi', k.inst(['pi',['=',1,0],['=',2,1]], ['s',0]),
          ['pi',['=',['s',1],0],['=',1,['s',1]]]),
    ('instantiate_nested_rec', k.inst(['r',0,1,['s',2]], ['s',3]),
          ['r',['s',3],0,['s',['s',5]]]),
]
for name, actual, expected in substitutions:
    if actual != expected:
        raise AssertionError((name, actual, expected))

# CLI tests also exercise behavior under optimized Python (no asserts in kernel).
invalid_path = ROOT/'rejected_scope_escape.json'
invalid_path.write_text(json.dumps(negative['sigma_witness_escape'])+'\n')
cli = []
for optimized in [False, True]:
    for name, path, expected in [('valid',compiled/'zero_witness.json',0),
                                 ('invalid',invalid_path,1)]:
        cmd = [sys.executable] + (['-O'] if optimized else []) + [str(ROOT/'checker.py'),str(path)]
        run = subprocess.run(cmd,capture_output=True,text=True)
        if run.returncode != expected:
            raise AssertionError((cmd,run.stdout,run.stderr))
        cli.append({'optimized':optimized,'case':name,'exit':run.returncode,'stdout':run.stdout.strip()})

source_text = (ROOT/'checker.py').read_text()
tree = ast.parse(source_text)
for node in ast.walk(tree):
    if isinstance(node,(ast.Module,ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and node.body:
        first = node.body[0]
        if isinstance(first,ast.Expr) and isinstance(first.value,ast.Constant) and isinstance(first.value.value,str):
            node.body.pop(0)
normalized = ast.unparse(tree)+'\n'
raw_tree = ast.parse(source_text)
doc_spans = [(n.body[0].lineno, n.body[0].end_lineno) for n in ast.walk(raw_tree)
    if isinstance(n,(ast.Module,ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and n.body
    and isinstance(n.body[0],ast.Expr) and isinstance(n.body[0].value,ast.Constant)
    and isinstance(n.body[0].value.value,str)]
skip = {tokenize.ENCODING,tokenize.ENDMARKER,tokenize.INDENT,tokenize.DEDENT,
        tokenize.NEWLINE,tokenize.NL,tokenize.COMMENT}
metrics = {'raw_bytes':len(source_text.encode()),'normalized_bytes':len(normalized.encode()),
 'lexical_tokens':sum(t.type not in skip and not any(lo <= t.start[0] <= hi for lo, hi in doc_spans)
       for t in tokenize.generate_tokens(io.StringIO(source_text).readline)),
 'normalized_tokens':sum(t.type not in skip for t in tokenize.generate_tokens(io.StringIO(normalized).readline)),
 'ast_nodes':len(list(ast.walk(tree))),'sha256':hashlib.sha256(source_text.encode()).hexdigest()}
results = {'metrics':metrics,'checks':checks,'cli':cli,'substitutions':len(substitutions),
           'archived_roundtrips':len(list(source.glob('*.json'))),'native_roundtrips':len(native),'wrapped_roundtrips':wrapped}
(ROOT/'test_results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({**metrics,'accepted':sum(x['accepted'] for x in checks),
    'rejected':sum(not x['accepted'] for x in checks),'cli':len(cli),
    'substitutions':len(substitutions)},indent=2))
