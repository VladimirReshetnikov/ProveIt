COMBINED GENUINE-FALSITY iPRA CHECKER

Recommended trusted program: checker.py only.
Metrics (Python 3.12): 1004 significant ORIGINAL-source tokens, 1061 executable
AST nodes, 3335 canonical executable bytes, 3806 raw UTF-8 bytes. The canonical
source has 1003 tokens; do not mix that number with original-source comparisons.
The checker imports only standard-library json and sys. Its complete JSON
entry boundary, error handling, fixed data, validation, and CLI are included.

This source combines reductions inherited from the six current proposals.
It retains a distinct genuine falsity node and an explicit bridge. No encoded
positive reduct is needed. No annotation validator has been deleted.

TERMS
  -1                   the number zero
  integer i >= 0       a free/locally bound de Bruijn number variable
  ["s",t]              successor
  ["r",n,a,h]          initialized primitive recursion; h binds state 0,
                       counter 1, then ambient parameters at indices >= 2.
FORMULAS
  ["=",s,t]            equality
  ["false"]            genuine absurdity
  ["pi",A,B]           forall x (A(x) -> B(x)); x bound in both children
  ["sig",A,B]          exists x (A(x) and B(x)); x bound in both children

PROOF RECORDS
  ["hyp",A]            look up and return a stored, validated assumption
  ["pi",A,p]           universal/implication introduction, fresh number
  ["use",p,a,q]        dispatch by inferred principal:
                       equality: a is a one-slot formula template
                       Pi: a is the instantiating number term
                       Sigma: a is the conclusion independent of fresh witness
  ["pair",t,p,q]       infer both Sigma matrices under fresh y=t
  ["bridge",p]         change genuine falsity to 0=S0, or conversely
  ["rec",r]            one recursion computation equation at 0 or successor
  ["nat",A]            the CURRIED numerical axiom below

For A(x), let Q = forall y (H_A(y) -> A(Sy)), where H_A(y)=A(y) when
A is a literal equation, and H_A(y)=A(0) otherwise. The nat leaf concludes
  forall x (A(0) -> (Q -> A(x))).
There is NO Sigma antecedent in this final implementation. The compiler
uses Pi introductions/applications to represent each old native number rule.

All syntax variables are unbounded nonnegative indices with finite support;
no outer-arity declaration is needed. Every Pi or Sigma proof binder shifts
the ambient assumption formulas, enforcing fresh-variable conditions.

Hypothesis records use a lookup selector. Python may compare a selector
containing 0.0 or False equal to an entry containing 0. The rule returns the
stored entry, not that selector. Tests check object identity here. Consequently
malformed selector metadata cannot become an inferred formula. Assertion
syntax, guards, templates, recursors, and witnesses still use exact-int checks.

VALIDATION
  python3 verify.py
  python3 checker.py certificates/zero_witness.json
  python3 translate.py forward source_certificates/legacy_reflexivity_derived.json out.json
  python3 translate.py backward out.json restored.json

53 original archived proofs are translated forward and backward, preserving
exact goals/assumptions. 106 source-level Sigma wrappings force fresh-witness
lifting of complete proofs with nested numerical schemas. Nine direct native
examples are checked and translated backward. All 168 resulting positive
checks pass; 37 malformed/unsound inputs reject; 6 independently specified
binding/substitution equations and 4 CLI checks (including -O) pass.

Both directions of the compiler are general structural proof transformations,
not fixture-specific acceptance hacks. translate.py converts the final proof
format to/from the unchanged universal checker. to_universal.py is the adapted
universal archive's general conversion to/from the earlier genuine-falsity
calculus. Every input and output is validated. Neither compiler is imported
by checker.py, and their size is not hidden inside its trusted dependencies.

The back-translation of the fresh witness rule substitutes the witness into
its branches, then discharges y=t by a derived reflexivity proof of t=t.
It protects all local number binders and remaps assumption indices. The
forward translation transports each old Sigma premise along t=y after
freshening. These transformations provide executable additional evidence;
they do not replace the written universal mathematical proofs.

The files controls/ and ablation_metrics.json hold matched variants with one
reduction removed. They are comparison artifacts; checker.py is the sole
recommended acceptance program. The package also includes compilers,
reference checkers, source and translated certificates, verification results,
and complete provenance.
