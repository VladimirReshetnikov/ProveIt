"""Offline reproduction of the finite evidence accompanying the iPRA report."""

import argparse
import hashlib
import json
import platform
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
CHECKER_SHA256 = "c450c71b809ecfa25990ae43f97394b839fab78e0686488319e5b56543407b06"


def run(script, *args):
    command = [sys.executable, str(ROOT / script), *map(str, args)]
    result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
    if result.returncode:
        print(result.stdout)
        print(result.stderr, file=sys.stderr)
        raise RuntimeError("Reproduction failed: " + script)
    print(script + ": passed")


def cli_checks():
    checker = str(ROOT / "checker.py")
    positive = (ROOT / "examples/reflexivity.json").read_text()
    direct = json.loads((ROOT / "results/direct_audit.json").read_text())
    escape = next(row["certificate"] for row in direct["rows"]
                  if row["name"] == "ex_elimination_direct_witness_escape")
    cases = [
        ("valid_reflexivity", positive, True),
        ("witness_escape", json.dumps(escape), False),
        ("empty_triple", "[]", False),
        ("extra_triple_field", "[[], [], [], []]", False),
        ("nonlist_context", "[{}, [\"=\", -1, -1], [\"=\", -1, -1]]", False),
        ("boolean_goal", '[[["=",1,1]],["=",true,true],["=",1,1]]', False),
        ("invalid_json", "[", False),
    ]
    rows = []
    with tempfile.TemporaryDirectory(prefix="ipra-cli-") as directory:
        for name, text, accepts in cases:
            path = Path(directory) / (name + ".json")
            path.write_text(text)
            result = subprocess.run([sys.executable, checker, str(path)],
                                    text=True, capture_output=True)
            wanted = (0, "ACCEPT") if accepts else (1, "REJECT")
            observed = (result.returncode, result.stdout.strip())
            if observed != wanted:
                raise AssertionError((name, wanted, observed, result.stderr))
            rows.append({"name": name, "expected_accepts": accepts,
                         "exit_code": result.returncode,
                         "stdout": result.stdout.strip(), "passed": True})
        for name, args in [("missing_filename", []),
                           ("extra_filename", [str(path), str(path)])]:
            result = subprocess.run([sys.executable, checker, *args],
                                    text=True, capture_output=True)
            if (result.returncode, result.stdout.strip()) != (1, "REJECT"):
                raise AssertionError((name, result.returncode, result.stdout))
            rows.append({"name": name, "expected_accepts": False,
                         "exit_code": 1, "stdout": "REJECT", "passed": True})
    (ROOT / "results/cli.json").write_text(json.dumps({"cases": rows}, indent=2) + "\n")
    return len(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf", action="store_true", help="also compile report.pdf")
    args = parser.parse_args()
    actual_hash = hashlib.sha256((ROOT / "checker.py").read_bytes()).hexdigest()
    if actual_hash != CHECKER_SHA256:
        raise ValueError("The frozen checker has changed; audit the change before reusing results.")
    (ROOT / "results").mkdir(exist_ok=True)
    run("comparison/measure.py")
    run("comparison/measure_ablation.py")
    run("validation/replay_translations.py")
    run("validation/direct_audit.py")
    run("validation/independent_audit.py", ROOT / "checker.py",
        ROOT / "results/independent_audit.json")
    count = cli_checks()
    print("JSON/CLI checks: " + str(count) + " passed")
    if args.pdf:
        run("build.py")
    result = {"status": "passed", "python_version": platform.python_version(),
              "checker_sha256": actual_hash, "cli_cases": count,
              "pdf_built": args.pdf,
              "qualification": "Finite evidence, not formal verification of the metatheorems."}
    (ROOT / "results/reproduction.json").write_text(json.dumps(result, indent=2) + "\n")
    print("All requested reproduction steps passed.")


if __name__ == "__main__":
    main()
