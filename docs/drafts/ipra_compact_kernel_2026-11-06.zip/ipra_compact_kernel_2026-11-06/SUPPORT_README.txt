REPRODUCIBLE KERNEL COMPARISON AND POSITIVE CERTIFICATE TRANSLATIONS

All paths are relative to this archive's top-level directory.

The trusted acceptance program is checker.py alone. It imports only Python's
standard json and sys modules. Every script and fixture described below is
untrusted supporting evidence and is never imported by checker.py.

1. Positive translation replay

   python3 validation/replay_translations.py

   This verifies hashes of 149 original certificates and their supplied
   translations, reproduces the forward translation, checks both kernels,
   and checks a reverse translation with exactly the original context and
   conclusion. It writes results/translation_replay.json.

   Original fixture bytes and comparison/baselines/sorted_core.py are preserved
   verbatim from the sorted-certificates draft. validation/translation_manifest.json
   records the source archive, snapshot commit, Git blob SHA, archive SHA-256,
   archive member of each fixture, file hashes and sequent hashes.

   This corpus deliberately contains accepted certificates only. A malformed
   annotation removed by a representation change need not preserve rejection.
   The direct and independent adversarial audits cover rejection boundaries.

2. Forward or reverse translation of an accepted certificate

   python3 proof_tools/translate.py input.json output.json
   python3 proof_tools/translate.py --reverse input.json output.json

   Omitting output.json prints the translated certificate to standard output.
   The forward source API is old.check(data); the final API is new.check(*data).
   The native file format remains [context, conclusion, proof].

3. Direct boundary checks

   python3 validation/direct_audit.py
   python3 validation/direct_audit.py /absolute/path/to/another_checker.py

   The chosen checker must expose check(context, conclusion, proof).
   These 34 fixed cases cover existence-scope deletion, ignored-argument
   validation, recursion counter discrimination and stored-hypothesis aliases.
   It writes results/direct_audit.json. The report distinguishes this small
   fixed audit from the separate named-variable and adversarial audit.

4. Whole-program ablation measurements

   python3 comparison/measure_ablation.py

   Source hashes and labels are in comparison/ablation_manifest.json. All
   numerical/logical checks and CLI code are counted. Syntax metrics omit
   docstrings, comments and whitespace. Source significant tokens and tokens
   after ast.unparse are both recorded because redundant grouping can differ.
   Normalized bytes use ast.unparse plus one trailing newline. Raw bytes include
   comments/docstrings and are explicitly separated from the syntax metrics.
   Results are written to results/ablation.json.

   The first changes combine mechanisms already present in different supplied
   drafts. Later rows separately account for routine API/CLI cleanup. The last
   control replaces the final shared introduction branch with separate branches.
   These finite implementation comparisons do not prove absolute minimality.
