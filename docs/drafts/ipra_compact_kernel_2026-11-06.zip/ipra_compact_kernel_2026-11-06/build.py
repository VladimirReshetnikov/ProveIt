"""Compile the report with pdfLaTeX, initializing a local format if necessary."""

import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def command(args, cwd, env=None):
    completed = subprocess.run(args, cwd=cwd, env=env, text=True,
                               capture_output=True)
    if completed.returncode:
        raise RuntimeError(" ".join(args) + "\n" + completed.stdout[-20000:]
                           + completed.stderr[-5000:])
    return completed.stdout


def main():
    if not shutil.which("pdflatex"):
        raise RuntimeError("Install a TeX distribution providing pdfLaTeX and the report's packages.")
    with tempfile.TemporaryDirectory(prefix="ipra-tex-format-") as directory:
        env = os.environ.copy()
        result = subprocess.run(["kpsewhich", "pdflatex.fmt"],
                                text=True, capture_output=True)
        local_format = not result.stdout.strip()
        if local_format:
            command(["pdftex", "-ini", "-jobname=pdflatex", "-progname=pdflatex",
                     "-etex", "-interaction=nonstopmode", "-halt-on-error",
                     "pdflatex.ini"], directory)
            env["TEXFORMATS"] = directory + os.pathsep + env.get("TEXFORMATS", "")
        for _ in range(3):
            command(["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                     "-file-line-error", "report.tex"], ROOT, env)
    log = (ROOT / "report.log").read_text(errors="replace")
    bad = [line for line in log.splitlines()
           if "Overfull" in line or "undefined" in line.lower()
           or "Rerun to get" in line or "Label(s) may have changed" in line]
    status = {"pdf": "report.pdf", "local_format_initialized": local_format,
              "passes": 3, "layout_or_reference_warnings": bad}
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results/latex.json").write_text(json.dumps(status, indent=2) + "\n")
    print(json.dumps(status, indent=2))
    if bad:
        raise RuntimeError("Inspect and fix the reported layout/reference warnings.")


if __name__ == "__main__":
    main()
