"""Reproduce validation, measurements, and the LaTeX report (Python 3.10+)."""

from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent


def run(*args):
    subprocess.run(args, cwd=ROOT, check=True)


def package():
    paths = sorted(p for p in ROOT.rglob("*") if p.is_file()
                   and "__pycache__" not in p.parts and "build" not in p.relative_to(ROOT).parts
                   and p.name != "SHA256SUMS.txt" and p.suffix != ".pyc")
    (ROOT / "SHA256SUMS.txt").write_text("".join(
        hashlib.sha256(path.read_bytes()).hexdigest() + "  " + path.relative_to(ROOT).as_posix() + "\n"
        for path in paths))
    archive = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
        for path in paths + [ROOT / "SHA256SUMS.txt"]:
            stream.write(path, ROOT.name + "/" + path.relative_to(ROOT).as_posix())
    print(json.dumps({"archive": str(archive), "bytes": archive.stat().st_size,
                      "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-tests", action="store_true",
                        help="Use only after unchanged code has already been validated")
    parser.add_argument("--package-only", action="store_true")
    args = parser.parse_args()
    if not args.package_only:
        if not args.skip_tests:
            run(sys.executable, "verify.py")
            run(sys.executable, "independent_audit.py")
        run(sys.executable, "measure.py")
        build = ROOT / "build"
        build.mkdir(exist_ok=True)
        for iteration in range(3):
            result = subprocess.run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                                     "-output-directory=build", "report.tex"],
                                    cwd=ROOT, capture_output=True, text=True)
            (build / f"pdflatex_pass_{iteration + 1}.txt").write_text(result.stdout + result.stderr)
            if result.returncode:
                print(result.stdout[-7000:])
                raise SystemExit(result.returncode)
        log = (build / "report.log").read_text(errors="replace")
        defects = [line for line in log.splitlines()
                   if "Overfull" in line or "undefined" in line or "multiply defined" in line]
        if defects:
            raise RuntimeError("Resolve LaTeX diagnostics: " + "\n".join(defects))
        shutil.copy2(build / "report.pdf", ROOT / "report.pdf")
    package()


if __name__ == "__main__":
    main()
