"""Recount every supplied source group and the complete new checker."""

from pathlib import Path
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("source_measurement", ROOT / "comparison/remeasure.py")
measurement = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measurement)


def main():
    subprocess.run([sys.executable, str(ROOT / "comparison/remeasure.py")], check=True,
                   stdout=subprocess.DEVNULL)
    comparison = json.loads((ROOT / "comparison/comparison.json").read_text())
    candidate = measurement.count(ROOT / "checker.py")
    envelope = {key: value["value"] for key, value in comparison["coordinate_envelope"].items()}
    savings = {key: envelope[key] - candidate[key] for key in envelope}
    if not all(savings[key] > 0 for key in ("significant_tokens", "ast_nodes")):
        raise RuntimeError("Candidate no longer improves the measured envelope")
    controls = {path.stem: measurement.count(path) for path in sorted((ROOT / "controls").glob("*.py"))}
    result = {"python_version": sys.version.split()[0], "candidate": candidate,
              "supplied_envelope": envelope, "savings": savings,
              "percentage_reductions": {key: 100 * savings[key] / envelope[key] for key in envelope},
              "controls": controls,
              "source_group_count": comparison["group_count"],
              "distinct_source_groups": comparison["unique_content_groups"],
              "counting_method": comparison["method"]}
    (ROOT / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    names = {"NewTokens": candidate["significant_tokens"], "NewAST": candidate["ast_nodes"],
             "NewNormalized": candidate["normalized_bytes"], "NewRaw": candidate["raw_bytes"],
             "TokenSaving": savings["significant_tokens"], "ASTSaving": savings["ast_nodes"]}
    (ROOT / "results.tex").write_text("".join(
        "\\newcommand{\\" + key + "}{" + f"{value:,}" + "}\n" for key, value in names.items()))
    labels = {"arithmetic_falsity": "Arithmetic falsity", "checked_presentation": "Checked presentation",
              "premise_kernel": "Premise validation", "shared_eliminator": "Shared eliminator",
              "universal_kernel": "Universal kernel", "witness_kernel": "Witness kernel"}
    fields = ("raw_bytes", "normalized_bytes", "significant_tokens", "ast_nodes")
    lines = [r"\begin{center}\small", r"\begin{tabular}{@{}lrrrr@{}}", r"\toprule",
             r"Complete checker & Raw bytes & Normalized & Tokens & AST nodes\\", r"\midrule"]
    for row in comparison["groups"]:
        if row["id"].endswith("/headline"):
            label = labels[row["id"].split("/")[0]]
            lines.append(label + " & " + " & ".join(f"{row['totals'][key]:,}" for key in fields) + r"\\")
    lines.extend([r"\midrule", "Supplied coordinate minima & " +
                  " & ".join(f"{envelope[key]:,}" for key in fields) + r"\\",
                  r"\textbf{Proposed, genuine falsity} & " +
                  " & ".join(r"\textbf{" + f"{candidate[key]:,}" + "}" for key in fields) + r"\\",
                  r"\bottomrule", r"\end{tabular}", r"\end{center}"])
    (ROOT / "comparison_table.tex").write_text("\n".join(lines) + "\n")
    print(json.dumps({"candidate": candidate, "savings": savings}, indent=2))


if __name__ == "__main__":
    main()
