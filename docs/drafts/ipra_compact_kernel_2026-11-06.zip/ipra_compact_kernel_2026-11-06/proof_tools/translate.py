"""Untrusted positive-certificate translations; never imported by the checker.

Run: python3 proof_tools/translate.py [--reverse] input.json [output.json]
Forward: sorted_core.py certificates -> checker.py certificates.
Reverse: checker.py certificates -> sorted_core.py certificates.
Only accepted input certificates are translated; malformed annotations need
not retain their old rejection behavior after an annotation is removed.
"""
import argparse
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


old = load('sorted_baseline', ROOT / 'comparison/baselines/sorted_core.py')
new = load('candidate_checker', ROOT / 'checker.py')


def proof(p, g, reverse=False):
    kernel = new if reverse else old
    match p:
        case [('lam' | 'pack') as tag, a, q]:
            h = a if tag == 'lam' else ['=', 0, kernel.subst(a, formula=False)]
            return [tag, a, proof(q, [*map(kernel.subst, g), h], reverse)]
        case ['use', p, *args]:
            head, *parts = kernel.infer(p, g)
            first = proof(p, g, reverse)
            if head == 'ex':
                q = args[-1]
                minor = proof(q, [*map(kernel.subst, g), *parts], reverse)
                if reverse:
                    conclusion = new.infer(['use', p, q], g)
                    return ['use', first, conclusion, minor]
                return ['use', first, minor]
            a, q = args
            return ['use', first, a, proof(q, g, reverse)]
        case ['nat', a, p]:
            return ['nat', a, proof(p, g, reverse)]
        case _:
            return p


def translate(data, reverse=False):
    if reverse:
        new.check(*data)
    else:
        old.check(data)
    g, a, p = data
    result = [g, a, proof(p, g, reverse)]
    if reverse:
        old.check(result)
    else:
        new.check(*result)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reverse', action='store_true')
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path, nargs='?')
    args = parser.parse_args()
    result = translate(json.loads(args.input.read_text(encoding='utf-8')), args.reverse)
    text = json.dumps(result, separators=(',', ':')) + '\n'
    if args.output is None:
        print(text, end='')
    else:
        args.output.write_text(text, encoding='utf-8')
