"""Targeted independent audit of the complete candidate checker.

The expected formulas below are handwritten. They are not constructed by the
candidate's substitution or inference functions. Only finite JSON objects are
used as certificates. No comparator source or proof builder is imported.

Usage: python3 independent_audit.py --checker ../code/checker.py
"""
from pathlib import Path
import argparse
import copy
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile


def eq(a, b): return ['=', a, b]
def s(a): return ['s', a]
def r(n, a, h): return ['r', n, a, h]
def pi(a, b): return ['pi', a, b]
def sig(a, b): return ['sig', a, b]
def hyp(a): return ['hyp', a]
def record(g, goal, proof): return dict(assumptions=g, goal=goal, proof=proof)


def cases():
    z = -1
    f = ['false']
    clash = eq(z, s(z))
    truth = eq(z, z)
    tests = []
    def add(name, want, g, goal, proof):
        tests.append((name, want, record(g, goal, proof)))

    rz = r(z, z, z)
    qz = ['rec', rz]
    add('derived_reflexivity_zero', True, [], truth,
        ['use', qz, eq(0, z), qz])
    rp = r(z, 0, z)
    qp = ['rec', rp]
    add('derived_reflexivity_free_parameter', True, [], eq(0, 0),
        ['use', qp, eq(0, 1), qp])
    add('unproved_falsity_rejected', False, [], f, hyp(f))
    add('missing_hypothesis_rejected', False, [truth], clash, hyp(clash))
    add('false_to_clash', True, [f], clash, ['bridge', hyp(f)])
    add('clash_to_false', True, [clash], f, ['bridge', hyp(clash)])
    add('bridge_round_trip', True, [f], f, ['bridge', ['bridge', hyp(f)]])
    add('bridge_of_truth_rejected', False, [truth], f, ['bridge', hyp(truth)])
    add('false_is_not_generic_eliminator_principal', False, [f], truth,
        ['use', hyp(f), truth, hyp(f)])
    add('unknown_reflexivity_rule_rejected', False, [], truth, ['refl', z])
    add('pi_identity_false', True, [], pi(f, f), ['pi', f, hyp(f)])
    g0 = eq(0, z)
    g1 = eq(1, z)
    add('pi_old_context_is_shifted', True, [g0], pi(truth, g1),
        ['pi', truth, hyp(g1)])
    add('pi_cannot_reuse_unshifted_old_variable', False, [g0], pi(truth, g0),
        ['pi', truth, hyp(g0)])
    ip = pi(eq(0, z), eq(s(0), s(z)))
    witness_guard = eq(2, z)
    add('pi_use_at_free_parameter', True, [ip, witness_guard], eq(s(2), s(z)),
        ['use', hyp(ip), 2, hyp(witness_guard)])
    add('pi_use_wrong_guard_rejected', False, [ip, truth], eq(s(2), s(z)),
        ['use', hyp(ip), 2, hyp(truth)])
    add('pi_boolean_witness_rejected', False, [pi(truth, truth), truth], truth,
        ['use', hyp(pi(truth, truth)), True, hyp(truth)])

    fresh_eq = eq(0, 1)
    add('pair_binds_fresh_witness_for_free_term', True, [], sig(fresh_eq, fresh_eq),
        ['pair', 0, hyp(fresh_eq), hyp(fresh_eq)])
    add('pair_float_witness_rejected', False, [], sig(fresh_eq, fresh_eq),
        ['pair', 0.0, hyp(fresh_eq), hyp(fresh_eq)])
    add('pair_cannot_assume_witness_equals_unshifted_parameter', False, [],
        sig(eq(0, 0), eq(0, 0)), ['pair', 0, hyp(eq(0, 0)), hyp(eq(0, 0))])

    nested = r(0, 1, r(2, 0, s(4)))
    nested_shift = r(1, 2, r(3, 0, s(5)))
    nested_fresh = eq(0, nested_shift)
    add('pair_shifts_free_parameters_under_nested_recursors', True, [],
        sig(nested_fresh, nested_fresh),
        ['pair', nested, hyp(nested_fresh), hyp(nested_fresh)])
    wrong_fresh = eq(0, nested)
    add('pair_capture_under_nested_recursors_rejected', False, [],
        sig(wrong_fresh, wrong_fresh),
        ['pair', nested, hyp(wrong_fresh), hyp(wrong_fresh)])

    se = sig(eq(0, z), truth)
    add('sigma_eliminates_to_closed_formula', True, [se], truth,
        ['use', hyp(se), truth, hyp(truth)])
    add('sigma_eigenvariable_cannot_escape', False, [se], eq(0, z),
        ['use', hyp(se), eq(0, z), hyp(eq(0, z))])
    add('sigma_retains_shifted_old_context', True, [se, g0], g0,
        ['use', hyp(se), g0, hyp(g1)])
    add('sigma_cannot_use_unshifted_conclusion', False, [se, g0], g0,
        ['use', hyp(se), g0, hyp(g0)])

    e = eq(0, 1)
    add('equational_transport', True, [e, g0], eq(1, z),
        ['use', hyp(e), eq(0, z), hyp(g0)])
    nested_at_zero = r(0, 0, r(2, 0, s(4)))
    nested_at_one = r(1, 0, r(3, 0, s(5)))
    branch = eq(nested_at_zero, z)
    trans = ['use', hyp(e), eq(nested, z), hyp(branch)]
    add('transport_avoids_nested_recursion_capture', True, [e, branch],
        eq(nested_at_one, z), trans)
    add('transport_decrements_old_parameters', False, [e, branch],
        eq(r(1, 1, r(3, 0, s(5))), z), trans)
    add('captured_transport_conclusion_rejected', False, [e, branch],
        eq(r(1, 0, r(1, 0, s(1))), z), trans)
    add('equality_boolean_template_rejected', False, [e, truth], truth,
        ['use', hyp(e), eq(False, z), hyp(truth)])
    add('malformed_template_not_repaired_by_substitution', False, [e, truth], truth,
        ['use', hyp(e), ['=', ['s', 0, 'extra'], z], hyp(truth)])

    reczero = r(z, nested, r(0, 1, s(2)))
    add('recursion_zero_keeps_nested_seed', True, [], eq(reczero, nested),
        ['rec', reczero])
    h = r(0, 1, s(2))
    recur = r(s(2), 1, h)
    previous = r(2, 1, h)
    previous_shift_two = r(4, 3, h)
    rhs = r(previous, 2, s(previous_shift_two))
    add('recursion_step_simultaneous_capture_avoiding_substitution', True, [],
        eq(recur, rhs), ['rec', recur])
    add('recursion_step_captured_insert_rejected', False, [],
        eq(recur, r(previous, 2, s(previous))), ['rec', recur])
    add('recursion_cannot_compute_free_counter', False, [],
        eq(r(0, z, 0), z), ['rec', r(0, z, 0)])
    add('float_zero_does_not_pass_recursion_validation', False, [], truth,
        ['rec', r(-1.0, z, z)])
    add('negative_variable_below_zero_rejected', False, [], truth,
        ['rec', r(z, -2, z)])

    p = eq(0, 1)
    nat_eq = pi(eq(z, 1), pi(pi(eq(0, 3), eq(s(0), 3)), eq(1, 2)))
    add('numerical_axiom_equation_with_parameter', True, [], nat_eq, ['nat', p])
    add('numerical_axiom_incorrect_parameter_shift_rejected', False, [],
        pi(eq(z, 1), pi(pi(eq(0, 2), eq(s(0), 2)), eq(1, 2))), ['nat', p])
    compound = pi(eq(0, 1), f)
    compound_base = pi(eq(0, z), f)
    successor = pi(eq(0, s(1)), f)
    fixed_step = pi(compound_base, successor)
    compound_out = pi(eq(0, 2), f)
    nat_compound = pi(compound_base, pi(fixed_step, compound_out))
    add('non_equation_numerical_axiom_uses_fixed_base', True, [], nat_compound,
        ['nat', compound])
    forged_step = pi(compound, successor)
    add('compound_induction_cannot_replace_fixed_base', False, [],
        pi(compound_base, pi(forged_step, compound_out)), ['nat', compound])
    add('falsity_numerical_axiom_is_vacuous', True, [],
        pi(f, pi(pi(f, f), f)), ['nat', f])
    add('formula_cannot_be_equation_term_in_nat', False, [], truth,
        ['nat', eq(f, f)])
    add('malformed_nat_annotation_rejected', False, [], truth,
        ['nat', ['=', z, z, z]])

    valid_alias_goal = eq(0, 1)
    alias_key = eq(False, 1.0)
    add('numeric_alias_hypothesis_key_selects_stored_formula', True,
        [valid_alias_goal], valid_alias_goal, hyp(alias_key))
    add('numeric_alias_cannot_corrupt_root_goal', False,
        [valid_alias_goal], alias_key, hyp(alias_key))
    add('boolean_in_assumption_rejected', False,
        [eq(True, 1)], eq(1, 1), hyp(eq(True, 1)))
    add('boolean_pi_guard_rejected', False, [], pi(eq(True, 1), eq(True, 1)),
        ['pi', eq(True, 1), hyp(eq(True, 1))])
    add('huge_open_parameter_remains_valid', True,
        [eq(10**80, z)], eq(10**80, z), hyp(eq(10**80, z)))
    add('extra_false_argument_rejected', False, [['false', z]], truth,
        hyp(['false', z]))
    add('string_variable_rejected', False, [eq('0', z)], eq('0', z),
        hyp(eq('0', z)))
    extra = copy.deepcopy(tests[0][2]); extra['extra'] = 0
    tests.append(('extra_root_field_rejected', False, extra))
    bad_context = copy.deepcopy(tests[0][2]); bad_context['assumptions'] = {}
    tests.append(('non_list_context_rejected', False, bad_context))
    return tests


def run(checker, output):
    spec = importlib.util.spec_from_file_location('audited_candidate', checker)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    results = []
    failures = []
    examples = cases()
    expected_errors = (ValueError, TypeError, IndexError, KeyError, RecursionError)
    for name, expected, certificate in examples:
        detail = ''
        try:
            observed = module.check(copy.deepcopy(certificate)) is True
        except expected_errors as error:
            observed = False
            detail = type(error).__name__
        except Exception as error:
            observed = False
            detail = 'UNEXPECTED '+type(error).__name__+': '+str(error)
        passed = observed == expected and not detail.startswith('UNEXPECTED')
        result = dict(name=name, expected_acceptance=expected,
                      accepted=observed, passed=passed, detail=detail)
        results.append(result)
        if not passed: failures.append(name)

    bindings = []
    def bind(name, observed, expected):
        passed = observed == expected
        bindings.append(dict(name=name, passed=passed,
                             observed=observed, expected=expected))
        if not passed: failures.append(name)
    z = -1
    nested = r(0, 1, r(2, 0, s(4)))
    bind('zero_is_preserved_by_large_shift', module.shift(z, 17), z)
    bind('free_variable_receives_shift', module.shift(0, 17), 17)
    bind('nested_recursion_shift_protects_bound_slots', module.shift(nested),
         r(1, 2, r(3, 0, s(5))))
    bind('nested_recursion_instantiation_removes_one_slot', module.inst(nested, 0),
         r(0, 0, r(2, 0, s(4))))
    both = pi(eq(0, 1), sig(eq(0, 2), eq(1, 3)))
    bind('nested_logical_instantiation_protects_two_binders', module.inst(both, 0),
         pi(eq(0, 1), sig(eq(0, 2), eq(1, 2))))
    inserted = r(0, z, 0)
    bind('recursion_term_inserted_beneath_two_formula_binders', module.inst(both, inserted),
         pi(eq(0, r(1, z, 0)), sig(eq(0, r(2, z, 0)), eq(1, 2))))
    stored = [eq(0, 1)]
    bind('alias_hypothesis_returns_stored_object',
         module.infer(hyp(eq(False, 1.0)), stored) is stored[0], True)
    bind('boolean_never_valid_term', module.wf(True), False)
    bind('float_never_valid_term', module.wf(0.0), False)
    bind('negative_minus_two_never_valid_term', module.wf(-2), False)
    bind('zero_sentinel_is_valid_term', module.wf(z), True)

    cli_results = []
    choices = [examples[0], examples[2],
               next(t for t in examples if t[0]=='recursion_step_simultaneous_capture_avoiding_substitution'),
               next(t for t in examples if t[0]=='compound_induction_cannot_replace_fixed_base')]
    with tempfile.TemporaryDirectory(prefix='ipra-independent-') as directory:
        for name, expected, certificate in choices:
            f = Path(directory)/(name+'.json')
            f.write_text(json.dumps(certificate))
            for optimized in (False, True):
                command = [sys.executable, *(['-O'] if optimized else []), str(checker), str(f)]
                completed = subprocess.run(command, capture_output=True, text=True, timeout=15)
                passed = (completed.returncode == (0 if expected else 1)
                          and completed.stdout.strip() == ('ACCEPT' if expected else 'REJECT')
                          and not completed.stderr)
                cli_results.append(dict(name=name, optimized=optimized, passed=passed,
                    returncode=completed.returncode, stdout=completed.stdout.strip(),
                    stderr=completed.stderr))
                if not passed: failures.append(name+' CLI '+str(optimized))
    result = dict(checker_name=checker.name,
        checker_sha256=hashlib.sha256(checker.read_bytes()).hexdigest(),
        python_version=sys.version.split()[0],
        scope='Targeted independent finite-JSON, binding, arithmetic-schema, and CLI checks. Expected formulas are hand-constructed; no candidate proof builders used. This is not a formal metatheory proof.',
        certificate_count=len(results),
        expected_acceptances=sum(t[1] for t in examples),
        expected_rejections=sum(not t[1] for t in examples),
        binding_checks=len(bindings), cli_checks=len(cli_results),
        all_passed=not failures, failures=failures,
        certificate_results=results, binding_results=bindings, cli_results=cli_results)
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['checker_sha256','certificate_count',
        'expected_acceptances','expected_rejections','binding_checks','cli_checks','all_passed','failures']},indent=2))
    return not failures


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    default=Path(__file__).resolve().parent/'checker.py'
    if not default.exists(): default=Path(__file__).resolve().parent.parent/'code'/'checker.py'
    parser.add_argument('--checker',type=Path,default=default)
    parser.add_argument('--output',type=Path,default=Path(__file__).with_name('independent_results.json'))
    args=parser.parse_args()
    sys.exit(0 if run(args.checker.resolve(),args.output.resolve()) else 1)
