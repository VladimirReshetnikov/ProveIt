import Init

/-
Abstract kernels for return induction.

Scope: these theorems use an arbitrary carrier D, not Nat. They verify the
logical extraction of induction from a single latch recursor, conditional on
the displayed computation, coverage, and return-induction assumptions.
They do NOT formalize the finite-term grammar, the axiom enumerator, the
pairing construction, or the full interpretation/definitional-equivalence
theorem. A successful check of this file is not a full formalization of PRA.
-/

universe u

namespace ReturnInduction

variable {D : Type u}

noncomputable def latch (zero : D) (pred : D → D)
    (A : D → D → Prop) (v n : D) : D := by
  classical
  exact if A n (pred v) then v else zero

/-- Latch reflection holds for every state, without a range invariant. -/
theorem latch_reflection
    (zero : D) (succ pred : D → D) (A : D → D → Prop)
    (succ_ne_zero : ∀ b, succ b ≠ zero)
    (pred_succ : ∀ b, pred (succ b) = b) :
    ∀ v n b, latch zero pred A v n = succ b ↔
      v = succ b ∧ A n b := by
  classical
  intro v n b
  unfold latch
  by_cases test : A n (pred v)
  · rw [if_pos test]
    constructor
    · intro hv
      refine ⟨hv, ?_⟩
      simpa only [hv, pred_succ] using test
    · intro hv
      exact hv.1
  · rw [if_neg test]
    constructor
    · intro hz
      exact False.elim (succ_ne_zero b hz.symm)
    · intro hv
      have tested : A n (pred v) := by
        simpa only [hv.1, pred_succ] using hv.2
      exact False.elim (test tested)

/-- Unshifted return induction plus coverage gives induction for A. -/
theorem orbit_implies_induction
    (zero : D) (succ : D → D)
    (A : D → D → Prop) (h R : D → D → D)
    (coverage : ∀ n, n = zero ∨ ∃ k, n = succ k)
    (rec_step : ∀ n a, R (succ n) a = h (R n a) n)
    (reflection : ∀ v n b, h v n = succ b ↔
      v = succ b ∧ A n b)
    (orbit : ∀ a, (∀ k, R k a = a → h a k = a) →
      ∀ n, R n a = a)
    (b : D) (base : A zero b)
    (step : ∀ n, A n b → A (succ n) b) :
    ∀ n, A n b := by
  have preserve : ∀ k, R k (succ b) = succ b →
      h (succ b) k = succ b := by
    intro k hk
    have ak : A k b := by
      cases coverage k with
      | inl hz =>
        simpa only [hz] using base
      | inr hs =>
        cases hs with
        | intro j hj =>
          have hr : h (R j (succ b)) j = succ b := by
            rw [← rec_step, ← hj]
            exact hk
          have ap : A j b :=
            ((reflection (R j (succ b)) j b).mp hr).2
          simpa only [← hj] using step j ap
    exact (reflection (succ b) k b).mpr ⟨rfl, ak⟩
  have all_returns : ∀ n, R n (succ b) = succ b :=
    orbit (succ b) preserve
  intro n
  have hr : h (R n (succ b)) n = succ b := by
    rw [← rec_step]
    exact all_returns (succ n)
  exact ((reflection (R n (succ b)) n b).mp hr).2

/-- A shifted orbit principle supplies the same induction without coverage. -/
theorem shifted_orbit_implies_induction
    (zero : D) (succ : D → D)
    (A : D → D → Prop) (h R : D → D → D)
    (rec_step : ∀ n a, R (succ n) a = h (R n a) n)
    (reflection : ∀ v n b, h v n = succ b ↔
      v = succ b ∧ A n b)
    (shifted_orbit : ∀ a,
      h a zero = a →
      (∀ k, R (succ k) a = a → h a (succ k) = a) →
      ∀ n, R (succ n) a = a)
    (b : D) (base : A zero b)
    (step : ∀ n, A n b → A (succ n) b) :
    ∀ n, A n b := by
  have start : h (succ b) zero = succ b :=
    (reflection (succ b) zero b).mpr ⟨rfl, base⟩
  have preserve : ∀ k, R (succ k) (succ b) = succ b →
      h (succ b) (succ k) = succ b := by
    intro k hk
    have hr : h (R k (succ b)) k = succ b := by
      rw [← rec_step]
      exact hk
    have ak : A k b :=
      ((reflection (R k (succ b)) k b).mp hr).2
    exact (reflection (succ b) (succ k) b).mpr
      ⟨rfl, step k ak⟩
  have all_returns : ∀ n, R (succ n) (succ b) = succ b :=
    shifted_orbit (succ b) start preserve
  intro n
  have hr : h (R n (succ b)) n = succ b := by
    rw [← rec_step]
    exact all_returns n
  exact ((reflection (R n (succ b)) n b).mp hr).2

/-- With coverage, an unshifted return axiom gives its shifted version. -/
theorem orbit_to_shifted
    (zero : D) (succ : D → D) (h R : D → D → D)
    (coverage : ∀ n, n = zero ∨ ∃ k, n = succ k)
    (orbit : ∀ a, (∀ k, R k a = a → h a k = a) →
      ∀ n, R n a = a) :
    ∀ a, h a zero = a →
      (∀ k, R (succ k) a = a → h a (succ k) = a) →
      ∀ n, R (succ n) a = a := by
  intro a start progress
  have preserve : ∀ k, R k a = a → h a k = a := by
    intro k hk
    cases coverage k with
    | inl hz =>
      simpa only [hz] using start
    | inr hs =>
      cases hs with
      | intro j hj =>
        have hr : R (succ j) a = a := by
          simpa only [hj] using hk
        simpa only [hj] using progress j hr
  intro n
  exact orbit a preserve (succ n)

/-- With coverage and the base computation, shifted returns give all returns. -/
theorem shifted_to_orbit
    (zero : D) (succ : D → D) (h R : D → D → D)
    (coverage : ∀ n, n = zero ∨ ∃ k, n = succ k)
    (rec_zero : ∀ a, R zero a = a)
    (shifted_orbit : ∀ a, h a zero = a →
      (∀ k, R (succ k) a = a → h a (succ k) = a) →
      ∀ n, R (succ n) a = a) :
    ∀ a, (∀ k, R k a = a → h a k = a) →
      ∀ n, R n a = a := by
  intro a progress
  have start : h a zero = a := progress zero (rec_zero a)
  have shifted : ∀ n, R (succ n) a = a :=
    shifted_orbit a start (fun k hk => progress (succ k) hk)
  intro n
  cases coverage n with
  | inl hz =>
    simpa only [hz] using rec_zero a
  | inr hs =>
    cases hs with
    | intro k hk =>
      simpa only [hk] using shifted k

noncomputable def coverageLatch (zero : D) (succ pred : D → D)
    (v n : D) : D := by
  classical
  exact if n = zero then v else if n = succ (pred n) then v else zero

/-- One explicitly given shifted instance already proves predecessor coverage. -/
theorem shifted_forces_coverage
    (zero one : D) (succ pred : D → D) (R : D → D → D)
    (one_ne_zero : one ≠ zero)
    (pred_succ : ∀ n, pred (succ n) = n)
    (rec_step : ∀ n a, R (succ n) a =
      coverageLatch zero succ pred (R n a) n)
    (shifted_orbit : ∀ a,
      coverageLatch zero succ pred a zero = a →
      (∀ k, R (succ k) a = a →
        coverageLatch zero succ pred a (succ k) = a) →
      ∀ n, R (succ n) a = a) :
    ∀ n, n = zero ∨ n = succ (pred n) := by
  classical
  have start : coverageLatch zero succ pred one zero = one := by
    simp [coverageLatch]
  have progress : ∀ k, R (succ k) one = one →
      coverageLatch zero succ pred one (succ k) = one := by
    intro k _
    simp [coverageLatch, pred_succ]
  have returns := shifted_orbit one start progress
  intro n
  have hn : coverageLatch zero succ pred (R n one) n = one := by
    rw [← rec_step]
    exact returns n
  by_cases hz : n = zero
  · exact Or.inl hz
  · by_cases hs : n = succ (pred n)
    · exact Or.inr hs
    · have impossible : zero = one := by
        simpa only [coverageLatch, if_neg hz, if_neg hs] using hn
      exact False.elim (one_ne_zero impossible.symm)

end ReturnInduction

#print axioms ReturnInduction.latch_reflection
#print axioms ReturnInduction.orbit_implies_induction
#print axioms ReturnInduction.shifted_orbit_implies_induction
#print axioms ReturnInduction.orbit_to_shifted
#print axioms ReturnInduction.shifted_to_orbit
#print axioms ReturnInduction.shifted_forces_coverage
