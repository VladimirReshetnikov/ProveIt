PRA FROM RETURN INDUCTION
Research package prepared for Vladimir Reshetnikov, November 2, 2026.

START HERE
  report.pdf     Complete research paper, including full written proofs.
  report.tex     Self-contained editable LaTeX source.
  AXIOMS.txt     Exact standalone specification of both equivalent variants.

RESULT
Induction can be restricted to the equation saying that a recursively defined
trajectory returns its initial value. With zero-or-successor coverage, this
gives a recurring schema with only two exposed input-body copies. A shifted
version needs three copies but derives coverage itself. Both are definitionally
equivalent, bi-interpretable, and equiconsistent with classical first-order PRA.
The interpretations preserve the full carrier and native equality; both round
trips are internally the identity.

The logic includes atomic-equality conditionals, conservatively definable in
classical first-order logic. This change is explicitly charged as a logical
specification cost and is shared with the current constancy draft.

COMPARISON
All six CURRENT November 2 draft archives were reviewed at ProveIt commit
d46d2b97cb3c4d4f3a0154fc5884ea42ffcd5966. Their older internal comparisons refer
to a different six-archive inventory. source_manifest.json pins the actual inputs.

After factoring fixed arithmetic assumptions once:
  Return:    recurring 29+2m+2i; fixed 16 nodes.
  Mask:      recurring 28+4m+3i; fixed 17 nodes.
  Constancy: recurring 18+5m+3i; fixed 6 nodes.

Return saves 2m+i-1 nodes per recurring mask formula. Against constancy it is
shorter for sufficiently large input bodies; constancy and zero-anchor variants
retain advantages on some small or special inputs. No absolute shortestness or
uniform dominance in every language/sharing convention is claimed.

The report also charges every stored descriptor at every occurrence. A finite
family of state-independent bodies can alter the full-cost comparison; the exact
formulas and quantifier tradeoffs are included rather than hidden in names.

NEGATIVE RESULT
Deleting coverage from the unshifted theory admits infinitely many successor
chains. Their component-swap automorphisms rule out ordinary bi-interpretability
with PRA, including interpretations with any fixed finite tuple of parameters.

VERIFICATION
  formal/OrbitKernel.lean      Six abstract kernels checked with Lean 4.19.0.
  formal/SCOPE.txt             Precise boundary of mechanization.
  verification/lean_output.txt Actual successful axiom-audit output.
  checks/check_syntax.py       Fresh literal AST checker, including all 6 drafts.
  checks/check_arithmetic.py   Finite scalar pairing and latch diagnostics.
  verification/*.json         Reproducible results and document checks.

The full syntax, pairing, compiler, and identity-round-trip theorems are written
proofs. No full Lean/Rocq formalization of the entire equivalence is claimed.
No third-party draft scripts were executed or imported. No repository was changed.

REBUILD
  python3 build.py
  python3 build.py --lean /absolute/path/to/lean
Requires Python 3 and a normal pdfLaTeX installation. Lean is optional for rebuild;
the stored formal log records the actual checked run. The build uses no network.

CONTENTS
  report.tex, report.pdf, AXIOMS.txt, README.txt, build.py
  checks/                     Reproducible finite checks.
  formal/                     Lean proof and scope documentation.
  verification/               Logs and JSON results.
  source_manifest.json        Immutable source URLs, hashes, and review inventory.
  SHA256SUMS                  Integrity hashes for packaged files.

Further research questions are included in the paper.
