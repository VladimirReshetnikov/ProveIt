#!/usr/bin/env python3
"""Offline reproduction of the finite checks, optional Lean kernels, and PDF."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--lean', help='Optional absolute path to a Lean 4 executable')
    ap.add_argument('--checks-only', action='store_true')
    args = ap.parse_args()
    root = Path(__file__).resolve().parent
    verification = root / 'verification'
    build = root / '.build'
    verification.mkdir(exist_ok=True)
    build.mkdir(exist_ok=True)
    commands = []
    env = dict(os.environ)
    env.setdefault('SOURCE_DATE_EPOCH', '1793642400')

    def run(command, logname):
        result = subprocess.run(command, cwd=root, env=env, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (verification / logname).write_text(result.stdout)
        commands.append({'command': command, 'exit_code': result.returncode,
                         'log': logname})
        if result.returncode:
            print(result.stdout[-9000:])
            raise RuntimeError(f'Command failed; see verification/{logname}')
        return result.stdout

    run([sys.executable, 'checks/check_syntax.py'], 'syntax_output.txt')
    run([sys.executable, 'checks/check_arithmetic.py'], 'arithmetic_output.txt')
    if args.lean:
        run([args.lean, 'formal/OrbitKernel.lean'], 'lean_output.txt')
    if not args.checks_only:
        if not shutil.which('pdflatex'):
            raise RuntimeError('pdflatex is required to compile report.tex')
        command = ['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
                   '-file-line-error', '-output-directory=.build', 'report.tex']
        for i in range(1, 4):
            run(command, f'latex_pass_{i}.txt')
        shutil.copy2(build / 'report.pdf', root / 'report.pdf')
        log = (build / 'report.log').read_text(errors='replace')
        issues = [line for line in log.splitlines()
                  if 'Overfull' in line or 'undefined' in line.lower()
                  or 'Rerun to get' in line]
        if issues:
            print('\n'.join(issues))
        else:
            print('PDF compiled without overfull boxes or unresolved references.')
    result = {
        'status': 'passed',
        'commands': commands,
        'lean_checked_in_this_build': bool(args.lean),
        'pdf_created': not args.checks_only,
        'scope': 'Build and reproducible finite checks. Visual review is separate; full equivalence is a written proof.',
    }
    (verification / 'build_results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'commands': len(commands)}, indent=2))


if __name__ == '__main__':
    main()
