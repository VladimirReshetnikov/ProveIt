#!/usr/bin/env python3
"""Independent finite AST audit for the PRA orbit presentation.

This checks syntax sizes and capture-free active substitutions, not the
mathematical bi-interpretation theorem.  Stored recursor descriptors are
frozen syntax.  The ``expanded`` metric recursively charges each descriptor
at each occurrence of the recursor symbol; the active metric treats a
recursor symbol as one node.  No code from the compared draft archives is
imported or executed.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path
import random


@dataclass(frozen=True)
class Node:
    tag: str
    children: tuple["Node", ...] = ()
    name: str = ""
    body: "Node | None" = None


def var(name):
    return Node("var", name=name)


ZERO = Node("zero")
FALSE = Node("false")
n, a, v, w, x, y, k = map(var, ("n", "a", "v", "w", "x", "y", "k"))


def S(t):
    return Node("S", (t,))


ONE = S(ZERO)


def eq(s, t):
    return Node("eq", (s, t))


def conj(p, q):
    return Node("and", (p, q))


def disj(p, q):
    return Node("or", (p, q))


def imp(p, q):
    return Node("implies", (p, q))


def forall(name, p):
    return Node("forall", (p,), name=name)


def exists(name, p):
    return Node("exists", (p,), name=name)


def fn(name, *args):
    return Node("function", tuple(args), name=name)


def rec(body, counter, seed):
    return Node("recursor", (counter, seed), body=body)


def ite(left, right, yes, no):
    # The equality guard is syntax and is fully charged.
    return Node("ite", (eq(left, right), yes, no))


def size(t, expanded=False):
    result = 1 + sum(size(c, expanded) for c in t.children)
    if expanded and t.body is not None:
        result += size(t.body, True)
    return result


def occurrences(t, name):
    return (t.tag == "var" and t.name == name) + sum(
        occurrences(c, name) for c in t.children
    )


def subst(t, replacements):
    """Simultaneous substitution in active syntax; descriptors stay frozen."""
    if t.tag == "var":
        return replacements.get(t.name, t)
    assert t.tag not in ("forall", "exists"), "This operation is for terms."
    return Node(t.tag, tuple(subst(c, replacements) for c in t.children),
                t.name, t.body)


def apply(u, state, counter):
    return subst(u, {"n": state, "a": counter})


def descriptor(u):
    return apply(u, v, w)


def close(p):
    return forall("a", forall("n", p))


SIGMA = imp(eq(ZERO, ONE), FALSE)


def pred(t):
    return rec(w, t, ZERO)


COV_EXISTS_MATRIX = disj(eq(n, ZERO), exists("k", eq(n, S(k))))
COV_PRED_MATRIX = disj(eq(n, ZERO), eq(n, S(pred(n))))
COV_EXISTS = forall("n", COV_EXISTS_MATRIX)
COV_PRED = forall("n", COV_PRED_MATRIX)


def basis(u, body=None):
    h = descriptor(u) if body is None else body
    r = lambda t, z: rec(h, t, z)
    base = eq(r(ZERO, a), a)
    step = eq(r(S(n), a), apply(u, r(n, a), n))
    return conj(base, step), r


def orbit(u, coverage=None, direct=False):
    b, r = basis(u)
    p = eq(r(n, a), a)
    nxt = eq(r(S(n), a), a) if direct else eq(apply(u, a, n), a)
    h = forall("n", imp(p, nxt))
    matrix = conj(b, imp(h, p))
    if coverage is not None:
        c = COV_EXISTS_MATRIX if coverage == "exists" else COV_PRED_MATRIX
        matrix = conj(SIGMA, conj(c, matrix))
    return close(matrix)


def shifted_orbit(u):
    b, r = basis(u)
    p = eq(r(S(n), a), a)
    h = conj(eq(apply(u, a, ZERO), a),
             forall("n", imp(p, eq(apply(u, a, S(n)), a))))
    return close(conj(b, imp(h, p)))


def constancy(u, repeated_separation=True):
    b, _ = basis(u)
    if repeated_separation:
        b = conj(SIGMA, b)
    h = forall("n", eq(apply(u, S(n), a), apply(u, n, a)))
    return close(conj(b, imp(h, eq(apply(u, n, a), apply(u, ZERO, a)))))


def zero_induction(u, repeated_separation=True):
    b, _ = basis(u)
    if repeated_separation:
        b = conj(SIGMA, b)
    e = lambda t: eq(apply(u, t, a), ZERO)
    h = conj(e(ZERO), forall("n", imp(e(n), e(S(n)))))
    return close(conj(b, imp(h, e(n))))


BIT_NORMALIZED = forall("x", forall("y", conj(
    eq(fn("epsilon", x, x), ZERO),
    disj(eq(x, y), eq(fn("epsilon", x, y), ONE)))))
BIT_GRAPH = forall("x", forall("y", disj(
    conj(eq(x, y), eq(fn("B", x, y), ZERO)),
    conj(imp(eq(x, y), FALSE), eq(fn("B", x, y), ONE)))))
OFF = forall("x", forall("y", disj(eq(x, y), eq(fn("Delta", x, y), ZERO))))


def exceptional_bit(u):
    if u != ZERO:
        return zero_induction(u, repeated_separation=False)
    b, _ = basis(u)
    bit = conj(eq(fn("epsilon", a, a), ZERO),
               disj(eq(a, n), eq(fn("epsilon", a, n), ONE)))
    return close(conj(b, conj(SIGMA, bit)))


def mask(u, repeated_separation=True, include_off=False):
    b, _ = basis(u)
    if repeated_separation:
        b = conj(SIGMA, b)
    p = eq(fn("Delta", n, apply(u, n, a)), n)
    h = forall("n", imp(p, eq(apply(u, S(n), a), S(n))))
    matrix = conj(b, imp(h, p))
    if include_off:
        matrix = conj(disj(eq(n, a), eq(fn("Delta", n, a), ZERO)), matrix)
    return close(matrix)


def diagonal_matrix():
    return eq(rec(pred(v), S(n), n), ONE)


DIAGONAL = forall("n", diagonal_matrix())


def four_occurrence(u, fused=False):
    b, _ = basis(u)
    p = disj(eq(n, ZERO), eq(apply(u, n, a), n))
    h = forall("n", imp(p, eq(apply(u, S(n), a), S(n))))
    matrix = conj(b, imp(h, p))
    if fused:
        matrix = conj(SIGMA, conj(diagonal_matrix(), matrix))
    return close(matrix)


def root_prune(t):
    while (t.tag == "recursor" and t.body == w
           and t.children[0].tag == "S"):
        t = t.children[0].children[0]
    return t


def zero_anchor(u, optional_pruning=False):
    i, j = occurrences(u, "n"), occurrences(u, "a")
    canonical = root_prune(descriptor(u))
    b, r = basis(u, canonical)
    if optional_pruning and i == 0:
        return close(conj(SIGMA, b))
    if j == 0:
        right = conj(eq(r(ZERO, a), a),
                     eq(r(S(n), a), r(n, apply(u, a, ZERO))))
        return close(conj(SIGMA, right))
    e = lambda t: eq(apply(u, t, a), apply(u, t, ZERO))
    p = disj(eq(n, ZERO), e(n))
    h = forall("n", imp(p, e(S(n))))
    return close(conj(conj(SIGMA, b), imp(h, p)))


def quantifiers(t):
    return (t.tag in ("forall", "exists")) + sum(quantifiers(c) for c in t.children)


def quantifier_depth(t):
    return (t.tag in ("forall", "exists")) + max(
        (quantifier_depth(c) for c in t.children), default=0)


def render(t):
    if t.tag == "var":
        return t.name
    if t.tag in ("zero", "false"):
        return "0" if t.tag == "zero" else "false"
    if t.tag == "recursor":
        return "R[" + render(t.body) + "](" + ",".join(map(render, t.children)) + ")"
    if t.tag in ("forall", "exists"):
        return t.tag + " " + t.name + " (" + render(t.children[0]) + ")"
    name = t.name if t.tag == "function" else t.tag
    return name + "(" + ",".join(map(render, t.children)) + ")"


def profile(u):
    return {"m": size(u), "W": size(u, True),
            "i": occurrences(u, "n"), "j": occurrences(u, "a")}


def build_cases():
    cases = [ZERO, n, a, ONE, S(n), S(a), rec(w, n, a),
             rec(v, n, a), rec(pred(v), n, a),
             rec(w, S(n), a), rec(w, S(rec(v, n, a)), a),
             ite(n, a, S(n), a)]
    rng = random.Random(20261102)
    bodies = [v, w, ZERO, S(v), S(w), pred(v), rec(w, v, w),
              ite(v, ZERO, w, S(v))]

    def generate(depth):
        if depth == 0 or rng.random() < 0.30:
            return rng.choice([ZERO, n, a])
        choice = rng.randrange(3)
        if choice == 0:
            return S(generate(depth - 1))
        if choice == 1:
            return rec(rng.choice(bodies), generate(depth - 1), generate(depth - 1))
        return ite(generate(depth - 1), generate(depth - 1),
                   generate(depth - 1), generate(depth - 1))

    cases.extend(generate(4) for _ in range(500))
    # Distinct raw syntax, including descriptor variants, matters here.
    return list(dict.fromkeys(cases))


def audit_case(u):
    p = profile(u)
    m, W, i, j = (p[key] for key in ("m", "W", "i", "j"))
    schemas = {
        "orbit_core": (orbit(u), 29 + 2*m + 2*i, 29 + (6+i)*W + 2*i),
        "orbit_exists_fused": (orbit(u, "exists"), 46 + 2*m + 2*i,
                                46 + (6+i)*W + 2*i),
        "orbit_predecessor_fused": (orbit(u, "pred"), 47 + 2*m + 2*i,
                                     48 + (6+i)*W + 2*i),
        "orbit_direct_core": (orbit(u, direct=True), 33 + m + 2*i,
                               33 + (6+i)*W + 2*i),
        "shifted_orbit_core": (shifted_orbit(u), 34 + 3*m + 2*i + j,
                                34 + (7+i)*W + 2*i + j),
        "constancy_published": (constancy(u), 25 + 5*m + 3*i,
                                 25 + (7+i)*W + 3*i),
        "constancy_factored": (constancy(u, False), 18 + 5*m + 3*i,
                                18 + (7+i)*W + 3*i),
        "equality_bit_published": (zero_induction(u), 33 + 5*m + 3*i,
                                    33 + (7+i)*W + 3*i),
        "equality_bit_factored": (zero_induction(u, False), 26 + 5*m + 3*i,
                                   26 + (7+i)*W + 3*i),
        "mask_published": (mask(u), 35 + 4*m + 3*i, 35 + (6+i)*W + 3*i),
        "mask_factored": (mask(u, False), 28 + 4*m + 3*i,
                           28 + (6+i)*W + 3*i),
        "mask_fused": (mask(u, True, True), 45 + 4*m + 3*i,
                        45 + (6+i)*W + 3*i),
        "four_occurrence_core": (four_occurrence(u), 32 + 4*m + 3*i,
                                  32 + (6+i)*W + 3*i),
        "four_occurrence_fused": (four_occurrence(u, True), 47 + 4*m + 3*i,
                                   51 + (6+i)*W + 3*i),
    }
    if u == ZERO:
        schemas["equality_bit_exceptional"] = (exceptional_bit(u), 38, 40)
    else:
        schemas["equality_bit_exceptional"] = (
            exceptional_bit(u), 26 + 5*m + 3*i, 26 + (7+i)*W + 3*i)
    H = size(root_prune(descriptor(u)), True)
    if j == 0:
        za = (22+m, 22+W+3*H)
    else:
        za = (35+7*m+4*i, 35+7*W+4*i+(2+i)*H)
    schemas["zero_anchor_published"] = (zero_anchor(u), *za)
    if i == 0:
        zap = (20+m, 20+W+2*H)
    elif j == 0:
        zap = (22+m, 22+W+3*H)
    else:
        zap = (35+7*m+4*i, 35+7*W+4*i+(2+i)*H)
    schemas["zero_anchor_optional_pruning"] = (zero_anchor(u, True), *zap)

    measured = {}
    for name, (formula, expected_active, expected_expanded) in schemas.items():
        actual = (size(formula), size(formula, True))
        assert actual == (expected_active, expected_expanded), (
            name, render(u), p, actual, (expected_active, expected_expanded))
        measured[name] = {"active": actual[0], "expanded": actual[1],
                          "quantifiers": quantifiers(formula),
                          "quantifier_depth": quantifier_depth(formula)}

    # Compare equally factored presentations, including each fixed kernel once.
    main_active = measured["orbit_core"]["active"] + size(SIGMA) + size(COV_EXISTS)
    main_full = measured["orbit_core"]["expanded"] + size(SIGMA, True) + size(COV_EXISTS, True)
    mask_active = measured["mask_factored"]["active"] + size(SIGMA) + size(OFF)
    mask_full = measured["mask_factored"]["expanded"] + size(SIGMA, True) + size(OFF, True)
    assert mask_active - main_active == 2*m+i > 0
    assert mask_full - main_full == i >= 0
    assert (measured["mask_fused"]["active"]
            - measured["orbit_exists_fused"]["active"]) == 2*m+i-1 > 0
    assert (measured["mask_fused"]["expanded"]
            - measured["orbit_exists_fused"]["expanded"]) == i-1
    return {"term": render(u), "profile": p, "schemas": measured,
            "normalized_mask_comparison": {
                "active_saving": mask_active-main_active,
                "expanded_saving": mask_full-main_full}}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parent.parent / "verification" / "syntax_results.json")
    args = parser.parse_args()
    fixed = {"separation": SIGMA, "coverage_exists": COV_EXISTS,
             "coverage_predecessor": COV_PRED, "mask_off": OFF,
             "bit_graph": BIT_GRAPH, "bit_normalized": BIT_NORMALIZED,
             "subtraction_diagonal": DIAGONAL}
    expected = {"separation": (6,6), "coverage_exists": (10,10),
                "coverage_predecessor": (11,12), "mask_off": (11,11),
                "bit_graph": (24,24), "bit_normalized": (18,18),
                "subtraction_diagonal": (8,12)}
    for name, formula in fixed.items():
        assert (size(formula), size(formula, True)) == expected[name]

    stored = rec(w, v, ZERO)
    term = rec(stored, n, a)
    changed = subst(term, {"n": S(a), "a": ZERO, "v": S(v), "w": ZERO})
    assert changed.body is stored
    assert changed.children == (S(a), ZERO)
    assert occurrences(term, "v") == occurrences(term, "w") == 0
    assert subst(n, {"n": a, "a": ZERO}) == a  # simultaneous, not cascading

    results = [audit_case(u) for u in build_cases()]
    summary = {
        "status": "passed",
        "scope": "Finite AST identities and frozen-descriptor substitution; not a formal proof of PRA equivalence.",
        "seed": 20261102,
        "distinct_cases": len(results),
        "schemas_per_case": len(results[0]["schemas"]),
        "fixed_axioms": {name: {"active": size(formula), "expanded": size(formula, True)}
                         for name, formula in fixed.items()},
        "formulas": {
            "orbit_core_active": "29+2m+2i",
            "orbit_core_expanded": "29+(6+i)W+2i",
            "orbit_exists_fused_active": "46+2m+2i",
            "orbit_exists_fused_expanded": "46+(6+i)W+2i",
            "orbit_predecessor_fused_active": "47+2m+2i",
            "orbit_predecessor_fused_expanded": "48+(6+i)W+2i",
            "mask_minus_orbit_including_fixed_kernel_active": "2m+i",
            "mask_minus_orbit_including_fixed_kernel_expanded": "i",
        },
        "frozen_substitution_checks": "passed",
        "cases": results,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({key: summary[key] for key in ("status", "distinct_cases", "schemas_per_case", "formulas")}, indent=2))


if __name__ == "__main__":
    main()
