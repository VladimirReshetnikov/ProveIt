#!/usr/bin/env python3
"""Finite diagnostics for the report's actual scalar recurrences.

The universal/nonstandard-carrier theorems are proved in report.tex.
These finite natural-number checks are not a formal proof of them.
"""
from __future__ import annotations

from functools import lru_cache
import json
from pathlib import Path


def rec(h, n, a):
    state = a
    for counter in range(n):
        state = h(state, counter)
    return state


def Q(n, a):
    return rec(lambda v, w: w, n, a)


def pred(n):
    return Q(n, 0)


@lru_cache(maxsize=None)
def add(x, y):
    return rec(lambda v, w: v + 1, y, x)


@lru_cache(maxsize=None)
def minus(x, y):
    return rec(lambda v, w: max(v - 1, 0), y, x)


@lru_cache(maxsize=None)
def triangular(n):
    return rec(lambda v, w: add(v, w + 1), n, 0)


def counter_values(last):
    """Share prefix values while implementing precisely q's scalar update."""
    values = [0]
    for w in range(last):
        v = values[-1]
        values.append(v + 1 if w + 1 == triangular(v + 1) else v)
    return values


def run():
    assertions = 0
    bound = 40
    for x in range(bound + 1):
        assert pred(x + 1) == x
        assertions += 1
        for y in range(bound + 1):
            assert add(0, y) == y
            assert add(x + 1, y) == add(x, y) + 1
            assert minus(x + 1, y + 1) == minus(x, y)
            assert minus(max(x - 1, 0), y) == max(minus(x, y) - 1, 0)
            assert minus(add(x, y), y) == x
            assert minus(add(x, y), x) == y
            assert minus(y, add(x, y)) == 0
            assertions += 7

    last = triangular(2 * bound) + bound
    q = counter_values(last)
    for b in range(2 * bound):
        assert q[triangular(b)] == b
        assertions += 1
        for j in range(b + 1):
            assert q[add(triangular(b), j)] == b
            assertions += 1

    pairs = 0
    for x in range(bound + 1):
        for y in range(bound + 1):
            code = add(triangular(add(x, y)), y)
            right = minus(code, triangular(q[code]))
            left = minus(q[code], right)
            assert (left, right) == (x, y)
            assertions += 1
            pairs += 1

    predicates = {
        'true': lambda n, b: True,
        'false': lambda n, b: False,
        'equality': lambda n, b: n == b,
        'initial_segment': lambda n, b: n <= b,
        'final_segment': lambda n, b: n >= b,
        'parity': lambda n, b: (n + b) % 2 == 0,
    }
    reflection_cases = 0
    for A in predicates.values():
        def latch(v, w):
            return v if A(w, pred(v)) else 0
        for b in range(12):
            seed = b + 1
            for w in range(15):
                for v in range(20):
                    assert (latch(v, w) == seed) == (v == seed and A(w, b))
                    reflection_cases += 1
                    assertions += 1
                post = rec(latch, w + 1, seed)
                assert post != seed or A(w, b)
                assertions += 1

    return {
        'status': 'passed',
        'scope': 'Finite standard-N diagnostics only; the paper and abstract Lean kernels carry the unbounded arguments.',
        'arithmetic_bound': bound,
        'pairing_cases': pairs,
        'largest_pairing_code': last,
        'latch_predicates': list(predicates),
        'arbitrary_old_state_reflection_cases': reflection_cases,
        'assertions': assertions,
    }


if __name__ == '__main__':
    result = run()
    target = Path(__file__).resolve().parents[1] / 'verification' / 'arithmetic_results.json'
    target.parent.mkdir(exist_ok=True)
    target.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
