"""Portable untrusted local-scope validation; the kernel never imports this file.

Named substitution is inherited from the supplied scope draft's independent
validation module. Source certificates are replayed in its frozen demand
kernel, extracted to a derivation tree, and recompiled with lexical names.
"""
from copy import deepcopy
import ast
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import random
import subprocess
import sys
import tokenize
import types

HERE = Path(__file__).resolve().parent
BASE = HERE / 'source'
ROOT = HERE.parent


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


support = load(BASE / 'validation/run.py', 'source_independent_named_support')
source = load(BASE / 'checker.py', 'source_global_demand')
NamedSyntax = support.NamedSyntax
names = support.negative_names
holes = support.used_holes
substitute = support.substitute_names


def opening(a, images=(), formula=True, boundary=0):
    syntax = NamedSyntax()
    tree = (syntax.formula if formula else syntax.term)(a, holes=len(images))
    if any(n < boundary for n in names(tree)):
        raise ValueError('parameter outside lexical boundary')
    replacements = {}
    for index in holes(tree):
        image = syntax.term(images[index])
        if any(n < boundary for n in names(image)):
            raise ValueError('image parameter outside lexical boundary')
        replacements[index] = image
    result = substitute(tree, replacements)
    return (syntax.formula_data if formula else syntax.term_data)(result)


class LocalOracle:
    """Rule interpreter with named binders and explicit freshness checks."""
    def __init__(self, stack):
        self.stack = deepcopy(stack)
        self.allocations = []

    def check(self, goal, context):
        limit = -len(context)
        opening(goal, boundary=limit)
        for assumption in context:
            opening(assumption, boundary=limit)
        instruction = self.stack.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            if not self.check(major, context):
                return goal in context
            if len(major) == 3:
                eigen = limit - 1
                relevant = [goal, major, *context]
                assert all(eigen not in names(NamedSyntax().formula(a)) for a in relevant)
                self.allocations.append((len(context), eigen, 1))
                instance = opening(major[0], [eigen], boundary=eigen)
                return self.check(goal, context + [instance])
            if len(major) == 1:
                motive, images = major[0], [0, annotation]
            else:
                motive, images = annotation, major
            base, result = [opening(motive, [image], boundary=limit) for image in images]
            return result == goal and self.check(base, context)
        if len(goal) == 1 and instruction == []:
            body = goal[0]
            base = opening(body, [0], boundary=limit)
            eigen = limit - 1
            relevant = [goal, *context]
            assert all(eigen not in names(NamedSyntax().formula(a)) for a in relevant)
            assumptions = [base]
            if len(body) == 2:
                assumptions.append(opening(body, [eigen], boundary=eigen))
            step = opening(body, [[eigen]], boundary=eigen)
            self.allocations.append((len(context), eigen, len(assumptions)))
            return self.check(step, context + assumptions)
        if len(goal) == 3 and type(instruction) is list and len(instruction) == 1:
            return self.check(opening(goal[0], instruction, boundary=limit), context)
        if len(goal) == 2 and type(goal[0]) is list and len(goal[0]) == 3 and instruction == []:
            counter, initial, update = goal[0]
            expected = initial
            if counter != 0:
                if type(counter) is not list or len(counter) != 1:
                    raise ValueError('bad computation counter')
                previous = counter[0]
                expected = opening(update, [[previous, initial, update], previous], False, limit)
            return goal[1] == expected
        return goal in context


def verdict(module, goal, stack, context=()):
    stack = deepcopy(stack)
    module.take = stack.pop
    try:
        return bool(module.check(deepcopy(goal), deepcopy(list(context)))), len(stack)
    except Exception:
        return False, len(stack)


def oracle_verdict(goal, stack, context=()):
    oracle = LocalOracle(stack)
    try:
        return bool(oracle.check(deepcopy(goal), deepcopy(list(context)))), len(oracle.stack)
    except AssertionError:
        raise
    except Exception:
        return False, len(oracle.stack)


def source_trace(goal, context, stack):
    """Replay successful rules in the unchanged global source kernel.

    Trees omit failed guarded attempts that only led to hypothesis fallback.
    Such failed attempts affect source consumption but have no proof content.
    """
    source.inst(goal)
    instruction = stack.pop()
    if type(instruction) is list and len(instruction) == 2:
        major, annotation = instruction
        major_tree = source_trace(major, context, stack)
        if major_tree is not None:
            if len(major) == 3:
                source.k -= 1
                eigen = source.k
                child = source_trace(goal, context + [source.inst(major[0], [eigen])], stack)
                if child is not None:
                    return ('EE', goal, instruction, eigen, major_tree, child)
                return None
            if len(major) == 1:
                motive, images, rule = major[0], (0, annotation), 'QE'
            else:
                motive, images, rule = annotation, major, 'EQ'
            base, result = (source.inst(motive, [image]) for image in images)
            if result != goal:
                return None
            minor_tree = source_trace(base, context, stack)
            return None if minor_tree is None else (rule, goal, instruction, None, major_tree, minor_tree)
        return ('H', goal, None) if goal in context else None
    if len(goal) == 1 and instruction == []:
        body = goal[0]
        local = [source.inst(body, [0]), body][:2 - len(body) % 2]
        source.k -= 1
        eigen = source.k
        step = source.inst(body, [[eigen]])
        new_context = context + [source.inst(c, [eigen]) for c in local]
        child = source_trace(step, new_context, stack)
        return None if child is None else ('QI', goal, [], eigen, child)
    if len(goal) == 3 and type(instruction) is list and len(instruction) == 1:
        child = source_trace(source.inst(goal[0], instruction), context, stack)
        return None if child is None else ('EI', goal, instruction, None, child)
    if len(goal) == 2 and type(goal[0]) is list and len(goal[0]) == 3 and instruction == []:
        counter, initial, update = goal[0]
        if counter:
            counter, = counter
            initial = source.inst(update, ([counter, initial, update], counter), d=1)
        return ('R', goal, []) if goal[1] == initial else None
    return ('H', goal, None) if goal in context else None


def rename(data, scope):
    if type(data) is int and data < 0:
        return scope.get(data, 0)
    if type(data) is list:
        return [rename(x, scope) for x in data]
    return data


def compile_tree(tree, size=0, scope=None):
    if scope is None:
        scope = {}
    rule, goal, instruction, *rest = tree
    goal, instruction = rename(goal, scope), rename(instruction, scope)
    if rule in ('H', 'R'):
        return goal, [instruction]
    eigen, *children = rest
    if rule == 'QI':
        next_scope = {**scope, eigen: -size - 1}
        increment = 2 if len(goal[0]) == 2 else 1
        _, stream = compile_tree(children[0], size + increment, next_scope)
        return goal, stream + [instruction]
    if rule == 'EI':
        _, stream = compile_tree(children[0], size, scope)
        return goal, stream + [instruction]
    major, major_stream = compile_tree(children[0], size, scope)
    if rule == 'EE':
        _, minor_stream = compile_tree(children[1], size + 1, {**scope, eigen: -size - 1})
    else:
        _, minor_stream = compile_tree(children[1], size, scope)
    return goal, minor_stream + major_stream + [[major, instruction[1]]]


def reflexivity(t):
    axiom = [[0, t, 0], t]
    return [[], [], [axiom, [1, t]]]


def trivial(goal, context=()):
    context = list(context)
    limit = -len(context)
    opening(goal, boundary=limit)
    if goal in context:
        return [None]
    if len(goal) == 2:
        if goal[0] != goal[1]:
            raise ValueError('nonreflexive goal')
        return reflexivity(goal[0])
    if len(goal) == 1:
        body = goal[0]
        local = [opening(body, [0], boundary=limit)]
        if len(body) == 2:
            local.append(opening(body, [limit - 1], boundary=limit - 1))
        step = opening(body, [[limit - 1]], boundary=limit - 1)
        return trivial(step, context + local) + [[]]
    if len(goal) == 3:
        return trivial(opening(goal[0], [0], boundary=limit), context) + [[0]]
    raise ValueError('invalid goal')


def exists_reflexive(witness):
    goal = [[1, 1], [0, 0], [0, 0]]
    return goal, reflexivity(witness) + [[witness]]


def add_redundant_exists(goal, stack, size, witness=0):
    major, major_stack = exists_reflexive(witness)
    return stack + major_stack + [[major, None]]


def main():
    kernels = {'checker_local.py': load(ROOT / 'checker_local.py', 'delivered_local_kernel')}
    results = {'kernels': sorted(kernels),
               'kernel_sha256': hashlib.sha256((ROOT / 'checker_local.py').read_bytes()).hexdigest(),
               'inherited': [], 'focused': [], 'mutants': []}
    records = json.loads((BASE / 'validation/reference/source_corpus.json').read_text())
    output = ROOT / 'examples/local'
    output.mkdir(parents=True, exist_ok=True)
    for index, record in enumerate(records):
        goal, stack, *context = support.encode_tagged(record['certificate'])
        source.k = 0
        for h in context:
            source.inst(h)
        source.take = deepcopy(stack).pop
        assert source.check(goal, context)
        source.k = 0
        for h in context:
            source.inst(h)
        tree = source_trace(goal, context, deepcopy(stack))
        assert tree is not None
        new_goal, new_stack = compile_tree(tree, len(context))
        new_context = rename(context, {})
        expected = oracle_verdict(new_goal, new_stack, new_context)
        assert expected == (True, 0), ('named oracle failed translated source', index, expected)
        for label, module in kernels.items():
            assert verdict(module, new_goal, new_stack, new_context) == expected, (label, index)
        if not context:
            (output / ('inherited_%03d.json' % index)).write_text(json.dumps(new_stack + [new_goal]) + '\n')
        results['inherited'].append({'index': index, 'public': not context, 'cells': len(new_stack), 'all_accepted': True})

    taut = [0, 0]
    ex_refl, ex_zero = exists_reflexive(0)
    nested = [[[1, 1]]]
    # Global sequential freshness used to retain -1 after the left scope ended.
    # The local policy deliberately rejects that reference in the later sibling.
    earlier = add_redundant_exists(taut, reflexivity(0), 0)
    later = add_redundant_exists(taut, reflexivity(0), 0, -1)
    sibling_leak = later + earlier + [[taut, taut]]
    equal_zero_major = [[1, 0], [0, 0], [0, 0]]
    local_minor = [None, None, [[-1, 0], [1, 0]]]
    scoped_equality = local_minor + reflexivity(0) + [[0], [equal_zero_major, None]]
    sibling_reuse = scoped_equality + scoped_equality + [[taut, taut]]
    # Equation QI adds two assumptions. -2 is a harmless spare parameter;
    # the next actual eigenparameter must be -3.
    equation_body = [1, 1]
    gap_step = add_redundant_exists([[-1], [-1]], reflexivity([-1]), 2, -2)
    gap_goal, gap_stack = [equation_body], gap_step + [[]]
    # Explicitly attempt the classic capture by passing an unbound positive
    # coordinate beneath a retained quantifier.
    invalid_capture_goal = [[[1, 0]], [0, 0], [0, 0]]
    specifications = [
        ('reflexivity', taut, reflexivity(0), True),
        ('nested_closures', nested, trivial(nested), True),
        ('root_parameter', [-1, -1], reflexivity(-1), False),
        ('root_parameter_in_annotation', [[0, 0], [-1, -1], [0, 0]], reflexivity(0) + [[0]], False),
        ('forward_used_witness', ex_refl, reflexivity(-1) + [[-1]], False),
        ('unused_future_witness', [[0, 0], [0, 0], [0, 0]], reflexivity(0) + [[-999]], True),
        ('sibling_scope_does_not_declare_parameter', taut, sibling_leak, False),
        ('same_eigenparameter_reused_in_sibling_scopes', taut, sibling_reuse, True),
        ('equation_gap_parameter_and_fresh_next_scope', gap_goal, gap_stack, True),
        ('fresh_decrement_is_necessary', [[[1, 0, 2], 0]], [[], []], False),
        ('false_closed_equation', [0, [0]], reflexivity(0), False),
        ('malformed_zero_length_formula', [], [None], False),
        ('malformed_binary_term', [[0, 0], [0, 0]], [None], False),
        ('positive_root_coordinate', [1, 1], reflexivity(1), False),
        ('boolean_root_term', [True, True], reflexivity(True), False),
        ('floating_root_term', [0.0, 0.0], reflexivity(0.0), False),
        ('invalid_inert_annotation', [[0, 0], False, [0, 0]], reflexivity(0) + [[0]], False),
        ('unread_prefix', taut, ['ignored', -999, None] + reflexivity(0), True),
    ]
    inherited_audits = json.loads((BASE / 'validation/artifacts/audit_cases.json').read_text())
    for record in inherited_audits:
        # Fresh-name schedules differ; use all negative controls only.
        if not record['expected_demand']:
            specifications.append(('inherited_attack/' + record['name'], record['goal'], record['proof'], False))
    for name, goal, stack, expected in specifications:
        named = oracle_verdict(goal, stack)
        assert named[0] == expected, ('oracle fixture mismatch', name, named, expected)
        for label, module in kernels.items():
            result = verdict(module, goal, stack)
            assert result == named, ('kernel/oracle fixture mismatch', label, name, result, named)
        filename = name.replace('/', '__') + '.json'
        (output / filename).write_text(json.dumps(stack + [goal]) + '\n')
        results['focused'].append({'name': name, 'expected': expected, 'all_matched': True})

    # Generated nested Q/E spines exercise the combination of unary logical
    # binding, ternary recursor binding, annotations, and lexical allocation.
    rng = random.Random(202611072)
    generated = []
    for index in range(120):
        depth = rng.randrange(1, 9)
        term = [0, 0, [0, 0, 4]] if index % 3 == 0 else 0
        goal = [term, term]
        for _ in range(depth):
            goal = [goal] if rng.randrange(2) else [goal, [0, 0], [0, 0]]
        stack = trivial(goal)
        expected = oracle_verdict(goal, stack)
        assert expected == (True, 0)
        for label, module in kernels.items():
            assert verdict(module, goal, stack) == expected, (label, 'generated', index)
        generated.append({'index': index, 'depth': depth, 'cells': len(stack)})
    results['generated'] = generated

    # A bounded malformed-tree campaign compares public no-proof acceptance
    # and context-sensitive hypothesis acceptance with the named parser.
    atoms = [None, True, False, 0.0, '0', {}, [], 0, 1, 2, -1, -2, -3]
    candidates = list(atoms)
    for _ in range(400):
        candidates.append([deepcopy(rng.choice(candidates[:70])) for _ in range(rng.randrange(5))])
    boundary_count = 0
    for goal in candidates:
        for size in range(4):
            context = [goal] + [[0, 0]] * (size - 1) if size else []
            expected = oracle_verdict(goal, [None], context)
            for label, module in kernels.items():
                assert verdict(module, goal, [None], context) == expected, (label, 'grammar', size, goal, expected)
            boundary_count += 1
    results['grammar_boundary_comparisons'] = boundary_count

    # Positive controls show the controls detect deleting the name boundary,
    # or trusting a used, potentially captured substitution image.
    base_text = (ROOT / 'checker_local.py').read_text()
    mutants = [
        ('name_boundary_deleted', base_text.replace(' and a >= k', ''),
         next(s for s in specifications if s[0] == 'root_parameter')),
        ('image_validation_deleted', base_text.replace('else inst(e[a - d - 1], s=0)', 'else e[a - d - 1]'),
         next(s for s in specifications if s[0].endswith('capture_by_illegal_positive_witness'))),
        ('fresh_decrement_deleted', base_text.replace('    k -= 1\n', ''),
         next(s for s in specifications if s[0] == 'fresh_decrement_is_necessary')),
    ]
    for name, text, fixture in mutants:
        module = types.ModuleType(name)
        exec(compile(text, name, 'exec'), module.__dict__)
        fixture_name, goal, stack, _ = fixture
        actual = verdict(module, goal, stack)[0]
        assert actual, ('positive mutant control did not fire', name, fixture_name)
        results['mutants'].append({'mutation': name, 'fixture': fixture_name, 'mutant_accepted': actual})

    cli_rows = []
    for label in kernels:
        for name in ['reflexivity', 'equation_gap_parameter_and_fresh_next_scope',
                     'root_parameter', 'sibling_scope_does_not_declare_parameter',
                     'same_eigenparameter_reused_in_sibling_scopes', 'fresh_decrement_is_necessary']:
            expected = next(s[3] for s in specifications if s[0] == name)
            for optimized in (False, True):
                command = [sys.executable, *(['-O'] if optimized else []), str(ROOT / label), str(output / (name + '.json'))]
                p = subprocess.run(command, text=True, capture_output=True)
                assert p.returncode == (0 if expected else 1) and p.stdout.strip() == ('ACCEPT' if expected else 'REJECT')
                cli_rows.append({'kernel': label, 'case': name, 'accepted': expected, 'optimized': optimized})
    results['cli'] = cli_rows
    results['status'] = 'all checks passed'
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results/results_local.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps({key: len(results[key]) for key in ['kernels', 'inherited', 'focused', 'generated', 'mutants', 'cli']}))
    print(json.dumps({'grammar_boundary_comparisons': boundary_count, 'status': results['status']}))


if __name__ == '__main__':
    main()
