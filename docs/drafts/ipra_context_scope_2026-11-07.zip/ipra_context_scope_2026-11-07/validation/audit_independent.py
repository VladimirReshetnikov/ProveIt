"""Independent finite CLI audit of the two delivered iPRA kernels.

No kernel opening or checking function is imported. All certificates below are
constructed directly from the documented syntax. Both ordinary and optimized
Python are exercised. The raw-image mutation is a deliberately unsound control,
created only in a temporary directory; it is not a candidate verifier.
"""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
KERNELS = {'global': ROOT / 'checker.py', 'local': ROOT / 'checker_local.py'}


def refl(term):
    """Instructions proving t=t by two R0 axioms and equality transport.

    term must be locally closed; these tests supply concrete closed trees
    or negative rigid parameter names, never a dangling positive coordinate.
    """
    major = [[0, term, 0], term]
    return [[], [], [major, [1, term]]]


def exists(matrix, left=None, right=None):
    return [matrix, [0, 0] if left is None else left,
            [0, 0] if right is None else right]


def q_refl(name):
    # Q x(x=x); its equation-introduction step proves S(name)=S(name).
    return refl([name]) + [[]]


def pack(instructions, goal):
    return instructions + [goal]


def test_cases():
    cases = []

    def add(name, data, global_result, local_result=None):
        cases.append({'name': name, 'document': data,
                      'expected': {'global': global_result,
                                   'local': global_result if local_result is None
                                   else local_result}})

    zero = [0, 0]
    qr = [[1, 1]]
    exr = exists([1, 1])
    add('recursion_zero', [[], [[0, 0, 0], 0]], True)
    add('recursion_successor_previous_value',
        [[], [[[0], 0, 1], [0, 0, 1]]], True)
    add('recursion_successor_previous_counter',
        [[], [[[0], 0, 2], 0]], True)
    inner = [0, 0, 3]
    previous = [0, 0, inner]
    add('nested_update_simultaneous_opening',
        [[], [[[0], 0, inner], [0, 0, previous]]], True)
    add('reflexivity_zero', pack(refl(0), zero), True)
    add('reflexivity_successor', pack(refl([0]), [[0], [0]]), True)
    add('equation_closure_introduction', pack(q_refl(-1), qr), True)
    add('existential_introduction', pack(refl(0) + [[0]], exr), True)

    # Q x E y(x=x); the compound introduction has only its retained base.
    compound_body = exists([2, 2])
    add('compound_closure_introduction',
        pack(refl([-1]) + [[0], []], [compound_body]), True)

    exzero = exists([1, 0])
    # E elimination opens x=0; transport the same assumption along itself.
    minor = [None, None, [[-1, 0], [1, 0]]]
    major = refl(0) + [[0]]
    add('existential_elimination_and_hypothesis_transport',
        pack(minor + major + [[exzero, None]], zero), True)
    add('closure_elimination',
        pack(refl(0) + q_refl(-1) + [[qr, 0]], zero), True)

    # The following pair verifies that the scope policies really differ.
    local_minor = refl(0) + q_refl(-1) + [[qr, 0]]
    global_minor = refl(0) + q_refl(-2) + [[qr, 0]]
    add('sibling_name_reuse_local_certificate',
        pack(local_minor + q_refl(-1) + [[qr, 0]], zero), False, True)
    add('distinct_sibling_names_global_certificate',
        pack(global_minor + q_refl(-1) + [[qr, 0]], zero), True, False)

    # An equation introduction appends two hypotheses, allowing auxiliary
    # parameter -2 in the local child even though its eigenparameter is -1.
    successor_equation = [[-1], [-1]]
    spare_step = (refl([-1]) + refl(-2)
                  + [[[-2, -2], successor_equation]])
    add('spare_local_name_is_an_auxiliary_parameter',
        pack(spare_step + [[]], qr), False, True)
    future_step = (refl([-1]) + refl(-3)
                   + [[[-3, -3], successor_equation]])
    add('name_below_local_and_global_boundary',
        pack(future_step + [[]], qr), False)

    add('open_root_rejected', pack(refl(-1), [-1, -1]), False)
    add('false_equation_rejected', pack(refl(0), [0, [0]]), False)
    add('wrong_zero_computation_rhs', [[], [[0, 0, 0], [0]]], False)
    add('wrong_successor_computation_rhs',
        [[], [[[0], 0, 2], [0]]], False)
    variable_counter_major = [[-1, 0, 1], 0]
    add('variable_counter_is_not_a_computation_redex',
        pack(refl([-1]) + [[]]
             + [[variable_counter_major, successor_equation], []], qr), False)
    add('positive_coordinate_at_closed_root', pack(refl(0), [1, 1]), False)
    add('empty_instruction_stream', [[0, 0]], False)
    add('unproved_hypothesis', [None, zero], False)
    add('malformed_equality_motive',
        pack(refl(0) + refl(0) + [[[0, 0], [1, 2]]], zero), False)

    # No B(y) hypothesis is available for compound Q matrices.
    body = exists([1, 2])
    unavailable_hypothesis = exists([1, -1])
    add('compound_matrix_has_no_induction_hypothesis',
        pack([None, [unavailable_hypothesis, None], []], [body]), False)

    add('unread_prefix_is_inert',
        [{'not': 'active syntax'}, [True, None]] + pack(refl(0), zero), True)
    for index, value in enumerate([None, True, 1.5, 'x', {'x': 0}, 1, -1]):
        add('used_bad_witness_%02d' % index,
            pack(refl(0) + [[value]], exr), False)
        add('unused_witness_%02d' % index,
            pack(refl(0) + [[value]], exists(zero)), True)

    # Existential padding is inert logically but must still be well-formed.
    for index, value in enumerate([None, True, 0, [], [0], [0, 0, 0, 0]]):
        add('malformed_existential_padding_%02d' % index,
            pack(refl(0) + [[0]], [zero, value, zero]), False)

    # Opening a Q matrix traverses inert E fields too. Here the witness is
    # absent from the active E equation but present in an inactive matrix.
    matrix = exists(zero, [2, 2])
    qmajor = [matrix]
    qmajor_proof = refl(0) + [[0], []]
    base_proof = refl(0) + [[0]]
    add('used_witness_in_opened_inert_matrix_is_checked',
        pack(base_proof + qmajor_proof + [[qmajor, None]], exists(zero)), False)

    for index, value in enumerate([None, True, 1.5, 'x', {'x': 0}, 0,
                                   [], [0], [0, 0, 0, 0], [[0, 0], 0]]):
        add('malformed_closed_goal_%02d' % index, [None, value], False)
    add('invalid_binary_term_arity', [[], [[0, [0, 0], 0], [0, 0]]], False)
    add('null_update_body', [[], [[0, 0, None], 0]], False)
    add('dangling_update_coordinate', [[], [[0, 0, 3], 0]], False)

    attack = json.loads((ROOT / 'validation' / 'experiments'
                         / 'capture_counterexample.json').read_text())
    add('capture_counterexample', attack, False)
    return cases


def cli(program, path, optimized):
    command = [sys.executable]
    if optimized:
        command.append('-O')
    command.extend([str(program), str(path)])
    proc = subprocess.run(command, cwd=ROOT, capture_output=True, text=True,
                          timeout=15)
    response = (proc.returncode, proc.stdout.strip(), proc.stderr.strip())
    if response == (0, 'ACCEPT', ''):
        return True
    if response == (1, 'REJECT', ''):
        return False
    raise AssertionError({'program': program.name, 'optimized': optimized,
                          'unexpected_process_response': response})


def main():
    cases = test_cases()
    names = [case['name'] for case in cases]
    if len(names) != len(set(names)):
        raise AssertionError('Duplicate semantic case names')
    rows = []
    with tempfile.TemporaryDirectory(prefix='ipra-independent-') as directory:
        temp = Path(directory)
        for index, case in enumerate(cases):
            path = temp / ('case_%03d.json' % index)
            path.write_text(json.dumps(case['document']) + '\n')
            for kernel_name, program in KERNELS.items():
                for optimized in (False, True):
                    observed = cli(program, path, optimized)
                    expected = case['expected'][kernel_name]
                    row = {'case': case['name'], 'kernel': kernel_name,
                           'optimized': optimized, 'expected_accept': expected,
                           'observed_accept': observed}
                    rows.append(row)
                    if observed != expected:
                        raise AssertionError(row)

        # Parser errors are checked as raw bytes, not pre-parsed JSON data.
        malformed_json = ['{', '[[],]', 'NaN', 'Infinity', '"scalar"']
        parser_rows = []
        for index, content in enumerate(malformed_json):
            path = temp / ('parser_%02d.json' % index)
            path.write_text(content)
            for kernel_name, program in KERNELS.items():
                for optimized in (False, True):
                    observed = cli(program, path, optimized)
                    row = {'case': index, 'kernel': kernel_name,
                           'optimized': optimized, 'observed_accept': observed}
                    parser_rows.append(row)
                    if observed:
                        raise AssertionError(row)

        # Deliberately remove exactly one image validation in a temporary copy.
        # This control must ACCEPT the six-cell false certificate, showing that
        # the adversarial test distinguishes the dangerous optimization.
        raw_source = KERNELS['global'].read_text()
        needle = 'else inst(env[a - d // 2 - 1], d=1)'
        if raw_source.count(needle) != 1:
            raise AssertionError('Raw-image mutation target changed')
        mutant = temp / 'unsound_raw_image_control.py'
        mutant.write_text(raw_source.replace(needle,
                                            'else env[a - d // 2 - 1]'))
        attack_path = ROOT / 'validation' / 'experiments' / 'capture_counterexample.json'
        mutant_rows = []
        for optimized in (False, True):
            observed = cli(mutant, attack_path, optimized)
            mutant_rows.append({'optimized': optimized, 'observed_accept': observed})
            if not observed:
                raise AssertionError('The unsound control no longer accepts the attack')

    result = {
        'status': 'PASS',
        'python': sys.version.split()[0],
        'kernels_sha256': {name: hashlib.sha256(path.read_bytes()).hexdigest()
                           for name, path in KERNELS.items()},
        'independent_certificate_cases': len(cases),
        'certificate_cli_runs': len(rows),
        'raw_parser_cases': len(malformed_json),
        'parser_cli_runs': len(parser_rows),
        'unsound_control_cli_runs': len(mutant_rows),
        'method': 'Direct concrete certificates; no kernel functions imported; normal and -O CLI runs.',
        'limits': 'Finite regression evidence, not a formal verification or exhaustive soundness proof.',
        'certificate_runs': rows,
        'parser_runs': parser_rows,
        'unsound_control_runs': mutant_rows,
    }
    destination = ROOT / 'results' / 'results_independent.json'
    destination.parent.mkdir(exist_ok=True)
    destination.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ('certificate_runs', 'parser_runs')}, indent=2))


if __name__ == '__main__':
    main()
