"""Check the report's exact six-cell capture counterexample.

Mutations exist only in memory. This script is untrusted validation support
and is never imported by either delivered acceptance kernel.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import types

import audit_local as support

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def verdict(module, document):
    document = deepcopy(document)
    module.k = 0
    module.take = document.pop
    try:
        return bool(module.check(module.take(), []))
    except Exception:
        return False


def main():
    fixture = HERE / 'experiments/capture_counterexample.json'
    document = json.loads(fixture.read_text())
    assert len(document) == 6
    rows = []
    specifications = [
        ('original_scope', HERE / 'source/checker.py', None, None),
        ('delivered_global', ROOT / 'checker.py',
         'else inst(env[a - d // 2 - 1], d=1)', 'else env[a - d // 2 - 1]'),
        ('delivered_local', ROOT / 'checker_local.py',
         'else inst(e[a - d - 1], s=0)', 'else e[a - d - 1]'),
    ]
    for label, path, before, after in specifications:
        module = support.load(path, 'capture_' + label)
        assert not verdict(module, document), (label, 'real checker accepted false sentence')
        row = {'kernel': label, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
               'real_checker_rejected': True}
        if before is not None:
            source = path.read_text()
            assert source.count(before) == 1
            mutant = types.ModuleType('capture_mutant_' + label)
            exec(compile(source.replace(before, after), mutant.__name__, 'exec'), mutant.__dict__)
            assert verdict(mutant, document), (label, 'capture control did not fire')
            row['image_validation_deleted_mutant_accepted'] = True
        rows.append(row)
    cli = []
    for name in ('checker.py', 'checker_local.py'):
        for optimized in (False, True):
            process = subprocess.run([sys.executable, *(['-O'] if optimized else []),
                                      str(ROOT / name), str(fixture)], text=True, capture_output=True)
            assert process.returncode == 1 and process.stdout.strip() == 'REJECT'
            cli.append({'kernel': name, 'optimized': optimized, 'rejected': True})
    result = {'status': 'all checks passed',
              'fixture': 'validation/experiments/capture_counterexample.json',
              'fixture_sha256': hashlib.sha256(fixture.read_bytes()).hexdigest(),
              'cells': 6, 'kernels': rows, 'cli': cli}
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results/results_capture.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'real_rejections': len(rows),
                      'mutant_acceptances': 2, 'cli_rejections': len(cli)}))


if __name__ == '__main__':
    main()
