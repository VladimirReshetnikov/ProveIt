"""Portable untrusted validation of the delivered global closed checker.

Compile successful source derivation trees with globally sequential names
in actual major-before-minor execution order. Renaming maps remain lexical:
a name allocated in a finished scope is not exported as an assumption.
The independent oracle uses named binding and explicit freshness checks.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import random
import subprocess
import sys
import types

import audit_local as local

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BASE = HERE / 'source'


def compile_global_tree(tree, scope=None, state=None):
    if scope is None:
        scope = {}
    if state is None:
        state = [0]
    rule, goal, instruction, *rest = tree
    goal = local.rename(goal, scope)
    instruction = local.rename(instruction, scope)
    if rule in ('H', 'R'):
        return goal, [instruction]
    old_eigen, *children = rest
    if rule == 'QI':
        state[0] -= 1
        _, child = compile_global_tree(children[0], {**scope, old_eigen: state[0]}, state)
        return goal, child + [instruction]
    if rule == 'EI':
        _, child = compile_global_tree(children[0], scope, state)
        return goal, child + [instruction]
    major, major_stream = compile_global_tree(children[0], scope, state)
    if rule == 'EE':
        state[0] -= 1
        _, minor_stream = compile_global_tree(children[1], {**scope, old_eigen: state[0]}, state)
    else:
        _, minor_stream = compile_global_tree(children[1], scope, state)
    return goal, minor_stream + major_stream + [[major, instruction[1]]]


class GlobalOracle:
    """Named-binder interpretation with a globally declared name boundary."""
    def __init__(self, stack, initial=0):
        self.stack = deepcopy(stack)
        self.k = initial
        self.allocations = []

    def opening(self, a, images=(), formula=True):
        return local.opening(a, images, formula, self.k)

    def allocate(self, relevant):
        self.k -= 1
        assert all(self.k not in local.names(local.NamedSyntax().formula(a)) for a in relevant)
        self.allocations.append(self.k)
        return self.k

    def check(self, goal, context):
        self.opening(goal)
        for assumption in context:
            self.opening(assumption)
        instruction = self.stack.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            if not self.check(major, context):
                return goal in context
            if len(major) == 3:
                eigen = self.allocate([goal, major, *context])
                instance = self.opening(major[0], [eigen])
                return self.check(goal, context + [instance])
            if len(major) == 1:
                motive, images = major[0], [0, annotation]
            else:
                motive, images = annotation, major
            base, result = [self.opening(motive, [image]) for image in images]
            return result == goal and self.check(base, context)
        if len(goal) == 1 and instruction == []:
            body = goal[0]
            base = self.opening(body, [0])
            eigen = self.allocate([goal, *context])
            assumptions = [base]
            if len(body) == 2:
                assumptions.append(self.opening(body, [eigen]))
            return self.check(self.opening(body, [[eigen]]), context + assumptions)
        if len(goal) == 3 and type(instruction) is list and len(instruction) == 1:
            return self.check(self.opening(goal[0], instruction), context)
        if len(goal) == 2 and type(goal[0]) is list and len(goal[0]) == 3 and instruction == []:
            counter, initial, update = goal[0]
            expected = initial
            if counter != 0:
                if type(counter) is not list or len(counter) != 1:
                    raise ValueError('bad computation counter')
                previous = counter[0]
                expected = self.opening(update, [[previous, initial, update], previous], False)
            return goal[1] == expected
        return goal in context


def verdict(module, goal, stream, context=(), initial=0):
    stack = deepcopy(stream)
    module.k = initial
    module.take = stack.pop
    try:
        return bool(module.check(deepcopy(goal), deepcopy(list(context)))), module.k, len(stack)
    except Exception:
        return False, module.k, len(stack)


def oracle_verdict(goal, stream, context=(), initial=0):
    oracle = GlobalOracle(stream, initial)
    try:
        return bool(oracle.check(deepcopy(goal), deepcopy(list(context)))), oracle.k, len(oracle.stack)
    except AssertionError:
        raise
    except Exception:
        return False, oracle.k, len(oracle.stack)


def main():
    path = ROOT / 'checker.py'
    kernel = local.load(path, 'delivered_global_kernel')
    results = {'kernel': 'checker.py', 'kernel_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
               'inherited': [], 'focused': [], 'mutants': [], 'cli': []}
    output = ROOT / 'examples/global'
    output.mkdir(parents=True, exist_ok=True)
    rows = json.loads((BASE / 'validation/reference/source_corpus.json').read_text())
    public = []
    for index, record in enumerate(rows):
        goal, stream, *context = local.support.encode_tagged(record['certificate'])
        local.source.k = 0
        for h in context:
            local.source.inst(h)
        local.source.take = deepcopy(stream).pop
        assert local.source.check(goal, context)
        local.source.k = 0
        for h in context:
            local.source.inst(h)
        tree = local.source_trace(goal, context, deepcopy(stream))
        assert tree is not None
        supply = [0]
        new_goal, new_stream = compile_global_tree(tree, state=supply)
        new_context = local.rename(context, {})
        expected = oracle_verdict(new_goal, new_stream, new_context)
        actual = verdict(kernel, new_goal, new_stream, new_context)
        assert actual == expected == (True, supply[0], 0), ('translated source mismatch', index, actual, expected, supply)
        if not context:
            name = 'inherited_%03d' % index
            (output / (name + '.json')).write_text(json.dumps(new_stream + [new_goal]) + '\n')
            public.append((name, True))
        results['inherited'].append({'index': index, 'public': not context, 'cells': len(new_stream),
                                     'final_supply': supply[0], 'accepted': True})

    truth = [0, 0]
    equal_zero_major = [[1, 0], [0, 0], [0, 0]]

    def scope(eigen):
        minor = [None, None, [[eigen, 0], [1, 0]]]
        return minor + local.reflexivity(0) + [[0], [equal_zero_major, None]]

    sibling_sequence = scope(-2) + scope(-1) + [[truth, truth]]
    sibling_repeated = scope(-1) + scope(-1) + [[truth, truth]]
    declared_reuse = local.add_redundant_exists(truth, local.reflexivity(0), 0, -1)
    future_reuse = local.add_redundant_exists(truth, local.reflexivity(0), 0, -2)
    first_scope = local.add_redundant_exists(truth, local.reflexivity(0), 0, 0)
    declared_sibling = declared_reuse + first_scope + [[truth, truth]]
    future_sibling = future_reuse + first_scope + [[truth, truth]]
    specifications = [
        ('reflexivity', truth, local.reflexivity(0), True),
        ('root_parameter', [-1, -1], local.reflexivity(-1), False),
        ('root_parameter_in_annotation', [[0, 0], [-1, -1], [0, 0]], local.reflexivity(0) + [[0]], False),
        ('forward_used_witness', [[1, 1], [0, 0], [0, 0]], local.reflexivity(-1) + [[-1]], False),
        ('unused_future_witness', [[0, 0], [0, 0], [0, 0]], local.reflexivity(0) + [[-999]], True),
        ('sequential_names_in_sibling_scopes', truth, sibling_sequence, True),
        ('repeated_local_name_in_global_trace', truth, sibling_repeated, False),
        ('declared_name_reused_without_assumption', truth, declared_sibling, True),
        ('future_name_used_before_declaration', truth, future_sibling, False),
        ('fresh_decrement_is_necessary', [[[1, 0, 2], 0]], [[], []], False),
        ('false_closed_equation', [0, [0]], local.reflexivity(0), False),
        ('malformed_zero_length_formula', [], [None], False),
        ('malformed_binary_term', [[0, 0], [0, 0]], [None], False),
        ('positive_root_coordinate', [1, 1], local.reflexivity(1), False),
        ('boolean_root_term', [True, True], local.reflexivity(True), False),
        ('floating_root_term', [0.0, 0.0], local.reflexivity(0.0), False),
        ('invalid_inert_annotation', [[0, 0], False, [0, 0]], local.reflexivity(0) + [[0]], False),
        ('unread_prefix', truth, ['ignored', -999, None] + local.reflexivity(0), True),
    ]
    audits = json.loads((BASE / 'validation/artifacts/audit_cases.json').read_text())
    for record in audits:
        if not record['expected_demand']:
            specifications.append(('inherited_attack/' + record['name'], record['goal'], record['proof'], False))
    for name, goal, stream, expected in specifications:
        named = oracle_verdict(goal, stream)
        actual = verdict(kernel, goal, stream)
        assert named[0] == expected and actual == named, ('focused mismatch', name, actual, named, expected)
        filename = name.replace('/', '__')
        (output / (filename + '.json')).write_text(json.dumps(stream + [goal]) + '\n')
        results['focused'].append({'name': name, 'expected': expected, 'final_supply': actual[1], 'all_matched': True})

    rng = random.Random(202611073)
    atoms = [None, True, False, 0.0, '0', {}, [], 0, 1, 2, -1, -2, -3]
    candidates = list(atoms)
    for _ in range(400):
        candidates.append([deepcopy(rng.choice(candidates[:70])) for _ in range(rng.randrange(5))])
    comparisons = 0
    for goal in candidates:
        for size in range(4):
            context = [goal] + [[0, 0]] * (size - 1) if size else []
            named = oracle_verdict(goal, [None], context, -size)
            actual = verdict(kernel, goal, [None], context, -size)
            assert actual == named, ('grammar mismatch', size, goal, actual, named)
            comparisons += 1
    results['grammar_boundary_comparisons'] = comparisons

    original = path.read_text()
    mutants = [
        ('name_boundary_deleted', original.replace(' and a >= k', ''),
         next(s for s in specifications if s[0] == 'root_parameter')),
        ('image_validation_deleted', original.replace('else inst(env[a - d // 2 - 1], d=1)', 'else env[a - d // 2 - 1]'),
         next(s for s in specifications if s[0].endswith('capture_by_illegal_positive_witness'))),
        ('fresh_decrement_deleted', original.replace('    k -= 1\n', ''),
         next(s for s in specifications if s[0] == 'fresh_decrement_is_necessary')),
    ]
    for name, text, fixture in mutants:
        module = types.ModuleType(name)
        exec(compile(text, name, 'exec'), module.__dict__)
        fixture_name, goal, stream, _ = fixture
        assert verdict(module, goal, stream)[0], ('positive mutant control did not fire', name)
        results['mutants'].append({'mutation': name, 'fixture': fixture_name, 'mutant_accepted': True})

    selected = ['root_parameter', 'sequential_names_in_sibling_scopes',
                'repeated_local_name_in_global_trace', 'declared_name_reused_without_assumption',
                'future_name_used_before_declaration', 'fresh_decrement_is_necessary']
    cli_cases = public + [(name, next(s[3] for s in specifications if s[0] == name)) for name in selected]
    for name, expected in cli_cases:
        for optimized in (False, True):
            command = [sys.executable, *(['-O'] if optimized else []), str(path), str(output / (name + '.json'))]
            process = subprocess.run(command, text=True, capture_output=True)
            assert process.returncode == (0 if expected else 1) and process.stdout.strip() == ('ACCEPT' if expected else 'REJECT'), ('CLI mismatch', name, optimized, process.stdout)
            results['cli'].append({'case': name, 'optimized': optimized, 'accepted': expected})
    results['status'] = 'all checks passed'
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results/results_global.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps({key: len(results[key]) for key in ['inherited', 'focused', 'mutants', 'cli']}))
    print(json.dumps({'grammar_boundary_comparisons': comparisons, 'status': results['status']}))


if __name__ == '__main__':
    main()
