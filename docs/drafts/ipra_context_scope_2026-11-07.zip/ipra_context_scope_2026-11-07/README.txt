SMALLER COMPLETE PRESENTATIONS OF iPRA
7 November 2026
=====================================

Read report.pdf for the construction, full interpretation arguments, exact
comparison, attribution, and limits. report.tex and sections/*.tex contain its
complete editable source.

RESULT
------
The ten top-level acceptance programs in the six supplied draft archives have
coordinatewise minima 457 significant Python tokens / 469 AST nodes / 1352
normalized UTF-8 bytes at the pinned repository snapshot:

  8b00e6ea50c664476e3a3289a78287946e5e0a34

This package supplies two complete standalone acceptance programs:

  checker.py         449 tokens / 465 AST nodes / 1336 bytes
  checker_local.py   454 tokens / 467 AST nodes / 1344 bytes

Both are strictly below all three coordinates of the current envelope.
checker.py combines compatible existing reductions and is the smallest measured
program in this package. checker_local.py eliminates global freshness state:
a call with L assumptions permits names -L,...,-1 and chooses -(L+1) for its
next eigenparameter. Each eigenvariable rule adds at least one hypothesis.

The reductions are modest. No absolute shortestness, general lower-bound
theorem, or major new arithmetic axiom reduction is claimed. Newness is stated
relative to the inspected draft corpus, not as a worldwide priority claim.

The public theorem interface takes CLOSED formulas. The full ordinary
first-order theory is recovered with derived connectives and quantifiers, and
an open theorem is represented by its universal closure. The report provides a
faithful ordinary realization T_cov and identity-domain bi-interpretations with
first-order intuitionistic PRA with quantifier-free induction. It explicitly
addresses nonstandard counters, falsity, and both composite interpretations.

REPRODUCTION
------------
Python 3.10+ is sufficient for the code syntax. Python 3.12.14 was used for the
reported source-normalization measurements. Tests need only the standard
library, and run offline:

  python3 reproduce.py

This runs source measurement and four audit scripts. Expected outcome: each
stage succeeds and the final line reports that all reproduction stages passed.
Detailed evidence is written into results/. The baselines are hash-checked
before measurement. Compilers and test oracles are outside the trusted kernel.

Rebuild the PDF using pdfLaTeX and the standard packages named by report.tex:

  python3 build.py

To verify the archive payload against its recorded SHA256 manifest:

  python3 package.py --verify

To regenerate the ZIP next to this directory (also refreshes the manifest):

  python3 package.py

Re-running audits or building the PDF can change generated result files or PDF
metadata. Refresh the manifest if you intentionally regenerate those artifacts.

USE A CHECKER
-------------
  python3 checker.py examples/global/reflexivity.json
  python3 checker_local.py examples/local/reflexivity.json

Each prints ACCEPT and exits 0. An invalid certificate prints REJECT and exits
1. Behavior is unchanged by Python's -O flag. No accepted inference uses an
assert statement. See FORMAT.txt for the complete syntax and instruction stream.

This attack must be rejected by both kernels:

  python3 checker.py validation/experiments/capture_counterexample.json

It exploits a dangling substitution coordinate that is captured when an unsafe
mutant omits depth-zero image validation. The independent audit executes that
mutant as a positive control. Mutants are experiments, never endorsed kernels.

CONTENTS
--------
report.pdf; report.tex; sections/    Mathematical report and editable source
checker.py                         Smallest measured global-scope kernel
checker_local.py                   Context-size local-scope kernel
FORMAT.txt                         Complete certificate/interface contract
measure.py                         Reproducible full-program accounting
reproduce.py                       Measurement and audit entry point
build.py                           PDF build entry point
package.py                         Integrity verification and ZIP creation
baselines/                         Ten unchanged kernels and pinned manifests
validation/                        Compilers, independent syntax, and audits
examples/                          Positive and negative public certificates
results/                           Executed outcomes and source measurements
MANIFEST.sha256                     SHA256 of every included file except itself
ATTRIBUTION.txt; LICENSE_SOURCE.txt  Research lineage and inherited MIT-0 license

EVIDENCE STATUS
---------------
Mathematical arguments are written proofs, not a Lean/Rocq formalization. Finite
implementation tests supplement them; they do not prove the metatheorems.
The report distinguishes proved refinements (including one-sided atomic
equality transport and predecessor-free logical reconstruction) from the
uncompleted scalar-iteration reduction. Published expressivity of pure
recursion does not by itself supply the required internal identities.

All delivered artifacts were prepared from the cited snapshot and the primary
sources listed in the report. No repository write or publication is involved.
