"""Build the report using an ordinary pdfLaTeX installation."""
from pathlib import Path
import calendar
import os
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    (ROOT / 'results').mkdir(exist_ok=True)
    environment = dict(os.environ, TZ='UTC',
                       SOURCE_DATE_EPOCH=str(calendar.timegm((2026, 11, 7, 0, 0, 0))),
                       FORCE_SOURCE_DATE='1')
    records = []
    for run in range(3):
        result = subprocess.run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
                                 'report.tex'], cwd=ROOT, env=environment,
                                text=True, capture_output=True)
        records.append(result.stdout + result.stderr)
        if result.returncode:
            (ROOT / 'results/build_log.txt').write_text('\n'.join(records))
            raise RuntimeError('pdfLaTeX failed; see results/build_log.txt')
    (ROOT / 'results/build_log.txt').write_text('\n'.join(records))
    print('Built report.pdf')


if __name__ == '__main__':
    main()
