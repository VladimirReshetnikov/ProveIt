"""Reproduce full-source metrics; no compiler or oracle is trusted by a kernel."""
import ast
import csv
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

ROOT = Path(__file__).resolve().parent


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if node.body and isinstance(node.body[0], ast.Expr):
            value = node.body[0].value
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                node.body.pop(0)
        return node

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(path):
    data = path.read_bytes()
    tree = StripDocstrings().visit(ast.parse(data.decode('utf-8')))
    normalized = ast.unparse(tree) + '\n'
    ignored = {tokenize.ENCODING, tokenize.NL, tokenize.NEWLINE, tokenize.INDENT,
               tokenize.DEDENT, tokenize.ENDMARKER, tokenize.COMMENT}
    tokens = sum(t.type not in ignored for t in tokenize.generate_tokens(io.StringIO(normalized).readline))
    return {'file': str(path.relative_to(ROOT)), 'tokens': tokens,
            'ast': sum(1 for _ in ast.walk(tree)),
            'bytes': len(normalized.encode('utf-8')), 'raw_bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def main():
    manifest = json.loads((ROOT / 'baselines/manifest.json').read_text())
    baselines = []
    for row in manifest['programs']:
        metrics = measure(ROOT / row['file'])
        if metrics['sha256'] != row['sha256']:
            raise ValueError('Frozen baseline changed: ' + row['file'])
        baselines.append({**row, **metrics})
    envelope = {key: min(row[key] for row in baselines) for key in ('tokens', 'ast', 'bytes')}
    candidates = [measure(ROOT / name) for name in ('checker.py', 'checker_local.py')]
    for row in candidates:
        if not all(row[key] < envelope[key] for key in envelope):
            raise AssertionError(('Candidate does not beat envelope', row, envelope))
    result = {'python': platform.python_version(), 'commit': manifest['commit'],
              'contract': 'Remove actual docstrings; ast.unparse plus LF; significant tokens, ast.walk nodes, UTF-8 bytes; whole program.',
              'baselines': baselines, 'envelope': envelope, 'candidates': candidates}
    target = ROOT / 'results'
    target.mkdir(exist_ok=True)
    (target / 'measurements.json').write_text(json.dumps(result, indent=2) + '\n')
    with (target / 'measurements.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=['file', 'tokens', 'ast', 'bytes', 'raw_bytes', 'sha256'], extrasaction='ignore')
        writer.writeheader()
        writer.writerows(baselines + candidates)
    print(json.dumps({'python': result['python'], 'baseline_count': len(baselines),
                      'envelope': envelope, 'candidates': candidates}, indent=2))


if __name__ == '__main__':
    main()
