"""Offline source measurement and executable verification entry point."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    for script in ['measure.py', 'validation/audit_local.py',
                   'validation/audit_global.py', 'validation/audit_independent.py',
                   'validation/audit_capture.py']:
        subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)
    print('All reproduction stages passed. Build the PDF with python3 build.py.')


if __name__ == '__main__':
    main()
