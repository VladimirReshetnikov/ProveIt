"""Verify payload hashes or create a deterministic-layout ZIP archive."""
import argparse
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / 'MANIFEST.sha256'
IGNORED_SUFFIXES = {'.aux', '.log', '.out', '.toc', '.pyc', '.synctex.gz'}


def payload():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and '__pycache__' not in p.parts
                  and p != MANIFEST
                  and p.suffix not in IGNORED_SUFFIXES
                  and not p.name.startswith('.'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify():
    recorded = {}
    for line in MANIFEST.read_text().splitlines():
        value, relative = line.split('  ', 1)
        path = (ROOT / relative).resolve()
        if not path.is_relative_to(ROOT):
            raise ValueError('Manifest path outside package: ' + relative)
        if not path.is_file() or digest(path) != value:
            raise ValueError('Missing or changed file: ' + relative)
        recorded[relative] = value
    actual = {str(p.relative_to(ROOT)) for p in payload()}
    if actual != set(recorded):
        raise ValueError('Manifest does not match the payload file set')
    print(f'Verified {len(recorded)} payload files.')


def package():
    files = payload()
    MANIFEST.write_text(''.join(f'{digest(p)}  {p.relative_to(ROOT)}\n' for p in files))
    verify()
    target = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in sorted(files + [MANIFEST]):
            name = f'{ROOT.name}/{path.relative_to(ROOT)}'
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(target) as archive:
        bad = archive.testzip()
        if bad is not None:
            raise ValueError('ZIP integrity failure: ' + bad)
    print(f'Created {target.name}: {target.stat().st_size} bytes; SHA256 {digest(target)}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify', action='store_true', help='check the existing manifest')
    args = parser.parse_args()
    verify() if args.verify else package()
