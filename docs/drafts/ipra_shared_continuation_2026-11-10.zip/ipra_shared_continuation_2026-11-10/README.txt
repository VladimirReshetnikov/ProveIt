iPRA WITH A SHARED ELIMINATION CONTINUATION
=========================================
Prepared for Vladimir Reshetnikov, 10 November 2026.

RESULT AND LIMIT
----------------
The complete checker coordinate envelope is reduced from
287 normalized Python tokens / 323 AST nodes / 738 normalized bytes
to 285 / 322 / 703. Different complete programs attain these coordinates.
No single new program attains all three minima or beats every old minimum.

This is a modest implementation synthesis of mechanisms already present
in the current drafts. The numerical axiomatization is inherited. The
requested significant new mathematical breakthrough and an absolute
simplicity minimum were NOT obtained. The report states this prominently.

The equivalent native presentation is specified completely: two scalar
iterator computation schemas, case/progress paired introduction (progress
only for literal equations), paired elimination, closure specialization,
equality transport, and the charged context-availability policy. Full
intuitionistic logic, quantifier-free induction, every fixed primitive
recursive operation, and both whole-domain interpretation composites are
reconstructed. Designated absurdity is explicitly 0=S0; the ordinary
interpretation includes its bridge to genuine falsity.

The new implementation combines explicit endpoint certificates, the
administrative continuation, and focused assumption availability. It
does not use an uncharged theorem oracle or a proof producer. A separate
one-variable successor-seeded recursor is an unresolved research candidate;
the missing left inverse of successor is not asserted as proved.

READ
----
ipra_shared_continuation.pdf  Complete report, proofs, limits, and references.
report.tex                  Main LaTeX source.
appendices/                 Three attributed arithmetic proof dependencies.
implementation/IMPLEMENTATION.txt
                            Implementation contract and correctness argument.
implementation/independent_review.md
                            Separate assistant source review (not formal QA).

RUN
---
From this extracted directory:

    python3 verify.py
    python3 build.py

Verification requires Python 3.12 for exact reproduction of the reported
source measures. Other Python versions can change ast.unparse and AST
node counts. The programs themselves use only Python's standard library.
The byte/token profiles require ordinary modern Python; the structure
profile uses an assignment expression and requires Python 3.8 or later.

The PDF build requires an existing pdfTeX/LaTeX distribution, Latin Modern,
AMS packages, and the standard packages named in the preamble. build.py
can generate absent format/font-map caches from installed packages; it
does not install packages or download them. Build intermediates go to build/.

The verification suite replays the inherited positive/negative corpora,
translates accepted proofs with fresh-name reallocation, compares compact
programs against explicit-guard controls, runs deterministic mutations,
and checks public ACCEPT/REJECT behavior both with and without Python -O.
The delivered receipt reports all tests passed: 350 old fixtures replayed,
157 positive translations per interface, 6,684 mutation comparisons,
and 1,114 selected-profile command-line runs.

CHECK A CERTIFICATE
-------------------
For a JSON array in certificate.json:

    python3 implementation/selected_bytes.py < certificate.json

Three small ready-to-run examples are in examples/: computation.json and
reflexivity.json are accepted; false_computation.json is rejected. All
three selected profiles were checked on these exact example files.

The packet formats differ between the ordinary and focused interfaces.
Use the supplied translated fixtures for the intended profile; do not
copy old packets unchanged. The whole standard-input array is data, and
no submitted Python code is evaluated. ACCEPT with exit status 0 denotes
acceptance; REJECT with nonzero status denotes rejection. A traceback on
stderr after rejection is permitted by the inherited public interface.

COMPARISON SNAPSHOT AND PROVENANCE
--------------------------------
Repository: VladimirReshetnikov/ProveIt
Commit: 7bded17cc0122767f86e494fcf256b47fe85c9b8
Directory: docs/drafts

All ten ZIPs were pinned and checked against their Git blob identities.
evidence/repository_snapshot.json records those exact source identities.
evidence/inherited_arithmetic.json records appendix hashes and source
members. implementation/provenance.json records copied implementation
inputs and comparison kernels. The MIT No Attribution source license
is retained in reference/ and implementation/reference/.

The full audit counted 6,213,010 archive bytes, 154 Python occurrences,
109 distinct Python byte strings, and 44 distinct standalone-checker
byte strings. The role classifications and exclusion reasons are in
implementation/evidence/current_corpus_audit.json. To repeat the full
source audit with your copies of the pinned original ZIPs, run:

    python3 implementation/audit_corpus.py /path/to/pinned/docs/drafts

This optional audit performs no downloads and executes no checker. The
ordinary verify.py command is self-contained and needs no original ZIPs.

All programs being measured are complete standalone modules. Their input,
verdict, scoping, and proof-rule code is counted. The standard Python/JSON
runtime is a shared assumption on both sides. The metric is an existing
corpus convention, not a universal lower-bound theorem or readability score.

RESEARCH LIMITS
---------------
Finite tests and assistant review are not Lean/Rocq verification or external
peer review. The arithmetic metatheorems are written proofs, with their
dependencies included and attributed. Physical resource limits can reject
large valid certificates. The main report contains a Further research
questions section and explicitly separates proved, inherited, and unresolved
claims.

The research/ weak-head-conversion prototype did not improve the metric.
It is included to record the rejected route and is not a trusted dependency.
