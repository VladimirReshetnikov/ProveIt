# Independent review of the selected complete checkers

Reviewed on 10 November 2026. This is a separate assistant-agent source
review, not a proof-assistant verification or external peer review.

## Files and measurements reviewed

The exact sources reviewed are:

| File | SHA-256 | Normalized tokens | AST nodes | Normalized bytes |
| --- | --- | ---: | ---: | ---: |
| `selected_tokens.py` | `615a1137e419403bb073294d4854ad74def52ff7035dceaa8f62bfabc33a3bb0` | 285 | 328 | 739 |
| `selected_structure.py` | `b514293cd820d14fd4895130c99df829bd6b713bcd3a9997eba6793315ae55d7` | 289 | 322 | 758 |
| `selected_bytes.py` | `a7021468e2417c4ca58e70a4e1cc2181c8688bc29eb54cbf6a27815d371e6bce` | 288 | 337 | 703 |

The existing whole-program measurement code independently reproduced
these figures. The coordinatewise envelope 285 / 322 / 703 belongs to
three different programs. No selected program attains all three minima.

## Review outcome

No correctness defect was found in the inspected changes. The new
programs combine already documented endpoint certificates, shared
continuations, and (for the byte profile) elimination-only assumption
availability. This is a modest implementation improvement, not a new
arithmetic axiomatization or a proven universal size minimum.

The token and structure profiles retain general hypothesis closure and
the native Eq/Q/D interface. The byte profile has the focused Eq/D object
interface, with Q restricted to internal elimination resources. They
therefore have different raw certificate interfaces; comparison and
certificate conversion must account for that distinction. On the
specified Eq/D object fragment the inherited focusing theorem supplies
the mathematical correspondence.

## Endpoint matching

For a short major, the check

    m in ([s, u], not s and [t])

has the two intended alternatives: an equality with supplied endpoints,
or a unary closure with zero source. A nonzero truthy source cannot use
the closure alternative. Falsy numerical aliases denote zero when they
are used; malformed unused fields do not affect a vacuous instance.
Every used numerical image passes the inherited root check in `i`.

The equality `i(t, u) == a` binds the target to the common motive, and
`i(t, s)` supplies its source instance. The externally supplied major
must first have a successful proof or the authorized context use.
The code does not accept a failed major merely because Python represents
successful checker completion by `None`.

## Failed-target sentinel

A failed endpoint or target match produces scalar `False`. In the
token and structure profiles every entry of the context is list-valued:

- Paired elimination appends the opening of the singleton list `m[2:]`.
- Short-major elimination appends the empty list.
- Paired introduction reaches the common tail only when its matrix
  supports `len(a)`; accepted syntax at that point is list-valued.

The opening traversal preserves list arity. Thus scalar `False`/zero
cannot close against the context. Computation and paired introduction
cannot terminate a scalar goal. An elimination either rejects or leaves
a strictly shorter proof obligation with scalar goal. No finite
successful trace can therefore escape from a failed-target sentinel.

In the focused byte profile there is no hypothesis-conclusion branch at
all. The same finite-trace argument excludes successful scalar goals.

## Failed computation

The token and structure profiles deliberately replace an explicit
division-by-false guard by a successful-match return. If the match fails,
the current frame has not assigned local `h`. Its common continuation
therefore raises, after at most an earlier validation failure. A value
of `h` in a caller or another recursive call is irrelevant: Python local
variables belong to the current frame. There is no successful fallback
from a failed computation match.

The byte profile retains the explicit `1 / (b == t)` check.

## Scope and malformed syntax

The token and structure profiles validate each goal on entry. The byte
profile validates the public goal and each external major; all remaining
recursive goals are supplied by the opening routine. These are the
same scope-validation sites justified by the inherited focusing report.

Root checking of an inserted numerical term prevents capture. The fresh
integer floor decreases only after the current retained goal, context,
matrix, and used witness have been checked. Extra floor decreases in
short-major continuations introduce unused rigid parameters; they do not
alter the already validated goal.

The structure profile's `d=(k := 0)` initializes the global floor when
the function is defined, before input is read. It is not a reset on each
recursive call. Its exception-based list traversal cannot silently
accept a malformed list: after a failed list traversal, the scalar
comparison on that list raises. JSON provides no user-defined objects
or operator overloads. Strings, mappings, and null values used in
numerical syntax reject. The inherited harmless scalar aliases require
the same semantic treatment as in the source formats.

## Dummy context entry and focused object purity

Every short-major continuation appends `[]`. In the byte profile this
entry is inaccessible as an elimination resource: availability is tested
only in the truthy-major branch, and no truthy list can open to the empty
list because opening preserves arity. There is also no general hypothesis
rule that could conclude this dummy entry.

The inherited finite-descent purity argument remains valid. Computation
concludes an equation; transport and closure specialization preserve the
meaningful formula spine; paired elimination preserves the goal; paired
introduction strips only its leading D. A successful focused trace cannot
terminate at a Q node or a scalar/empty truth alias on that spine. No new
purity exception is introduced by endpoint certificates or the common
continuation.

## Limits of this review

This review examines the changed control flow and its relation to the
inherited sorted decoder and native calculi. It does not independently
formalize the complete scalar-predecessor, primitive-recursion, or
intuitionistic bi-interpretation developments. The parent report should
retain their source attribution and state their written-proof status.
The separate validation suite supplies executable regression evidence;
finite tests are not a universal soundness proof. Physical Python resource
limits may reject very large valid finite certificates.

No claim of a significant mathematical breakthrough follows from these
small whole-program improvements. The report should state that the
user's stronger breakthrough objective remains unmet.
