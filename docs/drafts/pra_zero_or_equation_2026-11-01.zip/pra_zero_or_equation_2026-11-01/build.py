#!/usr/bin/env python3
"""Reproduce the syntax checks, LaTeX PDF, and optional Lean verification."""
from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys
from datetime import datetime, timezone


ROOT = pathlib.Path(__file__).resolve().parent
AUDIT = ROOT / "audit"


def run(command: list[str], log_name: str, cwd: pathlib.Path = ROOT) -> dict:
    result = subprocess.run(command, cwd=cwd, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (AUDIT / log_name).write_text(result.stdout, encoding="utf-8")
    record = {"command": command, "exit_code": result.returncode,
              "log": "audit/" + log_name}
    if result.returncode:
        print(result.stdout[-8000:])
        raise RuntimeError(f"Command failed with status {result.returncode}: {command}")
    return record


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Lean 4.19.0 executable; omitted means skip")
    args = parser.parse_args()
    AUDIT.mkdir(exist_ok=True)
    records = {"started_utc": datetime.now(timezone.utc).isoformat(), "steps": []}
    records["steps"].append(run([sys.executable, "checks/check_spec.py"],
                                 "python-check.log"))
    latex = shutil.which("pdflatex")
    if not latex:
        raise RuntimeError("pdflatex is required to compile report.tex")
    for number in (1, 2):
        records["steps"].append(run(
            [latex, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
            f"latex-pass-{number}.log"))
    log = (ROOT / "report.log").read_text(encoding="utf-8", errors="replace")
    unresolved = [line for line in log.splitlines()
                  if "undefined" in line.lower() or "Overfull" in line]
    records["latex_unresolved_or_overfull"] = unresolved
    if unresolved:
        raise RuntimeError("LaTeX reports unresolved references or overfull boxes")
    if args.lean:
        lean = str(pathlib.Path(args.lean).resolve())
        records["steps"].append(run([lean, "--version"], "lean-version.log"))
        records["steps"].append(run([lean, "ZeroOrEquation.lean"],
                                     "lean-recheck.log", ROOT / "formal"))
        records["lean_rerun"] = True
    else:
        records["lean_rerun"] = False
        records["lean_note"] = "Not rerun by this command; see formal/verification.json"
    pdf = ROOT / "report.pdf"
    records["pdf_bytes"] = pdf.stat().st_size
    records["pdf_sha256"] = hashlib.sha256(pdf.read_bytes()).hexdigest()
    records["finished_utc"] = datetime.now(timezone.utc).isoformat()
    records["status"] = "passed"
    (AUDIT / "build_results.json").write_text(
        json.dumps(records, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "passed", "pdf": str(pdf),
                      "bytes": records["pdf_bytes"],
                      "lean_rerun": records["lean_rerun"]}, indent=2))


if __name__ == "__main__":
    main()
