#!/usr/bin/env python3
"""Finite syntax and arithmetic diagnostics for zero-or-equation PRA.

Run from any directory with Python 3.10 or later:
    python3 checks/check_spec.py

The file uses only Python's standard library.  It exhaustively generates
all terms of at most four active AST nodes over a stated finite descriptor
catalog, then checks every pair as a dynamic matrix.  A separately parsed
S-expression tree checks binding and literal matrix admission.  A second
finite corpus includes arbitrary shallow formulas, most of which must be
rejected.  These are executable diagnostics, NOT a formal proof of the
infinite theory, its arithmetic bootstrap, or its bi-interpretability.

Descriptor names are opaque symbol metadata.  The AST size ledger excludes
their stored bodies, whose separate sizes are also reported.  An emitted
transition explicitly substitutes into its stored body, as the paper does.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from functools import lru_cache
import hashlib
import itertools
import json
from pathlib import Path
import re


@dataclass(frozen=True)
class Tree:
    tag: str
    args: tuple = ()


def V(name): return Tree("var", (name,))
def Z(): return Tree("zero")
def S(t): return Tree("succ", (t,))
def D(name, n, a): return Tree("delay", (name, n, a))
def Eq(s, t): return Tree("eq", (s, t))
def Bot(): return Tree("bot")
def And(a, b): return Tree("and", (a, b))
def Or(a, b): return Tree("or", (a, b))
def Imp(a, b): return Tree("imp", (a, b))
def All(name, body): return Tree("all", (name, body))


ZERO, ONE = Z(), S(Z())
N, A, STATE = V("n"), V("a"), V("v")
DELTA = Eq(ZERO, ONE)
SEP = Imp(DELTA, Bot())


def active_children(t):
    if t.tag in {"zero", "var", "bot"}:
        return ()
    if t.tag in {"delay", "all"}:
        return t.args[1:]
    return t.args


def size(t):
    return 1 + sum(size(c) for c in active_children(t))


def free(t):
    if t.tag == "var":
        return {t.args[0]}
    found = set().union(*(free(c) for c in active_children(t)))
    return found - {t.args[0]} if t.tag == "all" else found


def names(t):
    found = set().union(*(names(c) for c in active_children(t)))
    if t.tag in {"var", "all"}:
        found.add(t.args[0])
    return found


def term_ok(t, known):
    if not isinstance(t, Tree):
        return False
    if t.tag == "zero":
        return not t.args
    if t.tag == "var":
        return len(t.args) == 1 and isinstance(t.args[0], str)
    if t.tag == "succ":
        return len(t.args) == 1 and term_ok(t.args[0], known)
    if t.tag == "delay":
        return (len(t.args) == 3 and t.args[0] in known
                and all(term_ok(c, known) for c in t.args[1:]))
    return False


def references(t):
    found = set().union(*(references(c) for c in active_children(t)))
    if t.tag == "delay":
        found.add(t.args[0])
    return found


def substitute(t, variable, value):
    """Capture-avoiding active substitution; descriptor metadata is opaque."""
    if t.tag == "var":
        return value if t.args[0] == variable else t
    if t.tag in {"zero", "bot"}:
        return t
    if t.tag == "all":
        binder, body = t.args
        if binder == variable or variable not in free(body):
            return t
        if binder in free(value):
            used = names(body) | free(value) | {variable, binder}
            i = 0
            while "fresh" + str(i) in used:
                i += 1
            fresh = "fresh" + str(i)
            body = substitute(body, binder, V(fresh))
            binder = fresh
        return All(binder, substitute(body, variable, value))
    if t.tag == "delay":
        descriptor, counter, seed = t.args
        return D(descriptor, substitute(counter, variable, value),
                 substitute(seed, variable, value))
    return Tree(t.tag, tuple(substitute(c, variable, value) for c in t.args))


class Catalog:
    def __init__(self):
        self.bodies = {}

    def add(self, name, body):
        if name in self.bodies:
            raise ValueError("duplicate descriptor")
        if not term_ok(body, self.bodies):
            raise ValueError("body is not a term over earlier descriptions")
        if not free(body) <= {"v"}:
            raise ValueError("stored body has an external free input")
        self.bodies[name] = body

    def apply(self, name, term):
        return substitute(self.bodies[name], "v", term)


def dynamic(s, t, catalog):
    if not all(term_ok(x, catalog.bodies) and free(x) <= {"n", "a"}
               for x in (s, t)):
        raise ValueError("G takes two legal terms, not arbitrary formulas")
    return Or(Eq(N, ZERO), Eq(s, t))


def reset(h, n=N, a=A):
    return Eq(D(h, D("one", n, ZERO), a), a)


def transition(h, catalog, n=N, a=A):
    return Eq(D(h, S(S(n)), a), catalog.apply(h, D(h, S(n), a)))


def stationary(h, catalog):
    if h not in catalog.bodies:
        raise ValueError("unknown descriptor")
    return And(SEP, All("n", And(reset(h), transition(h, catalog))))


def emit(matrix):
    return All("a", Imp(All("n", Imp(matrix, substitute(matrix, "n", S(N)))),
                         All("n", matrix)))


def sexpr(t):
    if t.tag in {"zero", "bot"}:
        return t.tag
    entries = [t.tag]
    for arg in t.args:
        entries.append(sexpr(arg) if isinstance(arg, Tree) else arg)
    return "(" + " ".join(entries) + ")"


def parse_sexpr(text):
    """Independent raw parser: no Tree constructor or substitution is used."""
    tokens = re.findall(r"\(|\)|[^\s()]+", text)
    position = 0

    def parse():
        nonlocal position
        if position >= len(tokens):
            raise ValueError("unexpected end")
        token = tokens[position]
        position += 1
        if token == "(":
            parts = []
            while position < len(tokens) and tokens[position] != ")":
                parts.append(parse())
            if position >= len(tokens):
                raise ValueError("missing closing parenthesis")
            position += 1
            return tuple(parts)
        if token == ")":
            raise ValueError("unexpected closing parenthesis")
        return token

    result = parse()
    if position != len(tokens):
        raise ValueError("trailing input")
    return result


def raw_term(raw, known, allowed):
    if raw == "zero":
        return True
    if not isinstance(raw, tuple) or not raw:
        return False
    if raw[0] == "var":
        return len(raw) == 2 and raw[1] in allowed
    if raw[0] == "succ":
        return len(raw) == 2 and raw_term(raw[1], known, allowed)
    if raw[0] == "delay":
        return (len(raw) == 4 and raw[1] in known
                and all(raw_term(x, known, allowed) for x in raw[2:]))
    return False


def raw_binding(raw, stack=()):
    """Independent lexical-scope traversal on parsed text."""
    if isinstance(raw, str):
        return set(), set()
    tag = raw[0]
    if tag == "var":
        return (set() if raw[1] in stack else {raw[1]}), {raw[1]}
    if tag == "all":
        unbound, used = raw_binding(raw[2], stack + (raw[1],))
        return unbound, used | {raw[1]}
    children = raw[2:] if tag == "delay" else raw[1:]
    unbound, used = set(), set()
    for child in children:
        a, b = raw_binding(child, stack)
        unbound |= a
        used |= b
    return unbound, used


def raw_count(raw):
    if isinstance(raw, str):
        return 1
    if raw[0] == "var":
        return 1
    if raw[0] in {"delay", "all"}:
        return 1 + sum(raw_count(c) for c in raw[2:])
    return 1 + sum(raw_count(c) for c in raw[1:])


def raw_classify(raw, catalog, stationary_text):
    """Literal syntax recognizer, independent of the dynamic constructor."""
    if (isinstance(raw, tuple) and len(raw) == 3 and raw[0] == "or"
            and raw[1] == ("eq", ("var", "n"), "zero")):
        right = raw[2]
        if (isinstance(right, tuple) and len(right) == 3 and right[0] == "eq"
                and all(raw_term(t, catalog.bodies, {"n", "a"})
                        for t in right[1:])):
            return "G"
    if raw in stationary_text:
        return "C"
    return None


def enumerate_terms(catalog, max_nodes):
    """All active term trees of a size bound, not a hand-picked sample."""
    by_size = {1: {ZERO, N, A}}
    for k in range(2, max_nodes + 1):
        current = {S(t) for t in by_size[k - 1]}
        for left_size in range(1, k - 1):
            right_size = k - 1 - left_size
            for name in catalog.bodies:
                for n in by_size[left_size]:
                    for a in by_size[right_size]:
                        current.add(D(name, n, a))
        by_size[k] = current
    return by_size


def build_catalog():
    result = Catalog()
    for name, body in (("zero", ZERO), ("one", ONE), ("succ", S(STATE)),
                       ("id", STATE), ("pred", D("succ", STATE, ZERO)),
                       ("double", D("succ", S(STATE), STATE))):
        result.add(name, body)
    return result


def evaluator(catalog):
    @lru_cache(maxsize=None)
    def run(t, n=0, a=0, v=0):
        if t.tag == "zero":
            return 0
        if t.tag == "var":
            return {"n": n, "a": a, "v": v}[t.args[0]]
        if t.tag == "succ":
            return run(t.args[0], n, a, v) + 1
        if t.tag == "delay":
            h, counter, seed = t.args
            times = max(run(counter, n, a, v) - 1, 0)
            answer = run(seed, n, a, v)
            for _ in range(times):
                answer = run(catalog.bodies[h], v=answer)
            return answer
        raise ValueError("the evaluator takes numerical terms only")
    return run


def rejected(action):
    try:
        action()
    except ValueError:
        return True
    return False


def check_all():
    catalog = build_catalog()
    bodies_before = dict(catalog.bodies)
    catalog_tests = [
        ("free counter", S(N)),
        ("frozen parameter", A),
        ("self reference", D("bad", STATE, ZERO)),
        ("forward reference", D("future", STATE, ZERO)),
        ("formula as body", Eq(STATE, ZERO)),
    ]
    for _, body in catalog_tests:
        assert rejected(lambda body=body: catalog.add("bad", body))
    assert rejected(lambda: catalog.add("one", ZERO))
    earlier = set()
    for name, body in catalog.bodies.items():
        raw = parse_sexpr(sexpr(body))
        assert raw_term(raw, earlier, {"v"})
        assert references(body) <= earlier
        earlier.add(name)

    cs = {parse_sexpr(sexpr(stationary(h, catalog))) for h in catalog.bodies}
    sizes = enumerate_terms(catalog, 4)
    terms = sorted(set().union(*sizes.values()), key=sexpr)
    dynamic_count = 0
    for s, t in itertools.product(terms, repeat=2):
        matrix = dynamic(s, t, catalog)
        raw = parse_sexpr(sexpr(matrix))
        assert raw_classify(raw, catalog, cs) == "G"
        assert size(matrix) == raw_count(raw) == 5 + size(s) + size(t)
        axiom = parse_sexpr(sexpr(emit(matrix)))
        unbound, used = raw_binding(axiom)
        assert not unbound and used <= {"n", "a"}
        base = parse_sexpr(sexpr(substitute(matrix, "n", ZERO)))
        assert base[1] == ("eq", "zero", "zero")
        dynamic_count += 1

    for h in catalog.bodies:
        matrix = stationary(h, catalog)
        assert raw_classify(parse_sexpr(sexpr(matrix)), catalog, cs) == "C"
        assert substitute(matrix, "n", S(N)) == matrix
        unbound, used = raw_binding(parse_sexpr(sexpr(emit(matrix))))
        assert not unbound and used <= {"n", "a"}

    # Corpus generated independently of either permitted matrix constructor.
    atoms = (Bot(), Eq(N, ZERO), DELTA, Eq(N, A), Eq(ZERO, ZERO), Eq(A, A))
    arbitrary = set(atoms)
    for connective in (And, Or, Imp):
        arbitrary.update(connective(x, y) for x, y in itertools.product(atoms, repeat=2))
    arbitrary.update(All(x, atom) for x in ("n", "a") for atom in atoms)
    accepted = [f for f in arbitrary
                if raw_classify(parse_sexpr(sexpr(f)), catalog, cs)]
    expected = {Or(Eq(N, ZERO), atom) for atom in atoms if atom.tag == "eq"}
    assert set(accepted) == expected

    invalid_inputs = [Bot(), Eq(N, A), Or(Eq(N, ZERO), Eq(N, A)),
                      Imp(Eq(N, ZERO), Eq(N, A)), All("n", Eq(N, A)), V("b")]
    for invalid in invalid_inputs:
        assert rejected(lambda invalid=invalid: dynamic(invalid, ZERO, catalog))
    negative_matrices = [
        Or(Eq(ZERO, N), Eq(N, A)),           # reversed required zero atom
        Or(Eq(N, ZERO), Bot()),             # arbitrary formula is not a term equality
        Or(Eq(N, ZERO), And(Eq(N, A), Eq(A, ZERO))),
        Or(Eq(N, ZERO), Eq(V("b"), ZERO)),
        Or(Eq(N, ZERO), All("n", Eq(N, A))),
        All("n", Eq(N, A)),
        And(SEP, All("a", And(reset("succ"), transition("succ", catalog)))),
        And(SEP, All("n", And(reset("succ"), Eq(D("succ", S(N), A), S(A))))),
    ]
    for f in negative_matrices:
        assert raw_classify(parse_sexpr(sexpr(f)), catalog, cs) is None

    # Active substitutions change both actual arguments but never stored bodies.
    probe = D("pred", STATE, D("succ", STATE, N))
    changed = substitute(probe, "v", A)
    assert changed == D("pred", A, D("succ", A, N))
    assert catalog.bodies == bodies_before
    capture_probe = substitute(All("a", Eq(N, A)), "n", A)
    assert free(capture_probe) == {"a"} and capture_probe.args[0] != "a"
    assert substitute(All("n", Eq(N, A)), "n", S(N)) == All("n", Eq(N, A))

    # Delayed standard semantics, evaluated on a declared finite rectangle.
    run = evaluator(catalog)
    numerical_checks = 0
    for h, n, a in itertools.product(catalog.bodies, range(9), range(7)):
        re = reset(h)
        tr = transition(h, catalog)
        assert run(re.args[0], n, a) == run(re.args[1], n, a)
        assert run(tr.args[0], n, a) == run(tr.args[1], n, a)
        assert run(D(h, ZERO, A), n, a) == a
        assert run(D(h, ONE, A), n, a) == a
        p = D("succ", N, ZERO)
        normal = D(h, S(p), A)
        assert run(D(h, N, A), n, a) == run(normal, n, a)
        numerical_checks += 5

    # Check scalar-to-product factorization on a bounded sample of equations.
    factor_checks = 0
    factor_terms = sorted(set().union(sizes[1], sizes[2], sizes[3]), key=sexpr)
    for s, t in itertools.product(factor_terms, repeat=2):
        for n0, n1, a0, a1 in ((0, 1, 2, 3), (3, 0, 1, 2), (2, 3, 0, 1)):
            left = (run(s, n0, a0), run(s, n1, a1))
            right = (run(t, n0, a0), run(t, n1, a1))
            factors = (run(s, n0, a0) == run(t, n0, a0)
                       and run(s, n1, a1) == run(t, n1, a1))
            assert (left == right) == factors
            factor_checks += 1
    n_pair = (0, 1)
    p_pair = tuple(max(x - 1, 0) for x in n_pair)
    sp_pair = tuple(x + 1 for x in p_pair)
    assert n_pair != (0, 0) and n_pair != sp_pair
    for pair in itertools.product(range(6), repeat=2):
        successor = tuple(x + 1 for x in pair)
        sp_successor = tuple(max(x - 1, 0) + 1 for x in successor)
        assert successor == sp_successor

    # Explicit, reproducible finite-instance ledger; it is not a shortestness metric.
    new_g = dynamic(N, A, catalog)
    old_a = Eq(N, A)
    old_g = Imp(Or(substitute(old_a, "n", ZERO), DELTA), old_a)
    old_r = All("n", reset("succ"))
    old_t = All("n", transition("succ", catalog))
    new_c = stationary("succ", catalog)
    split_r = And(SEP, old_r)
    ledger = {
        "counting_convention": (
            "Each variable, 0, application, equality, bottom, connective and quantifier "
            "costs one; bound-variable declarations and descriptor-name metadata cost "
            "zero extra. Stored bodies and the entire generator are excluded."
        ),
        "outer_opaque_binary_matrix_template": 15,
        "general_G_term_size_formula": "5 + |s| + |t|",
        "general_old_guard_size_formula": "6 + |A[n:=0]| + |A|",
        "comparison_inputs": "s=n, t=a, old A=(n=a), h(v)=S(v); q is expanded",
        "comparison_scope": (
            "One selected emitted instance per matrix constructor. These selected finite "
            "sets need not be deductively equivalent: in particular, the old dynamic "
            "choice A=(n=a) does not itself derive separation. This is a display ledger, "
            "not a comparison of equivalent finite subtheories."
        ),
        "old_matrices": {"G": size(old_g), "R": size(old_r), "T": size(old_t)},
        "new_matrices": {"G": size(new_g), "C": size(new_c)},
        "split_new_matrices": {"G": size(new_g), "R": size(split_r), "T": size(old_t)},
        "old_emitted_axioms_total": sum(size(emit(f)) for f in (old_g, old_r, old_t)),
        "new_emitted_axioms_total": sum(size(emit(f)) for f in (new_g, new_c)),
        "split_new_emitted_axioms_total": sum(size(emit(f)) for f in (new_g, split_r, old_t)),
        "raw_reset_atom": size(reset("succ")),
        "raw_successor_transition_atom": size(transition("succ", catalog)),
        "separation_formula": size(SEP),
        "conclusion": (
            "The fixed logical input grammar is simpler. This selected representative "
            "collection grows by two AST nodes; no AST-size record is claimed. "
            "Merging stationary probes only removes a repeated outer wrapper."
        ),
    }
    assert ledger["old_matrices"] == {"G": 12, "R": 8, "T": 12}
    assert ledger["new_matrices"] == {"G": 7, "C": 27}
    assert ledger["old_emitted_axioms_total"] == 112
    assert ledger["new_emitted_axioms_total"] == 114
    assert ledger["split_new_emitted_axioms_total"] == 119
    for f in (old_g, old_r, old_t, new_g, new_c):
        assert size(emit(f)) == raw_count(parse_sexpr(sexpr(emit(f))))

    return {
        "status": "passed",
        "scope": (
            "Exhaustive finite term-tree diagnostics, independently parsed binding and "
            "literal matrix checks, negative controls, exact finite AST counts, and "
            "bounded standard arithmetic. Not a formal proof of the infinite theory "
            "or of the bi-interpretation theorem. The N^2 EqI proof is written mathematics."
        ),
        "descriptors": [{"name": h, "body": sexpr(b), "body_nodes": size(b),
                         "earlier_references": sorted(references(b))}
                        for h, b in catalog.bodies.items()],
        "exhaustive_term_bound": 4,
        "terms_by_active_node_size": {str(k): len(v) for k, v in sizes.items()},
        "total_enumerated_terms": len(terms),
        "exhaustive_dynamic_matrices_and_closed_two_name_axioms": dynamic_count,
        "stationary_matrices_and_closed_two_name_axioms": len(cs),
        "arbitrary_shallow_formula_corpus": len(arbitrary),
        "admitted_from_arbitrary_formula_corpus": len(accepted),
        "rejected_dynamic_input_controls": len(invalid_inputs),
        "rejected_near_miss_matrices": len(negative_matrices),
        "rejected_descriptor_controls": len(catalog_tests) + 1,
        "substitution_controls": ["shadow binder", "capture avoidance", "opaque descriptor"],
        "bounded_arithmetic_domain": {"counter": [0, 8], "seed": [0, 6]},
        "bounded_arithmetic_equalities_checked": numerical_checks,
        "bounded_product_factorization_checks": factor_checks,
        "product_coverage_counterexample": {
            "n": n_pair, "zero": [0, 0], "predecessor_n": p_pair,
            "successor_predecessor_n": sp_pair, "coverage": False,
            "successor_coverage_samples": 36,
            "qualification": "Full product-model EqI validity is proved in the paper, not by this sample."
        },
        "examples": {"G": sexpr(new_g), "C_succ": sexpr(new_c)},
        "count_ledger": ledger,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("results.json"))
    args = parser.parse_args()
    result = check_all()
    result["checker_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    args.output.with_name("counts.json").write_text(
        json.dumps(result["count_ledger"], indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: result[k] for k in (
        "status", "total_enumerated_terms",
        "exhaustive_dynamic_matrices_and_closed_two_name_axioms",
        "arbitrary_shallow_formula_corpus", "bounded_arithmetic_equalities_checked")
    }, indent=2))


if __name__ == "__main__":
    main()
