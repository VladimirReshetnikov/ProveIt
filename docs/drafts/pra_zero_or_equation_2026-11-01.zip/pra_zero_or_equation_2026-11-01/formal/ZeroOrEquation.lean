/-
Zero-or-equation propagation: constructive arbitrary-carrier kernels.

There is no assumption of induction for arbitrary predicates. EqInd below
is ONE instance for the displayed two term interpretations; each theorem
lists the exact instances it uses. PropagationAt likewise denotes one
specific matrix instance. See SCOPE.txt for the semantic-parameter boundary.

The delayed bridge adapts the attributed DelayedKernel.lean in the supplied
pra_delayed_iteration_2026-11-01 draft. Everything else checks the new
zero-or-equation extraction and its constructive arithmetic bootstrap.

No imports, sorry, added axioms, or classical reasoning.
-/

universe u
namespace ZeroOrEquation
variable {A : Type u}

def EqInd (z : A) (s : A → A) (f g : A → A) : Prop :=
  f z = g z → (∀ n, f n = g n → f (s n) = g (s n)) → ∀ n, f n = g n

def PropagationAt (s : A → A) (F : A → A → Prop) : Prop :=
  ∀ a, (∀ n, F n a → F (s n) a) → ∀ n, F n a

theorem stationary_extract (z : A) (s : A → A) (R : A → Prop)
    (pp : PropagationAt s (fun _ a => R a)) : ∀ a, R a := by
  intro a
  exact pp a (fun _ h => h) z

theorem zero_or_equation_induction (z : A) (s : A → A)
    (f g : A → A → A)
    (pp : PropagationAt s (fun n a => n = z ∨ f n a = g n a)) :
    ∀ a, EqInd z s (fun n => f n a) (fun n => g n a) := by
  intro a base step
  have progress : ∀ n, (n = z ∨ f n a = g n a) →
      s n = z ∨ f (s n) a = g (s n) a := by
    intro n hn
    apply Or.inr
    cases hn with
    | inl hz => exact step n (hz ▸ base)
    | inr he => exact step n he
  intro n
  cases pp a progress n with
  | inl hz => exact hz ▸ base
  | inr he => exact he

theorem coverage_from_propagation (z : A) (s p : A → A)
    (pSucc : ∀ n, p (s n) = n)
    (pp : PropagationAt s (fun n _ => n = z ∨ n = s (p n))) :
    ∀ n, n = z ∨ n = s (p n) := by
  apply pp z
  intro n _
  exact Or.inr (congrArg s (pSucc n)).symm

theorem extract_separation_and_reset (z : A) (s : A → A)
    (q d : A → A → A)
    (pp : PropagationAt s
      (fun _ a => z ≠ s z ∧ ∀ n, d (q n z) a = a)) :
    z ≠ s z ∧ ∀ n a, d (q n z) a = a := by
  have ext := stationary_extract z s
    (fun a => z ≠ s z ∧ ∀ n, d (q n z) a = a) pp
  exact ⟨(ext z).1, fun n a => (ext a).2 n⟩

theorem extract_tail (z : A) (s h : A → A) (d : A → A → A)
    (pp : PropagationAt s
      (fun _ a => ∀ n, d (s (s a)) n = h (d (s a) n))) :
    ∀ n a, d (s (s n)) a = h (d (s n) a) := by
  exact stationary_extract z s
    (fun a => ∀ n, d (s (s a)) n = h (d (s a) n)) pp

theorem extract_combined_computation (z : A) (s h : A → A)
    (q d : A → A → A)
    (pp : PropagationAt s (fun _ a => z ≠ s z ∧
      ∀ n, d (q n z) a = a ∧ d (s (s n)) a = h (d (s n) a))) :
    z ≠ s z ∧ (∀ n a, d (q n z) a = a) ∧
      (∀ n a, d (s (s n)) a = h (d (s n) a)) := by
  have ext := stationary_extract z s (fun a => z ≠ s z ∧
    ∀ n, d (q n z) a = a ∧ d (s (s n)) a = h (d (s n) a)) pp
  exact ⟨(ext z).1, (fun n a => ((ext a).2 n).1),
    fun n a => ((ext a).2 n).2⟩

structure Delayed (z : A) (s h : A → A) where
  run : A → A → A
  atZero : ∀ a, run z a = a
  atOne : ∀ a, run (s z) a = a
  atStep : ∀ n a, run (s (s n)) a = h (run (s n) a)

def delayed_of_reset (z : A) (s h : A → A) (q d : A → A → A)
    (qReset : ∀ n a, q (q n z) a = a)
    (qTail : ∀ n a, q (s (s n)) a = s z)
    (dReset : ∀ n a, d (q n z) a = a)
    (dTail : ∀ n a, d (s (s n)) a = h (d (s n) a)) :
    Delayed z s h where
  run := d
  atOne := by
    intro a
    have e := dReset (s (s z)) a
    rw [qTail z z] at e
    exact e
  atZero := by
    intro a
    have e := qReset (s (s z)) z
    rw [qTail z z] at e
    have r := dReset (s z) a
    rw [e] at r
    exact r
  atStep := dTail

def iter {z : A} {s h : A → A} (d : Delayed z s h) (n a : A) : A :=
  d.run (s n) a

theorem iter_zero {z : A} {s h : A → A} (d : Delayed z s h) (a : A) :
    iter d z a = a := d.atOne a

theorem iter_step {z : A} {s h : A → A} (d : Delayed z s h) (n a : A) :
    iter d (s n) a = h (iter d n a) := d.atStep n a

def pred {z : A} {s : A → A} (ds : Delayed z s s) (n : A) : A :=
  ds.run n z

theorem pred_zero {z : A} {s : A → A} (ds : Delayed z s s) :
    pred ds z = z := ds.atZero z

theorem pred_succ {z : A} {s : A → A} (ds : Delayed z s s)
    (ei : EqInd z s (fun n => ds.run (s n) z) (fun n => n)) :
    ∀ n, pred ds (s n) = n := by
  apply ei
  · exact ds.atOne z
  · intro n ih
    exact (ds.atStep n z).trans (congrArg s ih)

theorem successor_injective (s p : A → A)
    (pSucc : ∀ n, p (s n) = n) {x y : A} (e : s x = s y) : x = y := by
  have t := congrArg p e
  rw [pSucc x, pSucc y] at t
  exact t

theorem successor_ne_zero (z : A) (s p : A → A)
    (pZero : p z = z) (pSucc : ∀ n, p (s n) = n)
    (sep : z ≠ s z) (n : A) : s n ≠ z := by
  intro e
  have t := congrArg p e
  rw [pSucc n, pZero] at t
  exact sep ((congrArg s t).symm.trans e).symm

/- Arithmetic operations below are interpretations of fixed source terms.
   The record contains only their defining equations, coverage, separation.
   Derived arithmetic laws are proved using selected equation instances. -/
structure Arithmetic (A : Type u) where
  zero : A
  succ : A → A
  pre : A → A
  add : A → A → A
  sub : A → A → A
  zeroSel : A → A → A
  preZero : pre zero = zero
  preSucc : ∀ n, pre (succ n) = n
  addZero : ∀ x, add x zero = x
  addSucc : ∀ x y, add x (succ y) = succ (add x y)
  subZero : ∀ x, sub x zero = x
  subSucc : ∀ x y, sub x (succ y) = pre (sub x y)
  zeroSelZero : ∀ a, zeroSel zero a = a
  zeroSelSucc : ∀ n a, zeroSel (succ n) a = zero
  separated : zero ≠ succ zero
  coverage : ∀ n, n = zero ∨ n = succ (pre n)

def arithmetic_of_delayed {z : A} {s : A → A}
    (ds : Delayed z s s) (d0 : Delayed z s (fun _ => z))
    (dp : Delayed z s (pred ds))
    (eiPred : EqInd z s (fun n => ds.run (s n) z) (fun n => n))
    (sep : z ≠ s z) (cov : ∀ n, n = z ∨ n = s (pred ds n)) : Arithmetic A where
  zero := z
  succ := s
  pre := pred ds
  add := fun x y => iter ds y x
  sub := fun x y => iter dp y x
  zeroSel := iter d0
  preZero := pred_zero ds
  preSucc := pred_succ ds eiPred
  addZero := iter_zero ds
  addSucc := fun x y => iter_step ds y x
  subZero := iter_zero dp
  subSucc := fun x y => iter_step dp y x
  zeroSelZero := iter_zero d0
  zeroSelSucc := iter_step d0
  separated := sep
  coverage := cov

structure Reflected (z one b : A) (P : Prop) : Prop where
  cases01 : b = z ∨ b = one
  trueIff : b = one ↔ P

namespace Reflected
variable {z one b c : A} {P Q : Prop}

theorem false_iff (sep : z ≠ one) (r : Reflected z one b P) :
    b = z ↔ ¬P := by
  constructor
  · intro hb hp
    exact sep (hb.symm.trans (r.trueIff.2 hp))
  · intro hn
    cases r.cases01 with
    | inl hz => exact hz
    | inr ho => exact False.elim (hn (r.trueIff.1 ho))

theorem map (r : Reflected z one b P) (hp : P ↔ Q) :
    Reflected z one b Q :=
  ⟨r.cases01, ⟨fun hb => hp.1 (r.trueIff.1 hb),
    fun hq => r.trueIff.2 (hp.2 hq)⟩⟩

theorem transport (r : Reflected z one b P) (hb : b = c) :
    Reflected z one c P := by
  cases hb
  exact r

theorem at_true (hp : P) : Reflected z one one P :=
  ⟨Or.inr rfl, ⟨fun _ => hp, fun _ => rfl⟩⟩

theorem at_false (sep : z ≠ one) (hp : ¬P) : Reflected z one z P :=
  ⟨Or.inl rfl, ⟨fun hb => False.elim (sep hb), fun h => False.elim (hp h)⟩⟩

end Reflected

namespace Arithmetic
variable (o : Arithmetic A)

def one : A := o.succ o.zero

theorem succ_ne_zero (n : A) : o.succ n ≠ o.zero :=
  successor_ne_zero o.zero o.succ o.pre o.preZero o.preSucc o.separated n

theorem zero_or_nonzero (n : A) : n = o.zero ∨ n ≠ o.zero := by
  cases o.coverage n with
  | inl h => exact Or.inl h
  | inr h => exact Or.inr (fun e => o.succ_ne_zero (o.pre n) (h.symm.trans e))

theorem zero_add
    (ei : EqInd o.zero o.succ (fun n => o.add o.zero n) (fun n => n)) :
    ∀ n, o.add o.zero n = n := by
  apply ei
  · exact o.addZero o.zero
  · intro n ih
    exact (o.addSucc o.zero n).trans (congrArg o.succ ih)

theorem succ_add (x : A)
    (ei : EqInd o.zero o.succ
      (fun n => o.add (o.succ x) n) (fun n => o.succ (o.add x n))) :
    ∀ n, o.add (o.succ x) n = o.succ (o.add x n) := by
  apply ei
  · dsimp only
    rw [o.addZero, o.addZero]
  · intro n ih
    dsimp only at ih ⊢
    rw [o.addSucc, o.addSucc, ih]

theorem add_comm (x : A)
    (zeroAdd : ∀ n, o.add o.zero n = n)
    (succAdd : ∀ x y, o.add (o.succ x) y = o.succ (o.add x y))
    (ei : EqInd o.zero o.succ (fun n => o.add x n) (fun n => o.add n x)) :
    ∀ n, o.add x n = o.add n x := by
  apply ei
  · dsimp only
    rw [o.addZero, zeroAdd]
  · intro n ih
    dsimp only at ih ⊢
    rw [o.addSucc, succAdd, ih]

theorem zero_sub
    (ei : EqInd o.zero o.succ (fun n => o.sub o.zero n) (fun _ => o.zero)) :
    ∀ n, o.sub o.zero n = o.zero := by
  apply ei
  · exact o.subZero o.zero
  · intro n ih
    dsimp only at ih ⊢
    rw [o.subSucc, ih, o.preZero]

theorem succ_sub_succ (x : A)
    (ei : EqInd o.zero o.succ
      (fun n => o.sub (o.succ x) (o.succ n)) (fun n => o.sub x n)) :
    ∀ n, o.sub (o.succ x) (o.succ n) = o.sub x n := by
  apply ei
  · dsimp only
    rw [o.subSucc, o.subZero, o.subZero, o.preSucc]
  · intro n ih
    dsimp only at ih ⊢
    rw [o.subSucc (o.succ x) (o.succ n), o.subSucc x n, ih]

theorem pre_sub (x : A)
    (ei : EqInd o.zero o.succ
      (fun n => o.sub (o.pre x) n) (fun n => o.pre (o.sub x n))) :
    ∀ n, o.sub (o.pre x) n = o.pre (o.sub x n) := by
  apply ei
  · dsimp only
    rw [o.subZero, o.subZero]
  · intro n ih
    dsimp only at ih ⊢
    rw [o.subSucc, o.subSucc, ih]

theorem add_sub_cancel (c : A)
    (zeroAdd : ∀ n, o.add o.zero n = n)
    (succAdd : ∀ x y, o.add (o.succ x) y = o.succ (o.add x y))
    (succSubSucc : ∀ x y, o.sub (o.succ x) (o.succ y) = o.sub x y)
    (ei : EqInd o.zero o.succ
      (fun n => o.sub (o.add n c) n) (fun _ => c)) :
    ∀ n, o.sub (o.add n c) n = c := by
  apply ei
  · dsimp only
    rw [zeroAdd, o.subZero]
  · intro n ih
    dsimp only at ih ⊢
    rw [succAdd, succSubSucc, ih]

theorem self_sub
    (cancel : ∀ c n, o.sub (o.add n c) n = c) (x : A) :
    o.sub x x = o.zero := by
  have h := cancel o.zero x
  rw [o.addZero] at h
  exact h

theorem succ_sub_self
    (cancel : ∀ c n, o.sub (o.add n c) n = c) (x : A) :
    o.sub (o.succ x) x = o.one := by
  have h := cancel o.one x
  change o.sub (o.add x (o.succ o.zero)) x = o.one at h
  rw [o.addSucc, o.addZero] at h
  exact h

def select (t b c : A) : A :=
  o.add (o.zeroSel t b) (o.zeroSel (o.zeroSel t o.one) c)

theorem select_zero (b c : A) : o.select o.zero b c = b := by
  unfold select one
  rw [o.zeroSelZero, o.zeroSelZero, o.zeroSelSucc, o.addZero]

theorem select_succ (zeroAdd : ∀ n, o.add o.zero n = n)
    (r b c : A) : o.select (o.succ r) b c = c := by
  unfold select
  rw [o.zeroSelSucc, o.zeroSelSucc, o.zeroSelZero, zeroAdd]

theorem select_guard (zeroAdd : ∀ n, o.add o.zero n = n) (q b c : A) :
    o.select q b c = c ↔ (q = o.zero → b = c) := by
  constructor
  · intro e h
    rw [h, o.select_zero] at e
    exact e
  · intro h
    cases o.coverage q with
    | inl hz => rw [hz, o.select_zero]; exact h hz
    | inr hs => rw [hs, o.select_succ zeroAdd]

/- These premises are previously proved equational ledger entries.
   The only new induction is the explicitly displayed selector equation. -/
theorem gap (t : A)
    (zeroAdd : ∀ n, o.add o.zero n = n)
    (succAdd : ∀ x y, o.add (o.succ x) y = o.succ (o.add x y))
    (zeroSub : ∀ n, o.sub o.zero n = o.zero)
    (preSub : ∀ x y, o.sub (o.pre x) y = o.pre (o.sub x y))
    (succSelf : ∀ x, o.sub (o.succ x) x = o.one)
    (ei : EqInd o.zero o.succ
      (fun x => o.select (o.sub x t) (o.add x (o.sub t x)) t)
      (fun _ => t)) :
    ∀ x, o.sub x t = o.zero → t = o.add x (o.sub t x) := by
  have allEq : ∀ x,
      o.select (o.sub x t) (o.add x (o.sub t x)) t = t := by
    apply ei
    · dsimp only
      rw [zeroSub, o.subZero, zeroAdd, o.select_zero]
    · intro x ih
      dsimp only at ih ⊢
      apply (o.select_guard zeroAdd _ _ _).2
      intro hs
      have hx : o.sub x t = o.zero := by
        have k := preSub (o.succ x) t
        rw [o.preSucc, hs, o.preZero] at k
        exact k
      have ht : t = o.add x (o.sub t x) :=
        ((o.select_guard zeroAdd _ _ _).1 ih hx).symm
      have nonzero : o.sub t x ≠ o.zero := by
        intro hr
        have tx : t = x := by rw [hr, o.addZero] at ht; exact ht
        rw [tx, succSelf] at hs
        exact o.separated hs.symm
      have hr : o.sub t x = o.succ (o.pre (o.sub t x)) := by
        cases o.coverage (o.sub t x) with
        | inl hz => exact False.elim (nonzero hz)
        | inr he => exact he
      calc
        o.add (o.succ x) (o.sub t (o.succ x))
            = o.succ (o.add x (o.pre (o.sub t x))) := by
              rw [o.subSucc, succAdd]
        _ = o.add x (o.succ (o.pre (o.sub t x))) := (o.addSucc _ _).symm
        _ = o.add x (o.sub t x) := congrArg (o.add x) hr.symm
        _ = t := ht.symm
  intro x hx
  exact ((o.select_guard zeroAdd _ _ _).1 (allEq x) hx).symm

theorem equality_iff_two_zero_differences
    (selfSub : ∀ x, o.sub x x = o.zero)
    (gapLaw : ∀ x t, o.sub x t = o.zero → t = o.add x (o.sub t x))
    (x y : A) : x = y ↔ o.sub x y = o.zero ∧ o.sub y x = o.zero := by
  constructor
  · intro he
    subst y
    exact ⟨selfSub x, selfSub x⟩
  · intro he
    have h := gapLaw x y he.1
    rw [he.2, o.addZero] at h
    exact h.symm

def zeroBit (n : A) : A := o.zeroSel n o.one

theorem zero_bit_reflected (n : A) :
    Reflected o.zero o.one (o.zeroBit n) (n = o.zero) := by
  cases o.coverage n with
  | inl hz =>
    have r : Reflected o.zero o.one o.one (n = o.zero) :=
      Reflected.at_true hz
    apply r.transport
    change o.one = o.zeroSel n o.one
    rw [hz, o.zeroSelZero]
  | inr hs =>
    have hn : n ≠ o.zero := fun he => o.succ_ne_zero (o.pre n) (hs.symm.trans he)
    have r : Reflected o.zero o.one o.zero (n = o.zero) :=
      Reflected.at_false o.separated hn
    apply r.transport
    change o.zero = o.zeroSel n o.one
    rw [hs, o.zeroSelSucc]

theorem reflected_and (zeroAdd : ∀ n, o.add o.zero n = n)
    {b c : A} {P Q : Prop} (rb : Reflected o.zero o.one b P)
    (rc : Reflected o.zero o.one c Q) :
    Reflected o.zero o.one (o.select b o.zero c) (P ∧ Q) := by
  cases rb.cases01 with
  | inl hb =>
    have hn : ¬P := (rb.false_iff o.separated).1 hb
    have r : Reflected o.zero o.one o.zero (P ∧ Q) :=
      Reflected.at_false o.separated (fun hp => hn hp.1)
    apply r.transport
    rw [hb, o.select_zero]
  | inr hb =>
    have hp := rb.trueIff.1 hb
    have r := rc.map (Iff.intro (fun hq => And.intro hp hq) (fun h => h.2))
    apply r.transport
    rw [hb]
    exact (o.select_succ zeroAdd o.zero o.zero c).symm

theorem reflected_or (zeroAdd : ∀ n, o.add o.zero n = n)
    {b c : A} {P Q : Prop} (rb : Reflected o.zero o.one b P)
    (rc : Reflected o.zero o.one c Q) :
    Reflected o.zero o.one (o.select b c o.one) (P ∨ Q) := by
  cases rb.cases01 with
  | inl hb =>
    have hn : ¬P := (rb.false_iff o.separated).1 hb
    have r := rc.map (Iff.intro Or.inr (fun h => h.elim (fun hp => False.elim (hn hp)) id))
    apply r.transport
    rw [hb, o.select_zero]
  | inr hb =>
    have r : Reflected o.zero o.one o.one (P ∨ Q) :=
      Reflected.at_true (Or.inl (rb.trueIff.1 hb))
    apply r.transport
    rw [hb]
    exact (o.select_succ zeroAdd o.zero c o.one).symm

theorem reflected_imp (zeroAdd : ∀ n, o.add o.zero n = n)
    {b c : A} {P Q : Prop} (rb : Reflected o.zero o.one b P)
    (rc : Reflected o.zero o.one c Q) :
    Reflected o.zero o.one (o.select b o.one c) (P → Q) := by
  cases rb.cases01 with
  | inl hb =>
    have hn : ¬P := (rb.false_iff o.separated).1 hb
    have r : Reflected o.zero o.one o.one (P → Q) :=
      Reflected.at_true (fun hp => False.elim (hn hp))
    apply r.transport
    rw [hb, o.select_zero]
  | inr hb =>
    have hp := rb.trueIff.1 hb
    have r := rc.map (Iff.intro (fun hq _ => hq) (fun h => h hp))
    apply r.transport
    rw [hb]
    exact (o.select_succ zeroAdd o.zero o.one c).symm

def eqBit (x y : A) : A :=
  o.select (o.zeroBit (o.sub x y)) o.zero (o.zeroBit (o.sub y x))

theorem equality_reflected
    (zeroAdd : ∀ n, o.add o.zero n = n)
    (selfSub : ∀ x, o.sub x x = o.zero)
    (gapLaw : ∀ x t, o.sub x t = o.zero → t = o.add x (o.sub t x))
    (x y : A) : Reflected o.zero o.one (o.eqBit x y) (x = y) := by
  exact (o.reflected_and zeroAdd (o.zero_bit_reflected (o.sub x y))
    (o.zero_bit_reflected (o.sub y x))).map
    (o.equality_iff_two_zero_differences selfSub gapLaw x y).symm

end Arithmetic

/- The complete bootstrap budget: seven explicitly displayed equation
   families, each with at most one frozen element parameter. This is NOT
   a quantification over all predicates or arbitrary semantic functions. -/
structure BootstrapInductions (o : Arithmetic A) : Prop where
  zeroAdd : EqInd o.zero o.succ (fun n => o.add o.zero n) (fun n => n)
  succAdd : ∀ x, EqInd o.zero o.succ
    (fun n => o.add (o.succ x) n) (fun n => o.succ (o.add x n))
  zeroSub : EqInd o.zero o.succ (fun n => o.sub o.zero n) (fun _ => o.zero)
  succSubSucc : ∀ x, EqInd o.zero o.succ
    (fun n => o.sub (o.succ x) (o.succ n)) (fun n => o.sub x n)
  preSub : ∀ x, EqInd o.zero o.succ
    (fun n => o.sub (o.pre x) n) (fun n => o.pre (o.sub x n))
  cancel : ∀ c, EqInd o.zero o.succ
    (fun n => o.sub (o.add n c) n) (fun _ => c)
  gap : ∀ t, EqInd o.zero o.succ
    (fun x => o.select (o.sub x t) (o.add x (o.sub t x)) t) (fun _ => t)

structure Calibration (o : Arithmetic A) : Prop where
  zeroAdd : ∀ n, o.add o.zero n = n
  selfSub : ∀ x, o.sub x x = o.zero
  gap : ∀ x t, o.sub x t = o.zero → t = o.add x (o.sub t x)

def calibrate (o : Arithmetic A) (budget : BootstrapInductions o) :
    Calibration o := by
  have za := o.zero_add budget.zeroAdd
  have sa : ∀ x y, o.add (o.succ x) y = o.succ (o.add x y) :=
    fun x => o.succ_add x (budget.succAdd x)
  have zs := o.zero_sub budget.zeroSub
  have ss : ∀ x y, o.sub (o.succ x) (o.succ y) = o.sub x y :=
    fun x => o.succ_sub_succ x (budget.succSubSucc x)
  have ps : ∀ x y, o.sub (o.pre x) y = o.pre (o.sub x y) :=
    fun x => o.pre_sub x (budget.preSub x)
  have cc : ∀ c n, o.sub (o.add n c) n = c :=
    fun c => o.add_sub_cancel c za sa ss (budget.cancel c)
  have sx := o.succ_sub_self cc
  exact ⟨za, o.self_sub cc, fun x t => o.gap t za sa zs ps sx (budget.gap t) x⟩

/- Finite QF syntax whose leaves are interpretations of source terms.
   Atom functions are semantic parameters, NOT new source function symbols.
   No quantified-formula constructor is included. -/
inductive Formula (A : Type u) where
  | atom : (A → A → A) → (A → A → A) → Formula A
  | bot : Formula A
  | conj : Formula A → Formula A → Formula A
  | disj : Formula A → Formula A → Formula A
  | impl : Formula A → Formula A → Formula A

namespace Formula

def holds : Formula A → A → A → Prop
  | .atom f g, n, a => f n a = g n a
  | .bot, _, _ => False
  | .conj B C, n, a => B.holds n a ∧ C.holds n a
  | .disj B C, n, a => B.holds n a ∨ C.holds n a
  | .impl B C, n, a => B.holds n a → C.holds n a

def bit (o : Arithmetic A) : Formula A → A → A → A
  | .atom f g, n, a => o.eqBit (f n a) (g n a)
  | .bot, _, _ => o.zero
  | .conj B C, n, a => o.select (B.bit o n a) o.zero (C.bit o n a)
  | .disj B C, n, a => o.select (B.bit o n a) (C.bit o n a) o.one
  | .impl B C, n, a => o.select (B.bit o n a) o.one (C.bit o n a)

theorem reflected (o : Arithmetic A)
    (zeroAdd : ∀ n, o.add o.zero n = n)
    (selfSub : ∀ x, o.sub x x = o.zero)
    (gapLaw : ∀ x t, o.sub x t = o.zero → t = o.add x (o.sub t x))
    (F : Formula A) (n a : A) :
    Reflected o.zero o.one (F.bit o n a) (F.holds n a) := by
  induction F with
  | atom f g => exact o.equality_reflected zeroAdd selfSub gapLaw (f n a) (g n a)
  | bot => exact Reflected.at_false o.separated (fun h => h)
  | conj B C ihB ihC => exact o.reflected_and zeroAdd ihB ihC
  | disj B C ihB ihC => exact o.reflected_or zeroAdd ihB ihC
  | impl B C ihB ihC => exact o.reflected_imp zeroAdd ihB ihC

theorem induction_from_bit_equation (o : Arithmetic A)
    (zeroAdd : ∀ n, o.add o.zero n = n)
    (selfSub : ∀ x, o.sub x x = o.zero)
    (gapLaw : ∀ x t, o.sub x t = o.zero → t = o.add x (o.sub t x))
    (F : Formula A) (a : A)
    (ei : EqInd o.zero o.succ (fun n => F.bit o n a) (fun _ => o.one))
    (base : F.holds o.zero a)
    (step : ∀ n, F.holds n a → F.holds (o.succ n) a) :
    ∀ n, F.holds n a := by
  have allBits : ∀ n, F.bit o n a = o.one := by
    apply ei
    · exact (reflected o zeroAdd selfSub gapLaw F o.zero a).trueIff.2 base
    · intro n ih
      exact (reflected o zeroAdd selfSub gapLaw F (o.succ n) a).trueIff.2
        (step n ((reflected o zeroAdd selfSub gapLaw F n a).trueIff.1 ih))
  intro n
  exact (reflected o zeroAdd selfSub gapLaw F n a).trueIff.1 (allBits n)

theorem reflected_from_selected_instances (o : Arithmetic A)
    (budget : BootstrapInductions o) (F : Formula A) (n a : A) :
    Reflected o.zero o.one (F.bit o n a) (F.holds n a) := by
  let c := calibrate o budget
  exact reflected o c.zeroAdd c.selfSub c.gap F n a

theorem induction_from_selected_instances (o : Arithmetic A)
    (budget : BootstrapInductions o) (F : Formula A) (a : A)
    (ei : EqInd o.zero o.succ (fun n => F.bit o n a) (fun _ => o.one))
    (base : F.holds o.zero a)
    (step : ∀ n, F.holds n a → F.holds (o.succ n) a) :
    ∀ n, F.holds n a := by
  let c := calibrate o budget
  exact induction_from_bit_equation o c.zeroAdd c.selfSub c.gap F a ei base step

end Formula
end ZeroOrEquation

#print axioms ZeroOrEquation.zero_or_equation_induction
#print axioms ZeroOrEquation.coverage_from_propagation
#print axioms ZeroOrEquation.extract_separation_and_reset
#print axioms ZeroOrEquation.extract_tail
#print axioms ZeroOrEquation.extract_combined_computation
#print axioms ZeroOrEquation.delayed_of_reset
#print axioms ZeroOrEquation.pred_succ
#print axioms ZeroOrEquation.arithmetic_of_delayed
#print axioms ZeroOrEquation.Arithmetic.select_guard
#print axioms ZeroOrEquation.Arithmetic.gap
#print axioms ZeroOrEquation.Arithmetic.equality_iff_two_zero_differences
#print axioms ZeroOrEquation.Arithmetic.equality_reflected
#print axioms ZeroOrEquation.Arithmetic.reflected_imp
#print axioms ZeroOrEquation.Formula.reflected
#print axioms ZeroOrEquation.Formula.induction_from_bit_equation
#print axioms ZeroOrEquation.calibrate
#print axioms ZeroOrEquation.Formula.reflected_from_selected_instances
#print axioms ZeroOrEquation.Formula.induction_from_selected_instances
