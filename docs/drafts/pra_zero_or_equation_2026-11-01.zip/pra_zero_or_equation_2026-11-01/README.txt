PRIMITIVE RECURSIVE ARITHMETIC FROM A SINGLE DISJUNCTION
Research prepared for Vladimir Reshetnikov, 1 November 2026.

START HERE

  report.pdf           Complete mathematical report.
  report.tex           Main LaTeX source.
  bootstrap.tex        New constructive equality/induction calibration.
  calibration.tex      Explicit pairing and primitive-recursion compiler.
  counter_aware.tex     Alternative computational interface and its tradeoff.
  AXIOMS.txt           Complete standalone theory specification.

RESULT

The dynamic induction matrix needs only two term inputs:

  n=0 OR s(n,a)=t(n,a).

Together with the best inspected two-scheme delayed-iteration interface,
this gives an effective axiom generator with the same specification in
classical and intuitionistic logic. The report proves a common conservative
definitional extension with first-order PRA in each matching logic, including
both full-carrier, native-equality identity round trips.

This is a reduction in the generator's logical input grammar. It is not an
absolute shortestness claim or an expanded-symbol-count record. The paper
and counts.json disclose a small count increase for one selected instance
of each constructor; these selections are not equivalent finite theories.

COMPARISON

All six archives currently in ProveIt/docs/drafts were inspected at commit
13300d26dac24e7e6b75fe38fd21fb5b5d416d41. The source manifest identifies
the exact archives and hashes. The delayed arithmetic and numerical pairing
are inherited with attribution; the fixed disjunctive matrix and its
constructive bootstrap are the new reduction relative to that snapshot.

VERIFICATION

  checks/check_spec.py         Finite syntax, scope, count, and arithmetic checks.
  checks/results.json          Results and exact finite verification scope.
  checks/counts.json           Explicit node-count conventions and ledger.
  formal/ZeroOrEquation.lean   Constructive kernel over an arbitrary carrier.
  formal/SCOPE.txt             Exact checked hypotheses and remaining boundary.
  formal/lean-check.log        Successful Lean 4.19.0 compiler output.
  formal/verification.json     Compiler receipt and source hash.
  audit/source_manifest.json   Pinned six-draft inventory and hashes.
  audit/build_results.json     Rebuild receipt.
  audit/pdf_validation.json    PDF and layout review record.
  SHA256SUMS.txt               Archive-member checksums, excluding this list.

The Lean file uses no added axioms, sorry, classical reasoning, or Mathlib.
Eighteen printed declaration-dependency checks report no axioms. It checks
propagation, delayed seeds, predecessor, selected arithmetic induction,
the selector-equation gap proof, native equality reflection, and the finite
QF compiler. Full syntactic bi-interpretability remains a written proof.

REBUILD

Requirements: Python 3.10+, pdflatex with standard LaTeX packages listed in
report.tex. Lean is optional for rebuilding the PDF; use version 4.19.0
to reproduce the formal check. No Python third-party packages are needed.

  python3 build.py
  python3 build.py --lean /absolute/path/to/lean

The first command runs the syntax checker and compiles the PDF twice.
The second also reruns the Lean kernel. It records the results without
claiming that omitted optional checks ran. Run checks alone with:

  python3 checks/check_spec.py

Run the proof file alone from its directory with:

  lean ZeroOrEquation.lean

MATHEMATICAL LIMIT

The theory is an infinite effective first-order schema. The fixed schema
does not quantify over functions or predicates in the object language.
No universal evaluator or standardness assumption is used. A product
countermodel proves that replacing the positive matrix by equation
induction alone would fail to recover the needed constructor coverage.
