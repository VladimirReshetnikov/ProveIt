#!/usr/bin/env python3
"""Compile the report with ordinary pdfLaTeX; no shell escape or network."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
BUILD = ROOT / "build"
BUILD.mkdir(exist_ok=True)
engine = shutil.which("pdflatex")
if not engine:
    raise SystemExit("pdflatex is required to rebuild the included PDF")
command = [engine, "-no-shell-escape", "-interaction=nonstopmode",
           "-halt-on-error", "-file-line-error", "-output-directory=build", "report.tex"]
for step in range(3):
    result = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, timeout=120)
    (BUILD / f"pass-{step+1}.txt").write_text(result.stdout)
    if result.returncode:
        print(result.stdout[-9000:])
        raise SystemExit(result.returncode)
log = (BUILD / "report.log").read_text(errors="replace")
bad = [line for line in log.splitlines()
       if "Overfull" in line or "undefined" in line.lower()
       or "Rerun to get cross-references right" in line]
pdf = ROOT / "report.pdf"
shutil.copyfile(BUILD / "report.pdf", pdf)
receipt = {"engine": "pdfLaTeX", "passes": 3, "shell_escape": False,
           "pdf_bytes": pdf.stat().st_size,
           "pdf_sha256": hashlib.sha256(pdf.read_bytes()).hexdigest(),
           "layout_or_reference_warnings": bad}
(ROOT / "results").mkdir(exist_ok=True)
(ROOT / "results" / "build_receipt.json").write_text(json.dumps(receipt, indent=2)+"\n")
print(json.dumps(receipt, indent=2))
if bad:
    raise SystemExit("Resolve the reported layout/reference warnings before delivery")
