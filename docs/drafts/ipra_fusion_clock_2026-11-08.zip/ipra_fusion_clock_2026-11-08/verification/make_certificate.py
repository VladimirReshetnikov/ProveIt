#!/usr/bin/env python3
"""Untrusted producer for the narrow symbolic fusion/clock certificate."""
import copy
import json
from pathlib import Path


def v(name):
    return ["v", name]


def app(symbol, *args):
    return ["app", symbol, *args]


def it(symbol, counter, initial, params=()):
    return ["it", symbol, counter, initial, *params]


def refl(t):
    return {"r": "refl", "t": t}


def sym(p):
    return {"r": "sym", "p": p}


def trans(p, q):
    return {"r": "trans", "left": p, "right": q}


def cong(context, proof):
    return {"r": "cong", "context": context, "p": proof}


zero, hole = ["zero"], ["hole"]
n, a, p, z1, z2, z3 = map(v, ("n", "a", "p", "z1", "z2", "z3"))

clock = sym({"r": "U", "eigen": "z1", "template": z1,
             "update": "s", "params": [], "target": n,
             "premise": refl(app("s", z1))})

iterate_z = it("g", z2, a, [p])
step_compute = {"r": "compS", "update": "g", "counter": z2,
                "initial": a, "params": [p]}
step_hyp = {"r": "hyp", "name": "intertwining", "argument": iterate_z}
recurrence = trans(cong(app("f", hole, p), step_compute), step_hyp)
unique = {"r": "U", "eigen": "z2", "template": app("f", iterate_z, p),
          "update": "h", "params": [p], "target": n, "premise": recurrence}
base_compute = {"r": "comp0", "update": "g", "initial": a, "params": [p]}
base_image = cong(app("f", hole, p), base_compute)
fusion_from_u = trans(unique, cong(it("h", n, hole, [p]), base_image))

fusion = {"r": "fusion", "eigen": "z3", "map": app("f", z3, p),
          "source_update": "s", "source_params": [],
          "target_update": "h", "target_params": [p],
          "counter": n, "initial": zero,
          "premise": {"r": "hyp", "name": "recurrence", "argument": z3}}
clock_image = cong(app("f", hole, p), {"r": "clock", "counter": n})
u_from_fusion_clock = trans(sym(clock_image), fusion)

proofs = [
    {"claim": "uniqueness_to_clock", "proof": clock},
    {"claim": "uniqueness_to_fusion", "proof": fusion_from_u},
    {"claim": "fusion_clock_to_uniqueness", "proof": u_from_fusion_clock},
]
controls = []


def control(label, claim, proof):
    controls.append({"label": label, "claim": claim, "proof": proof})


control("unlicensed_clock_shortcut", "uniqueness_to_clock", {"r": "clock", "counter": n})
bad = copy.deepcopy(clock)
bad["p"]["eigen"] = "n"
control("eigenvariable_collides_with_target", "uniqueness_to_clock", bad)
bad = copy.deepcopy(fusion_from_u)
bad["left"]["premise"]["right"]["argument"] = zero
control("intertwining_at_wrong_argument", "uniqueness_to_fusion", bad)
control("reflexivity_does_not_prove_clock", "uniqueness_to_clock", refl(n))
bad = copy.deepcopy(u_from_fusion_clock)
bad["right"]["source_update"] = "g"
bad["right"]["source_params"] = [p]
control("wrong_fusion_source_update", "fusion_clock_to_uniqueness", bad)
bad = copy.deepcopy(fusion_from_u)
bad["left"]["template"] = app("f", v("escaped"), p)
control("free_variable_escapes_scope", "uniqueness_to_fusion", bad)

bundle = {"format": "scalar-fusion-clock-equations-v1", "proofs": proofs,
          "negative_controls": controls}
destination = Path(__file__).with_name("fusion_clock_certificate.json")
destination.write_text(json.dumps(bundle, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(destination.name)
