#!/usr/bin/env python3
"""Finite diagnostics for the ambient pair algebra, not a finite countermodel.

The actual mathematical model restricts an uncountable nonstandard model M
to A = (M x {0}) union ((M minus its standard cut) x M).  Python integers
cannot instantiate that domain.  These checks only exercise the fixed
finite computations used in its algebraic construction.
"""

from __future__ import annotations

import json
import random
from collections import Counter
from itertools import product


# Numerical term AST: zero, variable, successor, or a state-binding iterator.
# An iterator's other free variables are fixed numerical parameters.
ZERO = ("zero",)


def var(name):
    return ("var", name)


def succ(term):
    return ("succ", term)


def iterate(count, initial, state, body):
    return ("iter", count, initial, state, body)


def evaluate(term, env):
    """Interpret one fixed scalar term in the ambient natural-pair algebra."""
    match term:
        case ("zero",):
            return (0, 0)
        case ("var", name):
            return env[name]
        case ("succ", inner):
            height, tag = evaluate(inner, env)
            return (height + 1, tag)
        case ("iter", count, initial, state, body):
            # Only the COUNT tag is ignored. State and parameter tags persist.
            n, _ = evaluate(count, env)
            value = evaluate(initial, env)
            for _ in range(n):
                local = dict(env)
                local[state] = value
                value = evaluate(body, local)
            return value
    raise ValueError("unknown term")


def evaluate_height(term, env):
    """Ordinary numerical interpretation of the same fixed scalar syntax."""
    match term:
        case ("zero",):
            return 0
        case ("var", name):
            return env[name]
        case ("succ", inner):
            return evaluate_height(inner, env) + 1
        case ("iter", count, initial, state, body):
            n = evaluate_height(count, env)
            value = evaluate_height(initial, env)
            for _ in range(n):
                local = dict(env)
                local[state] = value
                value = evaluate_height(body, local)
            return value
    raise ValueError("unknown term")


def call(body, value, env):
    return evaluate(body, dict(env, u=value))


def orbit(body, count, initial, env):
    # Independent host-level orbit driver for the displayed fusion instances.
    value = initial
    for _ in range(count[0]):
        value = call(body, value, env)
    return value


def threshold_related(left, right, bound):
    return left[0] == right[0] and (
        left[0] >= bound or left[1] == right[1]
    )


def transpose(value):
    height, tag = value
    return height, {1: 2, 2: 1}.get(tag, tag)


def require(condition, label):
    if not condition:
        raise AssertionError(label)


def run():
    counts = Counter()
    u, n, a, p, q = map(var, ("u", "n", "a", "p", "q"))
    s = var("s")
    plus_p = iterate(p, u, "s", succ(s))
    plus_q = iterate(q, u, "s", succ(s))
    double = iterate(u, u, "s", succ(s))
    double_p = iterate(p, p, "s", succ(s))
    plus_twice_p = iterate(double_p, u, "s", succ(s))
    seed_p = iterate(u, p, "s", succ(s))
    gate = iterate(u, q, "s", p)
    reset = succ(gate)
    gated_state = iterate(q, u, "s", p)
    updates = [u, succ(u), ZERO, p, plus_p, reset, gated_state]
    terms = [ZERO, succ(u), double, seed_p, gate]
    terms += [iterate(n, a, "u", body) for body in updates]
    terms.append(iterate(n, iterate(q, a, "s", succ(s)), "u", reset))

    rng = random.Random(20261108)
    variables = ("u", "n", "a", "p", "q")
    for bound in range(7):
        for _ in range(150):
            left = {}
            right = {}
            for name in variables:
                height = rng.randrange(7)
                tag = rng.randrange(4)
                left[name] = (height, tag)
                right[name] = (
                    height,
                    tag if height < bound else rng.randrange(4),
                )
            for term in terms:
                lv = evaluate(term, left)
                rv = evaluate(term, right)
                require(threshold_related(lv, rv, bound), "joint threshold")
                counts["joint_threshold_checks"] += 1
                heights = {name: value[0] for name, value in left.items()}
                require(lv[0] == evaluate_height(term, heights), "height projection")
                counts["height_projection_checks"] += 1
                canonical = {name: (value[0], 0) for name, value in left.items()}
                require(evaluate(term, canonical)[1] == 0, "canonical tag")
                counts["canonical_tag_checks"] += 1
                permuted = {name: transpose(value) for name, value in left.items()}
                require(evaluate(term, permuted) == transpose(lv), "tag equivariance")
                counts["joint_parameter_equivariance_checks"] += 1

    samples = list(product(range(5), range(4)))
    parameter_samples = [(0, 0), (0, 2), (1, 1), (3, 2)]
    iteration_samples = [(0, 0), (0, 3), (1, 2), (2, 1), (4, 3)]

    for pv, qv in product(parameter_samples, repeat=2):
        env = {"p": pv, "q": qv}
        for body, av, nv in product(updates, samples, iteration_samples):
            term = iterate(n, a, "u", body)
            require(
                evaluate(term, dict(env, n=(0, 0), a=av)) == av,
                "zero computation",
            )
            counts["zero_computation_checks"] += 1
            lhs = evaluate(term, dict(env, n=(nv[0] + 1, nv[1]), a=av))
            rhs = call(body, evaluate(term, dict(env, n=nv, a=av)), env)
            require(lhs == rhs, "successor computation")
            counts["successor_computation_checks"] += 1

        # Each triple means f(g(x)) = h(f(x)). These examples include captured
        # nonzero parameter tags and maps that either retain or discard x's tag.
        fusion_cases = [
            ("two_parameter_translations", plus_q, plus_p, plus_p),
            ("doubling_and_translation", double, plus_p, plus_twice_p),
            ("tag_replacing_affine_map", seed_p, succ(u), succ(u)),
            ("constant_parameter_map", q, reset, q),
            ("constant_parameter_update", succ(u), p, succ(p)),
            ("nonlinear_map_identity_updates", gate, u, u),
        ]
        for label, f, g, h in fusion_cases:
            for value in samples:
                require(
                    call(f, call(g, value, env), env)
                    == call(h, call(f, value, env), env),
                    label + " intertwining",
                )
                counts["intertwining_sample_checks"] += 1
            for av, nv in product(samples, iteration_samples):
                lhs = call(f, orbit(g, nv, av, env), env)
                rhs = orbit(h, nv, call(f, av, env), env)
                require(lhs == rhs, label + " fusion")
                counts["fusion_sample_checks"] += 1

    # Ambient illustration only: a nonzero tag disappears from a count.
    # The actual countermodel requires a NONSTANDARD height for this witness.
    tagged_count = (7, 2)
    clock_value = evaluate(iterate(n, ZERO, "s", succ(s)), {"n": tagged_count})
    require(
        clock_value == (7, 0) and clock_value != tagged_count,
        "ambient clock tag loss",
    )
    counts["ambient_clock_tag_loss_examples"] += 1

    return {
        "status": "PASS",
        "scope": "finite computations in the ambient pair algebra only",
        "not_claimed": [
            "a finite model of the strengthened theory",
            "a numerical construction of the nonstandard allowed domain A",
            "verification of universal stationarity or full induction",
            "a machine-checked proof of non-bi-interpretability",
            "a complete iPRA proof checker or a source-size record",
        ],
        "checks": dict(sorted(counts.items())),
        "total_checks": sum(counts.values()),
        "ambient_clock_illustration": {
            "count": tagged_count,
            "value": clock_value,
            "caveat": "replace height 7 by a nonstandard height in the mathematical witness",
        },
    }


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
