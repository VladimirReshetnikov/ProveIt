#!/usr/bin/env python3
"""Replay three generic equational derivations for fusion and scalar uniqueness.

This deliberately narrow verifier is not a complete iPRA proof checker and
does not verify the infinite tagged countermodel.  Its charged U and fusion
inferences are exactly the principles compared in the report.  No assertion
statement, theorem library, proof producer, or external oracle is trusted.
"""
import json
import re
import sys
from pathlib import Path


class ProofError(Exception):
    pass


def require(condition, message):
    if not condition:
        raise ProofError(message)


def keys(obj, expected):
    require(type(obj) is dict and set(obj) == set(expected),
            "Unexpected or missing object fields")


def v(name):
    return ["v", name]


ZERO = ["zero"]
SIGNATURE = {"s": 1, "f": 2, "g": 2, "h": 2}


def app(symbol, *args):
    return ["app", symbol, *args]


def it(symbol, counter, initial, params=()):
    return ["it", symbol, counter, initial, *params]


def subst(term, name, replacement):
    if term == ["v", name]:
        return replacement
    if term[0] in ("zero", "v", "hole"):
        return term
    return term[:2] + [subst(x, name, replacement) for x in term[2:]]


def fill(term, replacement):
    if term == ["hole"]:
        return replacement
    if term[0] in ("zero", "v"):
        return term
    return term[:2] + [fill(x, replacement) for x in term[2:]]


def problem(name):
    n, a, p, w = v("n"), v("a"), v("p"), v("w")
    if name == "uniqueness_to_clock":
        return ({"n"}, {}, {"U"}, [it("s", n, ZERO), n])
    if name == "uniqueness_to_fusion":
        hypothesis = [app("f", app("g", w, p), p),
                      app("h", app("f", w, p), p)]
        goal = [app("f", it("g", n, a, [p]), p),
                it("h", n, app("f", a, p), [p])]
        return ({"n", "a", "p"}, {"intertwining": ("w", hypothesis)},
                {"U"}, goal)
    if name == "fusion_clock_to_uniqueness":
        hypothesis = [app("f", app("s", w), p),
                      app("h", app("f", w, p), p)]
        goal = [app("f", n, p), it("h", n, app("f", ZERO, p), [p])]
        return ({"n", "p"}, {"recurrence": ("w", hypothesis)},
                {"fusion", "clock"}, goal)
    raise ProofError("Unknown claim")


class Checker:
    def __init__(self, claim):
        self.scope, self.hypotheses, self.principles, self.goal = problem(claim)
        self.nodes = 0
        self.rule_counts = {}
        self.eigenvariables = []

    def term(self, t, scope, hole=False, depth=0):
        require(depth < 80, "Term depth limit exceeded")
        require(type(t) is list and bool(t), "A term must be a nonempty array")
        tag = t[0]
        require(type(tag) is str, "A term tag must be a string")
        if tag == "zero":
            require(len(t) == 1, "Zero has no arguments")
        elif tag == "hole":
            require(hole and len(t) == 1, "A context hole escaped")
        elif tag == "v":
            require(len(t) == 2 and type(t[1]) is str and t[1] in scope,
                    "Unbound numerical variable")
        elif tag in ("app", "it"):
            require(len(t) >= 2 and type(t[1]) is str and t[1] in SIGNATURE,
                    "Unknown numerical operation")
            arity = SIGNATURE[t[1]] + (1 if tag == "it" else 0)
            require(len(t) == arity + 2, "Wrong numerical operation arity")
            for child in t[2:]:
                self.term(child, scope, hole, depth + 1)
        else:
            raise ProofError("Unknown term constructor")
        return t

    def update(self, symbol, params, scope):
        require(type(symbol) is str and symbol in SIGNATURE,
                "Unknown update symbol")
        require(type(params) is list and len(params) == SIGNATURE[symbol] - 1,
                "Wrong passive-parameter count")
        for t in params:
            self.term(t, scope)

    def fresh(self, name, scope):
        require(type(name) is str and re.fullmatch(r"[a-z][a-z0-9_]*", name),
                "Malformed eigenvariable")
        require(name not in scope, "Eigenvariable is already in scope")
        # The sole bound hypothesis name w is also reserved, a harmless
        # strengthening of capture-avoidance for these three certificates.
        require(all(name != binder for binder, _ in self.hypotheses.values()),
                "Eigenvariable collides with a hypothesis binder")
        self.eigenvariables.append(name)
        return scope | {name}

    def proof(self, node, scope=None, depth=0):
        if scope is None:
            scope = self.scope
        require(depth < 80, "Proof depth limit exceeded")
        self.nodes += 1
        require(self.nodes <= 2000, "Proof size limit exceeded")
        require(type(node) is dict and type(node.get("r")) is str,
                "Malformed proof node")
        r = node["r"]
        self.rule_counts[r] = self.rule_counts.get(r, 0) + 1
        child = lambda p: self.proof(p, scope, depth + 1)

        if r == "refl":
            keys(node, ("r", "t"))
            t = self.term(node["t"], scope)
            return [t, t]
        if r == "sym":
            keys(node, ("r", "p"))
            a, b = child(node["p"])
            return [b, a]
        if r == "trans":
            keys(node, ("r", "left", "right"))
            a, b = child(node["left"])
            c, d = child(node["right"])
            require(b == c, "Transitivity endpoints do not match")
            return [a, d]
        if r == "cong":
            keys(node, ("r", "context", "p"))
            context = self.term(node["context"], scope, hole=True)
            a, b = child(node["p"])
            return [fill(context, a), fill(context, b)]
        if r == "hyp":
            keys(node, ("r", "name", "argument"))
            require(type(node["name"]) is str and node["name"] in self.hypotheses,
                    "Unknown hypothesis")
            argument = self.term(node["argument"], scope)
            binder, equation = self.hypotheses[node["name"]]
            return [subst(t, binder, argument) for t in equation]
        if r in ("comp0", "compS"):
            fields = ("r", "update", "initial", "params")
            if r == "compS":
                fields += ("counter",)
            keys(node, fields)
            h, params = node["update"], node["params"]
            self.update(h, params, scope)
            initial = self.term(node["initial"], scope)
            if r == "comp0":
                return [it(h, ZERO, initial, params), initial]
            counter = self.term(node["counter"], scope)
            return [it(h, app("s", counter), initial, params),
                    app(h, it(h, counter, initial, params), *params)]
        if r == "clock":
            keys(node, ("r", "counter"))
            require("clock" in self.principles, "Clock is not licensed in this claim")
            counter = self.term(node["counter"], scope)
            return [it("s", counter, ZERO), counter]
        if r == "U":
            keys(node, ("r", "eigen", "template", "update", "params",
                        "target", "premise"))
            require("U" in self.principles, "Uniqueness is not licensed in this claim")
            inner = self.fresh(node["eigen"], scope)
            z = v(node["eigen"])
            template = self.term(node["template"], inner)
            h, params = node["update"], node["params"]
            self.update(h, params, scope)
            target = self.term(node["target"], scope)
            expected = [subst(template, z[1], app("s", z)),
                        app(h, template, *params)]
            actual = self.proof(node["premise"], inner, depth + 1)
            require(actual == expected, "Uniqueness recurrence premise does not match")
            return [subst(template, z[1], target),
                    it(h, target, subst(template, z[1], ZERO), params)]
        if r == "fusion":
            keys(node, ("r", "eigen", "map", "source_update", "source_params",
                        "target_update", "target_params", "counter", "initial", "premise"))
            require("fusion" in self.principles, "Fusion is not licensed in this claim")
            inner = self.fresh(node["eigen"], scope)
            z = v(node["eigen"])
            mapping = self.term(node["map"], inner)
            g, gp = node["source_update"], node["source_params"]
            h, hp = node["target_update"], node["target_params"]
            self.update(g, gp, scope)
            self.update(h, hp, scope)
            counter = self.term(node["counter"], scope)
            initial = self.term(node["initial"], scope)
            expected = [subst(mapping, z[1], app(g, z, *gp)),
                        app(h, mapping, *hp)]
            actual = self.proof(node["premise"], inner, depth + 1)
            require(actual == expected, "Fusion intertwining premise does not match")
            return [subst(mapping, z[1], it(g, counter, initial, gp)),
                    it(h, counter, subst(mapping, z[1], initial), hp)]
        raise ProofError("Unknown inference rule")

    def verify(self, proof):
        equation = self.proof(proof)
        for term in equation:
            self.term(term, self.scope)
        require(equation == self.goal, "Conclusion is not the exact required generic equation")
        return {"nodes": self.nodes, "rule_counts": self.rule_counts,
                "eigenvariables": self.eigenvariables, "conclusion": equation}


CLAIMS = {"uniqueness_to_clock", "uniqueness_to_fusion", "fusion_clock_to_uniqueness"}


def verify_bundle(bundle):
    keys(bundle, ("format", "proofs", "negative_controls"))
    require(bundle["format"] == "scalar-fusion-clock-equations-v1", "Unknown certificate format")
    require(type(bundle["proofs"]) is list and len(bundle["proofs"]) == 3,
            "Exactly three positive claims are required")
    require(type(bundle["negative_controls"]) is list and len(bundle["negative_controls"]) == 6,
            "Exactly six negative controls are required")
    names, positives, negatives = set(), [], []
    for item in bundle["proofs"]:
        keys(item, ("claim", "proof"))
        require(type(item["claim"]) is str and item["claim"] in CLAIMS,
                "Unknown positive claim")
        require(item["claim"] not in names, "Duplicate positive claim")
        names.add(item["claim"])
        detail = Checker(item["claim"]).verify(item["proof"])
        positives.append({"claim": item["claim"], "status": "accepted", **detail})
    require(names == CLAIMS, "Missing positive claim")
    for item in bundle["negative_controls"]:
        keys(item, ("label", "claim", "proof"))
        require(type(item["label"]) is str and type(item["claim"]) is str and item["claim"] in CLAIMS,
                "Malformed negative-control metadata")
        try:
            Checker(item["claim"]).verify(item["proof"])
        except ProofError as error:
            negatives.append({"label": item["label"], "status": "rejected", "reason": str(error)})
        else:
            raise ProofError("A negative control was incorrectly accepted: " + item["label"])
    return {"status": "PASS", "accepted_generic_derivations": len(positives),
            "rejected_negative_controls": len(negatives), "positive_results": positives,
            "negative_results": negatives,
            "scope": "Symbolic equational replay only; not a complete iPRA checker or formal verification of the infinite countermodel."}


def main():
    require(len(sys.argv) == 2, "Usage: check_certificate.py CERTIFICATE.json")
    raw = Path(sys.argv[1]).read_bytes()
    require(len(raw) <= 1_000_000, "Certificate size limit exceeded")
    result = verify_bundle(json.loads(raw))
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    try:
        main()
    except (ProofError, ValueError, TypeError, KeyError, IndexError, OSError, RecursionError) as error:
        print(json.dumps({"status": "REJECT", "reason": str(error)}, sort_keys=True))
        sys.exit(1)
