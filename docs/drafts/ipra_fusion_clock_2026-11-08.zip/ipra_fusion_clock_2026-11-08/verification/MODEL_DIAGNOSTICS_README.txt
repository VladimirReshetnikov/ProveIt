AMBIENT PAIR-ALGEBRA DIAGNOSTICS
==============================

Run with Python 3.10 or later, from the package root:

    python3 verification/model_diagnostics.py

Only Python's standard library is used. The program prints its exact executed
check counts and raises an explicit error if a checked property disagrees.
Its checks remain enabled under Python's -O flag. It is separate from the
symbolic certificate checker.

What is implemented
-------------------
The script interprets fixed scalar term descriptions on ordinary pairs
(height, tag). Zero is (0,0), successor increments height while retaining the
tag, and a scalar iterator uses the height of its count while preserving the
tags carried by its initial state and all fixed update parameters. An update
may contain further iterators and freely captured numerical parameters.

The finite diagnostics check:

* joint preservation of selected threshold relations, including passive
  parameter coordinates;
* the height projection and preservation of the all-zero-tag section;
* equivariance under transposition of two nonzero tag values, jointly in
  all arguments and parameters;
* both computation equations for several open updates;
* selected intertwining and fusion calculations, including genuinely
  parameterized maps that retain or discard state tags;
* a schematic example of the successor clock discarding its count tag.

All numerical ranges and the deterministic random seed are visible in the
source. No test is counted as verification of a universal mathematical law.

Essential scope restriction
---------------------------
The actual countermodel is not a finite pair algebra. It uses an uncountable
nonstandard arithmetic model M and the domain

    A = (M x {0}) union ((M minus its external standard cut) x M).

In particular a nonzero tag at a standard numerical height is NOT an allowed
point of A. The script deliberately works in the larger ambient algebra and
does not pretend that its tagged small numbers satisfy the coverage and
stationarity assertions of the theorem. Its height-7 clock example illustrates
the tag-discarding formula only; the theorem's actual witness has nonstandard
height.

The all-term threshold lemma, closure of A, fusion for every fixed term,
stationarity on nonstandard successor components, zero-test induction, and the
automorphism argument are proved mathematically in the manuscript. Their
correctness is not inferred from finite tests. This script is not a complete
iPRA checker and must not be compared with the complete-kernel source minima.
