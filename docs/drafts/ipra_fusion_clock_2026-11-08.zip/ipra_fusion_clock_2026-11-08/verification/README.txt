SYMBOLIC VERIFICATION: FUSION, CLOCK, AND SCALAR UNIQUENESS

For the separate finite pair-algebra diagnostics in model_diagnostics.py,
see MODEL_DIAGNOSTICS_README.txt. Those numerical diagnostics have a different
scope from the symbolic replay described here.

Run from this directory:

  python3 make_certificate.py
  python3 check_certificate.py fusion_clock_certificate.json

The producer is untrusted. The standalone checker does not import it.
Only the Python standard library is used. Acceptance uses explicit checks
raising ProofError, never Python assert statements. The output is JSON.

Scope
-----
This is a narrow symbolic equational replay checker for three exact generic
derivations. It is not a complete iPRA proof checker. It does not formally
verify the infinite tagged countermodel, induction over an arbitrary
signature, full-theory bi-interpretability, or any absolute complexity bound.

The functions f, g, h are opaque binary operations: a state argument plus
one fixed passive parameter p. Successor s is opaque unary. I_g denotes
the scalar iterator of the fixed update g. Terms are finite arrays with
explicit variable, zero, application, and iterator tags. Numerical terms
contain no binders; the fixed update descriptors are symbol names. No
universal evaluator is present. The checker validates arities and scopes.

The three hardcoded problems, including their hypotheses and exact target
equations, are independent of the supplied certificate:

1. Uniqueness -> clock: I_s(n,0)=n.
2. Uniqueness -> fusion: from universally quantified intertwining
   f(g(w,p),p)=h(f(w,p),p), derive
   f(I_g(n,a,p),p)=I_h(n,f(a,p),p).
3. Fusion + clock -> uniqueness: from universally quantified recurrence
   f(s(w),p)=h(f(w,p),p), derive
   f(n,p)=I_h(n,f(0,p),p).

The checker licenses uniqueness only in problems 1 and 2, and fusion plus
clock only in problem 3. It reconstructs each proof-node conclusion from
its premises, then requires the final equation to match the fixed target.
Thus changing the claimed result or silently using the principle being
derived cannot make the positive checks pass.

Trusted replay rules
--------------------
- Equality reflexivity, symmetry, transitivity, and term congruence.
- Instantiation of the problem's one explicitly declared universal
  hypothesis, when present.
- Zero and successor iterator computation equations.
- Scalar recurrence uniqueness U, where licensed: its recurrence premise
  is checked at a fresh numerical eigenvariable; target and passive
  parameters must lie in the outer scope.
- Iterator fusion, where licensed: the intertwining premise is checked at
  a fresh numerical eigenvariable; target, initializer, and update
  parameters must lie in the outer scope.
- The clock equation, where licensed.

The two high-level rules U and fusion are charged assumptions being
compared, not imported theorems. The replay certifies their relationship
using only the displayed equational steps. The written proof explains why
the generic schemata are stable under arbitrary fixed passive parameters
and the addition of any retained context fresh for the eigenvariable.

Six controls must reject: an unlicensed clock shortcut; an eigenvariable
colliding with the target; an intertwining hypothesis at the wrong
argument; reflexivity substituted for the clock conclusion; the wrong
source update in fusion; and an escaped free variable. These controls are
diagnostics, not a replacement for an audit of the checker.

No source-size comparison with complete iPRA checkers is meaningful for
this limited replay checker. Its purpose is to make the finite symbolic
interface derivations inspectable and reproducible.

COMPLETE WRITTEN SCALAR RECONSTRUCTION
-------------------------------------
scalar_uniqueness_predecessor.tex and scalar_uniqueness_completion.tex
are included directly by report.tex. They prove the full scalar-U
axiomatization and both interpretations. Their proofs received independent
assistant review; they are not claims accepted by check_certificate.py.
The predecessor proof uses scalar recurrences and fusion, the completion
proves actual equality reflection before general equation induction, and
only then invokes the explicitly reproduced inherited pairing/compiler.
