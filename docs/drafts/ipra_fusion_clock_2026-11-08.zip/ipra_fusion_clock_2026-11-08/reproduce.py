#!/usr/bin/env python3
"""Replay only the explicitly documented computational evidence."""
from pathlib import Path
import ast
import json
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
def run(args):
    process = subprocess.run([sys.executable, *args], cwd=ROOT,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             text=True, timeout=120)
    if process.returncode:
        raise RuntimeError(f"Failed: {args}\n{process.stdout}\n{process.stderr}")
    return process.stdout

certificate = "verification/fusion_clock_certificate.json"
normal = run(["verification/check_certificate.py", certificate])
optimized = run(["-O", "verification/check_certificate.py", certificate])
if normal != optimized:
    raise RuntimeError("Normal and optimized certificate results disagree")
checker = ast.parse((ROOT / "verification/check_certificate.py").read_text())
if any(isinstance(n, ast.Assert) for n in ast.walk(checker)):
    raise RuntimeError("Assertion-based verification gate found")
model = run(["verification/model_diagnostics.py"])
baseline = run(["comparison/measure.py"])
result = {"python": platform.python_version(),
          "symbolic_certificate": json.loads(normal),
          "optimized_replay_identical": True,
          "assertion_acceptance_gates": 0,
          "ambient_model_diagnostics": json.loads(model),
          "baseline_measurement": json.loads(baseline),
          "scope": "Exact generic equational replay, finite ambient diagnostics, and source measurements. No complete new iPRA checker or formal infinite-model verification."}
(ROOT / "results/reproduction.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps({"status": "PASS", "python": platform.python_version(),
                  "optimized_replay_identical": True,
                  "scope": result["scope"]}, indent=2))
