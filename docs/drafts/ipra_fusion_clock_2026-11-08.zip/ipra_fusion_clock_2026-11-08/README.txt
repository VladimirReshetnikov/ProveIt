PARAMETERIZED FUSION, SUCCESSOR CLOCKS, AND THE iPRA MINIMIZATION GAP
=================================================================
Prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific date).

STATUS
------
A complete scalar-iteration presentation of full iPRA is proved, including
whole-domain bi-interpretability and equiconsistency. The requested strict
improvement over the complete-checker complexity frontier has NOT been
established. This is not a claim of a smallest theory or a new code record.

The complete theory T_U uses ordinary intuitionistic equality logic,
open scalar iterator computation, numerical coverage, separation, and
one uniform scalar recurrence-uniqueness rule. The manuscript derives:
1. Predecessor by scalar recurrence comparisons and parameterized fusion,
   before any general equation induction or equality reflector is used.
2. A scalar half retraction H(x)=d(G(x),x), followed by a signed scalar
   clock that reflects actual equality.
3. Full contextual quantifier-free induction via the direct reset clock.
4. Explicit pairing/projections, every fixed primitive-recursive operation,
   and both internal identity composites with iPRA.

It also proves:
5. Parameterized fusion plus the successor clock is exactly scalar U.
6. Fusion alone canonically defines an idempotent endomorphism c(n)=I_S(n,0).
   With coverage and separation, its fixed-point domain is a complete
   iPRA presentation. Under those assumptions zero-test formulas cannot
   distinguish the original domain from this retract. This yields zero-test-
   sentence conservation and equiconsistency with the clock extension,
   and therefore equiconsistency with iPRA.
7. A nonstandard tagged model validates full parameterized fusion,
   stationarity and every zero-test-formula induction instance, while
   refuting the clock. A parameter-fixing involution rules out ordinary
   bi-interpretability of the unclocked theory with iPRA, including quotient
   domains. The canonical core therefore does not recover its ambient domain.

The predecessor terms, signed-clock method, pairing/compiler, base tagged
construction and reset-clock method are inherited and credited. The new
scalar uniqueness proofs, scalar half replacement, open-fusion extension,
and core/conservation results are stated relative to the inspected corpus.
No literature-wide priority claim is made.

COMPLETE POSITIVE REFERENCE
---------------------------
The manuscript specifies all logical and nonlogical rules of a direct
recursor theory, proves actual equality reflection without circularity,
recovers quantifier-free induction, and proves both whole-domain
interpretation composites with iPRA. This reference is not advertised
as a new reduction. The inherited native five-pattern basis is separately
listed and distinguished from the four-pattern clausal presentation.

COMPARISON
----------
Repository: VladimirReshetnikov/ProveIt
Snapshot: 4890fd00a5cacfc9881ae282120978f95c3ba392
Current archives: 16 (all sizes and Git blobs verified)
Exact complete comparator programs: 17
Coordinate envelope: 312 tokens / 347 AST nodes / 878 normalized bytes
The three minima have different attainers. They are not universal lower
bounds. The smallest programs implement the inherited scalar calculus,
not the newest shifted-unary arithmetic theorem.

START HERE
----------
report.pdf                       Compiled manuscript
report.tex, sections/             Complete editable TeX source
verification/                    Narrow symbolic certificate and diagnostics
comparison/                      Exact comparator sources, license, metrics
provenance/snapshot.json          Pinned input identities
results/                         Reproduction and build receipts
ATTRIBUTION.txt                   New/inherited material and proof boundaries
MANIFEST.json                    SHA-256 identities of the packaged payload

REPRODUCE
---------
Python 3.12, standard library only:
    python3 reproduce.py
Compile the PDF using a standard pdfLaTeX installation:
    python3 build.py
Rebuild the distribution after reviewing any changes:
    python3 package.py

The exact metatheorems have written proofs and independent assistant
review; no external peer review is claimed. The
symbolic replayer verifies only three generic equational implications.
Finite pair-algebra diagnostics do not verify a nonstandard model or an
infinite induction schema. No Lean/Rocq formalization is claimed.

The report includes Further research questions. No changes were pushed
to the repository.
