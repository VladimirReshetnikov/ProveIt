#!/usr/bin/env python3
"""Measure complete comparator source as data; never import or execute it.

Usage, from any working directory: python3 /path/to/comparison/measure.py
Uses only the standard library. Exact reported measurements use CPython 3.12.14.
"""

import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize


HERE = Path(__file__).resolve().parent
FIELDS = ("normalized_tokens", "ast_nodes", "normalized_bytes")
IGNORED = {
    tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
    tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER,
}


def normalized_source(raw):
    """Delete actual leading docstrings, then use the standard AST unparser."""
    tree = ast.parse(raw.decode("utf-8"))
    containers = (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)
    for node in ast.walk(tree):
        if not isinstance(node, containers) or not node.body:
            continue
        first = node.body[0]
        if (isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant)
                and isinstance(first.value.value, str)):
            del node.body[0]
    return tree, ast.unparse(tree) + "\n"


def measure(entry):
    path = (HERE / entry["file"]).resolve()
    if not path.is_relative_to(HERE):
        raise ValueError("Comparator path is outside the comparison directory")
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if digest != entry["sha256"] or len(raw) != entry["raw_bytes"]:
        raise ValueError("Comparator source identity mismatch: " + entry["file"])
    tree, source = normalized_source(raw)
    normalized_digest = hashlib.sha256(source.encode("utf-8")).hexdigest()
    metrics = {
        "normalized_tokens": sum(
            item.type not in IGNORED
            for item in tokenize.generate_tokens(io.StringIO(source).readline)
        ),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "normalized_bytes": len(source.encode("utf-8")),
    }
    return {
        "file": entry["file"], "raw_bytes": len(raw), "sha256": digest,
        "normalized_sha256": normalized_digest,
        "matches_recorded_normalized_sha256": normalized_digest == entry["normalized_sha256"],
        **metrics,
        "matches_recorded_metrics": metrics == entry["recorded_metrics"],
    }


def main():
    manifest = json.loads((HERE / "manifest.json").read_text())
    entries = manifest["programs"]
    listed = {entry["file"] for entry in entries}
    present = {path.relative_to(HERE).as_posix()
               for path in (HERE / "checkers").glob("*.py")}
    if len(entries) != 17 or len(listed) != 17 or listed != present:
        raise ValueError("Exactly the seventeen disclosed comparator sources are required")
    rows = [measure(entry) for entry in entries]
    rows.sort(key=lambda row: tuple(row[field] for field in FIELDS) + (row["file"],))
    envelope = {field: min(row[field] for row in rows) for field in FIELDS}
    result = {
        "format": "ipra-complete-comparator-metrics-v1",
        "repository": manifest["repository"], "commit": manifest["commit"],
        "python": platform.python_version(), "implementation": platform.python_implementation(),
        "program_count": len(rows), "whole_program_boundary": True,
        "comparator_code_imported_or_executed": False,
        "all_source_identities_verified": True,
        "all_metrics_match_recorded": all(row["matches_recorded_metrics"] for row in rows),
        "all_normalized_identities_match_recorded": all(
            row["matches_recorded_normalized_sha256"] for row in rows
        ),
        "coordinate_envelope": envelope,
        "matches_recorded_envelope": envelope == manifest["recorded_envelope"],
        "attainers": {field: [row["file"] for row in rows if row[field] == envelope[field]]
                      for field in FIELDS},
        "programs": rows,
        "scope": "Whole-program source measurements, not correctness proofs or universal lower bounds. Different programs attain the coordinate minima.",
    }
    output = HERE.parent / "results"
    output.mkdir(exist_ok=True)
    (output / "baseline_metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    table = {
        "columns": ["file", *FIELDS],
        "rows": [[row["file"], *(row[field] for field in FIELDS)] for row in rows],
        "coordinate_envelope": envelope,
        "source": "baseline_metrics.json",
    }
    (output / "baseline_table.json").write_text(json.dumps(table, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in (
        "program_count", "python", "coordinate_envelope",
        "all_source_identities_verified", "all_metrics_match_recorded",
    )}, indent=2))
    if not result["all_metrics_match_recorded"] or not result["matches_recorded_envelope"]:
        raise SystemExit("Measurements differ from the recorded CPython 3.12.14 profile; inspect results/baseline_metrics.json.")


if __name__ == "__main__":
    main()
