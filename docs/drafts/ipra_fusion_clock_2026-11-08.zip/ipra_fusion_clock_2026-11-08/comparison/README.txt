COMPLETE CHECKER COMPARISON
===========================

Run, from the package root:

    python3 comparison/measure.py

The script uses only Python's standard library. It reads the seventeen
complete sources in checkers/ as UTF-8 data, verifies their raw byte lengths
and SHA-256 identities against manifest.json, parses their ASTs, removes
actual docstrings, and applies ast.unparse. It never imports or executes a
comparator. Comments disappear during parsing. It counts significant tokens,
all remaining AST nodes, and normalized UTF-8 bytes for the WHOLE program.
Imports, parsing, scope validation, proof dispatch, acceptance, and rejection
are included. No prospective or incomplete kernel is included.

The current envelope is:

    312 normalized tokens / 347 AST nodes / 878 normalized bytes.

Different programs attain these minima. There is no source measuring
312/347/878. These are observed minima for this finite collection, not
universal mathematical lower bounds and not correctness certificates.

Exact reported measurements use CPython 3.12.14. Other Python versions may
normalize the same AST differently. A mismatch is recorded and reported by
the script; it must not be silently treated as the original measurement.

Outputs:

    ../results/baseline_metrics.json   All measurements, hashes, attainers.
    ../results/baseline_table.json     The same seventeen rows in table form.

The latest array_only.py measures 312/348/920. It is an inherited checker
for the scalar-iteration/native-logic calculus, not a checker for the new
mathematical proposal in the accompanying report. Its change from the
preceding compact profile concerns the array traversal guard.

All seventeen sources are copied byte for byte from the successor-clock
archive retained in the pinned current repository snapshot. The manifest
identifies the precise archive and member for every file. Original historical
provenance and the older sixteen-source measurement receipt are preserved
in provenance/. The old receipt intentionally predates the array-only entry;
the new seventeen-source result is in ../results/baseline_metrics.json.

See ATTRIBUTION.txt and LICENSE-inherited.txt. The authoritative inventory
and verified hashes of all sixteen current input archives are recorded in
../provenance/snapshot.json. The input archives themselves are not all copied
into this package.
