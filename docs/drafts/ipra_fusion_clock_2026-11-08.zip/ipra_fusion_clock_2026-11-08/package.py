#!/usr/bin/env python3
"""Create a deterministic distribution of the reviewed research payload."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
SKIP_DIRS = {"build", "__pycache__"}


def payload():
    return sorted(
        p for p in ROOT.rglob("*")
        if p.is_file()
        and not any(part in SKIP_DIRS for part in p.relative_to(ROOT).parts)
        and p.name != "MANIFEST.json"
        and p.suffix not in {".pyc", ".pyo"}
    )


if not (ROOT / "report.pdf").is_file():
    raise SystemExit("Build and review report.pdf before packaging")

files = payload()
records = [
    {"path": str(p.relative_to(ROOT)), "bytes": p.stat().st_size,
     "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
    for p in files
]
manifest = ROOT / "MANIFEST.json"
manifest.write_text(json.dumps({
    "format": 1,
    "snapshot": "4890fd00a5cacfc9881ae282120978f95c3ba392",
    "hash_algorithm": "sha256",
    "note": "The manifest excludes itself; the ZIP contains it alongside all listed files.",
    "files": records,
}, indent=2) + "\n")

archive = ROOT.with_suffix(".zip")
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED,
                     compresslevel=9) as bundle:
    for path in sorted([*files, manifest]):
        member = str(Path(ROOT.name) / path.relative_to(ROOT))
        entry = zipfile.ZipInfo(member, date_time=(2026, 11, 9, 0, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        entry.external_attr = 0o100644 << 16
        bundle.writestr(entry, path.read_bytes(), compresslevel=9)

with zipfile.ZipFile(archive) as bundle:
    if bundle.testzip() is not None:
        raise SystemExit("ZIP integrity check failed")
    for record in records:
        member = str(Path(ROOT.name) / record["path"])
        data = bundle.read(member)
        if len(data) != record["bytes"] or hashlib.sha256(data).hexdigest() != record["sha256"]:
            raise SystemExit("Payload hash mismatch: " + record["path"])

print(json.dumps({"archive": str(archive), "files": len(files) + 1,
                  "bytes": archive.stat().st_size,
                  "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}, indent=2))
