#!/usr/bin/env python3
"""Finite diagnostics for the manuscript's actual binary descriptions.

Only zero, successor, variables, and binary R_h applications are constructors.
Every stored update body is checked for free variables and earlier dependencies.
The interpreter executes the defining recursion equations with cached prefixes;
it does not replace arithmetic descriptions by Python arithmetic shortcuts.

Finite tests do not prove the arbitrary-model arithmetic, induction, or
bi-interpretation claims. Those claims rest on the written internal proofs.
No external Python packages are required.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from dataclasses import dataclass
from pathlib import Path
from time import perf_counter
from typing import Callable


@dataclass(frozen=True)
class Term:
    tag: str
    label: str | int | None = None
    args: tuple["Term", ...] = ()


ZERO = Term("zero")


def variable(name: str) -> Term:
    return Term("var", name)


def succ(arg: Term) -> Term:
    return Term("succ", args=(arg,))


def rec(description: int, index: Term, seed: Term) -> Term:
    return Term("rec", description, (index, seed))


ONE = succ(ZERO)
U, W = variable("u"), variable("v")


def free_variables(term: Term) -> set[str]:
    result = {str(term.label)} if term.tag == "var" else set()
    for child in term.args:
        result |= free_variables(child)
    return result


def dependencies(term: Term) -> set[int]:
    result = {int(term.label)} if term.tag == "rec" else set()
    for child in term.args:
        result |= dependencies(child)
    return result


def tree_size(term: Term) -> int:
    return 1 + sum(tree_size(child) for child in term.args)


def encode(term: Term) -> list:
    return [term.tag, term.label, *[encode(child) for child in term.args]]


class Basis:
    """A finite, validated list of legal binary recursion descriptions."""

    def __init__(self) -> None:
        self.descriptions: list[tuple[str, Term]] = []

    def introduce(self, name: str, body: Term) -> int:
        index = len(self.descriptions)
        assert free_variables(body) <= {"u", "v"}, (name, free_variables(body))
        assert all(0 <= dep < index for dep in dependencies(body)), name
        assert name not in {old_name for old_name, _ in self.descriptions}
        self.descriptions.append((name, body))
        return index


class Arithmetic:
    """Term abbreviations, expanded entirely into the binary signature."""

    def __init__(self) -> None:
        self.basis = Basis()
        self.r_pred = self.basis.introduce("R_pred", U)
        self.r_zero = self.basis.introduce("R_zero", ZERO)
        self.r_add = self.basis.introduce("R_add", succ(W))
        self.r_sub = self.basis.introduce("R_sub", self.p(W))
        self.r_tri = self.basis.introduce("R_tri", self.add(W, succ(U)))
        boundary_body = self.case(
            self.e(self.tri(succ(W)), succ(U)), succ(W), W
        )
        self.r_boundary = self.basis.introduce("R_boundary", boundary_body)

        # Ordinary multiplication f(0,b)=0; f(Sn,b)=f(n,b)+b.
        # Code the single frozen parameter, then keep its code in the state.
        parameter_code = self.left(W)
        frozen_b = self.decode(parameter_code, 1, 1)
        accumulator = self.right(W)
        mul_body = self.pair(parameter_code, self.add(accumulator, frozen_b))
        self.r_mul = self.basis.introduce("R_mul_compiled", mul_body)

        # Ordinary powers f(0,b)=1; f(Sn,b)=f(n,b)*b. The multiplication
        # appearing here is itself the preceding compiled binary description.
        power_body = self.pair(parameter_code, self.mul(accumulator, frozen_b))
        self.r_power = self.basis.introduce("R_power_compiled", power_body)

        # A two-frozen-parameter example f(0,b,c)=b;
        # f(Sn,b,c)=f(n,b,c)+c. This exercises nontrivial tuple decoding.
        frozen_c = self.decode(parameter_code, 2, 2)
        affine_body = self.pair(parameter_code, self.add(accumulator, frozen_c))
        self.r_affine = self.basis.introduce("R_affine_compiled", affine_body)

    def p(self, x: Term) -> Term:
        return rec(self.r_pred, x, ZERO)

    def z(self, n: Term, a: Term) -> Term:
        return rec(self.r_zero, n, a)

    def add(self, x: Term, y: Term) -> Term:
        return rec(self.r_add, y, x)

    def sub(self, x: Term, y: Term) -> Term:
        return rec(self.r_sub, y, x)

    def case(self, z: Term, a: Term, b: Term) -> Term:
        return self.add(self.z(z, a), self.z(self.z(z, ONE), b))

    def one_detector(self, r: Term) -> Term:
        return self.case(r, ONE, self.case(self.p(r), ZERO, ONE))

    def e(self, x: Term, y: Term) -> Term:
        return self.one_detector(self.sub(succ(x), y))

    def tri(self, n: Term) -> Term:
        return rec(self.r_tri, n, ZERO)

    def boundary(self, n: Term) -> Term:
        return rec(self.r_boundary, n, ZERO)

    def pair(self, x: Term, y: Term) -> Term:
        return self.add(self.tri(self.add(x, y)), x)

    def left(self, w: Term) -> Term:
        return self.sub(w, self.tri(self.boundary(w)))

    def right(self, w: Term) -> Term:
        return self.sub(self.boundary(w), self.left(w))

    def code(self, components: list[Term]) -> Term:
        result = ZERO
        for component in components:
            result = self.pair(result, component)
        return result

    def decode(self, code: Term, length: int, position: int) -> Term:
        assert 1 <= position <= length
        result = code
        for _ in range(length - position):
            result = self.left(result)
        return self.right(result)

    def mul(self, n: Term, b: Term) -> Term:
        seed = self.pair(self.code([b]), ZERO)
        return self.right(rec(self.r_mul, n, seed))

    def power(self, n: Term, b: Term) -> Term:
        seed = self.pair(self.code([b]), ONE)
        return self.right(rec(self.r_power, n, seed))

    def affine(self, n: Term, b: Term, c: Term) -> Term:
        seed = self.pair(self.code([b, c]), b)
        return self.right(rec(self.r_affine, n, seed))


Evaluator = Callable[[dict[str, int]], int]


class Interpreter:
    """Execute each legal R_h by its literal base/step equations."""

    def __init__(self, basis: Basis) -> None:
        self.basis = basis
        self.compiled: dict[Term, Evaluator] = {}
        self.prefixes: dict[tuple[int, int], list[int]] = {}
        self.bodies: list[Evaluator] = []
        self.recursion_steps = 0
        for _, body in basis.descriptions:
            self.bodies.append(self.compile(body))

    def compile(self, term: Term) -> Evaluator:
        cached = self.compiled.get(term)
        if cached is not None:
            return cached
        if term.tag == "zero":
            function = lambda env: 0
        elif term.tag == "var":
            name = str(term.label)
            function = lambda env, name=name: env[name]
        elif term.tag == "succ":
            child = self.compile(term.args[0])
            function = lambda env, child=child: child(env) + 1
        elif term.tag == "rec":
            description = int(term.label)
            index, seed = map(self.compile, term.args)
            function = lambda env, description=description, index=index, seed=seed: (
                self.run(description, index(env), seed(env))
            )
        else:
            raise ValueError(f"Unknown term constructor {term.tag!r}")
        self.compiled[term] = function
        return function

    def run(self, description: int, index: int, seed: int) -> int:
        if index < 0 or seed < 0:
            raise ValueError("The numerical diagnostic uses natural numbers")
        key = (description, seed)
        prefix = self.prefixes.setdefault(key, [seed])
        if index >= len(prefix):
            body = self.bodies[description]
            for counter in range(len(prefix) - 1, index):
                prefix.append(body({"u": counter, "v": prefix[-1]}))
                self.recursion_steps += 1
        return prefix[index]


def canonical_json(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def diagnostics() -> tuple[dict, dict]:
    started = perf_counter()
    arithmetic = Arithmetic()
    basis = arithmetic.basis
    interpreter = Interpreter(basis)
    x, y, z, n, b, c = map(variable, ("x", "y", "z", "n", "b", "c"))

    terms = {
        "predecessor": arithmetic.p(x),
        "zero_selector": arithmetic.z(x, y),
        "addition": arithmetic.add(x, y),
        "subtraction": arithmetic.sub(x, y),
        "case": arithmetic.case(z, x, y),
        "one_detector": arithmetic.one_detector(x),
        "equality_bit": arithmetic.e(x, y),
        "triangular": arithmetic.tri(n),
        "boundary": arithmetic.boundary(n),
        "pair": arithmetic.pair(x, y),
        "left": arithmetic.left(z),
        "right": arithmetic.right(z),
        "mul": arithmetic.mul(n, b),
        "power": arithmetic.power(n, b),
        "affine": arithmetic.affine(n, b, c),
        "guarded_residual": arithmetic.case(
            arithmetic.sub(y, n), y, arithmetic.add(n, arithmetic.sub(y, n))
        ),
    }
    evaluators = {name: interpreter.compile(term) for name, term in terms.items()}

    counts: dict[str, int] = {}

    def check(group: str, actual: object, expected: object) -> None:
        if actual != expected:
            raise AssertionError({"group": group, "actual": actual, "expected": expected})
        counts[group] = counts.get(group, 0) + 1

    for i in range(13):
        check("predecessor", evaluators["predecessor"]({"x": i}), max(i - 1, 0))
        check("one_detector", evaluators["one_detector"]({"x": i}), int(i != 1))
        for j in range(13):
            env = {"x": i, "y": j}
            check("zero_selector", evaluators["zero_selector"](env), j if i == 0 else 0)
            check("addition", evaluators["addition"](env), i + j)
            check("subtraction", evaluators["subtraction"](env), max(i - j, 0))
            check("equality_bit", evaluators["equality_bit"](env), int(i != j))
            pair = evaluators["pair"](env)
            check("pair_code", pair, (i + j) * (i + j + 1) // 2 + i)
            check("left_projection", evaluators["left"]({"z": pair}), i)
            check("right_projection", evaluators["right"]({"z": pair}), j)
            check("guarded_residual", evaluators["guarded_residual"]({"y": i, "n": j}), i)

    for selector in range(5):
        for i in range(5):
            for j in range(5):
                check("case", evaluators["case"]({"z": selector, "x": i, "y": j}),
                      i if selector == 0 else j)

    for t in range(25):
        triangular = evaluators["triangular"]({"n": t})
        check("triangular", triangular, t * (t + 1) // 2)
        check("endpoint", evaluators["boundary"]({"n": triangular}), t)
        for offset in range(t + 1):
            check("segment", evaluators["boundary"]({"n": triangular + offset}), t)

    tuple_counts: dict[str, int] = {}
    for length in range(4):
        variables = [variable(f"b{i}") for i in range(1, length + 1)]
        code_term = arithmetic.code(variables)
        code_fn = interpreter.compile(code_term)
        decoders = [interpreter.compile(arithmetic.decode(z, length, i))
                    for i in range(1, length + 1)]
        for values in itertools.product(range(3), repeat=length):
            encoded = code_fn({f"b{i}": value for i, value in enumerate(values, 1)})
            tuple_counts[str(length)] = tuple_counts.get(str(length), 0) + 1
            if length == 0:
                check("empty_tuple", encoded, 0)
            for i, decoder in enumerate(decoders):
                check("tuple_projection", decoder({"z": encoded}), values[i])

    for factor in range(4):
        for index in range(7):
            check("compiled_multiplication", evaluators["mul"]({"n": index, "b": factor}),
                  index * factor)
        for exponent in range(4):
            check("compiled_power", evaluators["power"]({"n": exponent, "b": factor}),
                  factor ** exponent)
    for first in range(3):
        for step in range(3):
            for index in range(4):
                check("compiled_two_parameter_affine",
                      evaluators["affine"]({"n": index, "b": first, "c": step}),
                      first + index * step)

    description_manifest = {
        "scope": "Literal finite binary descriptions; macros expand into these symbols.",
        "constructors": ["variable", "zero", "successor", "binary R_h application"],
        "descriptions": [
            {"id": i, "name": name, "arity": 2,
             "free_update_variables": sorted(free_variables(body)),
             "earlier_dependencies": sorted(dependencies(body)),
             "body_tree_nodes": tree_size(body), "body": encode(body)}
            for i, (name, body) in enumerate(basis.descriptions)
        ],
    }
    manifest_hash = hashlib.sha256(canonical_json(description_manifest)).hexdigest()
    results = {
        "status": "passed",
        "scope": ("Finite standard-natural-number diagnostics only. The interpreter executes "
                  "the actual binary recursion descriptions. These computations do not prove "
                  "arbitrary-model identities, induction, or bi-interpretability."),
        "ranges": {"pair_and_equality_inputs": [0, 12], "triangular_endpoints": [0, 24],
                   "tuple_lengths": [0, 3], "tuple_entries": [0, 2],
                   "multiplication_frozen_factor": [0, 3], "multiplication_counter": [0, 6],
                   "power_frozen_base": [0, 3], "power_counter": [0, 3],
                   "affine_frozen_parameters": [0, 2], "affine_counter": [0, 3]},
        "checks_by_group": counts,
        "total_assertions": sum(counts.values()),
        "tuple_cases_by_length": tuple_counts,
        "description_count": len(basis.descriptions),
        "all_description_arities": 2,
        "free_update_variables_at_most_u_v": True,
        "all_update_dependencies_strictly_earlier": True,
        "description_manifest_sha256": manifest_hash,
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "execution": {"elapsed_seconds": round(perf_counter() - started, 6),
                      "recursion_steps_executed": interpreter.recursion_steps,
                      "cached_prefixes": len(interpreter.prefixes),
                      "cached_prefix_values": sum(map(len, interpreter.prefixes.values())),
                      "compiled_subterms": len(interpreter.compiled)},
    }
    return results, description_manifest


def main() -> None:
    directory = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=directory / "check_binary_arithmetic_results.json")
    parser.add_argument("--descriptions", type=Path,
                        default=directory / "check_binary_arithmetic_descriptions.json")
    args = parser.parse_args()
    results, manifest = diagnostics()
    args.output.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    args.descriptions.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
