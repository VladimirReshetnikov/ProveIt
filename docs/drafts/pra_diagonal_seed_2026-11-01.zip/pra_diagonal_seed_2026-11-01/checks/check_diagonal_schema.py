#!/usr/bin/env python3
"""Structural diagnostics for diagonal seed normalization.

This checks literal substitution/admission, the two probes, generated variable
names, and partial display counts. It is not a first-order proof checker.
"""

from __future__ import annotations

import json
from dataclasses import dataclass


@dataclass(frozen=True)
class Node:
    tag: str
    name: str = ""
    args: tuple["Node", ...] = ()


def var(name: str) -> Node:
    return Node("var", name)


def app(name: str, *args: Node) -> Node:
    return Node("app", name, args)


def eq(left: Node, right: Node) -> Node:
    return Node("eq", args=(left, right))


def imp(left: Node, right: Node) -> Node:
    return Node("imp", args=(left, right))


def conj(left: Node, right: Node) -> Node:
    return Node("and", args=(left, right))


def all_(name: str, formula: Node) -> Node:
    return Node("all", name, (formula,))


ZERO = Node("zero")
BOTTOM = Node("bottom")
x, z, a = map(var, ("x", "z", "a"))


def successor(term: Node) -> Node:
    return app("S", term)


def recursor(index: Node, seed: Node) -> Node:
    return app("R_h", index, seed)


def free_vars(tree: Node) -> set[str]:
    if tree.tag == "var":
        return {tree.name}
    names: set[str] = set()
    for child in tree.args:
        names |= free_vars(child)
    return names - {tree.name} if tree.tag == "all" else names


def all_names(tree: Node) -> set[str]:
    names = {tree.name} if tree.tag in {"var", "all"} else set()
    for child in tree.args:
        names |= all_names(child)
    return names


def has_quantifier(tree: Node) -> bool:
    return tree.tag == "all" or any(has_quantifier(ch) for ch in tree.args)


def substitute_qf(tree: Node, env: dict[str, Node]) -> Node:
    """Simultaneous substitution: inserted replacements are NOT revisited."""
    if tree.tag == "all":
        raise ValueError("Only quantifier-free matrices are accepted")
    if tree.tag == "var":
        return env.get(tree.name, tree)
    return Node(tree.tag, tree.name,
                tuple(substitute_qf(ch, env) for ch in tree.args))


def modified_base(matrix: Node) -> Node:
    return substitute_qf(matrix, {"x": ZERO, "z": recursor(ZERO, a)})


def admitted(matrix: Node) -> bool:
    if has_quantifier(matrix) or not free_vars(matrix) <= {"x", "z", "a"}:
        return False
    base = modified_base(matrix)
    return base.tag == "imp" and base.args[0] == base.args[1]


def diagonal(matrix: Node, index: Node) -> Node:
    return substitute_qf(matrix, {"x": index, "z": a})


def computation() -> Node:
    return eq(recursor(successor(x), a), app("h", x, recursor(x, a)))


def generate(matrix: Node) -> Node:
    if not admitted(matrix):
        raise ValueError("Matrix fails literal reflexive-base admission")
    current, following = diagonal(matrix, x), diagonal(matrix, successor(x))
    return all_("a", imp(all_("x", imp(current, following)),
                         all_("x", conj(current, computation()))))


def size(tree: Node) -> int:
    return 1 + sum(size(child) for child in tree.args)


def check() -> dict[str, object]:
    initial = recursor(ZERO, a)
    reflexive = eq(initial, initial)
    probe = imp(reflexive, eq(z, initial))
    truth_probe = imp(eq(ZERO, ZERO), eq(ZERO, ZERO))
    formula = imp(eq(app("f", x, a), ZERO), eq(app("g", a), x))
    normalized = imp(substitute_qf(formula, {"x": ZERO}), formula)

    assert admitted(probe)
    assert modified_base(probe) == imp(reflexive, reflexive)
    assert diagonal(probe, x) == imp(reflexive, eq(a, initial))
    assert "x" not in free_vars(diagonal(probe, x))
    assert diagonal(probe, x) == diagonal(probe, successor(x))
    assert admitted(truth_probe)
    assert admitted(normalized)
    assert modified_base(normalized).args[0] == modified_base(normalized).args[1]

    rejected = [BOTTOM, eq(z, initial), eq(x, ZERO),
                imp(eq(var("extra"), ZERO), eq(var("extra"), ZERO)),
                all_("z", truth_probe)]
    for matrix in rejected:
        assert not admitted(matrix)

    instances = [generate(probe), generate(truth_probe), generate(normalized)]
    for instance in instances:
        assert not free_vars(instance)
        assert all_names(instance) <= {"x", "a"}

    current = Node("pred", "A", (x, a, a))
    following = Node("pred", "A", (successor(x), a, a))
    progress = all_("x", imp(current, following))
    conclusion = all_("x", conj(current, computation()))
    schematic = all_("a", imp(progress, conclusion))
    separation = imp(eq(ZERO, successor(ZERO)), BOTTOM)
    ledger = {
        "diagonal_formula_application": size(current),
        "successor_formula_application": size(following),
        "progress_block": size(progress),
        "successor_computation_matrix": size(computation()),
        "universal_conclusion": size(conclusion),
        "DN_schema": size(schematic),
        "separation": size(separation),
        "total_partial_display_count": size(schematic) + size(separation),
    }
    assert ledger == {
        "diagonal_formula_application": 4,
        "successor_formula_application": 5,
        "progress_block": 11,
        "successor_computation_matrix": 10,
        "universal_conclusion": 16,
        "DN_schema": 29,
        "separation": 6,
        "total_partial_display_count": 35,
    }

    return {
        "status": "passed",
        "accepted_probes": ["initialization", "computation", "QFI normalization"],
        "rejected_inputs": len(rejected),
        "generated_axioms_closed": True,
        "actual_axiom_variable_names": ["a", "x"],
        "recognizer_placeholder_names": ["a", "x", "z"],
        "ledger": ledger,
        "scope": "Structural diagnostics only; not a first-order proof checker.",
    }


if __name__ == "__main__":
    print(json.dumps(check(), indent=2))
