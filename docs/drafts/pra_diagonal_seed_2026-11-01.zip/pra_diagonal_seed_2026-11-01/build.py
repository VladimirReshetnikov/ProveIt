#!/usr/bin/env python3
"""Reproduce the relevant diagnostics, optional Lean check, and LaTeX PDF."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parent


def run(command: list[str], timeout: int = 120) -> subprocess.CompletedProcess:
    result = subprocess.run(command, cwd=ROOT, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            timeout=timeout, check=False)
    if result.returncode:
        raise RuntimeError(f"Command failed: {command[0]}\n{result.stdout}")
    return result


def save_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Lean executable (otherwise search PATH)")
    args = parser.parse_args()
    checks = {}
    for stem in ("check_diagonal_schema", "check_binary_arithmetic"):
        result = run([sys.executable, str(ROOT / "checks" / f"{stem}.py")])
        data = json.loads(result.stdout)
        if data.get("status") != "passed":
            raise RuntimeError(f"Failed diagnostic: {stem}")
        save_json(ROOT / "checks" / f"{stem}_results.json", data)
        checks[stem] = "passed"

    lean = args.lean or shutil.which("lean")
    lean_status = "not rechecked; see supplied formal/verification.json"
    if lean:
        source = ROOT / "formal" / "DiagonalSchema.lean"
        result = run([lean, str(source)])
        lines = [line for line in result.stdout.splitlines()
                 if "does not depend on any axioms" in line]
        if len(lines) != 9 or re.search(r"\b(warning|error):", result.stdout):
            raise RuntimeError("Unexpected Lean dependency or warning output")
        (ROOT / "formal" / "verification.log").write_text(result.stdout)
        save_json(ROOT / "formal" / "verification.json", {
            "checker": run([lean, "--version"]).stdout.strip(),
            "source": source.name,
            "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
            "exit_code": 0,
            "audited_theorem_count": len(lines),
            "no_axiom_dependencies": True,
            "scope": "Constructive abstract logical kernel with explicitly restricted predicate classes; concrete syntax, arithmetic compiler and bi-interpretations are outside this Lean file.",
        })
        lean_status = "passed; nine audited theorems without axiom dependencies"

    with tempfile.TemporaryDirectory(prefix="pra-diagonal-build-") as temp:
        command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                   f"-output-directory={temp}", str(ROOT / "report.tex")]
        run(command)
        final = run(command)
        log = (Path(temp) / "report.log").read_text(errors="replace")
        forbidden = [r"Overfull \\[hv]box", r"undefined references",
                     r"Citation .* undefined", r"Reference .* undefined"]
        if any(re.search(pattern, log) for pattern in forbidden):
            raise RuntimeError("LaTeX layout/reference gate failed:\n" + log)
        shutil.copy2(Path(temp) / "report.pdf", ROOT / "report.pdf")
        (ROOT / "audit" / "latex_build.log").write_text(final.stdout)
        pages = re.search(r"Output written on .*?\((\d+) pages", log, re.S)
        page_count = int(pages.group(1)) if pages else None

    result = {
        "status": "passed",
        "diagnostics": checks,
        "lean": lean_status,
        "latex_passes": 2,
        "overfull_boxes": 0,
        "undefined_references": 0,
        "page_count": page_count,
        "report_tex_sha256": hashlib.sha256((ROOT / "report.tex").read_bytes()).hexdigest(),
        "report_pdf_sha256": hashlib.sha256((ROOT / "report.pdf").read_bytes()).hexdigest(),
    }
    save_json(ROOT / "audit" / "build.json", result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
