import Init

/-!
# Constructive logical kernel for PRA with diagonal admission

This file verifies the logical equivalence between the diagonal schema and
the two computation equations plus induction for an explicitly supplied class
of one-parameter predicate families.

`Predicates` and `Admitted` are abstract classes. They are NOT identified with
all predicates. The actual first-order theory instantiates them by denotations
of quantifier-free formulas and of the syntactically admitted ternary templates.
The syntactic admission test, its soundness, closure under diagonal substitution,
the term grammar, arithmetic compiler, and bi-interpretations are outside this
file's scope. Their exact obligations are exposed in `SyntaxInterface`.

All arguments use intuitionistic reasoning. In particular, no decidability of
equality, excluded middle, choice, or arithmetic induction on `Carrier` is used.
The final `#print axioms` commands audit the resulting proof dependencies.
-/

universe u

namespace PRADiagonal

variable {Carrier : Type u}

abbrev Predicate (Carrier : Type u) := Carrier → Carrier → Prop
abbrev Template (Carrier : Type u) := Carrier → Carrier → Carrier → Prop

/-- A template whose modified base becomes a literal reflexive implication. -/
def InitializationProbe
    (zero : Carrier) (recursor : Carrier → Carrier → Carrier) :
    Template Carrier :=
  fun _ value parameter =>
    recursor zero parameter = recursor zero parameter →
      value = recursor zero parameter

/-- A syntactically reflexive template that supplies successor computation. -/
def ReflexiveTemplate (zero : Carrier) : Template Carrier :=
  fun _ _ _ => zero = zero → zero = zero

/-- A normalized induction matrix; its value at zero is literally B → B. -/
def NormalizedTemplate (zero : Carrier) (predicate : Predicate Carrier) :
    Template Carrier :=
  fun index _ parameter => predicate zero parameter → predicate index parameter

/-- Both ordinary computation equations for a binary recursor. -/
def Computation
    (zero : Carrier) (succ : Carrier → Carrier)
    (recursor update : Carrier → Carrier → Carrier) : Prop :=
  (∀ seed, recursor zero seed = seed) ∧
    ∀ index seed,
      recursor (succ index) seed = update index (recursor index seed)

/-- Induction is restricted to the explicitly supplied predicate class. -/
def OneParameterInduction
    (Predicates : Predicate Carrier → Prop)
    (zero : Carrier) (succ : Carrier → Carrier) : Prop :=
  ∀ predicate, Predicates predicate → ∀ parameter,
    predicate zero parameter →
    (∀ index, predicate index parameter → predicate (succ index) parameter) →
      ∀ index, predicate index parameter

/-- The displayed schema, with no base-case hypothesis. -/
def DiagonalSchema
    (Admitted : Template Carrier → Prop)
    (_zero : Carrier) (succ : Carrier → Carrier)
    (recursor update : Carrier → Carrier → Carrier) : Prop :=
  ∀ template, Admitted template → ∀ seed,
    (∀ index, template index seed seed → template (succ index) seed seed) →
      ∀ index,
        template index seed seed ∧
          recursor (succ index) seed = update index (recursor index seed)

/--
The exact semantic obligations discharged by the concrete first-order syntax.
`admission_sound` follows because the modified base is a literal B → B.
Neither class is assumed to contain all semantic predicates.
-/
structure SyntaxInterface
    (Predicates : Predicate Carrier → Prop)
    (Admitted : Template Carrier → Prop)
    (zero : Carrier) (recursor : Carrier → Carrier → Carrier) : Prop where
  probe_admitted : Admitted (InitializationProbe zero recursor)
  reflexive_admitted : Admitted (ReflexiveTemplate zero)
  normalized_admitted :
    ∀ predicate, Predicates predicate →
      Admitted (NormalizedTemplate zero predicate)
  diagonal_closed :
    ∀ template, Admitted template →
      Predicates (fun index parameter => template index parameter parameter)
  admission_sound :
    ∀ template, Admitted template → ∀ seed,
      template zero (recursor zero seed) seed

/-- Soundness of the literal B → B admission test, considered semantically. -/
theorem reflexive_base_sound
    {base : Prop} (witness : ∃ proposition : Prop,
      base = (proposition → proposition)) : base := by
  obtain ⟨proposition, identical⟩ := witness
  rw [identical]
  intro proof
  exact proof

theorem diagonal_implies_initialization
    {Admitted : Template Carrier → Prop}
    {zero : Carrier} {succ : Carrier → Carrier}
    {recursor update : Carrier → Carrier → Carrier}
    (probe_admitted : Admitted (InitializationProbe zero recursor))
    (schema : DiagonalSchema Admitted zero succ recursor update) :
    ∀ seed, recursor zero seed = seed := by
  intro seed
  have reversed : seed = recursor zero seed :=
    (schema (InitializationProbe zero recursor) probe_admitted seed
      (fun _ proof => proof) zero).1 rfl
  exact reversed.symm

theorem diagonal_implies_successor_computation
    {Admitted : Template Carrier → Prop}
    {zero : Carrier} {succ : Carrier → Carrier}
    {recursor update : Carrier → Carrier → Carrier}
    (reflexive_admitted : Admitted (ReflexiveTemplate zero))
    (schema : DiagonalSchema Admitted zero succ recursor update) :
    ∀ index seed,
      recursor (succ index) seed = update index (recursor index seed) := by
  intro index seed
  exact (schema (ReflexiveTemplate zero) reflexive_admitted seed
    (fun _ proof => proof) index).2

theorem diagonal_implies_induction
    {Predicates : Predicate Carrier → Prop}
    {Admitted : Template Carrier → Prop}
    {zero : Carrier} {succ : Carrier → Carrier}
    {recursor update : Carrier → Carrier → Carrier}
    (normalized_admitted : ∀ predicate, Predicates predicate →
      Admitted (NormalizedTemplate zero predicate))
    (schema : DiagonalSchema Admitted zero succ recursor update) :
    OneParameterInduction Predicates zero succ := by
  intro predicate in_class parameter base step index
  have normalized_step : ∀ index,
      NormalizedTemplate zero predicate index parameter parameter →
      NormalizedTemplate zero predicate (succ index) parameter parameter := by
    intro index conditional initial
    exact step index (conditional initial)
  exact (schema (NormalizedTemplate zero predicate)
    (normalized_admitted predicate in_class) parameter
    normalized_step index).1 base

theorem diagonal_implies_computation_and_induction
    {Predicates : Predicate Carrier → Prop}
    {Admitted : Template Carrier → Prop}
    {zero : Carrier} {succ : Carrier → Carrier}
    {recursor update : Carrier → Carrier → Carrier}
    (interface : SyntaxInterface Predicates Admitted zero recursor)
    (schema : DiagonalSchema Admitted zero succ recursor update) :
    Computation zero succ recursor update ∧
      OneParameterInduction Predicates zero succ := by
  exact ⟨⟨diagonal_implies_initialization interface.probe_admitted schema,
    diagonal_implies_successor_computation interface.reflexive_admitted schema⟩,
    diagonal_implies_induction interface.normalized_admitted schema⟩

theorem computation_and_induction_imply_diagonal
    {Predicates : Predicate Carrier → Prop}
    {Admitted : Template Carrier → Prop}
    {zero : Carrier} {succ : Carrier → Carrier}
    {recursor update : Carrier → Carrier → Carrier}
    (interface : SyntaxInterface Predicates Admitted zero recursor)
    (computation : Computation zero succ recursor update)
    (induction : OneParameterInduction Predicates zero succ) :
    DiagonalSchema Admitted zero succ recursor update := by
  intro template admitted seed step index
  have base : template zero seed seed := by
    have shifted := interface.admission_sound template admitted seed
    rw [computation.1 seed] at shifted
    exact shifted
  exact ⟨induction (fun n parameter => template n parameter parameter)
    (interface.diagonal_closed template admitted) seed base step index,
    computation.2 index seed⟩

theorem diagonal_iff_computation_and_induction
    {Predicates : Predicate Carrier → Prop}
    {Admitted : Template Carrier → Prop}
    {zero : Carrier} {succ : Carrier → Carrier}
    {recursor update : Carrier → Carrier → Carrier}
    (interface : SyntaxInterface Predicates Admitted zero recursor) :
    DiagonalSchema Admitted zero succ recursor update ↔
      (Computation zero succ recursor update ∧
        OneParameterInduction Predicates zero succ) := by
  constructor
  · exact diagonal_implies_computation_and_induction interface
  · intro basis
    exact computation_and_induction_imply_diagonal interface basis.1 basis.2

/-- Separation is retained as a separate arithmetic axiom on both sides. -/
theorem separated_diagonal_iff_basis
    {Predicates : Predicate Carrier → Prop}
    {Admitted : Template Carrier → Prop}
    {zero : Carrier} {succ : Carrier → Carrier}
    {recursor update : Carrier → Carrier → Carrier}
    (interface : SyntaxInterface Predicates Admitted zero recursor) :
    ((zero ≠ succ zero) ∧
      DiagonalSchema Admitted zero succ recursor update) ↔
    ((zero ≠ succ zero) ∧
      Computation zero succ recursor update ∧
        OneParameterInduction Predicates zero succ) := by
  constructor
  · intro theory
    exact ⟨theory.1,
      (diagonal_iff_computation_and_induction interface).mp theory.2⟩
  · intro theory
    exact ⟨theory.1,
      (diagonal_iff_computation_and_induction interface).mpr theory.2⟩

/--
The whole family of recursors shares the same predicate class. A selected legal
description (for example, the zero update) supplies the induction instances.
-/
theorem family_diagonal_iff_basis
    {Description : Type}
    (selected : Description)
    {Predicates : Predicate Carrier → Prop}
    {Admitted : Description → Template Carrier → Prop}
    {zero : Carrier} {succ : Carrier → Carrier}
    {recursors updates : Description → Carrier → Carrier → Carrier}
    (interface : ∀ description,
      SyntaxInterface Predicates (Admitted description) zero
        (recursors description)) :
    ((zero ≠ succ zero) ∧ ∀ description,
      DiagonalSchema (Admitted description) zero succ
        (recursors description) (updates description)) ↔
    ((zero ≠ succ zero) ∧
      (∀ description,
        Computation zero succ (recursors description) (updates description)) ∧
      OneParameterInduction Predicates zero succ) := by
  constructor
  · intro theory
    have basis := fun description =>
      diagonal_implies_computation_and_induction (interface description)
        (theory.2 description)
    exact ⟨theory.1, fun description => (basis description).1,
      (basis selected).2⟩
  · intro theory
    exact ⟨theory.1, fun description =>
      computation_and_induction_imply_diagonal (interface description)
        (theory.2.1 description) theory.2.2⟩

#print axioms reflexive_base_sound
#print axioms diagonal_implies_initialization
#print axioms diagonal_implies_successor_computation
#print axioms diagonal_implies_induction
#print axioms diagonal_implies_computation_and_induction
#print axioms computation_and_induction_imply_diagonal
#print axioms diagonal_iff_computation_and_induction
#print axioms separated_diagonal_iff_basis
#print axioms family_diagonal_iff_basis

end PRADiagonal
