PRA WITH DIAGONAL SEED ADMISSION
Research report prepared for Vladimir Reshetnikov -- 1 November 2026

MAIN RESULT

One effective infinite schema, together with 0 != S0, is definitionally
equivalent to first-order PRA in each matching logic: classical or
intuitionistic. All primitive functions have arity at most two; each actual
nonlogical axiom uses at most two individual variable names.

For each earlier binary update h and quantifier-free template A(x,z,p),
admit the pair exactly when the simultaneous substitution

    A(0, R_h(0,a), a)

is literally B -> B. Emit the axiom

    forall a (
      [forall n (A(n,a,a) -> A(Sn,a,a))]
      -> forall n [A(n,a,a) and
            R_h(Sn,a) = h(n,R_h(n,a))]
    ).

The third formal slot retains the original seed during admission and is
identified with the second slot in the emitted axiom. This recovers the
initialization law without an independent probe parameter. See Section 3
for the purely logical proof and Sections 4--7 for the arithmetic compiler
and the two identity round trips.

The partial display count is 35 (29 + 6). This metric does not include
arbitrary substituted bodies, the grammar, or the admission implementation.
The report does not claim an absolute shortest axiomatization.

CONTENTS

report.pdf              Complete 15-page mathematical report.
report.tex              Editable LaTeX source, including references.
build.py                Rebuilds the report and reruns relevant checks.
checks/                 Structural and finite arithmetic diagnostics.
formal/                 Lean 4.19 logical kernel, scope, and recorded output.
audit/                  Source manifest, build and review records, hashes.

REPRODUCE

    python3 build.py

This requires Python 3.10+ and pdflatex with the packages named in report.tex.
The standard library suffices for both Python diagnostic scripts.
If Lean is on PATH it is checked as well. To specify a Lean executable:

    python3 build.py --lean /path/to/lean

The supplied formal certificate was checked with Lean 4.19.0. All nine
printed theorem dependency reports contain no axiom dependencies. The
kernel assumes the explicit SyntaxInterface obligations for the concrete
formula grammar. It does not formalize the entire first-order syntax,
arithmetic bootstrap, or bi-interpretation. Those proofs are given in the
report; finite numerical tests are not substitutes for them.

BASELINE AND PROVENANCE

All five current archives in VladimirReshetnikov/ProveIt/docs/drafts were
retrieved at commit 0bf6525f9b09421e5ffacdd5fba7648d28b7fcff. Their Git blob
hashes were verified. See audit/source_manifest.json for immutable URLs,
archive hashes, and all LaTeX-member hashes.

The binary recursion grammar and one-parameter pairing construction come
from the inspected drafts. The new contribution is the diagonal admission
reduction and its constructive equivalence proof. The report credits the
reused ingredients and includes a Further research questions section.

