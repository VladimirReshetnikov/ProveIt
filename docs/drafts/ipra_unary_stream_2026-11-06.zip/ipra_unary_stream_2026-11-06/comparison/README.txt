CURRENT IPRA DRAFT ACCEPTANCE-PROGRAM CENSUS

Pinned repository commit: b9aefe20fe876273886d5d55be49e6ccbefce9ad
Scope: all six current docs/drafts ZIPs; every checker*.py in each archive's
root package directory. Exactly 14 complete acceptance programs are included.
Earlier reports describing 13 programs refer to their own older snapshots.
None of the 14 current programs imports a theory-specific helper. Each imports
only the ordinary json and sys standard-library modules. Source files and
available source licenses are copied unchanged. Manifest records retain exact
ZIP membership, Git blob identity, and SHA-256 checksums.

REPRODUCE
    python3 measure.py
    python3 measure.py /absolute/path/to/a/candidate.py

CPython 3.12.14 was used. The normalization removes actual module/function/
class docstrings, then uses ast.unparse(tree) plus a final newline. Comments,
layout/newline tokens, encoding and end markers do not contribute significant
tokens. Every remaining ast.walk node counts, including contexts/operators,
imports, schema data, I/O, argument processing, and rejection behavior.
Raw bytes retain all comments/docstrings/formatting. Source tokens omit only
actual docstring tokens and the ignored lexical token classes. The executable
AST/node terminology does not mean that load contexts or Module are omitted.

COMPLETE-PROGRAM COORDINATEWISE MINIMA
    Significant source tokens       522
    Normalized significant tokens   526
    AST nodes                        537
    Normalized UTF-8 bytes          1633
    Raw UTF-8 bytes                 1683

These minima are attained by different programs. They are a finite observed
lower envelope, not an impossibility lower bound on all potential theories.

UNIFORM CORE-ONLY DIAGNOSTIC
All imports and the top-level __name__ CLI conditional are removed identically
from every program after docstring stripping. The resulting coordinatewise
minima are 461 normalized tokens, 468 AST nodes, and 1324 normalized bytes.
This boundary is supplementary and does not replace complete-program counts.

INTERFACE AND WITNESS POLICY
The reduced_kernel, stack_kernel and unary_universal programs expose open
sequents [goal, proof, *hypotheses], validating all external formulas. Their
well-formed contexts are assumptions; their acceptance does not assert an
unconditional theorem when hypotheses are present. The other programs accept
exactly [goal, proof] at the CLI and use an empty starting context. Arbitrary
free numerical variables are allowed as parameters in both interfaces.

Strict variants validate all witnesses on active rules. Demand variants can
ignore a universal-instantiation annotation if the distinguished variable is
unused in both relevant formula positions. Such an annotation can be replaced
by zero in the extracted strict derivation. Neither policy is blanket proof-
input sanitation: unused alternative/hypothesis proof annotations can remain
uninspected, and prefix stack variants can leave unread stack cells. Stack
checker_exact.py requires stack exhaustion and strict active witnesses.

The rigid_parameters variants additionally allow negative integer syntax
codes as rigid numerical parameters; these are not negative arithmetic values.
The other programs reject negative term codes. All statements concerning the
abstract checker assume finite JSON trees and sufficient interpreter resources.
The full CLI catches ordinary exceptions and prints REJECT/nonzero on failure.

FILES
    manifest.json   Archive/program provenance and interface classification.
    metrics.json    Full measurements, minimum attainments, core diagnostics.
    metrics.csv     Flat comparison table.
    measure.py      Self-contained reproducible measurement implementation.
    sources/       Fourteen unchanged complete acceptance programs.
    licenses/      Unchanged available archive-level source-license records.

This census verifies size, source integrity, dependency boundary and interface.
It does not by itself certify each implementation's metatheoretical correctness.
