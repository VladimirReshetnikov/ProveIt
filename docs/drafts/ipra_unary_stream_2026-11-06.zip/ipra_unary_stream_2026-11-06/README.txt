A SMALLER COMPLETE iPRA PRESENTATION
Unary closure and a shared proof stream
Prepared for Vladimir Reshetnikov, 6 November 2026

RESULT

The complete strict checker has 519 normalized significant Python tokens,
528 executable AST nodes, and 1,611 normalized UTF-8 bytes. All three are
below the coordinatewise minima 526 / 537 / 1,633 among all 14 complete
root checkers in the six active ProveIt draft archives at commit:
  b9aefe20fe876273886d5d55be49e6ccbefce9ad

This is a reduction below a pinned finite comparison corpus, not an absolute
shortest-axiomatization theorem. The logical and arithmetic basis is inherited
from the retained-base unary numerical closure drafts. The new integration
combines that basis with a shared instruction stack and rigid parameters.

The optional demand checker is smaller still: 511 / 520 / 1,567 for the
whole program and 453 / 454 / 1,305 for the uniformly isolated core. It also
strictly beats the core-only envelope, which the strict checker does not.
Its only extra permissiveness is an unused closure-witness annotation;
replacing that annotation by zero gives the same premises and conclusion.

CONTENTS

report.tex and sections/*.tex    Complete self-contained research report
report.pdf                     Compiled report
checker.py                     Primary strict standalone theorem checker
checker_named_table.py         Readable named-table variant, also below envelope
checker_demand.py              Smallest variant with demand witness validation
FORMAT.txt                     Concrete input, syntax, and certificate format
examples/*.json                Canonical theorem certificates
validation/                    Independent interpreter and differential checks
audit/                         Independent substitution and CLI audit
comparison/sources/            All 14 unchanged reference acceptance programs
comparison/manifest.json        Exact archive member provenance and hashes
comparison/github_directory.json  Six archive Git identities at the pinned commit
ablations/                     Standalone intermediate implementations
results/                       Generated measurements and verification results
measure.py                     Regenerate measurements and comparison tables
reproduce.py                   Run all packaged checks and regenerate examples
build.py                       Recompile report.pdf
MANIFEST.sha256                Hashes of the delivered files

QUICK START

Use Python 3.12 for the exact recorded normalization counts.

  python3 checker.py examples/reflexivity_zero.json
  python3 reproduce.py
  python3 build.py

The checker prints ACCEPT or REJECT; rejection exits with status 1.
Only Python's standard library is needed for checking and validation.
A normal pdfLaTeX installation is needed to rebuild the PDF. No network
access is needed to reproduce the supplied evidence.

BOUNDARY AND MATHEMATICAL CLAIM

The public input is [goal, stack], starting with no assumptions. Positive
integer coordinates are ordinary de Bruijn numerical variables, zero is
number zero, and negative integers are rigid numerical parameter names.
They are NOT negative numerical values and do not add constants to iPRA.

Instructions are consumed from the end. Canonical examples exhaust their
stacks; the program allows an inert unread initial segment. It validates
all active witnesses in the primary strict variant. It does not call any
builder, oracle, evaluator, or measurement script.

The report specifies every primitive rule and computation schema. It proves
full intuitionistic logic, quantifier-free induction, faithful presentation
of an ordinary first-order theory, and bi-interpretability with iPRA by
whole-domain interpretations whose two composites are the identity up to
internally proved function equality. The inconsistency statements are
equivalent. Finite tests are supporting evidence; a Lean/Rocq formalization
of the general metatheory is not claimed.

SOURCE ATTRIBUTION

The source snapshot and prior mathematical/implementation contributions are
identified in the report and comparison manifest. Preserved source licenses
are in LICENSE_SOURCE.txt, comparison/licenses, and validation/frozen.
