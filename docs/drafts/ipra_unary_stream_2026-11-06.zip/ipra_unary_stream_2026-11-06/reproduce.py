"""Reproduce measurements, strict/demand checks, independent audits, and examples."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(*arguments):
    command = [sys.executable, *map(str, arguments)]
    completed = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
    if completed.returncode:
        print(completed.stdout)
        print(completed.stderr, file=sys.stderr)
        raise SystemExit(completed.returncode)
    print('Passed: ' + str(arguments[0]))


def write_summary():
    strict = json.loads((ROOT / 'validation/results/results.json').read_text())
    demand = json.loads((ROOT / 'validation/results/demand_results.json').read_text())
    audit = json.loads((ROOT / 'audit/adversarial_results.json').read_text())
    source_hash = hashlib.sha256((ROOT / 'checker.py').read_bytes()).hexdigest()
    if strict['status'] != 'passed' or demand['status'] != 'passed' or not audit['all_passed']:
        raise AssertionError('A validation suite did not pass.')
    if any(result != source_hash for result in
           (strict['checker_sha256'], demand['strict_sha256'], audit['checker_sha256'])):
        raise AssertionError('Validation source hashes disagree.')
    rows = [
        ('Targeted strict fixtures (48 accept, 91 reject)', strict['targeted_fixtures']),
        ('Generated and logical derivations', strict['translated_generated_and_logical_derivations']),
        ('Bounded stack mutations', strict['mutations']),
        ('Named substitution comparisons', strict['named_substitution_comparisons']),
        ('Public CLI executions, including optimized Python', strict['public_CLI_runs']),
        ('Accepted traces rechecked by both frozen oracles', strict['accepted_traces_rechecked_by_both_frozen_tree_checkers']),
        ('Accepted traces canonicalized with exact exhaustion', strict['accepted_traces_canonicalized_and_exhausted']),
        ('Independent named substitution audit', audit['substitution_cases']),
        ('Independent strict/demand CLI executions', len(audit['cli_cases'])),
    ]
    text = 'The delivered strict program passed the following finite checks.\n'
    text += '\\begin{center}\\small\n\\begin{tabular}{lr}\n\\toprule\nCheck category & Count\\\\\n\\midrule\n'
    text += ''.join(label + ' & ' + str(count) + '\\\\\n' for label, count in rows)
    text += '\\bottomrule\n\\end{tabular}\n\\end{center}\n'
    text += ('Seven deliberate faults were detected: unrestricted formula induction, '
             'omission of the atomic IH, omission of the retained base, omission of '
             'the closure-elimination base, existential witness escape, skipped strict '
             'vacuous-witness validation, and shifting rigid parameter names. '
             'The archive contains ' + str(strict['canonical_theorem_example_files']) +
             ' canonical theorem example files.\n\n')
    text += ('For the optional demand variant, all ' +
             str(demand['canonical_strict_derivations_also_accepted_demand']) +
             ' valid canonical strict fixtures also accepted. The audit accepted and '
             'repaired 24 malformed unused witnesses, rejected 36 malformed used '
             'witnesses, and independently checked all ' +
             str(demand['accepted_demand_traces_repaired_to_exhausted_strict_stacks']) +
             ' repaired strict traces with both frozen tree oracles. It also ran ' +
             str(demand['actual_CLI_comparisons']) +
             ' real strict/demand CLI comparisons, including optimized Python.\n')
    (ROOT / 'results/validation_summary.tex').write_text(text)
    combined = {'status': 'passed', 'strict_checker_sha256': source_hash,
                'primary': strict, 'demand': demand, 'independent_audit': audit}
    (ROOT / 'results/validation.json').write_text(json.dumps(combined, indent=2) + '\n')
    shutil.copytree(ROOT / 'validation/results/examples', ROOT / 'examples', dirs_exist_ok=True)
    print('All checks passed; regenerated measurements, validation summary, and examples.')


def main():
    run('measure.py')
    run('validation/verify.py', '--checker', 'checker.py')
    run('validation/verify_demand.py', '--strict', 'checker.py', '--demand', 'checker_demand.py')
    run('audit/adversarial_audit.py', '--checker', 'checker.py', '--demand', 'checker_demand.py',
        '--output', 'audit/adversarial_results.json')
    write_summary()


if __name__ == '__main__':
    main()
