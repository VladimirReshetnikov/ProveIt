"""Compile the complete report using a local pdfLaTeX installation."""
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    results = ROOT / 'results'
    results.mkdir(exist_ok=True)
    if not (results / 'numbers.tex').exists():
        subprocess.run([sys.executable, str(ROOT / 'measure.py')], cwd=ROOT, check=True)
    if not (results / 'validation_summary.tex').exists():
        raise SystemExit('Run python3 reproduce.py before building the report.')
    engine = shutil.which('pdflatex')
    if not engine:
        raise SystemExit('pdfLaTeX is required to compile report.tex.')
    logs = []
    for _ in range(2):
        process = subprocess.run([engine, '-interaction=nonstopmode', '-halt-on-error',
                                  '-file-line-error', 'report.tex'], cwd=ROOT,
                                 capture_output=True, text=True)
        logs.append(process.stdout + process.stderr)
        if process.returncode:
            (results / 'latex_build.txt').write_text('\n'.join(logs))
            print(process.stdout[-8000:])
            raise SystemExit(process.returncode)
    (results / 'latex_build.txt').write_text('\n'.join(logs))
    print('Built report.pdf')


if __name__ == '__main__':
    main()
