"""Reproduce the pinned, whole-program iPRA checker comparison."""
import csv
import importlib.util
import json
from pathlib import Path
import platform

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('source_metrics', ROOT / 'comparison/measure.py')
source_metrics = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source_metrics)
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    old = []
    for entry in manifest['programs']:
        row = source_metrics.metrics(ROOT / 'comparison' / entry['local_file'])
        if row['sha256'] != entry['sha256']:
            raise ValueError('Changed comparison source: ' + entry['local_file'])
        old.append({**entry, **row})
    minima = {key: min(row[key] for row in old) for key in KEYS}
    core_minima = {key: min(row['core'][key] for row in old) for key in KEYS}
    variants = {name: source_metrics.metrics(ROOT / name) for name in
                ('checker.py', 'checker_named_table.py', 'checker_demand.py')}
    primary = variants['checker.py']
    for name in ('checker.py', 'checker_named_table.py'):
        for key in KEYS:
            if variants[name][key] >= minima[key]:
                raise AssertionError((name, key, variants[name][key], minima[key]))
    ablation_manifest = json.loads((ROOT / 'comparison/ablation_source_manifest.json').read_text())
    ablations = []
    for entry in ablation_manifest['stages']:
        row = source_metrics.metrics(ROOT / entry['file'])
        if row['sha256'] != entry['sha256']:
            raise ValueError('Changed ablation source: ' + entry['file'])
        ablations.append({'label': entry['label'], 'file': entry['file'], **row})
    result = {
        'python': platform.python_version(), 'implementation': platform.python_implementation(),
        'commit': manifest['commit'], 'archive_count': len(manifest['archives']),
        'program_count': len(old), 'coordinatewise_minimum': minima,
        'core_coordinatewise_minimum': core_minima,
        'primary': primary, 'variants': variants, 'programs': old, 'ablations': ablations,
        'absolute_reductions': {key: minima[key] - primary[key] for key in KEYS},
        'percentage_reductions': {key: 100 * (minima[key] - primary[key]) / minima[key] for key in KEYS}
    }
    directory = ROOT / 'results'
    directory.mkdir(exist_ok=True)
    (directory / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    fields = ('label', 'normalized_tokens', 'ast_nodes', 'normalized_bytes', 'source_tokens', 'raw_bytes', 'sha256')
    rows = old + [{'label': name, **row} for name, row in variants.items()]
    with (directory / 'metrics.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)
    macros = {'NewTokens': primary['normalized_tokens'], 'NewAST': primary['ast_nodes'],
              'NewBytes': primary['normalized_bytes'], 'OldTokens': minima['normalized_tokens'],
              'OldAST': minima['ast_nodes'], 'OldBytes': minima['normalized_bytes'],
              'TokenDrop': minima['normalized_tokens'] - primary['normalized_tokens'],
              'ASTDrop': minima['ast_nodes'] - primary['ast_nodes'],
              'ByteDrop': minima['normalized_bytes'] - primary['normalized_bytes']}
    (directory / 'numbers.tex').write_text(''.join('\\newcommand{\\' + k + '}{' + str(v) + '}\n'
                                                for k, v in macros.items()))
    lines = ['\\begin{center}\\small', '\\begin{tabular}{llrrr}', '\\toprule',
             'Draft / variant & Policy & Tokens & AST & Bytes\\\\', '\\midrule']
    for row in old:
        label = row['label'].replace('_', ' ').replace('/checker', '').replace('.py', '')
        policy = row['witness_policy'].split(',')[0]
        lines.append(f"{label} & {policy} & {row['normalized_tokens']} & {row['ast_nodes']} & {row['normalized_bytes']}\\\\")
    lines += ['\\midrule', f"\\textbf{{New unary stream}} & strict & \\textbf{{{primary['normalized_tokens']}}} & \\textbf{{{primary['ast_nodes']}}} & \\textbf{{{primary['normalized_bytes']}}}\\\\", '\\bottomrule', '\\end{tabular}', '\\end{center}']
    (directory / 'comparison_table.tex').write_text('\n'.join(lines) + '\n')
    lines = ['\\begin{center}\\small', '\\begin{tabular}{lrrr}', '\\toprule',
             'Cumulative implementation change & Tokens & AST & Bytes\\\\', '\\midrule']
    for row in ablations:
        lines.append(f"{row['label']} & {row['normalized_tokens']} & {row['ast_nodes']} & {row['normalized_bytes']}\\\\")
    lines += ['\\bottomrule', '\\end{tabular}', '\\end{center}']
    (directory / 'ablation_table.tex').write_text('\n'.join(lines) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('programs', 'ablations')}, indent=2))


if __name__ == '__main__':
    main()
