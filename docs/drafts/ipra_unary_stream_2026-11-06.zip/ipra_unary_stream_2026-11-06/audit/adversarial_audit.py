"""Independent finite audits of the combined checker.

This file is not imported by the acceptance program.  Its substitution oracle
first decodes indices into distinct named variables and performs replacement
on names, rather than reimplementing the checker's scope-table traversal.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile


def named_decode(a, bound=(), prefix=(), formula=True):
    if not formula and type(a) is int:
        if a < 0:
            return ("rigid", -a)
        if a == 0:
            return ("zero",)
        return ("bound", bound[a - 1]) if a <= len(bound) else ("free", a - len(bound))
    if not isinstance(a, list):
        raise ValueError("not an expression tree")
    if formula:
        if len(a) == 3 and a[0] == "=":
            return ("eq", named_decode(a[1], bound, prefix + (1,), False),
                    named_decode(a[2], bound, prefix + (2,), False))
        if len(a) == 2 and a[0] in ("q", "ex"):
            x = prefix + ("binder",)
            return (a[0], x, named_decode(a[1], (x,) + bound, prefix + (1,), True))
    else:
        if len(a) == 2 and a[0] == "s":
            return ("s", named_decode(a[1], bound, prefix + (1,), False))
        if len(a) == 4 and a[0] == "r":
            x, y = prefix + ("value",), prefix + ("counter",)
            return ("r", named_decode(a[1], bound, prefix + (1,), False),
                    named_decode(a[2], bound, prefix + (2,), False), x, y,
                    named_decode(a[3], (x, y) + bound, prefix + (3,), False))
    raise ValueError("incorrect sorted constructor")


def named_encode(a, bound=()):
    tag = a[0]
    if tag == "rigid":
        return -a[1]
    if tag == "zero":
        return 0
    if tag == "free":
        return len(bound) + a[1]
    if tag == "bound":
        return bound.index(a[1]) + 1
    if tag == "eq":
        return ["=", named_encode(a[1], bound), named_encode(a[2], bound)]
    if tag in ("q", "ex"):
        return [tag, named_encode(a[2], (a[1],) + bound)]
    if tag == "s":
        return ["s", named_encode(a[1], bound)]
    if tag == "r":
        return ["r", named_encode(a[1], bound), named_encode(a[2], bound),
                named_encode(a[5], (a[3], a[4]) + bound)]
    raise ValueError(tag)


def replace_free_names(a, replacements, delta):
    tag = a[0]
    if tag == "free":
        i = a[1]
        return replacements[i - 1] if i <= len(replacements) else ("free", i + delta)
    if tag in ("zero", "bound", "rigid"):
        return a
    if tag == "eq":
        return (tag, replace_free_names(a[1], replacements, delta),
                replace_free_names(a[2], replacements, delta))
    if tag in ("q", "ex"):
        return (tag, a[1], replace_free_names(a[2], replacements, delta))
    if tag == "s":
        return (tag, replace_free_names(a[1], replacements, delta))
    if tag == "r":
        return (tag, replace_free_names(a[1], replacements, delta),
                replace_free_names(a[2], replacements, delta), a[3], a[4],
                replace_free_names(a[5], replacements, delta))
    raise ValueError(tag)


def oracle_substitution(a, env, depth, formula):
    protected = tuple(("protected", i) for i in range(depth))
    expression = named_decode(a, protected, ("input",), formula)
    replacements = [named_decode(t, (), ("replacement", i), False)
                    for i, t in enumerate(env[:-1])]
    transformed = replace_free_names(expression, replacements, env[-1])
    return named_encode(transformed, protected)


def random_term(rng, depth):
    if depth == 0 or rng.random() < .40:
        return rng.choice([0, 1, 2, 3, 4, 8, -1, -7])
    if rng.random() < .45:
        return ["s", random_term(rng, depth - 1)]
    return ["r", *(random_term(rng, depth - 1) for _ in range(3))]


def random_formula(rng, depth):
    if depth == 0 or rng.random() < .40:
        return ["=", random_term(rng, 2), random_term(rng, 2)]
    return [rng.choice(["q", "ex"]), random_formula(rng, depth - 1)]


def cli_cases():
    zero, one = 0, ["s", 0]
    contradiction = ["=", zero, one]
    r0term = ["r", 0, 0, 0]
    comp = ["=", r0term, 0]
    qcomp = ["q", comp]
    exists_rigid = ["ex", ["=", 1, -7]]
    rigid_major = ["=", ["r", 0, -7, 0], -7]
    rigid_refl_stack = [[], [], [rigid_major, ["=", 1, -7]]]
    ex_zero = ["ex", ["=", 1, 0]]
    vacuous_universal_stack = [[], None, [], [qcomp, ["bogus"]]]
    cases = []

    def add(name, value, expected, explanation, demand=None):
        cases.append({"name": name, "value": value, "expected": expected,
                      "explanation": explanation, "demand_expected": demand})

    add("zero_computation", [comp, [[]]], True, "R(0,0;0)=0 is a computation axiom.")
    add("successor_computation", [["=", ["r", ["s", 0], 0, ["s", 1]],
                                  ["s", ["r", 0, 0, ["s", 1]]]], [[]]], True,
        "The previous recursive value replaces update variable one.")
    add("rigid_reflexivity", [["=", -7, -7], rigid_refl_stack], True,
        "Reflexivity follows from computation and equality transport for a rigid free parameter.")
    add("rigid_existential", [exists_rigid, [None, [-7]]], True,
        "The arbitrary rigid parameter may be an existential witness.")
    add("ordinary_free_existential", [["ex", ["=", 1, 2]], [None, [1]]], True,
        "The external numerical parameter is correctly lifted below the fresh witness variable.")
    add("q_equation_base", [qcomp, [None, []]], True,
        "The constant equation matrix is available as the retained base.")
    add("q_compound_base", [["q", ["ex", ["=", 1, 1]]], [None, []]], True,
        "A constant compound matrix is available as its retained base, without an induction hypothesis.")
    add("unread_prefix", [comp, [{"unread": [False, "arbitrary metadata"]}, []]], True,
        "Unused initial cells are intentionally not certified proof steps.")
    add("failed_major_hypothesis_fallback", [exists_rigid,
        [None, [contradiction, None], [-7]]], True,
        "The failed attempt consumes a cell; the successful local derivation is simply Hyp.")
    add("strict_unused_q_witness", [comp, vacuous_universal_stack], False,
        "Strict mode rejects even an unused malformed numerical instantiation witness.", True)
    add("malformed_existential_witness", [["ex", comp], [[], [["bogus"]]]], False,
        "Existential witnesses are validated even when the matrix does not use them.", False)
    add("false_hypothesis", [contradiction, [None]], False, "The theorem context is empty.")
    add("failed_major_at_root", [contradiction, [None, [contradiction, None]]], False,
        "Failed-major fallback cannot create a missing hypothesis.")
    add("failed_local_context_does_not_leak", [contradiction,
        [None, [0], [["ex", contradiction], None]]], False,
        "The failed major's local witness equation is not added to its caller's context.")
    add("existential_eigenvariable_escape", [["=", 1, 0],
        [None, None, [0], [ex_zero, None]]], False,
        "Opening exists y(y=0) does not imply that an unrelated external x is zero.")
    add("rigid_not_a_numeral", [["=", -1, 0], [None]], False,
        "Negative encodings have no arithmetic value and satisfy no special equations.")
    add("false_equation_induction", [["q", ["=", 1, 0]], [None, []]], False,
        "The equation x=0 is not its own successor-step conclusion.")
    add("variable_recursion_counter", [["=", ["r", 1, 0, 0], 0], [[]]], False,
        "A free variable is not treated as a known zero or successor counter.")
    add("rigid_recursion_counter", [["=", ["r", -7, 0, 0], 0], [[]]], False,
        "Rigid names are likewise not evaluated as concrete recursion counters.")
    add("non_successor_counter", [["=", ["r", r0term, 0, 0], 0], [[]]], False,
        "Only the literal recursion equations are primitive; arbitrary reductions need certificates.")
    add("wrong_successor_result", [["=", ["r", ["s", 0], 0, ["s", 1]], 0], [[]]], False,
        "The checker recomputes the successor equation rather than trusting the asserted right side.")
    add("malformed_equality_motive", [comp, [[], [], [comp, ["bogus"]]]], False,
        "A major equation does not authorize an ill-formed formula motive.")
    add("premature_stack_end", [comp, []], False, "There is no instruction to justify the goal.")
    add("nonlist_stack", [comp, {"instruction": []}], False,
        "The public stack must support the declared list-pop operation.")
    add("extra_public_assumption", [contradiction, [None], contradiction], False,
        "The theorem-only wrapper does not accept an external assumption field.")
    add("missing_public_stack", [comp], False, "The public input must supply the stack.")
    add("boolean_numeral", [["=", False, 0], [None]], False,
        "Python booleans are not admitted as numerical syntax.")
    add("float_numeral", [["=", 0.0, 0], [None]], False,
        "Floating-point zero is not an integer syntax node.")
    add("unknown_formula_tag", [["unknown", 0, 0], [None]], False,
        "Formula formation is checked before interpreting any instruction.")
    add("wrong_formula_arity", [["=", 0], [None]], False,
        "Strict child-width traversal enforces exact arities.")
    add("wrong_term_arity", [["=", ["s", 0, 0], 0], [None]], False,
        "Successor has exactly one term child.")
    add("formula_in_term_position", [["=", ["q", ["=", 0, 0]], 0], [None]], False,
        "The term and formula constructor tables remain disjoint.")
    add("term_in_formula_position", [["q", 0], [None]], False,
        "A numerical atom is not a formula matrix.")
    add("object_impersonating_tree", [{"=": 0, "x": 0, "y": 0}, [None]], False,
        "A JSON object cannot impersonate a well-formed expression tree.")
    add("string_impersonating_tree", ["=00", [None]], False,
        "Expression trees are not reparsed from strings.")
    return cases


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checker", type=Path, required=True)
    parser.add_argument("--demand", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location("audited_checker", args.checker)
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    rng = random.Random(2026110607)
    substitution_count = 0
    for index in range(1600):
        formula = bool(index % 2)
        a = random_formula(rng, 3) if formula else random_term(rng, 3)
        depth = index % 4
        k = index % 3
        delta = rng.choice([-k, 0, 1, 3])
        env = [random_term(rng, 2) for _ in range(k)] + [delta]
        expected = oracle_substitution(a, env, depth, formula)
        actual = checker.subst(a, env, depth, formula)
        if actual != expected:
            raise AssertionError({"input": a, "environment": env, "depth": depth,
                                  "formula": formula, "expected": expected, "actual": actual})
        substitution_count += 1
    records = []
    with tempfile.TemporaryDirectory(prefix="ipra-audit-") as temporary:
        input_path = Path(temporary) / "certificate.json"
        for case in cli_cases():
            input_path.write_text(json.dumps(case["value"]), encoding="utf-8")
            targets = [("strict", args.checker, case["expected"])]
            if args.demand is not None:
                targets.append(("demand", args.demand,
                    case["expected"] if case["demand_expected"] is None else case["demand_expected"]))
            for policy, target, expected in targets:
                result = subprocess.run([sys.executable, str(target), str(input_path)],
                    capture_output=True, text=True, timeout=15)
                wanted = "ACCEPT" if expected else "REJECT"
                success = result.stdout.strip() == wanted and result.returncode == (0 if expected else 1)
                records.append({"name": case["name"], "policy": policy,
                    "expected": wanted, "actual_stdout": result.stdout.strip(),
                    "return_code": result.returncode, "passed": success,
                    "explanation": case["explanation"]})
                if not success:
                    raise AssertionError(records[-1] | {"stderr": result.stderr})
        # A parser error is tested using invalid bytes, not reconstructed JSON.
        input_path.write_text('[ ["=",0,0], [ ]', encoding="utf-8")
        result = subprocess.run([sys.executable, str(args.checker), str(input_path)],
                                capture_output=True, text=True, timeout=15)
        if result.stdout.strip() != "REJECT" or result.returncode != 1:
            raise AssertionError("invalid JSON did not reject")
        records.append({"name": "invalid_json", "policy": "strict", "expected": "REJECT",
                        "actual_stdout": result.stdout.strip(), "return_code": result.returncode,
                        "passed": True, "explanation": "Parsing failures fail closed."})
    output = {
        "checker_path": str(args.checker.resolve()),
        "checker_sha256": hashlib.sha256(args.checker.read_bytes()).hexdigest(),
        "substitution_oracle": "decode to distinct named variables, replace free names, re-encode",
        "substitution_cases": substitution_count,
        "substitution_passed": substitution_count,
        "cli_cases": records,
        "all_passed": all(r["passed"] for r in records),
        "scope": "Finite audit only; the general correctness claims require the separate proofs."
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"substitution_cases": substitution_count, "cli_executions": len(records),
                      "all_passed": output["all_passed"], "output": str(args.output)}))


if __name__ == "__main__":
    main()
