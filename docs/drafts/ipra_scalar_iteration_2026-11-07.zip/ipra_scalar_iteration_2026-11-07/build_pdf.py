#!/usr/bin/env python3
"""Compile the report in three noninteractive passes, without network access."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    compiler = shutil.which('pdflatex')
    if compiler is None:
        raise SystemExit('pdfLaTeX is required to rebuild the supplied PDF.')
    results = ROOT / 'results'
    results.mkdir(exist_ok=True)
    logs = []
    for number in range(1, 4):
        process = subprocess.run([compiler, '-interaction=nonstopmode',
                                  '-halt-on-error', '-file-line-error',
                                  'report.tex'], cwd=ROOT, text=True,
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        logs.append(f'PASS {number}\n' + process.stdout)
        if process.returncode:
            (results / 'pdf_compile.log').write_text('\n'.join(logs))
            print(process.stdout, end='')
            raise SystemExit('PDF build failed; inspect results/pdf_compile.log.')
    (results / 'pdf_compile.log').write_text('\n'.join(logs))
    final = (ROOT / 'report.log').read_text(errors='replace')
    warnings = [line for line in final.splitlines()
                if 'Warning:' in line or 'Overfull' in line]
    if 'undefined references' in final.lower() or 'undefined citations' in final.lower():
        raise SystemExit('PDF contains unresolved references; inspect report.log.')
    page_match = re.search(r'Output written on report\.pdf \((\d+) pages?', final)
    pdf = ROOT / 'report.pdf'
    summary = {'status': 'PASS', 'passes': 3,
               'pages': int(page_match.group(1)) if page_match else None,
               'pdf_bytes': pdf.stat().st_size,
               'pdf_sha256': hashlib.sha256(pdf.read_bytes()).hexdigest(),
               'layout_warnings': warnings,
               'visual_review': 'Recompilation does not perform visual page inspection.'}
    (results / 'pdf_build.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
