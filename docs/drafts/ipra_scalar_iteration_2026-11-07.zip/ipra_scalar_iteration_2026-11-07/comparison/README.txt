PINNED CURRENT-CORPUS COMPARISON

Run from the package root:
  python3 -B comparison/measure.py
The script also works from any other directory. All manifest and runtime paths
are relative to this comparison directory; there is no network dependency.

The six archives in docs/drafts were frozen at ProveIt commit:
  5c4724e5550a1b19347ac62c9b02857a7e3fbd19

sources/ contains unchanged copies of all TEN proposed root checker*.py programs in those
six archives. The two archives called proof_clock are distinct: "Proof clock A"
is the archive whose filename ends "(1).zip"; "Proof clock B" is the unsuffixed
archive. Archived comparator programs nested inside the current packages are
not treated as additional current proposals. The successor-absorption archive
also has a root source_checker.py inherited from a previous proposal. It is
copied and measured separately as an explicitly labeled sensitivity reference;
including it changes neither whole-program nor core coordinatewise minima.

manifest.json records each archive's repository path, Git blob SHA1, ZIP SHA256,
byte size, each copied program's archive member and SHA256, and both candidates'
SHA256 values. source_measure.py is copied unchanged from the argument-opening
archive; its SHA256 is f1404184bf9d39d85c4587f30e191785886c85fed0b3fe01f693191ca6f218dc.
measure.py verifies every pinned program and the measurement helper before use.

The primary comparison includes imports, the public parser, error handling,
entry point, and output. Comments and docstrings are removed by the unchanged
normalizer. Normalized tokens, AST nodes, and normalized bytes are measured
from the resulting AST. Raw bytes and source-token counts are secondary fields.

The common-boundary core comparison removes only top-level imports and the
__name__ entry-point conditional, identically for every program. It is a
secondary statistic; it is not presented as a complete acceptance program.
Closed and open interfaces are explicitly labeled in the manifest and CSV.

Outputs beneath ../results/:
  comparison.json          Full archive provenance, all thirteen programs,
                           whole-program/core envelopes, attainers and deltas.
  comparison.csv           All thirteen programs with both measurement boundaries.
  comparison_table.tex     Compact whole-program table for the report.
  measurement_summary.json Environment, source identities, envelopes and deltas.

All reported minima are coordinatewise minima of this finite inspected corpus,
not mathematical lower bounds on all possible theories or proof checkers.
Exact normalization counts were reproduced with CPython 3.12.14.
