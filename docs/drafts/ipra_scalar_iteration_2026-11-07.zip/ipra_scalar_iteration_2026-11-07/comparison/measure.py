"""Measure ten proposed kernels, one inherited reference, and both candidates.
The normalizer is copied unchanged as source_measure.py. Paths are relative.
"""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import platform

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT.parent/'results'
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def require(condition, description):
    if not condition:
        raise ValueError(description)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_measurement(manifest):
    item = manifest['measurement_source']
    path = ROOT/item['local_path']
    require(sha256(path) == item['sha256'], 'Changed frozen normalization source.')
    specification = importlib.util.spec_from_file_location('frozen_source_measure', path)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def measure_rows(items, measurement, kind):
    rows = []
    for item in items:
        actual = measurement.metrics(ROOT/item['local_path'])
        require(actual['sha256'] == item['sha256'],
                'Changed frozen program: ' + item['local_path'])
        rows.append({**item, **actual, 'kind': kind})
    return rows


def envelope(rows, core=False):
    records = [row['core'] if core else row for row in rows]
    values = {key: min(row[key] for row in records) for key in KEYS}
    attainers = {key: [row['label'] for row, record in zip(rows, records)
                      if record[key] == values[key]] for key in KEYS}
    return values, attainers


def reduction(candidate, minimum, core_minimum):
    return {
        'label': candidate['label'], 'local_path': candidate['local_path'],
        'whole_program': {key: minimum[key] - candidate[key] for key in KEYS},
        'core': {key: core_minimum[key] - candidate['core'][key] for key in KEYS},
        'whole_program_percent': {
            key: 100 * (minimum[key] - candidate[key]) / minimum[key] for key in KEYS},
        'core_percent': {
            key: 100 * (core_minimum[key] - candidate['core'][key]) / core_minimum[key]
            for key in KEYS},
        'strict_whole_program_improvement': all(candidate[key] < minimum[key] for key in KEYS),
        'strict_core_improvement': all(candidate['core'][key] < core_minimum[key] for key in KEYS),
    }


def latex_escape(value):
    return value.replace('\\', r'\textbackslash{}').replace('&', r'\&').replace('_', r'\_')


def latex_table(baselines, inherited, candidates, minimum, improvements):
    lines = [r'{\small', r'\begin{tabular*}{\linewidth}{@{}l@{\extracolsep{\fill}}rrr@{}}',
             r'\toprule', r'Complete program & Tokens & AST & Bytes\\', r'\midrule']
    for row in baselines:
        lines.append(latex_escape(row['label']) + ' & ' +
                     ' & '.join(str(row[key]) for key in KEYS) + r'\\')
    for row in inherited:
        lines.append(latex_escape(row['label']) + ' & ' +
                     ' & '.join(str(row[key]) for key in KEYS) + r'\\')
    lines.extend([r'\midrule', 'Coordinatewise proposal minimum & ' +
                  ' & '.join(str(minimum[key]) for key in KEYS) + r'\\'])
    for row in candidates:
        lines.append(r'\textbf{' + latex_escape(row['label']) + '} & ' +
                     ' & '.join(r'\textbf{' + str(row[key]) + '}' for key in KEYS) + r'\\')
    lines.extend([r'\midrule', 'Primary reduction below minimum & ' +
                  ' & '.join(str(improvements[0]['whole_program'][key]) for key in KEYS) + r'\\',
                  r'\bottomrule', r'\end{tabular*}', '}'])
    return '\n'.join(lines) + '\n'


def main():
    manifest = json.loads((ROOT/'manifest.json').read_text())
    measurement = load_measurement(manifest)
    baselines = measure_rows(manifest['programs'], measurement, 'baseline')
    inherited = measure_rows(manifest['inherited_references'], measurement, 'inherited_reference')
    candidates = measure_rows(manifest['candidates'], measurement, 'candidate')
    require(len(baselines) == 10 and len(candidates) == 2,
            'The pinned cohort must contain ten baselines and two candidates.')
    minimum, attainers = envelope(baselines)
    core_minimum, core_attainers = envelope(baselines, core=True)
    sensitivity_minimum, _ = envelope([*baselines, *inherited])
    sensitivity_core_minimum, _ = envelope([*baselines, *inherited], core=True)
    improvements = [reduction(row, minimum, core_minimum) for row in candidates]
    require(all(row['strict_whole_program_improvement'] and row['strict_core_improvement']
                for row in improvements), 'A candidate no longer beats every envelope coordinate.')
    boundary = {
        'whole_program': 'All executable source, including imports, parsing, entry point, '
                         'error handling, and acceptance output; docstrings and comments removed '
                         'by the unchanged frozen normalization implementation.',
        'core': 'The same AST after deleting top-level imports and the __name__ entry-point '
                'conditional. This is a secondary common-boundary statistic, not a complete checker.',
        'scope': 'Finite-corpus coordinatewise minima, not proved absolute lower bounds; '
                 'the minima can have different attaining programs.',
    }
    environment = {'python': platform.python_version(),
                   'implementation': platform.python_implementation(),
                   'normalization_source_sha256': manifest['measurement_source']['sha256'],
                   'manifest_sha256': sha256(ROOT/'manifest.json')}
    summary = {
        'repository': manifest['repository'], 'commit': manifest['commit'],
        'archive_count': len(manifest['archives']), 'baseline_program_count': len(baselines),
        'inherited_reference_count': len(inherited), 'candidate_count': len(candidates),
        'environment': environment,
        'reference_sensitivity': {
            'coordinatewise_minimum': sensitivity_minimum,
            'core_coordinatewise_minimum': sensitivity_core_minimum,
            'envelope_unchanged': (sensitivity_minimum == minimum and sensitivity_core_minimum == core_minimum)},
        'boundary': boundary, 'coordinatewise_minimum': minimum,
        'core_coordinatewise_minimum': core_minimum, 'minimum_attainers': attainers,
        'core_minimum_attainers': core_attainers, 'reductions': improvements,
    }
    comparison = dict(summary, archives=manifest['archives'],
                      baselines=baselines, inherited_references=inherited, candidates=candidates)
    RESULTS.mkdir(exist_ok=True)
    (RESULTS/'comparison.json').write_text(json.dumps(comparison, indent=2) + '\n')
    (RESULTS/'measurement_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    fields = ['kind', 'label', 'interface', 'local_path', 'archive_name', 'archive_member',
              'source_tokens', *KEYS, 'raw_bytes',
              'core_normalized_tokens', 'core_ast_nodes', 'core_normalized_bytes', 'sha256']
    with (RESULTS/'comparison.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fields, extrasaction='ignore')
        writer.writeheader()
        for row in [*baselines, *inherited, *candidates]:
            writer.writerow(dict(row, **{'core_' + key: row['core'][key] for key in KEYS}))
    (RESULTS/'comparison_table.tex').write_text(
        latex_table(baselines, inherited, candidates, minimum, improvements))
    print(json.dumps({key: value for key, value in summary.items()
                      if key not in ('boundary', 'minimum_attainers', 'core_minimum_attainers')},
                     indent=2))


if __name__ == '__main__':
    main()
