# Removing the recursion counter from iPRA

**A scalar iterator, an internal predecessor construction, and a smaller complete proof checker.** Prepared for Vladimir Reshetnikov, 7 November 2026.

The complete mathematical deliverable is [report.pdf](report.pdf), with source [report.tex](report.tex) and the files in `sections/`. The public certificate format is specified in [FORMAT.md](FORMAT.md). Reused material and historical sources are identified in [ATTRIBUTION.txt](ATTRIBUTION.txt).

## What this construction achieves

The numerical basis has zero, successor, and one initialized scalar iterator:

\[
I(0,a;u.h)=a,\qquad
I(Sn,a;u.h)=h[I(n,a;u.h)/u].
\]

Only the previous value `u` is bound in the update `h`. The iteration count and initializer are outside that binding, and every other parameter in `h` is fixed. In particular, the update has no primitive previous-counter variable. These are schemas for each fixed finite update term; there is no object-language evaluator taking a program code as input.

The logical basis is the supplied fused-binder calculus: equations, a one-variable closure binder `Q`, a two-variable binder `D`, five inference patterns, and the two computation schemas above. Its intended ordinary readings are

\[
Q_xB=B(0)\to\forall xB(x),\qquad
D_{x,y}B=\exists x\bigl(B(x,0)\to\forall yB(x,y)\bigr).
\]

The report states every native rule and derives ordinary intuitionistic logic, equality reflection, quantifier-free induction, and the primitive-recursive operations needed for the interpretations. The resulting ordinary first-order theory is bi-interpretable with full intuitionistic primitive recursive arithmetic with quantifier-free induction. Both interpretations use the entire numerical domain. Each composite isomorphism has graph `x = y`, and the theories are equiconsistent.

The arithmetic reduction is substantive: the drafts' update `R(n,a;u,v.h)` receives both a previous value and a previous counter. Here the latter is reconstructed internally. The essential steps are:

1. Construct a Boolean control term `c(y,n)` from scalar iteration. Prove its diagonal and shifted-diagonal identities and persistence of zero using literal-equation induction.
2. Use one guarded equation, with its parameter fixed during induction, to recover predecessor from the diagonal of a cyclic iterator. No predecessor, successor injectivity, pairing, or quantifier-free induction is assumed at this stage.
3. Derive equality reflection and quantifier-free induction. Construct subtraction, bounded square-root search, and numerical pairing with provable projection identities.
4. Simulate each fixed primitive recursion by iterating a paired state containing its counter and previous value. Prove the computation equations and both interpretation round trips internally.

Scalar iteration's extensional completeness for primitive-recursive functions has classical precedents, including Gladstone's work and Severin's survey of the available bases. That historical fact is not claimed as a new discovery. The contribution relative to the supplied drafts is the explicit weak-theory bootstrap, its use in an internal bi-interpretation, and the smaller fully counted checker. Historical priority for the factor-trading construction itself has not been established.

## Exact complexity comparison

The comparison freezes the supplied repository at commit
`5c4724e5550a1b19347ac62c9b02857a7e3fbd19`:

<https://github.com/VladimirReshetnikov/ProveIt/tree/5c4724e5550a1b19347ac62c9b02857a7e3fbd19/docs/drafts>

The current corpus consists of ten proposed `checker*.py` kernels across six archives. An additional inherited `source_checker.py` in the successor-absorption archive is larger and does not change the comparison envelope. Older comparator copies nested inside the archives are not counted as additional current proposals. Exact archive identities and copied source hashes are recorded in `comparison/manifest.json`.

The disclosed metric removes genuine Python docstrings, normalizes with `ast.unparse` plus a final newline, and counts significant normalized tokens, all AST nodes, and normalized UTF-8 bytes. Comments, whitespace tokens, and formatting choices do not improve these scores. The complete acceptance program is measured: imports, JSON loading, syntax validation, substitution, freshness, all rules, verdict printing, and rejection exit status. Python and its standard library form the common ambient runtime.

| Complete program or comparison envelope | Normalized tokens | AST nodes | Normalized bytes |
|---|---:|---:|---:|
| Separate minima among the ten proposed source kernels | 427 | 436 | 1,246 |
| `checker.py` | **413** | **427** | **1,210** |
| `checker_depth.py` | **414** | **425** | **1,212** |
| Primary reduction below the source minima | 14 | 9 | 36 |

The source minima need not be attained by one source program. The primary reduction is approximately 3.28% in tokens, 2.06% in AST nodes, and 2.89% in normalized bytes. Both delivered kernels are strictly below all three minima. The companion has the smaller AST; the primary has fewer tokens and bytes.

For a boundary sensitivity check, deleting the same imports and public driver from every measured program gives:

| Core only | Normalized tokens | AST nodes | Normalized bytes |
|---|---:|---:|---:|
| Separate source minima | 367 | 373 | 979 |
| `checker.py` | 354 | 364 | 960 |
| `checker_depth.py` | 355 | 362 | 962 |

Exact published normalization used CPython 3.12.14. Different Python versions may change `ast.unparse` output. The frozen metric implementation is retained in `comparison/source_measure.py`; the package's current comparison driver is `comparison/measure.py`. Full measurements are in `results/comparison.json` and `results/comparison.csv`, with the envelope and reductions in `results/measurement_summary.json`.

These inequalities establish improvement over the measured lower envelope of the supplied proposals. They do not establish an absolute minimum over all presentations, programming languages, encodings, or possible proof checkers.

## Reproduction

From the extracted package directory, run:

```sh
python3 reproduce.py
```

This verifies the frozen kernel hashes, measures the comparison sources, runs the portable checker validation, and reruns the numerical examples. Results and logs are written beneath `results/`, with detailed checker results under `validation/results/` and numerical results in `numerical/iterator_results.json`. `results/reproduction.json` records the overall result. The script also works when invoked by absolute path from another directory.

To rebuild the PDF as well:

```sh
python3 reproduce.py --pdf
```

The checkers and Python reproduction scripts require Python 3.10 or later and the standard library. Exact metric replication uses CPython 3.12.14. PDF rebuilding additionally requires pdfLaTeX and the ordinary packages listed in `report.tex`; `build_pdf.py` runs three noninteractive compilation passes. The supplied PDF can be read without a TeX installation. Reproduction uses no network access and needs no original checkout or files outside this package.

To rebuild the distributable ZIP after reproduction, run `python3 make_archive.py`.
It writes the ZIP beside the package directory and refreshes `SHA256SUMS.txt`,
excluding transient TeX files and Python caches.

The components can also be run separately:

```sh
python3 comparison/measure.py
python3 validation/verify.py
python3 numerical/check_iterator_model.py
python3 build_pdf.py
```

For an individual packet, save one of the JSON packet examples in `FORMAT.md` to a file and run:

```sh
python3 checker.py proof.json
python3 checker_depth.py proof.json
```

Each public checker prints `ACCEPT` with status 0 or `REJECT` with status 1. The JSON case collections under `validation/new_cases/` are test metadata, not single proof packets: extract a record's `packet` field before passing it to a checker.

## Mathematical proof and finite evidence

The report contains mathematical proofs of the arithmetic bootstrap, the interpretations, and the checker's soundness and canonical completeness. It does not contain a Lean or Rocq formalization of those metatheorems. The executable tests support implementation review and reproducibility; they are finite tests, not substitutes for the proofs.

The portable checker validation records, for **each** delivered kernel:

| Check | Scope |
|---|---|
| Explicit named-binder opening oracle | 3,672 cases: 2,043 valid and 1,629 rejected |
| Scalar-to-binary opening coherence | The same 3,672 cases |
| Fixed certificate corpus | 62 distinct packets: 45 accepted and 17 rejected |
| Packet mutation corpus | 1,200 attempts, yielding 1,125 distinct packets |
| Actual public command-line calls | 124: 62 with ordinary Python and 62 with `-O` |
| Focused incorrect implementations | Five deliberate mutants |
| Focused translation controls | Twelve |
| Generated finite computation certificates | Eight, containing 5–71 instruction cells |

The two candidates reuse the same corpora. There are 248 public command-line runs in total, not 248 distinct theorems. The fixed corpus comprises 32 directly transported counter-free source proofs, 27 newly generated scalar cases, one retained-base separating theorem, and two transported negative controls.

The finite source-to-target transporter deliberately handles only source updates whose counter binders are unused. It transports 32 of 45 positive frozen source certificates and explicitly excludes the remaining 13. The general primitive-recursion simulation is a mathematical theorem in the report; it is not implemented or verified by this restricted transporter. The opposite embedding inserts an unused counter binder and is used only as a validation reference. Neither translator is imported by either acceptance kernel.

The numerical artifacts contain **2,100 checks**, split into three disclosed modes:

| Numerical mode | Checks | Evaluation method |
|---|---:|---|
| Literal bootstrap | 12 | Direct scalar iteration, no cache and no predecessor shortcut |
| Prefix-memoized bootstrap | 1,953 | Exact iterator-orbit prefixes reused, no predecessor shortcut |
| Post-predecessor arithmetic | 135 | Uses the proved predecessor equations as an evaluator rewrite |

The bootstrap checks include predecessor through argument 10. The post-predecessor checks cover bounded root search, pairing projections, and four compiled primitive recursions. Every iterator update receives only its previous state; the Python loop counter is not passed to the update. The compiler recovers a counter from its numerical paired state. See `numerical/README.txt` for the exact evaluation scope and disclosed optimization.

Two limitations of the executable interface are intentional and explicit. It accepts closed native theorems, with no external assumptions or parameter declarations. Also, finite Python parsing, recursion, and memory limits may reject very large valid certificates; rejection is not a theorem of underivability. Canonical serialization is complete under the ordinary unbounded-resource interpretation of the algorithm.

## Package guide

| Path | Purpose |
|---|---|
| `report.pdf`, `report.tex`, `sections/` | Complete article and editable mathematical source |
| `checker.py`, `checker_depth.py` | The two complete measured acceptance programs |
| `FORMAT.md` | Numerical and formula scopes, packet layout, rules, and exact examples |
| `comparison/` | Frozen comparison sources, provenance, and measurement code |
| `validation/` | Independent named-binder oracle, source transports, generated cases, adversarial controls, and results |
| `numerical/` | Explicit numerical term implementations and finite numerical evidence |
| `reproduce.py`, `build_pdf.py`, `make_archive.py`, `results/` | Reproduction entry points, comparison measurements, logs, and results |
| `ATTRIBUTION.txt`, `LICENSE_SOURCE.txt` | Provenance, historical references, and preserved source license |

The article also records why a tempting additional shortening—removing the retained base from atomic introduction while leaving the other rules unchanged—fails. The retained base remains in both delivered kernels. This obstruction is separate from the successful scalar-iterator reduction.
