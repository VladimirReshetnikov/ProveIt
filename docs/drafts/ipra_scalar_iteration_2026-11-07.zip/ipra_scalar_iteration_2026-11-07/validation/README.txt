SCALAR-ITERATOR CHECKER VALIDATION

From the package root run:
  python3 -B validation/verify.py
Or run from any directory with the absolute path to validation/verify.py.
The default candidates are ../checker.py and ../checker_depth.py, relative
to this directory. Two repeated --checker PATH arguments override these paths.
Only Python 3.10+ and its standard library are required. No network, original
checkout, review_inputs, checker_work, or other external directory is used.

Each candidate passes:
- 3,672 opening cases (2,043 valid and 1,629 rejected) against an explicit
  named-binder oracle.
- The same 3,672 cases additionally test that scalar opening commutes with
  embedding into the unchanged frozen binary-recursor checker.
- 62 distinct fixed packets, 45 accepting and 17 rejecting: 32 counter-free
  source transports; 27 independently generated scalar cases; one retained-base
  separating theorem; and two transported negative controls.
- 1,200 packet mutations, 1,125 distinct in this fixed ordered corpus.
- 124 actual public CLI calls, 62 under normal Python and 62 under Python -O.
  The two-candidate total is 248. Each candidate reuses the same corpora.
- Five explicit implementation mutants: contextual image capture; restoring an
  invalid second update binder; omitting root-goal validation; allowing compound
  induction hypotheses; and removing the atomic retained base.
- Twelve focused translation controls, including both paired spellings of
  removed counter variables under nested iteration and logical binders.
- Eight finite computation certificates, 5-71 instructions, whose numerical
  values are also checked by a direct standard-number evaluator.

The reference source_checker.py is an unchanged frozen R2 checker from the
fused-binder archive at the recorded ProveIt commit. lift_to_binary.py inserts
one unused counter binder into each scalar update and adjusts all remaining
coordinates. It is used only for validation, not by the candidate kernels.

transport_counter_free.py implements a deliberately partial reverse map.
Exactly 32 of 45 positive frozen source certificates have unused counter binders
throughout and transport directly. The other 13 are explicitly excluded.
The mathematical general R2-to-I simulation is a theorem of the report; these
finite transports do not implement it and are not claimed to verify it.

named_oracle.py independently parses named binder trees. It has been adapted
for one update binder and one successor-substitution image. Its tree record
retains an unused dummy counter-name field solely to reuse inherited traversal
code;that field is never added to the update binding context.

The new retained-base theorem is D_{w,x}(x=S0), with w unused.
generate_separation.py constructs a 9-instruction proof using the retained
base 0=S0 once and never using the induction hypothesis. Removing the atomic
base causes the deliberate mutant to reject this valid certificate. This is
an incompleteness control, not a soundness defect. The report's separate
counterinterpretation establishes nonderivability in the modified calculus.

The new 4-instruction capture attack targets D_{x,y}G_y(x=y), which is false:
the zero gate is true, but no number equals every successor. Correct kernels
and the named oracle reject it; validating witness images at their insertion
depth instead of depth zero makes the deliberate mutant accept it.

All hashes and input provenance are in provenance.json and source_fixtures.json.
The original source license is retained. Results are reproducible JSON files
under results/. Helpers, fixtures, translators, oracle, and generators are all
outside each measured candidate's trusted acceptance boundary.

These are finite tests, not proof-assistant formalizations or a universal
soundness/completeness proof. Counts are packet or test counts, not numbers
of distinct mathematical theorems.
