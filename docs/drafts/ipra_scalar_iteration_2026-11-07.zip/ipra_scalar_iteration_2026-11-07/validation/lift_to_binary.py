"""Embed scalar-iterator syntax into the unchanged binary-recursor checker.

Insert one unused counter binder into each iterator update. Every existing
bound or exposed coordinate is shifted to retain its reference; paired alias
spelling is preserved. Thus the old R2 computation clauses simulate I exactly.
The extension to malformed JSON keeps invalid constructors invalid and supports
finite differential tests; the mathematical claim concerns valid syntax.
"""
from copy import deepcopy


def leaf(value, old, new):
    slot = (value - 1) // 2
    if slot < len(old):
        target = new.index(old[slot])
    else:
        target = len(new) + slot - len(old)
    return 2 * target + 1 + (1 - value % 2)


def term(value, old=(), new=()):
    if type(value) is int:
        return value if value <= 0 else leaf(value, old, new)
    if type(value) is not list:
        return deepcopy(value)
    if len(value) == 1:
        return [term(value[0], old, new)]
    if len(value) == 3:
        previous, counter = object(), object()
        return [term(value[0], old, new), term(value[1], old, new),
                term(value[2], (previous,) + old, (previous, counter) + new)]
    return deepcopy(value)


def formula(value, old=(), new=()):
    if type(value) is not list:
        return deepcopy(value)
    if len(value) == 2:
        return [term(t, old, new) for t in value]
    if len(value) in (1, 3):
        count = 1 if len(value) == 1 else 2
        bound = tuple(object() for _ in range(count))
        return [formula(b, bound + old, bound + new) for b in value]
    return deepcopy(value)


def packet(value):
    if type(value) is not list or not value:
        return deepcopy(value)
    result = []
    for cell in value[:-1]:
        if type(cell) is list and len(cell) == 1:
            result.append([term(cell[0])])
        elif (type(cell) is list and len(cell) == 2
              and type(cell[0]) is list):
            major, annotation = cell
            if len(major) == 2:
                hole = object()
                annotation = formula(annotation, (hole,), (hole,))
            elif len(major) == 1:
                annotation = term(annotation)
            result.append([formula(major), deepcopy(annotation)])
        else:
            result.append(deepcopy(cell))
    return result + [formula(value[-1])]
