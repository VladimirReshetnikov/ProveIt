"""Reproduce finite validation of both scalar-iterator iPRA kernels.

All support is local and outside the trusted acceptance programs. No network
or file outside this package is required. The default kernels are ../checker.py and ../checker_depth.py; repeated
--checker PATH options validate relocated copies.
"""
from pathlib import Path
from copy import deepcopy
import argparse
import hashlib
import importlib.util
import json
import platform
import random
import subprocess
import sys
import tempfile
import types

from named_oracle import Oracle
from opening_audit import audit_opening
from mutation_support import mutate
from generate_separation import make_packet
from generate_scalar_cases import cases as scalar_cases
import transport_counter_free as restrict
import lift_to_binary as lift

ROOT = Path(__file__).resolve().parent


def require(value, message):
    if not value:
        raise AssertionError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def packet_digest(packet):
    return hashlib.sha256(json.dumps(packet, sort_keys=True,
                                     separators=(',', ':')).encode()).hexdigest()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(module, packet):
    module.k = 0
    stream = deepcopy(packet)
    try:
        module.take = stream.pop
        accepted = bool(module.check(stream.pop(), []))
        error = None
    except Exception as exception:
        accepted, error = False, type(exception).__name__
    return {'accepted': accepted, 'error': error, 'final_k': module.k,
            'remaining': len(stream) if type(stream) is list else None}


def oracle_run(packet):
    try:
        return Oracle().run(packet)
    except (AttributeError, TypeError):
        return {'accepted': False, 'error': 'nonarray_packet', 'final_k': 0,
                'remaining': None, 'allocations': [], 'rules': {}}


class OpeningAudit:
    """Compare an I opening with the unchanged R2 opening after embedding."""
    def __init__(self, candidate, reference):
        self.candidate, self.reference = candidate, reference
        self.comparisons = 0

    @property
    def k(self):
        return self.candidate.k

    @k.setter
    def k(self, value):
        self.candidate.k = self.reference.k = value

    def inst(self, value, *images, d=0):
        self.comparisons += 1
        try:
            actual = self.candidate.inst(deepcopy(value), *deepcopy(images), d=d)
            failed = None
        except Exception as exception:
            actual, failed = None, exception
        protected = tuple(object() for _ in range(d // 2))
        convert = lift.term if d % 2 else lift.formula
        encoded_value = convert(value, protected, protected)
        encoded_images = tuple(lift.term(image) for image in images)
        try:
            expected = self.reference.inst(encoded_value, encoded_images, d)
            reference_failed = False
        except Exception:
            expected, reference_failed = None, True
        require((failed is not None) == reference_failed,
                ('embedding opening validity', value, images, d))
        if failed is not None:
            raise failed
        require(convert(actual, protected, protected) == expected,
                ('embedding opening result', value, images, d, actual, expected))
        return actual


def standard_value(term, environment=()):
    """Direct standard-number meaning, independent of proof interpretation."""
    if type(term) is int:
        if term == 0:
            return 0
        require(term > 0, 'No free rigid parameter in finite numeric examples.')
        return environment[(term - 1) // 2]
    if len(term) == 1:
        return standard_value(term[0], environment) + 1
    counter, initial, update = term
    value = standard_value(initial, environment)
    for _ in range(standard_value(counter, environment)):
        value = standard_value(update, (value, *environment))
    return value


def translation_controls():
    accepted = [
        ([0, 0, 1], [0, 0, 1]),
        ([0, 0, 2], [0, 0, 2]),
        ([0, 0, [0, 0, 5]], [0, 0, [0, 0, 3]]),
        ([0, 0, [0, 0, 6]], [0, 0, [0, 0, 4]]),
    ]
    rejected = [
        [0, 0, 3], [0, 0, 4],
        [0, 0, [0, 0, 3]], [0, 0, [0, 0, 4]],
        [0, 0, [0, 0, 7]], [0, 0, [0, 0, 8]],
    ]
    for source, target in accepted:
        require(restrict.term(source) == target, ('term restriction', source))
        require(lift.term(target) == source, ('term round trip', source))
    for source in rejected:
        try:
            restrict.term(source)
        except restrict.CounterUsed:
            pass
        else:
            raise AssertionError(('counter use escaped restriction', source))
    formula_pairs = [
        ([[[0, 0, 5], 0]], [[[0, 0, 3], 0]]),
        ([[[0, 0, 7], 0], [0, 0], [0, 0]],
         [[[0, 0, 5], 0], [0, 0], [0, 0]]),
    ]
    for source, target in formula_pairs:
        require(restrict.formula(source) == target, ('formula restriction', source))
        require(lift.formula(target) == source, ('formula round trip', source))
    return {'accepted_term_pairs': 4, 'rejected_counter_terms': 6,
            'accepted_formula_pairs': 2}


def cli(path, packet_file, expected, optimized):
    result = subprocess.run([sys.executable, *(['-O'] if optimized else []),
                             str(path), str(packet_file)],
                            capture_output=True, text=True, timeout=20)
    wanted = (0, 'ACCEPT', '') if expected else (1, 'REJECT', '')
    require((result.returncode, result.stdout.strip(), result.stderr) == wanted,
            ('CLI', path.name, packet_file.name, optimized, result.stdout, result.stderr))
    return {'optimized': optimized, 'exit_code': result.returncode,
            'stdout': result.stdout.strip()}


def changed_module(source, old, new, label):
    require(source.count(old) == 1, ('mutation anchor', label))
    module = types.ModuleType('deliberate_' + label)
    # Execute only the inspected checker source with this explicitly listed
    # local alteration, never any data taken from a proof certificate.
    exec(compile(source.replace(old, new), label, 'exec'), module.__dict__)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', type=Path, action='append')
    parser.add_argument('--output', type=Path, default=ROOT/'results')
    args = parser.parse_args()
    paths = [p.resolve() for p in (args.checker or [
        ROOT.parent/'checker.py',
        ROOT.parent/'checker_depth.py'])]
    require(len(paths) == 2 and len({p.stem for p in paths}) == 2,
            'Supply two candidate files with distinct stems.')
    args.output.mkdir(parents=True, exist_ok=True)
    provenance = json.loads((ROOT/'provenance.json').read_text())
    for name, expected in provenance['pinned_files'].items():
        require(digest(ROOT/name) == expected, ('changed support', name))
    source_rows = json.loads((ROOT/'source_fixtures.json').read_text())['cases']
    source_by_name = {row['name']: row for row in source_rows}
    transported, excluded = restrict.transport_all(source_rows)
    require(len(transported) == 32 and len(excluded) == 13, 'Transport cohort changed.')
    for row in transported:
        require(lift.packet(row['packet']) == source_by_name[row['name']]['packet'],
                ('counter-free packet round trip', row['name']))
    generated = scalar_cases()
    require(generated == json.loads((ROOT/'new_cases/scalar_cases.json').read_text()),
            'Scalar generated fixtures do not reproduce.')
    separation = make_packet()
    require(separation == json.loads((ROOT/'new_cases/retained_base_separation.json').read_text()),
            'The retained-base separation certificate does not reproduce.')
    rows = [*transported, *generated,
            {'name': 'retained_base_separation', 'packet': separation, 'expected': True}]
    for name in ('compound_induction_hypothesis', 'false_eigenparameter_escape'):
        rows.append({'name': name, 'packet': restrict.packet(source_by_name[name]['packet']),
                     'expected': False})
    require(rows == json.loads((ROOT/'new_cases/all_cases.json').read_text()),
            'The combined case corpus does not reproduce.')
    require(len(rows) == len({packet_digest(r['packet']) for r in rows}) == 62,
            'Fixed packet count changed.')
    controls = translation_controls()
    numerical = []
    for row in generated:
        if row['name'].startswith('scalar_evaluation_') and row['expected']:
            actual = standard_value(row['packet'][-1][0])
            require(actual == row['explanation']['standard_value'],
                    ('numerical value', row['name'], actual))
            numerical.append({'name': row['name'], 'value': actual,
                              'instruction_cells': len(row['packet']) - 1})
    reference = load(ROOT/'source_checker.py', 'frozen_binary_reference')
    baseline = []
    for row in rows:
        original = run(reference, lift.packet(row['packet']))
        named = oracle_run(row['packet'])
        require(original['accepted'] == named['accepted'] == row['expected'],
                ('fixed oracle', row['name'], original, named))
        baseline.append((original, named))
    random_source = random.Random(20261107)
    mutations = []
    for index in range(1200):
        parent = rows[index % len(rows)]
        packet = mutate(parent['packet'], random_source)
        original, named = run(reference, lift.packet(packet)), oracle_run(packet)
        require(original['accepted'] == named['accepted'],
                ('mutation oracle', index, original, named))
        mutations.append({'index': index, 'parent': parent['name'], 'packet': packet,
                          'packet_sha256': packet_digest(packet),
                          'expected': original['accepted']})
    by_name = {row['name']: row for row in rows}
    summaries = []
    for path in paths:
        candidate = load(path, 'candidate_' + path.stem)
        opening_proxy = OpeningAudit(candidate, reference)
        openings = audit_opening(opening_proxy)
        require(openings == {'invalid': 1629, 'valid': 2043},
                ('opening cohort changed', openings))
        fixed_rows = []
        with tempfile.TemporaryDirectory(prefix='ipra_iterator_validation_') as temporary:
            for index, (row, (original, named)) in enumerate(zip(rows, baseline)):
                actual = run(candidate, row['packet'])
                for field in ('accepted', 'remaining', 'final_k'):
                    require(actual[field] == original[field],
                            (path.name, row['name'], field, actual, original))
                packet_file = Path(temporary)/f'case_{index:03d}.json'
                packet_file.write_text(json.dumps(row['packet']) + '\n')
                executions = [cli(path, packet_file, row['expected'], optimized)
                              for optimized in (False, True)]
                fixed_rows.append({'name': row['name'], 'expected': row['expected'],
                                   'packet_sha256': packet_digest(row['packet']),
                                   'candidate': actual, 'named_oracle': named,
                                   'cli': executions})
        mutation_rows = []
        for row in mutations:
            actual = run(candidate, row['packet'])['accepted']
            require(actual == row['expected'], (path.name, 'packet mutation', row['index']))
            mutation_rows.append({k: v for k, v in row.items() if k != 'packet'} |
                                 {'accepted': actual})
        modifications = [
            ('contextual_image_capture',
             'inst(env[a - d >> 1], d=1)', 'inst(env[a - d >> 1], d=d)',
             'scalar_contextual_capture', True,
             'Accepts the false formula D_xy G_y(x=y) by capturing an image coordinate.'),
            ('old_two_binder_formation',
             "b'\\0\\0\\2'", "b'\\0\\0\\4'",
             'nonexistent_counter_slot', True,
             'Accepts a malformed scalar update using a nonexistent counter binder.'),
            ('goal_validation_removed', 'if inst(a) in g:', 'if a in g:',
             'false_eigenparameter_escape', True,
             'Accepts a forbidden escaping eigenparameter.'),
            ('compound_induction_hypothesis',
             'h = [b, inst(b, 0)][len(b) % 2:]', 'h = [b, inst(b, 0)]',
             'compound_induction_hypothesis', True,
             'Accepts an impermissible certificate; the conclusion has another proof.'),
            ('atomic_retained_base_removed',
             'h = [b, inst(b, 0)][len(b) % 2:]',
             'h = [b] if len(b) == 2 else [inst(b, 0)]',
             'retained_base_separation', False,
             'Rejects a valid certificate: incompleteness, not unsoundness. '
             'The separate counterinterpretation proves the stronger nonderivability claim.'),
        ]
        mutant_rows = []
        source = path.read_text()
        for label, old, new, name, expected, explanation in modifications:
            mutant = changed_module(source, old, new, label)
            actual = run(mutant, by_name[name]['packet'])['accepted']
            require(actual == expected, (path.name, 'mutation control', label, actual))
            mutant_rows.append({'name': label, 'fixture': name,
                                'original_accepts': by_name[name]['expected'],
                                'mutant_accepts': actual, 'interpretation': explanation})
        result = {
            'status': 'PASS', 'python': platform.python_version(),
            'checker': path.name, 'checker_sha256': digest(path),
            'binary_reference_sha256': digest(ROOT/'source_checker.py'),
            'named_oracle_sha256': digest(ROOT/'named_oracle.py'),
            'opening_cases': openings, 'opening_case_count': sum(openings.values()),
            'opening_embedding_comparisons': opening_proxy.comparisons,
            'transported_counter_free_proofs': 32, 'excluded_counter_using_proofs': 13,
            'new_scalar_cases': 27, 'new_retained_base_case': 1,
            'transported_negative_controls': 2,
            'fixed_packets': 62, 'distinct_fixed_packets': 62,
            'positive_fixed_packets': 45, 'negative_fixed_packets': 17,
            'actual_cli_runs': 2*len(rows), 'packet_mutations': len(mutations),
            'distinct_packet_mutations': len({r['packet_sha256'] for r in mutations}),
            'numeric_evaluations': numerical, 'translation_controls': controls,
            'mutation_controls': mutant_rows, 'cases': fixed_rows, 'mutations': mutation_rows,
            'limits': 'Finite executable evidence. The source-to-target proof translator '
                      'is deliberately restricted to unused-counter updates; these tests '
                      'do not prove the general R2-to-I simulation or the metatheory.',
        }
        (args.output/(path.stem + '.json')).write_text(json.dumps(result, indent=2) + '\n')
        summary = {key: value for key, value in result.items()
                   if key not in ('cases', 'mutations', 'mutation_controls')}
        summaries.append(summary)
        print(json.dumps(summary, indent=2))
    overall = {'status': 'PASS', 'candidates': summaries,
               'total_actual_cli_runs': sum(x['actual_cli_runs'] for x in summaries),
               'unique_fixed_corpus_packets': 62,
               'unique_mutation_corpus_packets': len({x['packet_sha256'] for x in mutations}),
               'cohort_note': 'Both candidates reuse the same corpora; counts are not '
                              'distinct mathematical theorems.'}
    (args.output/'summary.json').write_text(json.dumps(overall, indent=2) + '\n')
    print('SCALAR-ITERATOR VALIDATION PASSED')


if __name__ == '__main__':
    main()
