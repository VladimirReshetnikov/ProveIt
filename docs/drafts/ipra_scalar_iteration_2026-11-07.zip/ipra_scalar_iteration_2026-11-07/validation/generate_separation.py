"""Build the retained-base separating theorem without an inherited compiler.

The goal is D_{w,x}(x = S0), with unused first witness w. Its DI base
assumption is 0 = S0. Put s = Sz and C(n,a,b)=R(n,a;u,v.b).

From 0=S0, transport C(0,s,S0)=s to C(S0,s,S0)=s.
Symmetry and C(S0,s,S0)=S0 yield s=S0. No use of the DI induction
hypothesis z=S0 is made. The explicit certificate below contains nine
instruction cells, consumed in the displayed order before reversal.

This builder is untrusted test support. The independent kernel and named
oracle, not this script, determine whether the resulting packet is valid.
"""
from pathlib import Path
import json


def make_packet():
    truth = [0, 0]
    eigen = -1
    successor = [eigen]
    one = [0]
    base = [0, one]
    selected_one = [one, successor, one]
    # A fresh R0 equality used to derive reflexivity of selected_one.
    reflexivity_major = [[0, selected_one, 0], selected_one]
    transported = [selected_one, successor]
    consumption = [
        [0],  # DI: first witness zero; the eigenparameter becomes -1.
        [[selected_one, one], [successor, 1]],  # final transitivity
        [],  # C(S0, Sz, S0) = S0, by RS
        [transported, [1, selected_one]],  # symmetry of transported
        [base, [[1, successor, one], successor]],  # transport 0=S0
        [],  # C(0, Sz, S0) = Sz, by R0
        [reflexivity_major, [1, selected_one]],  # reflexivity bootstrap
        [],  # R0, major
        [],  # R0, minor
    ]
    goal = [[1, one], truth, truth]
    return consumption[::-1] + [goal]


if __name__ == '__main__':
    target = Path(__file__).resolve().parent / 'new_cases/retained_base_separation.json'
    target.parent.mkdir(exist_ok=True)
    target.write_text(json.dumps(make_packet(), indent=2) + '\n')
    print(target)
