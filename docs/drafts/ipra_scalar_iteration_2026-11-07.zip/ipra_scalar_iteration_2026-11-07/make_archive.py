#!/usr/bin/env python3
"""Create a ZIP with sources, PDF, evidence, and per-file SHA-256 checksums.

Run after reproduce.py. Transient TeX files and Python caches are excluded.
The archive is written next to this directory, with its directory name.
"""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent
SUFFIXES = {'.py', '.tex', '.pdf', '.md', '.txt', '.json', '.csv'}
CHECKSUMS = ROOT / 'SHA256SUMS.txt'


def included(path):
    relative = path.relative_to(ROOT)
    if not path.is_file() or any(part.startswith('.') or part == '__pycache__'
                                 for part in relative.parts):
        return False
    return path.suffix in SUFFIXES or (relative.parts[0] == 'results'
                                       and path.suffix == '.log')


def main():
    for required in ('report.pdf', 'report.tex', 'README.md', 'FORMAT.md',
                     'ATTRIBUTION.txt', 'results/reproduction.json'):
        if not (ROOT / required).is_file():
            raise SystemExit('Missing deliverable: ' + required)
    files = sorted((path for path in ROOT.rglob('*')
                    if included(path) and path != CHECKSUMS),
                   key=lambda path: path.relative_to(ROOT).as_posix())
    CHECKSUMS.write_text(''.join(hashlib.sha256(path.read_bytes()).hexdigest()
                               + '  ' + path.relative_to(ROOT).as_posix() + '\n'
                               for path in files))
    files.append(CHECKSUMS)
    target = ROOT.with_suffix('.zip')
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in sorted(files, key=lambda item: item.relative_to(ROOT).as_posix()):
            name = ROOT.name + '/' + path.relative_to(ROOT).as_posix()
            entry = zipfile.ZipInfo(name, date_time=(2026, 11, 7, 0, 0, 0))
            entry.create_system = 3
            entry.external_attr = 0o100644 << 16
            entry.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(entry, path.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(target) as archive:
        failure = archive.testzip()
        if failure is not None:
            raise SystemExit('Archive CRC failure: ' + failure)
    print(f'{target.name}: {len(files)} files, {target.stat().st_size} bytes')
    print('SHA256 ' + hashlib.sha256(target.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
