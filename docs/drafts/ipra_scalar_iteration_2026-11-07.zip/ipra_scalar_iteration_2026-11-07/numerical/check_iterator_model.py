#!/usr/bin/env python3
"""Finite implementation evidence, not a machine proof of the metatheorems."""
import json
import math
from pathlib import Path
from iterator_model import Model


def main():
    counts = {}
    witnesses = {}

    literal = Model(memoize=False)
    literal_checks = 0
    for n in range(3):
        for actual, expected in [(literal.N(n), n % 2),
                                 (literal.M(n), n % 3),
                                 (literal.G(n), (3*n)//2),
                                 (literal.P(n), max(0, n-1))]:
            assert actual == expected
            literal_checks += 1
    counts['literal_bootstrap_checks'] = literal_checks

    core = Model(memoize=True)
    core_checks = 0
    for n in range(257):
        expected_h = (3*n)//2 if n % 2 == 0 else n
        for actual, expected in [(core.N(n), n % 2),
                                 (core.M(n), n % 3),
                                 (core.G(n), (3*n)//2),
                                 (core.H(n), expected_h),
                                 (core.G(3*n), 3*core.G(n)+core.N(n)),
                                 (core.H(3*n), 3*core.H(n))]:
            assert actual == expected
            core_checks += 1
    for x in range(10):
        for y in range(10):
            assert core.T(x+1, y+1) == 3*core.T(x, y)
            assert core.c(x, y) == (0 if x <= y else 1)
            assert core.c(x, y)*core.c(x, y+1) == core.c(x, y+1)
            guard = core.c(y, x)
            assert core.C(guard, 0, core.g(x, y)) == core.C(guard, 0, x)
            core_checks += 4
    pred_values = [core.P(x) for x in range(11)]
    assert pred_values == [max(0, x-1) for x in range(11)]
    core_checks += 11
    counts['memoized_bootstrap_checks'] = core_checks
    witnesses['P_0_through_10'] = pred_values
    witnesses['c_rows_x_0_through_6_columns_y_0_through_6'] = [
        [core.c(x, y) for y in range(7)] for x in range(7)]
    witnesses['T_5_y_0_through_8'] = [core.T(5, y) for y in range(9)]

    # P is now evaluated by its previously proved defining equations. Without
    # this disclosed reduction, evaluating the literal predecessor at pair
    # codes would require enormous factor-trading intermediate values.
    arithmetic = Model(memoize=True, reduce_predecessor=True)
    arithmetic_checks = 0
    for n in range(81):
        assert arithmetic.root(n) == math.isqrt(n)
        arithmetic_checks += 1
    for x in range(5):
        for y in range(5):
            code = arithmetic.J(x, y)
            assert arithmetic.left(code) == x
            assert arithmetic.right(code) == y
            arithmetic_checks += 2
    compiled_examples = []
    examples = [
        ('successor_accumulation', 4, 3,
         lambda old, counter: arithmetic.S(old),
         lambda old, counter: old+1),
        ('counter_sum', 4, 0,
         lambda old, counter: arithmetic.add(old, counter),
         lambda old, counter: old+counter),
        ('factorial', 4, 1,
         lambda old, counter: arithmetic.mul(old, arithmetic.S(counter)),
         lambda old, counter: old*(counter+1)),
        ('counter_copy', 4, 0, lambda old, counter: counter,
         lambda old, counter: counter),
    ]
    for name, count, seed, update, oracle in examples:
        expected = seed
        for counter in range(count):
            expected = oracle(expected, counter)
        actual = arithmetic.primitive_recursion(count, seed, update)
        assert actual == expected
        compiled_examples.append({'name': name, 'counter': count,
                                  'seed': seed, 'result': actual})
        arithmetic_checks += 1
    counts['post_predecessor_arithmetic_checks'] = arithmetic_checks
    witnesses['compiled_primitive_recursions'] = compiled_examples

    result = {
        'status': 'all finite checks passed',
        'scope': 'Numerical evidence only; internal proofs are in the paper.',
        'modes': {
            'literal': 'All definitions use scalar I; no cache or P rewrite.',
            'memoized_bootstrap': 'Exact orbit-prefix memoization; no P rewrite.',
            'post_predecessor': 'Orbit memoization plus the proved P equations.'
        },
        'counts': counts,
        'total_checks': sum(counts.values()),
        'witnesses': witnesses,
        'telemetry': {'literal': literal.telemetry(),
                      'memoized_bootstrap': core.telemetry(),
                      'post_predecessor': arithmetic.telemetry()},
        'counter_access': 'The I update receives only previous state. PR counters are decoded from paired states.',
    }
    target = Path(__file__).with_name('iterator_results.json')
    target.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
