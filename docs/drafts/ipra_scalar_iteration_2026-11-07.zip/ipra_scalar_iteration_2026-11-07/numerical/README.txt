SCALAR ITERATOR NUMERICAL EVIDENCE

Run with Python 3.10 or later (standard library only):
    python3 check_iterator_model.py

iterator_model.py implements the report's fixed terms C, Z, sg, addition,
multiplication, powers of two, N, j, M, G, H, T, c, q, g, f, P, monus,
bounded root search, pairing projections, and the primitive-recursion compiler.
The update supplied to I receives exactly one argument: the previous value.
Its Python iteration count controls how many steps are executed and is never
made available to the update. The compiler recovers its previous counter
from the paired state by the proved numerical projection terms.

Three evaluation modes are disclosed separately in iterator_results.json:

1. Literal bootstrap: definitions are evaluated by ordinary scalar iteration,
   with no cache and no shortcut for predecessor. The finite checks cover
   N, M, G, and P at 0, 1, and 2.

2. Prefix-memoized bootstrap: exact prefixes of fixed iterator orbits are
   retained and reused. This changes evaluation cost only, not any function's
   definition. There is no predecessor shortcut. Checks include N, M, G, H,
   scaling identities, T's diagonal identity, the control term, the guarded
   prefix invariant, and P through argument 10.

3. Post-predecessor arithmetic: the already-proved equations P(0)=0 and
   P(Sx)=x are used as an explicit evaluator rewrite. This avoids enormous
   intermediate values when predecessor is called at large pairing codes.
   All subsequent numerical term definitions still use scalar iteration.
   Checks cover bounded square-root search, both pairing projections, and
   compilation of successor accumulation, counter summation, factorial, and
   counter-copy recursions. Their compiled updates use the derived arithmetic
   methods; separate ordinary Python operations provide the expected values.

These 2100 finite checks are implementation evidence, not a mechanized proof
of the mathematical theorems. The internal proofs in the LaTeX report apply
to all arguments, including nonstandard counters. These scripts are not part
of the measured proof checker's trusted acceptance program.
