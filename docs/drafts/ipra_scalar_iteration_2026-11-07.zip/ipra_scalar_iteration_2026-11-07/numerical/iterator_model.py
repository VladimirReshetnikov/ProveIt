#!/usr/bin/env python3
"""Executable scalar-iterator definitions used in the mathematical report.

Every object-language update passed to I receives ONE argument: previous value.
Python loop counters implement iteration, but are never passed to an update.

Memoization stores exact prefixes of fixed orbits; it introduces no arithmetic
oracle. The optional reduce_predecessor mode uses the proved P(0)=0, P(Sx)=x
rewrite to make the subsequent pairing/compiler experiments feasible. It is
reported separately from literal and prefix-memoized bootstrap evaluation.
"""
from collections import Counter


class Model:
    def __init__(self, memoize=True, reduce_predecessor=False):
        self.memoize = memoize
        self.reduce_predecessor = reduce_predecessor
        self.orbits = {}
        self.stats = Counter()

    @staticmethod
    def S(value):
        return value + 1

    def I(self, count, seed, update, key=None):
        """Iterate a fixed update; its sole input is the previous state."""
        if type(count) is not int or count < 0:
            raise ValueError("The iteration count must be a natural number")
        self.stats['iterator_calls'] += 1
        if self.memoize and key is not None:
            orbit = self.orbits.setdefault(key, [seed])
            if orbit[0] != seed:
                raise ValueError("A memoization key changed its seed")
            while len(orbit) <= count:
                orbit.append(update(orbit[-1]))
                self.stats['executed_update_steps'] += 1
            self.stats['cached_orbit_queries'] += 1
            return orbit[count]
        state = seed
        for _ in range(count):
            state = update(state)
            self.stats['executed_update_steps'] += 1
        return state

    def C(self, count, first, second):
        return self.I(count, first, lambda previous: second,
                      ('C', first, second))

    def Z(self, value):
        return self.C(value, 1, 0)

    def sg(self, value):
        return self.C(value, 0, 1)

    def add(self, first, second):
        return self.I(second, first, self.S)

    def mul(self, first, second):
        return self.I(second, 0, lambda previous: self.add(previous, first))

    def square(self, value):
        return self.mul(value, value)

    def E2(self, count):
        return self.I(count, 1, lambda previous: self.add(previous, previous),
                      ('E2',))

    def N(self, count):
        return self.I(count, 0, self.Z, ('N',))

    def j(self, previous):
        return self.add(self.Z(previous), self.mul(2, self.N(previous)))

    def M(self, count):
        return self.I(count, 0, self.j, ('M',))

    def G(self, count):
        return self.I(count, 0,
                      lambda previous: self.S(self.add(previous,
                                                       self.M(previous))),
                      ('G',))

    def H(self, previous):
        return self.C(self.N(previous), self.G(previous), previous)

    def T(self, first, second):
        return self.I(second, self.E2(first), self.H, ('T', first))

    def c(self, first, second):
        return self.Z(self.N(self.T(first, second)))

    def q(self, fixed_bound, previous):
        return self.C(self.c(fixed_bound, previous), 0, self.S(previous))

    def g(self, count, fixed_bound):
        return self.I(count, 0,
                      lambda previous: self.q(fixed_bound, previous),
                      ('g', fixed_bound))

    def f(self, count, fixed_bound):
        return self.I(count, fixed_bound,
                      lambda previous: self.q(fixed_bound, previous),
                      ('f', fixed_bound))

    def P(self, value):
        if self.reduce_predecessor:
            self.stats['proved_predecessor_rewrites'] += 1
            return 0 if value == 0 else value - 1
        return self.f(value, value)

    def d(self, first, second):
        return self.I(second, first, self.P, ('d', first))

    def ell(self, first, second):
        return self.Z(self.d(first, second))

    def root(self, value):
        def advance(previous):
            candidate = self.S(previous)
            allowed = self.ell(self.square(candidate), value)
            return self.C(allowed, previous, candidate)
        return self.I(value, 0, advance, ('root', value))

    def J(self, first, second):
        return self.add(self.square(self.add(first, second)), first)

    def left(self, state):
        return self.d(state, self.square(self.root(state)))

    def right(self, state):
        return self.d(self.root(state), self.left(state))

    def primitive_recursion(self, count, seed, update):
        """Compile a two-input PR update to one-input scalar iteration.

        update(previous_value, previous_counter) receives a decoded counter,
        never the host loop counter. The callback supplied to I below has one
        argument, state, which encodes (counter, value).
        """
        def step(state):
            old_counter = self.left(state)
            old_value = self.right(state)
            return self.J(self.S(old_counter), update(old_value, old_counter))
        state = self.I(count, self.J(0, seed), step)
        return self.right(state)

    def telemetry(self):
        result = dict(self.stats)
        result['memoized_orbits'] = len(self.orbits)
        result['memoized_states'] = sum(map(len, self.orbits.values()))
        return result
