#!/usr/bin/env python3
"""Reproduce measurements and finite evidence; optionally rebuild the PDF.

Run from any directory. The primary and companion checkers are never modified.
Only Python's standard library is needed unless --pdf is requested.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'results'
FROZEN = {
    'checker.py': '3dadda1d10cf3b4d232f9f68f0719261f1c5b89f6e0793846293c7db3c48f849',
    'checker_depth.py': 'b1451007ffaee86fa535f44d0b8837c90c9ccd1867aa9bdac8f396173ac667e3',
}


def run(name, arguments):
    print(f'{name}: running', flush=True)
    environment = os.environ.copy()
    environment.pop('PYTHONOPTIMIZE', None)
    environment['PYTHONDONTWRITEBYTECODE'] = '1'
    began = time.monotonic()
    result = subprocess.run(arguments, cwd=ROOT, env=environment,
                            text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT)
    log = RESULTS / (name + '.log')
    log.write_text(result.stdout, encoding='utf-8')
    if result.returncode:
        print(result.stdout, end='')
        raise SystemExit(f'{name} failed; see {log.relative_to(ROOT)}')
    print(f'{name}: PASS', flush=True)
    return {'status': 'PASS', 'log': str(log.relative_to(ROOT)),
            'elapsed_seconds': round(time.monotonic() - began, 3)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pdf', action='store_true',
                        help='also compile report.tex with pdfLaTeX')
    args = parser.parse_args()
    RESULTS.mkdir(exist_ok=True)
    for name, expected in FROZEN.items():
        actual = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
        if actual != expected:
            raise SystemExit(f'Frozen kernel changed: {name}')
    if platform.python_version() != '3.12.14':
        print('Note: exact published ast.unparse measurements used CPython 3.12.14.')
    steps = {}
    steps['measurements'] = run('measurements', [sys.executable, '-B', 'comparison/measure.py'])
    steps['checker_validation'] = run('checker_validation', [sys.executable, '-B', 'validation/verify.py'])
    steps['numerical'] = run('numerical', [sys.executable, '-B', 'numerical/check_iterator_model.py'])
    if args.pdf:
        steps['pdf'] = run('pdf', [sys.executable, '-B', 'build_pdf.py'])
    summary = {'status': 'PASS', 'python': platform.python_version(),
               'frozen_kernel_sha256': FROZEN, 'steps': steps,
               'limits': 'Finite executable evidence, not a mechanization of the report metatheory.'}
    (RESULTS / 'reproduction.json').write_text(json.dumps(summary, indent=2) + '\n')
    print('All requested reproduction steps passed.')


if __name__ == '__main__':
    main()
