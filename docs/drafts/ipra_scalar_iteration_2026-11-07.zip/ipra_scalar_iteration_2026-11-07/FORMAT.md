# Scalar-iterator proof packet format

This document specifies the public JSON interface of `checker.py` and `checker_depth.py`. Both programs check the same native calculus. Their only implementation difference is how paired introduction protects its remaining inner variable while substituting the outer witness.

## 1. Packet and verdict

A packet is a JSON array:

```text
[instruction_N, ..., instruction_2, instruction_1, closed_goal]
```

The checker removes the final element as its goal. It then consumes instructions from the end, so `instruction_1` is read first. Subproofs are checked depth first. A goal already present in the current logical context closes immediately and consumes **no** instruction.

The initial logical context is empty. There is no assumption header, free-parameter header, rule table, or imported arithmetic compiler. The root goal must be a closed native formula. Unread prefix elements are permitted as inert data and do not supply assumptions. Canonical generators consume every instruction.

Run:

```sh
python3 checker.py proof.json
```

Acceptance prints `ACCEPT` and exits with status 0. Rejection prints `REJECT` and exits with status 1. The same interface applies to `checker_depth.py`. Syntax errors, failed endpoint comparisons, unavailable instructions, and exceptions all reject. Resource-limited rejection does not establish that the goal is underivable.

The arrays of named records in `validation/new_cases/*.json` are test collections. A record has fields such as `name`, `packet`, `expected`, and `explanation`; only its `packet` array is input to the public checker.

## 2. Two sorts share JSON arrays

The surrounding context determines whether an array is a numerical term or a formula. There are no string tags.

### Numerical terms

| JSON | Meaning | Binding |
|---|---|---|
| `0` | Numerical zero | None |
| A permitted negative integer | A rigid numerical parameter name | None; it is a variable, not a negative number |
| A permitted positive integer | A bound numerical coordinate | Nearest enclosing numerical binder first |
| `[t]` | Successor `S(t)` | None |
| `[n,a,h]` | Scalar iterator `I(n,a;u.h)` | One variable `u`, in `h` only |

The iterator's counter term `n` and initializer `a` are outside the update binding. Its body `h` receives the previous iterator value, and only that value. There is no second update binder for the previous counter. Terms may use any fixed parameters already in scope.

Numerals are successor trees: `0`, `[0]`, `[[0]]`, and so on. JSON integer `1` is a variable coordinate; it is not the numeral one. JSON integer `2` is also a variable coordinate, not the numeral two.

### Formulas

| JSON | Meaning | Binding |
|---|---|---|
| `[s,t]` | Equality `s = t` | None |
| `[B]` | Closure `Q_x B` | One numerical variable `x`, in `B` |
| `[B,P1,P2]` | Paired binder `D_{x,y} B` | Two numerical variables, in all three formula fields |

The intended ordinary readings are `Q_x B = (B(0) -> forall x B(x))` and `D_{x,y} B = exists x (B(x,0) -> forall y B(x,y))`. These explain the native constructors; the public checker does not parse ordinary logical connectives.

In a paired formula, `y` is nearest and `x` is next. The first field `B` is its mathematical matrix. `P1` and `P2` are semantically inert formula annotations, but both are fully syntax-checked under the same two binders. Canonical certificates use `[0,0]` for each annotation. They are not arbitrary unchecked padding.

An equation has an outer array of length two. A formula with outer length one or three is compound even if its body is an equation. Only a literal equation receives an induction hypothesis in paired introduction.

Empty arrays are not terms or formulas. An empty array can be a computation instruction. Other formula/term arities, strings, objects, booleans, `null`, and floating-point numerical leaves are invalid wherever used as syntax. An explicitly unused annotation or unread packet cell can contain inert JSON data, as described below.

## 3. Coordinates and scopes

The paired positive spellings `2j-1` and `2j` both refer to the `j`-th nearest numerical binder. Canonical certificates use the odd spelling.

| Positive coordinate | Bound variable |
|---|---|
| `1` or `2` | Nearest numerical binder |
| `3` or `4` | Second nearest numerical binder |
| `5` or `6` | Third nearest numerical binder |

For example:

```text
[[[0],0,[1]], [[0,0,[1]]]]
```

is the equation `I(S0,0;u.Su) = S(I(0,0;u.Su))`. Each `1` is bound by its own iterator update. The zero initializer and the successor-shaped counter have no update binder over them.

Inside the update of an iterator nested beneath `D_{x,y}`, the variables are ordered `u`, `y`, `x`. Thus coordinates `1`, `3`, and `5` denote `u`, `y`, and `x` respectively. In the initializer of that same iterator, the order is still `y`, `x`, since the update binding does not cover the initializer.

A second update binder does not exist merely because coordinate `3` appears in an update. Coordinate `3` is valid there only when a surrounding numerical binder supplies it. In a closed, unnested iterator update, only `1` and `2` are bound.

Raw endpoint comparisons and context membership use JSON-tree equality. The checker does not normalize different positive spellings to a common spelling. Both spellings have the stated binding interpretation, but arbitrary mixing can fail a literal endpoint comparison. The completeness claim uses canonical odd coordinates.

### Rigid names and freshness

The program maintains a global name floor `k`, initially zero. A rigid negative name is admitted only if it is at least `k`. Each eigenparameter allocation decreases `k` by one, introducing `-1`, then `-2`, and so forth. The floor never increases, including between sibling subproofs, so a newly allocated name cannot occur in fixed data already validated against the earlier floor.

The initial closed goal therefore cannot contain any negative name or unbound positive coordinate. Used negative names in later instructions refer to rigid parameters already allocated during the proof traversal. Discharged assumptions do not survive into unrelated sibling contexts.

### Exact opening operation

`inst(a, *env, d=0)` combines syntax validation and capture-avoiding opening. Write `d = 2b+s`, with `b` protected numerical binders and sort bit `s` (`0` for formula, `1` for term). The child increments are:

| Requested sort | Constructor | Increments added to `d` for its children |
|---|---|---|
| Formula | `[B]` | `(2)` |
| Formula | `[s,t]` | `(1,1)` |
| Formula | `[B,P1,P2]` | `(4,4,4)` |
| Term | `[t]` | `(0)` |
| Term | `[n,a,h]` | `(0,0,2)` |

An integer is permitted only at term sort and only if it is at least the current floor `k`. An admitted integer below `d` is unchanged. Otherwise the image is taken from slot `(a-d)//2` of `env`. Every **used** image is separately validated at term depth zero (`d=1`) with no further opening environment before insertion. This prevents a free coordinate in the image from being captured by a binder at its insertion site. Missing images and ill-formed used images reject.

If a substitution variable never occurs, its image is never read. Such an unused instruction annotation may be inert data; it can be replaced by zero when decoding the proof mathematically. This does not exempt an iterator's update body, or a paired formula's two annotation fields, from full syntax validation. Those are actual children of the syntax tree and are always traversed.

## 4. Instructions

There are three instruction shapes. Their interpretation is determined by the already validated goal and, for a two-field instruction, its proved major formula. There is no instruction for a hypothesis leaf.

### `[]`: one direct computation

The goal must be an equation whose left side is an iterator:

```text
[[n,a,h], b]
```

If `n` is integer zero, the right side must be exactly `a`. If `n` is `[m]`, the right side must be exactly `h` with its previous-value variable replaced by `[m,a,h]`. This is one application of `I0` or `IS`; the checker does not automatically evaluate the resulting expression or close arbitrary reflexive equations.

The entire goal, including an unused update at counter zero, is validated before the instruction is interpreted. Thus malformed or unbound update syntax cannot be hidden behind the zero equation.

### `[t]`: paired introduction

The current goal must be `[B,P1,P2]`, representing `D_{x,y} B(x,y)`. The annotation `t` supplies the witness for the outer variable `x`. After substituting `t` while protecting the remaining variable `y`, call the resulting matrix `b(y)`.

Allocate a fresh rigid name `z`. Prove `b(Sz)` in the original retained context, additionally assuming `b(0)`. If and only if `b` is literally an equation, additionally assume `b(z)`. The kernel's actual list order is the induction hypothesis followed by the retained base; the logical context is reusable. These local assumptions are discharged by the rule.

The primary implements the partial opening as `b, = inst([b], t)`. The companion uses `b = inst(b, t, d=2)`. Both protect exactly the inner variable and validate every used witness image at its own depth zero.

### `[m,t]`: elimination or equality transport

First prove the major formula `m` in the original context. Instructions for that subproof are consumed before instructions for the continuation. Its outer constructor selects the operation:

| Major `m` | Role of `t` | Remaining obligation |
|---|---|---|
| `[s,r]`, an equation | A formula motive `F(w)` with one open numerical slot | The goal must be exactly `F(r)`; prove `F(s)` |
| `[B]`, a closure | A numerical instance term | The goal must be exactly `B(t)`; prove `B(0)` |
| `[B,P1,P2]`, a paired formula | Unused annotation; canonical value `null` | Allocate fresh `a`, retain `Q_y B(a,y)`, and prove the original goal |

The motive's open slot is encoded by coordinates `1` or `2` at its outer level, increasing beneath its own binders. Endpoint opening validates its complete used syntax. In paired elimination, the retained closure permits repeated instantiation with the **same** fresh witness `a`; it is not replaced by a single chosen matrix instance. The fresh witness is absent from the goal, original context, and previously validated fixed data.

## 5. Exact accepted examples from the staged corpus

The examples below are copied as complete packets from `validation/new_cases/all_cases.json`. The stated verdicts are checked for both public kernels, including normal and optimized Python execution in the supplied validation run.

### A direct scalar successor computation

Source case: `declared/033_recursion_nested_update_0.json`.

```json
[[],[[[0],0,1],[0,0,1]]]
```

Verdict: `ACCEPT`. This is the single computation equation `I(S0,0;u.u) = I(0,0;u.u)`. The final cell is the goal; the preceding empty cell supplies its computation instruction.

The newly generated `previous_alias_2` case uses the alternate spelling of the same bound coordinate:

```json
[[],[[[0],0,2],[0,0,2]]]
```

Verdict: `ACCEPT`.

### Reflexivity derived by transport

Source case: `declared/007_rigid_reflexivity_1.json`.

```json
[[],[],[[[0,0,0],0],[1,0]],[0,0]]
```

Verdict: `ACCEPT`. Let `r = I(0,0;u.0)`. The first consumed instruction is `[[r,0],[1,0]]`: prove `r=0`, then use the motive `w=0`. Both required instances are direct copies of the computation equation `r=0`. This derives the final goal `0=0`; no primitive reflexivity instruction is used.

### Paired introduction and a surrounding formula variable

New source case: `formula_variable_beneath_iterator`.

```json
[[],[0],[[[0,0,3],0],[0,0],[0,0]]]
```

Verdict: `ACCEPT`. The goal is `D_{x,y}(I(0,0;u.y)=0)`. The outer witness is zero. Within the iterator body, coordinate `3` denotes the surrounding `y`; the nearest coordinate is the iterator's `u`. The successor premise is a zero computation.

New source case: `first_formula_variable_beneath_iterator`.

```json
[[],[[0]],[[[0,3,5],3],[0,0],[0,0]]]
```

Verdict: `ACCEPT`. This is `D_{x,y}(I(0,x;u.x)=x)`, with witness `S0` for `x`. In the initializer, coordinate `3` is `x`; inside the update, coordinate `5` is `x`. This example checks the differing scopes of an iterator's initializer and update.

### A genuinely nested iterator update

New source case: `nested_outer_previous`.

```json
[[],[[[0],[0],[[0],1,3]],[[0],[0,[0],[[0],1,3]],[0,[0],[[0],1,3]]]]]
```

Verdict: `ACCEPT`. In the inner update, coordinate `3` denotes the outer iterator's previous value. Opening the outer successor step replaces that occurrence and the inner initializer's coordinate `1` with the same previous outer iterator term. The inner update retains its own single binder.

## 6. Exact rejected examples from the staged corpus

| Case name | Complete packet | Reason |
|---|---|---|
| `nonexistent_counter_slot` | `[[],[[0,0,3],0]]` | No second binder exists in this closed scalar update |
| `nonexistent_counter_alias` | `[[],[[0,0,4],0]]` | The alternate spelling also lacks a binder |
| `future_parameter_in_unused_update` | `[[],[[0,0,-1],0]]` | The root mentions an unallocated rigid name, even though the update would not be evaluated |
| `boolean_in_unused_update` | `[[],[[0,0,true],0]]` | A Boolean is not an integer term |
| `false_zero_equation` | `[[],[[0,[0],1],0]]` | The zero computation returns initializer `[0]`, not `0` |
| `nested_unbound_coordinate` | `[[],[[0,0,[0,1,5]],0]]` | Only two binders cover the nested update; coordinate `5` needs a third |

Each verdict is `REJECT`. They are syntactic or proof-specific rejections; a rejection generally does not decide the underlying theorem relation.

The new `scalar_contextual_capture` attack is also rejected:

```json
[[],[],[[[0,[[-1],0,[-1]],0],[[-1],0,[-1]]],[1,[[-1],0,[-1]]]],[3],[[[1,0,5],[1,0,3]],[0,0],[0,0]]]
```

Its goal expresses `D_{x,y} G_y(x=y)`: the zero-gated matrix is true, but no number equals every successor. The proposed witness coordinate `3` is not locally closed at its own insertion boundary. An intentionally incorrect implementation that validates the witness at the surrounding protected depth captures that coordinate and accepts the attack. Both delivered kernels and the independent named-binder oracle reject it.

## 7. Validation boundary

`validation/verify.py` tests these packets and the larger frozen corpus against an independently organized named-binder oracle. It also checks scalar opening against an embedding into the unchanged source binary-recursor checker, tests mutations, and makes actual public command-line calls. None of this test machinery is imported by either acceptance program.

The report supplies the general soundness argument and canonical serialization theorem. It also supplies the general arithmetic translation from two-variable primitive recursion to scalar iteration. The finite transporter in `validation/transport_counter_free.py` has the narrower, explicitly stated purpose of moving source certificates whose counter binder is unused; it is not an implementation of the general arithmetic translation.
