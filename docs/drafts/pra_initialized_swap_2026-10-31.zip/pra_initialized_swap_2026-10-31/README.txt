PRA WITH ONE UPDATE CONSTRUCTOR
Research report prepared for Vladimir Reshetnikov, 31 October 2026

MAIN RESULT
The initialized swap-recursion basis in specification.txt is bi-interpretable
and equiconsistent with ordinary first-order PRA, separately in classical
and intuitionistic logic. The interpretations use the whole domain and native
equality, with identity round-trip isomorphisms. A common conservative
definitional extension is proved in the paper.

The computation constructor has one arbitrary update term h:
  R_h(0,a,b_vec) = a
  R_h(Sn,a,b_vec) = h(n,a,b_vec,R_h(a,n,b_vec)).
The arithmetic ingredients are one fixed positive sentence and the
stationary-separation schema. The matched one-parameter display count is
52 versus 54 in the current substitution-descent draft. This is not a claim
of an absolute minimum or a shortest complete binary encoding.

READ FIRST
  pra_initialized_swap.pdf       Complete 16-page report.
  specification.txt             Complete concise axiomatization.

SOURCE
  pra_initialized_swap.tex       Main LaTeX source.
  swap_compiler.tex              Ordinary PR compiler and internal uniqueness.
  finite_cover.tex               Countermodel to deleting the equality bridge.

CHECKED ARTIFACTS
  formal/InitializedSwap.lean    Constructive arbitrary-carrier Lean kernel.
  formal/InitializedSwap.log     Successful Lean 4.19.0 output; 14 empty axiom audits.
  formal/SCOPE.txt               Precise scope and explicit assumptions.
  artifacts/schema_metrics.py   Exact syntax-tree counts.
  artifacts/schema_metrics.json Reproduced counts and program-body costs.
  artifacts/check_constructions.py
                                Finite checks of both compilers and helpers.
  artifacts/construction_checks.json
                                Check results, including a detected bad compiler.
  artifacts/program_descriptions.json
                                Exact descriptor and term specification.
  audit/source_manifest.json    Pinned repository snapshot and source hashes.
  audit/validation.json         Build, verification, and visual-review record.
  SHA256SUMS                   Checksums of every other packaged file.

REBUILD
With Python 3 and a TeX Live installation containing the packages used by
the source:
  python3 build.py
The script reruns the diagnostics and compiles the PDF in a temporary
directory. It writes the final PDF beside the source.

To check the certificate with Lean 4.19.0 (no Mathlib needed):
  lean formal/InitializedSwap.lean
Or run the build with:
  python3 build.py --lean /absolute/path/to/lean

SCOPE
The full first-order syntax, reverse compiler, and bi-interpretation theorem
are proved in the written report, not in one end-to-end Lean theorem. The
Lean kernel uses a semantic stationarity interface; its uses correspond to
the explicit finite term instances listed in the paper. Empty global Lean
axiom dependencies do not remove the theorem's explicit Basis hypotheses.
Finite Python diagnostics are implementation checks, not universal proofs.

COMPARISON SNAPSHOT
VladimirReshetnikov/ProveIt
392757d09455930d2b090b26bd1537799451c91a
All six current docs/drafts archives were checked. The docs/incoming
inventory and complete README had no additional PRA-labelled material.
No repository files were changed.
