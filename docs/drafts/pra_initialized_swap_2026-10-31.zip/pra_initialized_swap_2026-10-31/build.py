#!/usr/bin/env python3
"""Reproduce diagnostics and the report; optionally check the Lean kernel."""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--lean', help='Path to Lean 4.19.0 executable')
    args=parser.parse_args()
    root=Path(__file__).resolve().parent
    for name in ('schema_metrics.py','check_constructions.py'):
        result=subprocess.run([sys.executable,str(root/'artifacts'/name)],
                              cwd=root,text=True,capture_output=True)
        if result.returncode:
            print(result.stdout); print(result.stderr,file=sys.stderr)
            raise SystemExit(result.returncode)
        print(name+': passed')
    latex=shutil.which('pdflatex')
    if not latex: raise SystemExit('pdflatex is required to build the PDF.')
    with tempfile.TemporaryDirectory(prefix='pra_swap_build_') as temp:
        out=Path(temp)
        for _ in range(3):
            result=subprocess.run([latex,'-interaction=nonstopmode','-halt-on-error',
                '-output-directory='+str(out),'pra_initialized_swap.tex'],
                cwd=root,text=True,capture_output=True)
            if result.returncode:
                print(result.stdout); print(result.stderr,file=sys.stderr)
                raise SystemExit(result.returncode)
        log=(out/'pra_initialized_swap.log').read_text()
        defects=[line for line in log.splitlines() if any(t in line for t in
            ('Overfull','Underfull','undefined references','Undefined control','Missing character'))]
        if defects: raise SystemExit('\n'.join(defects))
        shutil.copy2(out/'pra_initialized_swap.pdf',root/'pra_initialized_swap.pdf')
        (root/'audit'/'latex_build.log').write_text(log)
    print('pra_initialized_swap.pdf: built')
    if args.lean:
        result=subprocess.run([args.lean,'formal/InitializedSwap.lean'],cwd=root,
                              text=True,capture_output=True)
        print(result.stdout,end='')
        if result.returncode:
            print(result.stderr,file=sys.stderr)
            raise SystemExit(result.returncode)
        lines=result.stdout.splitlines()
        audits=[line for line in lines if 'does not depend on any axioms' in line]
        if len(audits)!=14: raise SystemExit('Expected fourteen empty axiom audits.')
        print('Lean kernel: passed; 14 empty axiom audits')

if __name__=='__main__': main()
