/-
Constructive kernel for PRA from initialized swap recursion.

The carrier is arbitrary.  No induction principle on that carrier, decidable
equality instance, classical reasoning, choice, or admitted proof is used.

Scope: the stationary-separation field has a semantic function interface.
It is stronger in form than the paper's first-order term schema.  Every use
below is a finite term-shaped instance: constant terms; the diagonal monitor;
an equality-bit monitor of a stationary term; and the shifted latch through
the derived constancy lemma.  Numerical parameters can remain fixed inside
these functions.  This file does not formalize the description grammar,
first-order proof syntax, reverse recursion compiler, or bi-interpretations.

The predecessor is the term near(x, zero); it requires no separate program.
The helper ofSeededEquations derives both predecessor equations directly
from the initialized swap equations of near.  The three selected programs
are near, select, and trans; their equations are computation instances.
-/

universe u

namespace PRAInitializedSwap

structure Basis (α : Type u) where
  zero : α
  succ : α → α
  pred : α → α
  select : α → α → α → α
  near : α → α → α
  trans : α → α → α
  pred_zero : pred zero = zero
  pred_succ : ∀ n, pred (succ n) = n
  select_zero : ∀ a b, select zero a b = a
  select_succ : ∀ n a b, select (succ n) a b = b
  near_zero : ∀ a, near zero a = a
  near_succ : ∀ n a, near (succ n) a = near a n
  trans_zero : ∀ a, trans zero a = a
  trans_succ : ∀ n a,
    trans (succ n) a =
      select (near a n) (select (near n a) a zero) a
  off : ∀ x y, trans x y = y ∨ x = y
  stationarySeparation : ∀ f : α → α,
    (∀ n, f (succ n) = f n) → ∀ n, succ (f n) ≠ f zero

def ofSeededEquations {α : Type u}
    (zero : α) (succ : α → α)
    (select : α → α → α → α) (near trans : α → α → α)
    (Czero : ∀ a b, select zero a b = a)
    (Csucc : ∀ n a b, select (succ n) a b = b)
    (Dzero : ∀ a, near zero a = a)
    (Dsucc : ∀ n a, near (succ n) a = near a n)
    (Tzero : ∀ a, trans zero a = a)
    (Tsucc : ∀ n a,
      trans (succ n) a = select (near a n) (select (near n a) a zero) a)
    (off : ∀ x y, trans x y = y ∨ x = y)
    (SS : ∀ f : α → α,
      (∀ n, f (succ n) = f n) → ∀ n, succ (f n) ≠ f zero) : Basis α where
  zero := zero
  succ := succ
  pred := fun n => near n zero
  select := select
  near := near
  trans := trans
  pred_zero := Dzero zero
  pred_succ := fun n => (Dsucc n zero).trans (Dzero n)
  select_zero := Czero
  select_succ := Csucc
  near_zero := Dzero
  near_succ := Dsucc
  trans_zero := Tzero
  trans_succ := Tsucc
  off := off
  stationarySeparation := SS

namespace Basis

variable {α : Type u} (B : Basis α)

abbrev one : α := B.succ B.zero

theorem succ_ne_self (x : α) : B.succ x ≠ x :=
  B.stationarySeparation (fun _ => x) (fun _ => rfl) B.zero

theorem one_ne_zero : B.one ≠ B.zero := B.succ_ne_self B.zero

theorem zero_ne_one : B.zero ≠ B.one := by
  intro h
  exact B.one_ne_zero h.symm

theorem succ_injective {x y : α} (h : B.succ x = B.succ y) : x = y :=
  (B.pred_succ x).symm.trans ((congrArg B.pred h).trans (B.pred_succ y))

theorem succ_ne_zero (x : α) : B.succ x ≠ B.zero := by
  intro h
  have hx : x = B.zero :=
    (B.pred_succ x).symm.trans ((congrArg B.pred h).trans B.pred_zero)
  exact B.one_ne_zero ((congrArg B.succ hx).symm.trans h)

theorem select_one (a b : α) : B.select B.one a b = b :=
  B.select_succ B.zero a b

theorem trans_one_one : B.trans B.one B.one = B.zero := by
  change B.trans (B.succ B.zero) (B.succ B.zero) = B.zero
  rw [B.trans_succ, B.near_succ, B.near_zero, B.near_zero,
    B.select_zero, B.select_succ]

theorem near_diagonal_step (n : α) :
    B.near (B.succ n) (B.succ n) = B.near n n :=
  (B.near_succ n (B.succ n)).trans (B.near_succ n n)

theorem stationary_one (t : α → α)
    (stationary : ∀ n, t (B.succ n) = t n)
    (initial : t B.zero = B.one) : ∀ n, t n = B.one := by
  let g : α → α := fun n => B.select (B.trans (t n) B.one) B.one B.zero
  have gstep : ∀ n, g (B.succ n) = g n := by
    intro n
    exact congrArg (fun d => B.select (B.trans d B.one) B.one B.zero)
      (stationary n)
  have gbase : g B.zero = B.one := by
    change B.select (B.trans (t B.zero) B.one) B.one B.zero = B.one
    rw [initial, B.trans_one_one, B.select_zero]
  intro x
  have hs := B.stationarySeparation g gstep x
  cases B.off (t x) B.one with
  | inl h =>
    have gx : g x = B.zero := by
      change B.select (B.trans (t x) B.one) B.one B.zero = B.zero
      rw [h, B.select_one]
    have bad : B.succ (g x) = g B.zero :=
      (congrArg B.succ gx).trans gbase.symm
    exact False.elim (hs bad)
  | inr h => exact h

theorem near_diagonal_zero (x : α) : B.near x x = B.zero := by
  have hs : ∀ n, B.succ (B.near (B.succ n) (B.succ n)) =
      B.succ (B.near n n) := fun n => congrArg B.succ (B.near_diagonal_step n)
  have hz : B.succ (B.near B.zero B.zero) = B.one :=
    congrArg B.succ (B.near_zero B.zero)
  exact B.succ_injective
    (B.stationary_one (fun n => B.succ (B.near n n)) hs hz x)

theorem near_next_step (n : α) :
    B.near (B.succ n) (B.succ (B.succ n)) = B.near n (B.succ n) :=
  (B.near_succ n (B.succ (B.succ n))).trans (B.near_succ (B.succ n) n)

theorem near_next_one (n : α) : B.near n (B.succ n) = B.one :=
  B.stationary_one (fun j => B.near j (B.succ j)) B.near_next_step
    (B.near_zero B.one) n

theorem trans_successor_diagonal (n : α) :
    B.trans (B.succ n) (B.succ n) = B.zero := by
  rw [B.trans_succ, B.near_succ, B.near_diagonal_zero,
    B.select_zero, B.near_next_one, B.select_one]

def zeroBit (x : α) : α := B.trans (B.succ x) B.one

theorem zeroBit_zero : B.zeroBit B.zero = B.zero := B.trans_one_one

theorem zero_classification (x : α) :
    x = B.zero ∨ B.zeroBit x = B.one := by
  cases B.off (B.succ x) B.one with
  | inl h => exact Or.inr h
  | inr h => exact Or.inl (B.succ_injective h)

theorem zeroBit_of_ne_zero {x : α} (hx : x ≠ B.zero) :
    B.zeroBit x = B.one := by
  cases B.zero_classification x with
  | inl h => exact False.elim (hx h)
  | inr h => exact h

theorem zeroBit_one_iff (x : α) : B.zeroBit x = B.one ↔ x ≠ B.zero := by
  constructor
  · intro h hx
    cases hx
    exact B.one_ne_zero (h.symm.trans B.zeroBit_zero)
  · exact B.zeroBit_of_ne_zero

theorem zero_decision (x : α) : x = B.zero ∨ x ≠ B.zero := by
  cases B.zero_classification x with
  | inl h => exact Or.inl h
  | inr h => exact Or.inr ((B.zeroBit_one_iff x).mp h)

theorem zeroBit_zero_iff (x : α) : B.zeroBit x = B.zero ↔ x = B.zero := by
  constructor
  · intro h
    cases B.zero_classification x with
    | inl hx => exact hx
    | inr hx => exact False.elim (B.one_ne_zero (hx.symm.trans h))
  · intro hx
    cases hx
    exact B.zeroBit_zero

theorem zeroBit_bits (x : α) :
    B.zeroBit x = B.zero ∨ B.zeroBit x = B.one := by
  cases B.zero_classification x with
  | inl hx =>
    cases hx
    exact Or.inl B.zeroBit_zero
  | inr hx => exact Or.inr hx

def choose (z a b : α) : α := B.select (B.zeroBit z) a b

theorem choose_zero (a b : α) : B.choose B.zero a b = a := by
  unfold choose
  rw [B.zeroBit_zero, B.select_zero]

theorem choose_of_zero {z : α} (hz : z = B.zero) (a b : α) :
    B.choose z a b = a := by
  cases hz
  exact B.choose_zero a b

theorem choose_of_ne_zero {z : α} (hz : z ≠ B.zero) (a b : α) :
    B.choose z a b = b := by
  unfold choose
  rw [B.zeroBit_of_ne_zero hz, B.select_one]

theorem choose_same (z a : α) : B.choose z a a = a := by
  cases B.zero_decision z with
  | inl hz => exact B.choose_of_zero hz a a
  | inr hz => exact B.choose_of_ne_zero hz a a

def error (x y : α) : α := B.trans (B.succ x) (B.succ y)

theorem error_zero_iff (x y : α) : B.error x y = B.zero ↔ x = y := by
  constructor
  · intro he
    cases B.off (B.succ x) (B.succ y) with
    | inl ht => exact False.elim (B.succ_ne_zero y (ht.symm.trans he))
    | inr ht => exact B.succ_injective ht
  · intro h
    cases h
    exact B.trans_successor_diagonal x

theorem error_diagonal (x : α) : B.error x x = B.zero :=
  (B.error_zero_iff x x).mpr rfl

theorem error_ne_zero {x y : α} (h : x ≠ y) : B.error x y ≠ B.zero := by
  intro he
  exact h ((B.error_zero_iff x y).mp he)

include B in
theorem equality_decision (x y : α) : x = y ∨ x ≠ y := by
  cases B.zero_decision (B.error x y) with
  | inl h => exact Or.inl ((B.error_zero_iff x y).mp h)
  | inr h =>
    exact Or.inr (fun he => h ((B.error_zero_iff x y).mpr he))

def equalityBit (x y : α) : α := B.choose (B.error x y) B.one B.zero

theorem equalityBit_of_eq {x y : α} (h : x = y) :
    B.equalityBit x y = B.one :=
  B.choose_of_zero ((B.error_zero_iff x y).mpr h) B.one B.zero

theorem equalityBit_of_ne {x y : α} (h : x ≠ y) :
    B.equalityBit x y = B.zero :=
  B.choose_of_ne_zero (B.error_ne_zero h) B.one B.zero

theorem equalityBit_bits (x y : α) :
    B.equalityBit x y = B.zero ∨ B.equalityBit x y = B.one := by
  cases B.equality_decision x y with
  | inl h => exact Or.inr (B.equalityBit_of_eq h)
  | inr h => exact Or.inl (B.equalityBit_of_ne h)

theorem equalityBit_one_iff (x y : α) :
    B.equalityBit x y = B.one ↔ x = y := by
  constructor
  · intro h
    cases B.equality_decision x y with
    | inl he => exact he
    | inr he =>
      exact False.elim (B.one_ne_zero (h.symm.trans (B.equalityBit_of_ne he)))
  · exact B.equalityBit_of_eq

theorem constancy (t : α → α)
    (stationary : ∀ n, t (B.succ n) = t n) : ∀ n, t n = t B.zero := by
  let f : α → α := fun n => B.equalityBit (t n) (t B.zero)
  have fs : ∀ n, f (B.succ n) = f n := by
    intro n
    exact congrArg (fun z => B.equalityBit z (t B.zero)) (stationary n)
  have f0 : f B.zero = B.one := B.equalityBit_of_eq rfl
  intro n
  cases B.equality_decision (t n) (t B.zero) with
  | inl h => exact h
  | inr h =>
    have fn : f n = B.zero := B.equalityBit_of_ne h
    have bad : B.succ (f n) = f B.zero :=
      (congrArg B.succ fn).trans f0.symm
    exact False.elim (B.stationarySeparation f fs n bad)

/- The initialized swap recursor R supplies arbitrary ordinary recursion
   by its delayed diagonal.  G and H may contain fixed parameters. -/
theorem ordinary_recursion_from_swap
    (R : α → α → α) (G : α) (H : α → α → α)
    (_seed : ∀ a, R B.zero a = a)
    (rstep : ∀ n a, R (B.succ n) a =
      B.choose (B.error a n) (R a n)
        (B.choose n G (H (B.pred n) (R a n)))) :
    R B.one B.one = G ∧
    ∀ n, R (B.succ (B.succ n)) (B.succ (B.succ n)) =
      H n (R (B.succ n) (B.succ n)) := by
  have inner (n : α) : R (B.succ n) n = R n n := by
    rw [rstep]
    exact B.choose_of_zero (B.error_diagonal n) (R n n)
      (B.choose n G (H (B.pred n) (R n n)))
  have outer (n : α) : R (B.succ n) (B.succ n) =
      B.choose n G (H (B.pred n) (R n n)) := by
    rw [rstep]
    have he : B.error (B.succ n) n ≠ B.zero :=
      B.error_ne_zero (B.succ_ne_self n)
    rw [B.choose_of_ne_zero he, inner n]
  constructor
  · exact (outer B.zero).trans (B.choose_zero G (H (B.pred B.zero) (R B.zero B.zero)))
  · intro n
    calc
      R (B.succ (B.succ n)) (B.succ (B.succ n)) =
          B.choose (B.succ n) G
            (H (B.pred (B.succ n)) (R (B.succ n) (B.succ n))) := outer (B.succ n)
      _ = H (B.pred (B.succ n)) (R (B.succ n) (B.succ n)) :=
          B.choose_of_ne_zero (B.succ_ne_zero n) G _
      _ = H n (R (B.succ n) (B.succ n)) :=
          congrArg (fun z => H z (R (B.succ n) (B.succ n))) (B.pred_succ n)

/- A quantifier-free formula supplies b and its constructive truth theorem.
   No arbitrary undecidable predicate is asserted to possess such a bit. -/
theorem shifted_latch_induction
    (P : α → Prop) (b r : α → α)
    (bits : ∀ n, b n = B.zero ∨ b n = B.one)
    (truth : ∀ n, P n ↔ b n = B.one)
    (rbase : r B.zero = B.one)
    (rstep : ∀ n, r (B.succ n) = B.select (b n) B.zero (r n))
    (base : P B.zero) (step : ∀ n, P n → P (B.succ n)) :
    ∀ n, P n := by
  have select_same (z : α) (hz : z = B.zero ∨ z = B.one) :
      B.select z B.zero B.zero = B.zero := by
    cases hz with
    | inl h => exact h ▸ B.select_zero B.zero B.zero
    | inr h => exact h ▸ B.select_one B.zero B.zero
  have bbase : b B.zero = B.one := (truth B.zero).mp base
  have shifted_base : r (B.succ B.zero) = B.one := by
    calc
      r (B.succ B.zero) = B.select (b B.zero) B.zero (r B.zero) := rstep B.zero
      _ = B.select B.one B.zero (r B.zero) := congrArg
          (fun z => B.select z B.zero (r B.zero)) bbase
      _ = r B.zero := B.select_one B.zero (r B.zero)
      _ = B.one := rbase
  have shifted_step : ∀ n, r (B.succ (B.succ n)) = r (B.succ n) := by
    intro n
    cases bits n with
    | inl hz =>
      have hn : r (B.succ n) = B.zero := by
        calc
          r (B.succ n) = B.select (b n) B.zero (r n) := rstep n
          _ = B.select B.zero B.zero (r n) := congrArg
              (fun z => B.select z B.zero (r n)) hz
          _ = B.zero := B.select_zero B.zero (r n)
      calc
        r (B.succ (B.succ n)) =
            B.select (b (B.succ n)) B.zero (r (B.succ n)) := rstep (B.succ n)
        _ = B.select (b (B.succ n)) B.zero B.zero := congrArg
            (fun z => B.select (b (B.succ n)) B.zero z) hn
        _ = B.zero := select_same (b (B.succ n)) (bits (B.succ n))
        _ = r (B.succ n) := hn.symm
    | inr ho =>
      have hnext : b (B.succ n) = B.one :=
        (truth (B.succ n)).mp (step n ((truth n).mpr ho))
      calc
        r (B.succ (B.succ n)) =
            B.select (b (B.succ n)) B.zero (r (B.succ n)) := rstep (B.succ n)
        _ = B.select B.one B.zero (r (B.succ n)) := congrArg
            (fun z => B.select z B.zero (r (B.succ n))) hnext
        _ = r (B.succ n) := B.select_one B.zero (r (B.succ n))
  have shifted_one : ∀ n, r (B.succ n) = B.one := by
    intro n
    exact (B.constancy (fun j => r (B.succ j)) shifted_step n).trans shifted_base
  intro n
  apply (truth n).mpr
  cases bits n with
  | inl hz =>
    have hn : r (B.succ n) = B.zero := by
      calc
        r (B.succ n) = B.select (b n) B.zero (r n) := rstep n
        _ = B.select B.zero B.zero (r n) := congrArg
            (fun z => B.select z B.zero (r n)) hz
        _ = B.zero := B.select_zero B.zero (r n)
    exact False.elim (B.one_ne_zero ((shifted_one n).symm.trans hn))
  | inr ho => exact ho

theorem choose_and (a b : α) :
    B.choose a b B.one = B.zero ↔ a = B.zero ∧ b = B.zero := by
  cases B.zero_decision a with
  | inl ha =>
    have hc := B.choose_of_zero ha b B.one
    exact ⟨fun h => ⟨ha, hc.symm.trans h⟩, fun h => hc.trans h.2⟩
  | inr ha =>
    have hc := B.choose_of_ne_zero ha b B.one
    exact ⟨fun h => False.elim (B.one_ne_zero (hc.symm.trans h)),
      fun h => False.elim (ha h.1)⟩

theorem choose_or (a b : α) :
    B.choose a B.zero b = B.zero ↔ a = B.zero ∨ b = B.zero := by
  cases B.zero_decision a with
  | inl ha =>
    exact ⟨fun _ => Or.inl ha, fun _ => B.choose_of_zero ha B.zero b⟩
  | inr ha =>
    have hc := B.choose_of_ne_zero ha B.zero b
    constructor
    · intro h
      exact Or.inr (hc.symm.trans h)
    · intro h
      cases h with
      | inl he => exact False.elim (ha he)
      | inr he => exact hc.trans he

theorem choose_imp (a b : α) :
    B.choose a b B.zero = B.zero ↔ (a = B.zero → b = B.zero) := by
  cases B.zero_decision a with
  | inl ha =>
    have hc := B.choose_of_zero ha b B.zero
    exact ⟨fun h _ => hc.symm.trans h, fun h => hc.trans (h ha)⟩
  | inr ha =>
    exact ⟨fun _ h => False.elim (ha h),
      fun _ => B.choose_of_ne_zero ha b B.zero⟩

/- This is structural syntax only.  Atom functions stand for specified
   finite terms; their fixed numerical parameters are held in closures. -/
inductive Formula (α : Type u) where
  | atom : (α → α) → (α → α) → Formula α
  | falsum : Formula α
  | conj : Formula α → Formula α → Formula α
  | disj : Formula α → Formula α → Formula α
  | impl : Formula α → Formula α → Formula α

def Formula.eval {α : Type u} : Formula α → α → Prop
  | .atom lhs rhs, n => lhs n = rhs n
  | .falsum, _ => False
  | .conj f g, n => f.eval n ∧ g.eval n
  | .disj f g, n => f.eval n ∨ g.eval n
  | .impl f g, n => f.eval n → g.eval n

def Formula.error {α : Type u} (B : Basis α) : Formula α → α → α
  | .atom lhs rhs, n => B.error (lhs n) (rhs n)
  | .falsum, _ => B.one
  | .conj f g, n => B.choose (f.error B n) (g.error B n) B.one
  | .disj f g, n => B.choose (f.error B n) B.zero (g.error B n)
  | .impl f g, n => B.choose (f.error B n) (g.error B n) B.zero

theorem formula_compiler (f : Formula α) :
    ∀ n, f.eval n ↔ f.error B n = B.zero := by
  induction f with
  | atom lhs rhs =>
    intro n
    exact (B.error_zero_iff (lhs n) (rhs n)).symm
  | falsum =>
    intro _
    exact ⟨fun h => False.elim h, fun h => B.one_ne_zero h⟩
  | conj f g ihf ihg =>
    intro n
    exact (and_congr (ihf n) (ihg n)).trans
      (B.choose_and (f.error B n) (g.error B n)).symm
  | disj f g ihf ihg =>
    intro n
    exact (or_congr (ihf n) (ihg n)).trans
      (B.choose_or (f.error B n) (g.error B n)).symm
  | impl f g ihf ihg =>
    intro n
    have hi : (f.eval n → g.eval n) ↔
        (f.error B n = B.zero → g.error B n = B.zero) := by
      constructor
      · intro h he
        exact (ihg n).mp (h ((ihf n).mpr he))
      · intro h he
        exact (ihg n).mpr (h ((ihf n).mp he))
    exact hi.trans (B.choose_imp (f.error B n) (g.error B n)).symm

theorem zero_latch_induction (e r : α → α)
    (rbase : r B.zero = B.one)
    (rstep : ∀ n, r (B.succ n) = B.choose (e n) (r n) B.zero)
    (base : e B.zero = B.zero)
    (step : ∀ n, e n = B.zero → e (B.succ n) = B.zero) :
    ∀ n, e n = B.zero := by
  have rone : r B.one = B.one := by
    exact (rstep B.zero).trans
      ((B.choose_of_zero base (r B.zero) B.zero).trans rbase)
  have rs : ∀ n, r (B.succ (B.succ n)) = r (B.succ n) := by
    intro n
    cases B.zero_decision (e n) with
    | inl he =>
      exact (rstep (B.succ n)).trans
        (B.choose_of_zero (step n he) (r (B.succ n)) B.zero)
    | inr he =>
      have rn : r (B.succ n) = B.zero :=
        (rstep n).trans (B.choose_of_ne_zero he (r n) B.zero)
      calc
        r (B.succ (B.succ n)) =
            B.choose (e (B.succ n)) (r (B.succ n)) B.zero := rstep (B.succ n)
        _ = B.choose (e (B.succ n)) B.zero B.zero :=
            congrArg (fun z => B.choose (e (B.succ n)) z B.zero) rn
        _ = B.zero := B.choose_same (e (B.succ n)) B.zero
        _ = r (B.succ n) := rn.symm
  have allone : ∀ n, r (B.succ n) = B.one := by
    intro n
    exact (B.constancy (fun j => r (B.succ j)) rs n).trans rone
  intro n
  cases B.zero_decision (e n) with
  | inl he => exact he
  | inr he =>
    have rn : r (B.succ n) = B.zero :=
      (rstep n).trans (B.choose_of_ne_zero he (r n) B.zero)
    exact False.elim (B.one_ne_zero ((allone n).symm.trans rn))

theorem quantifier_free_induction (f : Formula α) (r : α → α)
    (rbase : r B.zero = B.one)
    (rstep : ∀ n, r (B.succ n) =
      B.choose (f.error B n) (r n) B.zero)
    (base : f.eval B.zero)
    (step : ∀ n, f.eval n → f.eval (B.succ n)) : ∀ n, f.eval n := by
  have compile := B.formula_compiler f
  have eb : f.error B B.zero = B.zero := (compile B.zero).mp base
  have es : ∀ n, f.error B n = B.zero → f.error B (B.succ n) = B.zero := by
    intro n hn
    exact (compile (B.succ n)).mp (step n ((compile n).mpr hn))
  have hz := B.zero_latch_induction (f.error B) r rbase rstep eb es
  intro n
  exact (compile n).mpr (hz n)

#print axioms succ_ne_self
#print axioms stationary_one
#print axioms near_diagonal_zero
#print axioms near_next_one
#print axioms trans_successor_diagonal
#print axioms zero_classification
#print axioms error_zero_iff
#print axioms equality_decision
#print axioms constancy
#print axioms ordinary_recursion_from_swap
#print axioms shifted_latch_induction
#print axioms formula_compiler
#print axioms zero_latch_induction
#print axioms quantifier_free_induction

end Basis
end PRAInitializedSwap
