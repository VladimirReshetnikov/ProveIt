#!/usr/bin/env python3
"""Exact formula-tree counts. This is a display metric, not a bit length."""
from __future__ import annotations
import json
from pathlib import Path

def node(tag, *children): return (tag, *children)
def var(name): return node(name)
def app(name, *args): return node(name, *args)
def eq(a, b): return node('=', a, b)
def imp(a, b): return node('implies', a, b)
def disj(a, b): return node('or', a, b)
def neg(a): return imp(a, node('bottom'))
def forall(names, body):
    for name in reversed(names): body = node('forall ' + name, body)
    return body
def size(t): return 1 + sum(size(c) for c in t[1:])

z, n, a, x, y = map(var, ['0', 'n', 'a', 'x', 'y'])
S = lambda t: app('S', t)

def displays(m):
    assert m >= 1
    frozen = [var('b'+str(i)) for i in range(m-1)]
    names = ['a'] + [t[0] for t in frozen]
    oldbase = forall(names, eq(app('R', z, a, *frozen), app('g', a, *frozen)))
    oldstep = forall(['n']+names, eq(app('R', S(n), a, *frozen),
        app('h', n, a, *frozen, app('R', n, app('k', a), *frozen))))
    newbase = forall(names, eq(app('R', z, a, *frozen), a))
    newstep = forall(['n']+names, eq(app('R', S(n), a, *frozen),
        app('h', n, a, *frozen, app('R', a, n, *frozen))))
    pars = [var('c'+str(i)) for i in range(m)]
    F = lambda t: app('f', t, *pars)
    ss = forall([p[0] for p in pars], imp(
        forall(['n'], eq(F(S(n)), F(n))),
        forall(['n'], neg(eq(S(F(n)), F(z))))))
    old_bridge = forall(['x','y'], disj(eq(app('E', x,y), z), eq(x,y)))
    new_bridge = forall(['x','y'], disj(eq(app('T', x,y), y), eq(x,y)))
    r = {'displayed_parameters':m,
         'old_computation':size(oldbase)+size(oldstep),
         'new_computation':size(newbase)+size(newstep),
         'stationary_separation':size(ss),
         'old_bridge':size(old_bridge), 'new_bridge':size(new_bridge)}
    r['old_total'] = r['old_computation']+r['stationary_separation']+r['old_bridge']
    r['new_total'] = r['new_computation']+r['stationary_separation']+r['new_bridge']
    return r

def main():
    rows = [displays(m) for m in range(1,5)]
    for r in rows:
        m=r['displayed_parameters']
        assert r['new_computation']==13+6*m
        assert r['old_computation']==14+7*m
        assert r['stationary_separation']==17+5*m
        assert r['new_total']==41+11*m
        assert r['old_total']==42+12*m
    t_update=app('C',app('D',a,n),app('C',app('D',n,a),a,z),a)
    updates={'C':size(var('b')),'D':size(var('v')),'T':size(t_update)}
    assert updates=={'C':1,'D':1,'T':11}
    result={'convention':'Every variable, constant, function application, equality, connective, bottom and individual quantifier is one node. Negation expands to implication to bottom. Descriptor bodies are separate.',
      'rows':rows,'selected_update_term_nodes':updates,
      'selected_update_total':sum(updates.values()),
      'scope':'Infinitely many terms and parameter arities. Counts do not establish a global minimum or a shorter fully encoded generator.'}
    out=Path(__file__).with_name('schema_metrics.json')
    out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__': main()
