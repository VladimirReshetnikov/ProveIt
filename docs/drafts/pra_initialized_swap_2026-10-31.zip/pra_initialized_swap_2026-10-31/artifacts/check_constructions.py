#!/usr/bin/env python3
"""Finite diagnostics for the two compilers; not a proof of their theorems."""
from __future__ import annotations
from functools import lru_cache
import json
from pathlib import Path

def c(z,u,v): return u if z==0 else v
def p(x): return max(x-1,0)

@lru_cache(None)
def d(x,y): return y if x==0 else d(y,x-1)

def t(x,y):
    if x==0: return y
    n=x-1
    return c(d(y,n),c(d(n,y),y,0),y)
def q(z): return t(z+1,1)
def j(z,u,v): return c(q(z),u,v)
def error(x,y): return t(x+1,y+1)

def swap_direct(h,x,a,pars=()):
    @lru_cache(None)
    def run(x,a):
        return a if x==0 else h(x-1,a,pars,run(a,x-1))
    return run(x,a)

def swap_compiled(h,x,a,pars=()):
    left=max(x-a,0); right=max(a-x,0); m=min(x,a)
    v=right if left==0 else h(p(left),0,pars,p(left))
    for k in range(m):
        v=h(left+k,right+k+1,pars,h(right+k,left+k,pars,v))
    return v

def ordinary_via_swap(g,h,n,pars=()):
    def update(k,a,bs,v):
        return j(error(a,k),v,j(k,g(bs),h(p(k),bs,v)))
    return swap_direct(update,n+1,n+1,pars)

def ordinary_direct(g,h,n,pars=()):
    v=g(pars)
    for k in range(n): v=h(k,pars,v)
    return v

def main():
    counts={'core_pairs':0,'swap_compiler_pairs':0,'swap_recurrence_checks':0,
            'ordinary_compiler_values':0,'diagonal_induction_normalizations':0,
            'boolean_truth_table_cases':0}
    for x in range(41):
      for y in range(41):
        assert d(x,y)==max(y-x,0)+p(max(x-y,0))
        assert d(x,x)==0
        assert (d(x,y)==0 and d(y,x)==0)==(x==y)
        assert t(x,y)==y or x==y
        assert error(x,y)==0 if x==y else error(x,y)!=0
        assert q(x)==(0 if x==0 else 1)
        counts['core_pairs']+=1
        left=max(x-y,0); right=max(y-x,0); m=min(x,y)
        assert left==0 or right==0
        assert left+m==x and right+m==y
        counts['diagonal_induction_normalizations']+=1
    cases=[('identity',lambda n,a,b,v:v,()),
           ('predecessor',lambda n,a,b,v:n,()),
           ('linear',lambda n,a,b,v:2*v+n+3*a,()),
           ('nonlinear_bounded',lambda n,a,b,v:(v*v+n*a+7)%101,()),
           ('zero_branches',lambda n,a,b,v:c(v,n+2,a+3),()),
           ('frozen_parameters',lambda n,a,b,v:(b[0]*v+n+b[1]*a)%1009,(3,5))]
    for name,h,bs in cases:
      for x in range(18):
        for a in range(18):
          out=swap_compiled(h,x,a,bs)
          assert out==swap_direct(h,x,a,bs),(name,x,a)
          assert swap_compiled(h,x+1,a,bs)==h(x,a,bs,swap_compiled(h,a,x,bs))
          counts['swap_compiler_pairs']+=1
          counts['swap_recurrence_checks']+=1
    ordinary=[('addition',lambda bs:bs[0],lambda n,bs,v:v+1,(7,)),
              ('factorial',lambda bs:1,lambda n,bs,v:(n+1)*v,()),
              ('counter_sensitive',lambda bs:bs[0],lambda n,bs,v:(v*v+3*n+bs[1])%1009,(2,7)),
              ('zero_sensitive',lambda bs:0,lambda n,bs,v:c(n,bs[0],p(v)),(9,))]
    for name,g,h,bs in ordinary:
      for n in range(18):
        assert ordinary_via_swap(g,h,n,bs)==ordinary_direct(g,h,n,bs),(name,n)
        counts['ordinary_compiler_values']+=1
    for u in (0,1):
      for v in (0,1):
        # Error bits: zero means true.
        assert (j(u,v,1)==0)==((u==0) and (v==0))
        assert (j(u,0,v)==0)==((u==0) or (v==0))
        assert (j(u,v,0)==0)==((u!=0) or (v==0))
        counts['boolean_truth_table_cases']+=3
    # Deliberately wrong compiler: dropping the inner h must be detected.
    h=lambda n,a,bs,v:2*v+n+3*a
    caught=False
    for x in range(1,5):
      for a in range(1,5):
        left=max(x-a,0); right=max(a-x,0)
        v=right if left==0 else h(p(left),0,(),p(left))
        for k in range(min(x,a)): v=h(left+k,right+k+1,(),v)
        caught |= (v!=swap_direct(h,x,a))
    assert caught
    result={'status':'passed','counts':counts,'swap_update_families':len(cases),
      'ordinary_update_families':len(ordinary),'intentional_bad_compiler_detected':caught,
      'scope':'Finite executable diagnostics; universal proofs and both interpretation round trips are in the paper.'}
    Path(__file__).with_name('construction_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
