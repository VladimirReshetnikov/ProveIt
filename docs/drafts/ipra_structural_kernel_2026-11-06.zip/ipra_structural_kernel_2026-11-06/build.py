"""Build report.pdf from the included LaTeX sources with pdfLaTeX."""
from datetime import datetime
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def main():
    if shutil.which('pdflatex') is None:
        raise SystemExit('Install pdfLaTeX and the standard packages listed in report.tex.')
    environment = os.environ.copy()
    epoch = datetime.fromisoformat('2026-11-07T04:13:53+00:00').timestamp()
    environment['SOURCE_DATE_EPOCH'] = str(int(epoch))
    environment['FORCE_SOURCE_DATE'] = '1'
    with tempfile.TemporaryDirectory(prefix='ipra-tex-') as directory:
        command = ['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
                   '-file-line-error', '-output-directory=' + directory, 'report.tex']
        for _ in range(3):
            run = subprocess.run(command, cwd=ROOT, env=environment,
                                 capture_output=True, text=True)
            if run.returncode:
                print(run.stdout[-16000:])
                print(run.stderr)
                raise SystemExit(run.returncode)
        log = (Path(directory) / 'report.log').read_text(errors='replace')
        warnings = [line for line in log.splitlines()
                    if 'Warning' in line or 'Overfull' in line or 'Underfull' in line]
        shutil.copyfile(Path(directory) / 'report.pdf', ROOT / 'report.pdf')
        result = {'passes': 3, 'engine': 'pdflatex', 'warnings': warnings,
                  'output': 'report.pdf', 'bytes': (ROOT / 'report.pdf').stat().st_size}
        (ROOT / 'results/latex_build.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
