"""Remeasure the complete current checkers and this package, offline.

The metric is deliberately the one used by the supplied draft series.
Only actual docstrings, comments, and formatting tokens are excluded.
Every application-specific acceptance operation and the entire CLI count.
"""
import ast
import csv
import hashlib
import io
import json
import platform
import sys
import tokenize
from pathlib import Path

ROOT = Path(__file__).resolve().parent
IGNORED = {
    tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
    tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER,
}
FIELDS = ('source_tokens', 'normalized_tokens', 'ast_nodes',
          'normalized_bytes', 'raw_bytes')
PRIMARY = FIELDS[:4]


def measure(path):
    raw = path.read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if (isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef,
                              ast.AsyncFunctionDef)) and node.body
                and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            doc = node.body.pop(0)
            spans.append(((doc.lineno, doc.col_offset),
                          (doc.end_lineno, doc.end_col_offset)))
    normalized = ast.unparse(tree) + '\n'

    def tokens(text, omitted=()):
        return sum(
            token.type not in IGNORED
            and not any(start <= token.start and token.end <= end
                        for start, end in omitted)
            for token in tokenize.generate_tokens(io.StringIO(text).readline)
        )

    return {
        'source': str(path.relative_to(ROOT)),
        'sha256': hashlib.sha256(raw).hexdigest(),
        'source_tokens': tokens(source, spans),
        'normalized_tokens': tokens(normalized),
        'ast_nodes': sum(1 for _ in ast.walk(tree)),
        'normalized_bytes': len(normalized.encode('utf-8')),
        'raw_bytes': len(raw),
    }


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    baselines = []
    for entry in manifest['baselines']:
        row = measure(ROOT / entry['frozen_source'])
        if row['sha256'] != entry['source_sha256']:
            raise ValueError('Modified frozen source: ' + row['source'])
        baselines.append(row)
    envelope = {key: min(row[key] for row in baselines) for key in FIELDS}
    candidates = [measure(ROOT / 'checker.py')]
    result = {
        'python': sys.version,
        'python_version': platform.python_version(),
        'repository': manifest['repository'],
        'commit': manifest['commit'],
        'boundary': ('Full standalone acceptance programs: syntax, binding data, '
                     'substitution, arithmetic, logic, JSON, CLI, and rejection. '
                     'Comments and docstrings excluded; raw bytes supplementary.'),
        'baselines': baselines,
        'coordinatewise_minimum': envelope,
        'candidates': candidates,
        'strictly_below': {
            row['source']: {key: row[key] < envelope[key] for key in FIELDS}
            for row in candidates
        },
    }
    destination = ROOT / 'results'
    destination.mkdir(exist_ok=True)
    (destination / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    with (destination / 'metrics.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, ['source', 'sha256', *FIELDS])
        writer.writeheader()
        writer.writerows([*baselines, *candidates])
    macros = []
    for label, data in [('Old', envelope), ('New', candidates[0])]:
        for field, suffix in [('source_tokens', 'SourceTokens'),
                              ('normalized_tokens', 'Tokens'),
                              ('ast_nodes', 'AST'),
                              ('normalized_bytes', 'Bytes'),
                              ('raw_bytes', 'RawBytes')]:
            macros.append('\\newcommand{\\' + label + suffix + '}{'
                          + str(data[field]) + '}')
    (destination / 'metrics.tex').write_text('\n'.join(macros) + '\n')
    if not all(all(row[key] for key in PRIMARY)
               for row in result['strictly_below'].values()):
        raise ValueError('Candidate does not strictly beat the current envelope')
    print(json.dumps({'measurement': 'passed', 'baselines': len(baselines),
                      'old_minimum': envelope, 'candidate': candidates[0]}, indent=2))
    return result


if __name__ == '__main__':
    main()
