"""Refresh the payload manifest and build a deterministic ZIP archive."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent


def payloads():
    for path in sorted(ROOT.rglob('*')):
        relative = path.relative_to(ROOT)
        if (not path.is_file() or '__pycache__' in relative.parts
                or any(part.startswith('ipra-audit-') for part in relative.parts)
                or path.suffix in ('.pyc', '.aux', '.log', '.out', '.toc')
                or path.name == 'MANIFEST.sha256'):
            continue
        yield path


def main():
    files = list(payloads())
    if not (ROOT / 'report.pdf').is_file():
        raise SystemExit('Build report.pdf before packaging.')
    manifest = ROOT / 'MANIFEST.sha256'
    manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  '
                               + str(p.relative_to(ROOT)) + '\n' for p in files))
    files.append(manifest)
    destination = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in sorted(files):
            name = ROOT.name + '/' + str(path.relative_to(ROOT))
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 7, 4, 13, 54))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise SystemExit('ZIP integrity check failed.')
    print(destination)
    print('Files:', len(files))
    print('Bytes:', destination.stat().st_size)
    print('SHA256:', hashlib.sha256(destination.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
