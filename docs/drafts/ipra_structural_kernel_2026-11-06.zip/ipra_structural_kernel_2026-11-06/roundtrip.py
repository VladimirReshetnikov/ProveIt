"""Reproduce sequent-preserving translations and the numerical-code bijection.

This file is untrusted support. The complete checker never imports it.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import sys

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'audit_support'))
from named_oracle import term, formula
from translate import load_checker, forward, readback, canonicalize, shift_codes


def main():
    source = load_checker(ROOT / 'comparison/automatic_introduction__checker.py')
    target = load_checker(ROOT / 'checker.py')
    rows = []
    for path in sorted((ROOT / 'audit_support/examples').glob('*.json')):
        old_goal, old_proof, *old_context = json.loads(path.read_text())
        data = forward(source, target, old_goal, old_proof, old_context)
        goal, proof, context = data
        if not target.check(goal, proof, context):
            raise AssertionError('Target rejected translated example: ' + path.name)
        expected = json.loads((ROOT / 'examples' / path.name).read_text())
        if data != expected:
            raise AssertionError('Packaged example differs: ' + path.name)
        back_goal, back_proof, *back_context = readback(source, target, *data)
        if (back_goal, back_context) != (old_goal, old_context):
            raise AssertionError('Sequent changed: ' + path.name)
        canonical = canonicalize(source, target, *data)
        if canonicalize(source, target, *canonical) != canonical:
            raise AssertionError('Canonicalization not idempotent: ' + path.name)
        rows.append({'file': path.name, 'open_assumptions': len(context),
                     'forward': True, 'readback': True, 'canonicalization': True})

    # Use the fixed, independently written syntax generator in the audit support.
    # This experiment compares coordinate conventions; the separate audit compares
    # the final substitution itself against named-variable substitution.
    rng = random.Random(20261106)
    environments = ((1,), (0,), [-1, 0], [['s', 0], 0], [2, -1],
                    [['r', ['s', 1], 0, 2], -1],
                    [0, ['s', 1], -2], [['r', 0, 1, ['s', 2]], 3, -2])
    count = 0
    for i in range(250):
        is_formula = i % 2 == 0
        a = formula(rng, 3) if is_formula else term(rng, 4)
        depth = i % 5
        for environment in environments:
            converted_environment = [*(shift_codes(t, 1) for t in environment[:-1]),
                                     environment[-1]]
            expected = shift_codes(source.subst(a, environment, depth, is_formula), 1)
            actual = target.subst(shift_codes(a, 1), converted_environment,
                                  depth, is_formula)
            if expected != actual:
                raise AssertionError('Numerical-code substitution identity failed')
            count += 1

    result = {
        'status': 'passed',
        'candidate_sha256': hashlib.sha256((ROOT / 'checker.py').read_bytes()).hexdigest(),
        'examples': len(rows),
        'with_public_assumptions': sum(row['open_assumptions'] > 0 for row in rows),
        'substitution_bijection_checks': count,
        'rows': rows,
        'qualification': ('Finite checks of translations and the coordinate convention. '
                          'Soundness, completeness, and bi-interpretability are paper proofs.'),
    }
    (ROOT / 'results/roundtrip.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'rows'}, indent=2))
    return result


if __name__ == '__main__':
    main()
