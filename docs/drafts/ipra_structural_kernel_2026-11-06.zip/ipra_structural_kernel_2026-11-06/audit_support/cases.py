"""Small purposeful rule corpus and systematic binder tests.

Every record is (label, goal, proof, context, expected). Expected answers for
hand-built cases are asserted independently of both rule implementations.
"""
import copy
import json
from pathlib import Path
from named_oracle import oracle
from rule_oracle import erase_automatic


ZERO = -1
ONE = ["s", ZERO]
TRUTH = ["=", ZERO, ZERO]
FALSE = ["=", ZERO, ONE]


def reflexivity(t):
    major = ["=", ["r", ZERO, t, ZERO], t]
    motive = ["=", 0, oracle(t, formula=False)]
    return [major, "r", motive, "r"]


def direct_cases(root):
    rows = []

    def add(label, a, p, g=(), expected=True):
        rows.append((label, a, p, list(g), expected))

    for source in sorted((root / "examples").glob("*.json")):
        a, p, *g = json.loads(source.read_text())
        add("upstream_" + source.stem, a, erase_automatic(a, p, g), g)

    add("closed_reflexivity", TRUTH, reflexivity(ZERO))
    add("open_reflexivity", ["=", 0, 0], reflexivity(0))
    add("contradiction_is_not_a_hypothesis", FALSE, None, expected=False)
    add("contradiction_under_itself", FALSE, {"irrelevant": True}, [FALSE])
    atom = ["=", 0, 1]
    for i, annotation in enumerate((None, False, True, -5, 0, 17, {}, [], "r", ["unused", 1])):
        add("membership_annotation_%02d" % i, atom, annotation, [atom])
    add("failed_major_falls_back_to_hypothesis", atom,
        [TRUTH, None, ["=", 0, ZERO], None], [atom])
    add("failed_major_without_hypothesis", atom,
        [TRUTH, None, ["=", 0, ZERO], None], expected=False)
    add("malformed_major_does_not_fall_back", atom,
        [["=", True, ZERO], None, ["=", 0, ZERO], None], [atom], False)

    # Direct equation-induction step genuinely uses its local equation.
    b = ["=", ["r", 0, ZERO, ["s", 0]], 0]
    b0 = oracle(b, [ZERO, 0])
    motive = ["=", ["r", ["s", 1], ZERO, ["s", 0]], ["s", 0]]
    step = [b, None, motive, "r"]
    add("equation_induction_uses_local_equation", ["pi", b0, b], [step])

    # An existential matrix must receive only B(0), never B(x), as hypothesis.
    ex = ["ex", ["=", 0, 1]]
    ex0 = oracle(ex, [ZERO, 0])
    exs = oracle(ex, [["s", 0], 0])
    transport = [["=", 1, 2], None, ["=", 1, ["s", 0]], None]
    needs_ih = [ex, None, [["s", 0], transport]]
    add("compound_successor_step_with_hypothesis", exs, needs_ih, [ex])
    add("compound_induction_hypothesis_forbidden", ["pi", ex0, ex], [needs_ih], expected=False)
    add("compound_cases_with_independent_successor", ["pi", ex0, ex], [[["s", 0], None]])

    # An ordinary-introduction certificate cannot just be erased at a collision.
    collision = ["pi", TRUTH, ["=", 0, 0]]
    add("naive_ordinary_collision", collision, [reflexivity(0)], expected=False)
    add("numerical_collision_with_successor_proof", collision, [reflexivity(["s", 0])])
    add("zero_free_collision", ["pi", ["=", 1, 1], ["=", 1, 1]], [None])

    # Fresh-variable obligations: retain outside parameters and prevent escape.
    existential = ["ex", ["=", 0, ZERO]]
    add("existential_witness_cannot_escape", ["=", 0, ZERO],
        [existential, None, None], [existential], False)
    outer = ["=", 0, ONE]
    add("outside_parameter_retained_by_exists", outer,
        [existential, None, None], [existential, outer])
    add("outside_parameter_not_a_universal_variable", ["pi", TRUTH, ["=", 0, ONE]],
        [None], [outer], False)
    add("fixed_existential_witness", ["ex", ["=", 0, 1]], [0, None])
    add("misbound_existential_witness", ["ex", ["=", 0, 1]], [1, None], expected=False)

    # The strict witness policy is exercised even for vacuous universal bodies.
    vacuous = ["pi", TRUTH, TRUTH]
    for label, witness in (("boolean", True), ("float", -1.0), ("object", {}),
                           ("null", None), ("negative", -2), ("term_arity", ["s", ZERO, ZERO])):
        add("unused_universal_witness_" + label, TRUTH,
            [vacuous, None, witness, None], [vacuous, TRUTH], False)
        add("existential_witness_" + label, existential, [witness, None], expected=False)
    add("unused_universal_witness_zero", TRUTH,
        [vacuous, None, ZERO, None], [vacuous, TRUTH])

    bad_terms = (True, False, -1.0, -2, None, {}, "s", ["s"], ["s", ZERO, ZERO],
                 ["r", ZERO, ZERO], ["r", ZERO, ZERO, ["s", None]])
    for i, bad in enumerate(bad_terms):
        add("public_bad_goal_%02d" % i, ["=", bad, ZERO], None, expected=False)
        add("unused_bad_hypothesis_%02d" % i, TRUTH, reflexivity(ZERO), [["=", bad, ZERO]], False)
        add("unused_bad_recursor_update_%02d" % i, ["=", ["r", ZERO, ZERO, bad], ZERO], "r", expected=False)

    for i, a in enumerate((ZERO, True, None, [], ["="], ["=", ZERO],
                           ["pi", TRUTH], ["ex", TRUTH, TRUTH], ["s", ZERO])):
        add("public_bad_formula_%02d" % i, a, None, expected=False)

    # Zero/successor computations at a parameterized initializer/update.
    n, initial = 2, ["s", 0]
    updates = [0, 1, 2, ["s", 0], ["r", 1, 2, ["s", 4]],
               ["r", ["s", 2], 0, ["r", 1, 4, 5]]]
    for i, update in enumerate(updates):
        add("computation_zero_%02d" % i, ["=", ["r", ZERO, initial, update], initial], "r")
        left = ["r", ["s", n], initial, update]
        rhs = oracle(update, [["r", n, initial, update], n, -2], formula=False)
        add("computation_successor_%02d" % i, ["=", left, rhs], "r")
        add("wrong_computation_rhs_%02d" % i, ["=", left, ["s", rhs]], "r", expected=False)
    add("variable_counter_is_not_computation", ["=", ["r", 0, ZERO, 0], ZERO], "r", expected=False)
    add("recursor_counter_is_not_successor", ["=", ["r", ["r", ZERO, ZERO, ZERO], ZERO, ZERO], ZERO], "r", expected=False)

    # Equality substitution across 1..8 binders: accepting an unlifted witness
    # would capture it, so paired targets distinguish the two implementations.
    major = ["=", ["s", 0], 0]
    for depth in range(1, 9):
        motive = ["=", depth, ZERO]
        captured = ["=", 0, ZERO]
        for _ in range(depth):
            motive = ["ex", motive]
            captured = ["ex", captured]
        premise = oracle(motive, [major[1], -1])
        conclusion = oracle(motive, [major[2], -1])
        proof = [major, None, motive, None]
        add("transport_depth_%02d" % depth, conclusion, proof, [major, premise])
        add("capture_depth_%02d" % depth, captured, proof, [major, premise], False)
    motive = ["=", ["r", ZERO, ZERO, 2], ZERO]
    premise = oracle(motive, [major[1], -1])
    conclusion = oracle(motive, [major[2], -1])
    proof = [major, None, motive, None]
    add("transport_inside_recursion_update", conclusion, proof, [major, premise])
    add("capture_inside_recursion_update", ["=", ["r", ZERO, ZERO, 0], ZERO],
        proof, [major, premise], False)
    return rows


def node_paths(tree, path=()):
    yield path
    if type(tree) is list:
        for i, child in enumerate(tree):
            yield from node_paths(child, (*path, i))


def replace_at(tree, path, value):
    if not path:
        return copy.deepcopy(value)
    answer = copy.deepcopy(tree)
    cursor = answer
    for i in path[:-1]:
        cursor = cursor[i]
    cursor[path[-1]] = copy.deepcopy(value)
    return answer
