"""Independent rules and readback for unlabelled automatic iPRA certificates.

The target is not imported here. Expressions are checked by a separate grammar;
substitution resolves de Bruijn slots to distinct named binders first. The
named-binder implementation and the strict automatic reference have explicit
attribution in provenance.json. This file states the rules independently.
"""
from collections import Counter
from named_oracle import valid, oracle


def require(condition):
    if not condition:
        raise ValueError("independent rule condition failed")


def expression(a, formula=True):
    require(valid(a, formula))
    return a


def context(g):
    # Match the natural interpretation of any accepted public JSON iterable:
    # its elements, not the original container annotation, are assumptions.
    result = list(g)
    for a in result:
        expression(a)
    return result


def local_goal(a):
    """Return the automatic Pi premise, using named-variable substitution."""
    require(a[0] == "pi")
    h, b = a[1:]
    if h != oracle(b, [-1, 0]):
        return b, h, "ordinary_guarded_introduction"
    hypothesis = b if b[0] == "=" else h
    kind = "equation_induction" if b[0] == "=" else "compound_numerical_cases"
    return oracle(b, [["s", 0], 0]), hypothesis, kind


def infer(a, p, g, counts=None):
    """Boolean rule check; malformed syntax/arity raises as at the public edge.

The order of introduction, elimination, computation, and hypothesis fallback
is part of the specified certificate language. The inference conditions are
evaluated using the named-binder oracle, never target substitution.
"""
    expression(a)
    counts = Counter() if counts is None else counts
    array = type(p) is list
    if a[0] == "pi" and array and len(p) == 1:
        b, h, kind = local_goal(a)
        counts[kind] += 1
        return infer(b, p[0], [*[oracle(x) for x in g], h], counts)
    if a[0] == "ex" and array and len(p) == 2:
        witness, child = p
        expression(witness, False)
        equation = ["=", 0, oracle(witness, formula=False)]
        counts["existential_introduction"] += 1
        return infer(a[1], child, [*[oracle(x) for x in g], equation], counts)
    if array and len(p) >= 2 and type(p[0]) is list and p[0]:
        major = p[0]
        if infer(major, p[1], g, counts):
            args = p[2:]
            if major[0] == "ex":
                require(len(args) == 1)
                counts["existential_elimination"] += 1
                return infer(oracle(a), args[0],
                             [*[oracle(x) for x in g], major[1]], counts)
            require(len(args) == 2)
            annotation, child = args
            if major[0] == "pi":
                expression(annotation, False)
                premise = oracle(major[1], [annotation, -1])
                conclusion = oracle(major[2], [annotation, -1])
                counts["guarded_elimination"] += 1
            else:
                require(major[0] == "=")
                expression(annotation)
                premise = oracle(annotation, [major[1], -1])
                conclusion = oracle(annotation, [major[2], -1])
                counts["equality_transport"] += 1
            return conclusion == a and infer(premise, child, g, counts)
        counts["failed_major_hypothesis_fallback"] += 1
    if p == "r" and a[0] == "=" and type(a[1]) is list and a[1][0] == "r":
        counter, initializer, update = a[1][1:]
        if counter == -1:
            rhs = initializer
            counts["computation_zero"] += 1
        else:
            require(type(counter) is list and len(counter) == 2 and counter[0] == "s")
            predecessor = counter[1]
            rhs = oracle(update, [["r", predecessor, initializer, update], predecessor, -2],
                         formula=False)
            counts["computation_successor"] += 1
        return rhs == a[2]
    counts["hypothesis_membership"] += 1
    return a in g


def accepted(a, p, g=(), counts=None):
    try:
        return infer(a, p, context(g), counts)
    except Exception:
        return False


def readback(a, p, g=()):
    """Produce a strict, explicitly tagged automatic certificate.

    Assumes independently accepted input. The caller then checks the returned
    proof with the frozen standalone automatic-introduction reference.
    """
    g = context(g)
    require(infer(a, p, g))
    array = type(p) is list
    if a[0] == "pi" and array and len(p) == 1:
        b, h, _ = local_goal(a)
        return ["lam", readback(b, p[0], [*[oracle(x) for x in g], h])]
    if a[0] == "ex" and array and len(p) == 2:
        witness, child = p
        h = ["=", 0, oracle(witness, formula=False)]
        return ["pack", witness, readback(a[1], child, [*[oracle(x) for x in g], h])]
    if array and len(p) >= 2 and type(p[0]) is list and p[0] and infer(p[0], p[1], g):
        major, proof, *args = p
        proof = readback(major, proof, g)
        if major[0] == "ex":
            child, = args
            return [major, proof,
                    readback(oracle(a), child, [*[oracle(x) for x in g], major[1]])]
        annotation, child = args
        premise = (oracle(major[1], [annotation, -1]) if major[0] == "pi"
                   else oracle(annotation, [major[1], -1]))
        return [major, proof, annotation, readback(premise, child, g)]
    if p == "r" and a[0] == "=" and type(a[1]) is list and a[1][0] == "r":
        return "r"
    return g.index(a)


def erase_automatic(a, p, g=()):
    """Erase explicit introduction tags from a validated upstream example."""
    if type(p) is not list:
        return p
    if p[0] == "lam":
        b, h, _ = local_goal(a)
        return [erase_automatic(b, p[1], [*[oracle(x) for x in g], h])]
    if p[0] == "pack":
        _, witness, child = p
        h = ["=", 0, oracle(witness, formula=False)]
        return [witness, erase_automatic(a[1], child, [*[oracle(x) for x in g], h])]
    major, proof, *args = p
    proof = erase_automatic(major, proof, g)
    if major[0] == "ex":
        child, = args
        return [major, proof,
                erase_automatic(oracle(a), child, [*[oracle(x) for x in g], major[1]])]
    annotation, child = args
    premise = (oracle(major[1], [annotation, -1]) if major[0] == "pi"
               else oracle(annotation, [major[1], -1]))
    return [major, proof, annotation, erase_automatic(premise, child, g)]
