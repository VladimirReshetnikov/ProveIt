INDEPENDENT FINITE AUDIT
========================

Run from any directory:

  python3 independent_audit.py --candidate checker.py

The default candidate is checker.py beside the audit driver, or
kernel_candidate.py when running in the research workspace. The output is
audit_support/summary.json. No third-party Python packages or network are used.

The acceptance program does not import any file in this directory. These
are untrusted audit and proof-conversion tools, outside the measured checker.

Independence boundary
--------------------

named_oracle.py parses the finite syntax into named free variables and fresh
binder identities, performs substitution there, and reconstructs indices.
It never calls the candidate's substitution function or scope table.

The frozen oracle and inherited fixtures retain their original convention:
zero is -1 and variable indices start at 0. The primary candidate uses zero=0
and variable indices starting at 1. The audit driver makes this coordinate
change explicitly by adding one to genuine integer expression leaves only.
Boolean and floating-point values are unchanged. In substitution environments,
only replacement terms are translated; the final tail shift and the ambient
binder depth stay unchanged. This is a syntax-coordinate bijection, not a new
substitution algorithm. The --notation negative option audits the earlier
coordinate convention without changing any frozen oracle source.

rule_oracle.py states the rule checks using that separate syntax and
substitution implementation. It contains no candidate import. The audit driver
imports the target only to compare results and execute its full CLI.

For independently accepted curated inputs, readback reconstructs hypothesis
indices and explicit introduction tags. The resulting proof is checked again
by the byte-identical strict automatic-introduction baseline, retained as
reference_automatic.py. This check supplements the independent oracle; it is
not itself an independent soundness proof of the inherited calculus.

Attribution and inputs
----------------------

provenance.json identifies the original archive, pinned repository commit,
source paths, destination paths, and SHA-256 values for the named-variable
oracle, strict reference checker, and nineteen inherited examples. Every
inherited example is translated on demand by erasing introduction labels.

cases.py also builds direct purpose-specific accepted/rejected pairs. These
exercise literal-equation induction, the prohibition on compound induction,
automatic-introduction collisions, computation, eight nested logical binders,
two-variable recursion binders, existential witness escape, retained outside
parameters, malformed public formulas/contexts, strict witnesses, and harmless
hypothesis fallback annotations.

The driver additionally compares 384 substitutions, creates 180 reproducible
bounded mutations of small accepted proofs, and runs the complete command-line
interface, including malformed JSON, arity errors, and selected Python -O
checks. In particular, the positive candidate rejects the actual integer -1
in numerical-term position. The exact source hash, coordinate convention,
translation contract, and per-case results are recorded in summary.json.

Interpretation
--------------

These groups overlap. Counts are checks, not claims of distinct theorems.
Passing finite tests does not prove soundness, completeness, bi-interpretability,
or consistency. Those universal statements require the mathematical proofs.
The candidate's source hash is checked again after the audit to detect changes
during execution.
