"""Reproduce a bounded independent audit of the complete iPRA acceptance program.

The oracle uses named variables and independent syntax, not target substitution.
Accepted curated proofs are read back into a frozen strict automatic checker.
All support is standard-library Python. This is finite executable evidence;
the universal correctness and bi-interpretability arguments are paper proofs.
"""
import argparse
from collections import Counter
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
SUPPORT = ROOT / "audit_support"
sys.path.insert(0, str(SUPPORT))
sys.dont_write_bytecode = True

from cases import direct_cases, node_paths, replace_at, reflexivity, TRUTH
from named_oracle import oracle, term, formula
from rule_oracle import accepted, context, infer, readback


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def positive_coordinates(value):
    """The explicit coordinate change from zero=-1 to zero=0.

    Genuine integer leaves gain one; Boolean and floating-point payloads stay
    unchanged so malformed type cases remain malformed. Proof-index leaves are
    irrelevant in the membership-based target. No binder or term operation is
    performed by this translation.
    """
    if type(value) is int:
        return value + 1
    if type(value) is list:
        return [positive_coordinates(x) for x in value]
    if type(value) is tuple:
        return tuple(positive_coordinates(x) for x in value)
    if type(value) is dict:
        return {key: positive_coordinates(x) for key, x in value.items()}
    return value


def target_accepts(target, a, p, g, encode):
    try:
        return bool(target.check(encode(a), encode(p), encode(g)))
    except Exception:
        return False


def public_expected(data, open_interface):
    if type(data) is not list or len(data) not in (2, 3):
        return False
    if len(data) == 3 and not open_interface:
        return False
    return accepted(data[0], data[1], data[2] if len(data) == 3 else ())


def run(candidate, output, notation="positive"):
    initial_bytes = candidate.read_bytes()
    target = load_module(candidate, "audited_iPRA_kernel")
    reference = load_module(SUPPORT / "reference_automatic.py", "frozen_automatic_reference")
    encode = positive_coordinates if notation == "positive" else lambda value: value
    open_interface = inspect.signature(target.check).parameters["g"].default is not inspect.Parameter.empty
    rows = direct_cases(SUPPORT)
    failures = []
    cases = []
    rules = Counter()
    reference_checks = 0

    for label, a, p, g, expected in rows:
        independently_accepted = accepted(a, p, g, rules)
        observed = target_accepts(target, a, p, g, encode)
        cases.append({"label": label, "expected": expected, "oracle": independently_accepted,
                      "target": observed})
        if independently_accepted != expected or observed != expected:
            failures.append({"group": "curated_rules", "label": label,
                             "expected": expected, "oracle": independently_accepted,
                             "target": observed})
        if independently_accepted and observed:
            restored = readback(a, p, g)
            try:
                for h in [a, *g]:
                    reference.subst(h)
                good = reference.check(a, restored, g)
            except Exception:
                good = False
            reference_checks += 1
            if not good:
                failures.append({"group": "strict_reference_readback", "label": label})

    # Systematic substitutions at varying ambient binder depth. The inputs
    # contain both one-variable logical binders and two-variable recursor updates.
    rng = random.Random(0x1A7A)
    environments = ((1,), (0,), [-1, 0], [["s", 0], 0], [2, -1],
                    [["r", ["s", 1], 0, 2], -1],
                    [0, ["s", 1], -2], [["r", 0, 1, ["s", 2]], 3, -2])
    substitution_checks = 0
    for i in range(48):
        is_formula = i % 2 == 0
        a = formula(rng, 4) if is_formula else term(rng, 5)
        depth = i % 4
        for env in environments:
            expected = encode(oracle(a, env, depth, is_formula))
            target_env = [*[encode(t) for t in env[:-1]], env[-1]]
            observed = target.subst(encode(a), target_env, depth, is_formula)
            substitution_checks += 1
            if observed != expected:
                failures.append({"group": "named_substitution", "case": i,
                                 "expression": a, "environment": env, "depth": depth,
                                 "expected": expected, "target": observed})

    # Bounded mutations of small, accepted proofs probe dispatch and validation.
    # The independent oracle, not the target, determines each expected answer.
    seeds = [[a, p, g] for label, a, p, g, expected in rows
             if expected and not label.startswith("upstream_")
             and len(json.dumps([a, p, g])) < 4000]
    replacements = [None, True, False, -2, -1.0, 0, 1, -1, [], {}, "r", ["s", -1],
                    ["ex", ["=", 0, -1]], ["pi", TRUTH, TRUTH]]
    mutations = []
    seen = set()
    while len(mutations) < 180:
        original = rng.choice(seeds)
        path = rng.choice(list(node_paths(original)))
        altered = replace_at(original, path, rng.choice(replacements))
        encoded = json.dumps(altered, sort_keys=True)
        if encoded in seen:
            continue
        seen.add(encoded)
        if type(altered) is not list or len(altered) != 3:
            continue
        a, p, g = altered
        expected = accepted(a, p, g)
        observed = target_accepts(target, a, p, g, encode)
        target_encoded = json.dumps(encode(altered), sort_keys=True)
        item = {"source_coordinates_sha256": hashlib.sha256(encoded.encode()).hexdigest(),
                "target_coordinates_sha256": hashlib.sha256(target_encoded.encode()).hexdigest(),
                "expected": expected, "target": observed}
        mutations.append(item)
        if expected != observed:
            failures.append({"group": "bounded_mutation", "input": altered,
                             "expected": expected, "target": observed})

    # Complete CLI tests cover the public acceptance boundary independently of
    # the internal function. They include malformed contexts and raw JSON.
    chosen = [row for row in rows if row[0] in {
        "closed_reflexivity", "open_reflexivity", "contradiction_is_not_a_hypothesis",
        "contradiction_under_itself", "equation_induction_uses_local_equation",
        "compound_induction_hypothesis_forbidden", "compound_cases_with_independent_successor",
        "naive_ordinary_collision", "numerical_collision_with_successor_proof",
        "existential_witness_cannot_escape", "outside_parameter_retained_by_exists",
        "outside_parameter_not_a_universal_variable", "fixed_existential_witness",
        "unused_universal_witness_boolean", "unused_bad_hypothesis_00",
        "public_bad_goal_02", "public_bad_goal_03", "capture_depth_08", "transport_inside_recursion_update",
        "failed_major_falls_back_to_hypothesis", "malformed_major_does_not_fall_back"}]
    cli_inputs = []
    for label, a, p, g, _ in chosen:
        data = [a, p, g] if g and open_interface else [a, p]
        cli_inputs.append((label, json.dumps(encode(data)), public_expected(data, open_interface)))
    a, p = TRUTH, reflexivity(-1)
    for label, data in (
        ("explicit_empty_context", [a, p, []]),
        ("empty_string_context_alias", [a, p, ""]),
        ("empty_object_context_alias", [a, p, {}]),
        ("bad_nonempty_context_string", [a, p, "x"]),
        ("bad_null_context", [a, p, None]),
        ("bad_context_formula", [a, p, [["=", True, -1]]]),
        ("missing_proof", [a]),
        ("extra_public_argument", [a, p, [], []]),
        ("null_public_input", None),
        ("object_public_input", {}),
    ):
        cli_inputs.append((label, json.dumps(encode(data)), public_expected(data, open_interface)))
    cli_inputs.extend((label, raw, False) for label, raw in (
        ("raw_unfinished_array", "["), ("raw_invalid_token", "not-json"),
        ("raw_trailing_comma", "[1,]"), ("raw_nan", "NaN")))
    cli_results = []
    with tempfile.TemporaryDirectory(prefix="ipra-audit-", dir=SUPPORT) as temp:
        path = Path(temp) / "certificate.json"
        for label, raw, expected in cli_inputs:
            path.write_text(raw, encoding="utf-8")
            command = [sys.executable, "-B", str(candidate), str(path)]
            completed = subprocess.run(command, capture_output=True, text=True, timeout=15)
            observed = completed.returncode == 0 and completed.stdout.strip() == "ACCEPT"
            verdict_correct = (observed if expected else
                               completed.returncode != 0 and completed.stdout.strip() == "REJECT")
            cli_results.append({"label": label, "expected": expected, "accepted": observed,
                                "exit_code": completed.returncode,
                                "verdict": completed.stdout.strip()})
            if not verdict_correct:
                failures.append({"group": "complete_cli", "label": label,
                                 "expected": expected, "returncode": completed.returncode,
                                 "stdout": completed.stdout, "stderr": completed.stderr})
        for label, raw, expected in cli_inputs[:6]:
            path.write_text(raw, encoding="utf-8")
            completed = subprocess.run([sys.executable, "-B", "-O", str(candidate), str(path)],
                                       capture_output=True, text=True, timeout=15)
            observed = completed.returncode == 0 and completed.stdout.strip() == "ACCEPT"
            cli_results.append({"label": label + "_optimized", "expected": expected,
                                "accepted": observed, "exit_code": completed.returncode,
                                "verdict": completed.stdout.strip()})
            if observed != expected:
                failures.append({"group": "optimized_cli", "label": label})
        for args in ([], [str(path), str(path)]):
            completed = subprocess.run([sys.executable, "-B", str(candidate), *args],
                                       capture_output=True, text=True, timeout=15)
            cli_results.append({"label": "argument_count_%d" % len(args), "expected": False,
                                "accepted": completed.returncode == 0,
                                "exit_code": completed.returncode, "verdict": completed.stdout.strip()})
            if completed.returncode == 0 or completed.stdout.strip() != "REJECT":
                failures.append({"group": "cli_argument_count", "count": len(args)})

    if candidate.read_bytes() != initial_bytes:
        failures.append({"group": "source_stability", "message": "Candidate changed during audit"})
    summary = {
        "status": "passed" if not failures else "failed",
        "python": sys.version,
        "candidate": candidate.name,
        "candidate_sha256": hashlib.sha256(initial_bytes).hexdigest(),
        "candidate_notation": notation,
        "oracle_notation": "zero=-1; variable indices start at 0",
        "coordinate_translation": ("Every genuine integer expression leaf gains one; Boolean/float values and substitution tail shifts remain unchanged. Binder depth is unchanged."
                                   if notation == "positive" else "Identity"),
        "public_interface": "[goal,proof] or [goal,proof,context]" if open_interface else "[goal,proof]",
        "curated_cases": len(cases),
        "curated_acceptances": sum(x["expected"] for x in cases),
        "curated_rejections": sum(not x["expected"] for x in cases),
        "strict_reference_readbacks": reference_checks,
        "named_substitution_comparisons": substitution_checks,
        "bounded_mutations": len(mutations),
        "complete_cli_runs": len(cli_results),
        "rule_visits": dict(sorted(rules.items())),
        "cases": cases,
        "mutations": mutations,
        "cli": cli_results,
        "failures": failures,
        "qualification": "Finite executable evidence; groups overlap and are not distinct theorem counts. The oracle does not import the target. Universal metatheorems require the mathematical proofs.",
    }
    output.write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({k: summary[k] for k in (
        "status", "candidate_sha256", "candidate_notation", "public_interface", "curated_cases",
        "curated_acceptances", "curated_rejections", "strict_reference_readbacks",
        "named_substitution_comparisons", "bounded_mutations", "complete_cli_runs", "failures")}, indent=2))
    return not failures


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path,
                        default=ROOT / ("checker.py" if (ROOT / "checker.py").exists() else "kernel_candidate.py"))
    parser.add_argument("--output", type=Path, default=SUPPORT / "summary.json")
    parser.add_argument("--notation", choices=("positive", "negative"), default="positive",
                        help="Target numeric coordinates; positive means zero=0 and variables start at 1")
    args = parser.parse_args()
    if not run(args.candidate.resolve(), args.output.resolve(), args.notation):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
