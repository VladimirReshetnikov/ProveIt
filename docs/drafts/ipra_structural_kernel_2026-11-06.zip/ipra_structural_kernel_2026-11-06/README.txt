A SMALLER COMPLETE PRESENTATION OF iPRA
======================================
Prepared for Vladimir Reshetnikov -- 6 November 2026 (Pacific time)

RESULT

This package gives a complete axiomatization and proof checker for full
first-order intuitionistic primitive recursive arithmetic. Its ordinary
first-order realization is bi-interpretable with iPRA on the whole number
domain. Equality defines both internal composite isomorphisms.

The complete STRICT OPEN-SEQUENT checker is below the minimum of all nine
current complete acceptance programs in the five supplied draft archives:

                                 Current minimum     New checker
  Significant source tokens             569                 547
  Normalized significant tokens         569                 553
  Executable Python AST nodes           582                 570
  Normalized UTF-8 bytes               1,762               1,751
  Raw source bytes (supplementary)     1,852               1,824

The baseline includes the smaller theorem-only and witness-erasing companions.
Every application-specific acceptance operation and the full JSON/CLI wrapper
are counted. The only imports in checker.py are Python's json and sys.
These are finite-corpus measurements, not a proof of absolute minimality.

The mathematical basis is inherited and explicitly attributed. The new
reduction combines automatic introduction, goal-determined certificate shapes,
assumption membership, a literal byte table of binding widths, positive
variable indices, and a shared validation entry point. The entry point keeps
the open-sequent interface and strictly checks witnesses of every selected
inference, including vacuous universal witnesses.

MATHEMATICAL CONTENT

report.pdf and its complete LaTeX source state every primitive rule and
arithmetic schema. The native syntax uses zero, successor, initialized
primitive recursion, equality, a guarded universal binder, and existence.
It reconstructs full intuitionistic first-order logic, successor axioms,
all primitive-recursive functions, and induction for every quantifier-free
formula, including implication and negation. The argument proves both
interpretations and their internally definable inverses, not just agreement
in the intended standard model.

The report proves cut and renaming before recovering ordinary introduction
by the closed-zero detour. It derives arbitrary number substitution only
after that step. It also explains why equation induction alone does not
justify dropping the general numerical-cases branch.

START HERE

  report.pdf                    Complete research article.
  report.tex, sections/*.tex     All LaTeX sources.
  checker.py                    Entire measured acceptance program.
  FORMAT.txt                    Exact syntax and public certificate format.
  examples/                     19 translated, executable certificates.
  translate.py                  Sequent-preserving translation and readback.
  measure.py                    Offline comparison with all 9 current checkers.
  comparison/                   Byte-identical sources and immutable provenance.
  independent_audit.py           Independent rule/binding/CLI audit driver.
  audit_support/                Named-binder oracle, cases, frozen inputs.
  roundtrip.py                  Proof round trips and coordinate checks.
  reproduce.py                  Run the complete offline verification.
  results/                      Recorded metrics, checks, and build/QA results.
  build.py                      Recompile report.pdf with pdfLaTeX.
  package.py                    Refresh the checksums and rebuild the ZIP.
  MANIFEST.sha256               Checksums of all other packaged files.
  LICENSE_SOURCE.txt            Preserved source license.

USE

Python 3.10 or newer is sufficient; no third-party Python packages or network
access are needed. Exact recorded normalization counts use CPython 3.12.14.
From this directory:

  python3 checker.py examples/reflexivity.json
  python3 checker.py examples/automatic_collision.json
  python3 reproduce.py

An accepted certificate prints ACCEPT and exits zero. A rejected certificate
prints REJECT and exits one. The public input is [goal,proof] or
[goal,proof,context], where the canonical context is a list of formulas.
Zero is the integer 0; number variables are positive de Bruijn indices.

There are no extra trusted proof generators or theorem libraries. The other
programs are untrusted support and are never imported by checker.py.

TRANSLATE A SOURCE EXAMPLE

  python3 translate.py forward audit_support/examples/reflexivity.json new.json \
    --source-checker comparison/automatic_introduction__checker.py \
    --target-checker checker.py

Use readback instead of forward for the reverse direction. Translation
renumbers numerical leaves and erases redundant proof annotations. It
preserves the mathematical sequent; proof bytes need not round-trip.

VERIFICATION

All recorded checks passed:

  - 141 curated cases, with 62 expected acceptances and 79 rejections;
  - all 62 accepted cases read back into the frozen strict source checker;
  - 384 substitution comparisons with an independent named-binder oracle;
  - 180 deterministic mutations;
  - 43 complete CLI runs, including malformed inputs and selected -O runs;
  - all 19 inherited examples translated forward and back;
  - 2,000 checks of the numerical-code substitution identity.

The groups overlap and are not counts of distinct theorems. Universal
soundness, completeness, and bi-interpretability are written mathematical
proofs, not a completed Lean/Rocq formalization. Finite tests are not an
internal consistency proof.

Every public formula and hypothesis is validated. Strict witness validation
concerns an actually selected inference. Unmatched proof data may request
the hypothesis rule; if its goal is already an assumption, ignored fields
are irrelevant metadata. Empty strings/objects are harmless empty-context
aliases. FORMAT.txt and the report explain these acceptance conventions.

BUILD AND PACKAGE

To rebuild the PDF, install a standard TeX distribution with the packages
listed in report.tex, then run:

  python3 build.py

To refresh the manifest and recreate the ZIP in the parent directory:

  python3 package.py

PINNED SOURCE

Repository: VladimirReshetnikov/ProveIt
Commit:     b41e161535c2696e4ee465142e131c6c3dab3316
Directory:  docs/drafts
URL:
https://github.com/VladimirReshetnikov/ProveIt/tree/b41e161535c2696e4ee465142e131c6c3dab3316/docs/drafts

The source directory contained five ZIP files. Their nine current root
checkers are frozen and remeasured, including every strict/erasing and
theorem/open companion. The reports' earlier 603-token / 639-AST envelope
is not used as the benchmark. Archive identities and source hashes are in
comparison/manifest.json.

The final checker SHA-256 is:
2e396e808e82fb0afd27c13671a7c12fa8ee231a15a8e262bdffc8cbf04e70b1
