"""Run the complete offline comparison and implementation verification."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True


def main():
    # Check every inherited audit support file before using it.
    provenance = json.loads((ROOT / 'audit_support/provenance.json').read_text())
    for item in provenance['files']:
        path = ROOT / 'audit_support' / item['destination']
        if hashlib.sha256(path.read_bytes()).hexdigest() != item['sha256']:
            raise ValueError('Modified inherited input: ' + str(path))
    commands = [
        [sys.executable, '-B', 'measure.py'],
        [sys.executable, '-B', 'roundtrip.py'],
        [sys.executable, '-B', 'independent_audit.py', '--candidate', 'checker.py',
         '--output', 'results/independent_audit.json'],
    ]
    for command in commands:
        subprocess.run(command, cwd=ROOT, check=True)
    result = {'status': 'passed', 'candidate_sha256':
              hashlib.sha256((ROOT / 'checker.py').read_bytes()).hexdigest(),
              'inherited_files_verified': len(provenance['files']),
              'commands': commands,
              'results': ['results/metrics.json', 'results/roundtrip.json',
                          'results/independent_audit.json']}
    # Record portable command names, not the generating machine's Python path.
    for command in result['commands']:
        command[0] = 'python3'
    (ROOT / 'results/reproduction.json').write_text(json.dumps(result, indent=2) + '\n')
    print('All comparison, translation, and independent-audit checks passed.')


if __name__ == '__main__':
    main()
