#!/usr/bin/env python3
"""Finite syntax diagnostics for the successor-rule presentation of iPRA.

Run with Python 3.10 or later; only the standard library is used::

    python3 artifacts/check_syntax.py

The output is ``syntax_checks.json`` beside this script.  The script checks
the stated tree-cost identities, fixed homomorphic parameter thinning,
capture-avoiding substitution, and literal target round trips on explicitly
bounded finite grammars.  A recursor's complete historical update tree is
charged at every occurrence.  Its descriptor is an immutable label: active
substitution and translation do not enter that label.

These are executable finite syntax checks, not a proof-assistant
formalization.  They do not prove intuitionistic soundness, arithmetic
induction, equivalence of the two closure principles, the unused-parameter
identity inside iPRA, or the full infinite bi-interpretation theorem.
Those mathematical claims require the written proofs in the report.
No tests of numerical values are used as substitutes for those proofs.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from dataclasses import dataclass
from functools import cache
from pathlib import Path
from typing import Callable, Iterable, Mapping, Union


# The formal state and counter slots of a stored descriptor are v and w.
# Declared parameter slots are ordered and are part of symbol identity.
# Their names need not be distinct from names outside their local label.
@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Succ:
    argument: Term


@dataclass(frozen=True)
class Descriptor:
    parameters: tuple[str, ...]
    body: Term


@dataclass(frozen=True)
class Rec:
    descriptor: Descriptor
    arguments: tuple[Term, ...]


@dataclass(frozen=True)
class Hat:
    """A fresh target name retaining its entire original descriptor."""

    descriptor: Descriptor
    arguments: tuple[Term, ...]


Term = Union[Var, Zero, Succ, Rec, Hat]


@dataclass(frozen=True)
class Eq:
    left: Term
    right: Term


@dataclass(frozen=True)
class Bottom:
    pass


@dataclass(frozen=True)
class Binary:
    connective: str
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Quantifier:
    quantifier: str
    variable: str
    body: Formula


Formula = Union[Eq, Bottom, Binary, Quantifier]
ZERO = Zero()
V = Var("v")
W = Var("w")
X = Var("x")


def conjunction(left: Formula, right: Formula) -> Formula:
    return Binary("and", left, right)


def disjunction(left: Formula, right: Formula) -> Formula:
    return Binary("or", left, right)


def implication(left: Formula, right: Formula) -> Formula:
    return Binary("implies", left, right)


def forall(variable: str, body: Formula) -> Formula:
    return Quantifier("forall", variable, body)


def exists(variable: str, body: Formula) -> Formula:
    return Quantifier("exists", variable, body)


def universal_close(variables: Iterable[str], body: Formula) -> Formula:
    for variable in reversed(tuple(variables)):
        body = forall(variable, body)
    return body


@cache
def term_size(term: Term) -> int:
    if isinstance(term, (Var, Zero)):
        return 1
    if isinstance(term, Succ):
        return 1 + term_size(term.argument)
    return (
        1
        + term_size(term.descriptor.body)
        + sum(term_size(argument) for argument in term.arguments)
    )


@cache
def formula_size(formula: Formula) -> int:
    if isinstance(formula, Eq):
        return 1 + term_size(formula.left) + term_size(formula.right)
    if isinstance(formula, Bottom):
        return 1
    if isinstance(formula, Binary):
        return 1 + formula_size(formula.left) + formula_size(formula.right)
    return 1 + formula_size(formula.body)


@cache
def term_free_variables(term: Term) -> frozenset[str]:
    if isinstance(term, Var):
        return frozenset((term.name,))
    if isinstance(term, Zero):
        return frozenset()
    if isinstance(term, Succ):
        return term_free_variables(term.argument)
    # A stored descriptor has its own local slots.  Do not enter it here.
    return frozenset().union(*(term_free_variables(t) for t in term.arguments))


@cache
def formula_free_variables(formula: Formula) -> frozenset[str]:
    if isinstance(formula, Eq):
        return term_free_variables(formula.left) | term_free_variables(formula.right)
    if isinstance(formula, Bottom):
        return frozenset()
    if isinstance(formula, Binary):
        return formula_free_variables(formula.left) | formula_free_variables(formula.right)
    return formula_free_variables(formula.body) - {formula.variable}


def all_active_formula_names(formula: Formula) -> frozenset[str]:
    if isinstance(formula, (Eq, Bottom)):
        return formula_free_variables(formula)
    if isinstance(formula, Binary):
        return all_active_formula_names(formula.left) | all_active_formula_names(formula.right)
    return all_active_formula_names(formula.body) | {formula.variable}


@cache
def active_occurrences(term: Term, variable: str) -> int:
    if isinstance(term, Var):
        return int(term.name == variable)
    if isinstance(term, Zero):
        return 0
    if isinstance(term, Succ):
        return active_occurrences(term.argument, variable)
    return sum(active_occurrences(t, variable) for t in term.arguments)


def equation_occurrences(equation: Eq, variable: str) -> int:
    return active_occurrences(equation.left, variable) + active_occurrences(equation.right, variable)


def term_substitute(term: Term, substitution: Mapping[str, Term]) -> Term:
    """Simultaneous substitution into active leaves; labels stay frozen."""
    if isinstance(term, Var):
        return substitution.get(term.name, term)
    if isinstance(term, Zero):
        return term
    if isinstance(term, Succ):
        return Succ(term_substitute(term.argument, substitution))
    return type(term)(
        term.descriptor,
        tuple(term_substitute(t, substitution) for t in term.arguments),
    )


def formula_substitute(formula: Formula, substitution: Mapping[str, Term]) -> Formula:
    """Capture-avoiding simultaneous substitution, with explicit renaming."""
    if isinstance(formula, Eq):
        return Eq(
            term_substitute(formula.left, substitution),
            term_substitute(formula.right, substitution),
        )
    if isinstance(formula, Bottom):
        return formula
    if isinstance(formula, Binary):
        return Binary(
            formula.connective,
            formula_substitute(formula.left, substitution),
            formula_substitute(formula.right, substitution),
        )
    reduced = {name: term for name, term in substitution.items() if name != formula.variable}
    variable, body = formula.variable, formula.body
    relevant = set(reduced) & formula_free_variables(body)
    replacement_variables = frozenset().union(
        *(term_free_variables(reduced[name]) for name in relevant)
    )
    if variable in replacement_variables:
        unavailable = (
            all_active_formula_names(body)
            | frozenset(reduced)
            | frozenset().union(*(term_free_variables(t) for t in reduced.values()))
        )
        index = 0
        while f"fresh_{index}" in unavailable:
            index += 1
        fresh = f"fresh_{index}"
        body = formula_substitute(body, {variable: Var(fresh)})
        variable = fresh
    return Quantifier(formula.quantifier, variable, formula_substitute(body, reduced))


@cache
def retained_positions(descriptor: Descriptor) -> tuple[int, ...]:
    active = term_free_variables(descriptor.body)
    return tuple(i for i, name in enumerate(descriptor.parameters) if name in active)


@cache
def tau(term: Term) -> Term:
    """Fixed source-to-target map; every recursor has a fresh hatted image."""
    if isinstance(term, (Var, Zero)):
        return term
    if isinstance(term, Succ):
        return Succ(tau(term.argument))
    if isinstance(term, Hat):
        raise TypeError("tau expects active source syntax, not a hatted call")
    keep = (0, 1) + tuple(2 + i for i in retained_positions(term.descriptor))
    return Hat(term.descriptor, tuple(tau(term.arguments[i]) for i in keep))


@cache
def sigma(term: Term) -> Term:
    """Fixed reverse map; each discarded parameter position receives 0."""
    if isinstance(term, (Var, Zero)):
        return term
    if isinstance(term, Succ):
        return Succ(sigma(term.argument))
    if isinstance(term, Rec):
        raise TypeError("sigma expects active target syntax, not a source call")
    retained = retained_positions(term.descriptor)
    parameters = [ZERO] * len(term.descriptor.parameters)
    for target_slot, source_slot in enumerate(retained, start=2):
        parameters[source_slot] = sigma(term.arguments[target_slot])
    return Rec(
        term.descriptor,
        (sigma(term.arguments[0]), sigma(term.arguments[1]), *parameters),
    )


def source_projection(term: Term) -> Term:
    """Independent statement of the source round trip's syntactic shape."""
    if isinstance(term, (Var, Zero)):
        return term
    if isinstance(term, Succ):
        return Succ(source_projection(term.argument))
    if isinstance(term, Hat):
        raise TypeError("source_projection expects source syntax")
    active = term_free_variables(term.descriptor.body)
    arguments = [source_projection(t) for t in term.arguments[:2]]
    arguments.extend(
        source_projection(argument) if parameter in active else ZERO
        for parameter, argument in zip(term.descriptor.parameters, term.arguments[2:])
    )
    return Rec(term.descriptor, tuple(arguments))


def map_formula(formula: Formula, transform: Callable[[Term], Term]) -> Formula:
    if isinstance(formula, Eq):
        return Eq(transform(formula.left), transform(formula.right))
    if isinstance(formula, Bottom):
        return formula
    if isinstance(formula, Binary):
        return Binary(
            formula.connective,
            map_formula(formula.left, transform),
            map_formula(formula.right, transform),
        )
    return Quantifier(formula.quantifier, formula.variable, map_formula(formula.body, transform))


def alpha_term_key(term: Term, bound: tuple[str, ...]) -> tuple:
    if isinstance(term, Var):
        if term.name in bound:
            return ("bound", tuple(reversed(bound)).index(term.name))
        return ("free", term.name)
    if isinstance(term, Zero):
        return ("zero",)
    if isinstance(term, Succ):
        return ("successor", alpha_term_key(term.argument, bound))
    # Descriptor equality is literal, with its own local slots.  A surrounding
    # formula quantifier never alpha-renames a historical descriptor.
    return (
        type(term).__name__,
        term.descriptor,
        tuple(alpha_term_key(t, bound) for t in term.arguments),
    )


def alpha_formula_key(formula: Formula, bound: tuple[str, ...] = ()) -> tuple:
    if isinstance(formula, Eq):
        return ("eq", alpha_term_key(formula.left, bound), alpha_term_key(formula.right, bound))
    if isinstance(formula, Bottom):
        return ("bottom",)
    if isinstance(formula, Binary):
        return (
            formula.connective,
            alpha_formula_key(formula.left, bound),
            alpha_formula_key(formula.right, bound),
        )
    return (formula.quantifier, alpha_formula_key(formula.body, bound + (formula.variable,)))


@cache
def validate_descriptor(descriptor: Descriptor) -> None:
    names = descriptor.parameters
    assert len(set(names)) == len(names)
    assert not {"v", "w"}.intersection(names)
    assert term_free_variables(descriptor.body) <= {"v", "w", *names}
    validate_term(descriptor.body, "source")


@cache
def validate_term(term: Term, language: str) -> None:
    if isinstance(term, (Var, Zero)):
        return
    if isinstance(term, Succ):
        validate_term(term.argument, language)
        return
    validate_descriptor(term.descriptor)
    if language == "source":
        assert isinstance(term, Rec)
        arity = 2 + len(term.descriptor.parameters)
    else:
        assert language == "target" and isinstance(term, Hat)
        arity = 2 + len(retained_positions(term.descriptor))
    assert len(term.arguments) == arity
    for argument in term.arguments:
        validate_term(argument, language)


def recursion_module(descriptor: Descriptor) -> Formula:
    """The entire original O_h, including all original outer quantifiers."""
    n, a = Var("n"), Var("a")
    parameters = tuple(Var(name) for name in descriptor.parameters)
    current = Rec(descriptor, (n, a, *parameters))
    update = term_substitute(descriptor.body, {"v": current, "w": n})
    base = Eq(Rec(descriptor, (ZERO, a, *parameters)), a)
    step = forall("n", Eq(Rec(descriptor, (Succ(n), a, *parameters)), update))
    return universal_close(("a", *descriptor.parameters), conjunction(base, step))


def closure(equation: Eq, parameters: tuple[str, ...], reduced: bool) -> Formula:
    """Old Z_E or new RC_E in fully expanded ordinary logical syntax."""
    assert formula_free_variables(equation) <= {"x", *parameters}
    rooted = disjunction(Eq(X, ZERO), equation)
    successor_equation = formula_substitute(equation, {"x": Succ(X)})
    successor = successor_equation
    if not reduced:
        successor = disjunction(Eq(Succ(X), ZERO), successor_equation)
    return universal_close(
        parameters,
        implication(forall("x", implication(rooted, successor)), forall("x", rooted)),
    )


def render_term(term: Term) -> str:
    if isinstance(term, Var):
        return term.name
    if isinstance(term, Zero):
        return "0"
    if isinstance(term, Succ):
        return f"S({render_term(term.argument)})"
    label = render_term(term.descriptor.body)
    parameters = ",".join(term.descriptor.parameters) or "none"
    head = "Rhat" if isinstance(term, Hat) else "R"
    arguments = ",".join(render_term(t) for t in term.arguments)
    return f"{head}[{label}; declared={parameters}]({arguments})"


def compositions(total: int, length: int):
    """All ordered positive compositions, used for exhaustive size layers."""
    if length == 0:
        if total == 0:
            yield ()
        return
    if length == 1:
        if total >= 1:
            yield (total,)
        return
    for first in range(1, total - length + 2):
        for rest in compositions(total - first, length - 1):
            yield (first, *rest)


def generate_terms(
    maximum_size: int,
    variables: tuple[str, ...],
    descriptors: tuple[Descriptor, ...],
    target: bool,
) -> list[tuple[Term, ...]]:
    """Exhaust a finite symbol alphabet up to a fully charged size bound."""
    layers: list[tuple[Term, ...]] = [()] * (maximum_size + 1)
    layers[1] = (ZERO, *(Var(name) for name in variables))
    constructor = Hat if target else Rec
    for size in range(2, maximum_size + 1):
        terms: dict[Term, None] = {Succ(t): None for t in layers[size - 1]}
        for descriptor in descriptors:
            arity = 2 + (
                len(retained_positions(descriptor)) if target else len(descriptor.parameters)
            )
            remaining = size - 1 - term_size(descriptor.body)
            for partition in compositions(remaining, arity):
                for arguments in itertools.product(*(layers[n] for n in partition)):
                    terms[constructor(descriptor, arguments)] = None
        layers[size] = tuple(terms)
        assert all(term_size(t) == size for t in layers[size])
    return layers


def require(condition: bool, description: str) -> None:
    if not condition:
        raise AssertionError(description)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("syntax_checks.json"))
    args = parser.parse_args()

    descriptors = {
        "identity": Descriptor((), V),
        "counter": Descriptor((), W),
        "successor": Descriptor((), Succ(V)),
        "successor_unused_1": Descriptor(("c0",), Succ(V)),
        "parameter_0": Descriptor(("c0",), Var("c0")),
        "parameter_1_of_2": Descriptor(("c0", "c1"), Var("c1")),
        "successor_unused_3": Descriptor(("c0", "c1", "c2"), Succ(V)),
    }
    inner = descriptors["parameter_0"]
    descriptors["frozen_parameter_only"] = Descriptor(
        ("c0", "c1"), Rec(inner, (W, V, ZERO))
    )
    descriptors["frozen_and_active_parameters"] = Descriptor(
        ("c0", "c1"), Rec(inner, (W, V, Var("c1")))
    )
    descriptors["noncontiguous_parameters"] = Descriptor(
        ("c0", "c1", "c2"),
        Rec(descriptors["successor"], (Var("c0"), Var("c2"))),
    )
    repeated_state = Rec(descriptors["identity"], (V, V))
    descriptors["two_active_state_occurrences"] = Descriptor((), repeated_state)
    descriptors["four_active_state_occurrences"] = Descriptor(
        ("c0",), Rec(descriptors["identity"], (repeated_state, repeated_state))
    )
    for descriptor in descriptors.values():
        validate_descriptor(descriptor)

    # Size seven admits active nested recursors.  Longer nested historical
    # descriptions and parameter tuples are exercised separately below.
    alphabet = tuple(descriptors.values())
    source_layers = generate_terms(7, ("x", "c0"), alphabet, target=False)
    target_layers = generate_terms(7, ("x", "c0"), alphabet, target=True)
    source_terms = tuple(itertools.chain.from_iterable(source_layers))
    target_terms = tuple(itertools.chain.from_iterable(target_layers))

    source_substitutions = (
        {"x": Succ(Var("c0")), "c0": ZERO},
        {"x": Rec(descriptors["successor_unused_1"], (X, Var("c0"), Succ(X)))},
        {"x": Var("c0"), "c0": X, "v": Succ(ZERO), "w": ZERO},
    )
    target_substitutions = tuple(
        {name: tau(term) for name, term in substitution.items()}
        for substitution in source_substitutions
    )
    source_term_substitution_checks = 0
    target_term_substitution_checks = 0
    strictly_smaller_terms = 0
    maximum_term_saving = 0
    for term in source_terms:
        validate_term(term, "source")
        image = tau(term)
        validate_term(image, "target")
        saving = term_size(term) - term_size(image)
        require(saving >= 0, "source term increased in size")
        strictly_smaller_terms += int(saving > 0)
        maximum_term_saving = max(maximum_term_saving, saving)
        require(tau(sigma(image)) == image, "target round trip is not literal identity")
        require(sigma(image) == source_projection(term), "wrong source round-trip projection")
        require(source_projection(source_projection(term)) == source_projection(term), "projection not idempotent")
        require(term_free_variables(image) <= term_free_variables(term), "translation introduced a free variable")
        for substitution in source_substitutions:
            left = tau(term_substitute(term, substitution))
            right = term_substitute(image, {name: tau(t) for name, t in substitution.items()})
            require(left == right, "tau failed literal term-substitution commutation")
            source_term_substitution_checks += 1
    for term in target_terms:
        validate_term(term, "target")
        require(tau(sigma(term)) == term, "independently generated target round trip failed")
        for substitution in target_substitutions:
            left = sigma(term_substitute(term, substitution))
            right = term_substitute(sigma(term), {name: sigma(t) for name, t in substitution.items()})
            require(left == right, "sigma failed literal term-substitution commutation")
            target_term_substitution_checks += 1

    # Every generated source term is tested as either side of a nontrivial
    # equation, and as a literal reflexivity.  Vacuous parameters are paid.
    closure_checks = 0
    closure_examples = []
    for term in source_terms:
        for equation in (Eq(term, X), Eq(term, ZERO), Eq(term, term)):
            for parameters in (("c0",), ("c0", "c1")):
                old = closure(equation, parameters, reduced=False)
                new = closure(equation, parameters, reduced=True)
                f = formula_size(equation)
                k = equation_occurrences(equation, "x")
                p = len(parameters)
                require(formula_size(old) == 3 * f + k + p + 17, "old Z_E cost mismatch")
                require(formula_size(new) == 3 * f + k + p + 12, "new RC_E cost mismatch")
                require(formula_size(old) - formula_size(new) == 5, "closure saving was not five")
                image_equation = map_formula(equation, tau)
                require(map_formula(new, tau) == closure(image_equation, parameters, True), "tau did not preserve closure form")
                require(formula_size(map_formula(new, tau)) <= formula_size(new), "closure image grew")
                closure_checks += 1
                if len(closure_examples) < 6 and parameters == ("c0",):
                    closure_examples.append({
                        "left": render_term(equation.left),
                        "right": render_term(equation.right),
                        "F": f, "k": k, "p": p,
                        "old_Z": formula_size(old), "new_RC": formula_size(new),
                        "saving": 5,
                    })

    # Full first-order syntax, including quantifiers whose names can be
    # captured by substitutions.  This is not limited to induction matrices.
    formula_terms = source_terms[::max(1, len(source_terms) // 180)]
    formulas: list[Formula] = [Bottom()]
    for term in formula_terms:
        atomic = Eq(term, X)
        formulas.extend((
            atomic,
            implication(atomic, Bottom()),
            forall("x", exists("c0", disjunction(atomic, Eq(Var("c0"), X)))),
            exists("c0", forall("x", implication(Eq(Var("c0"), X), atomic))),
            forall("x", conjunction(Eq(Var("c0"), X), forall("x", atomic))),
        ))
    formula_substitution_checks = 0
    literal_formula_substitution_checks = 0
    reverse_formula_substitution_checks = 0
    reverse_literal_formula_substitution_checks = 0
    formula_strict_savings = 0
    for formula in formulas:
        image = map_formula(formula, tau)
        require(formula_size(image) <= formula_size(formula), "full formula image grew")
        formula_strict_savings += int(formula_size(image) < formula_size(formula))
        require(map_formula(map_formula(image, sigma), tau) == image, "literal formula target round trip failed")
        for substitution in source_substitutions:
            left = map_formula(formula_substitute(formula, substitution), tau)
            right = formula_substitute(image, {name: tau(t) for name, t in substitution.items()})
            require(alpha_formula_key(left) == alpha_formula_key(right), "formula substitution did not commute up to alpha")
            literal_formula_substitution_checks += int(left == right)
            formula_substitution_checks += 1
        for substitution in target_substitutions:
            left = map_formula(formula_substitute(image, substitution), sigma)
            right = formula_substitute(
                map_formula(image, sigma),
                {name: sigma(t) for name, t in substitution.items()},
            )
            require(
                alpha_formula_key(left) == alpha_formula_key(right),
                "reverse formula substitution did not commute up to alpha",
            )
            reverse_literal_formula_substitution_checks += int(left == right)
            reverse_formula_substitution_checks += 1

    # Exercise capture avoidance directly, independently of translation.
    capture_source = forall("x", Eq(Var("c0"), X))
    capture_actual = formula_substitute(capture_source, {"c0": X})
    capture_expected = forall("z", Eq(X, Var("z")))
    require(alpha_formula_key(capture_actual) == alpha_formula_key(capture_expected), "substitution captured a free x")
    require(formula_free_variables(capture_actual) == {"x"}, "capture-avoiding free-variable set wrong")
    shadowed = forall("x", exists("x", Eq(X, Var("c0"))))
    shadowed_actual = formula_substitute(shadowed, {"c0": X})
    shadowed_expected = forall("a", exists("b", Eq(Var("b"), X)))
    require(alpha_formula_key(shadowed_actual) == alpha_formula_key(shadowed_expected), "nested shadowing was mishandled")

    module_checks = []
    for name, descriptor in descriptors.items():
        module = recursion_module(descriptor)
        image = map_formula(module, tau)
        h = term_size(descriptor.body)
        m = len(descriptor.parameters)
        s = active_occurrences(descriptor.body, "v")
        expected = 3 * h + 3 * m + 13 + s * (h + m + 2)
        require(formula_size(module) == expected, f"O_h cost mismatch for {name}")
        require(formula_size(image) <= expected, f"whole module grew for {name}")
        require(map_formula(map_formula(image, sigma), tau) == image, f"module target round trip failed for {name}")
        module_checks.append({
            "name": name, "H": h, "m": m, "active_state_occurrences": s,
            "retained_parameter_positions_zero_based": list(retained_positions(descriptor)),
            "original_module": expected, "literal_image_module": formula_size(image),
            "saving": expected - formula_size(image),
        })

    unused_parameter_family = []
    for m in range(13):
        parameters = tuple(f"c{i}" for i in range(m))
        descriptor = Descriptor(parameters, Succ(V))
        call = Rec(descriptor, (Var("n"), Var("a"), *(Var(name) for name in parameters)))
        module = recursion_module(descriptor)
        image = map_formula(module, tau)
        require(term_size(call) == m + 5 and term_size(tau(call)) == 5, "unused-parameter call formula failed")
        require(formula_size(module) == 4 * m + 23, "unused-parameter source module formula failed")
        require(formula_size(image) == m + 23, "outer quantifiers were not retained in literal image")
        unused_parameter_family.append({
            "unused_parameters": m,
            "original_call": term_size(call), "image_call": term_size(tau(call)),
            "original_module": formula_size(module), "literal_image_module": formula_size(image),
            "original_outer_quantifiers_retained": m + 1,
        })

    # Frozen labels can use the very same spelling as an outer active slot.
    # They still do not make the outer slot active.
    frozen = descriptors["frozen_parameter_only"]
    active = descriptors["frozen_and_active_parameters"]
    require(retained_positions(frozen) == (), "a local name in a frozen label was treated as an active parameter")
    require(retained_positions(active) == (1,), "active nested argument position was dropped or reordered")
    frozen_body_substituted = term_substitute(frozen.body, {"c0": Succ(ZERO), "c1": Succ(Succ(ZERO))})
    require(frozen_body_substituted == frozen.body, "substitution entered a frozen label")
    active_body_substituted = term_substitute(active.body, {"c0": Succ(ZERO), "c1": Succ(Succ(ZERO))})
    require(active_body_substituted.descriptor == inner, "nested historical label changed")
    require(active_body_substituted.arguments[2] == Succ(Succ(ZERO)), "active argument was not substituted")
    frozen_call = Rec(frozen, (X, Succ(X), Var("c0"), Var("c1")))
    active_call = Rec(active, (X, Succ(X), Var("c0"), Var("c1")))
    for call in (frozen_call, active_call):
        require(tau(sigma(tau(call))) == tau(call), "nested-label round trip failed")
        require(term_size(tau(call)) <= term_size(call), "nested-label call grew")

    noncontiguous = descriptors["noncontiguous_parameters"]
    sparse_call = Rec(noncontiguous, (Var("n"), Var("a"), Var("b"), Var("d"), Var("e")))
    sparse_image = tau(sparse_call)
    sparse_returned = sigma(sparse_image)
    require(retained_positions(noncontiguous) == (0, 2), "noncontiguous support positions were wrong")
    require(sparse_image.arguments == (Var("n"), Var("a"), Var("b"), Var("e")), "thinning reordered parameters")
    require(sparse_returned.arguments == (Var("n"), Var("a"), Var("b"), ZERO, Var("e")), "reverse map inserted zero in wrong slot")

    first_name = tau(Rec(descriptors["successor_unused_1"], (X, ZERO, ZERO)))
    second_name = tau(Rec(descriptors["successor_unused_3"], (X, ZERO, ZERO, ZERO, ZERO)))
    require(first_name != second_name, "historically distinct hatted names were accidentally identified")
    require(first_name.arguments == second_name.arguments, "fresh-name collision example malformed")

    # Local x in this descriptor is frozen.  E has no active x at all,
    # despite x contributing to the fully charged historical label size.
    local_x = Descriptor(("x",), Var("x"))
    frozen_x_term = Rec(local_x, (ZERO, ZERO, ZERO))
    frozen_x_equation = Eq(frozen_x_term, ZERO)
    require(equation_occurrences(frozen_x_equation, "x") == 0, "frozen x counted as active")
    require(term_substitute(frozen_x_term, {"x": Succ(X)}) == frozen_x_term, "frozen x substituted")
    frozen_x_old = closure(frozen_x_equation, (), False)
    frozen_x_new = closure(frozen_x_equation, (), True)
    frozen_x_f = formula_size(frozen_x_equation)
    require(formula_size(frozen_x_old) == 3 * frozen_x_f + 17, "frozen-label old closure cost failed")
    require(formula_size(frozen_x_new) == 3 * frozen_x_f + 12, "frozen-label new closure cost failed")

    result = {
        "status": "passed",
        "verification_kind": "finite deterministic syntax diagnostics, not a formal arithmetic proof",
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "cost_convention": {
            "nodes": "one per variable, constant, application, equality, logical connective, falsity, and individual quantifier",
            "recursor_labels": "every occurrence additionally pays its entire recursively frozen historical update tree",
            "target_names": "fresh hatted names; original descriptor and declared parameter list distinguish names",
            "label_substitution": "none; only active actual arguments are substituted or translated",
            "outer_quantifiers": "retained in exact images of original modules, including vacuous parameter quantifiers",
        },
        "bounded_grammars": {
            "maximum_charged_term_size": 7,
            "active_variable_alphabet": ["x", "c0"],
            "fixed_descriptor_names": list(descriptors),
            "source_terms_by_size": {str(i): len(source_layers[i]) for i in range(1, 8)},
            "target_terms_by_size": {str(i): len(target_layers[i]) for i in range(1, 8)},
            "source_term_count": len(source_terms), "target_term_count": len(target_terms),
            "scope": "exhaustive within these finite symbol alphabets and the stated charged-size bound only",
        },
        "term_checks": {
            "source_nonincrease_cases": len(source_terms),
            "source_strict_savings_cases": strictly_smaller_terms,
            "maximum_saving_in_bounded_source_grammar": maximum_term_saving,
            "literal_target_roundtrip_independent_cases": len(target_terms),
            "literal_target_roundtrip_source_image_cases": len(source_terms),
            "source_roundtrip_projection_cases": len(source_terms),
            "source_projection_idempotence_cases": len(source_terms),
            "tau_substitution_commutation_cases": source_term_substitution_checks,
            "sigma_substitution_commutation_cases": target_term_substitution_checks,
        },
        "closure_count_checks": {
            "cases": closure_checks + 1,
            "old_Z_formula": "3*F + k + p + 17",
            "new_RC_formula": "3*F + k + p + 12",
            "saving_each": 5,
            "includes": ["reflexive equations", "equations without active x", "vacuous parameters", "nested active recursors", "frozen local x"],
            "examples": closure_examples,
            "frozen_local_x_case": {"F": frozen_x_f, "k": 0, "p": 0, "old_Z": formula_size(frozen_x_old), "new_RC": formula_size(frozen_x_new)},
        },
        "full_formula_checks": {
            "formulas": len(formulas),
            "nonincrease_and_literal_target_roundtrip_cases": len(formulas),
            "strict_savings_cases": formula_strict_savings,
            "tau_substitution_commutation_up_to_alpha_cases": formula_substitution_checks,
            "also_literal_substitution_commutation_cases": literal_formula_substitution_checks,
            "sigma_substitution_commutation_up_to_alpha_cases": reverse_formula_substitution_checks,
            "sigma_also_literal_substitution_commutation_cases": reverse_literal_formula_substitution_checks,
            "connectives_tested": ["equality", "falsity", "conjunction", "disjunction", "implication", "universal quantifier", "existential quantifier"],
            "capture_avoidance": "direct free-x and nested shadowing checks passed; formula commutation uses alpha-equivalence when fresh names differ",
        },
        "whole_original_recursion_modules": {
            "source_cost_formula": "3*H + 3*m + 13 + s*(H+m+2)",
            "s": "number of active occurrences of the state slot v; historical labels are excluded",
            "cases": module_checks,
        },
        "unused_parameter_successor_family": {
            "body": "S(v)",
            "original_call_formula": "m+5", "image_call_formula": "5",
            "original_module_formula": "4*m+23", "literal_image_module_formula": "m+23",
            "cases": unused_parameter_family,
        },
        "frozen_label_and_parameter_order_checks": {
            "label_only_body": render_term(frozen.body),
            "label_only_retained_positions": list(retained_positions(frozen)),
            "active_argument_body": render_term(active.body),
            "active_argument_retained_positions": list(retained_positions(active)),
            "label_only_source_call": render_term(frozen_call),
            "label_only_target_call": render_term(tau(frozen_call)),
            "sparse_source_call": render_term(sparse_call),
            "sparse_target_call": render_term(sparse_image),
            "sparse_reverse_call": render_term(sparse_returned),
            "fresh_hatted_names_remain_distinct": True,
        },
        "limits": [
            "Finite generated tests do not replace structural proofs for all finite syntax.",
            "No arithmetic evaluator is used; these results do not prove internal recursor identities.",
            "The RC-to-Z equivalence and all iPRA bi-interpretability assertions require the report's mathematical arguments.",
            "Formula substitution is compared up to bound-variable renaming; target round trips themselves are checked as literal AST identity.",
            "Tree counts do not measure proof lengths, generator complexity, or shared-DAG compression.",
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=False) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "output": str(args.output.resolve()),
        "source_terms": len(source_terms),
        "target_terms": len(target_terms),
        "closure_count_cases": closure_checks + 1,
        "full_formulas": len(formulas),
        "original_recursion_modules": len(module_checks),
        "unused_parameter_family_cases": len(unused_parameter_family),
    }, indent=2))


if __name__ == "__main__":
    main()
