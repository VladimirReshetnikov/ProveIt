#!/usr/bin/env python3
"""Run the syntax checks and compile the complete iPRA report."""

from __future__ import annotations

import datetime
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


def main() -> None:
    root = Path(__file__).resolve().parent
    scratch = root / ".build"
    scratch.mkdir(exist_ok=True)
    artifacts = root / "artifacts"
    artifacts.mkdir(exist_ok=True)

    subprocess.run(
        [sys.executable, str(artifacts / "check_syntax.py")],
        cwd=root, check=True,
    )
    executable = shutil.which("pdflatex")
    if executable is None:
        raise SystemExit("pdflatex is required; install a standard TeX Live distribution.")

    environment = os.environ.copy()
    epoch = datetime.datetime(2026, 11, 3, 22, 49, 14,
                              tzinfo=datetime.timezone.utc)
    environment.setdefault("SOURCE_DATE_EPOCH", str(int(epoch.timestamp())))
    environment.setdefault("FORCE_SOURCE_DATE", "1")
    command = [executable, "-interaction=nonstopmode", "-halt-on-error",
               "-file-line-error", "-output-directory=.build", "report.tex"]
    for pass_number in range(1, 4):
        result = subprocess.run(command, cwd=root, env=environment,
                                text=True, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT)
        (scratch / f"pass_{pass_number}.txt").write_text(result.stdout)
        if result.returncode:
            print(result.stdout[-10000:])
            raise SystemExit(f"LaTeX pass {pass_number} failed.")

    log = (scratch / "report.log").read_text(errors="replace")
    defects = [line for line in log.splitlines()
               if "Overfull" in line or "undefined" in line.lower()
               or "Rerun to get" in line]
    shutil.copyfile(scratch / "report.pdf", root / "report.pdf")
    info = None
    if shutil.which("pdfinfo"):
        info = subprocess.run(["pdfinfo", str(root / "report.pdf")],
                              check=True, text=True, capture_output=True).stdout
    summary = {
        "latex_passes": 3,
        "syntax_checks": "artifacts/syntax_checks.json",
        "pdf": "report.pdf",
        "pdf_bytes": (root / "report.pdf").stat().st_size,
        "latex_layout_or_reference_warnings": defects,
        "pdfinfo": info,
        "mathematical_verification": "Written proofs; not a proof-assistant formalization.",
    }
    (artifacts / "build_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({"pdf_bytes": summary["pdf_bytes"],
                      "latex_warnings": defects}, indent=2))
    if defects:
        raise SystemExit("Resolve the reported LaTeX issues before delivery.")


if __name__ == "__main__":
    main()
