A small complete calculus for iPRA
=================================

Read report.pdf for the full argument. report.tex and sections/ contain
the complete editable LaTeX source. SPECIFICATION.txt gives all logical
rules, numerical formation rules, nonlogical axioms, and arithmetic rules
without requiring the report's notation.

The principal calculus has genuine intuitionistic first-order logic,
separation (0=S0)->FALSE, initialized primitive recursion, and one
equation-indexed successor rule. Its ordinary first-order axiom form
is five syntax nodes shorter per instance than the current closure draft.
The proof recovers all quantifier-free induction and establishes full
whole-carrier bi-interpretability and syntactic equiconsistency with iPRA.

A separately specified unused-parameter interpretation applies to each
of the four current drafts. It preserves the source's existing reductions
and logical interface, and never increases an exact finite formula or
axiom packet. The clean core and this exact source-relative comparison
are distinct claims; the report does not assert an absolute shortestness
theorem or a uniform proof-length improvement.

Rebuild
-------
Run from this directory:

  python3 build.py

Requirements: Python 3.10+ and a standard TeX Live installation providing
pdflatex, amsmath/amsthm/mathtools, lmodern, microtype, booktabs, longtable,
tabularx, enumitem, xcolor, fancyhdr, and hyperref.

The build runs artifacts/check_syntax.py, then three pdflatex passes.
Intermediates go in .build/. Rebuilding may change PDF metadata depending
on the installed TeX release; the mathematical sources are the authority.

Files
-----
report.pdf                   Compiled research report.
report.tex, sections/*.tex    Complete mathematical and logical description.
SPECIFICATION.txt            Standalone exact specification.
build.py                     Reproducible build entry point.
artifacts/check_syntax.py     Executable syntax/size/thinning checks.
artifacts/syntax_checks.json  Results produced by those checks.
artifacts/build_summary.json Build and verification summary.
provenance/source_manifest.json
                             Pinned GitHub paths and checked input hashes.
provenance/comparison.csv     Explicit cost formulas and their scope.
SHA256SUMS.txt                Checksums for all other packaged files.

All source comparisons refer to ProveIt commit
5753b3f955eb6681b6f89f5d778fda2b7ec8f87a.
The four current reports are sibling proposals based on earlier inputs;
their own historical source comparisons are not silently treated as
comparisons against one another.

Verification scope
------------------
The mathematical metatheorems have written proofs. The Python artifact
checks finite syntax, substitutions, round trips, and exact node counts.
It does not prove bi-interpretability by testing standard numerical values,
and it is not a Lean/Rocq formalization.
