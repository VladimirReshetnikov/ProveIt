"""Reproduce measurements and implementation validation without network access."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    for script in ('measure.py', 'validation/replay.py', 'validation/run_audit.py'):
        subprocess.run([sys.executable, script], cwd=ROOT, check=True)
    print('Reproduced all measurements, canonical replays, and independent checks.')


if __name__ == '__main__':
    main()
