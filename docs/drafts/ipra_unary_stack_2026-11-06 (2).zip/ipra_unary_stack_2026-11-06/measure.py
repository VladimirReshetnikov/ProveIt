"""Measure every pinned current checker and the delivered candidates.

The source/normalization definitions agree with the ProveIt draft series.
This script does not execute comparator programs. It verifies their hashes.
"""
from pathlib import Path
import ast
import csv
import hashlib
import io
import json
import platform
import tokenize

ROOT = Path(__file__).resolve().parent
FIELDS = ('source_tokens', 'normalized_tokens', 'ast_nodes',
          'normalized_bytes', 'raw_bytes')
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL,
           tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
           tokenize.ENDMARKER}


def main_guard(node):
    return (isinstance(node, ast.If) and isinstance(node.test, ast.Compare)
            and isinstance(node.test.left, ast.Name)
            and node.test.left.id == '__name__'
            and len(node.test.ops) == len(node.test.comparators) == 1
            and isinstance(node.test.ops[0], ast.Eq)
            and isinstance(node.test.comparators[0], ast.Constant)
            and node.test.comparators[0].value == '__main__')


def measure(path):
    raw = path.read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    omitted = []
    for node in ast.walk(tree):
        if (isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef,
                              ast.AsyncFunctionDef)) and node.body
                and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            doc = node.body.pop(0)
            omitted.append(((doc.lineno, doc.col_offset),
                            (doc.end_lineno, doc.end_col_offset)))

    def within(span, token):
        return span[0] <= token.start and token.end <= span[1]

    def tokens(text, excluded=(), retained=None):
        return sum(t.type not in IGNORED
                   and not any(within(s, t) for s in excluded)
                   and (retained is None or any(within(s, t) for s in retained))
                   for t in tokenize.generate_tokens(io.StringIO(text).readline))

    normalized = ast.unparse(tree) + '\n'
    body = [n for n in tree.body
            if not isinstance(n, (ast.Import, ast.ImportFrom))
            and not main_guard(n)]
    core = ast.Module(body=body, type_ignores=[])
    core_text = ast.unparse(core) + '\n'
    spans = [((min([n.lineno] + [d.lineno for d in getattr(n, 'decorator_list', [])]), 0),
              (n.end_lineno, n.end_col_offset)) for n in body]
    return dict(
        sha256=hashlib.sha256(raw).hexdigest(),
        source_tokens=tokens(source, omitted),
        normalized_tokens=tokens(normalized),
        ast_nodes=sum(1 for _ in ast.walk(tree)),
        normalized_bytes=len(normalized.encode()), raw_bytes=len(raw),
        core=dict(source_tokens=tokens(source, omitted, spans),
                  normalized_tokens=tokens(core_text),
                  ast_nodes=sum(1 for _ in ast.walk(core)),
                  normalized_bytes=len(core_text.encode())))


def metadata(path):
    """Explicit interface cohorts, independently visible in each CLI."""
    archive = path.parent.name
    name = path.name
    opened = any(x in archive for x in ('reduced_kernel', 'stack_kernel', 'unary_universal'))
    demand = 'demand' in name or 'text_scopes' in name
    if 'stack_kernel' in archive and name == 'checker.py':
        demand = True
    return dict(interface='sequent' if opened else 'theorem',
                validation='demand' if demand else 'strict',
                boundary='exact' if name == 'checker_exact.py' else 'prefix' if 'stack_kernel' in archive else 'tree')


def minimum(rows, core=False):
    keys = FIELDS[:-1] if core else FIELDS
    return {k: min((r['core'] if core else r)[k] for r in rows) for k in keys}


def write_program_table(baselines, candidates):
    labels = {'ipra_reduced_kernel_2026-11-06':'Reduced',
              'ipra_rigid_parameters_2026-11-06':'Rigid parameters',
              'ipra_scope_kernel_2026-11-06':'Scope',
              'ipra_stack_kernel_2026-11-06':'Stack',
              'ipra_unary_numerical_binder_2026-11-06':'Unary numerical',
              'ipra_unary_universal_2026-11-06':'Unary universal'}
    lines = [r'\begin{longtable}{@{}llrrr@{}}', r'\toprule',
             r'Program & Interface / policy & AST & Tokens & Bytes\\',
             r'\midrule', r'\endhead']
    for row in baselines:
        path = Path(row['path'])
        label = labels[path.parent.name]
        if path.name == 'checker_text_scopes.py':
            label += ' (text)'
        policy = row['interface']+' / '+row['validation']
        if row['boundary'] == 'exact':
            policy += ' / exact'
        lines.append(f"{label} & {policy} & {row['ast_nodes']} & {row['normalized_tokens']} & {row['normalized_bytes']}" + r'\\')
    lines.append(r'\midrule')
    for name, row in candidates.items():
        label = {'checker.py':'New primary', 'checker_exact.py':'New exact',
                 'checker_open.py':'New open'}[name]
        policy = 'sequent / strict' if name == 'checker_open.py' else 'theorem / strict'
        if name == 'checker_exact.py':
            policy += ' / exact'
        lines.append(f"{label} & {policy} & {row['ast_nodes']} & {row['normalized_tokens']} & {row['normalized_bytes']}" + r'\\')
    lines += [r'\bottomrule', r'\end{longtable}']
    (ROOT / 'results/program_table.tex').write_text('\n'.join(lines)+'\n')


def main():
    manifest = json.loads((ROOT / 'comparison/source_manifest.json').read_text())
    baselines = []
    for item in manifest['acceptance_programs']:
        path = ROOT / item['path']
        row = measure(path)
        if row['sha256'] != item['sha256']:
            raise ValueError('Baseline changed: ' + item['path'])
        baselines.append(dict(item, **metadata(path), **{k:v for k,v in row.items() if k != 'sha256'}))
    candidates = {}
    for name in ('checker.py', 'checker_exact.py', 'checker_open.py'):
        if (ROOT / name).is_file():
            candidates[name] = measure(ROOT / name)
    old = minimum(baselines)
    core_old = minimum(baselines, True)
    cohorts = {}
    for interface in ('theorem', 'sequent'):
        for validation in ('strict', 'demand'):
            rows = [r for r in baselines if r['interface'] == interface and r['validation'] == validation]
            if rows:
                cohorts[interface + ':' + validation] = dict(count=len(rows), whole=minimum(rows), core=minimum(rows, True))
    primary = candidates['checker.py']
    result = dict(python=platform.python_version(), commit=manifest['commit'],
                  archive_count=len(manifest['drafts']), program_count=len(baselines),
                  baselines=baselines, candidates=candidates,
                  minima=old, core_minima=core_old, cohorts=cohorts,
                  primary_below_whole_minima={k:primary[k] < old[k] for k in FIELDS},
                  primary_below_core_minima={k:primary['core'][k] < core_old[k] for k in FIELDS[:-1]})
    (ROOT / 'results/metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    with (ROOT / 'results/metrics.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=['kind', 'path', *FIELDS], extrasaction='ignore')
        writer.writeheader()
        for r in baselines:
            writer.writerow(dict(r, kind='baseline'))
        for name,r in candidates.items():
            writer.writerow(dict(r, kind='candidate', path=name))
    labels = dict(source_tokens='SourceTokens', normalized_tokens='Tokens',
                  ast_nodes='AST', normalized_bytes='Bytes', raw_bytes='Raw')
    lines = ['% Generated by measure.py; do not hand-edit.']
    for prefix, row in [('Old', old), ('New', primary), ('OldCore', core_old), ('NewCore', primary['core'])]:
        for key,suffix in labels.items():
            if key in row:
                lines.append('\\newcommand{\\'+prefix+suffix+'}{'+str(row[key])+'}')
    (ROOT / 'results/metrics.tex').write_text('\n'.join(lines)+'\n')
    write_program_table(baselines, candidates)
    print(json.dumps({k:result[k] for k in ['python','archive_count','program_count','minima','core_minima','primary_below_whole_minima','primary_below_core_minima']}, indent=2))
    print('Primary:', {k:primary[k] for k in FIELDS})
    if not all(result['primary_below_whole_minima'].values()):
        raise SystemExit('The stated whole-program strict reduction did not reproduce.')


if __name__ == '__main__':
    main()
