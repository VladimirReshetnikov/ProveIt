"""Rebuild report.pdf using a standard TeX Live installation."""
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def typeset(engine, extra=()):
    for _ in range(3):
        result = subprocess.run([engine, *extra, '-interaction=nonstopmode',
                                 '-halt-on-error', '-file-line-error', 'report.tex'],
                                cwd=ROOT, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True)
        (ROOT / 'results/latex_build.txt').write_text(result.stdout)
        if result.returncode:
            print(result.stdout[-14000:])
            raise SystemExit(result.returncode)
    log = (ROOT / 'report.log').read_text(errors='replace')
    problems = ['undefined references', 'Citation ', 'Reference ']
    if any(p in log and 'undefined' in log for p in problems):
        raise SystemExit('Resolve the undefined references recorded in report.log.')
    print('Built report.pdf')


def main():
    engine = shutil.which('pdflatex')
    if engine is None:
        raise SystemExit('Install pdfLaTeX. A compiled report.pdf is supplied.')
    found = subprocess.run(['kpsewhich', 'pdflatex.fmt'], capture_output=True,
                           text=True).stdout.strip()
    if found:
        typeset(engine)
    else:
        with tempfile.TemporaryDirectory(prefix='ipra-unary-stack-tex-') as directory:
            result = subprocess.run(['pdftex', '-ini', '-jobname=pdflatex',
                                     '-progname=pdflatex', '-etex', 'pdflatex.ini'],
                                    cwd=directory, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, text=True)
            if result.returncode:
                print(result.stdout[-14000:])
                raise SystemExit(result.returncode)
            typeset(engine, ['-fmt=' + str(Path(directory) / 'pdflatex.fmt')])


if __name__ == '__main__':
    main()
