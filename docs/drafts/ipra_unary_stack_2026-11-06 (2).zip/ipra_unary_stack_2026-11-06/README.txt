A SMALLER COMPLETE CHECKER FOR iPRA
Unary closure and a proof stack
Prepared for Vladimir Reshetnikov, 6 November 2026

READ FIRST

report.pdf contains the complete research report. Its source is report.tex
plus sections/ and the generated tables in results/.

MAIN RESULT

The primary strict theorem checker is below the coordinatewise minimum of
all fourteen current top-level checkers in the six supplied ProveIt draft
archives, pinned to commit b9aefe20fe876273886d5d55be49e6ccbefce9ad.

                              Current minimum     New primary
Significant source tokens                 522             515
Normalized tokens                         526             519
Python AST nodes                          537             531
Normalized UTF-8 bytes                   1633            1621
Raw UTF-8 bytes                          1683            1673

This is a finite-corpus proof-presentation improvement, not an absolute
minimality theorem. The inherited arithmetic basis is not reduced further.
The new checker integrates unary numerical closure, proof stacks, rigid
free parameter names, and removal of redundant syntax-validation passes.

The report specifies every native rule and computation schema, reconstructs
full intuitionistic logic and quantifier-free induction, and proves that
the ordinary theory faithfully presented by the native calculus is
bi-interpretable and equiconsistent with full first-order iPRA. Both ordinary
interpretations use the whole number domain; identity is the definable
isomorphism for each composite. Here iPRA explicitly means the full
intuitionistic first-order theory with quantifier-free induction, as in the
inspected drafts. The report distinguishes it from restricted equational
presentations.

The metatheory is proved in mathematical prose. No complete Lean or Rocq
formalization is claimed. Executed independent tests are implementation
evidence and are identified separately from the general proofs.

CORE COMPARISON QUALIFICATION

After uniformly removing imports and command-line blocks, the new core has
457 source tokens, 461 normalized tokens, 465 AST nodes, and 1360 normalized
bytes. Across all current cores, the respective minima are 459,461,468,1324.
Thus source tokens and AST improve, normalized tokens tie, and normalized
bytes do not improve. Against every strict current checker, all four core
measures improve. Matched strict open-sequent comparisons are also supplied.

PUBLIC INTERFACES

  checker.py        Input [goal, stack]; initial context forced empty.
                    Strict active-witness validation; unused bottom stack
                    prefix allowed, matching the prior stack convention.
  checker_exact.py  Same theorem interface and rules; requires exhaustion.
  checker_open.py   Input [goal, stack, [H0, H1, ...]]; validates external
                    hypotheses; same strict active-witness policy.

All three have the same derivable well-formed theorem set. The primary
in-process check(goal, stack, context) function assumes its context has
been constructed internally; it is not an arbitrary open-sequent boundary.
The separate open companion is the external-context interface.

See FORMAT.txt for exact syntax, finite-tree assumptions, rule order,
negative parameter names, and how failed major attempts may consume cells
before a sound hypothesis fallback. Soundness extracts successful rule
branches; it does not assert that every consumed cell belongs to one
canonical proof. Canonical examples exhaust their stacks in every checker.

QUICK START

Use Python 3.10 or newer. Exact recorded normalization uses CPython 3.12.14.
Only the Python standard library is needed for validation.

  python3 checker.py examples/equation_induction.json
  python3 checker_exact.py examples/rigid_reflexivity_parameter.json
  python3 reproduce.py

The first two commands print ACCEPT. The third remeasures all programs,
verifies baseline hashes, replays 60 canonical certificates, and runs the
independent named-variable audit. Reproduction requires no network access.

  python3 build.py
  python3 package.py

The build command requires a standard TeX Live/pdfLaTeX installation. The
compiled PDF is supplied. The package command writes the ZIP and rebuilds
MANIFEST.sha256. All archive paths are relative and no original checkout
is required.

EXECUTED EVIDENCE

- All fourteen unmodified comparator-source hashes verified.
- Sixty converted certificates accepted by all three checkers: 180 imported
  function checks and 180 command-line checks; every stack exhausted.
- Independent named-variable oracle: 66 targeted cases and 81 inherited
  sequents, including negative parameter capture and eigenvariable checks.
- 1600 mutated certificates: no candidate/oracle disagreement; 88 accepted
  by both (mutations are not assumed invalid).
- 2400 independent named-variable substitution comparisons: no disagreement.
- 24 primary and 24 companion command-line boundary checks, including -O.

These finite checks overlap and do not replace the mathematical proofs.
The implementation may reject valid certificates that exceed actual
interpreter resources; the mathematical calculus has no fixed size bound.

CONTENTS

report.pdf, report.tex, sections/   Complete article and LaTeX sources
checker*.py                       Three standalone acceptance programs
FORMAT.txt                        Exact syntax and public contracts
examples/                         Sixty canonical accepted certificates
validation/                       Independent oracle, fixtures, replay, audit
comparison/sources/               All fourteen current sources, unchanged
comparison/source_manifest.json   Pinned archive and source identities
results/                          Source metrics and canonical replay results
measure.py, reproduce.py           Measurement and verification commands
build.py, package.py               PDF generation and deterministic packaging
LICENSE_SOURCE.txt                Inherited MIT No Attribution license
MANIFEST.sha256                   Delivered-file integrity hashes

ATTRIBUTION

The native unary-closure theory, formula gates/selectors, arithmetic
reflection, and ordinary bi-interpretations come from the pinned unary
numerical binder and unary universal drafts. Stack certificates and rigid
parameter syntax come from the corresponding pinned drafts. This package
adds the integrated complete checker and its validation and comparison.
The report explicitly credits inherited mathematics and source material.
