"""Reproduce 60 stack certificates from the 30 included source tree fixtures.

The transformer is audit support, not an acceptance dependency. Every original
is checked by the unchanged pinned unary-Q tree checker. Each output is checked
by all three delivered programs, both as a function and through their public
command-line interfaces. All these certificates exhaust their stacks.
"""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'comparison/sources/ipra_unary_numerical_binder_2026-11-06/checker.py'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


old = load('tree_checker', SOURCE)
CANDIDATES = {name: load(name.removesuffix('.py'), ROOT / name)
              for name in ('checker.py', 'checker_exact.py', 'checker_open.py')}


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def convert(expression, depth=0, rigid=False):
    """Optionally replace ordinary free positive coordinates by rigid names."""
    if type(expression) is int:
        return -(expression - depth) if rigid and expression > depth else expression
    tag, *args = expression
    widths = {'s': [0], 'r': [0, 0, 2], '=': [0, 0], 'q': [1], 'ex': [1]}[tag]
    return [tag] + [convert(body, depth + width, rigid)
                    for body, width in zip(args, widths, strict=True)]


def compile_proof(goal, proof, context=(), depth=0, rigid=False):
    """Emit canonical stack instructions in execution order, before reversal."""
    cv = lambda value, extra=0: convert(value, depth + extra, rigid)
    if goal[0] == 'q' and type(proof) is list and len(proof) == 1:
        body = goal[1]
        hypotheses = [old.subst(body, [0, 0])] + ([body] if body[0] == '=' else [])
        child = old.subst(body, [['s', 1], 0])
        return [[]] + compile_proof(child, proof[0],
                                   [*map(old.subst, context), *hypotheses],
                                   depth + 1, rigid)
    if goal[0] == 'ex' and type(proof) is list and len(proof) == 2:
        witness, child = proof
        hypothesis = ['=', 1, old.subst(witness, formula=False)]
        return [[cv(witness)]] + compile_proof(goal[1], child,
                                             [*map(old.subst, context), hypothesis],
                                             depth + 1, rigid)
    if type(proof) is list and len(proof) >= 2 and type(proof[0]) is list:
        major, major_proof, *args = proof
        if old.check(major, major_proof, context):
            tag, *parts = major
            if tag == 'ex':
                child, = args
                return ([[cv(major), None]]
                        + compile_proof(major, major_proof, context, depth, rigid)
                        + compile_proof(old.subst(goal), child,
                                        [*map(old.subst, context), *parts],
                                        depth + 1, rigid))
            witness, child = args
            if tag == 'q':
                minor = old.subst(parts[0], [0, -1])
                annotation = cv(witness)
            else:
                minor = old.subst(witness, [parts[0], -1])
                annotation = cv(witness, 1)
            return ([[cv(major), annotation]]
                    + compile_proof(major, major_proof, context, depth, rigid)
                    + compile_proof(minor, child, context, depth, rigid))
    return [[] if proof == 'r' else None]


def main():
    fixtures = json.loads((ROOT / 'validation/fixtures_tree.json').read_text())
    results = []
    output = ROOT / 'examples'
    output.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='ipra_stack_replay_') as temporary:
        open_input = Path(temporary) / 'open.json'
        for fixture in fixtures:
            goal, tree = fixture['document']
            require(old.check(goal, tree, []), 'Source proof rejected: ' + fixture['name'])
            for rigid in (False, True):
                translated = convert(goal, 0, rigid)
                stack = list(reversed(compile_proof(goal, tree, rigid=rigid)))
                name = ('rigid_' if rigid else '') + fixture['name']
                document = [translated, stack]
                path = output / (name + '.json')
                path.write_text(json.dumps(document, separators=(',', ':')) + '\n')
                open_input.write_text(json.dumps([translated, stack, []]) + '\n')
                observations = {}
                for filename, candidate in CANDIDATES.items():
                    remaining = copy.deepcopy(stack)
                    require(candidate.check(translated, remaining, []),
                            filename + ' rejected ' + name)
                    require(not remaining, filename + ' left stack cells in ' + name)
                    input_path = open_input if filename == 'checker_open.py' else path
                    process = subprocess.run([sys.executable, str(ROOT / filename), str(input_path)],
                                             text=True, capture_output=True, check=False)
                    require(process.returncode == 0 and process.stdout.strip() == 'ACCEPT',
                            filename + ' CLI rejected ' + name + ': ' + process.stdout + process.stderr)
                    observations[filename] = {'accepted': True, 'remaining_cells': 0,
                                              'cli_status': process.returncode}
                results.append({'name': name, 'rigid_parameters': rigid,
                                'stack_cells': len(stack), 'checkers': observations})
    record = {
        'source_tree_count': len(fixtures),
        'accepted_certificate_count': len(results),
        'function_checks': len(results) * len(CANDIDATES),
        'cli_checks': len(results) * len(CANDIDATES),
        'all_three_checkers_accept': True,
        'all_stacks_exhausted': True,
        'source_checker_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        'candidate_sha256': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                             for name in CANDIDATES},
        'results': results,
    }
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results/replay.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({key: value for key, value in record.items() if key != 'results'}, indent=2))


if __name__ == '__main__':
    main()
