INDEPENDENT VALIDATION
======================

From the package root, run:

    python3 validation/run_audit.py

The default candidate is ../checker.py relative to this directory. The
checker_exact.py and checker_open.py companions must be beside it. A different
candidate may be supplied explicitly. No original repository checkout or
network connection is needed. The ordinary Python 3.10+ standard library is
sufficient. The driver writes validation/audit_results.json.

To regenerate the 66 targeted certificates and their reference self-check:

    python3 validation/build_fixtures.py

The 81 inherited proofs are supplied directly as portable stack certificates.
Their original source and transformation are recorded in ATTRIBUTION.txt.

The audit checks:

* 66 targeted valid and invalid sequents, including distinct negative names,
  capture beneath two binders, recursion-variable order, equality transport,
  rejected compound induction hypotheses, escaping existential eigenvariables,
  malformed terms and formulas, and strict universal-witness validation.
* 81 inherited arithmetic and logical proof sequents against a separate
  named-variable reference interpreter. Its exact mode also confirms that
  canonical inherited proofs use the whole stack.
* 1,600 deterministic mutations of valid certificate documents. Both acceptance
  and rejection are compared; accepting harmless inactive data is permitted.
* 2,400 sorted substitutions compared with named substitution, using nested
  numerical/formula binders and rigid negative parameters.
* 24 command-line tests of the primary theorem checker, with and without -O.
* 24 command-line tests of the exact and open companion policies, with and
  without -O. The exact companion rejects unused lower stack cells. The open
  companion validates its explicit context before accepting a sequent.

The primary input is [goal, stack]. Its core check(goal, stack, context)
function assumes an internally well-formed context; the hostile-input
boundary is its command-line wrapper. The open companion accepts
[goal, stack, context] and validates all supplied assumptions. A theorem is
an accepted sequent with empty context.

The prefix policy permits unused lower stack cells. A failed but well-formed
major proof can consume instructions before falling back to the hypothesis
rule. Soundness extracts only the inferences that actually support success;
it need not identify the entire consumed suffix with one canonical derivation.
The targeted fallback fixture also verifies that exact-stack acceptance can
contain such harmless failed attempts even after every cell is consumed.

These finite checks are evidence for the implementation. They are not a
machine-checked proof of soundness, completeness, or bi-interpretability.
The mathematical argument is in the accompanying paper. The reference
interpreter is independent of the candidate's coordinate implementation,
but retains disclosed ancestry from a previous sorted named-variable oracle.
