"""Small independent certificates targeting calculus boundaries."""
import json
from pathlib import Path
from named_oracle import accept_document, accept_sequent, substitution

ROOT = Path(__file__).resolve().parent


def refl(t):
    seed = ['r', 0, t, 0]
    major = ['=', seed, t]
    motive = ['=', 1, substitution(t, formula=False)]
    return [[], [], [major, motive]]


fixtures = []

def add(name, goal, stack, expected, *, context=(), strict_expected=None):
    fixtures.append(dict(name=name, goal=goal, stack=stack,
                         context=list(context), expected=expected,
                         strict_expected=expected if strict_expected is None else strict_expected))


falsehood = ['=', 0, ['s', 0]]
truth = ['=', 0, 0]
add('no_falsehood_axiom', falsehood, [None], False)
add('zero_computation', ['=', ['r',0,0,1], 0], [[]], True)
add('rigid_zero_computation', ['=', ['r',0,-1,1], -1], [[]], True)
add('rigid_update_is_not_accumulator', ['=', ['r',['s',0],-1,-2], -2], [[]], True)
add('rigid_update_does_not_capture', ['=', ['r',['s',0],-1,-2], -1], [[]], False)
add('rigid_update_with_positive_counter', ['=', ['r',['s',3],-1,-2], -2], [[]], True)
add('counter_one_means_accumulator', ['=', ['r',['s',0],-1,1], ['r',0,-1,1]], [[]], True)
add('counter_two_means_predecessor', ['=', ['r',['s',0],-1,2], 0], [[]], True)
add('variable_counter_is_not_successor', ['=', ['r',1,-1,1], -1], [[]], False)
add('recursive_counter_is_not_successor', ['=', ['r',['r',0,0,0],-1,1], -1], [[]], False)

exist_rigid = ['ex',['=',1,-1]]
add('rigid_existential_witness', exist_rigid, [None,[-1]], True)
add('distinct_rigid_witnesses', exist_rigid, [None,[-2]], False)
add('rigid_negative_under_two_binders', ['q', exist_rigid], [None,[-1],[]], True)
add('rigid_witness_not_numerical_binder', ['q',['=',1,-1]], [None,[]], False)
add('rigid_parameter_not_generalized', ['q',['=',-1,1]], [None,[]], False)

exist_zero = ['ex',['=',1,0]]
add('existential_eigenvariable_cannot_escape', ['=',1,0],
    [None,None,[0],[exist_zero,None]], False)
add('existential_rigid_name_cannot_change', ['=',-1,-2],
    [None,None,[-1],[exist_rigid,None]], False)
add('nested_rigid_existential_roundtrip', ['q',exist_rigid],
    [None,[-1],None,[-1],[exist_rigid,None],[]], True)

# B(x)=exists z(z=x). The explicit step can be proved without induction,
# but this particular attempted certificate requires a forbidden compound IH.
by = ['ex',['=',1,2]]
add('compound_IH_must_be_absent', ['q',by],
    [None,[['s',2]],None,[by,None],[]], False)
add('compound_case_direct_witness_is_allowed', ['q',by],
    [None,[['s',1]],[]], True)

add('reflexivity_of_rigid_parameter', ['=',-1,-1], refl(-1), True)
add('reflexivity_of_positive_parameter', ['=',1,1], refl(1), True)
add('reflexivity_of_compound_term', ['=',['s',-1],['s',-1]], refl(['s',-1]), True)
add('reflexivity_under_recursion_scope', ['=', ['r',2,-1,['s',1]], ['r',2,-1,['s',1]]],
    refl(['r',2,-1,['s',1]]), True)

major = ['=', ['r',0,-1,0], -1]
motive = ['q',['ex',['=',1,3]]]
add('equality_transport_beneath_two_binders', ['q',exist_rigid],
    [None,[['r',0,-1,0]],[],[],[major,motive]], True)

vacuous = ['q',truth]
add('vacuous_Q_ignores_unused_annotation', truth,
    refl(0) + [None,[],[vacuous,{'inactive':'payload'}]], True, strict_expected=False)
nonvacuous = ['q',['=',1,1]]
add('active_Q_rejects_boolean_witness', truth,
    refl(0) + refl(['s',1]) + [[],[nonvacuous,True]], False)
add('active_Q_rejects_formula_as_term', truth,
    refl(0) + refl(['s',1]) + [[],[nonvacuous,['ex',truth]]], False)
add('active_Q_accepts_rigid_witness', ['=',-2,-2],
    refl(0) + refl(['s',1]) + [[],[nonvacuous,-2]], True)

bad = [True, False, 1.0, None, '', [], ['s'], ['s',0,0], ['=',0,0], ['r',0,0], ['bad',0]]
for i, term in enumerate(bad):
    add('malformed_term_%02d'%i, ['=',term,term], [None], False)
    add('malformed_existential_witness_%02d'%i, exist_zero, [None,[term]], False)
for i, formula in enumerate([0, True, None, [], ['s',0], ['=',0], ['=',0,0,0], ['q'], ['q',truth,truth], ['ex',0], ['pi',truth,truth]]):
    add('malformed_formula_%02d'%i, formula, [None], False)

add('assumption_is_allowed_in_sequent_API', truth, [None], True, context=[truth])
add('unvalidated_hypothesis_is_rejected', truth, [None], False, context=[True])
add('unused_prefix_is_permitted', truth, [{'unused':'prefix'}, *refl(0)], True)
add('failed_major_attempt_can_fall_back_to_hypothesis', ['q',truth],
    [None,[falsehood,None],[]], True)

if __name__ == '__main__':
    rows = []
    for f in fixtures:
        got = accept_sequent(f['goal'], f['stack'], f['context'])
        strict = accept_sequent(f['goal'], f['stack'], f['context'], strict=True)
        rows.append(dict(name=f['name'], expected=f['expected'], got=got,
                         strict_expected=f['strict_expected'], strict=strict,
                         pass_=got == f['expected'] and strict == f['strict_expected']))
    (ROOT/'fixtures.json').write_text(json.dumps(fixtures, indent=2)+'\n')
    (ROOT/'oracle_selfcheck.json').write_text(json.dumps(rows, indent=2)+'\n')
    failed = [r for r in rows if not r['pass_']]
    print(json.dumps(dict(count=len(rows), failures=failed), indent=2))
    if failed:
        raise SystemExit(1)
