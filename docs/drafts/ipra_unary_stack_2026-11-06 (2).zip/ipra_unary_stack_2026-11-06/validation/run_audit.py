"""Reproducible independent binding and derivation audit for a stack checker.

Only this driver imports the candidate. named_oracle.py does not. The inherited
positive proof corpus is translated from trees into reverse preorder stacks;
its source and every compared candidate are hashed in the output.
"""
import argparse
import copy
import hashlib
import importlib.util
import json
import random
import subprocess
import sys
import tempfile
from pathlib import Path

from named_oracle import accept_document, accept_sequent, substitution

ROOT = Path(__file__).resolve().parent


def load(path):
    spec = importlib.util.spec_from_file_location('audited_candidate', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def candidate_accept(module, goal, stack, context=()):
    try:
        return bool(module.check(copy.deepcopy(goal), copy.deepcopy(stack),
                                 copy.deepcopy(list(context))))
    except Exception:
        return False


def tree_to_preorder(proof):
    """Translate canonical tree proofs, without querying the candidate."""
    if proof == 'r':
        return [[]]
    if type(proof) is list:
        if len(proof) == 1:
            return [[]] + tree_to_preorder(proof[0])
        if len(proof) == 2:
            return [[proof[0]]] + tree_to_preorder(proof[1])
        if len(proof) == 3:
            return [[proof[0], None]] + tree_to_preorder(proof[1]) + tree_to_preorder(proof[2])
        if len(proof) == 4:
            return [[proof[0], proof[2]]] + tree_to_preorder(proof[1]) + tree_to_preorder(proof[3])
    return [None]


def inherited_rows(example_root):
    rows = []
    inputs = [example_root/'generated_sequents.json', example_root/'logic/logic_sequents.json']
    for path in inputs:
        for row in json.loads(path.read_text()):
            rows.append(dict(name='inherited/'+row['name'], goal=row['goal'],
                             stack=list(reversed(tree_to_preorder(row['proof']))),
                             context=row['context'],
                             expected=row.get('accepted', row.get('kernel_accepted'))))
    return rows, inputs


def locations(value, prefix=()):
    yield prefix
    if type(value) is list:
        for i, child in enumerate(value):
            yield from locations(child, prefix+(i,))


def changed(value, path, replacement):
    result = copy.deepcopy(value)
    if not path:
        return replacement
    current = result
    for i in path[:-1]:
        current = current[i]
    current[path[-1]] = replacement
    return result


def random_term(rng, depth=3):
    if depth <= 0 or rng.random() < .42:
        return rng.choice([-3,-2,-1,0,1,2,3,4,5,7])
    if rng.random() < .45:
        return ['s',random_term(rng,depth-1)]
    return ['r',random_term(rng,depth-1),random_term(rng,depth-1),random_term(rng,depth-1)]


def random_formula(rng, depth=3):
    if depth <= 0 or rng.random() < .5:
        return ['=',random_term(rng),random_term(rng)]
    return [rng.choice(['q','ex']),random_formula(rng,depth-1)]


def cli_check(path, document, optimized=False):
    with tempfile.NamedTemporaryFile('w',suffix='.json',encoding='utf-8') as f:
        json.dump(document,f)
        f.flush()
        command=[sys.executable]
        if optimized:
            command.append('-O')
        command += [str(path),f.name]
        run=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                           text=True,timeout=10)
        return run.returncode == 0 and run.stdout.strip() == 'ACCEPT'


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('candidate',type=Path,nargs='?',default=ROOT.parent/'checker.py')
    parser.add_argument('--examples',type=Path)
    parser.add_argument('--output',type=Path,default=ROOT/'audit_results.json')
    args=parser.parse_args()
    candidate=load(args.candidate)
    fixed=json.loads((ROOT/'fixtures.json').read_text())
    rows=[]
    failures=[]
    for f in fixed:
        expected=f['strict_expected']
        actual=candidate_accept(candidate,f['goal'],f['stack'],f['context'])
        oracle=accept_sequent(f['goal'],f['stack'],f['context'],strict=True)
        result=dict(name=f['name'],candidate=actual,oracle=oracle,expected=expected)
        rows.append(result)
        if actual != expected or oracle != expected:
            failures.append(result)

    inherited=[]
    inputs=[]
    if args.examples:
        inherited,inputs=inherited_rows(args.examples)
        (ROOT/'inherited_stack_fixtures.json').write_text(json.dumps(inherited,indent=2)+'\n')
    elif (ROOT/'inherited_stack_fixtures.json').is_file():
        fixture_path=ROOT/'inherited_stack_fixtures.json'
        inherited=json.loads(fixture_path.read_text())
        inputs=[fixture_path]
    for f in inherited:
        actual=candidate_accept(candidate,f['goal'],f['stack'],f['context'])
        oracle=accept_sequent(f['goal'],f['stack'],f['context'],strict=True,exact=True)
        result=dict(name=f['name'],candidate=actual,oracle=oracle,expected=f['expected'])
        rows.append(result)
        if actual != f['expected'] or oracle != f['expected']:
            failures.append(result)

    rng=random.Random(2026110703)
    mutation_failures=[]
    mutation_acceptances=0
    pool=[r for r in fixed+inherited if r.get('strict_expected',r['expected'])]
    replacements=[None, True, False, 0, -1, 1, 1.0, [], {}, '', ['s'], ['bad',0], ['=',0,0], ['q',['=',0,0]]]
    for index in range(1600):
        base=rng.choice(pool)
        document=[base['goal'],base['stack']]
        path=rng.choice(list(locations(document)))
        replacement=copy.deepcopy(rng.choice(replacements))
        mutated=changed(document,path,replacement)
        if type(mutated) is list and len(mutated)==2:
            actual=candidate_accept(candidate,mutated[0],mutated[1],base['context'])
            oracle=accept_sequent(mutated[0],mutated[1],base['context'],strict=True)
        else:
            actual=False
            oracle=False
        mutation_acceptances+=actual
        if actual!=oracle:
            mutation_failures.append(dict(index=index,base=base['name'],path=path,
                                          replacement=replacement,candidate=actual,oracle=oracle,
                                          mutated=mutated,context=base['context']))

    substitution_failures=[]
    for index in range(2400):
        formula=bool(rng.randrange(2))
        expression=random_formula(rng) if formula else random_term(rng)
        width=rng.randrange(4)
        environment=[random_term(rng,2) for _ in range(width)] + [rng.choice([-width,0,1,2])]
        depth=rng.randrange(4)
        actual=candidate.subst(expression,environment,depth,formula)
        oracle=substitution(expression,environment,depth,formula)
        if actual != oracle:
            substitution_failures.append(dict(index=index,expression=expression,
                                               environment=environment,depth=depth,formula=formula,
                                               candidate=actual,oracle=oracle))

    # Check actual theorem-only command-line boundary and Python -O.
    accepted=[r for r in fixed if r['strict_expected'] and not r['context']]
    cli_docs=[dict(name='cli/'+r['name'],document=[r['goal'],r['stack']],expected=True)
              for r in accepted[:8]]
    cli_docs += [
        dict(name='cli/extra_hypothesis_not_allowed',document=[['=',0,['s',0]],[None],['=',0,['s',0]]],expected=False),
        dict(name='cli/malformed_top_level',document={'goal':['=',0,0]},expected=False),
        dict(name='cli/empty_stack',document=[['=',0,0],[]],expected=False),
        dict(name='cli/boolean_term',document=[['=',True,True],[None]],expected=False),
    ]
    cli_rows=[]
    for r in cli_docs:
        for optimized in (False,True):
            actual=cli_check(args.candidate,r['document'],optimized)
            result=dict(name=r['name'],optimized=optimized,expected=r['expected'],candidate=actual)
            cli_rows.append(result)
            if actual!=r['expected']:
                failures.append(result)

    # Companion policies are checked through their actual public CLI.
    valid=next(r for r in fixed if r['name']=='reflexivity_of_rigid_parameter')
    valid_doc=[valid['goal'],valid['stack']]
    prefix_doc=[valid['goal'],[{'unused':'prefix'},*valid['stack']]]
    fallback=next(r for r in fixed if r['name']=='failed_major_attempt_can_fall_back_to_hypothesis')
    falsehood=['=',0,['s',0]]
    true=['=',0,0]
    companion_specs={
        'checker_exact.py':[
            ('canonical_theorem',valid_doc,True),
            ('unused_prefix_rejected',prefix_doc,False),
            ('failed_major_fallback_consumes_all',[fallback['goal'],fallback['stack']],True),
            ('no_public_assumptions',[falsehood,[None],[falsehood]],False),
            ('empty_stack',[true,[]],False),
            ('falsehood_rejected',[falsehood,[None]],False),
        ],
        'checker_open.py':[
            ('canonical_empty_context',valid_doc+[[]],True),
            ('prefix_allowed',prefix_doc+[[]],True),
            ('assumption_sequent',[falsehood,[None],[falsehood]],True),
            ('malformed_context_rejected',[true,[None],[true,True]],False),
            ('explicit_context_required',valid_doc,False),
            ('falsehood_empty_context',[falsehood,[None],[]],False),
        ],
    }
    companion_rows=[]
    companion_hashes={}
    for filename,tests in companion_specs.items():
        companion=args.candidate.with_name(filename)
        if not companion.is_file():
            failures.append(dict(companion=filename,error='missing companion'))
            continue
        companion_hashes[filename]=hashlib.sha256(companion.read_bytes()).hexdigest()
        for name,document,expected in tests:
            for optimized in (False,True):
                actual=cli_check(companion,document,optimized)
                result=dict(companion=filename,name=name,optimized=optimized,
                            expected=expected,candidate=actual)
                companion_rows.append(result)
                if actual!=expected:
                    failures.append(result)

    report=dict(
        candidate=str(args.candidate),candidate_sha256=hashlib.sha256(args.candidate.read_bytes()).hexdigest(),
        companion_sha256=companion_hashes,
        oracle_sha256=hashlib.sha256((ROOT/'named_oracle.py').read_bytes()).hexdigest(),
        source_provenance=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in inputs],
        targeted_cases=len(fixed),inherited_cases=len(inherited),
        targeted_and_inherited_failures=failures,
        mutation_count=1600,mutation_acceptances=mutation_acceptances,mutation_failures=mutation_failures,
        substitution_count=2400,substitution_failures=substitution_failures,
        cli_cases=len(cli_rows),companion_cli_cases=len(companion_rows),seed=2026110703,
        fixed_results=rows,cli_results=cli_rows,companion_cli_results=companion_rows,
        limitation='Finite tests support but do not prove general soundness or completeness; the oracle is independent of candidate coordinate substitution and uses named sorted ASTs.')
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    summary={k:v for k,v in report.items() if k not in ('fixed_results','cli_results','companion_cli_results','source_provenance')}
    print(json.dumps(summary,indent=2))
    return bool(failures or mutation_failures or substitution_failures)

if __name__=='__main__':
    raise SystemExit(main())
