"""Create a deterministic ZIP of the delivered files and an integrity manifest."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED = {'.aux', '.log', '.out', '.toc', '.pyc', '.fls', '.fdb_latexmk'}


def files():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and '__pycache__' not in p.parts
                  and p.suffix not in EXCLUDED
                  and p.name not in {'MANIFEST.sha256', 'latex_build.txt'})


def main():
    selected = files()
    if not (ROOT / 'report.pdf').is_file():
        raise SystemExit('Build report.pdf before packaging.')
    manifest = ROOT / 'MANIFEST.sha256'
    manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()
                               + '  ' + p.relative_to(ROOT).as_posix() + '\n'
                               for p in selected))
    selected.append(manifest)
    output = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for p in sorted(selected):
            item = zipfile.ZipInfo(ROOT.name + '/' + p.relative_to(ROOT).as_posix(),
                                   date_time=(2026, 11, 6, 12, 0, 0))
            item.compress_type = zipfile.ZIP_DEFLATED
            item.external_attr = 0o100644 << 16
            archive.writestr(item, p.read_bytes())
    print(output)
    print('Files:', len(selected), 'Bytes:', output.stat().st_size)
    print('SHA-256:', hashlib.sha256(output.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
