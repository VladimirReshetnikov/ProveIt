#!/usr/bin/env python3
"""Compile the report and generate its self-contained LaTeX source."""
from pathlib import Path
import os
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
STEM = "ipra_unclamped_feedback"


def tex_environment(work):
    env = dict(os.environ, SOURCE_DATE_EPOCH="1794268800", FORCE_SOURCE_DATE="1")
    probe = subprocess.run(["kpsewhich", "pdflatex.fmt"], env=env,
                           capture_output=True, text=True)
    if probe.returncode == 0 and probe.stdout.strip():
        return env
    # Adapted from the attributed one_fixed_recurrence build helper.
    # Create a disposable local format from already installed TeX sources.
    trees = [Path("/usr/share/texmf"), Path("/usr/share/texlive/texmf-dist")]
    if not all(tree.is_dir() for tree in trees):
        raise SystemExit("Configure the installed LaTeX formats before building.")
    cache = work / "texcache"
    cache.mkdir(exist_ok=True)
    env["TEXMF"] = "{" + ",".join(map(str, [cache, *trees])) + "}"
    target = cache / "web2c/pdftex/pdflatex.fmt"
    if not target.exists():
        target.parent.mkdir(parents=True, exist_ok=True)
        run = subprocess.run(
            ["pdftex", "-ini", "-etex", "-no-shell-escape",
             "-interaction=nonstopmode", "-halt-on-error", "-jobname=pdflatex",
             "-progname=pdflatex", "pdflatex.ini"],
            cwd=cache, env=env, capture_output=True, text=True)
        if run.returncode:
            raise SystemExit(run.stdout[-9000:] + run.stderr)
        shutil.move(cache / "pdflatex.fmt", target)
    maps = [trees[0] / "fonts/map/dvips/lm/lm.map"]
    maps += sorted((trees[1] / "fonts/map/dvips/amsfonts").glob("*.map"))
    fontmap = cache / "fonts/map/pdftex/local/pdftex.map"
    fontmap.parent.mkdir(parents=True, exist_ok=True)
    fontmap.write_text("\n".join(path.read_text() for path in maps))
    return env


def expand(path, seen=()):
    path = Path(path)
    if path in seen:
        raise ValueError("Cyclic TeX input: " + str(path))
    source = path.read_text(encoding="utf-8")
    def replace(match):
        child = ROOT / match.group(1)
        if child.suffix != ".tex":
            child = child.with_suffix(".tex")
        return "% Begin " + match.group(1) + "\n" + expand(child, seen + (path,)) + "\n% End input\n"
    return re.sub(r"\\input\{([^}]+)\}", replace, source)


def main():
    tex = ROOT / (STEM + ".tex")
    standalone = ROOT / (STEM + "_standalone.tex")
    standalone.write_text(expand(tex), encoding="utf-8")
    work = ROOT / "build"
    work.mkdir(exist_ok=True)
    env = tex_environment(work)
    for _ in range(3):
        result = subprocess.run(
            ["pdflatex", "-no-shell-escape", "-interaction=nonstopmode",
             "-halt-on-error", "-output-directory=" + str(work), tex.name],
            cwd=ROOT, env=env, capture_output=True, text=True)
        if result.returncode:
            print(result.stdout[-10000:])
            print(result.stderr, file=sys.stderr)
            raise SystemExit(result.returncode)
    shutil.copyfile(work / (STEM + ".pdf"), ROOT / (STEM + ".pdf"))
    print("Built " + STEM + ".pdf and standalone LaTeX source.")


if __name__ == "__main__":
    main()

