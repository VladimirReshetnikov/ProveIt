#!/usr/bin/env python3
"""Whole-module matched measurements and frozen native-frontier comparison.

The source normalizer and old complete checkers are unmodified attributed
inputs. This program does not execute any proof-acceptance implementation.
"""
import ast
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import platform

ROOT = Path(__file__).resolve().parent.parent
FIELDS = ("normalized_tokens", "ast_nodes", "normalized_bytes")


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    manifest = json.loads((ROOT / "reference" / "checker_manifest.json").read_text())
    normalizer = ROOT / manifest["normalizer"]["file"]
    if sha256(normalizer) != manifest["normalizer"]["sha256"]:
        raise ValueError("Modified source normalizer")
    spec = importlib.util.spec_from_file_location("source_measure", normalizer)
    measurement = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(measurement)
    for entry in manifest["support_files"]:
        if sha256(ROOT / entry["file"]) != entry["sha256"]:
            raise ValueError("Modified inherited support file: " + entry["file"])

    def metrics(path):
        result = measurement.metrics(path)
        result.pop("core")
        return {"file": str(path.relative_to(ROOT)), **result}

    rows = []
    for entry in manifest["programs"]:
        row = metrics(ROOT / entry["file"])
        if row["sha256"] != entry["sha256"]:
            raise ValueError("Modified comparator: " + entry["file"])
        rows.append(row)
    strict = [row for row in rows if not row["file"].endswith("iterable_306.py")]
    pairs, differences = [], []
    for anchored, key in ((False, "matched_baseline"), (True, "matched_anchored_baseline")):
        entry = manifest[key]
        old_path = ROOT / entry["file"]
        new_path = ROOT / "code" / ("anchored_checker.py" if anchored else "checker.py")
        if sha256(old_path) != entry["sha256"]:
            raise ValueError("Modified matched baseline")
        old, new = old_path.read_bytes(), new_path.read_bytes()
        needle = b"sign(predecessor(comparison))"
        if old.count(needle) != 1 or old.replace(needle, b"predecessor(comparison)") != new:
            raise ValueError("Candidate differs from its baseline beyond the declared deletion")
        old_ast, new_ast = ast.parse(old), ast.parse(new)
        if len(old_ast.body) != len(new_ast.body):
            raise ValueError("Changed module structure")
        changed = []
        for before, after in zip(old_ast.body, new_ast.body):
            if ast.dump(before) != ast.dump(after):
                changed.append(getattr(before, "name", None))
        if changed != ["reset_argument"]:
            raise ValueError("Changed an unrelated abstract syntax tree")
        old_metrics, new_metrics = metrics(old_path), metrics(new_path)
        pairs.append({"anchored": anchored, "old": old_metrics, "new": new_metrics,
                      "saving": {field: old_metrics[field] - new_metrics[field] for field in FIELDS},
                      "exact_single_expression_deletion": True,
                      "changed_ast_functions": changed})
        differences.extend(difflib.unified_diff(old.decode().splitlines(True), new.decode().splitlines(True),
                                              fromfile=entry["file"], tofile=str(new_path.relative_to(ROOT))))
    result = {
        "python": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "current_repository_commit": manifest["current_commit"],
        "scope": "Complete modules including imports, validation, rejection and verdict handling; genuine docstrings/comments removed, ast.unparse normalized",
        "pairs": pairs,
        "native_comparators": rows,
        "runtime_inclusive_coordinate_envelope": {field: min(row[field] for row in rows) for field in FIELDS},
        "strict_guarded_coordinate_envelope": {field: min(row[field] for row in strict) for field in FIELDS},
        "global_minimum_claim": False,
        "caveats": ["Different native programs attain the envelope coordinates.",
                    "The iterable alias implementation has a distinct malformed-input contract.",
                    "Byte measurements depend on identifier spelling.",
                    "These are finite-corpus implementation measurements, not universal lower bounds."]}
    (ROOT / "evidence" / "checker_metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    (ROOT / "evidence" / "checker_changes.patch").write_text("".join(differences))
    print(json.dumps({key: value for key, value in result.items() if key != "native_comparators"}, indent=2))


if __name__ == "__main__":
    main()
