COMPLETE CHECKERS AND REPRODUCIBLE VALIDATION
==========================================

checker.py is the complete standalone acceptance program for the arbitrary
passive anchor c. anchored_checker.py is the complete standalone acceptance
program for the fixed anchor f(1). Each uses only Python's standard library.
Neither imports this README, fixtures, a proof producer, a theorem table,
measurement code, or an evaluator.

These are exact derivatives of the two unchanged feedback checkers in
reference/. Each differs by one expression only:

  old: sign(predecessor(comparison))
  new: predecessor(comparison)

The reset's successful branch and sign guard are unchanged. code/measure.py
checks the exact byte replacement and confirms that reset_argument is the
only changed abstract-syntax function. No source shortening or renaming is
combined with the mathematical change.

RUNNING A CERTIFICATE
---------------------
From the package root:

  python3 code/checker.py < certificate.json
  python3 -O code/checker.py < certificate.json

Use code/anchored_checker.py for an anchored SR certificate. A successful
run prints ACCEPT on stdout and exits 0. Rejection prints REJECT: followed
by a reason on stderr, leaves stdout empty, and exits 1. Resource exhaustion
can reject a large otherwise-valid proof. Neither checker searches for a
proof or performs implicit mathematical conversion.

PUBLIC PACKET AND NUMERICAL SYNTAX
---------------------------------
The packet is a JSON object with exactly two keys, goal and proof. The goal
is a closed formula. Open reasoning is encoded by explicit introductions
inside the proof; no unchecked public context is accepted.

Terms:
  ["0"]
  ["v", "variable_name"]
  ["S", term]
  ["app", description, [argument_0, ...]]

Descriptions:
  ["zero", k]                      zero function of arity k
  ["succ"]                         successor, arity 1
  ["compare"]                      primitive e, arity 2, NO defining equation
  ["proj", k, i]                    projection 0 <= i < k
  ["comp", k, g, [h_0, ...]]        arity-k composition
  ["rec", g, h]                    recursion, arity(g)+1

All descriptions are finite trees. For composition, arity(g) must equal
the number of inner descriptions and each inner description has arity k.
For recursion, arity(h)=arity(g)+2. The recursion count is the first actual
argument. Description symbols are not object variables or evaluator codes.

Formulas:
  ["bot"]
  ["eq", left_term, right_term]
  ["and", A, B], ["or", A, B], ["imp", A, B]
  ["all", "name", body], ["ex", "name", body]

BOUNDARIES AND ALL PROOF INSTRUCTIONS
-----------------------------------
Every proof node is an object with rule, premises, and exactly the listed
additional fields. premises is always a JSON array. The number in brackets
below is its required length.

  hyp [0]: index
  refl [0]: term
  transport [2]: var, body
  bot_e [1]: as
  and_i [2]: no extra fields
  and_e [1]: side
  or_i [1]: side, other
  or_e [3]: no extra fields
  imp_i [1]: assume
  imp_e [2]: no extra fields
  all_i [1]: var
  all_e [1]: term
  ex_i [1]: var, body, term
  ex_e [2]: var
  compute [0]: description, arguments
  BR [0]: term
  Sep [0]: no extra fields
  FR [1]: var, template, anchor, at     (checker.py only)
  SR [1]: var, template, at             (anchored_checker.py only)

Thus each checker has 18 primitive instruction tags. The earlier upstream
README's reference to 19 tags is not used here.

Hypothesis indices address the retained ordered context from 0. Introduction
and elimination rules append their local hypotheses in the standard manner.
transport checks its equality source and the exact source instance of its
fixed formula motive. Substitution avoids variable capture; formula matching
uses nearest-binder alpha equivalence. Quantifier eigenvariables, transport
template variables and reset variables must be fresh for the ambient names.
The existential eigenvariable cannot escape into the result.

compute checks exactly one defining-equation step. It cannot evaluate compare
and cannot compute recursion at an arbitrary nonliteral counter. BR gives
sigma(t)=0 or sigma(t)=1. Sep gives(0=1)->bottom. There is no instruction for
coverage, ordinary induction, equality reflection, a universal evaluator,
or a preproved arithmetic theorem.

For FR, let x be var, f(x) be template, c be anchor, and t be at. Its single
premise must literally match, up to bound-variable renaming:

  f(C(sigma(e(f(x),c)), Sx, P(e(f(x),c)))) = c.

The conclusion is f(t)=c. The premise is checked with x fresh; neither c
nor t may contain x. For SR the same rule sets c=f(1), rather than reading an
anchor field. Exact malformed/extra fields reject.

The old clamped premise and a constant-zero premise are rejected when passed
DIRECTLY to this primitive instruction. This is a statement about exact rule
matching, not an assertion that their associated derived principles are
unprovable in the resulting theory.

VALIDATION
----------
  python3 code/validate_feedback.py
  python3 code/validate_anchored.py
  python3 code/check_reset_contracts.py
  python3 code/measure.py
  python3 code/validate_calibration.py

The last command independently reconstructs the six closed goal formulas and
replays the complete calibration packet in fresh normal and optimized CLI
processes. It rejects eight targeted corruptions in both modes and rejects
the unchanged certificate under the old clamped rule contract. The main
certificate uses no Sep or bot_e rule; its statement and replay scope are
documented in certificates/README.txt. An optional relative packet path can
be supplied to the validator when reviewing a regenerated certificate.

The first two scripts adapt the attributed upstream fixtures, preserving
positive ordinary-logic cases, malformed description/term rejection, variable
capture and scope controls, and the prohibition on compare computation. They
also reject the old clamped and constant-zero reset premises. They regenerate
fixtures/ and anchored_fixtures/ and write the detailed JSON receipts under
evidence/. Both normal and optimized Python invocations are checked.

check_reset_contracts.py independently constructs eight premise shapes and
checks both old/new programs and both anchor interfaces. Only the raw P
premise is accepted as a primitive reset by the new programs; only the old
sign(P) premise is accepted by the old programs. These are rule-matcher
controls, not calibration proofs.

The universal arithmetic result is proved in the report. The separate
certificates/ derivations supplied with this package have their own stated
scope. Finite regressions alone do not establish the interpretation theorem.

MEASUREMENTS
------------
The inherited whole-source normalizer removes comments and true docstrings,
then uses ast.unparse. It includes imports, input parsing, rejection and
verdict handling. Exact recorded values use CPython 3.12.14.

                               tokens   AST nodes   normalized bytes
  previous arbitrary anchor      3316      3526            13382
  new arbitrary anchor           3313      3523            13376
  previous fixed anchor          3318      3528            13390
  new fixed anchor               3315      3525            13384

Each matched saving is 3 tokens, 3 AST nodes and 6 bytes. The anchored source
has a smaller proof-field interface but is slightly larger under this
particular whole-source measure, because it constructs f(1) itself.

The inherited compact native checker envelope is305/340/820; excluding the
iterable-alias source it is305/341/820. Different programs attain the three
coordinates. These ordinary-logic implementations do not beat that envelope.
There is no global minimality claim.

PROVENANCE
----------
reference/ATTRIBUTION.txt and reference/checker_manifest.json identify the
unchanged old programs, seven compact comparators, source normalizer, fixture
producer, and retained license. No repository modification is required to
run this package.
