#!/usr/bin/env python3
"""Independent public-CLI replay and targeted corruption checks.

The expected six closed goal formulas are reconstructed without importing
the certificate producer or the checker. Negative controls are deliberately
chosen rule/term changes; they are not an independence proof for the axioms.
"""
import copy
from collections import Counter
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import time

import upstream_fixtures as u

ROOT = Path(__file__).resolve().parent.parent
CERTIFICATE = ROOT / (sys.argv[1] if len(sys.argv) > 1 else "certificates/calibration.json")
CHECKER = ROOT / "code" / "checker.py"


def comparison(a, b):
    return u.call(["compare"], a, b)


def expected_goals():
    a, b, t, x = (u.v(name) for name in ("a", "b", "t", "x"))
    E = lambda r, s: u.sign(comparison(r, s))
    return [
        ("diagonal", "forall a: E(a,a)=0", u.forall(["a"], u.e(E(a, a), u.ZERO))),
        ("reflection", "forall a,b: E(a,b)=0 implies a=b",
         u.forall(["a", "b"], ["imp", u.e(E(a, b), u.ZERO), u.e(a, b)])),
        ("raw_failure", "forall a,b: E(a,b)=1 implies P(e(a,b))=0",
         u.forall(["a", "b"], ["imp", u.e(E(a, b), u.ONE), u.e(u.call(u.PRED, comparison(a, b)), u.ZERO)])),
        ("zero_fibre_identity", "forall t: C(sigma(t),0,S(P(t)))=t",
         u.forall(["t"], u.e(u.select(u.sign(t), u.ZERO, u.s(u.call(u.PRED, t))), t))),
        ("coverage", "forall x: x=0 or x=S(P(x))",
         u.forall(["x"], ["or", u.e(x, u.ZERO), u.e(x, u.s(u.call(u.PRED, x)))])),
        ("raw_comparison_normalized", "forall a,b: e(a,b)=sigma(e(a,b))",
         u.forall(["a", "b"], u.e(comparison(a, b), E(a, b)))),
    ]


def conjunction(formulas):
    result = formulas[-1]
    for formula in reversed(formulas[:-1]):
        result = ["and", formula, result]
    return result


def walk(node, path=(), ambient=()):
    yield path, node, ambient
    for i, child in enumerate(node["premises"]):
        scope = ambient
        if node["rule"] in ("all_i", "FR") or (node["rule"] == "ex_e" and i == 1):
            scope = ambient + (node["var"],)
        yield from walk(child, path + (i,), scope)


def at(proof, path):
    for index in path:
        proof = proof["premises"][index]
    return proof


def changed_case(packet, name, path, edit):
    result = copy.deepcopy(packet)
    node = at(result["proof"], path)
    before = copy.deepcopy(node)
    edit(node)
    if before == node:
        raise ValueError("Ineffective mutation: " + name)
    return name, result, list(path)


def replace_exact(value, old, new):
    if value == old:
        return copy.deepcopy(new), 1
    if isinstance(value, list):
        result, count = [], 0
        for child in value:
            rewritten, total = replace_exact(child, old, new)
            result.append(rewritten)
            count += total
        return result, count
    if isinstance(value, dict):
        result, count = {}, 0
        for key, child in value.items():
            rewritten, total = replace_exact(child, old, new)
            result[key] = rewritten
            count += total
        return result, count
    return value, 0


def mutations(packet):
    nodes = list(walk(packet["proof"]))
    first = lambda predicate: next((path, node, scope) for path, node, scope in nodes if predicate(node))
    fr_path, fr, scope = first(lambda node: node["rule"] == "FR")
    br_path, br, _ = first(lambda node: node["rule"] == "BR" and node["term"] != u.ZERO)
    compute_path, computation, _ = first(lambda node: node["rule"] == "compute")
    projection_path, projection, _ = first(lambda node: node["rule"] == "compute"
                                           and node["description"][0] == "proj"
                                           and node["description"][1] >= 2)
    hyp_path, _, _ = first(lambda node: node["rule"] == "hyp")

    yield changed_case(packet, "reset_target_eigenvariable_escape", fr_path,
                       lambda node: node.update(at=u.v(node["var"])))
    if not scope:
        raise ValueError("The selected reset has no ambient variable for the freshness control")
    yield changed_case(packet, "reset_reuses_ambient_variable", fr_path,
                       lambda node: node.update(var=scope[0]))
    yield changed_case(packet, "boolean_range_on_wrong_term", br_path,
                       lambda node: node.update(term=u.ZERO))

    def fake_computation(node):
        node["description"] = ["compare"]
        node["arguments"] = [u.ZERO, u.ZERO]
    yield changed_case(packet, "invented_comparison_computation", compute_path, fake_computation)

    def wrong_projection(node):
        node["description"][2] = (node["description"][2] + 1) % node["description"][1]
    yield changed_case(packet, "changed_valid_projection_computation", projection_path, wrong_projection)
    yield changed_case(packet, "hidden_hypothesis_reference", hyp_path,
                       lambda node: node.update(index=1000000))

    damaged = copy.deepcopy(packet)
    damaged["goal"] = u.e(u.ZERO, u.ONE)
    yield "false_conclusion", damaged, []

    damaged = copy.deepcopy(packet)
    target = at(damaged["proof"], fr_path)
    index = u.v(target["var"])
    raw_compare = comparison(target["template"], target["anchor"])
    old = u.select(u.sign(raw_compare), u.s(index), u.call(u.PRED, raw_compare))
    new = u.select(u.sign(raw_compare), u.s(index), u.sign(u.call(u.PRED, raw_compare)))
    target["premises"][0], count = replace_exact(target["premises"][0], old, new)
    if count == 0:
        raise ValueError("No explicit raw reset found in its premise proof")
    yield "clamped_destination_inside_reset_premise", damaged, list(fr_path)


def run_case(label, packet, checker, expected, flags, path=None):
    start = time.monotonic()
    run = subprocess.run([sys.executable, *flags, str(checker)], input=json.dumps(packet),
                         text=True, capture_output=True, timeout=90)
    accepted = run.returncode == 0 and run.stdout == "ACCEPT\n" and not run.stderr
    rejected = run.returncode == 1 and not run.stdout and run.stderr.startswith("REJECT:")
    return {"case": label, "checker": str(checker.relative_to(ROOT)),
            "optimized": bool(flags), "expected_accept": expected,
            "passed": accepted if expected else rejected,
            "exit_code": run.returncode, "seconds": round(time.monotonic() - start, 4),
            "diagnostic": run.stdout.strip() if accepted else run.stderr.strip(),
            "changed_proof_path": path}


def main():
    raw = CERTIFICATE.read_bytes()
    packet = json.loads(raw)
    goals = expected_goals()
    if packet["goal"] != conjunction([goal for _, _, goal in goals]):
        raise ValueError("Certificate goal differs from the independently reconstructed six formulas")
    nodes = list(walk(packet["proof"]))
    counts = Counter(node["rule"] for _, node, _ in nodes)
    if counts.get("Sep", 0) or counts.get("bot_e", 0):
        raise ValueError("The numerical calibration must not use separation or falsity elimination")
    goal_output = [{"name": name, "statement": text, "formula": goal} for name, text, goal in goals]
    (ROOT / "evidence" / "calibration_goals.json").write_text(json.dumps(goal_output, indent=2) + "\n")
    runs = [run_case("original_calibration", packet, CHECKER, True, flags) for flags in ([], ["-O"])]
    print("Original certificate accepted in both public CLI modes.", flush=True)
    for label, damaged, path in mutations(packet):
        for flags in ([], ["-O"]):
            runs.append(run_case(label, damaged, CHECKER, False, flags, path))
        print(label + ": checked", flush=True)
    old = ROOT / "reference" / "feedback_checker.py"
    for flags in ([], ["-O"]):
        runs.append(run_case("old_clamped_rule_contract", packet, old, False, flags))
    failures = [run for run in runs if not run["passed"]]
    result = {"python": platform.python_version(), "certificate": str(CERTIFICATE.relative_to(ROOT)),
              "certificate_sha256": hashlib.sha256(raw).hexdigest(), "certificate_bytes": len(raw),
              "checker_sha256": hashlib.sha256(CHECKER.read_bytes()).hexdigest(),
              "independently_matched_goal_count": len(goals), "proof_nodes": len(nodes),
              "maximum_proof_depth": max(len(path) for path, _, _ in nodes) + 1,
              "rule_counts": dict(sorted(counts.items())), "public_cli_runs": len(runs),
              "corrupted_certificates": 8, "old_contract_controls": 2,
              "scope": "A full closed derivation of the six stated formulas, checked by the complete supplied checker; not formal verification of that checker or the entire interpretation metatheory",
              "failures": failures, "runs": runs}
    receipt = ROOT / "evidence" / (CERTIFICATE.stem + "_validation.json")
    receipt.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "runs"}, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
