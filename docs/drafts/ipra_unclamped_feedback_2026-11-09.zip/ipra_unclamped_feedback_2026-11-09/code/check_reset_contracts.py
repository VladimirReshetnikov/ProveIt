#!/usr/bin/env python3
"""Independent exact-premise controls for both public reset interfaces.

These are rule-matcher tests, not arithmetic calibration proofs. The complete
checkers never import this program or the fixture producer.
"""
import json
from pathlib import Path
import platform
import subprocess
import sys

import upstream_fixtures as u

ROOT = Path(__file__).resolve().parent.parent


def reset(value, anchor, index, variant):
    comparison = u.call(["compare"], value, anchor)
    pred = u.call(u.PRED, comparison)
    guard, successful = u.sign(comparison), u.s(index)
    if variant == "raw_predecessor":
        failure = pred
    elif variant == "old_clamped_predecessor":
        failure = u.sign(pred)
    elif variant == "constant_zero":
        failure = u.ZERO
    elif variant == "raw_comparison":
        failure = comparison
    elif variant == "clamped_comparison":
        failure = u.sign(comparison)
    elif variant == "unshifted_success":
        failure, successful = pred, index
    elif variant == "unclamped_guard":
        failure, guard = pred, comparison
    elif variant == "swapped_comparison":
        failure = u.call(u.PRED, u.call(["compare"], anchor, value))
    else:
        raise ValueError(variant)
    return u.select(guard, successful, failure)


def schema(variant, anchored):
    z, t = u.v("z"), u.v("t")
    anchor = u.ONE if anchored else u.v("c")
    body = u.e(reset(z, anchor, z, variant), anchor)
    assumption = u.forall(["z"], body)
    fields = {"var": "z", "template": z, "at": t}
    if not anchored:
        fields["anchor"] = anchor
    proof = u.node("SR" if anchored else "FR",
                   u.node("all_e", u.hyp(0), term=z), **fields)
    parameters = ["t"] if anchored else ["c", "t"]
    goal = ["imp", assumption, u.e(t, anchor)]
    return u.packet(u.forall(parameters, goal),
                    u.generalize(parameters, u.node("imp_i", proof, assume=assumption)))


def main():
    variants = ("raw_predecessor", "old_clamped_predecessor", "constant_zero",
                "raw_comparison", "clamped_comparison", "unshifted_success",
                "unclamped_guard", "swapped_comparison")
    runs, failures = [], []
    for anchored in (False, True):
        files = (("new", ROOT / "code" / ("anchored_checker.py" if anchored else "checker.py")),
                 ("old", ROOT / "reference" / ("feedback_anchored_checker.py" if anchored else "feedback_checker.py")))
        for variant in variants:
            packet = schema(variant, anchored)
            for age, checker in files:
                expected = variant == ("raw_predecessor" if age == "new" else "old_clamped_predecessor")
                for flags in ([], ["-O"]):
                    run = subprocess.run([sys.executable, *flags, str(checker)],
                                         input=json.dumps(packet), text=True,
                                         capture_output=True, timeout=15)
                    accepted = run.returncode == 0 and run.stdout == "ACCEPT\n" and not run.stderr
                    rejected = run.returncode == 1 and not run.stdout and run.stderr.startswith("REJECT:")
                    passed = accepted if expected else rejected
                    record = {"anchored": anchored, "checker": age, "variant": variant,
                              "optimized": bool(flags), "expected_accept": expected,
                              "passed": passed}
                    runs.append(record)
                    if not passed:
                        failures.append(record)
    result = {"python": platform.python_version(), "scope": "Exact syntactic premise matching only",
              "public_cli_runs": len(runs), "failures": failures, "runs": runs}
    (ROOT / "evidence" / "reset_contracts.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "runs"}, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
