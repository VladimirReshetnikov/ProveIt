#!/usr/bin/env python3
"""Untrusted fixtures and measurements for the feedback-reset checker.

The checker does not import this producer or its inherited fixture module.
These finite checks exercise the disclosed interfaces; they are not a proof
of the universal calibration or of the full interpretation theorem.
"""
import copy
import json
from pathlib import Path
import platform
import subprocess
import sys

import upstream_fixtures as u

ROOT = Path(__file__).resolve().parent
CHECKER = ROOT / "checker.py"
COMPARE = ["compare"]


def comparison(a, b):
    return u.call(COMPARE, a, b)


def reset(value, anchor, index, old=False, clamped=False):
    test = comparison(value, anchor)
    failure = u.ZERO if old else u.call(u.PRED, test)
    if clamped:
        failure = u.sign(failure)
    return u.select(u.sign(test), u.s(index), failure)


def feedback_schema(template, target, anchor, parameters, old=False, clamped=False):
    x = "z"
    rho = reset(template, anchor, u.v(x), old, clamped)
    body = u.e(u.replace_term(template, x, rho), anchor)
    assumption = ["all", x, body]
    application = u.node("FR", u.node("all_e", u.hyp(0), term=u.v(x)),
                         var=x, template=template, anchor=anchor, at=target)
    goal = ["imp", assumption, u.e(u.replace_term(template, x, target), anchor)]
    return u.packet(u.forall(parameters, goal),
                    u.generalize(parameters, u.node("imp_i", application, assume=assumption)))


def fixtures():
    inherited_positive, inherited_negative = u.fixtures()
    keep = lambda p: not (u.used_rules(p["proof"]) & {"SR"})
    positive = {"inherited_" + k: v for k, v in inherited_positive.items() if keep(v)}
    negative = {"inherited_" + k: v for k, v in inherited_negative.items() if keep(v)}
    A = u.e(u.ZERO, u.ZERO)
    positive["comparison_reflexivity"] = u.packet(
        u.forall(["a", "b"], u.e(comparison(u.v("a"), u.v("b")),
                                     comparison(u.v("a"), u.v("b")))),
        u.generalize(["a", "b"], u.refl(comparison(u.v("a"), u.v("b")))))
    positive["constant_feedback"] = u.packet(
        A, u.node("FR", u.refl(u.ZERO), var="z", template=u.ZERO,
                  anchor=u.ZERO, at=u.TWO))
    positive["parameter_feedback"] = u.packet(
        u.forall(["a", "t"], u.e(u.v("a"), u.v("a"))),
        u.generalize(["a", "t"], u.node("FR", u.refl(u.v("a")), var="z",
                                        template=u.v("a"), anchor=u.v("a"), at=u.v("t"))))
    positive["arbitrary_anchor_schema"] = feedback_schema(
        u.v("z"), u.v("t"), u.v("c"), ["c", "t"])
    positive["comparison_template_schema"] = feedback_schema(
        comparison(u.v("z"), u.v("a")), u.v("t"), u.v("c"), ["a", "c", "t"])
    positive["compound_passive_anchor"] = feedback_schema(
        u.v("z"), u.v("t"), comparison(u.v("a"), u.v("b")), ["a", "b", "t"])
    desc = ["comp", 1, COMPARE, [["proj", 1, 0], ["zero", 1]]]
    right = comparison(u.call(["proj", 1, 0], u.ONE), u.call(["zero", 1], u.ONE))
    positive["comparison_in_composition"] = u.packet(
        u.e(u.call(desc, u.ONE), right), u.node("compute", description=desc, arguments=[u.ONE]))
    desc = ["rec", ["zero", 0], COMPARE]
    right = comparison(u.ZERO, u.call(desc, u.ZERO))
    positive["comparison_in_recursion"] = u.packet(
        u.e(u.call(desc, u.ONE), right), u.node("compute", description=desc, arguments=[u.ONE]))

    negative["compare_has_no_equation"] = u.packet(
        u.e(comparison(u.ZERO, u.ZERO), u.ZERO),
        u.node("compute", description=COMPARE, arguments=[u.ZERO, u.ZERO]))
    negative["compare_tag_has_no_arguments"] = u.packet(
        A, u.node("compute", description=["compare", 2], arguments=[u.ZERO, u.ZERO]))
    negative["compare_wrong_arity"] = u.packet(A, u.refl(u.call(COMPARE, u.ZERO)))
    negative["comparison_does_not_compute_by_reflexivity"] = u.packet(
        u.e(comparison(u.ZERO, u.ZERO), u.ZERO), u.refl(u.ZERO))
    negative["reset_old_zero_fallback"] = feedback_schema(
        u.v("z"), u.v("t"), u.v("c"), ["c", "t"], old=True)
    negative["reset_old_clamped_fallback"] = feedback_schema(
        u.v("z"), u.v("t"), u.v("c"), ["c", "t"], clamped=True)
    negative["reset_wrong_premise"] = u.packet(
        A, u.node("FR", u.refl(u.ZERO), var="z", template=u.v("z"),
                  anchor=u.ZERO, at=u.ZERO))
    negative["anchor_captures_eigenvariable"] = u.packet(
        A, u.node("FR", u.refl(u.ZERO), var="z", template=u.ZERO,
                  anchor=u.v("z"), at=u.ZERO))
    negative["anchor_has_unbound_parameter"] = u.packet(
        A, u.node("FR", u.refl(u.ZERO), var="z", template=u.ZERO,
                  anchor=u.v("c"), at=u.ZERO))
    negative["anchor_malformed_even_if_unused"] = u.packet(
        A, u.node("FR", u.refl(u.ZERO), var="z", template=u.ZERO,
                  anchor=["not_a_term"], at=u.ZERO))
    negative["target_captures_eigenvariable"] = u.packet(
        A, u.node("FR", u.refl(u.ZERO), var="z", template=u.ZERO,
                  anchor=u.ZERO, at=u.v("z")))
    negative["feedback_reuses_ambient_variable"] = u.packet(
        u.forall(["z"], A), u.generalize(["z"], u.node("FR", u.refl(u.ZERO),
                  var="z", template=u.ZERO, anchor=u.ZERO, at=u.ZERO)))
    negative["feedback_hidden_hypothesis"] = u.packet(
        A, u.node("FR", u.hyp(0), var="z", template=u.ZERO,
                  anchor=u.ZERO, at=u.ZERO))
    negative["feedback_extra_premise"] = u.packet(
        A, u.node("FR", u.refl(u.ZERO), u.refl(u.ZERO), var="z", template=u.ZERO,
                  anchor=u.ZERO, at=u.ZERO))
    negative["feedback_anchor_omitted"] = copy.deepcopy(positive["constant_feedback"])
    del negative["feedback_anchor_omitted"]["proof"]["anchor"]
    negative["old_raw_reset_instruction"] = u.packet(
        A, u.node("SR", u.refl(u.ZERO), var="z", template=u.ZERO, at=u.ZERO))
    negative["invented_coverage_instruction"] = u.packet(
        A, u.node("Cov", term=u.ZERO))
    return positive, negative


def main():
    checker = u.load_checker(CHECKER)
    positive, negative = fixtures()
    receipts, failures = [], []
    coverage = set()
    output = ROOT.parent / "fixtures"
    output.mkdir(exist_ok=True)
    for expected, group in ((True, positive), (False, negative)):
        for label, packet in group.items():
            (output / (label + ".json")).write_text(json.dumps(packet, indent=2) + "\n")
            if expected:
                coverage |= u.used_rules(packet["proof"])
            try:
                result = checker.verify(packet) is True
            except Exception:
                result = False
            if result != expected:
                failures.append(label + ": API verdict")
            for flags in ([], ["-O"]):
                run = subprocess.run([sys.executable, *flags, str(CHECKER)],
                                     input=json.dumps(packet), text=True, capture_output=True, timeout=15)
                accepted = run.returncode == 0 and run.stdout == "ACCEPT\n" and not run.stderr
                rejected = run.returncode == 1 and not run.stdout and run.stderr.startswith("REJECT:")
                passed = accepted if expected else rejected
                receipts.append({"case": label, "expected": expected, "optimized": bool(flags),
                                 "passed": passed})
                if not passed:
                    failures.append(label + ": CLI verdict " + repr(flags))
    if coverage != set(checker.RULES):
        failures.append("Rule coverage differs: " + repr(coverage ^ set(checker.RULES)))
    malformed = ["{", "[]", '{"goal":0,"goal":1,"proof":null}',
                 '{"goal":NaN,"proof":null}', '{"goal":Infinity,"proof":null}']
    for j, raw in enumerate(malformed):
        for flags in ([], ["-O"]):
            run = subprocess.run([sys.executable, *flags, str(CHECKER)], input=raw,
                                 text=True, capture_output=True, timeout=15)
            passed = run.returncode == 1 and not run.stdout and run.stderr.startswith("REJECT:")
            receipts.append({"case": "malformed_json_" + str(j), "expected": False,
                             "optimized": bool(flags), "passed": passed})
            if not passed:
                failures.append("Malformed JSON " + str(j))
    result = {"python": platform.python_version(), "accepted_packets": len(positive),
              "rejected_packets": len(negative), "malformed_json_cases": len(malformed),
              "public_cli_runs": len(receipts), "rule_coverage": sorted(coverage),
              "feedback_metrics": u.measure(CHECKER),
              "baseline_metrics": u.measure(ROOT.parent / "reference" / "feedback_checker.py"),
              "failures": failures, "runs": receipts}
    (ROOT.parent / "evidence" / "checker_validation.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "runs"}, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
