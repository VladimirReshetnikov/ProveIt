"""Untrusted producer of full natural-deduction certificates for raw feedback.

Every leaf is a rule accepted by the complete inherited checker. Numerical
normalization is compiled to literal defining equations and equality transport;
it is not a trusted checker shortcut. This script imports the checker solely
for data constructors and final verification; it never changes its rule set.
"""
from dataclasses import dataclass
import importlib.util
import json
from pathlib import Path
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
# Distributed beside checker.py; the second path is for the research workspace.
CHECKER = HERE / "checker.py"
if not CHECKER.exists():
    CHECKER = ROOT / "output/ipra_unclamped_feedback_2026-11-09/code/checker.py"
if not CHECKER.exists():
    raise SystemExit("Place this producer beside the delivered checker.py.")
spec = importlib.util.spec_from_file_location("raw_checker", CHECKER)
K = importlib.util.module_from_spec(spec)
spec.loader.exec_module(K)

Z = K.zero()
O = K.successor(Z)
v, eq, sign, pred, choose = K.variable, K.eq, K.sign, K.predecessor, K.choose


def E(a, b):
    return sign(K.app(K.COMPARISON, a, b))


def D(a, b):
    return pred(K.app(K.COMPARISON, a, b))


def numeral(n):
    t = Z
    for _ in range(n):
        t = K.successor(t)
    return t


def pp(t, k):
    for _ in range(k):
        t = pred(t)
    return t


def spike(j, x, a, b):
    t = choose(sign(pp(x, j)), b, a)
    for k in reversed(range(j)):
        t = choose(sign(pp(x, k)), a, t)
    return t


@dataclass
class P:
    formula: list
    node: dict


class Builder:
    def __init__(self, context=(), names=(), counter=None):
        self.context = tuple(context)
        self.names = set(names)
        self.counter = counter if counter is not None else [0]

    def fresh(self, stem="u"):
        while True:
            self.counter[0] += 1
            name = "_" + stem + str(self.counter[0])
            if name not in self.names:
                return name

    def sub(self, *, context=None, name=None):
        return Builder(self.context if context is None else context,
                       self.names | ({name} if name else set()), self.counter)

    def node(self, rule, formula, premises=(), **fields):
        return P(formula, {"rule": rule, "premises": [p.node for p in premises], **fields})

    def hyp(self, index):
        return self.node("hyp", self.context[index], index=index)

    def refl(self, term):
        return self.node("refl", eq(term, term), term=term)

    def transport(self, equality, minor, name, body):
        assert equality.formula[0] == "eq"
        assert minor.formula == K.substitute(body, name, equality.formula[1])
        return self.node("transport", K.substitute(body, name, equality.formula[2]),
                         (equality, minor), var=name, body=body)

    def sym(self, proof):
        a, b = proof.formula[1:]
        if a == b:
            return self.refl(a)
        name = self.fresh()
        return self.transport(proof, self.refl(a), name, eq(v(name), a))

    def trans(self, first, second):
        a, b = first.formula[1:]
        assert second.formula[1] == b
        c = second.formula[2]
        if a == b:
            return second
        if b == c:
            return first
        name = self.fresh()
        return self.transport(second, first, name, eq(a, v(name)))

    def cong(self, proof, make):
        s, t = proof.formula[1:]
        if s == t:
            return self.refl(make(s))
        name = self.fresh()
        left = make(s)
        return self.transport(proof, self.refl(left), name, eq(left, make(v(name))))

    def normalize(self, term, rules=()):
        rules = tuple(rules)
        table = {json.dumps(p.formula[1], separators=(",", ":")): p for p in rules
                 if p.formula[0] == "eq" and p.formula[1] != p.formula[2]}
        cache = {}

        def norm(t):
            key = json.dumps(t, separators=(",", ":"))
            if key in cache:
                return cache[key]
            if key in table:
                r = table[key]
                u, p = norm(r.formula[2])
                answer = (u, self.trans(r, p))
                cache[key] = answer
                return answer
            current = t
            proof = self.refl(t)
            if t[0] == "S":
                u, p = norm(t[1])
                current = K.successor(u)
                proof = self.cong(p, K.successor)
            elif t[0] == "app":
                desc, args = t[1], list(t[2])
                for i, arg in enumerate(args):
                    u, p = norm(arg)
                    if u != arg:
                        old = list(args)
                        def make(x, i=i, old=old):
                            new = old.copy()
                            new[i] = x
                            return K.app(desc, *new)
                        proof = self.trans(proof, self.cong(p, make))
                        args[i] = u
                current = K.app(desc, *args)
            currentkey = json.dumps(current, separators=(",", ":"))
            if currentkey in table:
                r = table[currentkey]
                u, p = norm(r.formula[2])
                answer = (u, self.trans(self.trans(proof, r), p))
            elif current[0] == "app" and current[1][0] != "compare" and (
                    current[1][0] != "rec" or current[2][0][0] in ("0", "S")):
                desc, args = current[1:]
                right = K.defining_right(desc, args)
                step = self.node("compute", eq(current, right),
                                 description=desc, arguments=args)
                u, p = norm(right)
                answer = (u, self.trans(self.trans(proof, step), p))
            else:
                answer = (current, proof)
            cache[key] = answer
            return answer
        return norm(term)

    def equality_by_normalization(self, left, right, rules=()):
        l, p = self.normalize(left, rules)
        r, q = self.normalize(right, rules)
        if l != r:
            raise ValueError("Different normal forms: " + json.dumps([l, r]))
        return self.trans(p, self.sym(q))

    def assumption(self, formula, body):
        sub = self.sub(context=self.context + (formula,))
        p = body(sub, sub.hyp(len(self.context)))
        return self.node("imp_i", ["imp", formula, p.formula], (p,), assume=formula)

    def apply(self, implication, antecedent):
        assert implication.formula[0] == "imp"
        assert implication.formula[1] == antecedent.formula
        return self.node("imp_e", implication.formula[2], (implication, antecedent))

    def let(self, proof, body):
        return self.apply(self.assumption(proof.formula, body), proof)

    def forall(self, name, body):
        assert name not in self.names
        p = body(self.sub(name=name), v(name))
        return self.node("all_i", ["all", name, p.formula], (p,), var=name)

    def specialize(self, proof, term):
        assert proof.formula[0] == "all"
        return self.node("all_e", K.substitute(proof.formula[2], proof.formula[1], term),
                         (proof,), term=term)

    def instance(self, proof, *terms):
        for t in terms:
            proof = self.specialize(proof, t)
        return proof

    def BR(self, term, branch):
        formulas = [eq(sign(term), Z), eq(sign(term), O)]
        major = self.node("BR", ["or", *formulas], term=term)
        ps = []
        for bit, f in enumerate(formulas):
            sub = self.sub(context=self.context + (f,))
            ps.append(branch(sub, bit, sub.hyp(len(self.context))))
        assert ps[0].formula == ps[1].formula
        return self.node("or_e", ps[0].formula, (major, *ps))

    def bits(self, term, width, branch, values=(), proofs=()):
        k = len(values)
        if k == width:
            return branch(self, values, proofs)
        return self.BR(pp(term, k), lambda sub, b, p:
                       sub.bits(term, width, branch, values + (b,), proofs + (p,)))

    def label(self, term, width, branch, proofs=(), at=0):
        if at == width:
            return branch(self, width, proofs)
        return self.BR(pp(term, at), lambda sub, b, p:
                       branch(sub, at, proofs + (p,)) if b == 0 else
                       sub.label(term, width, branch, proofs + (p,), at + 1))

    def FR(self, template_fn, anchor, target, premise):
        name = self.fresh("z")
        sub = self.sub(name=name)
        template = template_fn(v(name))
        reset = K.reset_argument(template, anchor, v(name))
        left = K.substitute_term(template, name, reset)
        p = premise(sub, v(name), left)
        assert p.formula == eq(left, anchor)
        conclusion = eq(K.substitute_term(template, name, target), anchor)
        return self.node("FR", conclusion, (p,), var=name, template=template,
                         anchor=anchor, at=target)

    def collapse(self, zero_one, left, right):
        """Numerical explosion compiled using selector equations, without Sep."""
        changed = self.cong(zero_one, lambda t: choose(t, left, right))
        before = self.equality_by_normalization(changed.formula[1], left)
        after = self.equality_by_normalization(changed.formula[2], right)
        return self.trans(self.sym(before), self.trans(changed, after))

    def contradiction(self, equality):
        sep = self.node("Sep", ["imp", eq(Z, O), ["bot"]])
        return self.apply(sep, equality)

    def absurd(self, contradiction, formula):
        return self.node("bot_e", formula, (contradiction,), **{"as": formula})

    def and_intro(self, *proofs):
        result = proofs[-1]
        for p in reversed(proofs[:-1]):
            result = self.node("and_i", ["and", p.formula, result.formula], (p, result))
        return result


def bad_diagonal(B):
    """All a,b: E(a,a)=1 -> b=a, with no earlier calibration theorem."""
    def at_b(B, a, b):
        def retained(B, diagonal):
            d, q = D(a, a), D(b, a)
            def at_destinations(B, ld, dp, lq, qp):
                j = next(j for j in range(3) if j not in (ld, lq))
                fn = lambda x: spike(j, x, a, b)
                def premise(B, z, left):
                    return B.BR(K.app(K.COMPARISON, b, a), lambda sub, bit, ep:
                        sub.bits(z, j + 1, lambda sub2, values, zp:
                            sub2.equality_by_normalization(left, a,
                                (*dp, *qp, diagonal, ep, *zp))))
                fr = B.FR(fn, a, numeral(j), premise)
                endpoint = B.equality_by_normalization(fn(numeral(j)), b)
                return B.trans(B.sym(endpoint), fr)
            return B.label(d, 3, lambda sub, ld, dp:
                sub.label(q, 3, lambda sub2, lq, qp:
                    at_destinations(sub2, ld, dp, lq, qp)))
        return B.assumption(eq(E(a, a), O), retained)
    return B.forall("a", lambda sub, a:
        sub.forall("b", lambda sub2, b: at_b(sub2, a, b)))


def diagonal(B, bad):
    def at_a(B, a):
        def branch(B, bit, hypothesis):
            if bit == 0:
                return hypothesis
            zero_a = B.apply(B.instance(bad, a, Z), hypothesis)
            one_a = B.apply(B.instance(bad, a, O), hypothesis)
            zero_one = B.trans(zero_a, B.sym(one_a))
            return B.trans(hypothesis, B.sym(zero_one))
        return B.BR(K.app(K.COMPARISON, a, a), branch)
    return B.forall("a", at_a)


def reflection(B, diag):
    def at_b(B, a, b):
        def retained(B, assumption):
            dbb = B.instance(diag, b)
            fn = lambda x: choose(sign(x), a, b)
            def premise(B, z, left):
                return B.BR(z, lambda sub, bit, p:
                    sub.equality_by_normalization(left, b, (assumption, dbb, p)))
            fr = B.FR(fn, b, Z, premise)
            endpoint = B.equality_by_normalization(fn(Z), a)
            return B.trans(B.sym(endpoint), fr)
        return B.assumption(eq(E(a, b), Z), retained)
    return B.forall("a", lambda sub, a:
        sub.forall("b", lambda sub2, b: at_b(sub2, a, b)))


def successor_nonzero(B, reflect):
    def at_z(B, z):
        def branch(B, bit, p):
            if bit == 1:
                return p
            sz_zero = B.apply(B.instance(reflect, K.successor(z), Z), p)
            signed = B.cong(sz_zero, sign)
            one, pleft = B.normalize(signed.formula[1])
            zero, pright = B.normalize(signed.formula[2])
            assert one == O and zero == Z
            one_zero = B.trans(B.sym(pleft), B.trans(signed, pright))
            return B.trans(p, B.sym(one_zero))
        return B.BR(K.app(K.COMPARISON, K.successor(z), Z), branch)
    return B.forall("z", at_z)


def raw_failure(B, diag, reflect, snz):
    def at_b(B, a, b):
        def retained(B, assumption):
            d = D(a, b)
            def branch(B, bit, dp):
                if bit == 0:
                    return B.apply(B.instance(reflect, d, Z), dp)
                fn = lambda x: choose(E(x, Z), a, b)
                dbb = B.instance(diag, b)
                def premise(B, z, left):
                    esz = B.instance(snz, z)
                    return B.BR(K.app(K.COMPARISON, z, Z), lambda sub, value, p:
                        sub.equality_by_normalization(left, b, (assumption, dp, dbb, esz, p)))
                fr = B.FR(fn, b, Z, premise)
                endpoint = B.equality_by_normalization(fn(Z), a, (B.instance(diag, Z),))
                a_b = B.trans(B.sym(endpoint), fr)
                changed = B.cong(a_b, lambda x: E(a, x))
                eab_zero = B.trans(B.sym(changed), B.instance(diag, a))
                zero_one = B.trans(B.sym(eab_zero), assumption)
                return B.collapse(zero_one, d, Z)
            return B.BR(K.app(K.COMPARISON, d, Z), branch)
        return B.assumption(eq(E(a, b), O), retained)
    return B.forall("a", lambda sub, a:
        sub.forall("b", lambda sub2, b: at_b(sub2, a, b)))


def J(t):
    return choose(sign(t), Z, K.successor(pred(t)))


def coverage_clock(B, diag, reflect, failure):
    """All t: J(t)=t, with exactly one new FR occurrence."""
    def at_t(B, t):
        fn = lambda x: E(J(x), x)
        def premise(B, z, left):
            fz = fn(z)
            def branch(B, bit, p):
                if bit == 1:
                    destination = B.apply(B.instance(failure, fz, Z), p)
                    rules = (p, destination, B.instance(diag, Z))
                else:
                    rules = (p, B.instance(diag, K.successor(z)))
                return B.equality_by_normalization(left, Z, rules)
            return B.BR(K.app(K.COMPARISON, fz, Z), branch)
        fr = B.FR(fn, Z, t, premise)
        return B.apply(B.instance(reflect, J(t), t), fr)
    return B.forall("t", at_t)


def normalize_raw_comparison(B, clock, failure):
    """All a,b: e(a,b)=sigma(e(a,b)), without assuming coverage."""
    def at_b(B, a, b):
        raw = K.app(K.COMPARISON, a, b)
        identity = B.instance(clock, raw)
        def branch(B, bit, p):
            extra = () if bit == 0 else (B.apply(B.instance(failure, a, b), p),)
            reduced = B.equality_by_normalization(J(raw), Z if bit == 0 else O,
                                                (p, *extra))
            raw_bit = B.trans(B.sym(identity), reduced)
            return B.trans(raw_bit, B.sym(p))
        return B.BR(raw, branch)
    return B.forall("a", lambda sub, a:
        sub.forall("b", lambda sub2, b: at_b(sub2, a, b)))


def coverage(B, clock):
    """All x: x=0 or x=S(Px), derived with no Cov axiom."""
    def at_x(B, x):
        identity = B.instance(clock, x)
        alternatives = [eq(x, Z), eq(x, K.successor(pred(x)))]
        def branch(B, bit, p):
            target = Z if bit == 0 else K.successor(pred(x))
            reduced = B.equality_by_normalization(J(x), target, (p,))
            result = B.trans(B.sym(identity), reduced)
            return B.node("or_i", ["or", *alternatives], (result,), side=bit,
                          other=alternatives[1-bit])
        return B.BR(x, branch)
    return B.forall("x", at_x)


def main():
    output = (HERE.parent / "certificates") if HERE.name == "code" else (HERE / "certificates")
    output.mkdir(exist_ok=True)
    B = Builder()
    start = time.monotonic()
    print("Producing bad-diagonal certificate", flush=True)
    bad = bad_diagonal(B)
    print("Checking bad-diagonal certificate", flush=True)
    K.verify({"goal": bad.formula, "proof": bad.node})
    print("Bad diagonal accepted", flush=True)
    def use_bad(B, hb):
        dg = diagonal(B, hb)
        return B.let(dg, lambda sub, hd:
            sub.let(reflection(sub, hd), lambda sub2, hr:
                sub2.let(successor_nonzero(sub2, hr), lambda sub3, hs:
                    sub3.let(raw_failure(sub3, hd, hr, hs), lambda sub4, hf:
                        sub4.let(coverage_clock(sub4, hd, hr, hf), lambda sub5, hj:
                            sub5.and_intro(hd, hr, hf, hj, coverage(sub5, hj),
                                normalize_raw_comparison(sub5, hj, hf)))))))
    full = B.let(bad, use_bad)
    packet = {"goal": full.formula, "proof": full.node}
    print("Checking combined calibration certificate", flush=True)
    K.verify(packet)
    path = output / "calibration.json"
    with path.open("w") as stream:
        json.dump(packet, stream, separators=(",", ":"))
    print(json.dumps({"status": "ACCEPT", "bytes": path.stat().st_size,
                      "seconds": round(time.monotonic() - start, 3),
                      "path": str(path), "checker": str(CHECKER)}, indent=2), flush=True)


if __name__ == "__main__":
    main()
