"""Finite Boolean verification of the new three-spike lemma.

This checks exactly the finite truth-table calculations used in the proof.
It does not claim to establish induction, reflection or bi-interpretability.
"""
from itertools import product
import json


def exceptional(bits, j):
    return all(bits[k] == 1 for k in range(j)) and bits[j] == 0


def verify(positions):
    width = max(positions) + 1
    signatures = list(product((0, 1), repeat=width))
    successor_checks = 0
    for bits in signatures:
        successor = (1,) + bits[:-1]
        assert sum(exceptional(bits, j) for j in positions) <= 1
        for j in positions:
            if exceptional(bits, j):
                assert not exceptional(successor, j)
            successor_checks += 1
    choices = []
    for d in signatures:
        for q in signatures:
            available = [j for j in positions
                         if not exceptional(d, j) and not exceptional(q, j)]
            assert available
            choices.append(available[0])
    for j in positions:
        numeral = tuple(int(k < j) for k in range(width))
        assert exceptional(numeral, j)
    return {
        "positions": positions,
        "boolean_signatures": len(signatures),
        "successor_checks": successor_checks,
        "destination_pairs": len(choices),
        "all_passed": True,
    }


if __name__ == "__main__":
    print(json.dumps({"free_target": verify([0, 1, 2]),
                      "anchor_at_one": verify([0, 2, 3])}, indent=2))
