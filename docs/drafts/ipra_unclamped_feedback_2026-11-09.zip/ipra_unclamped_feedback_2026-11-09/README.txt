UNCLAMPED FEEDBACK FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
Research package prepared for Vladimir Reshetnikov, 9 November 2026
================================================================

RESULT AND LIMIT
----------------
The requested complete axiomatization strictly below the entire current
proof-checker frontier has NOT been obtained. This package does not claim
absolute simplestness or a global minimum-breaking construction.

It establishes a new mathematical simplification of the current feedback
proposal. The failed reset destination can be left unbounded: the outer
sign in sigma(P(e(value,anchor))) is unnecessary. The same numerical
language, Boolean sign-range axiom, separation sentence, ordinary logic,
and single reset-rule interface suffice with P(e(value,anchor)) instead.

The proof establishes a more general calibration theorem. A two-valued
spike encounters at most two failed destinations, even if those destinations
are unrestricted numerical values. Three transient spike shapes suffice to
avoid both. This forces the comparison's zero diagonal; a first ramp then
reflects actual equality, and a second ramp detects actual zero and forces
every failed destination to be zero. No numerical coverage or induction is
assumed in that calibration, and separation is not needed for its numerical
conclusions.

For the specific raw destination P(e(a,b)), the theory then proves that the
initially unspecified primitive e is exactly the zero/one equality test.
It recovers full contextual quantifier-free induction and is equiconsistent
and whole-domain bi-interpretable with full first-order intuitionistic PRA.
Both numerical composites have the identity graph x=y. The report explicitly
accounts for every relative primitive-recursive function description and
every logical rule; no quotient or standard-numeral restriction is used.

The mathematical result is relative to the inspected supplied corpus. No
literature-wide priority theorem is claimed.

START HERE
----------
ipra_unclamped_feedback.pdf
    The complete report, including the rule inventory, finite separation
    theorem, calibration, arithmetic recovery, both interpretation composites,
    boundary examples, measurements, and further research questions.

ipra_unclamped_feedback.tex and sections/
    The editable modular LaTeX source.

ipra_unclamped_feedback_standalone.tex
    The same complete report in one compilable LaTeX file.

COMPLETE IMPLEMENTATIONS AND MATCHED SAVINGS
------------------------------------------
code/checker.py is the complete arbitrary-anchor implementation. The previous
matched source measures 3316 normalized tokens, 3526 AST nodes, and 13382
normalized bytes; the new one measures 3313, 3523, and 13376, respectively.

code/anchored_checker.py supplies the fixed-anchor variant c=f(1). Its old
and new measurements are 3318/3528/13390 and 3315/3525/13384. Each pair saves
exactly 3 tokens, 3 AST nodes, and 6 normalized bytes. The implementations
differ from their matched baselines by exactly one expression deletion;
no source golfing, renaming, or unrelated refactoring is included.

These ordinary-logic checkers remain larger than the compact native programs
already in the corpus. The current coordinate envelope is 305 tokens,
340 AST nodes, and 820 bytes; excluding the iterable-alias implementation
gives 305/341/820. Different programs attain the different coordinates.
These are finite-corpus implementation measurements, not universal lower
bounds. Byte measurements also depend on identifier spelling.

The fixed-anchor interface has one fewer explicit certificate field, but its
straightforward implementation is slightly larger than the arbitrary-anchor
one because it constructs f(1) itself. No contrary size claim is made.

FULL CALIBRATION CERTIFICATE
---------------------------
certificates/calibration.json is a full closed proof packet for the supplied
complete arbitrary-anchor checker. It proves six universally closed results:
the comparison diagonal, actual equality reflection, the raw failure clamp,
the zero-fibre identity, numerical coverage, and e=sigma(e).

The certificate contains 21,101 proof nodes, including 19 reset applications,
115 Boolean-range instances, 4,602 literal computation steps, and 10,322
equality transports. Its maximum proof depth is 49. It uses ZERO Sep
instructions and ZERO falsity-elimination instructions. The theory still
retains separation for full ordinary intuitionistic arithmetic.

The certificate is accepted by fresh normal and optimized Python processes.
Eight targeted corruptions reject in both modes. Its six exact goal formulas
are independently reconstructed by the validator. Across the complete public
checker regressions, reset-contract controls, and certificate checks, the
recorded final validation comprises 400 CLI observations with zero failures.

This is not a finite-numeral sample or a fragment replay with arithmetic
lemmas declared as trusted axioms. It is also not a Lean or Rocq verification
of the checker or the entire bi-interpretability metatheory. The general
description compiler, fixed-anchor equivalence, and interpretation composites
remain written mathematical proofs, with independent assistant reviews.

FILE MAP
--------
code/checker.py, code/anchored_checker.py
    Complete standalone acceptance programs; only Python's standard library
    is imported. code/README.txt documents the entire public syntax and all
    18 instruction tags in each implementation.

code/certify_calibration.py
    Untrusted producer of the full numerical calibration certificate.
    Numerical normalization is compiled into literal compute and transport
    steps; the checker has no normalization or theorem oracle.

code/validate_feedback.py, code/validate_anchored.py
    Attributed public-interface regression suites, including malformed input,
    scope, capture, description arity, and forbidden comparison computation.
    They regenerate fixtures/ and anchored_fixtures/.

code/check_reset_contracts.py
    Independent old/new tests of eight exact reset-premise shapes for both
    interfaces. Rejection of an old premise by the new primitive instruction
    is a syntactic rule-matching control, not a theorem of nonderivability.

code/validate_calibration.py
    Independent six-goal check, public certificate replay, and targeted
    corruption controls.

code/check_finite_spikes.py
    Finite Boolean diagnostics for the separation argument. These supplement
    the written arbitrary-domain proof rather than replace it.

code/measure.py
    Hash checks, exact old/new source-difference checks, and whole-module
    measurements using the unchanged inherited normalizer.

reference/
    Unchanged matched feedback sources, seven compact native comparators,
    their normalizer, detailed provenance, and the inherited license.

certificates/
    Main certificate, structural receipt, and a precise statement of scope.

evidence/
    Detailed validation and measurement receipts; all 20 source-archive
    identities; complete Python inventory and corpus audit; independent
    mathematical/code reviews; and a larger synthesis experiment retained
    only as evidence of an unsuccessful complexity route.

build.py, reproduce.py, package.py
    Document build, offline verification, and deterministic archive creation.
    MANIFEST.json records every packaged payload file's size and SHA-256.

REPRODUCTION
------------
From this extracted directory, with Python's standard library:

  python3 reproduce.py

This replays the supplied complete certificate, runs the regressions and
targeted corruptions, checks the finite spike diagnostics, and remeasures
the unchanged comparison sources. Exact source-normalization values use
CPython 3.12.14; another Python release can format ast.unparse differently.

To regenerate the main certificate rather than merely replay it:

  python3 code/certify_calibration.py
  python3 code/validate_calibration.py

To rebuild the PDF and standalone LaTeX source:

  python3 build.py

This needs pdfLaTeX and the ordinary packages listed in the document
preamble. Shell escape is disabled. A local-only fallback can initialize a
missing TeX format from already installed TeX sources; it downloads nothing
and does not change system configuration. The compiled PDF is supplied.

To refresh the payload manifest and rebuild the ZIP:

  python3 package.py

The packaging script verifies every ZIP CRC and every manifested payload
hash, and excludes transient TeX files and Python caches. Verification and
reproduction can refresh receipts, so verify the original manifest before
rebuilding if original byte identity matters.

SOURCE SNAPSHOT
---------------
Repository: VladimirReshetnikov/ProveIt
Commit: 718c23f33f04b6b914699a0b02face47bd211be3
Directory: docs/drafts

All 20 current archives were checked against their Git blob SHA-1 and byte
lengths. Their SHA-256 hashes and pinned URLs are in evidence/source_archives.json.
The static audit inventoried 548 Python member occurrences and 202 distinct
sources. Inherited material is identified in ATTRIBUTION.txt and the more
detailed reference/ATTRIBUTION.txt. No remote repository was changed.
