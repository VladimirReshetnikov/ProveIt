#!/usr/bin/env python3
"""Create a deterministic archive with a verified SHA-256 payload manifest."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
NAME = ROOT.name
OUT = ROOT.parent / (NAME + ".zip")
EXCLUDED = {"build", "__pycache__"}
files = [p for p in ROOT.rglob("*") if p.is_file()
         and not EXCLUDED.intersection(p.relative_to(ROOT).parts)
         and p.name != "MANIFEST.json"
         and p.suffix not in {".pyc", ".aux", ".log", ".out", ".toc"}]
files.sort(key=lambda p: p.relative_to(ROOT).as_posix())
manifest = {
    "format": "sha256-payload-v1",
    "files": [{"path": p.relative_to(ROOT).as_posix(),
               "bytes": p.stat().st_size,
               "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
}
mp = ROOT / "MANIFEST.json"
mp.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
files.append(mp)
with zipfile.ZipFile(OUT, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(files, key=lambda q: q.relative_to(ROOT).as_posix()):
        name = NAME + "/" + p.relative_to(ROOT).as_posix()
        info = zipfile.ZipInfo(name, (2026, 11, 9, 12, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        z.writestr(info, p.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(OUT) as z:
    bad = z.testzip()
    if bad:
        raise ValueError("ZIP CRC failed: " + bad)
    for entry in manifest["files"]:
        body = z.read(NAME + "/" + entry["path"])
        if len(body) != entry["bytes"] or hashlib.sha256(body).hexdigest() != entry["sha256"]:
            raise ValueError("Payload mismatch: " + entry["path"])
print(json.dumps({"archive": str(OUT), "payload_files": len(manifest["files"]),
                  "bytes": OUT.stat().st_size,
                  "sha256": hashlib.sha256(OUT.read_bytes()).hexdigest()}, indent=2))

