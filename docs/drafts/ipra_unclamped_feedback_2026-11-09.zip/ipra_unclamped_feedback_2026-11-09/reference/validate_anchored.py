#!/usr/bin/env python3
"""Focused independent fixtures for the fixed-anchor feedback variant."""
import copy
import json
from pathlib import Path
import platform
import subprocess
import sys

import upstream_fixtures as u
import validate_feedback as f

ROOT = Path(__file__).resolve().parent
CHECKER = ROOT / "feedback_anchored_checker.py"


def schema(template, target, parameters, old=False, wrong_anchor=False):
    x = "z"
    anchor = u.replace_term(template, x, u.ZERO if wrong_anchor else u.ONE)
    rho = f.reset(template, anchor, u.v(x), old)
    body = u.e(u.replace_term(template, x, rho), anchor)
    assumption = ["all", x, body]
    application = u.node("SR", u.node("all_e", u.hyp(0), term=u.v(x)),
                         var=x, template=template, at=target)
    goal = ["imp", assumption, u.e(u.replace_term(template, x, target), anchor)]
    return u.packet(u.forall(parameters, goal),
                    u.generalize(parameters, u.node("imp_i", application, assume=assumption)))


def fixtures():
    old_positive, old_negative = u.fixtures()
    positive = {"inherited_" + k: v for k, v in old_positive.items()
                if not (u.used_rules(v["proof"]) & {"SR"})}
    negative = {"inherited_" + k: v for k, v in old_negative.items()
                if not (u.used_rules(v["proof"]) & {"SR"})}
    primary_positive, primary_negative = f.fixtures()
    for label in ["comparison_reflexivity", "comparison_in_composition", "comparison_in_recursion"]:
        positive[label] = primary_positive[label]
    for label in ["compare_has_no_equation", "compare_tag_has_no_arguments", "compare_wrong_arity",
                  "comparison_does_not_compute_by_reflexivity"]:
        negative[label] = primary_negative[label]
    positive["constant_reset"] = u.packet(u.e(u.ZERO, u.ZERO),
        u.node("SR", u.refl(u.ZERO), var="z", template=u.ZERO, at=u.TWO))
    positive["parameter_reset"] = u.packet(
        u.forall(["a", "t"], u.e(u.v("a"), u.v("a"))),
        u.generalize(["a", "t"], u.node("SR", u.refl(u.v("a")), var="z",
                                        template=u.v("a"), at=u.v("t"))))
    positive["identity_schema"] = schema(u.v("z"), u.v("t"), ["t"])
    positive["comparison_schema"] = schema(f.comparison(u.v("z"), u.v("a")),
                                           u.v("t"), ["a", "t"])
    negative["old_zero_fallback"] = schema(u.v("z"), u.v("t"), ["t"], old=True)
    negative["anchor_zero_instead_of_one"] = schema(u.v("z"), u.v("t"), ["t"], wrong_anchor=True)
    for label in ["reset_wrong_premise", "reset_target_escape", "reset_template_escape",
                  "reset_variable_reused", "reset_formula_as_template", "reset_hidden_induction_hypothesis",
                  "reset_extra_premise", "reset_arbitrary_anchor_field", "reset_unchecked_target_even_if_unused"]:
        negative[label] = old_negative[label]
    negative["free_anchor_rule_rejected"] = primary_positive["arbitrary_anchor_schema"]
    return positive, negative


def main():
    checker = u.load_checker(CHECKER)
    positive, negative = fixtures()
    output = ROOT.parent / "anchored_fixtures"
    output.mkdir(exist_ok=True)
    runs, failures = [], []
    coverage = set()
    for expected, group in ((True, positive), (False, negative)):
        for label, packet in group.items():
            (output / (label + ".json")).write_text(json.dumps(packet, indent=2) + "\n")
            if expected:
                coverage |= u.used_rules(packet["proof"])
            for flags in ([], ["-O"]):
                run = subprocess.run([sys.executable, *flags, str(CHECKER)], input=json.dumps(packet),
                                     text=True, capture_output=True, timeout=15)
                passed = ((run.returncode == 0 and run.stdout == "ACCEPT\n" and not run.stderr)
                          if expected else
                          (run.returncode == 1 and not run.stdout and run.stderr.startswith("REJECT:")))
                runs.append({"case": label, "expected": expected, "optimized": bool(flags), "passed": passed})
                if not passed:
                    failures.append(label + ": " + repr(flags))
    if coverage != set(checker.RULES):
        failures.append("Rule coverage differs: " + repr(coverage ^ set(checker.RULES)))
    result = {"python": platform.python_version(), "accepted_packets": len(positive),
              "rejected_packets": len(negative), "public_cli_runs": len(runs),
              "rule_coverage": sorted(coverage), "failures": failures,
              "anchored_metrics": u.measure(CHECKER),
              "free_anchor_metrics": u.measure(ROOT / "feedback_checker.py"),
              "baseline_metrics": u.measure(ROOT / "baseline_raw_reset.py"), "runs": runs}
    (ROOT.parent / "anchored_validation.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "runs"}, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
