FULL NUMERICAL CALIBRATION CERTIFICATE
=====================================

calibration.json is a closed proof packet for the complete code/checker.py.
It is a nested conjunction of these six universally closed statements:

  1. E(a,a)=0.
  2. E(a,b)=0 implies a=b.
  3. E(a,b)=1 implies P(e(a,b))=0.
  4. C(sigma(t),0,S(P(t)))=t.
  5. x=0 or x=S(P(x)).
  6. e(a,b)=sigma(e(a,b)).

Here E(a,b)=sigma(e(a,b)); the comparison e has no defining equation.
Every occurrence of a fixed numerical operation is expanded to its explicit
relative primitive-recursive description in the public certificate syntax.

The packet contains 21,101 proof nodes, including 19 applications of the raw
feedback rule FR, 115 Boolean-range instances, 4,602 literal computation
steps, and 10,322 equality transports. Maximum proof depth is 49. It contains
ZERO Sep instructions and ZERO bot_e instructions. Numerical collapse is
derived through the selector equations and equality replacement.

REPLAY
------
From the package root:

  python3 code/checker.py < certificates/calibration.json
  python3 -O code/checker.py < certificates/calibration.json
  python3 code/validate_calibration.py

The validator independently reconstructs the six exact goal formulas, counts
the actual proof nodes, confirms the absence of Sep and bot_e, and invokes
fresh ordinary and optimized public checker processes. Eight targeted
corruptions reject in both modes. The original certificate also rejects when
submitted directly to the old clamped-reset checker: the new primitive rule
has a different exact premise. This last check does not assert that the new
arithmetic theorems are unprovable by longer derivations in the old theory.

The detailed independent receipt is evidence/calibration_validation.json;
the six explicit JSON goal formulas are evidence/calibration_goals.json.
receipt.json records structural counts and the primary certificate hash.

REPRODUCTION
------------
  python3 code/certify_calibration.py

The untrusted producer regenerates calibration.json and checks its result.
It imports the complete checker for data constructors, substitution, and
final validation, but never modifies the checker's inference rules. Its
normalization routines emit explicit compute and transport nodes; the
acceptance program has no normalization shortcut or imported theorem oracle.
The supplied independent validation should be rerun after regeneration.

SCOPE
-----
This is a full derivation of the six closed universal statements in the
supplied ordinary-logic arithmetic checker. It is not a finite-numeral test
or a fragment replay with unproved arithmetic lemmas declared as axioms.
The complete checker itself has not been formally verified in Lean or Rocq.
The general primitive-recursive description round trips and the universal
bi-interpretability metatheorem remain written mathematical proofs.

The certificate uses the arbitrary-anchor FR interface. The fixed-anchor
SR variant has complete implementation and regression tests, and its full
arithmetic equivalence is proved in the report; this packet is not claimed
as a direct SR certificate.

The six numerical results do not need separation. The full theory still
retains Sep to connect0=1 to genuine falsity and recover the requested full
intuitionistic arithmetic. Removing Sep from the theory would leave a
one-element model and would change the interpretation claim.

Certificate SHA-256:
11b02f322b5cfeb8052d64f9532ce10284d44a0266adc068176165a008d7c11c
