#!/usr/bin/env python3
"""Replay supplied proofs, targeted checks, and the complete-source comparison."""
from pathlib import Path
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SCRIPTS = [
    "code/validate_feedback.py",
    "code/validate_anchored.py",
    "code/check_reset_contracts.py",
    "code/check_finite_spikes.py",
    "code/validate_calibration.py",
    "code/measure.py",
]
env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
for script in SCRIPTS:
    run = subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT,
                         env=env, capture_output=True, text=True)
    if run.returncode:
        print(run.stdout, end="")
        print(run.stderr, end="", file=sys.stderr)
        raise SystemExit(run.returncode)
    if script.endswith("check_finite_spikes.py"):
        (ROOT / "evidence/finite_spikes.json").write_text(run.stdout, encoding="utf-8")
    print("PASS", script)
print("All proof, scope, mutation, and comparison checks passed.")

