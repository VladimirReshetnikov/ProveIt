#!/usr/bin/env python3
"""Fresh exact preorder audit, independent of all producer/verifier modules.
Default n=6 checks every certificate and complete isomorphism/duality coverage.
For n=7 --allow-partial reports missing certificates without approving a theorem.
"""
from pathlib import Path
from itertools import combinations,permutations,product
from collections import Counter,defaultdict
from functools import lru_cache
from fractions import Fraction as F
from hashlib import sha256
from math import comb
import json,sys,time,argparse

ap=argparse.ArgumentParser();ap.add_argument('--n',type=int,choices=(6,7),default=6);ap.add_argument('--source',default='/workspace/shared/weighted-preorder-gamma');ap.add_argument('--allow-partial',action='store_true');args=ap.parse_args()
N=args.n;ROOT=Path(args.source);OUT=Path(__file__).resolve().parent/f'n{N}';OUT.mkdir(exist_ok=True);START=time.time()

def bits(mask):
    while mask:
        bit=mask&-mask;yield bit.bit_length()-1;mask^=bit

def transpose(rows):
    n=len(rows)
    return tuple(sum(1<<a for a in range(n) if rows[a]>>b&1) for b in range(n))

def validate_preorder(rows):
    n=len(rows);assert all(type(x)is int and 0<=x<(1<<n) and not x>>i&1 for i,x in enumerate(rows))
    reflex=tuple(x|(1<<i) for i,x in enumerate(rows))
    assert all(reflex[b]&~reflex[a]==0 for a in range(n) for b in bits(reflex[a]))

def undirected(rows):return tuple(x|y for x,y in zip(rows,transpose(rows)))

def branch(rows):
    n=len(rows);adj=undirected(rows)
    @lru_cache(None)
    def maximum(mask):
        if not mask:return 0
        low=mask&-mask;a=low.bit_length()-1;rest=mask^low
        return max([maximum(rest)]+[1+maximum(rest^(1<<b)) for b in bits(adj[a]&rest)])
    degree=maximum((1<<n)-1)
    if degree<=2:return 'rank_at_most_two'
    assert degree==3
    todo=[0];seen={0}
    for a in todo:
        for b in bits(adj[a]):
            if b not in seen:seen.add(b);todo.append(b)
    if len(seen)!=n:return 'disconnected_rank3'
    colors={0:0};bip=True
    for a in todo:
        for b in bits(adj[a]):
            if b not in colors:colors[b]=1-colors[a]
            elif colors[b]==colors[a]:bip=False
    if bip:
        incoming=transpose(rows)
        assert all(not rows[a] or not incoming[a] for a in range(n))
        assert all(not (rows[a]>>b&1 and rows[b]>>a&1) for a in range(n) for b in range(n))
        tails=sum(bool(x) for x in rows);heads=sum(bool(x) for x in incoming)
        assert min(tails,heads)==3 and tails+heads==n
        return 'connected_bipartite_rank3'
    if all(adj[a]==((1<<n)-1)^(1<<a) for a in range(n)):return 'total_rank3'
    return 'nontotal_connected_nonbip_rank3'

def forward_posets(n):
    """Flat forward-arc masks, followed by direct transitivity, not recursion
    through ideals/downsets and not the producer's equivalence-class generator.
    """
    pairs=list(combinations(range(n),2))
    for mask in range(1<<len(pairs)):
        rows=[0]*n
        for bit,(a,b) in enumerate(pairs):
            if mask>>bit&1:rows[a]|=1<<b
        if all(rows[b]&~rows[a]==0 for a in range(n) for b in bits(rows[a])):
            yield tuple(rows)

def compositions(total,parts):
    if parts==1:
        if total>=1:yield(total,)
    else:
        for first in range(1,total-parts+2):
            for tail in compositions(total-first,parts-1):yield(first,)+tail

def expand(quotient,sizes):
    labels=tuple(i for i,size in enumerate(sizes) for _ in range(size))
    return tuple(sum(1<<b for b in range(len(labels)) if a!=b and (labels[a]==labels[b] or quotient[labels[a]]>>labels[b]&1)) for a in range(len(labels)))

def permute(rows,order):
    n=len(rows);inv=[0]*n
    for new,old in enumerate(order):inv[old]=new
    return tuple(sum(1<<inv[b] for b in bits(rows[a])) for a in order)

@lru_cache(None)
def directed_canonical(rows):
    """Exact colored canonical form: degree signatures are isomorphism
    invariants. All orderings within every equal-signature bucket are examined.
    Sorting signatures first loses no possible isomorphism.
    """
    incoming=transpose(rows);groups=defaultdict(list)
    for i in range(len(rows)):groups[(rows[i].bit_count(),incoming[i].bit_count())].append(i)
    keys=sorted(groups);best=None
    for pieces in product(*(list(permutations(groups[k])) for k in keys)):
        order=tuple(v for piece in pieces for v in piece)
        cand=permute(rows,order)
        if best is None or cand<best:best=cand
    return best

def canonical(rows):return min(directed_canonical(rows),directed_canonical(transpose(rows)))

def role_polynomials(rows):
    n=len(rows);levels=[{(0,)*(2*n):1}];supports=[{(0,0)}];tested=0
    for k in range(1,n//2+1):
        P={};ss=set()
        for aa in combinations(range(n),k):
            A=sum(1<<a for a in aa)
            for bb in combinations(tuple(bits(((1<<n)-1)^A)),k):
                B=sum(1<<b for b in bb)
                okay=True;sub=A
                while sub:
                    union=0
                    for a in bits(sub):union|=rows[a]
                    if (union&B).bit_count()<sub.bit_count():okay=False;break
                    sub=(sub-1)&A
                witness=any(all(rows[a]>>b&1 for a,b in zip(aa,order)) for order in permutations(bb))
                assert okay==witness
                tested+=1
                if okay:
                    exp=tuple((A>>i)&1 for i in range(n))+tuple((B>>i)&1 for i in range(n))
                    assert exp not in P;P[exp]=1;ss.add((A,B))
        levels.append(P);supports.append(ss)
    return levels,supports,tested

def plus(a,b):assert len(a)==len(b);return tuple(x+y for x,y in zip(a,b))

def multiply(P,Q):
    out=defaultdict(F)
    for a,u in P.items():
        for b,v in Q.items():out[plus(a,b)]+=u*v
    return dict(out)

def exponent(e,dim):
    assert isinstance(e,list) and len(e)==dim and all(type(x)is int and x>=0 for x in e)
    return tuple(e)

def exact_check(row,raw):
    n=row['n'];rows=tuple(row['rows']);assert n==N and row['mode']=='role'
    validate_preorder(rows);assert branch(rows)=='nontotal_connected_nonbip_rank3'
    g,ss,tested=role_polynomials(rows);assert g[3]
    # Role duality independently checked at support level, not inferred from the
    # producer's symmetry handling.
    gd,sd,_=role_polynomials(transpose(rows))
    assert all({(B,A) for A,B in ss[k]}==sd[k] for k in range(4))
    P=defaultdict(F,multiply(g[2],g[2]))
    for e,c in multiply(g[1],g[3]).items():P[e]-=3*c
    remainder=defaultdict(F,P);squares=defaultdict(F)
    for q,term in row['terms']:
        assert isinstance(q,(str,int));q=F(q);assert q>0
        mon,inner=term;m=exponent(mon,2*n);Q=defaultdict(F)
        for a,c in inner:
            assert isinstance(c,(str,int));Q[exponent(a,2*n)]+=F(c)
        for e,c in multiply(Q,Q).items():
            e=plus(m,e);assert sum(e[:n])==sum(e[n:])==4
            squares[e]+=q*c;remainder[e]-=q*c
    assert all(c>=0 for c in remainder.values()),(row['id'],min(remainder.values()))
    assert all(P.get(e,F(0))==squares.get(e,F(0))+remainder.get(e,F(0)) for e in P.keys()|squares.keys()|remainder.keys())
    rem=[[list(e),str(c)] for e,c in sorted(remainder.items()) if c>0]
    rem_bytes=(json.dumps(rem,separators=(',',':'))+'\n').encode()
    rem_name=f"remainder_t{row['id']:03d}.json";(OUT/rem_name).write_bytes(rem_bytes)
    return {'id':row['id'],'rows':rows,'certificate_sha256':sha256(raw).hexdigest(),
            'hall_candidate_tests':tested,'support_counts':list(map(len,ss)),
            'square_terms':len(row['terms']),'positive_remainder_terms':len(rem),
            'remainder_file':rem_name,'remainder_sha256':sha256(rem_bytes).hexdigest(),
            'nonnegative_integer_exponents_and_dimensions':True,
            'positive_rational_square_weights':True,'bidegree_4_4':True,
            'exact_identity_verified':True,'duality_supports_verified':True}

manifest_path=ROOT/f'nontotal{N}_templates.json';manifest_raw=manifest_path.read_bytes();manifest=json.loads(manifest_raw)
reps=manifest['templates'];assert len({r['id'] for r in reps})==len(reps)
by_canonical={};by_id={};audits=[];missing=[]
for rep in reps:
    rows=tuple(rep['rows']);validate_preorder(rows);assert len(rows)==N
    assert branch(rows)=='nontotal_connected_nonbip_rank3'
    key=canonical(rows);assert key not in by_canonical,('duplicate orbit',rep['id'],by_canonical.get(key))
    by_canonical[key]=rep['id'];by_id[rep['id']]=rep
    path=ROOT/f'nontotal{N}_certificates'/f"t{rep['id']:03d}.json"
    if not path.exists():missing.append(rep['id']);continue
    raw=path.read_bytes();row=json.loads(raw)
    assert row['id']==rep['id'] and tuple(row['rows'])==rows
    audits.append(exact_check(row,raw))
    if len(audits)%50==0:print('certificates',len(audits),'of',len(reps),flush=True)

# At n=6 additionally expand EVERY n! permutation and its order dual, without
# invariant pruning, giving a separate full-group coverage table. For n=7 the
# exact invariant canonicalizer avoids a large memory footprint.
full_orbits={};full_group_actions=0
if N==6:
    perms=list(permutations(range(N)))
    for rep in reps:
        for rows in (tuple(rep['rows']),transpose(rep['rows'])):
            for order in perms:
                p=permute(rows,order);owner=full_orbits.setdefault(p,rep['id'])
                assert owner==rep['id'];full_group_actions+=1

coverage=Counter();multiplicity=Counter();quotient_counts=[];config_rows=[]
for q in range(1,N+1):
    count=0
    sizes_all=list(compositions(N,q));assert len(sizes_all)==comb(N-1,q-1)
    for quotient in forward_posets(q):
        count+=1
        for sizes in sizes_all:
            rows=expand(quotient,sizes);validate_preorder(rows)
            category=branch(rows);coverage[category]+=1;coverage['configurations']+=1
            if category=='nontotal_connected_nonbip_rank3':
                key=canonical(rows);assert key in by_canonical,('missing orbit',q,quotient,sizes,rows)
                ident=by_canonical[key]
                if N==6:assert full_orbits[rows]==ident
                multiplicity[ident]+=1
                config_rows.append({'quotient_rows':quotient,'block_sizes':sizes,'rows':rows,'target_id':ident})
    quotient_counts.append(count)
    print('quotient_size',q,'posets',count,'configs_so_far',coverage['configurations'],flush=True)
assert set(multiplicity)==set(by_id)
for ident,rep in by_id.items():assert multiplicity[ident]==rep['multiplicity'],('multiplicity',ident,multiplicity[ident],rep['multiplicity'])
assert coverage['configurations']==manifest['summary']['configurations']
assert coverage['nontotal_connected_nonbip_rank3']==manifest['summary']['retained_configurations']
assert len(reps)==manifest['summary']['distinct_up_to_isomorphism_and_duality']
if N==6:
    assert quotient_counts==[1,2,7,40,357,4824]
    assert dict(coverage)=={'configurations':7090,'rank_at_most_two':3183,'disconnected_rank3':515,'connected_bipartite_rank3':301,'total_rank3':32,'nontotal_connected_nonbip_rank3':3059}
    assert len(audits)==223 and not missing
    assert sum(r['square_terms'] for r in audits)==586
    assert sum(r['positive_remainder_terms'] for r in audits)==31094
    claimed=json.loads((ROOT/'nontotal6_complete_verification.json').read_text())
    claims={r['id']:r for r in claimed['target_audits']}
    assert set(claims)==set(by_id)
    for r in audits:
        assert tuple(claims[r['id']]['rows'])==tuple(r['rows'])
        assert claims[r['id']]['sha256']==r['certificate_sha256']

summary={'all_available_certificates_passed':True,'complete_certificate_set':not missing,
         'all_passed':not missing,'n':N,'representatives':len(reps),'checked_certificates':len(audits),
         'missing_certificate_ids':missing,'hall_candidate_tests':sum(r['hall_candidate_tests'] for r in audits),
         'additional_dual_hall_candidate_tests':sum(r['hall_candidate_tests'] for r in audits),
         'square_terms':sum(r['square_terms'] for r in audits),
         'positive_remainder_terms':sum(r['positive_remainder_terms'] for r in audits),
         'full_group_actions':full_group_actions,'distinct_labeled_orbit_members':len(full_orbits),
         'coverage':dict(coverage),'quotient_counts':quotient_counts,'seconds':round(time.time()-START,3),
         'source_manifest_sha256':sha256(manifest_raw).hexdigest(),
         'audit_script_sha256':sha256(Path(__file__).read_bytes()).hexdigest()}
out={'summary':summary,'target_audits':audits,'relevant_configuration_coverage':config_rows}
(OUT/'receipt.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(summary,indent=2),flush=True)
if missing and not args.allow_partial:raise SystemExit('Incomplete certificate set: no theorem approval')
