# Complete independent-role degree-three audit

Read AUDIT.md and approval_receipt.json. Run:

    python /path/to/this/folder/verify_all.py

Python 3 standard library only; no network, compiler, optimizer, or LaTeX is required for this bundle. The replay uses temporary extracted copies, preserving the approved source receipts, and writes portable_replay.json. Expect roughly 1-2 minutes. The full article's separate companion role-cover replay also uses its included C++17 sources.

This bundle contains the full pure-role finite and structural dependency closure. It contains no vertex-specialized certificate as a proof dependency. The published HPP list is factual matroid data with attribution and provenance in its nested audit; whole external research papers are not redistributed. SHA256SUMS pins every included source and approved receipt. The original complete replay is preserved as approved_replay.json; new runs write the separate, unpinned portable_replay.json output, so replaying repeatedly is supported.
