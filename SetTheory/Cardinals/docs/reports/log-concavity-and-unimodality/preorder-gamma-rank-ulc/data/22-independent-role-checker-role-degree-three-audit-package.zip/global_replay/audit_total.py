#!/usr/bin/env python3
"""Independent standard-library audit. No imports from the producer or its verifiers.

Run: python audit.py [source_dir]
Reconstructs Hall supports; checks them against permutation witnesses; expands every
selected rational orthant-square certificate; verifies the 96-template reduction
manifest; exercises boundary refinements with exact rational activities.
"""
from collections import Counter, defaultdict
from fractions import Fraction
from functools import lru_cache
from itertools import combinations, permutations
from pathlib import Path
from hashlib import sha256
import json, random, sys, time

ROOT=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/shared/weighted-preorder-gamma')
OUT=Path(__file__).resolve().parent
F=Fraction
START=time.time()

def sha(path): return sha256(path.read_bytes()).hexdigest()

def comps(n):
    if not n:
        yield ()
    else:
        for first in range(1,n+1):
            for tail in comps(n-first): yield (first,)+tail

def labels(b): return tuple(i for i,size in enumerate(b) for _ in range(size))

def bits(mask):
    while mask:
        low=mask&-mask
        yield low.bit_length()-1
        mask^=low

@lru_cache(None)
def support_sets(b):
    """All ordered disjoint endpoint supports, each counted once, Hall method.
    Also cross-check every candidate by explicit bijection permutations.
    """
    cls=labels(b); n=len(cls); full=(1<<n)-1
    neighbors=tuple(sum(1<<j for j in range(n) if j!=i and cls[i]<=cls[j]) for i in range(n))
    levels=[[(0,0)]]
    tested=0
    for k in range(1,n//2+1):
        level=[]
        for aa in combinations(range(n),k):
            A=sum(1<<a for a in aa)
            for bb in combinations(tuple(bits(full^A)),k):
                B=sum(1<<b for b in bb)
                H=True; U=A
                while U:
                    N=0
                    for a in bits(U): N|=neighbors[a]
                    if (N&B).bit_count()<U.bit_count(): H=False;break
                    U=(U-1)&A
                W=any(all(neighbors[a]&(1<<b) for a,b in zip(aa,order)) for order in permutations(bb))
                assert H==W,('Hall/witness disagreement',b,A,B)
                tested+=1
                if H: level.append((A,B))
        levels.append(level)
    assert levels[-1],('wrong actual degree',b)
    return tuple(tuple(level) for level in levels),tested

def role_exp(A,B,n):
    return tuple((A>>i)&1 for i in range(n))+tuple((B>>i)&1 for i in range(n))

def polynomial_levels(b):
    ss,_=support_sets(b); n=sum(b)
    return [Counter(role_exp(A,B,n) for A,B in level) for level in ss]

def expadd(a,b):
    assert len(a)==len(b)
    return tuple(x+y for x,y in zip(a,b))

def product(P,Q):
    R=defaultdict(F)
    for a,ca in P.items():
        for b,cb in Q.items(): R[expadd(a,b)]+=ca*cb
    return dict(R)

def gap(b):
    G=polynomial_levels(b)
    P=defaultdict(F,product(G[2],G[2]))
    for e,c in product(G[1],G[3]).items(): P[e]-=3*c
    return dict(P)

def validate_exp(e,dim):
    assert isinstance(e,list) and len(e)==dim
    assert all(type(x) is int and x>=0 for x in e),e
    return tuple(e)

def check_certificate(b,path):
    row=json.loads(path.read_text())
    assert row['mode']=='role' and tuple(row['blocks'])==b
    dim=2*sum(b); P=gap(b); R=defaultdict(F,P); squares=defaultdict(F)
    q_min=None; inner_count=0
    for entry in row['terms']:
        assert isinstance(entry,list) and len(entry)==2
        q=F(entry[0]); assert q>0
        q_min=q if q_min is None else min(q_min,q)
        multiplier,terms=entry[1]
        m=validate_exp(multiplier,dim); S=defaultdict(F)
        for exponent,coefficient in terms:
            e=validate_exp(exponent,dim); c=F(coefficient)
            assert c!=0
            S[e]+=c; inner_count+=1
        assert any(S.values())
        expansion=product(S,S)
        for e,c in expansion.items():
            out=expadd(m,e)
            assert sum(out[:dim//2])==4 and sum(out[dim//2:])==4
            squares[out]+=q*c
            R[out]-=q*c
    assert all(c>=0 for c in R.values()),('negative remainder',b,min(R.values()))
    assert all(squares.get(e,F(0))+R.get(e,F(0))==P.get(e,F(0)) for e in P.keys()|squares.keys()|R.keys())
    positive=sorted((e,c) for e,c in R.items() if c>0)
    remainder_blob=json.dumps([[list(e),str(c)] for e,c in positive],separators=(',',':'))
    # A portable positive remainder closes the certificate without relying on
    # implementation-specific sparse-polynomial formatting.
    outfile=OUT/('remainder_'+''.join(map(str,b))+'.json')
    outfile.write_text(remainder_blob+'\n')
    return {'blocks':b,'certificate':path.name,'certificate_sha256':sha(path),
            'hall_gamma_support_counts':[len(s) for s in support_sets(b)[0]],
            'square_terms':len(row['terms']),'inner_polynomial_terms':inner_count,
            'smallest_square_weight':str(q_min) if q_min else None,
            'positive_remainder_terms':len(positive),'remainder_file':outfile.name,
            'remainder_sha256':sha(outfile),'exact_identity_verified':True,
            'all_exponents_nonnegative_integers_of_correct_dimension':True,
            'all_terms_correct_bidegree':True}

def canonical(b):
    steps=[]
    if b[0] in (2,3):
        k=b[0];b=(1,)*k+b[1:];steps.append({'action':'refine_initial_block','size':k})
    if b[-1] in (2,3):
        k=b[-1];b=b[:-1]+(1,)*k;steps.append({'action':'refine_final_block','size':k})
    if b[::-1]<b:
        b=b[::-1];steps.append({'action':'reverse_order_and_swap_roles'})
    return b,steps

def gamma_values(b,u,v):
    ss,_=support_sets(b); out=[]
    for level in ss:
        value=F(0)
        for A,B in level:
            w=F(1)
            for i in bits(A): w*=u[i]
            for i in bits(B): w*=v[i]
            value+=w
        out.append(value)
    return out

def refine_initial(b,u,v):
    s=b[0];assert s in (2,3)
    # Relabelling only within an equivalence class is an exact symmetry.
    order=sorted(range(s),key=lambda i:u[i])+list(range(s,len(u)))
    u=[u[i] for i in order];v=[v[i] for i in order]
    w=v.copy()
    if s==2:
        w[1]=v[1]+u[1]*v[0]/u[0]
    else:
        x,y,z=u[:3]
        a=sum(u[i]*v[j] for i in range(3) for j in range(3) if i!=j)
        c=u[1]*u[2]*v[0]+u[0]*u[2]*v[1]+u[0]*u[1]*v[2]
        delta=z*(x+y)-x*y
        assert delta>0
        w[1]=((x+y)*c-x*y*a)/(x*delta)
        w[2]=(z*a-c)/delta
        assert x*w[1]+(x+y)*w[2]==a
        assert x*z*w[1]+x*y*w[2]==c
    assert all(t>=0 for t in w)
    return (1,)*s+b[1:],u,w

def apply_steps(b,u,v,steps):
    zeros=0
    for step in steps:
        old=gamma_values(b,u,v)
        if step['action']=='refine_initial_block':
            assert b[0]==step['size'];b,u,v=refine_initial(b,u,v)
        elif step['action']=='refine_final_block':
            assert b[-1]==step['size']
            dual,du,dv=refine_initial(b[::-1],v[::-1],u[::-1])
            b,u,v=dual[::-1],dv[::-1],du[::-1]
        elif step['action']=='reverse_order_and_swap_roles':
            b,u,v=b[::-1],v[::-1],u[::-1]
        else: raise AssertionError(step)
        assert gamma_values(b,u,v)==old,('boundary or dual identity',b,step)
        zeros+=sum(t==0 for t in u+v)
    return b,u,v,zeros

def local_states(b,u,v):
    """Feasible boundary states indexed by (tail count, head count), no
    equality-of-counts requirement; explicit internal injection existence.
    """
    cls=labels(b); n=len(cls); result=defaultdict(F)
    for A in range(1<<n):
        unused=((1<<n)-1)^A;B=unused
        while True:
            aa=tuple(bits(A));bb=tuple(bits(B))
            if len(aa)>=len(bb) and any(all(cls[t]<cls[h] or cls[t]==cls[h] for t,h in zip(tails,bb)) for tails in permutations(aa,len(bb))):
                w=F(1)
                for t in aa:w*=u[t]
                for h in bb:w*=v[h]
                result[(len(aa),len(bb))]+=w
            if B==0:break
            B=(B-1)&unused
    return dict(result)

def main():
    authoritative=json.loads((ROOT/'role_total_degree3_complete_verification.json').read_text())
    allb=list(comps(6))+list(comps(7))
    assert len(allb)==96 and len(set(allb))==96
    mapping={tuple(r['blocks']):r for r in authoritative['coverage']}
    assert len(authoritative['coverage'])==96 and set(mapping)==set(allb)
    coverage=[];needed=set();total_candidates=0;total_supports=0
    for b in allb:
        target,steps=canonical(b);needed.add(target)
        row=mapping[b]
        assert row['n']==sum(b) and tuple(row['target'])==target and row['steps']==steps
        assert row['certificate']=='sos_role_'+''.join(map(str,target))+'.json'
        levels,tested=support_sets(b);total_candidates+=tested;total_supports+=sum(map(len,levels))
        # Independently check role-swap/order-reversal on every support.
        reverse=lambda mask:sum(1<<(sum(b)-1-i) for i in bits(mask))
        dual=support_sets(b[::-1])[0]
        assert all({(reverse(B),reverse(A)) for A,B in levels[k]}==set(dual[k]) for k in range(len(levels)))
        coverage.append({'blocks':b,'target':target,'steps':steps,'support_counts':list(map(len,levels))})
    assert len(needed)==24
    expected_audits={tuple(r['blocks']):r for r in authoritative['target_audits']}
    assert set(expected_audits)==needed and len(authoritative['target_audits'])==24
    audits=[]
    for b in sorted(needed):
        path=ROOT/('sos_role_'+''.join(map(str,b))+'.json')
        result=check_certificate(b,path);audits.append(result)
        prev=expected_audits[b]
        assert result['square_terms']==prev['square_terms'] and result['positive_remainder_terms']==prev['positive_remainder_terms']
        print('PASS',b,result['square_terms'],result['positive_remainder_terms'],flush=True)
    # Full reduction paths with rational activities, equal activities, and
    # independently varied heads/tails. Every intermediate polynomial is checked.
    rng=random.Random(20261001);weighted_cases=0;zeros=0
    for b in allb:
        target,steps=canonical(b);n=sum(b)
        for trial in range(12):
            u=[F(rng.randrange(1,12),rng.randrange(1,8)) for _ in range(n)]
            v=[F(rng.randrange(1,12),rng.randrange(1,8)) for _ in range(n)]
            if trial==0:u=[F(1)]*n
            if trial==1:v=[F(1)]*n
            if trial==2:u=v=[F(1)]*n
            orig=gamma_values(b,u,v)
            end,uu,vv,z=apply_steps(b,u,v,steps);zeros+=z
            assert end==target and orig==gamma_values(target,uu,vv)
            d=n//2
            assert orig[1]**2>=F(2*d,d-1)*orig[2]
            assert orig[2]**2>=3*orig[1]*orig[3]
            weighted_cases+=1
    # Local-state signatures across diverse weights test the all-rank argument,
    # separately from the degree-three continuation/reduction paths.
    local_cases=0
    for size in (2,3):
        for trial in range(120):
            u=[F(rng.randrange(1,12),rng.randrange(1,8)) for _ in range(size)]
            v=[F(rng.randrange(1,12),rng.randrange(1,8)) for _ in range(size)]
            if trial%12==0:u=[F(1)]*size
            b2,uu,vv=refine_initial((size,),u,v)
            assert local_states((size,),u,v)==local_states(b2,uu,vv)
            local_cases+=1
    summary={'all_passed':True,'covered_n6_templates':32,'covered_n7_templates':64,
             'all_hall_candidates_cross_checked_by_bijections':total_candidates,
             'support_records_including_empty':total_supports,
             'independently_verified_target_certificates':len(audits),
             'square_terms':sum(r['square_terms'] for r in audits),
             'positive_remainder_terms':sum(r['positive_remainder_terms'] for r in audits),
             'boundary_reduced_templates':sum(any(s['action'].startswith('refine') for s in row['steps']) for row in coverage),
             'exact_rational_full_reduction_test_cases':weighted_cases,
             'exact_rational_local_state_test_cases':local_cases,
             'zero_effective_activity_occurrences_in_intermediate_states':zeros,
             'certificate_arithmetic':'fractions.Fraction, arbitrary-precision exact rational',
             'authoritative_manifest_sha256':sha(ROOT/'role_total_degree3_complete_verification.json'),
             'audit_script_sha256':sha(Path(__file__)),
             'seconds':round(time.time()-START,3)}
    assert summary['square_terms']==793 and summary['positive_remainder_terms']==50660
    receipt={'summary':summary,'target_audits':audits,'coverage':coverage}
    (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':main()
