#!/usr/bin/env python3
"""Portable full modular replay of the independent-role degree-three proof."""
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib,json,subprocess,sys,zipfile,time
R=Path(__file__).resolve().parent;start=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# SHA256SUMS is created when the portable audit is sealed.
if (R/'SHA256SUMS').exists():
 for line in (R/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);assert sha(R/n)==h,n
if (R/'approval_receipt.json').exists():
 approval=json.loads((R/'approval_receipt.json').read_text());assert approval['verdict']=='approved';assert sha(R/'source_theorem.md')==approval['source_theorem_sha256'];assert sha(R/'complete-hybrid-audit-package.zip')==approval['hybrid_archive_sha256'];assert sha(R/'approved_replay.json')==approval['full_replay_receipt_sha256']
pins=json.loads((R/'global_finite_pins.json').read_text())
for n,h in pins['source_receipt_pins'].items():assert sha(R/'dependencies'/n)==h
for p in pins['exact_dependency_certificate_pins']:
 path=R/'global_inputs'/('nontotal6_certificates' if p['family']=='six_vertex_nontotal' else '')/p['file'];assert sha(path)==p['sha256']
def run(p,*args):subprocess.run([sys.executable,str(p),*map(str,args)],check=True)
def unpack(archive,destination):
 destination.mkdir()
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None;assert len(z.namelist())==len(set(z.namelist()));assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
  for line in z.read('SHA256SUMS').decode().splitlines():
   h,n=line.split('  ',1);assert hashlib.sha256(z.read(n)).hexdigest()==h,n
  z.extractall(destination)
 return destination
with TemporaryDirectory(prefix='role-degree-three-replay-') as td:
 T=Path(td);D=unpack(R/'complete-hybrid-audit-package.zip',T/'hybrid')
 run(D/'audit_hybrid.py','--phase','all');run(D/'check_dependencies.py');run(D/'check_negative_controls.py')
 role=json.loads((D/'hybrid_audit_receipt.json').read_text());assert role['complete'] and role['covered_targets']==role['target_count']==1686 and not role['remaining_target_ids'];assert len(role['proved_refinement_sources'])==40
 module_counts={}
 for kind,archive,script in [('mixed_a2','mixed-sign-a2-audit-package.zip','audit_a2_mixed.py'),('same_a2','same-sign-a2-audit-package.zip','audit_a2_same.py'),('marked_five_gluing','marked-five-audit-package.zip','audit_marked_five.py')]:
  M=unpack(D/'dependencies'/kind/archive,T/kind);run(M/script);v=json.loads((M/'independent_verification.json').read_text());module_counts[kind]=v['counts']
  if kind=='mixed_a2':assert v['passed']
  elif kind=='same_a2':assert v['all_mathematical_checks_passed'] and v['complete_certificate_set']
  else:assert v['verified'] and v['marked_classes']==96;run(M/'check_gluing.py')
 # This final-case archive recursively replays its twenty proper minors, the
 # exact nine-element database maps, the <=8 HPP applications, and all-real SOS.
 H=unpack(D/'dependencies/side1565_all_real_rayleigh/side1565-final-case-audit-package.zip',T/'final_side');run(H/'verify_all.py')
 # The role-rank-three corollary is an ordinary proof. Verify its pinned source.
 C=unpack(R/'dependencies/role-rank-three-audit-package.zip',T/'role_rank_three');a=json.loads((C/'approval_receipt.json').read_text());assert a['verdict']=='approved' and sha(C/'source_theorem.md')==a['source_theorem_sha256']
 F=T/'finite';F.mkdir()
 for name in ('audit_nontotal.py','audit_total.py'):(F/name).write_bytes((R/'global_replay'/name).read_bytes())
 run(F/'audit_nontotal.py','--n','6','--source',R/'global_inputs');n6=json.loads((F/'n6/receipt.json').read_text());assert n6['summary']['all_passed'] and n6['summary']['checked_certificates']==223
 run(F/'audit_total.py',R/'global_inputs');total=json.loads((F/'receipt.json').read_text());assert total['summary']['all_passed'] and total['summary']['covered_n6_templates']==32 and total['summary']['covered_n7_templates']==64
 out={'passed':True,'complete_independent_role_finite_domain':True,'vertex_only_proof_dependencies':0,'catalog_target_types':1686,'available_role_certificates':role['available_certificates_verified'],'refinement_sources':len(role['proved_refinement_sources']),'exact_structural_modules_replayed':module_counts,'side_HPP_and_published_positive_maps_replayed':True,'final_side_proper_minors_and_all_real_SOS_replayed':True,'six_vertex_nontotal_certificates':223,'total_preorder_certificates':24,'hybrid_archive_sha256':sha(R/'complete-hybrid-audit-package.zip'),'source_theorem_sha256':sha(R/'source_theorem.md'),'seconds':time.monotonic()-start,'scope':'Full independent nonnegative tail/head activities, every finite preorder, actual surviving support degree at most three. The arbitrary-size conclusion uses the separately reviewed ordinary GE assembly and cited literature theorems.'}
(R/'portable_replay.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
