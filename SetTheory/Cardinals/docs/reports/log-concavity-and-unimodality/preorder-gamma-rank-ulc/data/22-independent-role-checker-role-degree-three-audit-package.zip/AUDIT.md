# Full independent-role degree-three theorem: independent approval

Approved. For every finite preorder and arbitrary independent nonnegative tail and head activities, the ordered-support polynomial is ultra-log-concave when normalized at its actual surviving degree, provided that degree is at most three. There is no bound on the number of vertices. A support is counted once regardless of matching witnesses; distinct ordered tail/head pairs remain distinct even if their physical unions agree.

The theorem and ordinary assembly are frozen in source_theorem.md. The complete seven-vertex manifest is pinned at SHA256 29cb378f370bb987ae34d837c72e78ea8f07d9b74e9a1939f45f7eb85e62e00f. The source synthesis is pinned at ff787e05c9b8e0985a809b7974e44766f9cd7bda296b9257a408dfe1a42dc6d4.

## Global mathematical review

The crucial zero-role step is valid for preorders: retain an arc only when its tail and head activities are positive, then restore reflexive loops. Every surviving two-step path has a surviving transitive shortcut, so the filtered relation is still a preorder. Set zero activities to one only in their now-unused roles. Positive-weight old supports and supports of the filtered relation have the same coefficients. Its physical matching number equals the original actual degree, even if the unfiltered graph has greater matching rank. This establishes the advertised nonnegative, surviving-degree scope rather than a fixed unweighted-degree scope.

For degree at least two, weighted Motzkin--Straus on physically compatible directed arcs gives gamma1^2 >= [2d/(d-1)] gamma2. Matching multiplicity is harmless in the required direction. Thus degree two uses the factor four and degree three the factor three. Positive supports restrict to submatchings, so no internal coefficient zeros occur below the actual degree.

The graph-only Gallai--Edmonds core bound and canonical exterior properties were checked against the included structural audit. Its earlier positivity claims are not imported: only its graph reduction is used. The present weighted assembly discharges each branch with independently role-valid inputs. At a=0 components are finite. At a=1 the same-direction pendant activities sum in the used role; the other role is irrelevant. A maximal seven-vertex core forces two rank-one residual components, giving the approved articulation theorem. At a=2 all 1,084 oriented templates have complete heterogeneous-role proofs. Their finite dependencies are direct certificates, so selecting two-attachment witnesses elsewhere in the final ledger creates no cycle. At a=3 the canonical orientation argument supplies a cover of at most three roles, using the approved pure-three Rayleigh and mixed two-by-two role-cover results.

Disconnected rank-three cases use only products of rank-at-most-two real-rooted factors, or a single rank-three component with isolated vertices. No general convolution closure for arbitrary rank-ULC polynomials is assumed. Effective zero activities created by a compression or refinement are explicitly allowed. Every binomial normalization uses the actual degree.

## Exact finite closure

The independently regenerated seven-vertex domain has 1,686 classes from 131,645 quotient/block configurations, including 75,160 relevant configurations. All classes are proved. The selected ledger has 812 rational role records, 834 direct structural records, and 40 acyclic extremal-block refinements. All 1,553 available role certificate files are replayed, including the four declared positive-multiplier identities. Every terminal has full independent-role scope; there are no vertex-only proof dependencies and no unresolved sources.

The last finite cases use the proved one-tail stable-side criterion. Side bases, real versus matroid duality, true parallel classes, and published-positive list membership are checked explicitly. The final ten-element side has twenty HPP proper minors and a 397-monomial all-real Rayleigh difference represented by 32 positive rational squares. Its 37-by-37 Gram matrix is exactly positive semidefinite of rank 32. Wagner--Wei yields HPP and closes target 1565; the existing refinement closes 1611. The complete theory remains rank-ULC, not generally real-rooted.

## Complete portable replay

The standard-library driver regenerates the complete hybrid domain and expands all role certificates. It replays both a2 modules, all marked-five certificates and gluing checks, the HPP side maps, published-list isomorphisms, all final proper minors and the all-real SOS. It also replays the 223 nontotal six-vertex certificates and 24 total-preorder targets. The first complete modular run passed in approximately 94 seconds. All computation is exact; no floating-point tolerance or numerical discovery output is accepted as proof.

Published ordinary theorems and the Kummer--Sert certified-positive data are explicitly cited mathematical dependencies. Their historical global computations are not represented as locally rerun. Ordinary structural proofs and their prior approval sources are included and pinned. The proof is computer-assisted, not proof-assistant formalized. Neither a higher-degree theorem nor a literature-wide priority claim is asserted.

Run `python verify_all.py` from any working directory. This checks the archive/input pins, extracts copies into temporary storage, and reruns the exact modules. It writes a fresh portable_replay.json with elapsed time; original approval receipts are preserved. The outer article package additionally replays the companion role-cover algebra, including its C++ corroborative checks. This audit bundle itself needs only Python's standard library.
