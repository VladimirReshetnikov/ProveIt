# A 243-state Turing machine for Con(ZFC)

This contribution supplies an explicit **243-working-state, binary, single-tape
Turing machine**, including all blank-tape initialization, with the ordinary
mathematical proof

\[
\mathrm{ZFC}\vdash
\bigl(\neg\operatorname{Halt}(M_{243},0^{\mathbb Z})
\leftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr).
\]

Read `report.pdf` for the full proof, exact table, verification results,
alternative finite-algebra search design, and further research. The editable
manuscript is `report.tex` with `sections/*.tex`.

## Exact machine

| Item | Value |
|---|---|
| Canonical table | `machine/machine.tm` |
| Working states | 0 through 242 |
| Start / dispatcher / separate halt | 0 / 87 / 243 |
| Binary transition rows | 486 |
| Tape | Two-way infinite, all zero initially; initial head 0 |
| Moves | Exactly one cell left or right per transition |
| Inherited-label table | `machine/machine_old.tm` |
| Inherited start / dispatcher / halt | 95 / 96 / 254 |

Canonical table SHA-256:

```text
a3860fb49d6b96e58ead6293134f246d59b3958231cb56850273c4b8a8138791
```

Inherited-label table SHA-256:

```text
4207fc3d1bb16f3c64c3cff0980eaa1486160c3f467aee7685740a39e3df7300
```

Every noncomment row is `state read write direction next_state`. The first
line declares the start state. The halt target has no outgoing rows and is
excluded from the working-state count. All 243 working states are graph-reachable
from the start; this does not assert that the blank computation visits every one.

## Construction

Starting with the old-label Routing245 table, delete old states **26 and 122**
and make the seven replacements recorded in `machine/construction.json`.
The first three replacements rotate a transfer-plus-one source loop; the other
four implement the compensated state reuse. These two ingredients were present
in earlier independent 244-state contributions. The new contribution is their
exact 243-state composition and the proof that the local reuse remains valid
after the source rotation.

The compensation theorem is rechecked on rotated244 itself. Its invariant,
480 ordinary transition identities and seven whole-tape exceptional identities
give **all-tape halting equivalence from old state 95 between rotated244 and
composed243**. The separate source rotation and runtime/initialization proofs
give the needed blank-start equivalence with Routing245. Arbitrary-tape
equivalence between Routing245 and composed243 is not asserted.

## Fresh evidence

| Obligation | Verified result |
|---|---|
| Exact construction, totality, renumbering | 243 states, 486 rows |
| Independent local proof | 480 ordinary rows, 7 exceptional identities |
| Invariant/guard finite implications | 7,752 old, 7,736 new, 52 partition assignments |
| Source rotation | Universal register proof and all 8,385 outside successor edges |
| Frame closure | All 8,389 nonhalting source successors |
| Exact sparse/dense blank startup | 407,967 transitions; identical full frame |
| Universal affine runtime | All 8,390 guarded cases |
| Expanded whole-tape runtime | All 8,390 guarded cases, 2,314,868 symbolic rules |
| Positive progress | Minimum expanded lower bound 13 literal transitions |

The expanded proof quantifies every natural register value, all gap parameters
with frame padding 64, and every nonempty finite spare suffix. The individual
case records and the induction engine are included. The table keeps the unused
completion row `(27,1)`; state 27 still counts. Universal traces use the other
485 rows, and the exact blank prefix avoids `(27,1)`.

The complete packaged offline command was freshly executed successfully;
`certificate/portable-full-replay.json` records `PASS_243_FULL_REPLAY`, and
`certificate/portable-full-logs/` preserves each step's output. That run
checked the 62-file pre-document manifest; the final `SHA256SUMS` additionally
covers the finished manuscript, PDF, and final replay/visual-review records.

The initial frame has head -5, marker -6, header 176, gap 181, logical registers
`[3,0,0,0,3,0,0,0,0]`, 167 spare blocks each of value one, and exactly 351
one-cells. `machine/boot.json` records every one-cell and excludes all others.

## Reproduce offline

Python 3.10+ and its standard library suffice. Assertions must stay enabled;
do not use `-O`. Use a new or empty output directory.

```sh
python3 -B code/verify.py --expanded --output /tmp/zfc243-full-replay
```

The expanded mode takes several minutes. It verifies the manifests, extracts
the pinned original reference ZIP, rebuilds the machine and boot, rechecks the
local/source/frame proofs, replays affine and expanded runtime, and runs the
finite-algebra semantic controls. No network or proof-assistant cache is needed.

A faster integration command reruns all steps except the expanded replay:

```sh
python3 -B code/verify.py --output /tmp/zfc243-fast-replay
```

Fast mode checks the complete recorded expanded certificate's identities and
case inventory. It does not substitute for a fresh expanded execution.

The original loop244 ZIP is unchanged. Its unused legacy wrapper
`code/check_whole_frame_candidate.py` has an inherited indentation error;
it is not executed or imported. This contribution adapts the working
`code/check_runtime.py` route and preserves the original archive for provenance.

## Rebuild the document

```sh
python3 -B code/render_table.py --check
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

Omit `--check` to regenerate the full printed table from the canonical file.

## Logical alternatives and formal status

`research/finite-algebra/` contains a separate exact finite-ground-clause
checker and proof. It replaces explicit equality/function-congruence
certificates with evaluation in finite total algebras. It supplies no complete
ZFC clause generator or binary compiler and makes no additional state-saving
or global novelty claim. The report explains its data/control tradeoff.

These are **ordinary mathematical proofs and executable proof-premise checks**.
The current pinned repository has a closed external Lean endpoint for Routing245,
whose maintained status/source were inspected; its historical caches were not
rebuilt here. No new complete 243-state Lean/Rocq endpoint, serialized PA proof,
absolute consistency theorem, or minimality claim is asserted.

`PROVENANCE.json`, `ATTRIBUTION.md`, `CONTRIBUTION.md`, and `SHA256SUMS` identify
the inputs, contribution, preserved credit, and exact artifact contents.
