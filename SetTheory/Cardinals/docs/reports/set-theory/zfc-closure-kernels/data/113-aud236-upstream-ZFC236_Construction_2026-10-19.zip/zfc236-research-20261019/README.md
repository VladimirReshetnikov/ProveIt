# A 236-state binary Turing machine calibrated to Con(ZFC)

**Result:** this package constructs a deterministic, binary, one-tape machine
with **236 working states**, excluding its halt state. The ordinary proofs
and exact certificates compose with the pinned ProveIt calibration to give

\[
\mathrm{ZFC}\vdash
\bigl(\neg\operatorname{Halts}(M_{236},\mathrm{blank})
\leftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr).
\]

The new construction uses a closed source reassociation to expose one useful
decoder edge, then merges inherited state 223 into 182 using the bit immediately
left of the head. This saves one state beyond the exact 237-state input in
commit `ec480205a17f9e2b5f575b4c5d9c2279ace903f7`.

Read **report.pdf** for the complete explanation and proofs. **report.tex**,
`sections/`, and the included formalism sections rebuild that PDF.

## Exact machine

| Item | Value |
|---|---|
| Canonical table | `machines/zfc236.tm` |
| Working states | 0–235 |
| Initial state / head / tape | 0 / 0 / identically zero |
| Dispatcher | 84 |
| Separate halt outcome | 236 |
| Alphabet / tape / moves | binary / two-sided one tape / L and R |
| Complete transition rows | 472 |
| Exact blank startup | 409,835 steps |

Canonical table SHA-256:

```text
d4302309401891d68b93c393e4ad6e24d2abf993dede4a61baa2d3e0c1c53c8e
```

Inherited-label table `machines/zfc236_old.tm` SHA-256:

```text
ff059535876bc9e1e1e63174ebfd1c10a91c1a818ba0c3f8c4ef2ac51a3cfcc3
```

Hashes cover complete bytes, including the header and final newline. The
relabeled tables are related by `machines/renumbering236.json`.

## What changed

The original 237 table first receives the following four source-rotation edits:

| Row | Before | After |
|---|---|---|
|177/0|0 R165|0 R185|
|177/1|1 R185|1 R212|
|185/0|0 R192|0 R165|
|185/1|1 R212|1 R192|

This replaces `(A,(B,C))` by `((A,B),C)` for three closed chunks of 245, 160,
and 132 leaves. It changes 537 paths, preserves 224 source DAG nodes, and
raises maximum depth from 48 to 49. Every ordered instruction and conditional
successor is preserved.

Next delete state 223, redirect its incoming row 237/0 to 182, and change
`182/0` to `0 L198` and `182/1` to `1 L210`. The old state 182 always has a 1
to its left; old 223 always has a 0. Four existing three-step paths reproduce
their old transitions, preserve the entire tape, and finish one cell to the
right. All other 470 old rows commute in one step. The missing path became
available precisely because of the new 177/1 row.

## Verification delivered

- Complete source equivalence on all 6,455 leaves and 8,386 guarded cases.
- Exact startup: 409,836 matching checkpoints, 351 one-cells, and independent
  dense canonical replay. The tape is explicitly compared with the inherited
  calibrated seed frame.
- Two independent local-fold proofs: a small four-case checker and a generic
  symbolic open-tape checker. No empirical window assumption enters either.
- Fresh full runtime proof of the reassociated 237 basis: 8,386 cases,
  2,262,455 symbolic rules, all 474 literal rows, minimum duration 13.
- Fresh direct full runtime proof of the final 236 machine: 8,386 cases,
  2,267,815 symbolic rules, all 472 literal rows, minimum duration 13.
- Exact construction, source, machine, proof-program and case-array pins.

**Proof boundary:** these are ordinary mathematical proofs formalizable in
ZFC, with executable finite certificates and the inherited unary/list
induction checker. The existing logical calibration and 240-state external
Lean endpoint are inherited. This package does not claim a newly compiled
Lean/Rocq theorem for 236 or a completed internal PA proof-code endpoint.
The biconditional itself needs no consistency assumption; assuming consistency
then implies actual nonhalting.

## Reproduce

Use Python 3.10 or newer, with assertions enabled, from this directory:

```sh
python3 -B reproduce.py --output-dir replay
python3 -B reproduce.py --full --output-dir replay-full
```

Choose a new or empty output directory. The default replay rebuilds the
machines and source, reruns exact startup and finite proofs, audits the
delivered complete runtime evidence, verifies the formalism artifacts and
replays the pinned inherited 237 quick suite. `--full` additionally reruns
both new unbounded runtime jobs. Those two jobs run concurrently, each
writing distinct output files. All work occurs in a manifest-checked
temporary copy; the delivered evidence is not overwritten.

The default mathematical replay needs no network, C++ compiler, Lean or Rocq.
The optional finite discovery replay uses C++17; see `discovery/positive236/`.
The formalism and generic-checker regressions use only the Python standard
library. To rebuild the report:

```sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

## Additional formalism result

`formalisms/` contains **E688**, a complete 688-bit equational presentation
obtained by deleting a derived truth equation from the incoming 713-bit
packet. It has exactly the same models and equational consequences, using
the unchanged signature and codec. The complete proof, independent encoder,
ground query, exact bit string and validation receipts are included.

This description-length result does not imply another TM state reduction.
The 236-state machine uses the existing calibrated frontend. A separate
infinite countermodel shows why deleting the native stack-tail equation
would lose the intended consistency calibration.

## Provenance and incorporation

The unchanged pinned 237 package is under `upstream/zfc237/`. The four incoming
238-state outputs were byte-identical; their exact tables and archive ledger
are retained under `upstream/`. New materials are compatible with the ProveIt
license; all inherited notices remain in `licenses/` and the pinned dependency.

The original compact set theory/source and 254-state construction retain
Mira-Cult's credit, the upstream Rocq verification Jeff Ketchersid's credit,
and the compiler framework Andrew James Wade's credit. The preceding ProveIt
reductions retain their original attribution. This work contributes the
specific 236-state composition, its new proof artifacts, E688 and the stated
research notes. 

`SHA256SUMS` records all delivered files except itself. The final mathematical
claim does not rely on finite discovery profiles or negative search results.
The optional 235-state search found no further candidate in its recorded
families; it establishes no lower bound.
