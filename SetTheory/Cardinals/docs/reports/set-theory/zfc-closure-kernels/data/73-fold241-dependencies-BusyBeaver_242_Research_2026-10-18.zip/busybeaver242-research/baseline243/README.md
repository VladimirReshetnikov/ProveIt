# Independent combined243 review

The exact candidate at ProveIt commit `e58338db7545909907e07a7603e8eb88625c527a` passes this independent ordinary-mathematical review. No supplied Python, Lean or other program was executed or imported. All supplied artifacts were parsed as data. Fresh checks used our own simulators and proof checkers, including a previously written symbolic induction engine.

## Exact results

- Canonical SHA-256: `a3860fb49d6b96e58ead6293134f246d59b3958231cb56850273c4b8a8138791`
- Inherited-label SHA-256: `4207fc3d1bb16f3c64c3cff0980eaa1486160c3f467aee7685740a39e3df7300`
- Logical source SHA-256: `3ee984818f0bdfd2c4daae72aeb14340572e34d73f5cdb5616b6d29d78fcd7f4`
- 243 working states, 486 binary transition rows, seven retained row edits, 479 unchanged retained rows, removed labels26 and122
- Renumbering preserves every row, start95→0, dispatcher96→87 and halt254→243
- Separate sparse inherited-label and dense canonical blank simulations agree after exactly407,967 transitions, on the complete tape: head−5, marker−6, header176, logical registers(3,0,0,0,3,0,0,0,0),167 spare ones,351 one-cells, zero everywhere else
- Compensation transfer freshly derived on the actual QT244 table:7,752 Boolean invariant implications,480 ordinary rows and seven disjoint/exhaustive whole-tape macro identities; all488 old and486 new rows accounted for
- QT source rotation: both symbolic iteration guards checked with arbitrary registers; natural induction gives N+=X+1, X=0 and exactly3X+2 instructions; all8,385 surrounding edges checked with no outside interior entry, sole external entry oldsite2 zero→6, halt6324→6323
- Original constructor-source to routed-source equivalence freshly replayed:3,013 guarded pairs,6,024 edges, one halt pair
- All8,389 nonhalting source successors close the full-frame domain with arbitrary natural registers, header distance64+n and a nonempty arbitrary finite spare list
- Universal runtime: all8,390 guarded cases,2,314,868 symbolic rules, minimum positive duration13;485 of486 rows used, only27/1 unused
-133 additional concrete arbitrary-register/gap/spare instances agree with symbolic duration/motion and independent dense/sparse entire tapes

## Proof scope

The compensation proof couples identical full binary configurations at positive bounded-duration endpoints. It covers arbitrary integer heads and binary tapes, including infinite support, from shared start95. It uses no source reachability or register bound. It transfers to QT244 because every local invariant, predecessor inventory and finite macro is freshly checked against the rotated table; disjoint table edits alone would not suffice.

The source rotation proof is separate. Its finite surrounding control-flow check and natural induction establish two-way source halting equivalence for every natural register vector. The exact blank seed, unbounded instruction contracts and successor-frame closure connect that program to the literal combined table. Consistency interpretation still inherits the original calibrated source theorem; this review does not independently reconstruct the complete foundational calibration.

This is executable ordinary mathematical evidence, not a fresh proof-assistant kernel check. The repository reports a checked relative Lean combined243↔QT244 machine theorem. Its complete exact243 Lean consistency endpoint remains open. The closed compensated244 endpoint is a different exact artifact. No unconditional nonhalting, absolute consistency, minimality, or two-sided independence from mere consistency is asserted.

## Evidence and replay

`REVIEW_RESULT.json` summarizes the result. `FETCH_MANIFEST.json` binds all downloaded files to exact Git blob hashes and SHA-256 values. `ARTIFACT_MANIFEST.json` binds this review's executable checkers and results.

The independent-runtime directory contains:

- `check_table_and_boot.py` and `table_and_boot.json`
- `check_local_compensation.py` and `local_compensation.json`
- `check_source_rotation.py` and `source_rotation_and_composition.json`
- `symbolic_runtime.py`, `independent_runtime.py`, `run_symbolic_checked.py`, and `combined243_universal{,_cases}.json`
- `crosscheck_instantiation.py` and `runtime_crosschecks.json`

Every generic symbolic proof function and class is AST-identical to the prior244 engine. Only the input validator changes to require the exact6459-leaf QT source pin; source equivalence is discharged separately. The fresh run took176.08seconds in this environment. The4000 symbolic-rule construction bound is not a bound on register values, spare length, gap, or actual runtime.

The table/startup and source checkers refer to the adjacent prior244/245 audit inputs. Reproduction requires those pinned data files. Run scripts with Python3 and assertions enabled, using `-B` to avoid bytecode. To rerun the unbounded proof, invoke `run_symbolic_checked.py` with `--table ../sources/candidate-combined243__zfc_combined243_old.tm --sites ../sources/candidate-combined243__sites_logical.json --output combined243_replay.json` from independent-runtime.

The separate exploratory `naive242_failure.json` records a rejected follow-on candidate and is not part of the243 pass. Its new source transform has not been certified by this review. The242 literal rewrite breaks an unchanged backward-routing caller at source path100111.
