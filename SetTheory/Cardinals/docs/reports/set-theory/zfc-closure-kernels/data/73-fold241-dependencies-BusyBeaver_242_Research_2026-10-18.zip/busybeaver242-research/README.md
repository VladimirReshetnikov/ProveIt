# Three 242-state reductions of combined243

This research package contains three exact 242-working-state binary single-tape machines, including initialization, with one separate halt state. All three have independently checked ordinary halting equivalence to the pinned combined243 machine, from inherited state 95 with any integer head position and any binary tape, including infinite support. The recommended primary machine is fold 15/27, `runtime/survivor_1.tm`.

Each table has 484 transitions and canonical working states 0 through 241. Start is 0; halt is 242. Every step writes one binary symbol and moves left or right. Candidate A deletes old27, B deletes old50, and C deletes old171. These are alternatives, not simultaneously applicable patches.

## Checked results

- A: 407,979 blank initialization transitions; 8,390 unbounded source cases; 2,314,880 symbolic rules
- B: 408,291 blank initialization transitions; 8,390 unbounded source cases; 2,318,402 symbolic rules
- C: 407,985 blank initialization transitions; 8,390 unbounded source cases; 2,314,880 symbolic rules
- All 484 rows covered per candidate; minimum derived instruction duration 13
- Every complete initialized tape agrees with combined243: 351 one-cells and zero elsewhere, inherited dispatcher96, head -5, marker -6, header176, logical values (3,0,0,0,3,0,0,0,0), and 167 spare blocks of value1
- Two separately written three-fold local proof checkers pass 7,640 inductive invariant implications and 512/768/256 exceptional whole-tape assignments
- A simpler independent principal-fold proof passes 7,696 invariant implications and 7,696 mapped positive-block checks; exact time is t_new = t_old + 2 * old visits to15/0
- 133 additional concrete dense/sparse arbitrary-frame checks per candidate

The local theorem is an all-tape mathematical induction, not an inference from testing. The runtime proof is a separate direct certificate for arbitrary natural registers, gap, and nonempty finite spare list. Finite simulations and random instances are implementation crosschecks.

## Read first

- `report.pdf` and editable `report.tex`: statement, complete local proof, runtime induction, source composition, limitations, and attribution
- `RELEASE_SUMMARY.json`: exact machine identities and terminal independent result summaries
- `runtime/README.md`, `runtime/REVIEW_RESULT.json`: sealed independent review
- `local-proof/LOCAL_PROOFS.md`: all three constructions and their global positive-block arguments
- `baseline243/README.md`: prior independently audited ordinary source and runtime chain

The exact baseline is combined243 at ProveIt commit e58338db7545909907e07a7603e8eb88625c527a. Inherited table SHA-256 is 4207fc3d1bb16f3c64c3cff0980eaa1486160c3f467aee7685740a39e3df7300. The unchanged QT source pin is 3ee984818f0bdfd2c4daae72aeb14340572e34d73f5cdb5616b6d29d78fcd7f4.

## Portable replay

Extract the ZIP into a fresh directory. Run with Python 3.10 or later:

    python3 -B verify_all.py --output replay_result.json

No third-party Python package, network request, installation, or repository checkout is required. Assertions must be enabled: -O and PYTHONOPTIMIZE are rejected. The runner checks the package manifest, executes the team's own checkers in a temporary working copy, and preserves recorded receipts. It replays:

1. Principal all-tape mapped simulation and two separately implemented three-fold local proofs
2. Three sparse/dense whole-blank simulations and the baseline exact table/boot check
3. Baseline all-tape compensated-fold proof and QT source rotation, original-to-routed source bisimulation, and full-frame successor closure
4. The 133 dense/sparse symbolic instantiations per candidate
5. Four complete 8,390-case unbounded runtime runs, including baseline243; every derived case must exactly equal the recorded case data

The four runtime jobs run concurrently and usually take a few minutes, depending on hardware. A successful terminal result is `FULL_FRESH_REPLAY_PASS`. `--quick` skips those four full runs and returns only `QUICK_REPLAY_PASS`; it must not be reported as a fresh universal replay. Each generic symbolic step is justified by the ordinary induction described in the report. The 4,000 symbolic-rule construction cap is not a bound on machine runtime, registers, gap, or spare length.

Fresh-extraction release validation is distributed separately from the ZIP so it can bind the final ZIP SHA-256 without a circular self-hash. The packet itself retains all primary independent PASS receipts.

## File conventions

Primary canonical table files are headerless `runtime/survivor_{1,2,3}.tm`; inherited files end `_old.tm`. Each row is `state read write direction next_state`, with direction L or R. The paired `_renumbering.json` files include the halt mapping. The dispatcher is 86 for A and B, 87 for C. Exact final file hashes are in `RELEASE_SUMMARY.json` and `MANIFEST.json`.

`local-proof/candidates/*/machine.tm` preserves the construction worker's alternative serialization with a `#! start 0` comment. It has a different byte hash but exactly the same transition relation and state map. The replay verifies equality. The primary independent boot receipts bind the headerless release tables, not the comment-bearing versions.

`runtime/ARTIFACT_MANIFEST.json` and `baseline243/ARTIFACT_MANIFEST.json` preserve the original review manifests as historical evidence. The outer `MANIFEST.json` is the authoritative release inventory. Portable adaptations of the baseline table and source checkers change only absolute input paths; the principal root proof also gains fail-closed assertions and an explicit finite-footprint check. `COPY_PROVENANCE.json` records these origins. Historical provenance paths are identifiers of the original work, not dependencies of portable replay. The shared helper's historical standalone main is not a replay entry point; use `verify_all.py` or the documented guarded runtime entry point.

## Proof and publication boundary

The all-tape equivalences do not assume consistency. Consistency interpretation is inherited from the previously calibrated original program and the audited combined243 source chain. This package does not rebuild the complete foundational source-theory argument.

No new Lean or Rocq endpoint is claimed. The complete exact243 Lean consistency endpoint remains open, and the existing relative combined243-to-QT244 Lean theorem does not close the calibrated source bridge. No unconditional nonhalting, absolute consistency, global minimum, internal PA theorem, or two-sided independence from mere consistency is claimed. No repository writes or publication have been performed by this package.

## Attribution

Credit remains with Mira-Cult for the original calculus/program, Jeff Ketchersid for upstream verification, Andrew James Wade for the compiler, and ProveIt for preceding source/routing/initialization and repository work. The compensated244 and QT source-rotation contributions retain their attribution. This investigation adds the three local folds, explicit ordinary proofs, independent checkers, and packaging. No additional personal author is inferred. Existing licenses and imported-source exclusions remain applicable; this package does not relicense inherited material. See `ATTRIBUTION.md` and pinned upstream references in the report.

To rebuild the PDF with a configured TeX Live installation, run `pdflatex -no-shell-escape report.tex` twice. The PDF is supplemental; the Python verification does not depend on TeX or the PDF.
