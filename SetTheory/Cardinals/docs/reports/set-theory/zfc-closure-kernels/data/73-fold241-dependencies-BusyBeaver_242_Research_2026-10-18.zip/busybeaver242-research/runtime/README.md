# Three independently verified 242-state folds

All three literal candidates pass a fresh unbounded runtime proof, independent sparse/dense whole-blank simulations, a second independent all-tape local equivalence proof, and concrete implementation cross-checks. They use the exact unchanged 6,459-leaf QT source from combined243. No downloaded program was executed or imported.

## Primary candidate: fold15/27

Delete inherited state27, redirect incoming18/0,47/0 and65/0 to15, and replace15/0 by `0 L 32`. The new row15/1 stays unchanged.

- Working states:242; total binary rows:484; separate halt:242
- Canonical start:0; canonical dispatcher:86
- Canonical SHA-256:`4156e3aecbcd38db9f1a74b5b91debfbff287c1d9ebf82fb860f18d3c76bdb38`
- Inherited SHA-256:`c8ef2f44d25fee6813164cc59ec05061799397da8cf7f0ea7baab63d32d76e02`
- Exact blank prefix:407,979 transitions
- Universal instruction cases:8,390; symbolic rules:2,314,880

The key detour at old15/0 is three new steps through32 and45, replacing one old step to21. The inductive invariant guarantees a zero immediately left of old15, so the detour restores the same tape and head. The other three blocks simply replace the intermediate27 by15. Their old/new lengths are2/2. The root time increases by12 transitions.

## Two verified alternatives

Fold27/50 deletes50, redirects its four incoming rows to27, and makes27/1 equal `0 L 20`. Canonical SHA-256:`0fb0df6d01faa77e9bfcce4b703286abe14bccd0b3e07b45931fc67ccb66f8c0`; inherited SHA-256:`e486fd402966944d296fb0abe0ea896f923e28c40c2a9a0226a4ccb408509bd6`. Its blank prefix is408,291 and its runtime proof uses2,318,402 symbolic rules. Canonical dispatcher86.

Fold27/171 deletes171, redirects150/0 to27, and makes27/1 equal `1 R 202`. Canonical SHA-256:`eb3023a5585a35c045a1e3e2b03726db2e04d7de08d4bda547baa71de7c28ec3`; inherited SHA-256:`211c0eeb9bbf292af817dc4839de6e784e755dc9192f8a2520637f9564f16321`. Its blank prefix is407,985 and its runtime proof uses2,314,880 symbolic rules. Canonical dispatcher87.

Every variant has242 working states,484 total binary rows and separate canonical halt242. All484 rows are used in each universal runtime proof. The two alternatives reuse the formerly unreachable27/1 row; they do not assert that this row remains unreachable in the new machine.

## Independent proof scope

The base is the exact inherited-label combined243 table with SHA-256 `4207fc3d1bb16f3c64c3cff0980eaa1486160c3f467aee7685740a39e3df7300`.

The old-side invariant is: a zero immediately left at15,18,47,65 and171; a one immediately left at91 and94; a zero under the head at27; and either a left one or current one at50. It is vacuous at95. All7,640 finite Boolean transition implications pass, proving induction on every old execution, including arbitrary infinite-support tapes.

The second local checker discovers matching positive joins directly from the exact tables rather than loading the search worker's block traces. It checks512,768 and256 admissible nine-bit assignments respectively. Every read/write is confined to that enumerated footprint, so every exterior cell is unchanged. Ordinary rows number480,479 and482. The unique removed state is excluded from paired checkpoints; no ordinary row targets it, and every exceptional entry has a matching positive block. No block crosses halt. This gives two-way halting equivalence from inherited95 on every binary tape and integer head position.

Separately, each unbounded symbolic runtime proof covers all8,390 guarded source cases and arbitrary independent natural primary registers, arbitrary additional natural gap, arbitrary first spare value and arbitrary finite spare tail. Unary and list traversals are proved by induction. All four exact-table one-block lemmas are freshly derived. Durations have lower bound13. The4,000-rule proof-construction bound does not bound actual execution time, register values or tape lengths.

All three sparse inherited-label and dense canonical blank simulations reach the same complete calibrated frame: inherited dispatcher96, head−5, marker−6, header176, logical registers(3,0,0,0,3,0,0,0,0),167 value-one spares,351 one-cells, and zero everywhere else. Each candidate additionally passes133 concrete arbitrary-register/gap/spare comparisons of symbolic duration/motion and dense/sparse entire tapes.

The exact unchanged logical source SHA-256 is `3ee984818f0bdfd2c4daae72aeb14340572e34d73f5cdb5616b6d29d78fcd7f4`. Its source rotation, inherited source bisimulation and successor-frame closure are independently checked in the adjacent combined243 review. The local all-tape transfer provides an independent composition route. Both routes inherit the original source consistency calibration.

## Limitations

These are ordinary mathematical proofs checked by independently written programs. No new Lean/Rocq kernel endpoint is claimed. The repository's relative combined243↔QT244 Lean theorem does not close the full243 consistency endpoint, and no242 endpoint is silently inherited from the closed compensated244 artifact. No unconditional nonhalting, absolute consistency, minimality or two-sided independence from mere consistency is claimed.

Canonical files here omit comments. The search worker's equivalent canonical files include a start comment, so their byte hashes differ despite identical transition rows. Claims in this review bind the exact files here.

## Replay

The runtime files here are byte-identical to the independently audited243 engine. Run with Python3, assertions enabled and `-B`:

1. `python3 -B check_boots.py`
2. `python3 -B check_local_blocks_independent.py`
3. `python3 -B crosscheck_instantiation.py 1` and similarly2 and3
4. `python3 -B run_symbolic_checked.py --table survivor_1_old.tm --sites sites_logical.json --output fresh_survivor_1.json`, and similarly2 and3

The historical full runtime reports preserve their original command paths. The copied engine, candidate and source files are hash-bound to those reports. The three full runs took approximately205–208 seconds each in the recorded environment.

`REVIEW_RESULT.json` gives the exact summary; `ARTIFACT_MANIFEST.json` records the checksums of all files. The source bridge remains available in the adjacent independent combined243 review. Its source certificate SHA-256 is `a37d06f70c7285c07e872d04f4a7740e8093e101c66671d5b4b90d65dfdb08e2`.
