#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
command -v pdflatex >/dev/null 2>&1 || { echo "Install pdfLaTeX to rebuild the PDF." >&2; exit 1; }
export SOURCE_DATE_EPOCH=1792454400
export FORCE_SOURCE_DATE=1
build_dir=$(mktemp -d)
export TEXMFVAR="$build_dir/texmf-var"
export TEXMFCONFIG="$build_dir/texmf-config"
trap 'rm -rf "$build_dir"' EXIT HUP INT TERM
# Support minimal TeX installations without generated file-name databases.
if [ -d /usr/share/texmf ]; then
  export TEXINPUTS=".:/usr/share/texmf/tex//:/usr/share/texlive/texmf-dist/tex//:${TEXINPUTS:-}"
  export TEXFONTMAPS="/usr/share/texmf/fonts/map//:/usr/share/texlive/texmf-dist/fonts/map//:${TEXFONTMAPS:-}"
  export TFMFONTS="/usr/share/texmf/fonts/tfm//:/usr/share/texlive/texmf-dist/fonts/tfm//:${TFMFONTS:-}"
  export T1FONTS="/usr/share/texmf/fonts/type1//:/usr/share/texlive/texmf-dist/fonts/type1//:${T1FONTS:-}"
  export ENCFONTS="/usr/share/texmf/fonts/enc//:/usr/share/texlive/texmf-dist/fonts/enc//:${ENCFONTS:-}"
fi
if ! kpsewhich pdftex.map >/dev/null 2>&1 && [ -f /usr/share/texmf/fonts/map/dvips/lm/lm.map ]; then
  cat /usr/share/texmf/fonts/map/dvips/lm/lm.map \
      /usr/share/texlive/texmf-dist/fonts/map/dvips/amsfonts/cm.map \
      /usr/share/texlive/texmf-dist/fonts/map/dvips/amsfonts/symbols.map > "$build_dir/pdftex.map"
  export TEXFONTMAPS="$build_dir:${TEXFONTMAPS:-}"
fi
if ! kpsewhich pdflatex.fmt >/dev/null 2>&1; then
  (cd "$build_dir" && pdftex -ini -etex -jobname=pdflatex -progname=pdflatex \
      -halt-on-error -interaction=nonstopmode '\input pdflatex.ini' >format-build.log)
  export TEXFORMATS="$build_dir:${TEXFORMATS:-}"
fi
for pass in 1 2; do
  if ! pdflatex -halt-on-error -interaction=nonstopmode -output-directory="$build_dir" supplement.tex > "$build_dir/run.log"; then
    cat "$build_dir/run.log" >&2
    exit 1
  fi
done
cp "$build_dir/supplement.pdf" supplement.pdf
printf '%s\n' 'Built supplement.pdf'
