#!/usr/bin/env python3
"""Literal Lean snapshot / current Coq AST comparison; no theorem prover needed."""
from pathlib import Path
import hashlib,itertools,json,re,sys
HERE=Path(__file__).resolve().parent;ROOT=HERE
import audit_models as a
D={};prim=a.PRIMITIVES

def need(b,s):
 if not b:raise ValueError(s)
def read(p,names):
 text=re.sub(r'/\-.*?\-/', '', p.read_text(), flags=re.S)
 text=re.sub(r'--[^\n]*','',text)
 for name in names:
  m=re.search(rf'^def {name}\b(.*?)\s*:\s*Nat\s*:=\s*(.*?)(?=^\s*(?:def|theorem|inductive|namespace|end)\b)',text,re.S|re.M)
  need(m is not None,'Missing '+name);sig,body=m.groups()
  params=tuple(x for g in re.findall(r'\((.*?)\s*:\s*Nat\s*\)',sig,re.S)for x in g.split())
  tokens=re.findall(r'[A-Za-z_][A-Za-z_0-9]*|[0-9]+|[()]',body)
  need(''.join(tokens)==re.sub(r'\s+','',body),'Unsupported syntax '+name)
  cursor=0
  def term():
   nonlocal cursor
   t=tokens[cursor];cursor+=1
   if t=='(':
    x=term();need(tokens[cursor]==')','Unbalanced '+name);cursor+=1;return x
   if t.isdigit():return int(t)
   if t in params:return t
   arity=prim.get(t,len(D[t][0])if t in D else None)
   need(arity is not None,'Unknown name '+t)
   return(t,*(term()for _ in range(arity)))
  body=term();need(cursor==len(tokens),'Trailing '+name);D[name]=(params,body)
def expand(n,env=None):
 env=env or{}
 if isinstance(n,int):return n
 if isinstance(n,str):return env.get(n,n)
 head,*args=n;args=[expand(x,env)for x in args]
 if head in prim:return(head,*args)
 ps,body=D[head];return expand(body,dict(zip(ps,args)))
code=HERE/'inputs/lean/Code254.lean';kcode=HERE/'inputs/lean/KCode222.lean'
for p in [code,kcode]:
 need(p.read_bytes()==(HERE/'inputs/singleton'/p.name).read_bytes(),'Singleton snapshot byte mismatch')
read(code,['F','wn','wa','wex',*(f'rho{i}'for i in range(1,9))])
read(kcode,['growG','req','clos','nks','vrel','bundle222'])
matches={}
for left,right in [(n,n)for n in ['F','wn','wa','wex',*(f'rho{i}'for i in range(1,9)),'growG','vrel','bundle222']]+[('nks','nks222')]:
 need(D[left][0]==a.DEFS[right][0],'Parameter order '+left)
 need(expand(D[left][1])==a.expanded(right),'Expanded AST '+left)
 matches[left]=dict(coq_name=right,exact_expanded_ast=True)
# Bind the exact C222 constructor list and retained gate. This is not a parser
# for Lean proof terms, only a checked literal API record for the proposal.
s=kcode.read_text();body=s.split('inductive C222 : Nat → Prop\n',1)[1].split('\ntheorem ',1)[0]
expected=['truth','mp','gen','r1','r2','r3','r4','r5','r6','rG','r8','bundle']
need(re.findall(r'^  \| (\w+)',body,re.M)==expected,'Unexpected calculus constructors')
need('| r8 (a b c u : Nat) : C222 (rho8 a b c u)'in body,'Changed rho8 API')
need('| bundle (a b c : Nat) : c ≠ a → c ≠ b → C222 (bundle222 a b c)'in body,'Changed bundle gate')
# Bind all rule signatures, not only their constructor names.
expected_body = """  | truth : C222 0
  | mp {t b : Nat} : C222 t → C222 (wim t b) → C222 b
  | gen (a : Nat) {h : Nat} : C222 h → C222 (wal a h)
  | r1 (a b : Nat) : C222 (rho1 a b)
  | r2 (a b c : Nat) : C222 (rho2 a b c)
  | r3 (a b c : Nat) : C222 (rho3 a b c)
  | r4 (a b c : Nat) : C222 (rho4 a b c)
  | r5 (a b c : Nat) : C222 (rho5 a b c)
  | r6 (a b : Nat) : C222 (rho6 a b)
  | rG (a b c : Nat) : C222 (growG a b c)
  | r8 (a b c u : Nat) : C222 (rho8 a b c u)
  | bundle (a b c : Nat) : c ≠ a → c ≠ b → C222 (bundle222 a b c)"""
need(re.sub(r"\s+", "", body)==re.sub(r"\s+", "", expected_body), 'Changed C222 rule signature')
# Explicitly bind the arithmetic constructor conventions used by CODE_OPS.
lean_code=code.read_text()
coq_code=a.KCODE.read_text()
for name,ps,body_text in [('wim','a b','4 * P a b'),('wel','i j','4 * P i j + 1'),('wal','i a','4 * P i a + 2'),('weq','i j','4 * P i j + 3')]:
 need(f'def {name} ({ps} : Nat) : Nat := {body_text}' in lean_code, 'Lean constructor '+name)
 need(f'Definition {name} ({ps} : nat) : nat := {body_text}.' in coq_code, 'Coq constructor '+name)
need('Definition P (a b : nat) : nat := tri (a + b) + b.' in coq_code, 'Pairing convention')
# Evaluate directly parsed upstream expressions as an additional independent
# AST input to the existing finite-matrix evaluator.
m=json.loads((HERE/'model.json').read_text());V=range(m['n']);des=set(m['D']);I=lambda x,y:m['table'][x][y];q=lambda x:m['Q'][x]
f,t,e=(m[x]for x in ['F','T','eq']);ops=dict(wim=I,wel=lambda x,y:f,wal=lambda x,y:q(y),weq=lambda x,y:e)
checks={}
for name in [*(f'rho{i}'for i in range(1,7)),'growG','bundle222','rho8']:
 ps,term=D[name];term=expand(term);n=0;vals=set()
 for vs in itertools.product(V,repeat=len(ps)-(name=='rho8')):
  env=dict(zip(ps,vs));env.update({'u':f}if name=='rho8'else{})
  z=a.evaluate(term,env,ops,lambda x:t if x==0 else f if x==1 else None)
  need(z in des,'Upstream model failure '+name);n+=1;vals.add(z)
 checks[name]=dict(cases=n,values=sorted(vals),pass_=True)
# Failure of truth-status quotients is concrete, not a general claim that
# every smaller/single-designated model is impossible.
need(3 in des and 4 in des and I(3,2)==1 and I(4,2)==0,'Designated-pair witness')
need(0 not in des and 1 not in des and I(0,0)in des and I(1,0)not in des,'Boolean quotient witness')
neg=[I(x,f)for x in V]
result=dict(all_C222_rule_signatures_match=True,primitive_constructor_definitions_match=True,singleton_snapshot_byte_equality=True,status='LITERAL_UPSTREAM_MATCH_AND_FINITE_MODEL_PASS',snapshot_commit='adfaaaecfc9b0433c41f5faa2b71a82f268dea2a',singleton_snapshot_commit='4ac81a189bbb62cd037900797a4615de94e30857',files={p.name:dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)for p in [code,kcode]},exact_expanded_definitions=matches,C222_constructors=expected,direct_Lean_AST_checks=checks,designated_values=sorted(des),negation_values=neg,failed_two_status_quotient=dict(equal_input_status=[0,1],same_consequent=0,outputs=[I(0,0),I(1,0)]),scope='The proposed replacement affects only r8. K and EFQ are derived in unmodified upstream C222 using unrestricted rho8, not primitive constructors inherited by the restriction. No contradiction with no-three-valued-single-designated search or conditional FreshLabel theorems.')
(HERE/'reports/upstream_comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
