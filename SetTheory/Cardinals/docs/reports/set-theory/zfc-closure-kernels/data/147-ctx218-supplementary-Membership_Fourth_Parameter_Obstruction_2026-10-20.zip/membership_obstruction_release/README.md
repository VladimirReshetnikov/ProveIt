# Membership fourth parameter obstruction

This standalone research supplement proves nonderivability of the native falsum F=1
when **only** unrestricted rho8 is replaced by rho8(A,B,C,R(A,B)), retaining the
literal C222 rules and gated fused bundle. It does not construct a small Turing
machine or change the delivered 219-state alternatives archive.

Read `supplement.pdf` for the six-page mathematical proof and its precise scope.
The matrix validates Eq(0,0)=3 and every identity, but not added EFQ or K axioms.
Its all-natural valuation and finite-derivation induction formalize in PA. Assuming
ZFC is consistent, the plain proposal therefore cannot admit a PA- or ZFC-provable
implication from its consistency to Con(ZFC). This does not rule out strengthened
theories, arbitrary interpretations, or every conceivable quotient.

## Verify offline

Unzip and run from any directory (replace the path as appropriate):

    python3 -B /path/to/membership_obstruction_release/verify_release.py

Requirements: Python 3.9+ and its standard library. No network, SMT solver, Lean,
Rocq, or external Python package is needed. The script checks the manifest, runs both
finite checks, and confirms that the regenerated JSON reports exactly match the
bundled files. It writes only the two reports inside this extracted directory.

Individual checks:

    python3 -B check_proposal.py
    python3 -B check_upstream.py

Expected summary: `PORTABLE_RELEASE_PASS`; 925 axiom assignments validate in each
front end; 16 expanded Lean/Coq definitions match; the two input snapshot pairs are
byte-identical. MP (25 cases), generalization (5 cases), truth, the zero-code alias,
identity, and concrete EFQ/K failures are checked. The source-expression regression
has 672 cases; 2,049 decoder-walk comparisons also pass. Finite regressions do not
substitute for the all-natural mathematical proof.

## Rebuild the PDF

    sh build.sh

Requires pdfLaTeX, Latin Modern, geometry, amsmath, amssymb, amsthm, booktabs, array,
microtype, fancyhdr, and hyperref from a standard TeX Live distribution. The script
builds twice in a temporary directory and replaces `supplement.pdf`. PDF dates and
trailer identifiers are suppressed. Exact binary reproducibility additionally
requires the same TeX versions and fonts; a different engine may give a correct but
byte-different PDF. The manifest verifies the released PDF, not arbitrary rebuilds.

## Package contents and trust boundary

- `supplement.tex`, `supplement.pdf`: editable source and visually checked proof.
- `model.json`: unchanged exact five-valued matrix, with designated values {3,4}.
- `audit_models.py`: portable independent Coq-expression parser and finite evaluator.
- `check_proposal.py`: literal retained rows, the membership-dependent replacement,
  rule preservation, optional-row scope, and emitter-tree checks.
- `check_upstream.py`: separate Lean parser, expanded-tree comparison, exact C222
  signature/constructor binding, direct Lean-tree evaluation, snapshot equality.
- `inputs/coq/`: exact required numerical definitions and original rule relation.
- `inputs/lean/`: pinned maintained Code254/KCode222 and conditional FreshLabel work.
- `inputs/singleton/`: separately retrieved pinned singleton-search input snapshots.
- `inputs/source_emitter_receipt.json`: exact G/bundle source-emitter tree receipt.
- `reports/`: deterministic mathematical and source comparison results.
- `PROVENANCE.json`: exact origins, commits, source URLs, and adaptation scope.
- `MANIFEST.json`: sizes and SHA-256 hashes for every released file except itself.

The arithmetic construction conventions are explicitly checked against the source
text. This is not a general Lean/Coq parser or proof assistant. No imports of those
source files are compiled, and no FreshLabel theorem or three-value singleton search
is rerun. Two syntax front ends share the finite evaluator. The mathematical
induction is written out in the PDF rather than supplied as a new formal endpoint.
The source-emitter receipt's unrelated historical fields are preserved as input
provenance; none is needed as a filesystem location by these scripts.

The singleton search concerns three values and one designated value. This model
has five values and two designated values, with non-Boolean native negation. It is
therefore compatible with that negative search and with the conditional FreshLabel
statements. It is not an ordinary Tarski model of ZFC.
