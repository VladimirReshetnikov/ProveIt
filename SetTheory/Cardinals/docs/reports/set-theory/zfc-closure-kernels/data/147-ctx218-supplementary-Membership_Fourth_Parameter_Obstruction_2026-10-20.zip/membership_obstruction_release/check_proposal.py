#!/usr/bin/env python3
"""Check dependent-membership restriction against the literal current calculus.

Standard-library only. Reuses the independent Coq-expression parser, not the
old solver or discovery checker. Run from any directory; all inputs are bundled next to this script.
"""
from pathlib import Path
import functools,hashlib,itertools,json,math,sys
HERE=Path(__file__).resolve().parent;ROOT=HERE
import audit_models as a

def need(ok,msg):
 if not ok:raise ValueError(msg)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
 walk=(0,0)
 for z in range(2049):
  need(a.unpair(z)==walk,'isqrt decoder differs from Coq Nat.iter decoder')
  x,y=walk;walk=(x-1,y+1)if x else(y+1,0)
 path=HERE/'model.json';model=json.loads(path.read_text());receipt=a.audit(path)
 need(receipt['proves_no_derivation_of_F'],'Model does not validate current retained calculus')
 need(receipt['code3_designated'],'Equality code3 must actually be designated')
 V=range(model['n']);D=set(model['D']);C=lambda x,y:model['table'][x][y];q=lambda x:model['Q'][x]
 t,f,e=(model[x]for x in ['T','F','eq'])
 @functools.cache
 def val(n):
  if n==0:return t
  x,y=a.unpair(n//4)
  return(C(val(x),val(y))if n%4==0 else f if n%4==1 else q(val(y))if n%4==2 else e)
 ops=dict(wim=C,wel=lambda x,y:f,wal=lambda x,y:q(y),weq=lambda x,y:e)
 def replace_u(n):
  if n=='u':return('wel','a','b')
  return tuple(replace_u(x)for x in n)if isinstance(n,tuple)else n
 proposal=replace_u(a.expanded('rho8'))
 checks=[]
 for av,bv,cv in itertools.product(V,repeat=3):
  result=a.evaluate(proposal,dict(a=av,b=bv,c=cv),ops,val)
  need(result in D,'Dependent-membership proposal failed');checks.append(result)
 # All natural U=4P(A,B)+1 has value f, including when A or B is itself
 # a formula code. No assignment-richness or equality interpretation required.
 need(C(t,t)==t,'The native code0 collision is incompatible')
 optional={}
 for name,arity,term in [('identity',1,lambda x:C(x,x)),('EFQ',1,lambda x:C(f,x)),('K',2,lambda x,y:C(x,C(y,x)))]:
  failures=[list(v)+[term(*v)] for v in itertools.product(V,repeat=arity)if term(*v)not in D]
  optional[name]=dict(valid=not failures,finite_failures=failures)
 need(optional['identity']['valid'] and not optional['EFQ']['valid'] and not optional['K']['valid'],'Optional-row scope changed')
 I=a.CODE_OPS['wim'];efq=I(1,3);k=I(1,I(0,1))
 need((efq,k)==(52,212)and val(efq)not in D and val(k)not in D,'Bad explicit extension witnesses')
 old_receipt=json.loads(a.EMITTER.read_text())
 for name,key in [('growG','row'),('bundle222','bundle')]:
  need(a.receipt_tree(a.expanded(name))==old_receipt[key]['new_expression'],'Current emitted AST mismatch')
 out=dict(unpair_iter_vs_isqrt_checks=2049,status='DEPENDENT_MEMBERSHIP_PROPOSAL_OBSTRUCTED_BY_FINITE_MODEL',upstream_commit='1eaaad5d3a736cfd6d6d0dc2b7d49e3cafacba9d',upstream_url='https://github.com/VladimirReshetnikov/ProveIt/blob/1eaaad5d3a736cfd6d6d0dc2b7d49e3cafacba9d/Computability/BusyBeaver/Research/ZFC/k219-fourth-parameter/README.md',model=model,retained_current_audit=receipt,proposal_ast=a.receipt_tree(proposal),proposal_algebra_checks=len(checks),proposal_values=sorted(set(checks)),optional_rows=optional,extension_counterexamples=dict(EFQ=dict(target=3,code=efq,value=val(efq)),K=dict(a=1,b=0,code=k,value=val(k))),source_hashes={str(p.relative_to(ROOT)):sha(p)for p in [path,a.KCODE,a.LOGIC,a.CURRENT/'Codes222.v',a.CURRENT/'Thm222.v',a.EMITTER]},scope='Elementary all-natural consistency proof by well-founded code valuation plus derivation induction; no blanket verdict about added EFQ/K or arbitrary alternative semantics; arithmetic formalizability argued, not a new Rocq/Lean endpoint')
 (HERE/'reports/result.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps({k:out[k]for k in ['status','proposal_algebra_checks','optional_rows','extension_counterexamples']},indent=2))
if __name__=='__main__':main()
