#!/usr/bin/env python3
"""Independent audit against the literal current Coq natural-code definitions.

Only model JSON data are reused. No solver or earlier checker is imported.
The source parser, numeric-code evaluator, and finite law checks are independent.
Portable helper for check_proposal.py and check_upstream.py. No solver imports.
"""
from __future__ import annotations

import functools
import hashlib
import itertools
import json
import math
import pathlib
import re
import sys

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE
KCODE = ROOT / "inputs/coq/KCode230.v"
LOGIC = ROOT / "inputs/coq/Codes230.v"
CURRENT = ROOT / "inputs/coq"
EMITTER = ROOT / "inputs/source_emitter_receipt.json"


def need(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pair(a, b):
    return (a + b) * (a + b + 1) // 2 + b


def unpair(z):
    diagonal = (math.isqrt(8 * z + 1) - 1) // 2
    right = z - diagonal * (diagonal + 1) // 2
    return diagonal - right, right


PRIMITIVES = {"wim": 2, "wel": 2, "wal": 2, "weq": 2}
DEFS = {}


def read_definitions(path, names):
    """Small checked parser for the exact expression fragment in these files."""
    text = re.sub(r"\(\*.*?\*\)", "", path.read_text(), flags=re.S)
    for name in names:
        match = re.search(
            rf"\bDefinition\s+{name}\b(.*?)\s*:\s*nat\s*:=\s*(.*?)\.", text, re.S
        )
        need(match is not None, f"Missing definition {name}")
        signature, body = match.groups()
        params = []
        for group in re.findall(r"\((.*?)\s*:\s*nat\s*\)", signature, flags=re.S):
            params.extend(group.split())
        tokens = re.findall(r"[A-Za-z_][A-Za-z_0-9]*|[0-9]+|[()]", body)
        need("".join(tokens) == re.sub(r"\s+", "", body), f"Unknown syntax: {body}")
        cursor = 0

        def term():
            nonlocal cursor
            token = tokens[cursor]
            cursor += 1
            if token == "(":
                result = term()
                need(tokens[cursor] == ")", "Unbalanced parentheses")
                cursor += 1
                return result
            if token.isdigit():
                return int(token)
            if token in params:
                return token
            arity = PRIMITIVES.get(token)
            if arity is None and token in DEFS:
                arity = len(DEFS[token][0])
            need(arity is not None, f"Unknown name: {token}")
            return (token, *(term() for _ in range(arity)))

        result = term()
        need(cursor == len(tokens), f"Trailing syntax in {name}")
        DEFS[name] = (tuple(params), result)


read_definitions(KCODE, ["F", "wn", "wa", "wex"])
read_definitions(LOGIC, [f"rho{i}" for i in range(1, 9)])
read_definitions(CURRENT / "Codes222.v", ["growG", "nks222", "vrel", "bundle222"])


def expand(node, env=None):
    env = env or {}
    if isinstance(node, int):
        return node
    if isinstance(node, str):
        return env.get(node, node)
    head, *args = node
    args = [expand(arg, env) for arg in args]
    if head in PRIMITIVES:
        return (head, *args)
    params, body = DEFS[head]
    return expand(body, dict(zip(params, args)))


def expanded(name):
    params, body = DEFS[name]
    return expand(body)


def receipt_tree(node):
    if not isinstance(node, tuple):
        return node
    return [
        {"wim": "I", "wel": "R", "wal": "Q", "weq": "E"}[node[0]],
        *(receipt_tree(arg) for arg in node[1:]),
    ]


def evaluate(node, env, operations, constants):
    if isinstance(node, int):
        return constants(node)
    if isinstance(node, str):
        return env[node]
    return operations[node[0]](
        *(evaluate(arg, env, operations, constants) for arg in node[1:])
    )


CODE_OPS = {
    "wim": lambda a, b: 4 * pair(a, b),
    "wel": lambda a, b: 4 * pair(a, b) + 1,
    "wal": lambda a, b: 4 * pair(a, b) + 2,
    "weq": lambda a, b: 4 * pair(a, b) + 3,
}


def audit(path):
    model = json.loads(path.read_text())
    need(model["status"] == "sat", f"Not a model: {path}")
    n = model["n"]
    universe = range(n)
    designated = set(model["D"])
    arrow = model["table"]
    quantifier = model["Q"]
    zero, member, equality = model["T"], model["F"], model["eq"]
    need(len(arrow) == n and all(len(row) == n for row in arrow), "Bad arrow shape")
    need(len(quantifier) == n, "Bad quantifier shape")
    need(all(v in universe for row in arrow for v in row), "Arrow not closed")
    need(all(v in universe for v in quantifier), "Quantifier not closed")
    need({zero, member, equality} <= set(universe), "Bad atom value")
    need(designated <= set(universe), "Bad designated value")

    @functools.cache
    def value(code):
        need(isinstance(code, int) and code >= 0, "Not a natural code")
        if code == 0:
            return zero
        left, right = unpair(code // 4)
        need(pair(left, right) == code // 4, "Pair inverse failure")
        need(left <= code // 4 and right <= code // 4 < code, "Not lower children")
        tag = code % 4
        if tag == 0:
            return arrow[value(left)][value(right)]
        if tag == 1:
            return member
        if tag == 2:
            return quantifier[value(right)]
        return equality

    algebra = {
        "wim": lambda a, b: arrow[a][b],
        "wel": lambda a, b: member,
        "wal": lambda a, b: quantifier[b],
        "weq": lambda a, b: equality,
    }
    tests = {}

    def law(name, results):
        results = list(results)
        tests[name] = {"cases": len(results), "pass": all(results)}

    law("W_true", [zero in designated])
    law("wim_0_0_collision", [arrow[zero][zero] == zero])
    law("W_mp", [
        a not in designated or arrow[a][b] not in designated or b in designated
        for a, b in itertools.product(universe, repeat=2)
    ])
    law("W_gen", [a not in designated or quantifier[a] in designated for a in universe])
    for name in [*(f"rho{i}" for i in range(1, 7)), "growG", "bundle222"]:
        params, _ = DEFS[name]
        formula = expanded(name)
        bad = []
        vals = set()
        for args in itertools.product(universe, repeat=len(params)):
            v = evaluate(formula, dict(zip(params, args)), algebra, value)
            vals.add(v)
            if v not in designated:
                bad.append({"arguments": dict(zip(params, args)), "value": v})
        tests[name] = {
            "cases": n ** len(params),
            "pass": not bad,
            "values": sorted(vals),
            "first_failure": bad[:1],
        }
    restricted = model["variant"]
    bad = []
    for a, b, c in itertools.product(universe, repeat=3):
        if len(restricted) == 3 and restricted[0] == "C":
            atoms = {"a": a, "b": b, "c": c, "F": member}
            need(restricted[1] in atoms and restricted[2] in atoms, "Unknown constructor term")
            u = arrow[atoms[restricted[1]]][atoms[restricted[2]]]
        else:
            u = {"a": a, "b": b, "c": c, "F": member, "T": zero, "cc": arrow[c][c]}[restricted]
        v = evaluate(expanded("rho8"), dict(a=a, b=b, c=c, u=u), algebra, value)
        if v not in designated:
            bad.append({"arguments": dict(a=a, b=b, c=c, u=u), "value": v})
    tests["rho8_restricted"] = {"cases": n ** 3, "pass": not bad, "first_failure": bad[:1]}

    # Concrete number evaluation independently checks interpretation against construction.
    for code in range(10001):
        value(code)
    for a, b in itertools.product(range(41), repeat=2):
        for constructor, operation in CODE_OPS.items():
            expected = algebra[constructor](value(a), value(b))
            need(value(operation(a, b)) == expected, f"Constructor law {constructor}")

    concrete_checks = 0
    concrete_bundle_failure = None
    for name in [*(f"rho{i}" for i in range(1, 9)), "growG", "bundle222"]:
        params, _ = DEFS[name]
        formula = expanded(name)
        for args in itertools.product(range(4), repeat=len(params)):
            env = dict(zip(params, args))
            v = evaluate(formula, {p: value(a) for p, a in env.items()}, algebra, value)
            # A current bundle's decimal numeral can have hundreds of thousands
            # of digits. Keep that code as its exact constructor expression;
            # the general constructor identities, not a huge numeral, justify it.
            if name != "bundle222":
                code = evaluate(formula, env, CODE_OPS, lambda x: x)
                need(value(code) == v, f"Source expression/code mismatch {name}")
                concrete_checks += 1
            if name == "bundle222" and env["c"] not in (env["a"], env["b"]) and v not in designated:
                concrete_bundle_failure = concrete_bundle_failure or {
                    "arguments": env, "code_expression": f"bundle222 {env['a']} {env['b']} {env['c']}", "value": v,
                    "gate_enabled": True,
                }

    # All values used in a negative witness must be represented by actual natural codes.
    representatives = {}
    for code in (0, 1, 3):
        representatives.setdefault(value(code), code)
    while True:
        updated = dict(representatives)
        for v, code in representatives.items():
            target = quantifier[v]
            newcode = CODE_OPS["wal"](0, code)
            updated[target] = min(updated.get(target, newcode), newcode)
        for a, b in itertools.product(representatives, repeat=2):
            target = arrow[a][b]
            newcode = CODE_OPS["wim"](representatives[a], representatives[b])
            updated[target] = min(updated.get(target, newcode), newcode)
        if updated == representatives:
            break
        representatives = updated
    need(len(representatives) == n, "Not all finite values realized by codes")
    need(all(value(code) == v for v, code in representatives.items()), "Bad representatives")

    # Neither the actual integer witnesses nor their values are read from old receipts.
    I = CODE_OPS["wim"]
    basis = {
        "identity": lambda a, b, c: I(a, a),
        "K": lambda a, b, c: I(a, I(b, a)),
        "S": lambda a, b, c: I(I(a, I(b, c)), I(I(a, b), I(a, c))),
        "Peirce": lambda a, b, c: I(I(I(a, b), a), a),
    }
    witnesses = {}
    for args in itertools.product(sorted(representatives.values()), repeat=3):
        for name, constructor in basis.items():
            code = constructor(*args)
            if value(code) not in designated and name not in witnesses:
                witnesses[name] = dict(arguments=args, code=code, value=value(code))
    for args in itertools.product(sorted(representatives.values()), repeat=4):
        env = dict(zip(("a", "b", "c", "u"), args))
        code = evaluate(expanded("rho8"), env, CODE_OPS, lambda x: x)
        if value(code) not in designated:
            witnesses["full_rho8"] = dict(arguments=env, code=code, value=value(code))
            break

    sound = all(test["pass"] for test in tests.values())
    return {
        "file": str(path.relative_to(ROOT)),
        "sha256": digest(path),
        "variant": restricted,
        "finite_values": n,
        "current_code_calculus_sound": sound,
        "F_undesignated": member not in designated,
        "code3_designated": equality in designated,
        "proves_no_derivation_of_F": sound and member not in designated,
        "algebra_laws": tests,
        "concrete_source_constructor_checks": concrete_checks,
        "concrete_current_bundle_failure": concrete_bundle_failure,
        "code_representatives": representatives,
        "negative_witness_codes": witnesses,
        "negative_witnesses_currently_underivable": sound,
    }

