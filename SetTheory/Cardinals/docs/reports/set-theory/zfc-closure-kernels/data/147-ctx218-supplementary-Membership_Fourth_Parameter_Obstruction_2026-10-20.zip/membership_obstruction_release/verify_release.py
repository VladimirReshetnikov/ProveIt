#!/usr/bin/env python3
"""Verify package hashes and replay both finite checks offline (stdlib only)."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

HERE = Path(__file__).resolve().parent

def verify_files():
    manifest = json.loads((HERE / 'MANIFEST.json').read_text())
    for row in manifest['files']:
        path = HERE / row['path']
        data = path.read_bytes()
        if len(data) != row['bytes'] or hashlib.sha256(data).hexdigest() != row['sha256']:
            raise SystemExit('Integrity mismatch: ' + row['path'])
    return len(manifest['files'])

count = verify_files()
for script in ('check_proposal.py', 'check_upstream.py'):
    run = subprocess.run([sys.executable, '-B', str(HERE / script)],
                         cwd=HERE, text=True, capture_output=True)
    if run.returncode:
        print(run.stdout)
        print(run.stderr, file=sys.stderr)
        raise SystemExit(run.returncode)
    print(script + ': PASS')
verify_files()
print(json.dumps({'status': 'PORTABLE_RELEASE_PASS',
                  'verified_files': count,
                  'regenerated_reports_byte_identical': True,
                  'network_required': False,
                  'third_party_python_packages_required': False}, indent=2))
