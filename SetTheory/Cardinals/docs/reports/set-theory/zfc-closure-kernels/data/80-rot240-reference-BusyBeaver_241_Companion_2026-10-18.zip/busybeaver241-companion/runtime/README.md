# Independently verified 241-state reduction

The exact primary candidate passes a fresh arbitrary-tape mapped simulation, independent sparse/dense whole-blank checks, the complete unbounded runtime proof, and133 additional arbitrary-frame concrete cross-checks. The source program is unchanged from the calibrated combined243/primary242 chain.

## Exact artifact

- 241 working states, including initialization;482 binary rows; one separate halt
- Canonical working states0–240, start0, dispatcher85, halt241
- Inherited start95, dispatcher96, halt254
- Canonical table:`candidate_1.tm`
- Canonical SHA-256:`c5278eaf0561cd12d676b3e9c030ffe46d5bc7ec94d29d705dee31a72ea95158`
- Inherited table:`candidate_1_old.tm`
- Inherited SHA-256:`1fa8526c3c971d5a48868599eaed890f614c5a79256e51622d3e32a64229f3a3`
- Base primary242 SHA-256:`c8ef2f44d25fee6813164cc59ec05061799397da8cf7f0ea7baab63d32d76e02`

The final table needs no incidental neutral-background edits. Delete inherited state39. Replace17/0 by`0 L 106`,17/1 by`1 L 37`, and redirect46/0 and50/0 from39 to17. Every other retained row is unchanged.

## Small all-tape proof

The old-side invariant says that state17 has a1 immediately left of the head and state39 has a0 immediately left. It is vacuous at shared start95. The only incoming row to17 is12/1, which writes1 and moves right. The only incoming rows to39 are46/0 and50/0, both writing0 and moving right. Therefore the invariant is one-step inductive on arbitrary binary tapes.

Map old39 to new17 and leave every other control, including halt, unchanged. Relate configurations by this control map and equality of the entire tape and head. Each old transition is matched by one new transition except:

- Old17/0: five new transitions through106,92,107 and125, ending at25
- Old17/1: three new transitions through37 and55, ending at20
- Old39/0: three new transitions through106 and93, ending at57
- Old39/1: three new transitions through37 and25, ending at69

The independent checker discovers the matching positive duration from the literal tables and verifies7,712 invariant implications and7,712 complete-tape blocks over all five-cell assignments. Every read/write is checked to remain inside offsets−2 through2; the arbitrary exterior is untouched. No matching block passes through halt. The clocks are1,3 or5, so induction proves both halting directions and rules out collapse of an infinite old run into finite new time.

Consequently the two machines have equivalent halting from95 for every integer head position and every two-way binary tape, including infinite support. The exact clock formula at paired endpoints is

`t_new = t_old + 4*old_visits(17,0) + 2*old_visits(17,1) + 2*old_visits(39,0) + 2*old_visits(39,1)`.

In particular `t_old <= t_new <= 5*t_old`. This is an ordinary mathematical all-tape theorem, not a claim inferred from finite testing or source reachability.

## Initialization and runtime

The new blank machine reaches the exact calibrated frame after408,419 transitions. Separate sparse inherited-label and dense canonical simulations agree on the entire tape: dispatcher96/85, head−5, marker−6, header176, logical registers(3,0,0,0,3,0,0,0,0),167 value-one spares,351 one-cells and zero elsewhere.

The old242 prefix has407,979 transitions and visits17/0 fifteen times,17/1 three times,39/0 132 times and39/1 fifty-five times. The exact formula gives440 extra transitions, independently agreeing with the actual new simulation.

The exact unchanged6,459-leaf QT source has SHA-256`3ee984818f0bdfd2c4daae72aeb14340572e34d73f5cdb5616b6d29d78fcd7f4`. All8,390 guarded cases pass the direct universal runtime checker:2,319,442 symbolic rules, all482 rows exercised, minimum derived duration13. The full run took177.83seconds. Four arbitrary-block traversal schemas are freshly derived from the exact new table. The proof quantifies all independent natural primary registers, extra header gap, an arbitrary first spare value and arbitrary finite remaining spare list. Its4,000-rule construction cap is not a runtime or data bound.

Another133 arbitrary concrete register/gap/spare instances agree with the symbolic durations and motions and independent dense/sparse entire tapes. These finite instances are implementation tests, separate from the unbounded induction proof.

The generic symbolic proof kernel and helper are byte-identical to the independently audited242/243 copies. No supplied executable program was executed or imported. Candidate table and source files were parsed only as data.

## Composition and limitations

The source tree, logical-to-physical register permutation and source-frame contracts are unchanged. The independently checked QT source rotation, original-to-routed source bisimulation, whole-frame successor closure and inherited consistency calibration therefore compose with this reduction. The all-tape theorem also directly transports whatever halting calibration is valid for the exact primary242 table.

No fresh Lean/Rocq kernel endpoint is claimed. The complete exact243 Lean consistency endpoint remains open; the earlier relative machine theorem does not close that source bridge, and no241 endpoint is silently inherited from a different artifact. The local all-tape equivalence has no consistency assumption. Actual nonhalting still depends on the inherited consistency premise. No absolute consistency, unconditional nonhalting, global minimality or two-sided independence from bare consistency is asserted.

## Reproduction

Use Python3 with assertions enabled and`-B`:

1. `python3 -B check_local_and_boot.py`
2. `python3 -B crosscheck_instantiation.py`
3. `python3 -B run_symbolic_checked.py --table candidate_1_old.tm --sites sites_logical.json --output fresh_universal.json`

The first script checks the literal patch, control map, totality and both entire-tape boot implementations, and regenerates the canonical table and renumbering. The complete runtime output must have8,390 cases and2,319,442 symbolic rules. `REVIEW_RESULT.json` summarizes the terminal evidence;`ARTIFACT_MANIFEST.json` binds all files.

The predecessor source bridge and frozen242 package remain separate dependencies. Their exact source/table hashes above identify the chain. This directory is a review of the primary241 machine only; no other241 proposal is covered implicitly.
