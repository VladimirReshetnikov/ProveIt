# A 241-state reduction using a predecessor bit

This is a separate, self-contained companion to the frozen 242-state release. The primary machine has 241 working states including initialization, 482 binary transition rows, canonical start 0, dispatcher 85, and one separate halt 241. It is obtained by deleting inherited state 39 from the recommended 242 machine and synthesizing both rows at retained 17.

The ordinary proof establishes two-way halting equivalence from inherited 95 with every integer head and every binary tape, including infinite support. The old 17 predecessor writes a left 1; old 39 predecessors write a left 0. That existing tape bit distinguishes the two roles. One old step is matched by 1, 3, or 5 new steps. No source or blank-reachability premise is required for this local theorem.

## Exact primary result

- Canonical table: `runtime/candidate_1.tm`
- Inherited-label table: `runtime/candidate_1_old.tm`
- Canonical SHA-256: c5278eaf0561cd12d676b3e9c030ffe46d5bc7ec94d29d705dee31a72ea95158
- Inherited SHA-256: 1fa8526c3c971d5a48868599eaed890f614c5a79256e51622d3e32a64229f3a3
- Base 242 SHA-256: c8ef2f44d25fee6813164cc59ec05061799397da8cf7f0ea7baab63d32d76e02
- Two separately written finite-local checks: 7,712 invariant implications and 7,712 whole-tape blocks
- Exact sparse/dense blank initialization: 408,419 transitions; complete tape identical to 242, with 351 one-cells and zero elsewhere
- Direct unbounded runtime: 8,390 guarded cases, 2,319,442 symbolic rules, all 482 rows, minimum duration 13
- Additional concrete dense/sparse/symbolic comparisons: 133

The exact time formula is t_new=t_old+4*visits(17,0)+2*(visits(17,1)+visits(39,0)+visits(39,1)). During the old 407,979-step bootstrap, those counts are 15, 3, 132, 55; the new prefix adds 440 steps. Its complete tape has head -5, marker -6, header 176, logical values (3,0,0,0,3,0,0,0,0), and 167 spare blocks of value 1.

Read `report.pdf` or its editable `report.tex` for the complete two-guard proof, all four exact paths, mechanism, runtime contract, calibration, and limitations. Other 241 variants and subsequent searches are outside this primary companion.

## Direct construction from combined243

`DIRECT_CONSTRUCTION.json` gives all eight edits in inherited labels: delete 27 and 39; set 15/0=0L32, 17/0=0L106, 17/1=1L37; redirect 18/0, 47/0, 65/0 to 15 and 46/0, 50/0 to 17. Every other retained row is unchanged. The runner checks this direct diff. The semantic proof composes through the exact 242 intermediate. Relative to routed245, the deleted labels are 26, 27, 39, 122. The 408,419-step blank prefix is independently simulated.

## Reproduce from a clean extraction

Use Python 3.10 or later with assertions enabled:

    python3 -B verify_all.py --output replay_result.json

The runner uses only the Python standard library. It makes no network requests and does not execute downloaded repository programs. It first checks the companion manifest and the exact dependency archive. It safely extracts a temporary working copy, leaving all recorded evidence and the delivered 242 archive unchanged.

Fresh work in this replay:

1. Every inherited package binding, the 242/243 local proof chain, source rotation and frame closure, exact bootstrap checks, and inherited concrete comparisons
2. Both new 241 finite-local proofs, whole-tape sparse/dense startup, exact clock formula, and 133 concrete instances
3. One complete new 241 unbounded runtime replay; all 8,390 derived case records must exactly equal the independent sealed outputs

The previous full 242/243 universal receipts remain explicitly inherited. They were already freshly replayed and independently audited for the frozen release; the companion does not relabel them as new executions. Their complete checkers and data remain available inside the dependency ZIP if another full historical replay is wanted.

A terminal `FULL_FRESH_241_COMPANION_REPLAY_PASS` means the fresh primary 241 universal run and every listed other gate completed. `--quick` skips only that primary 241 universal run and reports `QUICK_COMPANION_REPLAY_PASS`; it is not a substitute for the full result. -O and PYTHONOPTIMIZE are rejected.

The final external validation receipt binds the exact companion ZIP hash to its actual extraction replay. It is outside the ZIP to avoid a circular self-hash.

## Package layout

- `runtime/`: primary tables, renumbering, independent proof/boot/runtime/concrete checkers, terminal summaries and every guarded case
- `root-proof/`: separately written simple mapped proof and clock/bootstrap check, adapted to package-relative inputs with fail-closed assertions
- `provenance/`: original root receipts/code and primary construction provenance; adapter changes and source hashes
- `dependencies/`: byte-for-byte frozen 242 ZIP, its release-file pins, full extraction receipt, and independent final audit
- `licenses/`: verbatim inherited licenses/notices, also preserved in the frozen dependency
- `MANIFEST.json`: authoritative companion inventory; the nested independent manifests remain historical records for their respective exact collections

All transition files use `state read write direction next_state`, with L/R directions. The canonical table is headerless. Inherited start/dispatcher/halt are 95/96/254. `renumbering.json` includes the halt mapping. The source remains the exact 6,459-leaf QT list, SHA-256 3ee984818f0bdfd2c4daae72aeb14340572e34d73f5cdb5616b6d29d78fcd7f4.

## Mechanism and limits

Both retained rows are synthesized: 17/0 becomes 0L106 and 17/1 becomes 1L37. Neither simply selects its corresponding row from old 17 or 39. Earlier negative searches confined to copying row overlays or synthesizing a single retained row therefore did not cover this mechanism. This is an explanation of search scope, not a historical-novelty or minimality claim.

The local equivalence has no consistency premise. The ZFC consistency calibration is inherited through the exact 242 and 243 chain and the previously calibrated original program. No complete source-theory reconstruction, new Lean/Rocq endpoint, internal PA result, unconditional nonhalting, absolute consistency, or two-sided independence from mere consistency is claimed. At the cited ProveIt source snapshot e58338db7545909907e07a7603e8eb88625c527a, the exact 243 Lean source bridge was not completed. This describes that pinned snapshot, not the status of later repository commits.

Credits remain with Mira-Cult, Jeff Ketchersid, Andrew James Wade, ProveIt, the earlier compensated/QT contributions, and the supplied neutral-edit/sequential-background research as recorded in their artifacts. This investigation contributes the direct 17/39 fold, explicit two-guard proof, independent validation, and companion. No incidental discovery-background edits survive in the final table, no supplied code was run, and no inherited work is relicensed. No repository write is part of this package.

With a configured TeX Live installation, rebuild the PDF using `pdflatex -no-shell-escape report.tex` twice. Python verification does not depend on TeX.

## Discovery provenance

The supplied `zfc-sub244-research-20261018.zip` neutral-edit family guided discovery (SHA-256 b96bb5c754ccaaf26799788a7b4d45a313259781db2be4dd1d954af7a72ab5d2; ProveIt source pin 248bc0593651331065ae558802a914110562d20a). Own checkers rederived it on the primary 242 table and searched 677,121 recipes, with five positive local constructions. Every incidental background edit was removed before the final direct four-row proof. Reuse of that supplied idea and data is credited separately from this concrete 241 construction and its proof. No supplied program was executed or imported. The discovery ZIP bytes are not needed for this self-contained proof; their exact identities and intake checks are retained in `provenance/construction_provenance.json`.
